<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN">
<html lang="cz">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<title>MR, Praha</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
</head>
<body class="neop">
<a name="Zac"><p class=l>MR, Praha, 6. červen 2009</p></a>
<div align=center>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=2 cellspacing=0>
<tr><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>&nbsp;</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1</td><td class=kt>A.Vargová</td><td class=kx>*</td>
<td class=k>4:1 + 1:1</td>
<td class=k>2:1 + 2:3</td>
<td class=k>2:2 + 2:1</td>
<td class=k>3:0 + 2:0</td>
<td class=k>2:0 + 4:0</td>
<td class=br>24:9</td>
<td class=bc>7 - 2 - 1</td>
<td class=br>23</td>
<td class=d>1.</td>
</tr><tr><td class=ir>2</td><td class=kt>M.Vargová</td><td class=k>1:4 + 1:1</td>
<td class=kx>*</td>
<td class=k>1:0 + 2:2</td>
<td class=k>3:0 + 2:0</td>
<td class=k>3:1 + 4:0</td>
<td class=k>5:2 + 5:3</td>
<td class=br>27:13</td>
<td class=bc>7 - 2 - 1</td>
<td class=br>23</td>
<td class=d>2.</td>
</tr><tr><td class=ir>3</td><td class=kt>A.Jackowská</td><td class=k>1:2 + 3:2</td>
<td class=k>0:1 + 2:2</td>
<td class=kx>*</td>
<td class=k>1:1 + 4:2</td>
<td class=k>2:0 + 0:0</td>
<td class=k>6:1 + 3:1</td>
<td class=br>22:12</td>
<td class=bc>5 - 3 - 2</td>
<td class=br>18</td>
<td class=d>3.</td>
</tr><tr><td class=ir>4</td><td class=kt>M.Pilařová</td><td class=k>2:2 + 1:2</td>
<td class=k>0:3 + 0:2</td>
<td class=k>1:1 + 2:4</td>
<td class=kx>*</td>
<td class=k>3:0 + 1:1</td>
<td class=k>4:1 + 3:1</td>
<td class=br>17:17</td>
<td class=bc>3 - 3 - 4</td>
<td class=br>12</td>
<td class=d>4.</td>
</tr><tr><td class=ir>5</td><td class=kt>L.Vokounová</td><td class=k>0:3 + 0:2</td>
<td class=k>1:3 + 0:4</td>
<td class=k>0:2 + 0:0</td>
<td class=k>0:3 + 1:1</td>
<td class=kx>*</td>
<td class=k>5:4 + 2:3</td>
<td class=br>9:25</td>
<td class=bc>1 - 2 - 7</td>
<td class=br>5</td>
<td class=d>5.</td>
</tr><tr><td class=ir>6</td><td class=kt>I.Mašková</td><td class=k>0:2 + 0:4</td>
<td class=k>2:5 + 3:5</td>
<td class=k>1:6 + 1:3</td>
<td class=k>1:4 + 1:3</td>
<td class=k>4:5 + 3:2</td>
<td class=kx>*</td>
<td class=br>16:39</td>
<td class=bc>1 - 0 - 9</td>
<td class=br>3</td>
<td class=d>6.</td>
</tr></table></td></tr></table></div></p>


<p class=v>MR, Praha - zápasy o umístění (play-off matches)<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
</tr>
<tr><td class=bl>Finále</td>
<td class=br>Vargová Anežka</td>
<td class=bl><b>- Vargová Marie</b></td>
<td class=bl>1:4&nbsp;&nbsp;</td>
<td class=bl>1:2&nbsp;&nbsp;</td>
<td class=bl>0:5 P&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=al>Semifinále</td>
<td class=ar><b>Vargová Anežka</b></td>
<td class=al>- Pilařová Markéta</td>
<td class=al>0:1&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=bl>Semifinále</td>
<td class=br><b>Vargová Marie</b></td>
<td class=bl>- Jackowská Aneta</td>
<td class=bl>3:2 P&nbsp;&nbsp;</td>
<td class=bl>0:1&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=al>O 3.místo</td>
<td class=ar><b>Jackowská Aneta</b></td>
<td class=al>- Pilařová Markéta</td>
<td class=al>5:0&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr>
</table>
</td></tr></table>

<p class=v>Konečné pořadí turnaje<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>Z</th>
<th>+</th>
<th>=</th>
<th>-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>B</th>
<th>&nbsp;</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al>Vargová Marie</td>
<td class=al>BSE České Budějovice</td>
<td class=ar>16</td>
<td class=ar>12</td>
<td class=ar>2</td>
<td class=ar>2</td>
<td class=ar>45</td>
<td class=al>: 19</td>
<td class=ar>38</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>2.</td>
<td class=bl>Vargová Anežka</td>
<td class=bl>BSE České Budějovice</td>
<td class=br>16</td>
<td class=br>9</td>
<td class=br>2</td>
<td class=br>5</td>
<td class=br>31</td>
<td class=bl>: 24</td>
<td class=br>29</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>3.</td>
<td class=al>Jackowská Aneta</td>
<td class=al>BSE České Budějovice</td>
<td class=ar>15</td>
<td class=ar>8</td>
<td class=ar>3</td>
<td class=ar>4</td>
<td class=ar>33</td>
<td class=al>: 20</td>
<td class=ar>27</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>4.</td>
<td class=bl>Pilařová Markéta</td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>15</td>
<td class=br>4</td>
<td class=br>3</td>
<td class=br>8</td>
<td class=br>22</td>
<td class=bl>: 29</td>
<td class=br>15</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>5.</td>
<td class=al>Vokounová Lucie</td>
<td class=al>Kamax K.Újezdec</td>
<td class=ar>10</td>
<td class=ar>1</td>
<td class=ar>2</td>
<td class=ar>7</td>
<td class=ar>9</td>
<td class=al>: 25</td>
<td class=ar>5</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>6.</td>
<td class=bl>Mašková Iva</td>
<td class=bl>SHC Cheb</td>
<td class=br>10</td>
<td class=br>1</td>
<td class=br>0</td>
<td class=br>9</td>
<td class=br>16</td>
<td class=bl>: 39</td>
<td class=br>3</td>
<td class=br>&nbsp;</td>
</tr></table></td></tr></table></div></p>


</body></html>