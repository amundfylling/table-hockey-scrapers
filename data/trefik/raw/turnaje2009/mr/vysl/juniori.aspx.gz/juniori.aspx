<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN">
<html lang="cz">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<title>MR, Praha</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
</head>
<body class="neop">
<a name="Zac"><p class=l>MR juniorů, Praha, 6. červen 2009</p></a>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=2 cellspacing=0>
<tr><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>&nbsp;</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1</td><td class=kt>M.Ležík</td><td class=kx>*</td>
<td class=k>4:2</td>
<td class=k>3:1</td>
<td class=k>6:3</td>
<td class=k>4:2</td>
<td class=k>2:3</td>
<td class=k>9:1</td>
<td class=k>8:1</td>
<td class=k>6:2</td>
<td class=k>9:1</td>
<td class=br>51:16</td>
<td class=bc>8 - 0 - 1</td>
<td class=br>24</td>
<td class=d>1.</td>
</tr><tr><td class=ir>2</td><td class=kt>E.Šlechta</td><td class=k>2:4</td>
<td class=kx>*</td>
<td class=k>0:4</td>
<td class=k>6:3</td>
<td class=k>4:2</td>
<td class=k>4:2</td>
<td class=k>4:3</td>
<td class=k>4:2</td>
<td class=k>5:1</td>
<td class=k>6:1</td>
<td class=br>35:22</td>
<td class=bc>7 - 0 - 2</td>
<td class=br>21</td>
<td class=d>2.</td>
</tr><tr><td class=ir>3</td><td class=kt>M.Lisý</td><td class=k>1:3</td>
<td class=k>4:0</td>
<td class=kx>*</td>
<td class=k>3:3</td>
<td class=k>3:3</td>
<td class=k>6:1</td>
<td class=k>7:1</td>
<td class=k>5:4</td>
<td class=k>6:1</td>
<td class=k>6:2</td>
<td class=br>41:18</td>
<td class=bc>6 - 2 - 1</td>
<td class=br>20</td>
<td class=d>3.</td>
</tr><tr><td class=ir>4</td><td class=kt>P.Petr</td><td class=k>3:6</td>
<td class=k>3:6</td>
<td class=k>3:3</td>
<td class=kx>*</td>
<td class=k>4:2</td>
<td class=k>0:2</td>
<td class=k>6:0</td>
<td class=k>4:2</td>
<td class=k>2:0</td>
<td class=k>7:1</td>
<td class=br>32:22</td>
<td class=bc>5 - 1 - 3</td>
<td class=br>16</td>
<td class=d>4.</td>
</tr><tr><td class=ir>5</td><td class=kt>F.Hamáček</td><td class=k>2:4</td>
<td class=k>2:4</td>
<td class=k>3:3</td>
<td class=k>2:4</td>
<td class=kx>*</td>
<td class=k>6:1</td>
<td class=k>5:3</td>
<td class=k>3:1</td>
<td class=k>7:0</td>
<td class=k>6:1</td>
<td class=br>36:21</td>
<td class=bc>5 - 1 - 3</td>
<td class=br>16</td>
<td class=d>5.</td>
</tr><tr><td class=ir>6</td><td class=kt>R.Nevrlík</td><td class=k>3:2</td>
<td class=k>2:4</td>
<td class=k>1:6</td>
<td class=k>2:0</td>
<td class=k>1:6</td>
<td class=kx>*</td>
<td class=k>3:6</td>
<td class=k>1:0</td>
<td class=k>4:2</td>
<td class=k>3:1</td>
<td class=br>20:27</td>
<td class=bc>5 - 0 - 4</td>
<td class=br>15</td>
<td class=d>6.</td>
</tr><tr><td class=ir>7</td><td class=kt>Š.Janoušek</td><td class=k>1:9</td>
<td class=k>3:4</td>
<td class=k>1:7</td>
<td class=k>0:6</td>
<td class=k>3:5</td>
<td class=k>6:3</td>
<td class=kx>*</td>
<td class=k>4:3</td>
<td class=k>5:5</td>
<td class=k>3:2</td>
<td class=br>26:44</td>
<td class=bc>3 - 1 - 5</td>
<td class=br>10</td>
<td class=d>7.</td>
</tr><tr><td class=ir>8</td><td class=kt>E.Vavruška</td><td class=k>1:8</td>
<td class=k>2:4</td>
<td class=k>4:5</td>
<td class=k>2:4</td>
<td class=k>1:3</td>
<td class=k>0:1</td>
<td class=k>3:4</td>
<td class=kx>*</td>
<td class=k>5:1</td>
<td class=k>5:1</td>
<td class=br>23:31</td>
<td class=bc>2 - 0 - 7</td>
<td class=br>6</td>
<td class=d>8.</td>
</tr><tr><td class=ir>9</td><td class=kt>M.Kouba</td><td class=k>2:6</td>
<td class=k>1:5</td>
<td class=k>1:6</td>
<td class=k>0:2</td>
<td class=k>0:7</td>
<td class=k>2:4</td>
<td class=k>5:5</td>
<td class=k>1:5</td>
<td class=kx>*</td>
<td class=k>2:2</td>
<td class=br>14:42</td>
<td class=bc>0 - 2 - 7</td>
<td class=br>2</td>
<td class=d>9.</td>
</tr><tr><td class=ir>10</td><td class=kt>O.Šmiták</td><td class=k>1:9</td>
<td class=k>1:6</td>
<td class=k>2:6</td>
<td class=k>1:7</td>
<td class=k>1:6</td>
<td class=k>1:3</td>
<td class=k>2:3</td>
<td class=k>1:5</td>
<td class=k>2:2</td>
<td class=kx>*</td>
<td class=br>12:47</td>
<td class=bc>0 - 1 - 8</td>
<td class=br>1</td>
<td class=d>10.</td>
</tr></table></td></tr></table></div></p>

<p class=v>MR, Praha - zápasy o umístění (play-off matches)<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
</tr>
<tr><td class=bl>Finále</td>
<td class=br><b>Ležík Matěj</b></td>
<td class=bl>- Lisý Marek</td>
<td class=bl>4:2&nbsp;&nbsp;</td>
<td class=bl>2:3 P&nbsp;&nbsp;</td>
<td class=bl>1:2 P&nbsp;&nbsp;</td>
<td class=bl>7:3&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=al>Semifinále</td>
<td class=ar><b>Ležík Matěj</b></td>
<td class=al>- Petr Patrik</td>
<td class=al>6:2&nbsp;&nbsp;</td>
<td class=al>1:4&nbsp;&nbsp;</td>
<td class=al>4:3 P&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=bl>Semifinále</td>
<td class=br>Šlechta Erik</td>
<td class=bl><b>- Lisý Marek</b></td>
<td class=bl>0:4&nbsp;&nbsp;</td>
<td class=bl>4:3 P&nbsp;&nbsp;</td>
<td class=bl>3:4 P&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=al>O 3.místo</td>
<td class=ar><b>Šlechta Erik</b></td>
<td class=al>- Petr Patrik</td>
<td class=al>3:5&nbsp;&nbsp;</td>
<td class=al>5:4 P&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=bl>Čtvrtfinále</td>
<td class=br><b>Ležík Matěj</b></td>
<td class=bl>- Vavruška Evžen</td>
<td class=bl>6:0&nbsp;&nbsp;</td>
<td class=bl>7:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=al>Čtvrtfinále</td>
<td class=ar><b>Šlechta Erik</b></td>
<td class=al>- Janoušek Šimon</td>
<td class=al>4:3&nbsp;&nbsp;</td>
<td class=al>4:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=bl>Čtvrtfinále</td>
<td class=br><b>Lisý Marek</b></td>
<td class=bl>- Nevrlík Radim</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=al>Čtvrtfinále</td>
<td class=ar><b>Petr Patrik</b></td>
<td class=al>- Hamáček Filip</td>
<td class=al>1:2&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>7:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr></table></td></tr></table></div></p>
<p>&nbsp;</p>


<p class=v>Konečné pořadí turnaje<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>Z</th>
<th>+</th>
<th>=</th>
<th>-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>B</th>
<th>&nbsp;</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al>Ležík Matěj</td>
<td class=al>SHC Votroci Hradec Králové</td>
<td class=ar>19</td>
<td class=ar>15</td>
<td class=ar>0</td>
<td class=ar>4</td>
<td class=ar>92</td>
<td class=al>: 37</td>
<td class=ar>45</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>2.</td>
<td class=bl>Lisý Marek</td>
<td class=bl>SHC Votroci Hradec Králové</td>
<td class=br>19</td>
<td class=br>12</td>
<td class=br>2</td>
<td class=br>5</td>
<td class=br>69</td>
<td class=bl>: 44</td>
<td class=br>38</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>3.</td>
<td class=al>Šlechta Erik</td>
<td class=al>THC Stiga-Game Příbram</td>
<td class=ar>17</td>
<td class=ar>12</td>
<td class=ar>0</td>
<td class=ar>5</td>
<td class=ar>61</td>
<td class=al>: 49</td>
<td class=ar>36</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>4.</td>
<td class=bl>Petr Patrik</td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>18</td>
<td class=br>9</td>
<td class=br>1</td>
<td class=br>8</td>
<td class=br>63</td>
<td class=bl>: 49</td>
<td class=br>28</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>5.</td>
<td class=al>Hamáček Filip</td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>12</td>
<td class=ar>6</td>
<td class=ar>1</td>
<td class=ar>5</td>
<td class=ar>41</td>
<td class=al>: 32</td>
<td class=ar>19</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>6.</td>
<td class=bl>Nevrlík Radim</td>
<td class=bl>THC Stiga Svitavy 93</td>
<td class=br>11</td>
<td class=br>5</td>
<td class=br>0</td>
<td class=br>6</td>
<td class=br>22</td>
<td class=bl>: 33</td>
<td class=br>15</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>7.</td>
<td class=al>Janoušek Šimon</td>
<td class=al>Kamax K.Újezdec</td>
<td class=ar>11</td>
<td class=ar>3</td>
<td class=ar>1</td>
<td class=ar>7</td>
<td class=ar>31</td>
<td class=al>: 52</td>
<td class=ar>10</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>8.</td>
<td class=bl>Vavruška Evžen</td>
<td class=bl>THC Stiga Svitavy 93</td>
<td class=br>11</td>
<td class=br>2</td>
<td class=br>0</td>
<td class=br>9</td>
<td class=br>24</td>
<td class=bl>: 44</td>
<td class=br>6</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>9.</td>
<td class=al>Kouba Martin</td>
<td class=al>BSE České Budějovice</td>
<td class=ar>9</td>
<td class=ar>0</td>
<td class=ar>2</td>
<td class=ar>7</td>
<td class=ar>14</td>
<td class=al>: 42</td>
<td class=ar>2</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>10.</td>
<td class=bl>Šmiták Ondřej</td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>9</td>
<td class=br>0</td>
<td class=br>1</td>
<td class=br>8</td>
<td class=br>12</td>
<td class=bl>: 47</td>
<td class=br>1</td>
<td class=br>&nbsp;</td>
</tr></table></td></tr></table></div></p>

</body>
</html>
