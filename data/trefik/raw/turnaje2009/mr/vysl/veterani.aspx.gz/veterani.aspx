<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN">
<html lang="cz">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<title>MR, Praha</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
</head>
<body class="neop">
<a name="Zac"><p class=l>MR veteráni, Praha, 6. červen 2009</p></a>
<div align=center>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=2 cellspacing=0>
<tr><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>&nbsp;</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1</td><td class=kt>P.Plešák</td><td class=kx>*</td>
<td class=k>1:2</td>
<td class=k>3:1</td>
<td class=k>7:2</td>
<td class=k>3:4</td>
<td class=k>4:2</td>
<td class=k>8:1</td>
<td class=k>4:1</td>
<td class=k>5:0</td>
<td class=k>5:2</td>
<td class=k>7:1</td>
<td class=k>2:1</td>
<td class=k>8:1</td>
<td class=k>9:1</td>
<td class=br>66:19</td>
<td class=bc>11 - 0 - 2</td>
<td class=br>33</td>
<td class=d>1.</td>
</tr><tr><td class=ir>2</td><td class=kt>P.Turoň</td><td class=k>2:1</td>
<td class=kx>*</td>
<td class=k>4:2</td>
<td class=k>3:7</td>
<td class=k>2:2</td>
<td class=k>2:1</td>
<td class=k>4:0</td>
<td class=k>2:2</td>
<td class=k>6:2</td>
<td class=k>3:1</td>
<td class=k>5:0</td>
<td class=k>5:3</td>
<td class=k>8:1</td>
<td class=k>8:0</td>
<td class=br>54:22</td>
<td class=bc>10 - 2 - 1</td>
<td class=br>32</td>
<td class=d>2.</td>
</tr><tr><td class=ir>3</td><td class=kt>Z.Pilař</td><td class=k>1:3</td>
<td class=k>2:4</td>
<td class=kx>*</td>
<td class=k>4:2</td>
<td class=k>5:0</td>
<td class=k>7:2</td>
<td class=k>4:5</td>
<td class=k>2:0</td>
<td class=k>2:1</td>
<td class=k>2:1</td>
<td class=k>4:0</td>
<td class=k>6:5</td>
<td class=k>5:3</td>
<td class=k>6:2</td>
<td class=br>50:28</td>
<td class=bc>10 - 0 - 3</td>
<td class=br>30</td>
<td class=d>3.</td>
</tr><tr><td class=ir>4</td><td class=kt>A.Šrajer</td><td class=k>2:7</td>
<td class=k>7:3</td>
<td class=k>2:4</td>
<td class=kx>*</td>
<td class=k>2:2</td>
<td class=k>0:4</td>
<td class=k>5:2</td>
<td class=k>4:1</td>
<td class=k>5:2</td>
<td class=k>2:2</td>
<td class=k>5:4</td>
<td class=k>4:3</td>
<td class=k>4:1</td>
<td class=k>3:2</td>
<td class=br>45:37</td>
<td class=bc>8 - 2 - 3</td>
<td class=br>26</td>
<td class=d>4.</td>
</tr><tr><td class=ir>5</td><td class=kt>Z.Matoušek st.</td><td class=k>4:3</td>
<td class=k>2:2</td>
<td class=k>0:5</td>
<td class=k>2:2</td>
<td class=kx>*</td>
<td class=k>2:0</td>
<td class=k>4:4</td>
<td class=k>3:3</td>
<td class=k>5:2</td>
<td class=k>2:2</td>
<td class=k>2:6</td>
<td class=k>7:1</td>
<td class=k>9:0</td>
<td class=k>5:1</td>
<td class=br>47:31</td>
<td class=bc>6 - 5 - 2</td>
<td class=br>23</td>
<td class=d>5.</td>
</tr><tr><td class=ir>6</td><td class=kt>V.Pikl</td><td class=k>2:4</td>
<td class=k>1:2</td>
<td class=k>2:7</td>
<td class=k>4:0</td>
<td class=k>0:2</td>
<td class=kx>*</td>
<td class=k>5:4</td>
<td class=k>1:2</td>
<td class=k>2:1</td>
<td class=k>5:3</td>
<td class=k>6:2</td>
<td class=k>4:5</td>
<td class=k>3:1</td>
<td class=k>6:0</td>
<td class=br>41:33</td>
<td class=bc>7 - 0 - 6</td>
<td class=br>21</td>
<td class=d>6.</td>
</tr><tr><td class=ir>7</td><td class=kt>I.Halama</td><td class=k>1:8</td>
<td class=k>0:4</td>
<td class=k>5:4</td>
<td class=k>2:5</td>
<td class=k>4:4</td>
<td class=k>4:5</td>
<td class=kx>*</td>
<td class=k>3:1</td>
<td class=k>4:9</td>
<td class=k>1:1</td>
<td class=k>5:3</td>
<td class=k>6:2</td>
<td class=k>6:4</td>
<td class=k>7:4</td>
<td class=br>48:54</td>
<td class=bc>6 - 2 - 5</td>
<td class=br>20</td>
<td class=d>7.</td>
</tr><tr><td class=ir>8</td><td class=kt>M.Ševr</td><td class=k>1:4</td>
<td class=k>2:2</td>
<td class=k>0:2</td>
<td class=k>1:4</td>
<td class=k>3:3</td>
<td class=k>2:1</td>
<td class=k>1:3</td>
<td class=kx>*</td>
<td class=k>1:5</td>
<td class=k>4:3</td>
<td class=k>6:2</td>
<td class=k>3:2</td>
<td class=k>5:1</td>
<td class=k>8:1</td>
<td class=br>37:33</td>
<td class=bc>6 - 2 - 5</td>
<td class=br>20</td>
<td class=d>8.</td>
</tr><tr><td class=ir>9</td><td class=kt>J.Kůrka</td><td class=k>0:5</td>
<td class=k>2:6</td>
<td class=k>1:2</td>
<td class=k>2:5</td>
<td class=k>2:5</td>
<td class=k>1:2</td>
<td class=k>9:4</td>
<td class=k>5:1</td>
<td class=kx>*</td>
<td class=k>5:7</td>
<td class=k>7:4</td>
<td class=k>6:0</td>
<td class=k>6:3</td>
<td class=k>8:1</td>
<td class=br>54:45</td>
<td class=bc>6 - 0 - 7</td>
<td class=br>18</td>
<td class=d>9.</td>
</tr><tr><td class=ir>10</td><td class=kt>L.Černý</td><td class=k>2:5</td>
<td class=k>1:3</td>
<td class=k>1:2</td>
<td class=k>2:2</td>
<td class=k>2:2</td>
<td class=k>3:5</td>
<td class=k>1:1</td>
<td class=k>3:4</td>
<td class=k>7:5</td>
<td class=kx>*</td>
<td class=k>2:4</td>
<td class=k>3:2</td>
<td class=k>11:1</td>
<td class=k>7:1</td>
<td class=br>45:37</td>
<td class=bc>4 - 3 - 6</td>
<td class=br>15</td>
<td class=d>10.</td>
</tr><tr><td class=ir>11</td><td class=kt>L.Příhoda</td><td class=k>1:7</td>
<td class=k>0:5</td>
<td class=k>0:4</td>
<td class=k>4:5</td>
<td class=k>6:2</td>
<td class=k>2:6</td>
<td class=k>3:5</td>
<td class=k>2:6</td>
<td class=k>4:7</td>
<td class=k>4:2</td>
<td class=kx>*</td>
<td class=k>6:5</td>
<td class=k>4:4</td>
<td class=k>6:1</td>
<td class=br>42:59</td>
<td class=bc>4 - 1 - 8</td>
<td class=br>13</td>
<td class=d>11.</td>
</tr><tr><td class=ir>12</td><td class=kt>J.Kraus</td><td class=k>1:2</td>
<td class=k>3:5</td>
<td class=k>5:6</td>
<td class=k>3:4</td>
<td class=k>1:7</td>
<td class=k>5:4</td>
<td class=k>2:6</td>
<td class=k>2:3</td>
<td class=k>0:6</td>
<td class=k>2:3</td>
<td class=k>5:6</td>
<td class=kx>*</td>
<td class=k>4:2</td>
<td class=k>8:2</td>
<td class=br>41:56</td>
<td class=bc>3 - 0 - 10</td>
<td class=br>9</td>
<td class=d>12.</td>
</tr><tr><td class=ir>13</td><td class=kt>J.Petr</td><td class=k>1:8</td>
<td class=k>1:8</td>
<td class=k>3:5</td>
<td class=k>1:4</td>
<td class=k>0:9</td>
<td class=k>1:3</td>
<td class=k>4:6</td>
<td class=k>1:5</td>
<td class=k>3:6</td>
<td class=k>1:11</td>
<td class=k>4:4</td>
<td class=k>2:4</td>
<td class=kx>*</td>
<td class=k>4:0</td>
<td class=br>26:73</td>
<td class=bc>1 - 1 - 11</td>
<td class=br>4</td>
<td class=d>13.</td>
</tr><tr><td class=ir>14</td><td class=kt>F.Marek</td><td class=k>1:9</td>
<td class=k>0:8</td>
<td class=k>2:6</td>
<td class=k>2:3</td>
<td class=k>1:5</td>
<td class=k>0:6</td>
<td class=k>4:7</td>
<td class=k>1:8</td>
<td class=k>1:8</td>
<td class=k>1:7</td>
<td class=k>1:6</td>
<td class=k>2:8</td>
<td class=k>0:4</td>
<td class=kx>*</td>
<td class=br>16:85</td>
<td class=bc>0 - 0 - 13</td>
<td class=br>0</td>
<td class=d>14.</td>
</tr></table></td></tr></table></div></p>

<p class=v>MR, Praha - zápasy o umístění (play-off matches)<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
</tr>
<tr><td class=bl>Finále</td>
<td class=br>Plešák Pavel</td>
<td class=bl><b>- Turoň Petr</b></td>
<td class=bl>6:7&nbsp;&nbsp;</td>
<td class=bl>2:4&nbsp;&nbsp;</td>
<td class=bl>3:4 P&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=al>Semifinále</td>
<td class=ar><b>Plešák Pavel</b></td>
<td class=al>- Matoušek st. Zdeněk</td>
<td class=al>4:3&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=bl>Semifinále</td>
<td class=br><b>Turoň Petr</b></td>
<td class=bl>- Pikl Václav</td>
<td class=bl>3:2 P&nbsp;&nbsp;</td>
<td class=bl>2:5&nbsp;&nbsp;</td>
<td class=bl>4:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=al>O 3.místo</td>
<td class=ar><b>Pikl Václav</b></td>
<td class=al>- Matoušek st. Zdeněk</td>
<td class=al>5:4&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=bl>Čtvrtfinále</td>
<td class=br><b>Plešák Pavel</b></td>
<td class=bl>- Ševr Miloš</td>
<td class=bl>1:2&nbsp;&nbsp;</td>
<td class=bl>4:3&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=al>Čtvrtfinále</td>
<td class=ar><b>Turoň Petr</b></td>
<td class=al>- Halama Ivan</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>9:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=bl>Čtvrtfinále</td>
<td class=br>Pilař Zbyněk</td>
<td class=bl><b>- Pikl Václav</b></td>
<td class=bl>1:4&nbsp;&nbsp;</td>
<td class=bl>1:4&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=al>Čtvrtfinále</td>
<td class=ar>Šrajer Antonín</td>
<td class=al><b>- Matoušek st. Zdeněk</b></td>
<td class=al>2:3 P&nbsp;&nbsp;</td>
<td class=al>4:2&nbsp;&nbsp;</td>
<td class=al>0:4&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr></table></td></tr></table></div></p>
<p>&nbsp;</p>

<p class=v>Konečné pořadí turnaje<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>Z</th>
<th>+</th>
<th>=</th>
<th>-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>B</th>
<th>&nbsp;</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al>Turoň Petr</td>
<td class=al>THC Třinec</td>
<td class=ar>21</td>
<td class=ar>17</td>
<td class=ar>2</td>
<td class=ar>2</td>
<td class=ar>90</td>
<td class=al>: 45</td>
<td class=ar>53</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>2.</td>
<td class=bl>Plešák Pavel</td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>21</td>
<td class=br>15</td>
<td class=br>0</td>
<td class=br>6</td>
<td class=br>92</td>
<td class=bl>: 46</td>
<td class=br>45</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>3.</td>
<td class=al>Pikl Václav</td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>20</td>
<td class=ar>12</td>
<td class=ar>0</td>
<td class=ar>8</td>
<td class=ar>66</td>
<td class=al>: 50</td>
<td class=ar>36</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>4.</td>
<td class=bl>Matoušek st. Zdeněk</td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>20</td>
<td class=br>8</td>
<td class=br>5</td>
<td class=br>7</td>
<td class=br>67</td>
<td class=bl>: 52</td>
<td class=br>29</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>5.</td>
<td class=al>Pilař Zbyněk</td>
<td class=al>Absolut Spiders</td>
<td class=ar>15</td>
<td class=ar>10</td>
<td class=ar>0</td>
<td class=ar>5</td>
<td class=ar>52</td>
<td class=al>: 36</td>
<td class=ar>30</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>6.</td>
<td class=bl>Šrajer Antonín</td>
<td class=bl>THC Stiga Elites</td>
<td class=br>16</td>
<td class=br>9</td>
<td class=br>2</td>
<td class=br>5</td>
<td class=br>51</td>
<td class=bl>: 46</td>
<td class=br>29</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>7.</td>
<td class=al>Halama Ivan</td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>15</td>
<td class=ar>6</td>
<td class=ar>2</td>
<td class=ar>7</td>
<td class=ar>51</td>
<td class=al>: 66</td>
<td class=ar>20</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>8.</td>
<td class=bl>Ševr Miloš</td>
<td class=bl>THC Stiga Elites</td>
<td class=br>16</td>
<td class=br>7</td>
<td class=br>2</td>
<td class=br>7</td>
<td class=br>44</td>
<td class=bl>: 41</td>
<td class=br>23</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>9.</td>
<td class=al>Kůrka Josef</td>
<td class=al>THC Stiga-Game Příbram</td>
<td class=ar>13</td>
<td class=ar>6</td>
<td class=ar>0</td>
<td class=ar>7</td>
<td class=ar>54</td>
<td class=al>: 45</td>
<td class=ar>18</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>10.</td>
<td class=bl>Černý Luboš</td>
<td class=bl>SHC Cheb</td>
<td class=br>13</td>
<td class=br>4</td>
<td class=br>3</td>
<td class=br>6</td>
<td class=br>45</td>
<td class=bl>: 37</td>
<td class=br>15</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>11.</td>
<td class=al>Příhoda Luděk</td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>13</td>
<td class=ar>4</td>
<td class=ar>1</td>
<td class=ar>8</td>
<td class=ar>42</td>
<td class=al>: 59</td>
<td class=ar>13</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>12.</td>
<td class=bl>Kraus Josef</td>
<td class=bl>ETHL Milovice</td>
<td class=br>13</td>
<td class=br>3</td>
<td class=br>0</td>
<td class=br>10</td>
<td class=br>41</td>
<td class=bl>: 56</td>
<td class=br>9</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>13.</td>
<td class=al>Petr Jindřich</td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>13</td>
<td class=ar>1</td>
<td class=ar>1</td>
<td class=ar>11</td>
<td class=ar>26</td>
<td class=al>: 73</td>
<td class=ar>4</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>14.</td>
<td class=bl>Marek František</td>
<td class=bl>BSE České Budějovice</td>
<td class=br>13</td>
<td class=br>0</td>
<td class=br>0</td>
<td class=br>13</td>
<td class=br>16</td>
<td class=bl>: 85</td>
<td class=br>0</td>
<td class=br>&nbsp;</td>
</tr></table></td></tr></table></div></p>
</body>
</html>