<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN">
<html lang="cz">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<title>MR, Praha</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
</head>
<body class="neop">
<a name="Zac"><p class=l>MR, Praha, 30. May 2015</p></a>
<div align=center><p><a href="index.aspx">Back</a></p></div>
<p class=vm>Basic groups</p>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=2 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=ir>1</td><td class=kt>Zd Matoušek ml.</td><td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>8:4</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kW>8:4</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>9:0</td>
<td class=kW>8:2</td>
<td class=kW>5:0</td>
<td class=br>101:27</td><td class=br>+74</td>
<td class=bc>22 - 1 - 0</td>
<td class=br>45</td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=ir>2</td><td class=kt>Mi Hvižď</td><td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>8:3</td>
<td class=kW>6:1</td>
<td class=kW>9:0</td>
<td class=kW>7:0</td>
<td class=kW>9:1</td>
<td class=kW>7:2</td>
<td class=kW>9:0</td>
<td class=br>119:35</td><td class=br>+84</td>
<td class=bc>21 - 1 - 1</td>
<td class=br>43</td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=ir>3</td><td class=kt>Ja Dryák</td><td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>7:4</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kT>5:5</td>
<td class=kL>5:6</td>
<td class=kW>5:1</td>
<td class=kW>10:0</td>
<td class=kW>8:0</td>
<td class=kW>5:3</td>
<td class=kW>8:2</td>
<td class=kW>6:2</td>
<td class=kW>9:0</td>
<td class=kW>9:0</td>
<td class=kW>8:3</td>
<td class=br>122:47</td><td class=br>+75</td>
<td class=bc>17 - 2 - 4</td>
<td class=br>36</td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=ir>4</td><td class=kt>Ma Maděra</td><td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>7:4</td>
<td class=kL>2:5</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>7:3</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=br>91:47</td><td class=br>+44</td>
<td class=bc>16 - 3 - 4</td>
<td class=br>35</td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=ir>5</td><td class=kt>Kr Lebl</td><td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>10:1</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=br>81:41</td><td class=br>+40</td>
<td class=bc>15 - 4 - 4</td>
<td class=br>34</td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=ir>6</td><td class=kt>St Kraus</td><td class=kL>3:5</td>
<td class=kL>3:6</td>
<td class=kL>4:7</td>
<td class=kL>4:7</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kL>4:6</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kT>5:5</td>
<td class=kW>5:2</td>
<td class=kW>7:2</td>
<td class=kW>8:3</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>6:2</td>
<td class=br>103:64</td><td class=br>+39</td>
<td class=bc>16 - 1 - 6</td>
<td class=br>33</td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=ir>7</td><td class=kt>An Šurýn</td><td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>0:6</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kW>9:1</td>
<td class=kW>8:1</td>
<td class=kW>13:0</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=br>81:50</td><td class=br>+31</td>
<td class=bc>15 - 1 - 7</td>
<td class=br>31</td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=ir>8</td><td class=kt>Kr Herold</td><td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>6:0</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kW>5:4</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>5:3</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=br>70:55</td><td class=br>+15</td>
<td class=bc>13 - 3 - 7</td>
<td class=br>29</td><td class=d>8.</td>
</tr><tr><td class=ir>J</td><td class=ir>9</td><td class=kt>Ad Zielinský</td><td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>7:3</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>6:2</td>
<td class=kW>8:3</td>
<td class=br>79:52</td><td class=br>+27</td>
<td class=bc>14 - 1 - 8</td>
<td class=br>29</td><td class=d>9.</td>
</tr><tr><td class=ir>J</td><td class=ir>10</td><td class=kt>Ho Sládek</td><td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kW>6:4</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>9:1</td>
<td class=kW>10:0</td>
<td class=kW>7:0</td>
<td class=kW>7:2</td>
<td class=br>87:47</td><td class=br>+40</td>
<td class=bc>12 - 5 - 6</td>
<td class=br>29</td><td class=d>10.</td>
</tr><tr><td class=ir>J</td><td class=ir>11</td><td class=kt>Vl Kraus</td><td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kL>0:3</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kW>6:3</td>
<td class=kW>11:0</td>
<td class=kW>3:0</td>
<td class=kW>8:3</td>
<td class=kW>9:2</td>
<td class=kW>4:0</td>
<td class=br>81:53</td><td class=br>+28</td>
<td class=bc>13 - 0 - 10</td>
<td class=br>26</td><td class=d>11.</td>
</tr><tr><td class=ir>J</td><td class=ir>12</td><td class=kt>Ma Ženíšek</td><td class=kL>2:4</td>
<td class=kL>2:7</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>0:6</td>
<td class=kL>3:4</td>
<td class=kW>6:1</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=br>67:63</td><td class=br>+4</td>
<td class=bc>10 - 3 - 10</td>
<td class=br>23</td><td class=d>12.</td>
</tr><tr><td class=ir>J</td><td class=ir>13</td><td class=kt>Mi Kobrle</td><td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>8:1</td>
<td class=kW>6:5</td>
<td class=kT>2:2</td>
<td class=kL>4:6</td>
<td class=kW>9:1</td>
<td class=kW>5:0</td>
<td class=br>76:68</td><td class=br>+8</td>
<td class=bc>8 - 4 - 11</td>
<td class=br>20</td><td class=d>13.</td>
</tr><tr><td class=ir>J</td><td class=ir>14</td><td class=kt>Ma Kouba</td><td class=kL>4:8</td>
<td class=kL>3:4</td>
<td class=kT>5:5</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kT>4:4</td>
<td class=kW>5:4</td>
<td class=kW>2:0</td>
<td class=kW>7:1</td>
<td class=kW>9:1</td>
<td class=kW>1:0</td>
<td class=br>69:74</td><td class=br>-5</td>
<td class=bc>9 - 2 - 12</td>
<td class=br>20</td><td class=d>14.</td>
</tr><tr><td class=ir>J</td><td class=ir>15</td><td class=kt>Zd Matoušek st.</td><td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kW>6:5</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kW>5:3</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kW>5:0</td>
<td class=br>66:76</td><td class=br>-10</td>
<td class=bc>9 - 1 - 13</td>
<td class=br>19</td><td class=d>15.</td>
</tr><tr><td class=ir>J</td><td class=ir>16</td><td class=kt>Ji Vácha</td><td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kT>5:5</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>3:7</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>11:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>7:1</td>
<td class=kW>6:1</td>
<td class=br>76:75</td><td class=br>+1</td>
<td class=bc>8 - 3 - 12</td>
<td class=br>19</td><td class=d>16.</td>
</tr><tr><td class=ir>J</td><td class=ir>17</td><td class=kt>Hy Nechutný</td><td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:10</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>10:2</td>
<td class=kW>4:0</td>
<td class=br>49:70</td><td class=br>-21</td>
<td class=bc>8 - 1 - 14</td>
<td class=br>17</td><td class=d>17.</td>
</tr><tr><td class=ir>J</td><td class=ir>18</td><td class=kt>Da Dvořáček</td><td class=kL>4:8</td>
<td class=kL>3:8</td>
<td class=kL>0:8</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kL>0:1</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=br>68:83</td><td class=br>-15</td>
<td class=bc>8 - 1 - 14</td>
<td class=br>17</td><td class=d>18.</td>
</tr><tr><td class=ir>J</td><td class=ir>19</td><td class=kt>Iv Mašková</td><td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>3:8</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kT>4:4</td>
<td class=kL>0:5</td>
<td class=kL>3:6</td>
<td class=kL>3:4</td>
<td class=kL>1:8</td>
<td class=kT>4:4</td>
<td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=br>55:100</td><td class=br>-45</td>
<td class=bc>4 - 4 - 15</td>
<td class=br>12</td><td class=d>19.</td>
</tr><tr><td class=ir>J</td><td class=ir>20</td><td class=kt>Ji Junek</td><td class=kL>1:5</td>
<td class=kL>0:9</td>
<td class=kL>2:8</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>1:9</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>0:11</td>
<td class=kL>0:5</td>
<td class=kL>5:6</td>
<td class=kL>4:5</td>
<td class=kW>5:4</td>
<td class=kL>1:11</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=br>46:110</td><td class=br>-64</td>
<td class=bc>4 - 4 - 15</td>
<td class=br>12</td><td class=d>20.</td>
</tr><tr><td class=ir>J</td><td class=ir>21</td><td class=kt>To Kahoun ml.</td><td class=kL>0:2</td>
<td class=kL>0:7</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>1:8</td>
<td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kL>1:9</td>
<td class=kL>0:3</td>
<td class=kL>0:7</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=br>34:91</td><td class=br>-57</td>
<td class=bc>2 - 6 - 15</td>
<td class=br>10</td><td class=d>21.</td>
</tr><tr><td class=ir>J</td><td class=ir>22</td><td class=kt>Lu Kahoun</td><td class=kL>0:9</td>
<td class=kL>1:9</td>
<td class=kL>0:9</td>
<td class=kL>3:7</td>
<td class=kL>1:10</td>
<td class=kL>2:3</td>
<td class=kL>0:13</td>
<td class=kL>3:5</td>
<td class=kL>1:7</td>
<td class=kL>0:10</td>
<td class=kL>3:8</td>
<td class=kL>1:4</td>
<td class=kW>6:4</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=br>40:133</td><td class=br>-93</td>
<td class=bc>3 - 1 - 19</td>
<td class=br>7</td><td class=d>22.</td>
</tr><tr><td class=ir>J</td><td class=ir>23</td><td class=kt>Ba Petrová</td><td class=kL>2:8</td>
<td class=kL>2:7</td>
<td class=kL>0:9</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kL>0:7</td>
<td class=kL>2:9</td>
<td class=kL>1:5</td>
<td class=kL>1:9</td>
<td class=kL>1:9</td>
<td class=kL>3:6</td>
<td class=kL>1:7</td>
<td class=kL>2:10</td>
<td class=kL>2:7</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=br>39:145</td><td class=br>-106</td>
<td class=bc>0 - 4 - 19</td>
<td class=br>4</td><td class=d>23.</td>
</tr><tr><td class=ir>J</td><td class=ir>24</td><td class=kt>Pa Komárek</td><td class=kL>0:5</td>
<td class=kL>0:9</td>
<td class=kL>3:8</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kL>3:8</td>
<td class=kL>2:7</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>0:1</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=br>25:119</td><td class=br>-94</td>
<td class=bc>0 - 2 - 21</td>
<td class=br>2</td><td class=d>24.</td>
</tr></table></td></tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Pa Komárek</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Ba Petrová</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Ji Junek</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ma Kouba</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Pa Komárek</td><td class=bc>-</td><td class=bl>Ba Petrová</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ji Junek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ma Kouba</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ba Petrová</td><td class=bc>-</td><td class=blW>Ji Junek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pa Komárek</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Ma Kouba</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ji Junek</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ba Petrová</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pa Komárek</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>8 : 4</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Ma Kouba</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ji Junek</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ba Petrová</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Pa Komárek</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ma Kouba</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Ja Dryák</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ji Junek</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ba Petrová</td><td class=bc>-</td><td class=blW>Ma Kouba</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Pa Komárek</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Ma Kouba</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ji Junek</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ba Petrová</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Pa Komárek</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=bl>Ma Kouba</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>0 : 13</tr></td>
<tr><td class=br>Ji Junek</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>1 : 11</tr></td>
<tr><td class=br>Ba Petrová</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Pa Komárek</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>4 : 7</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ma Kouba</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Ji Junek</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ba Petrová</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Pa Komárek</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ma Kouba</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Ji Junek</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ba Petrová</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Pa Komárek</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Kouba</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ji Junek</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ba Petrová</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Pa Komárek</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ja Dryák</td><td class=bc>-</td><td class=bl>Mi Hvižď</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Kouba</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ji Junek</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ba Petrová</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Pa Komárek</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Kouba</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Ji Junek</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Ba Petrová</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Pa Komárek</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Kouba</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Ji Junek</td><td class=bc>-</td><td class=bl>Pa Komárek</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ba Petrová</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Kouba</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Pa Komárek</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=bl>Ba Petrová</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ji Junek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ma Kouba</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Pa Komárek</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=bl>Ba Petrová</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ji Junek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ma Kouba</td><td class=bc>-</td><td class=bl>Pa Komárek</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ba Petrová</td><td class=bc>10 : 2</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=bl>Ji Junek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Pa Komárek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Ba Petrová</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ma Kouba</td><td class=bc>-</td><td class=bl>Ji Junek</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Pa Komárek</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Ba Petrová</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ji Junek</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Kouba</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Pa Komárek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ba Petrová</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ji Junek</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ma Kouba</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Pa Komárek</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ba Petrová</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ji Junek</td><td class=bc>11 : 0</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Kouba</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Pa Komárek</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ba Petrová</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Ji Junek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ma Kouba</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Pa Komárek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Ba Petrová</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ji Junek</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Kouba</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Pa Komárek</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Ba Petrová</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Ji Junek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ma Kouba</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=2 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=ir>1</td><td class=kt>Pa Petr</td><td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kW>6:3</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>11:3</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>12:0</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=br>122:32</td><td class=br>+90</td>
<td class=bc>22 - 0 - 1</td>
<td class=br>44</td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=ir>2</td><td class=kt>Fi Hamáček</td><td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kL>1:2</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>8:2</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=kW>7:0</td>
<td class=br>101:29</td><td class=br>+72</td>
<td class=bc>19 - 3 - 1</td>
<td class=br>41</td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=ir>3</td><td class=kt>Le Hvižď ml.</td><td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>7:2</td>
<td class=kW>7:0</td>
<td class=br>99:32</td><td class=br>+67</td>
<td class=bc>17 - 3 - 3</td>
<td class=br>37</td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=ir>4</td><td class=kt>Da Matýsek</td><td class=kL>3:6</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=br>59:33</td><td class=br>+26</td>
<td class=bc>16 - 3 - 4</td>
<td class=br>35</td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=ir>5</td><td class=kt>Da Šmíd</td><td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>0:1</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>8:1</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=br>87:37</td><td class=br>+50</td>
<td class=bc>16 - 2 - 5</td>
<td class=br>34</td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=ir>6</td><td class=kt>Ti Varga</td><td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kT>5:5</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:4</td>
<td class=kW>5:3</td>
<td class=kW>5:4</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=br>73:43</td><td class=br>+30</td>
<td class=bc>15 - 4 - 4</td>
<td class=br>34</td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=ir>7</td><td class=kt>ml Chylík</td><td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>7:3</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=br>78:44</td><td class=br>+34</td>
<td class=bc>16 - 1 - 6</td>
<td class=br>33</td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=ir>8</td><td class=kt>Mi Černoch</td><td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kL>1:6</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kW>9:0</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=br>71:44</td><td class=br>+27</td>
<td class=bc>13 - 4 - 6</td>
<td class=br>30</td><td class=d>8.</td>
</tr><tr><td class=ir>J</td><td class=ir>9</td><td class=kt>Vá Pikl</td><td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kL>2:6</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kW>7:0</td>
<td class=kW>6:1</td>
<td class=br>66:48</td><td class=br>+18</td>
<td class=bc>14 - 2 - 7</td>
<td class=br>30</td><td class=d>9.</td>
</tr><tr><td class=ir>J</td><td class=ir>10</td><td class=kt>Mi Boštík</td><td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kW>5:1</td>
<td class=kT>5:5</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=br>72:59</td><td class=br>+13</td>
<td class=bc>13 - 2 - 8</td>
<td class=br>28</td><td class=d>10.</td>
</tr><tr><td class=ir>J</td><td class=ir>11</td><td class=kt>Lu Paclík</td><td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=br>58:53</td><td class=br>+5</td>
<td class=bc>12 - 3 - 8</td>
<td class=br>27</td><td class=d>11.</td>
</tr><tr><td class=ir>J</td><td class=ir>12</td><td class=kt>Al Fiala</td><td class=kL>3:6</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>9:0</td>
<td class=br>70:47</td><td class=br>+23</td>
<td class=bc>10 - 5 - 8</td>
<td class=br>25</td><td class=d>12.</td>
</tr><tr><td class=ir>J</td><td class=ir>13</td><td class=kt>Ro Jež</td><td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>4:6</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=br>62:60</td><td class=br>+2</td>
<td class=bc>11 - 1 - 11</td>
<td class=br>23</td><td class=d>13.</td>
</tr><tr><td class=ir>J</td><td class=ir>14</td><td class=kt>Mi Ševr</td><td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kT>5:5</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>5:4</td>
<td class=kW>8:0</td>
<td class=kW>5:2</td>
<td class=br>60:61</td><td class=br>-1</td>
<td class=bc>8 - 4 - 11</td>
<td class=br>20</td><td class=d>14.</td>
</tr><tr><td class=ir>J</td><td class=ir>15</td><td class=kt>An Jackowská</td><td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kW>5:3</td>
<td class=kL>0:4</td>
<td class=kT>5:5</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kW>6:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=br>61:75</td><td class=br>-14</td>
<td class=bc>8 - 3 - 12</td>
<td class=br>19</td><td class=d>15.</td>
</tr><tr><td class=ir>J</td><td class=ir>16</td><td class=kt>Ja Matýsek</td><td class=kL>1:5</td>
<td class=kL>2:8</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>3:7</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>2:5</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=br>47:78</td><td class=br>-31</td>
<td class=bc>8 - 2 - 13</td>
<td class=br>18</td><td class=d>16.</td>
</tr><tr><td class=ir>J</td><td class=ir>17</td><td class=kt>Fr Marek</td><td class=kL>2:7</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>7:4</td>
<td class=kW>3:0</td>
<td class=br>55:78</td><td class=br>-23</td>
<td class=bc>7 - 2 - 14</td>
<td class=br>16</td><td class=d>17.</td>
</tr><tr><td class=ir>J</td><td class=ir>18</td><td class=kt>Sa Hána</td><td class=kL>3:11</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>4:5</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=br>54:85</td><td class=br>-31</td>
<td class=bc>5 - 3 - 15</td>
<td class=br>13</td><td class=d>18.</td>
</tr><tr><td class=ir>J</td><td class=ir>19</td><td class=kt>To Kahoun st.</td><td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kL>1:8</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kL>0:9</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=br>35:83</td><td class=br>-48</td>
<td class=bc>5 - 1 - 17</td>
<td class=br>11</td><td class=d>19.</td>
</tr><tr><td class=ir>J</td><td class=ir>20</td><td class=kt>To Jedlička</td><td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=br>46:82</td><td class=br>-36</td>
<td class=bc>3 - 4 - 16</td>
<td class=br>10</td><td class=d>20.</td>
</tr><tr><td class=ir>J</td><td class=ir>21</td><td class=kt>Ji Petr</td><td class=kL>0:12</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=br>41:94</td><td class=br>-53</td>
<td class=bc>4 - 0 - 19</td>
<td class=br>8</td><td class=d>21.</td>
</tr><tr><td class=ir>J</td><td class=ir>22</td><td class=kt>Pa Pohořalý</td><td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>2:6</td>
<td class=kL>2:7</td>
<td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>4:5</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=br>41:94</td><td class=br>-53</td>
<td class=bc>3 - 2 - 18</td>
<td class=br>8</td><td class=d>22.</td>
</tr><tr><td class=ir>J</td><td class=ir>23</td><td class=kt>Mi Mareš st.</td><td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>2:7</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kW>4:3</td>
<td class=kL>0:8</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>4:7</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=br>29:112</td><td class=br>-83</td>
<td class=bc>1 - 3 - 19</td>
<td class=br>5</td><td class=d>23.</td>
</tr><tr><td class=ir>J</td><td class=ir>24</td><td class=kt>Ha Marešová</td><td class=kL>1:3</td>
<td class=kL>0:7</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>0:9</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=br>16:100</td><td class=br>-84</td>
<td class=bc>1 - 1 - 21</td>
<td class=br>3</td><td class=d>24.</td>
</tr></table></td></tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ji Petr</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ti Varga</td><td class=bc>-</td><td class=bl>An Jackowská</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>Al Fiala</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Lu Paclík</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ji Petr</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>An Jackowská</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Al Fiala</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ti Varga</td><td class=bc>-</td><td class=bl>Lu Paclík</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>Ji Petr</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>11 : 3</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>An Jackowská</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Al Fiala</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Lu Paclík</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ti Varga</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ji Petr</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=blW>Sa Hána</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>An Jackowská</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Al Fiala</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Lu Paclík</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Ti Varga</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ji Petr</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>Pa Pohořalý</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>An Jackowská</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Al Fiala</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Lu Paclík</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ji Petr</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>An Jackowská</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Al Fiala</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Lu Paclík</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ji Petr</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>An Jackowská</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=blW>Al Fiala</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>Lu Paclík</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=blW>An Jackowská</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ji Petr</td><td class=bc>-</td><td class=blW>Al Fiala</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Lu Paclík</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Mi Mareš st.</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Fi Hamáček</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=bl>An Jackowská</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Al Fiala</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=blW>Lu Paclík</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ji Petr</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=blW>Ti Varga</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>An Jackowská</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Al Fiala</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=bl>Lu Paclík</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ji Petr</td><td class=bc>-</td><td class=blW>Ti Varga</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>An Jackowská</td><td class=bc>-</td><td class=blW>Al Fiala</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Lu Paclík</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Ti Varga</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ji Petr</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Fi Hamáček</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Al Fiala</td><td class=bc>-</td><td class=blW>Lu Paclík</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Jackowská</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Ti Varga</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ji Petr</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Lu Paclík</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Al Fiala</td><td class=bc>-</td><td class=blW>Ti Varga</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Jackowská</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ji Petr</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Ti Varga</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Lu Paclík</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Fiala</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>An Jackowská</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ji Petr</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 12</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Lu Paclík</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Al Fiala</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>An Jackowská</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ji Petr</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Ti Varga</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Lu Paclík</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Fiala</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Jackowská</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Ha Marešová</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ji Petr</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ti Varga</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Lu Paclík</td><td class=bc>-</td><td class=bl>Fi Hamáček</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Fiala</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>An Jackowská</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Ji Petr</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ti Varga</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Lu Paclík</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Al Fiala</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>An Jackowská</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Ji Petr</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Sa Hána</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ti Varga</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Lu Paclík</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Al Fiala</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>An Jackowská</td><td class=bc>-</td><td class=bl>Ji Petr</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=bl>Fi Hamáček</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ti Varga</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Lu Paclík</td><td class=bc>-</td><td class=bl>Ji Petr</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Al Fiala</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>An Jackowská</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ti Varga</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Ji Petr</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Lu Paclík</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Al Fiala</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>An Jackowská</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ji Petr</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ti Varga</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Lu Paclík</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Al Fiala</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>An Jackowská</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Ji Petr</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ti Varga</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Lu Paclík</td><td class=bc>-</td><td class=bl>An Jackowská</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Al Fiala</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ji Petr</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ti Varga</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>An Jackowská</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Al Fiala</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Lu Paclík</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div>

</p>


<hr>




<p class=v>Group A</br><div align=center>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=2 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/8</td><td class=ir>1</td><td class=kt>Fi Hamáček</td><td class=kx>*</td>
<td class=kW>3:1 K</td>
<td class=kT>3:3</td>
<td class=kT>3:3 K</td>
<td class=kL>1:2</td>
<td class=kT>2:2 K</td>
<td class=kL>2:5</td>
<td class=kW>2:0 K</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>5:2 K</td>
<td class=kW>2:1</td>
<td class=kW>5:0 K</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>5:2 K</td>
<td class=br>46:24</td><td class=br>+22</td>
<td class=bc>10 - 3 - 2</td>
<td class=br>23</td><td class=d>1.</td>
</tr><tr><td class=ir>1/8</td><td class=ir>2</td><td class=kt>Pa Petr</td><td class=kL>1:3 K</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>5:3 K</td>
<td class=kL>2:4</td>
<td class=kW>6:2 K</td>
<td class=kW>4:0</td>
<td class=kW>6:3 K</td>
<td class=kW>2:1</td>
<td class=kL>2:6</td>
<td class=kW>4:0 K</td>
<td class=kT>2:2</td>
<td class=kW>4:0 K</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>4:2 K</td>
<td class=br>51:29</td><td class=br>+22</td>
<td class=bc>11 - 1 - 3</td>
<td class=br>23</td><td class=d>2.</td>
</tr><tr><td class=ir>1/8</td><td class=ir>3</td><td class=kt>Zd Matoušek ml.</td><td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>3:1 K</td>
<td class=kL>2:4</td>
<td class=kW>4:1 K</td>
<td class=kW>3:0</td>
<td class=kW>3:2 K</td>
<td class=kW>5:3 K</td>
<td class=kW>3:0</td>
<td class=kW>1:0 K</td>
<td class=kW>4:1</td>
<td class=kT>1:1 K</td>
<td class=kW>2:1 K</td>
<td class=kW>4:2</td>
<td class=br>41:26</td><td class=br>+15</td>
<td class=bc>10 - 2 - 3</td>
<td class=br>22</td><td class=d>3.</td>
</tr><tr><td class=ir>1/8</td><td class=ir>4</td><td class=kt>Le Hvižď ml.</td><td class=kT>3:3 K</td>
<td class=kL>3:5 K</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>0:2 K</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>1:0 K</td>
<td class=kW>4:2</td>
<td class=kW>3:2 K</td>
<td class=kW>2:0</td>
<td class=kW>5:3</td>
<td class=kW>5:0 K</td>
<td class=br>37:24</td><td class=br>+13</td>
<td class=bc>8 - 5 - 2</td>
<td class=br>21</td><td class=d>4.</td>
</tr><tr><td class=ir>1/8</td><td class=ir>5</td><td class=kt>Mi Hvižď</td><td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kL>1:3 K</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kT>3:3 K</td>
<td class=kL>2:3</td>
<td class=kW>4:2 K</td>
<td class=kW>6:3 K</td>
<td class=kL>2:4</td>
<td class=kW>5:1 K</td>
<td class=kW>6:2</td>
<td class=kW>4:0 K</td>
<td class=kW>3:2 K</td>
<td class=kL>2:4</td>
<td class=br>45:34</td><td class=br>+11</td>
<td class=bc>8 - 2 - 5</td>
<td class=br>18</td><td class=d>5.</td>
</tr><tr><td class=ir>1/8</td><td class=ir>6</td><td class=kt>ml Chylík</td><td class=kT>2:2 K</td>
<td class=kL>2:6 K</td>
<td class=kW>4:2</td>
<td class=kW>2:0 K</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>0:1 K</td>
<td class=kL>1:4</td>
<td class=kW>6:0</td>
<td class=kL>1:5 K</td>
<td class=kW>2:1</td>
<td class=kL>0:4 K</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>3:2 K</td>
<td class=br>32:32</td><td class=br>0</td>
<td class=bc>7 - 3 - 5</td>
<td class=br>17</td><td class=d>6.</td>
</tr><tr><td class=ir>1/8</td><td class=ir>7</td><td class=kt>Ja Dryák</td><td class=kW>5:2</td>
<td class=kL>0:4</td>
<td class=kL>1:4 K</td>
<td class=kT>2:2</td>
<td class=kT>3:3 K</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1 K</td>
<td class=kW>7:4 K</td>
<td class=kL>2:4</td>
<td class=kL>2:3 K</td>
<td class=kT>2:2</td>
<td class=kW>5:1 K</td>
<td class=kW>5:0 K</td>
<td class=kW>7:3</td>
<td class=br>47:38</td><td class=br>+9</td>
<td class=bc>6 - 4 - 5</td>
<td class=br>16</td><td class=d>7.</td>
</tr><tr><td class=ir>1/8</td><td class=ir>8</td><td class=kt>Da Matýsek</td><td class=kL>0:2 K</td>
<td class=kL>3:6 K</td>
<td class=kL>0:3</td>
<td class=kT>2:2 K</td>
<td class=kW>3:2</td>
<td class=kW>1:0 K</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>0:4 K</td>
<td class=kT>1:1</td>
<td class=kW>2:0 K</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kT>1:1 K</td>
<td class=br>22:27</td><td class=br>-5</td>
<td class=bc>5 - 5 - 5</td>
<td class=br>15</td><td class=d>8.</td>
</tr><tr><td class=ir>1/8</td><td class=ir>9</td><td class=kt>Kr Lebl</td><td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3 K</td>
<td class=kL>0:2</td>
<td class=kL>2:4 K</td>
<td class=kW>4:1</td>
<td class=kL>1:2 K</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:2 K</td>
<td class=kT>3:3</td>
<td class=kW>2:1 K</td>
<td class=kW>2:0</td>
<td class=kT>4:4 K</td>
<td class=kL>1:2 K</td>
<td class=kW>4:2</td>
<td class=br>31:33</td><td class=br>-2</td>
<td class=bc>5 - 3 - 7</td>
<td class=br>13</td><td class=d>9.</td>
</tr><tr><td class=ir>1/8</td><td class=ir>10</td><td class=kt>St Kraus</td><td class=kL>0:2</td>
<td class=kW>6:2</td>
<td class=kL>3:5 K</td>
<td class=kT>1:1</td>
<td class=kL>3:6 K</td>
<td class=kL>0:6</td>
<td class=kL>4:7 K</td>
<td class=kW>3:2</td>
<td class=kL>2:3 K</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>4:2 K</td>
<td class=kL>0:3</td>
<td class=kL>4:7 K</td>
<td class=kW>4:2 K</td>
<td class=kW>3:2</td>
<td class=br>42:52</td><td class=br>-10</td>
<td class=bc>6 - 1 - 8</td>
<td class=br>13</td><td class=d>10.</td>
</tr><tr><td class=ir>1/8</td><td class=ir>11</td><td class=kt>Da Šmíd</td><td class=kL>2:5 K</td>
<td class=kL>0:4 K</td>
<td class=kL>0:3</td>
<td class=kL>0:1 K</td>
<td class=kW>4:2</td>
<td class=kW>5:1 K</td>
<td class=kW>4:2</td>
<td class=kW>4:0 K</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kT>2:2 K</td>
<td class=kL>4:5</td>
<td class=kW>2:1</td>
<td class=kT>1:1 K</td>
<td class=br>33:39</td><td class=br>-6</td>
<td class=bc>5 - 3 - 7</td>
<td class=br>13</td><td class=d>11.</td>
</tr><tr><td class=ir>1/8</td><td class=ir>12</td><td class=kt>An Šurýn</td><td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>0:1 K</td>
<td class=kL>2:4</td>
<td class=kL>1:5 K</td>
<td class=kL>1:2</td>
<td class=kW>3:2 K</td>
<td class=kT>1:1</td>
<td class=kL>1:2 K</td>
<td class=kL>2:4 K</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:2 K</td>
<td class=kL>0:6 K</td>
<td class=kW>3:1</td>
<td class=br>29:37</td><td class=br>-8</td>
<td class=bc>4 - 3 - 8</td>
<td class=br>11</td><td class=d>12.</td>
</tr><tr><td class=ir>1/8</td><td class=ir>13</td><td class=kt>Mi Černoch</td><td class=kL>0:5 K</td>
<td class=kL>0:4 K</td>
<td class=kL>1:4</td>
<td class=kL>2:3 K</td>
<td class=kL>2:6</td>
<td class=kW>4:0 K</td>
<td class=kT>2:2</td>
<td class=kL>0:2 K</td>
<td class=kL>0:2</td>
<td class=kW>3:0</td>
<td class=kT>2:2 K</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>2:5</td>
<td class=kT>3:3 K</td>
<td class=br>28:44</td><td class=br>-16</td>
<td class=bc>3 - 4 - 8</td>
<td class=br>10</td><td class=d>13.</td>
</tr><tr><td class=ir>1/8</td><td class=ir>14</td><td class=kt>Ma Maděra</td><td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kT>1:1 K</td>
<td class=kL>0:2</td>
<td class=kL>0:4 K</td>
<td class=kT>2:2</td>
<td class=kL>1:5 K</td>
<td class=kL>0:3</td>
<td class=kT>4:4 K</td>
<td class=kW>7:4 K</td>
<td class=kW>5:4</td>
<td class=kL>2:5 K</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:0 K</td>
<td class=kL>2:3</td>
<td class=br>30:47</td><td class=br>-17</td>
<td class=bc>3 - 3 - 9</td>
<td class=br>9</td><td class=d>14.</td>
</tr><tr><td class=ir>1/8</td><td class=ir>15</td><td class=kt>Kr Herold</td><td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2 K</td>
<td class=kL>3:5</td>
<td class=kL>2:3 K</td>
<td class=kT>1:1</td>
<td class=kL>0:5 K</td>
<td class=kL>0:1</td>
<td class=kW>2:1 K</td>
<td class=kL>2:4 K</td>
<td class=kL>1:2</td>
<td class=kW>6:0 K</td>
<td class=kW>5:2</td>
<td class=kL>0:3 K</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=br>29:37</td><td class=br>-8</td>
<td class=bc>4 - 1 - 10</td>
<td class=br>9</td><td class=d>15.</td>
</tr><tr><td class=ir>1/8</td><td class=ir>16</td><td class=kt>Ti Varga</td><td class=kL>2:5 K</td>
<td class=kL>2:4 K</td>
<td class=kL>2:4</td>
<td class=kL>0:5 K</td>
<td class=kW>4:2</td>
<td class=kL>2:3 K</td>
<td class=kL>3:7</td>
<td class=kT>1:1 K</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kT>1:1 K</td>
<td class=kL>1:3</td>
<td class=kT>3:3 K</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=br>30:50</td><td class=br>-20</td>
<td class=bc>2 - 3 - 10</td>
<td class=br>7</td><td class=d>16.</td>
</tr></table></td></tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Fi Hamáček</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ja Dryák</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Dryák</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Ti Varga</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=blW>Ti Varga</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ja Dryák</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ja Dryák</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ti Varga</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Fi Hamáček</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ti Varga</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Fi Hamáček</td><td class=bc>-</td><td class=bl>Zd Matoušek ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Mi Hvižď</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ti Varga</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Mi Hvižď</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Mi Hvižď</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ti Varga</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>


<p class=v>Play-off<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><th colspan=11><font size="+1"><strong>Finále</strong></font></th></tr>
<tr><td class=br>Hvižď Michal&nbsp;&nbsp;</td>
<td class=bl><b>- Matoušek ml. Zdeněk</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 4&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:2 P&nbsp;&nbsp;</td>
<td class=bl>4:5 P&nbsp;&nbsp;</td>
<td class=bl>5:3&nbsp;&nbsp;</td>
<td class=bl>1:3&nbsp;&nbsp;</td>
<td class=bl>4:3 P&nbsp;&nbsp;</td>
<td class=bl>1:2&nbsp;&nbsp;</td>
<td class=bl>1:3&nbsp;&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>Semifinále</strong></font></th></tr>
<tr><td class=ar>Hamáček Filip&nbsp;&nbsp;</td>
<td class=al><b>- Hvižď Michal</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 4&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>1:5&nbsp;&nbsp;</td>
<td class=al>4:3&nbsp;&nbsp;</td>
<td class=al>3:2 P&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>1:3&nbsp;&nbsp;</td>
<td class=al>4:1&nbsp;&nbsp;</td>
<td class=al>2:6&nbsp;&nbsp;</td>
</tr><tr><td class=br>Petr Patrik&nbsp;&nbsp;</td>
<td class=bl><b>- Matoušek ml. Zdeněk</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;0 : 4&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:4&nbsp;&nbsp;</td>
<td class=bl>1:2&nbsp;&nbsp;</td>
<td class=bl>1:5&nbsp;&nbsp;</td>
<td class=bl>2:6&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>O 3.místo</strong></font></th></tr>
<tr><td class=ar><b>Petr Patrik</b>&nbsp;&nbsp;</td>
<td class=al>- Hamáček Filip&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:2 P&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>4:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>Čtvrtfinále</strong></font></th></tr>
<tr><td class=br><b>Hamáček Filip</b>&nbsp;&nbsp;</td>
<td class=bl>- Matýsek Daniel&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 2&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:3 P&nbsp;&nbsp;</td>
<td class=bl>0:1&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>4:2&nbsp;&nbsp;</td>
<td class=bl>4:0&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar>Hvižď ml. Leoš&nbsp;&nbsp;</td>
<td class=al><b>- Hvižď Michal</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;1 : 4&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>0:3&nbsp;&nbsp;</td>
<td class=al>4:3&nbsp;&nbsp;</td>
<td class=al>1:6&nbsp;&nbsp;</td>
<td class=al>3:4 P&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><b>Matoušek ml. Zdeněk</b>&nbsp;&nbsp;</td>
<td class=bl>- Chylík ml. Jiří&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:3&nbsp;&nbsp;</td>
<td class=bl>2:4&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>3:4&nbsp;&nbsp;</td>
<td class=bl>5:1&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
</tr><tr><td class=ar><b>Petr Patrik</b>&nbsp;&nbsp;</td>
<td class=al>- Dryák Jan&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:0&nbsp;&nbsp;</td>
<td class=al>4:3 P&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>5:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>O 17. místo</strong></font></th></tr>
<tr><td class=br><b>Zielinský Adam</b>&nbsp;&nbsp;</td>
<td class=bl>- Pikl Václav&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>7:1&nbsp;&nbsp;</td>
<td class=bl>7:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>O 19. místo</strong></font></th></tr>
<tr><td class=ar>Sládek Honza&nbsp;&nbsp;</td>
<td class=al><b>- Boštík Michal</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;1 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>1:5&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>2:5&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>O 21. místo</strong></font></th></tr>
<tr><td class=br>Kraus Vladimír&nbsp;&nbsp;</td>
<td class=bl><b>- Paclík Lukáš</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;0 : 2&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>1:5&nbsp;&nbsp;</td>
<td class=bl>1:6&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>O 23. místo</strong></font></th></tr>
<tr><td class=ar>Ženíšek Martin&nbsp;&nbsp;</td>
<td class=al><b>- Fiala Aleš</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;0 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:3 P&nbsp;&nbsp;</td>
<td class=al>2:3 P&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>O 25. místo</strong></font></th></tr>
<tr><td class=br><b>Kobrle Michal</b>&nbsp;&nbsp;</td>
<td class=bl>- Jež Robert&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>5:1&nbsp;&nbsp;</td>
<td class=bl>7:5&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>O 27. místo</strong></font></th></tr>
<tr><td class=ar>Kouba Martin&nbsp;&nbsp;</td>
<td class=al><b>- Ševr Miloš</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;0 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>5:6 P&nbsp;&nbsp;</td>
<td class=al>3:4&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>O 29. místo</strong></font></th></tr>
<tr><td class=br><b>Matoušek st. Zdeněk</b>&nbsp;&nbsp;</td>
<td class=bl>- Jackowská Aneta&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>1:4&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>O 31. místo</strong></font></th></tr>
<tr><td class=ar><b>Vácha Jiří</b>&nbsp;&nbsp;</td>
<td class=al>- Matýsek Jakub&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;2 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>4:2&nbsp;&nbsp;</td>
<td class=al>6:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr></table></td></tr></table></div></p>
<hr>

<p class=v>Konečné pořadí turnaje<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>Z</th>
<th>+</th>
<th>=</th>
<th>-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>B</th>
<th>Zisk b.</th>
<th>&nbsp;</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al>Matoušek ml. Zdeněk</td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>49</td>
<td class=ar>38</td>
<td class=ar>2</td>
<td class=ar>9</td>
<td class=ar>183</td>
<td class=al>: 86</td>
<td class=ar>78</td>
<td class=art>160</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>2.</td>
<td class=bl>Hvižď Michal</td>
<td class=bl>THC Stiga Elites</td>
<td class=br>50</td>
<td class=br>35</td>
<td class=br>2</td>
<td class=br>13</td>
<td class=br>199</td>
<td class=bl>: 103</td>
<td class=br>72</td>
<td class=brt>152</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>3.</td>
<td class=al>Petr Patrik</td>
<td class=al>THC Stiga Elites</td>
<td class=ar>42</td>
<td class=ar>34</td>
<td class=ar>1</td>
<td class=ar>7</td>
<td class=ar>175</td>
<td class=al>: 76</td>
<td class=ar>69</td>
<td class=art>146</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>4.</td>
<td class=bl>Hamáček Filip</td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>47</td>
<td class=br>31</td>
<td class=br>4</td>
<td class=br>12</td>
<td class=br>162</td>
<td class=bl>: 84</td>
<td class=br>66</td>
<td class=brt>141</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>5.</td>
<td class=al>Hvižď ml. Leoš</td>
<td class=al>THC Stiga-Game Příbram</td>
<td class=ar>36</td>
<td class=ar>23</td>
<td class=ar>6</td>
<td class=ar>7</td>
<td class=ar>129</td>
<td class=al>: 61</td>
<td class=ar>52</td>
<td class=art>137</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>6.</td>
<td class=bl>Chylík ml. Jiří</td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>38</td>
<td class=br>24</td>
<td class=br>3</td>
<td class=br>11</td>
<td class=br>116</td>
<td class=bl>: 78</td>
<td class=br>51</td>
<td class=brt>134</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>7.</td>
<td class=al>Dryák Jan</td>
<td class=al>Big Band</td>
<td class=ar>35</td>
<td class=ar>19</td>
<td class=ar>5</td>
<td class=ar>11</td>
<td class=ar>150</td>
<td class=al>: 84</td>
<td class=ar>43</td>
<td class=art>132</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>8.</td>
<td class=bl>Matýsek Daniel</td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>37</td>
<td class=br>21</td>
<td class=br>6</td>
<td class=br>10</td>
<td class=br>80</td>
<td class=bl>: 63</td>
<td class=br>48</td>
<td class=brt>131</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>9.</td>
<td class=al>Lebl Kryštof</td>
<td class=al>Big Band</td>
<td class=ar>31</td>
<td class=ar>18</td>
<td class=ar>6</td>
<td class=ar>7</td>
<td class=ar>97</td>
<td class=al>: 56</td>
<td class=ar>42</td>
<td class=art>128</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>10.</td>
<td class=bl>Kraus Stanislav</td>
<td class=bl>Absolut Desperation</td>
<td class=br>31</td>
<td class=br>20</td>
<td class=br>2</td>
<td class=br>9</td>
<td class=br>121</td>
<td class=bl>: 84</td>
<td class=br>42</td>
<td class=brt>127</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>11.</td>
<td class=al>Šmíd David</td>
<td class=al>THC Stiga Svitavy 93</td>
<td class=ar>31</td>
<td class=ar>19</td>
<td class=ar>3</td>
<td class=ar>9</td>
<td class=ar>106</td>
<td class=al>: 62</td>
<td class=ar>41</td>
<td class=art>126</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>12.</td>
<td class=bl>Šurýn Antonín</td>
<td class=bl>Big Band</td>
<td class=br>31</td>
<td class=br>17</td>
<td class=br>4</td>
<td class=br>10</td>
<td class=br>98</td>
<td class=bl>: 65</td>
<td class=br>38</td>
<td class=brt>125</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>13.</td>
<td class=al>Černoch Miroslav</td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>31</td>
<td class=ar>15</td>
<td class=ar>6</td>
<td class=ar>10</td>
<td class=ar>88</td>
<td class=al>: 69</td>
<td class=ar>36</td>
<td class=art>124</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>14.</td>
<td class=bl>Maděra Martin</td>
<td class=bl>APP Gladiators Plzeň</td>
<td class=br>31</td>
<td class=br>17</td>
<td class=br>4</td>
<td class=br>10</td>
<td class=br>103</td>
<td class=bl>: 71</td>
<td class=br>38</td>
<td class=brt>123</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>15.</td>
<td class=al>Herold Kryštof</td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>31</td>
<td class=ar>15</td>
<td class=ar>4</td>
<td class=ar>12</td>
<td class=ar>86</td>
<td class=al>: 74</td>
<td class=ar>34</td>
<td class=art>122</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>16.</td>
<td class=bl>Varga Tibor</td>
<td class=bl>BSE United</td>
<td class=br>31</td>
<td class=br>17</td>
<td class=br>4</td>
<td class=br>10</td>
<td class=br>92</td>
<td class=bl>: 71</td>
<td class=br>38</td>
<td class=brt>121</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>17.</td>
<td class=al>Zielinský Adam</td>
<td class=al>Big Band</td>
<td class=ar>25</td>
<td class=ar>16</td>
<td class=ar>1</td>
<td class=ar>8</td>
<td class=ar>93</td>
<td class=al>: 54</td>
<td class=ar>33</td>
<td class=art>119</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>18.</td>
<td class=bl>Pikl Václav</td>
<td class=bl>THC Stiga Elites</td>
<td class=br>25</td>
<td class=br>14</td>
<td class=br>2</td>
<td class=br>9</td>
<td class=br>68</td>
<td class=bl>: 62</td>
<td class=br>30</td>
<td class=brt>118</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>19.</td>
<td class=al>Boštík Michal</td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>26</td>
<td class=ar>15</td>
<td class=ar>2</td>
<td class=ar>9</td>
<td class=ar>84</td>
<td class=al>: 65</td>
<td class=ar>32</td>
<td class=art>117</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>20.</td>
<td class=bl>Sládek Honza</td>
<td class=bl>APP Gladiators Plzeň</td>
<td class=br>26</td>
<td class=br>13</td>
<td class=br>5</td>
<td class=br>8</td>
<td class=br>93</td>
<td class=bl>: 59</td>
<td class=br>31</td>
<td class=brt>116</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>21.</td>
<td class=al>Paclík Lukáš</td>
<td class=al>BSE United</td>
<td class=ar>25</td>
<td class=ar>14</td>
<td class=ar>3</td>
<td class=ar>8</td>
<td class=ar>69</td>
<td class=al>: 55</td>
<td class=ar>31</td>
<td class=art>115</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>22.</td>
<td class=bl>Kraus Vladimír</td>
<td class=bl>Absolut Desperation</td>
<td class=br>25</td>
<td class=br>13</td>
<td class=br>0</td>
<td class=br>12</td>
<td class=br>83</td>
<td class=bl>: 64</td>
<td class=br>26</td>
<td class=brt>114</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>23.</td>
<td class=al>Fiala Aleš</td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>25</td>
<td class=ar>12</td>
<td class=ar>5</td>
<td class=ar>8</td>
<td class=ar>76</td>
<td class=al>: 51</td>
<td class=ar>29</td>
<td class=art>113</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>24.</td>
<td class=bl>Ženíšek Martin</td>
<td class=bl>APP Gladiators Plzeň</td>
<td class=br>25</td>
<td class=br>10</td>
<td class=br>3</td>
<td class=br>12</td>
<td class=br>71</td>
<td class=bl>: 69</td>
<td class=br>23</td>
<td class=brt>112</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>25.</td>
<td class=al>Kobrle Michal</td>
<td class=al>THC Stiga Elites</td>
<td class=ar>25</td>
<td class=ar>10</td>
<td class=ar>4</td>
<td class=ar>11</td>
<td class=ar>88</td>
<td class=al>: 74</td>
<td class=ar>24</td>
<td class=art>111</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>26.</td>
<td class=bl>Jež Robert</td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>25</td>
<td class=br>11</td>
<td class=br>1</td>
<td class=br>13</td>
<td class=br>68</td>
<td class=bl>: 72</td>
<td class=br>23</td>
<td class=brt>109</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>27.</td>
<td class=al>Ševr Miloš</td>
<td class=al>THC Stiga Elites</td>
<td class=ar>25</td>
<td class=ar>10</td>
<td class=ar>4</td>
<td class=ar>11</td>
<td class=ar>70</td>
<td class=al>: 69</td>
<td class=ar>24</td>
<td class=art>107</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>28.</td>
<td class=bl>Kouba Martin</td>
<td class=bl>BSE United</td>
<td class=br>25</td>
<td class=br>9</td>
<td class=br>2</td>
<td class=br>14</td>
<td class=br>77</td>
<td class=bl>: 84</td>
<td class=br>20</td>
<td class=brt>106</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>29.</td>
<td class=al>Matoušek st. Zdeněk</td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>26</td>
<td class=ar>11</td>
<td class=ar>1</td>
<td class=ar>14</td>
<td class=ar>74</td>
<td class=al>: 83</td>
<td class=ar>23</td>
<td class=art>105</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>30.</td>
<td class=bl>Jackowská Aneta</td>
<td class=bl>BSE United</td>
<td class=br>26</td>
<td class=br>9</td>
<td class=br>3</td>
<td class=br>14</td>
<td class=br>68</td>
<td class=bl>: 83</td>
<td class=br>21</td>
<td class=brt>104</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>31.</td>
<td class=al>Vácha Jiří</td>
<td class=al>SHC Cheb</td>
<td class=ar>25</td>
<td class=ar>10</td>
<td class=ar>3</td>
<td class=ar>12</td>
<td class=ar>86</td>
<td class=al>: 79</td>
<td class=ar>23</td>
<td class=art>103</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>32.</td>
<td class=bl>Matýsek Jakub</td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>25</td>
<td class=br>8</td>
<td class=br>2</td>
<td class=br>15</td>
<td class=br>51</td>
<td class=bl>: 88</td>
<td class=br>18</td>
<td class=brt>102</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>33.</td>
<td class=al>Nechutný Hynek</td>
<td class=al>APP Gladiators Plzeň</td>
<td class=ar>23</td>
<td class=ar>8</td>
<td class=ar>1</td>
<td class=ar>14</td>
<td class=ar>49</td>
<td class=al>: 70</td>
<td class=ar>17</td>
<td class=art>100</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>34.</td>
<td class=bl>Marek František</td>
<td class=bl>BSE United</td>
<td class=br>23</td>
<td class=br>7</td>
<td class=br>2</td>
<td class=br>14</td>
<td class=br>55</td>
<td class=bl>: 78</td>
<td class=br>16</td>
<td class=brt>99</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>35.</td>
<td class=al>Dvořáček David</td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>23</td>
<td class=ar>8</td>
<td class=ar>1</td>
<td class=ar>14</td>
<td class=ar>68</td>
<td class=al>: 83</td>
<td class=ar>17</td>
<td class=art>98</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>36.</td>
<td class=bl>Hána Samuel</td>
<td class=bl>BSE United</td>
<td class=br>23</td>
<td class=br>5</td>
<td class=br>3</td>
<td class=br>15</td>
<td class=br>54</td>
<td class=bl>: 85</td>
<td class=br>13</td>
<td class=brt>97</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>37.</td>
<td class=al>Mašková Iva</td>
<td class=al>SHC Cheb</td>
<td class=ar>23</td>
<td class=ar>4</td>
<td class=ar>4</td>
<td class=ar>15</td>
<td class=ar>55</td>
<td class=al>: 100</td>
<td class=ar>12</td>
<td class=art>96</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>38.</td>
<td class=bl>Kahoun st. Tomáš</td>
<td class=bl>BSE United</td>
<td class=br>23</td>
<td class=br>5</td>
<td class=br>1</td>
<td class=br>17</td>
<td class=br>35</td>
<td class=bl>: 83</td>
<td class=br>11</td>
<td class=brt>95</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>39.</td>
<td class=al>Junek Jiří</td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>23</td>
<td class=ar>4</td>
<td class=ar>4</td>
<td class=ar>15</td>
<td class=ar>46</td>
<td class=al>: 110</td>
<td class=ar>12</td>
<td class=art>94</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>40.</td>
<td class=bl>Jedlička Tomáš</td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>23</td>
<td class=br>3</td>
<td class=br>4</td>
<td class=br>16</td>
<td class=br>46</td>
<td class=bl>: 82</td>
<td class=br>10</td>
<td class=brt>93</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>41.</td>
<td class=al>Kahoun ml. Tomáš</td>
<td class=al>BSE United</td>
<td class=ar>23</td>
<td class=ar>2</td>
<td class=ar>6</td>
<td class=ar>15</td>
<td class=ar>34</td>
<td class=al>: 91</td>
<td class=ar>10</td>
<td class=art>92</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>42.</td>
<td class=bl>Petr Jindřich</td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>23</td>
<td class=br>4</td>
<td class=br>0</td>
<td class=br>19</td>
<td class=br>41</td>
<td class=bl>: 94</td>
<td class=br>8</td>
<td class=brt>91</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>43.</td>
<td class=al>Pohořalý Pavel</td>
<td class=al>THC Teplýšovice</td>
<td class=ar>23</td>
<td class=ar>3</td>
<td class=ar>2</td>
<td class=ar>18</td>
<td class=ar>41</td>
<td class=al>: 94</td>
<td class=ar>8</td>
<td class=art>90</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>44.</td>
<td class=bl>Kahoun Lukáš</td>
<td class=bl>BSE United</td>
<td class=br>23</td>
<td class=br>3</td>
<td class=br>1</td>
<td class=br>19</td>
<td class=br>40</td>
<td class=bl>: 133</td>
<td class=br>7</td>
<td class=brt>89</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>45.</td>
<td class=al>Mareš st. Miroslav</td>
<td class=al>BSE United</td>
<td class=ar>23</td>
<td class=ar>1</td>
<td class=ar>3</td>
<td class=ar>19</td>
<td class=ar>29</td>
<td class=al>: 112</td>
<td class=ar>5</td>
<td class=art>88</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>46.</td>
<td class=bl>Petrová Barbora</td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>23</td>
<td class=br>0</td>
<td class=br>4</td>
<td class=br>19</td>
<td class=br>39</td>
<td class=bl>: 145</td>
<td class=br>4</td>
<td class=brt>86</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>47.</td>
<td class=al>Marešová Hana</td>
<td class=al>BSE United</td>
<td class=ar>23</td>
<td class=ar>1</td>
<td class=ar>1</td>
<td class=ar>21</td>
<td class=ar>16</td>
<td class=al>: 100</td>
<td class=ar>3</td>
<td class=art>84</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>48.</td>
<td class=bl>Komárek Pavel</td>
<td class=bl>BSE United</td>
<td class=br>23</td>
<td class=br>0</td>
<td class=br>2</td>
<td class=br>21</td>
<td class=br>25</td>
<td class=bl>: 119</td>
<td class=br>2</td>
<td class=brt>83</td>
<td class=br>&nbsp;</td>
</tr></table></td></tr></table></div></p>

</body></html>