<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN">
<html lang="cz">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<title>MR, Praha</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
</head>
<body class="neop">
<a name="Zac"><p class=l>MR, Praha, 30. May 2015</p></a>
<div align=center><p><a href="index.aspx">Back</a></p></div>
<p class=v>Basic Group</br><div align=center>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=2 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=ir>1</td><td class=kt>ml Chylík</td><td class=kx>*</td>
<td class=kL>2:4 + 3:2</td>
<td class=kT>2:2 + 3:2</td>
<td class=kW>4:2 + 4:1</td>
<td class=kW>2:1 + 3:1</td>
<td class=kW>4:2 + 5:1</td>
<td class=kW>5:1 + 2:2</td>
<td class=kT>4:4 + 8:2</td>
<td class=kW>9:0 + 12:2</td>
<td class=kW>4:1 + 5:2</td>
<td class=br>81:32</td><td class=br>+49</td>
<td class=bc>14 - 3 - 1</td>
<td class=br>31</td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=ir>2</td><td class=kt>Mi Kobrle</td><td class=kW>4:2 + 2:3</td>
<td class=kx>*</td>
<td class=kL>0:2 + 4:0</td>
<td class=kW>4:0 + 7:3</td>
<td class=kW>5:3 + 4:5</td>
<td class=kW>6:2 + 5:3</td>
<td class=kW>6:1 + 6:3</td>
<td class=kW>7:1 + 6:1</td>
<td class=kW>7:0 + 8:3</td>
<td class=kW>13:0 + 5:0</td>
<td class=br>99:32</td><td class=br>+67</td>
<td class=bc>15 - 0 - 3</td>
<td class=br>30</td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=ir>3</td><td class=kt>Ho Sládek</td><td class=kT>2:2 + 2:3</td>
<td class=kW>2:0 + 0:4</td>
<td class=kx>*</td>
<td class=kT>3:3 + 3:3</td>
<td class=kW>7:0 + 5:0</td>
<td class=kW>5:1 + 5:0</td>
<td class=kW>5:1 + 6:1</td>
<td class=kW>6:0 + 4:0</td>
<td class=kW>10:1 + 12:0</td>
<td class=kW>14:0 + 5:0</td>
<td class=br>96:19</td><td class=br>+77</td>
<td class=bc>13 - 3 - 2</td>
<td class=br>29</td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=ir>4</td><td class=kt>Sa Hána</td><td class=kL>2:4 + 1:4</td>
<td class=kL>0:4 + 3:7</td>
<td class=kT>3:3 + 3:3</td>
<td class=kx>*</td>
<td class=kL>0:1 + 7:2</td>
<td class=kL>1:4 + 2:2</td>
<td class=kW>4:1 + 5:3</td>
<td class=kW>6:3 + 7:0</td>
<td class=kW>8:1 + 5:2</td>
<td class=kW>5:1 + 5:1</td>
<td class=br>67:46</td><td class=br>+21</td>
<td class=bc>9 - 3 - 6</td>
<td class=br>21</td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=ir>5</td><td class=kt>To Kahoun ml.</td><td class=kL>1:2 + 1:3</td>
<td class=kL>3:5 + 5:4</td>
<td class=kL>0:7 + 0:5</td>
<td class=kW>1:0 + 2:7</td>
<td class=kx>*</td>
<td class=kT>1:1 + 2:1</td>
<td class=kL>1:6 + 2:3</td>
<td class=kW>6:2 + 5:2</td>
<td class=kW>9:1 + 9:0</td>
<td class=kW>6:0 + 5:0</td>
<td class=br>59:49</td><td class=br>+10</td>
<td class=bc>9 - 1 - 8</td>
<td class=br>19</td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=ir>6</td><td class=kt>Lu Kahoun</td><td class=kL>2:4 + 1:5</td>
<td class=kL>2:6 + 3:5</td>
<td class=kL>1:5 + 0:5</td>
<td class=kW>4:1 + 2:2</td>
<td class=kT>1:1 + 1:2</td>
<td class=kx>*</td>
<td class=kW>4:2 + 2:2</td>
<td class=kW>2:1 + 5:1</td>
<td class=kW>4:3 + 9:1</td>
<td class=kW>3:1 + 3:1</td>
<td class=br>49:48</td><td class=br>+1</td>
<td class=bc>8 - 3 - 7</td>
<td class=br>19</td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=ir>7</td><td class=kt>Ja Matýsek</td><td class=kL>1:5 + 2:2</td>
<td class=kL>1:6 + 3:6</td>
<td class=kL>1:5 + 1:6</td>
<td class=kL>1:4 + 3:5</td>
<td class=kW>6:1 + 3:2</td>
<td class=kL>2:4 + 2:2</td>
<td class=kx>*</td>
<td class=kW>6:0 + 5:2</td>
<td class=kW>7:1 + 7:1</td>
<td class=kL>1:3 + 3:0</td>
<td class=br>55:55</td><td class=br>0</td>
<td class=bc>7 - 2 - 9</td>
<td class=br>16</td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=ir>8</td><td class=kt>Pa Komárek</td><td class=kT>4:4 + 2:8</td>
<td class=kL>1:7 + 1:6</td>
<td class=kL>0:6 + 0:4</td>
<td class=kL>3:6 + 0:7</td>
<td class=kL>2:6 + 2:5</td>
<td class=kL>1:2 + 1:5</td>
<td class=kL>0:6 + 2:5</td>
<td class=kx>*</td>
<td class=kW>3:0 + 3:1</td>
<td class=kW>3:1 + 2:1</td>
<td class=br>30:80</td><td class=br>-50</td>
<td class=bc>4 - 1 - 13</td>
<td class=br>9</td><td class=d>8.</td>
</tr><tr><td class=ir>J</td><td class=ir>9</td><td class=kt>Lu Vaněk</td><td class=kL>0:9 + 2:12</td>
<td class=kL>0:7 + 3:8</td>
<td class=kL>1:10 + 0:12</td>
<td class=kL>1:8 + 2:5</td>
<td class=kL>1:9 + 0:9</td>
<td class=kL>3:4 + 1:9</td>
<td class=kL>1:7 + 1:7</td>
<td class=kL>0:3 + 1:3</td>
<td class=kx>*</td>
<td class=kW>3:0 + 1:1</td>
<td class=br>21:123</td><td class=br>-102</td>
<td class=bc>1 - 1 - 16</td>
<td class=br>3</td><td class=d>9.</td>
</tr><tr><td class=ir>J</td><td class=ir>10</td><td class=kt>Al Mačinský</td><td class=kL>1:4 + 2:5</td>
<td class=kL>0:13 + 0:5</td>
<td class=kL>0:14 + 0:5</td>
<td class=kL>1:5 + 1:5</td>
<td class=kL>0:6 + 0:5</td>
<td class=kL>1:3 + 1:3</td>
<td class=kW>3:1 + 0:3</td>
<td class=kL>1:3 + 1:2</td>
<td class=kL>0:3 + 1:1</td>
<td class=kx>*</td>
<td class=br>13:86</td><td class=br>-73</td>
<td class=bc>1 - 1 - 16</td>
<td class=br>3</td><td class=d>10.</td>
</tr></table></td></tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>9 : 0 + 12 : 2</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Al Mačinský</td><td class=bc>14 : 0 + 5 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Pa Komárek</td><td class=bc>7 : 1 + 6 : 1</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 6 + 2 : 3</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>4 : 1 + 2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Lu Vaněk</td><td class=bc>-</td><td class=bl>Al Mačinský</td><td class=bc>3 : 0 + 1 : 1</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=bl>Pa Komárek</td><td class=bc>4 : 4 + 8 : 2</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>5 : 1 + 6 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>4 : 0 + 7 : 3</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>1 : 1 + 2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Al Mačinský</td><td class=bc>-</td><td class=blW>Pa Komárek</td><td class=bc>1 : 3 + 1 : 2</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 7 + 1 : 7</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>4 : 2 + 4 : 1</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>5 : 1 + 5 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>5 : 3 + 4 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Pa Komárek</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 6 + 2 : 5</tr></td>
<tr><td class=br>Al Mačinský</td><td class=bc>-</td><td class=blW>Sa Hána</td><td class=bc>1 : 5 + 1 : 5</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>3 : 4 + 1 : 9</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>2 : 1 + 3 : 1</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>2 : 0 + 0 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Sa Hána</td><td class=bc>1 : 4 + 3 : 5</tr></td>
<tr><td class=br>Pa Komárek</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>1 : 2 + 1 : 5</tr></td>
<tr><td class=br>Al Mačinský</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>0 : 6 + 0 : 5</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 7 + 3 : 8</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>2 : 2 + 3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>0 : 1 + 7 : 2</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 6 + 3 : 6</tr></td>
<tr><td class=br>Pa Komárek</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 6 + 0 : 4</tr></td>
<tr><td class=br>Al Mačinský</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>1 : 4 + 2 : 5</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 6 + 3 : 5</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>3 : 3 + 3 : 3</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>1 : 5 + 2 : 2</tr></td>
<tr><td class=brW>Pa Komárek</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>3 : 0 + 3 : 1</tr></td>
<tr><td class=br>Al Mačinský</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 7 + 0 : 5</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>2 : 4 + 1 : 5</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>8 : 1 + 5 : 2</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Al Mačinský</td><td class=bc>1 : 3 + 3 : 0</tr></td>
<tr><td class=br>Pa Komárek</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>4 : 2 + 2 : 3</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>9 : 1 + 9 : 0</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Al Mačinský</td><td class=bc>3 : 1 + 3 : 1</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>Pa Komárek</td><td class=bc>6 : 3 + 7 : 0</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>10 : 1 + 12 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Al Mačinský</td><td class=bc>13 : 0 + 5 : 0</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Pa Komárek</td><td class=bc>6 : 2 + 5 : 2</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>4 : 2 + 2 : 2</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>


<p class=v>Play-off<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><th colspan=11><font size="+1"><strong>Finále</strong></font></th></tr>
<tr><td class=br><b>Chylík ml. Jiří</b>&nbsp;&nbsp;</td>
<td class=bl>- Sládek Honza&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:2&nbsp;&nbsp;</td>
<td class=bl>2:1&nbsp;&nbsp;</td>
<td class=bl>3:0&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>Semifinále</strong></font></th></tr>
<tr><td class=ar><b>Chylík ml. Jiří</b>&nbsp;&nbsp;</td>
<td class=al>- Hána Samuel&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>1:2&nbsp;&nbsp;</td>
<td class=al>3:4 P&nbsp;&nbsp;</td>
<td class=al>4:2&nbsp;&nbsp;</td>
<td class=al>6:1&nbsp;&nbsp;</td>
<td class=al>3:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br>Kobrle Michal&nbsp;&nbsp;</td>
<td class=bl><b>- Sládek Honza</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:3 P&nbsp;&nbsp;</td>
<td class=bl>5:3&nbsp;&nbsp;</td>
<td class=bl>1:3&nbsp;&nbsp;</td>
<td class=bl>1:2 P&nbsp;&nbsp;</td>
<td class=bl>1:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>O 3.místo</strong></font></th></tr>
<tr><td class=ar><b>Kobrle Michal</b>&nbsp;&nbsp;</td>
<td class=al>- Hána Samuel&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>9:0&nbsp;&nbsp;</td>
<td class=al>2:1 P&nbsp;&nbsp;</td>
<td class=al>6:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr></table></td></tr></table></div></p>

<hr>

<p class=v>Konečné pořadí turnaje<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>Z</th>
<th>+</th>
<th>=</th>
<th>-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>B</th>
<th></th>
<th>&nbsp;</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al>Chylík ml. Jiří</td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>26</td>
<td class=ar>20</td>
<td class=ar>3</td>
<td class=ar>3</td>
<td class=ar>107</td>
<td class=al>: 45</td>
<td class=ar>43</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>2.</td>
<td class=bl>Sládek Honza</td>
<td class=bl>APP Gladiators Plzeň</td>
<td class=br>26</td>
<td class=br>16</td>
<td class=br>3</td>
<td class=br>7</td>
<td class=br>113</td>
<td class=bl>: 40</td>
<td class=br>35</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>3.</td>
<td class=al>Kobrle Michal</td>
<td class=al>THC Stiga Elites</td>
<td class=ar>26</td>
<td class=ar>20</td>
<td class=ar>0</td>
<td class=ar>6</td>
<td class=ar>128</td>
<td class=al>: 49</td>
<td class=ar>40</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>4.</td>
<td class=bl>Hána Samuel</td>
<td class=bl>BSE United</td>
<td class=br>26</td>
<td class=br>11</td>
<td class=br>3</td>
<td class=br>12</td>
<td class=br>80</td>
<td class=bl>: 80</td>
<td class=br>25</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>5.</td>
<td class=al>Kahoun ml. Tomáš</td>
<td class=al>BSE United</td>
<td class=ar>18</td>
<td class=ar>9</td>
<td class=ar>1</td>
<td class=ar>8</td>
<td class=ar>59</td>
<td class=al>: 49</td>
<td class=ar>19</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>6.</td>
<td class=bl>Kahoun Lukáš</td>
<td class=bl>BSE United</td>
<td class=br>18</td>
<td class=br>8</td>
<td class=br>3</td>
<td class=br>7</td>
<td class=br>49</td>
<td class=bl>: 48</td>
<td class=br>19</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>7.</td>
<td class=al>Matýsek Jakub</td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>18</td>
<td class=ar>7</td>
<td class=ar>2</td>
<td class=ar>9</td>
<td class=ar>55</td>
<td class=al>: 55</td>
<td class=ar>16</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>8.</td>
<td class=bl>Komárek Pavel</td>
<td class=bl>BSE United</td>
<td class=br>18</td>
<td class=br>4</td>
<td class=br>1</td>
<td class=br>13</td>
<td class=br>30</td>
<td class=bl>: 80</td>
<td class=br>9</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>9.</td>
<td class=al>Vaněk Lukáš</td>
<td class=al>Praha</td>
<td class=ar>18</td>
<td class=ar>1</td>
<td class=ar>1</td>
<td class=ar>16</td>
<td class=ar>21</td>
<td class=al>: 123</td>
<td class=ar>3</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>10.</td>
<td class=bl>Mačinský Alexander</td>
<td class=bl>Praha</td>
<td class=br>18</td>
<td class=br>1</td>
<td class=br>1</td>
<td class=br>16</td>
<td class=br>13</td>
<td class=bl>: 86</td>
<td class=br>3</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr></table></td></tr></table></div></p>
<p>&nbsp;</p>
<div align=center><p>Created by <b>Trefik</b>, table hockey edition. Copyright 2003-2015 Vladimír Kraus<br><a href="http://www.trefik.cz">www.trefik.cz</a></p></div>

</body>
</html>