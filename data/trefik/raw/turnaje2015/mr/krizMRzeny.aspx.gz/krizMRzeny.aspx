<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN">
<html lang="cz">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<title>MR, Praha</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
</head>
<body class="neop">
<a name="Zac"><p class=l>MR, Praha, 30. May 2015</p></a>
<div align=center><p><a href="index.aspx">Back</a></p></div>
<p class=vm>Basic groups</p>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=2 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=ir>1</td><td class=kt>An Jackowská</td><td class=kx>*</td>
<td class=kW>3:2 + 3:4</td>
<td class=kT>4:4 + 5:1</td>
<td class=kW>4:0 + 6:2</td>
<td class=br>25:13</td><td class=br>+12</td>
<td class=bc>4 - 1 - 1</td>
<td class=br>9</td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=ir>2</td><td class=kt>Iv Mašková</td><td class=kL>2:3 + 4:3</td>
<td class=kx>*</td>
<td class=kT>4:4 + 5:4</td>
<td class=kW>4:0 + 1:4</td>
<td class=br>20:18</td><td class=br>+2</td>
<td class=bc>3 - 1 - 2</td>
<td class=br>7</td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=ir>3</td><td class=kt>Ba Petrová</td><td class=kT>4:4 + 1:5</td>
<td class=kT>4:4 + 4:5</td>
<td class=kx>*</td>
<td class=kW>2:0 + 2:2</td>
<td class=br>17:20</td><td class=br>-3</td>
<td class=bc>1 - 3 - 2</td>
<td class=br>5</td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=ir>4</td><td class=kt>Ha Marešová</td><td class=kL>0:4 + 2:6</td>
<td class=kL>0:4 + 4:1</td>
<td class=kL>0:2 + 2:2</td>
<td class=kx>*</td>
<td class=br>8:19</td><td class=br>-11</td>
<td class=bc>1 - 1 - 4</td>
<td class=br>3</td><td class=d>4.</td>
</tr></table></td></tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>An Jackowská</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>4 : 0 + 6 : 2</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=bl>Ba Petrová</td><td class=bc>4 : 4 + 5 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=blW>Ba Petrová</td><td class=bc>0 : 2 + 2 : 2</tr></td>
<tr><td class=brW>An Jackowská</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>3 : 2 + 3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ba Petrová</td><td class=bc>-</td><td class=bl>An Jackowská</td><td class=bc>4 : 4 + 1 : 5</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>4 : 0 + 1 : 4</tr></td>
<tr><td class=br>Ba Petrová</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>


<p class=v>Play-off<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><th colspan=11><font size="+1"><strong>Finále</strong></font></th></tr>
<tr><td class=br>&nbsp;</td>
<td class=bl><b>Jackowská Aneta</b>&nbsp;&nbsp;</td>
<td class=bl>- Mašková Iva&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;4:1</strong></td>
<td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:2</td>
<td class=bl>3:2</td>
<td class=bl>3:2P</td>
<td class=bl>3:4P</td>
<td class=bl>3:2</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>Semifinále</strong></font></th></tr>
<tr><td class=ar><b>Jackowská Aneta</b>&nbsp;&nbsp;</td>
<td class=al>- Marešová Hana&nbsp;&nbsp;</td>
<td class=al><b>4:1</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;</strong></td>
<td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>5:1</td>
<td class=al>5:6</td>
<td class=al>2:1</td>
<td class=al>3:2</td>
<td class=al>8:0</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><b>Mašková Iva</b>&nbsp;&nbsp;</td>
<td class=bl>- Petrová Barbora&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 2&nbsp;&nbsp;</strong></td>
<td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>5:3&nbsp;&nbsp;</td>
<td class=bl>5:2&nbsp;&nbsp;</td>
<td class=bl>1:2 P&nbsp;&nbsp;</td>
<td class=bl>2:3 P&nbsp;&nbsp;</td>
<td class=bl>6:1&nbsp;&nbsp;</td>
<td class=bl>3:0&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>O 3.místo</strong></font></th></tr>
<tr><td class=ar><b>Petrová Barbora</b>&nbsp;&nbsp;</td>
<td class=al>- Marešová Hana&nbsp;&nbsp;</td>
<td class=al><b>4:0</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;</strong></td>
<td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>4:3</td>
<td class=al>4:0</td>
<td class=al>3:2P</td>
<td class=al>4:0</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr>
</table>
</td>
</tr>
</table>
</div>

<p class=v>Konečné pořadí turnaje<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>Z</th>
<th>+</th>
<th>=</th>
<th>-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>B</th>
<th></th>
<th>&nbsp;</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al>Jackowská Aneta</td>
<td class=al>BSE United</td>
<td class=ar>16</td>
<td class=ar>12</td>
<td class=ar>1</td>
<td class=ar>3</td>
<td class=ar>64</td>
<td class=al>: 35</td>
<td class=ar>25</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>2.</td>
<td class=bl>Mašková Iva</td>
<td class=bl>SHC Cheb</td>
<td class=br>17</td>
<td class=br>8</td>
<td class=br>1</td>
<td class=br>8</td>
<td class=br>54</td>
<td class=bl>: 45</td>
<td class=br>17</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>3.</td>
<td class=al>Petrová Barbora</td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>16</td>
<td class=ar>7</td>
<td class=ar>3</td>
<td class=ar>6</td>
<td class=ar>43</td>
<td class=al>: 47</td>
<td class=ar>17</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr>
<tr><td class=br>3.</td>
<td class=bl>Marešová Hana</td>
<td class=bl>BSE United</td>
<td class=br>15</td>
<td class=br>2</td>
<td class=br>1</td>
<td class=br>4</td>
<td class=br>31</td>
<td class=bl>: 57</td>
<td class=br>5</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr>
</table></td></tr></table></div></p>


<hr>