<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN">
<html lang="cz">

<head>
<meta http-equiv="Content-Type"
content="text/html; charset=windows-1250">
<title>Mistrovství republiky ve stolním hokeji Stiga 201</title>
<link rel="StyleSheet" href="../../css.css" type="text/css">
</head>

<body class="neop">


<table width="100%" border="0" cellspacing="0" cellpadding="0">
<tr>
<td valign="top" align="center">

<table border="0" cellspacing="0" cellpadding="0" width="800">

<tr>

<td valign="middle" align="center">

<img alt="Česká asociace Stiga Game" border="0" src="../../images/logocasg.gif">

</td>



<td align="center">


	<table border="0" cellpadding="0" cellspacing="0" width="100%" align="center">
	<tr>
		<td><table border="0" cellpadding="0" cellspacing="0" width="100%">
			<tr>
				<td align=center><img src="../../images/zahlaviwebu.jpg" alt=""></td>
			</tr>
			<tr>
				<td>
					<table border="0" cellpadding="1" cellspacing="0" align="center" width="550">
					<tr>
						<td class="menu1"><a class="menu" href="../../index.htm">Úvod</a></td>
<td>&nbsp;|&nbsp;</td>
						<td class="menu1"><a class="menu" href="../../hokej.htm">Stolní hokej</a></td>
<td>&nbsp;|&nbsp;</td>
						<td class="menu1"><a class="menu" href="../../asociace.htm">Asociace</a></td>
<td>&nbsp;|&nbsp;</td>
						<td class="menu1"><a class="menu" href="../../pohar.aspx">Český pohár</a></td>
<td>&nbsp;|&nbsp;</td>
						<td class="menu1"><a class="menu" href="../../odkazy.htm">Odkazy</a></td>
<td>&nbsp;|&nbsp;</td>
						<td class="menu1"><a class="menu" href="../../ohlasy/index.asp">Diskuze</a></td>
					</tr>
					</table>
				</td>
			</tr>
			</table>
		</td>
		
	</tr>
	</table>
</td>

</tr>
<tr><td colspan="2"><hr></td></tr>

</table></td></tr>

<tr><td valign="top">

<br>
<table border="0" align="center" width="80%" cellspacing="0" cellpadding="2"><tr><td>
<p class="v">Mistrovství republiky ve stolním hokeji Stiga 2015</p>
<br>

<p align="center"><a href="krizMRJ.aspx"><font face="Arial">Turnaj
jednotlivců</font></a><font face="Arial"> - vítěz: <strong>Zdeněk Matoušek ml.</strong>, 2.místo: <strong>Michal Hvižď</strong>,
3.místo: <strong>Patrik Petr</strong>.</p>

<p align="center"><font face="Arial"><a href="druzstva.htm"><font face="Arial">Turnaj družstev</font></a> - vítěz: <strong>THC Stiga Elites</strong>, 2.místo: <strong>HCS Žabka Praha</strong>, 3.místo <strong>Big Band</strong>.</font></p>

<p align="center"><a href="krizMRzeny.aspx"><font face="Arial">Turnaj žen</font></a><font
face="Arial"> - vítězka: <strong>Aneta Jackowská</strong>, 2.místo:
<strong>Iva Mašková</strong>, 3.místo: <strong>Barbora Petrová</strong>.</font></p>

<p align="center"><a href="krizMRjun.aspx"><font face="Arial">Turnaj
juniorů</font></a><font face="Arial"> - vítěz: <strong>Jiří Chylík</strong>, 2.místo: <strong>Jan Sládek</strong>, 3.místo:
<strong>Michal Kobrle</strong>.</font></p>

<p align="center"><a href="krizMRvet.aspx"><font face="Arial">Turnaj
veteránů</font></a><font face="Arial"> - vítěz: <strong>Jan Dryák</strong>, 2.místo: <strong>Václav Pikl</strong>, 3.místo: <strong>Pavel Plešák</strong>.</font></p>

<br><br>


</td></tr></table>



</td></tr>

</table>



</body>
</html>