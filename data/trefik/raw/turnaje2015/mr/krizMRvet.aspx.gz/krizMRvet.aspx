<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN">
<html lang="cz">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<title>MR, Praha</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
</head>
<body class="neop">
<a name="Zac"><p class=l>MR, Praha, 30. May 2015</p></a>
<div align=center><p><a href="index.aspx">Back</a></p></div>
<p class=vm>Basic groups</p>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=2 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=ir>1</td><td class=kt>Ja Dryák</td><td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>7:0</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=br>72:26</td><td class=br>+46</td>
<td class=bc>11 - 3 - 1</td>
<td class=br>25</td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=ir>2</td><td class=kt>Da Matýsek</td><td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>8:2</td>
<td class=kW>5:2</td>
<td class=br>52:32</td><td class=br>+20</td>
<td class=bc>10 - 2 - 3</td>
<td class=br>22</td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=ir>3</td><td class=kt>Mi Ševr</td><td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>7:3</td>
<td class=kW>6:1</td>
<td class=kW>11:0</td>
<td class=br>58:34</td><td class=br>+24</td>
<td class=bc>9 - 3 - 3</td>
<td class=br>21</td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=ir>4</td><td class=kt>Da Šmíd</td><td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>9:3</td>
<td class=kW>5:0</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kL>2:5</td>
<td class=kW>10:0</td>
<td class=kW>6:0</td>
<td class=kW>11:1</td>
<td class=kW>10:1</td>
<td class=br>79:32</td><td class=br>+47</td>
<td class=bc>9 - 2 - 4</td>
<td class=br>20</td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=ir>5</td><td class=kt>Pa Plešák</td><td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kW>8:2</td>
<td class=kT>4:4</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>8:0</td>
<td class=kW>6:1</td>
<td class=kW>8:0</td>
<td class=kW>11:1</td>
<td class=br>76:31</td><td class=br>+45</td>
<td class=bc>8 - 4 - 3</td>
<td class=br>20</td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=ir>6</td><td class=kt>Vá Pikl</td><td class=kL>3:5</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>7:3</td>
<td class=kW>8:0</td>
<td class=br>59:35</td><td class=br>+24</td>
<td class=bc>8 - 4 - 3</td>
<td class=br>20</td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=ir>7</td><td class=kt>Ro Jež</td><td class=kL>0:6</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kL>3:9</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kW>7:3</td>
<td class=kW>6:2</td>
<td class=kW>9:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=br>54:37</td><td class=br>+17</td>
<td class=bc>9 - 2 - 4</td>
<td class=br>20</td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=ir>8</td><td class=kt>An Šrajer</td><td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kL>0:5</td>
<td class=kL>2:8</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kW>8:3</td>
<td class=kW>6:3</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=br>49:43</td><td class=br>+6</td>
<td class=bc>8 - 2 - 5</td>
<td class=br>18</td><td class=d>8.</td>
</tr><tr><td class=ir>J</td><td class=ir>9</td><td class=kt>Al Fiala</td><td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>7:0</td>
<td class=kW>5:0</td>
<td class=br>42:40</td><td class=br>+2</td>
<td class=bc>6 - 3 - 6</td>
<td class=br>15</td><td class=d>9.</td>
</tr><tr><td class=ir>J</td><td class=ir>10</td><td class=kt>Zb Froněk</td><td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kW>7:1</td>
<td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=br>40:42</td><td class=br>-2</td>
<td class=bc>6 - 2 - 7</td>
<td class=br>14</td><td class=d>10.</td>
</tr><tr><td class=ir>J</td><td class=ir>11</td><td class=kt>Zd Matoušek st.</td><td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>3:7</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kT>5:5</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=br>33:42</td><td class=br>-9</td>
<td class=bc>2 - 8 - 5</td>
<td class=br>12</td><td class=d>11.</td>
</tr><tr><td class=ir>J</td><td class=ir>12</td><td class=kt>Fr Marek</td><td class=kL>0:7</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kL>2:6</td>
<td class=kL>3:8</td>
<td class=kL>2:5</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=br>40:64</td><td class=br>-24</td>
<td class=bc>5 - 1 - 9</td>
<td class=br>11</td><td class=d>12.</td>
</tr><tr><td class=ir>J</td><td class=ir>13</td><td class=kt>Ji Petr</td><td class=kL>2:6</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kL>0:10</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>2:9</td>
<td class=kL>3:6</td>
<td class=kL>3:5</td>
<td class=kL>1:7</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=br>29:68</td><td class=br>-39</td>
<td class=bc>3 - 2 - 10</td>
<td class=br>8</td><td class=d>13.</td>
</tr><tr><td class=ir>J</td><td class=ir>14</td><td class=kt>To Kahoun st.</td><td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>3:7</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kW>6:2</td>
<td class=kT>5:5</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>0:0</td>
<td class=br>26:60</td><td class=br>-34</td>
<td class=bc>3 - 2 - 10</td>
<td class=br>8</td><td class=d>14.</td>
</tr><tr><td class=ir>J</td><td class=ir>15</td><td class=kt>Pe Sládek</td><td class=kL>1:3</td>
<td class=kL>2:8</td>
<td class=kL>1:6</td>
<td class=kL>1:11</td>
<td class=kL>0:8</td>
<td class=kL>3:7</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>0:7</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=br>23:69</td><td class=br>-46</td>
<td class=bc>1 - 3 - 11</td>
<td class=br>5</td><td class=d>15.</td>
</tr><tr><td class=ir>J</td><td class=ir>16</td><td class=kt>Mi Mareš st.</td><td class=kL>0:7</td>
<td class=kL>2:5</td>
<td class=kL>0:11</td>
<td class=kL>1:10</td>
<td class=kL>1:11</td>
<td class=kL>0:8</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kT>0:0</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=br>8:85</td><td class=br>-77</td>
<td class=bc>0 - 1 - 14</td>
<td class=br>1</td><td class=d>16.</td>
</tr></table></td></tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>An Šrajer</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Zb Froněk</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>11 : 1</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ji Petr</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Pe Sládek</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Al Fiala</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>An Šrajer</td><td class=bc>-</td><td class=blW>Zb Froněk</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ji Petr</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Pe Sládek</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Al Fiala</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Zb Froněk</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>An Šrajer</td><td class=bc>-</td><td class=bl>Ji Petr</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Pe Sládek</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Al Fiala</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>Ji Petr</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zb Froněk</td><td class=bc>-</td><td class=bl>Pe Sládek</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>An Šrajer</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Al Fiala</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ji Petr</td><td class=bc>-</td><td class=bl>Pe Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Zb Froněk</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>An Šrajer</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Al Fiala</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ji Petr</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Zb Froněk</td><td class=bc>-</td><td class=bl>Al Fiala</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>An Šrajer</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ji Petr</td><td class=bc>-</td><td class=blW>Al Fiala</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>Zb Froněk</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>An Šrajer</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ja Dryák</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Al Fiala</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ji Petr</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Zb Froněk</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>An Šrajer</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Ji Petr</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Zb Froněk</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>An Šrajer</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Al Fiala</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 11</tr></td>
<tr><td class=br>Ji Petr</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>An Šrajer</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Zb Froněk</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Fiala</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=blW>An Šrajer</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ji Petr</td><td class=bc>-</td><td class=blW>Zb Froněk</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Fiala</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>An Šrajer</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Zb Froněk</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Pe Sládek</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ji Petr</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>3 : 9</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Al Fiala</td><td class=bc>-</td><td class=blW>An Šrajer</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Zb Froněk</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Ji Petr</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>An Šrajer</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Zb Froněk</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Al Fiala</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Ji Petr</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Pe Sládek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>An Šrajer</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Zb Froněk</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ji Petr</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Al Fiala</td><td class=bc>-</td><td class=bl>Pe Sládek</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>An Šrajer</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Zb Froněk</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ji Petr</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Pe Sládek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Al Fiala</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Play-off<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><th colspan=11><font size="+1"><strong>Finále</strong></font></th></tr>
<tr><td class=br><b>Dryák Jan</b>&nbsp;&nbsp;</td>
<td class=bl>- Pikl Václav&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>6:3&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>2:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>Semifinále</strong></font></th></tr>
<tr><td class=ar><b>Dryák Jan</b>&nbsp;&nbsp;</td>
<td class=al>- Plešák Pavel&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 1&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>4:3 P&nbsp;&nbsp;</td>
<td class=al>1:3&nbsp;&nbsp;</td>
<td class=al>6:1&nbsp;&nbsp;</td>
<td class=al>6:4&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br>Matýsek Daniel&nbsp;&nbsp;</td>
<td class=bl><b>- Pikl Václav</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;0 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>1:2 P&nbsp;&nbsp;</td>
<td class=bl>3:4&nbsp;&nbsp;</td>
<td class=bl>1:2 P&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>O 3.místo</strong></font></th></tr>
<tr><td class=ar>Matýsek Daniel&nbsp;&nbsp;</td>
<td class=al><b>- Plešák Pavel</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;0 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:3 P&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>Čtvrtfinále</strong></font></th></tr>
<tr><td class=br><b>Dryák Jan</b>&nbsp;&nbsp;</td>
<td class=bl>- Šrajer Antonín&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>5:2&nbsp;&nbsp;</td>
<td class=bl>4:2&nbsp;&nbsp;</td>
<td class=bl>6:4&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Matýsek Daniel</b>&nbsp;&nbsp;</td>
<td class=al>- Jež Robert&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>5:1&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>1:2&nbsp;&nbsp;</td>
<td class=al>2:3 P&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br>Ševr Miloš&nbsp;&nbsp;</td>
<td class=bl><b>- Pikl Václav</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:6&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>4:3&nbsp;&nbsp;</td>
<td class=bl>0:1&nbsp;&nbsp;</td>
<td class=bl>2:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar>Šmíd David&nbsp;&nbsp;</td>
<td class=al><b>- Plešák Pavel</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;1 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:4&nbsp;&nbsp;</td>
<td class=al>1:2&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>2:6&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr></table></td></tr></table></div></p>
<hr>
<p class=v>Konečné pořadí turnaje<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>Z</th>
<th>+</th>
<th>=</th>
<th>-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>B</th>
<th></th>
<th>&nbsp;</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al>Dryák Jan</td>
<td class=al>Big Band</td>
<td class=ar>25</td>
<td class=ar>20</td>
<td class=ar>3</td>
<td class=ar>2</td>
<td class=ar>115</td>
<td class=al>: 50</td>
<td class=ar>43</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>2.</td>
<td class=bl>Pikl Václav</td>
<td class=bl>THC Stiga Elites</td>
<td class=br>26</td>
<td class=br>14</td>
<td class=br>4</td>
<td class=br>8</td>
<td class=br>86</td>
<td class=bl>: 64</td>
<td class=br>32</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>3.</td>
<td class=al>Plešák Pavel</td>
<td class=al>APP Gladiators Plzeň</td>
<td class=ar>26</td>
<td class=ar>15</td>
<td class=ar>4</td>
<td class=ar>7</td>
<td class=ar>110</td>
<td class=al>: 63</td>
<td class=ar>34</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>4.</td>
<td class=bl>Matýsek Daniel</td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>26</td>
<td class=br>13</td>
<td class=br>2</td>
<td class=br>11</td>
<td class=br>76</td>
<td class=bl>: 58</td>
<td class=br>28</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>5.</td>
<td class=al>Šrajer Antonín</td>
<td class=al>THC Stiga Elites</td>
<td class=ar>18</td>
<td class=ar>8</td>
<td class=ar>2</td>
<td class=ar>8</td>
<td class=ar>57</td>
<td class=al>: 58</td>
<td class=ar>18</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>6.</td>
<td class=bl>Jež Robert</td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>20</td>
<td class=br>11</td>
<td class=br>2</td>
<td class=br>7</td>
<td class=br>63</td>
<td class=bl>: 50</td>
<td class=br>24</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>7.</td>
<td class=al>Ševr Miloš</td>
<td class=al>THC Stiga Elites</td>
<td class=ar>20</td>
<td class=ar>11</td>
<td class=ar>3</td>
<td class=ar>6</td>
<td class=ar>71</td>
<td class=al>: 48</td>
<td class=ar>25</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>8.</td>
<td class=bl>Šmíd David</td>
<td class=bl>THC Stiga Svitavy 93</td>
<td class=br>19</td>
<td class=br>10</td>
<td class=br>2</td>
<td class=br>7</td>
<td class=br>88</td>
<td class=bl>: 46</td>
<td class=br>22</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>9.</td>
<td class=al>Fiala Aleš</td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>15</td>
<td class=ar>6</td>
<td class=ar>3</td>
<td class=ar>6</td>
<td class=ar>42</td>
<td class=al>: 40</td>
<td class=ar>15</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>10.</td>
<td class=bl>Froněk Zbyněk</td>
<td class=bl>SHC Cheb</td>
<td class=br>15</td>
<td class=br>6</td>
<td class=br>2</td>
<td class=br>7</td>
<td class=br>40</td>
<td class=bl>: 42</td>
<td class=br>14</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>11.</td>
<td class=al>Matoušek st. Zdeněk</td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>15</td>
<td class=ar>2</td>
<td class=ar>8</td>
<td class=ar>5</td>
<td class=ar>33</td>
<td class=al>: 42</td>
<td class=ar>12</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>12.</td>
<td class=bl>Marek František</td>
<td class=bl>BSE United</td>
<td class=br>15</td>
<td class=br>5</td>
<td class=br>1</td>
<td class=br>9</td>
<td class=br>40</td>
<td class=bl>: 64</td>
<td class=br>11</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>13.</td>
<td class=al>Petr Jindřich</td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>15</td>
<td class=ar>3</td>
<td class=ar>2</td>
<td class=ar>10</td>
<td class=ar>29</td>
<td class=al>: 68</td>
<td class=ar>8</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>14.</td>
<td class=bl>Kahoun st. Tomáš</td>
<td class=bl>BSE United</td>
<td class=br>15</td>
<td class=br>3</td>
<td class=br>2</td>
<td class=br>10</td>
<td class=br>26</td>
<td class=bl>: 60</td>
<td class=br>8</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>15.</td>
<td class=al>Sládek Petr</td>
<td class=al>APP Gladiators Plzeň</td>
<td class=ar>15</td>
<td class=ar>1</td>
<td class=ar>3</td>
<td class=ar>11</td>
<td class=ar>23</td>
<td class=al>: 69</td>
<td class=ar>5</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>16.</td>
<td class=bl>Mareš st. Miroslav</td>
<td class=bl>BSE United</td>
<td class=br>15</td>
<td class=br>0</td>
<td class=br>1</td>
<td class=br>14</td>
<td class=br>8</td>
<td class=bl>: 85</td>
<td class=br>1</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr></table></td></tr></table></div></p>


</body></html>