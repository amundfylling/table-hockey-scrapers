<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/pohar13.aspx">U13</a>
&nbsp;<a href="../data/pohar55.aspx">55+</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co/index.aspx">Czech Open, 19. duben 2025</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Základní skupiny (Basic groups)</a><br>
<a href="#final">Výkonnostní skupiny (Final groups)</a><br>
<a name="basic"><p class=vm>Základní skupiny (Basic groups)</p></a>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ra Kalninš</td><td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>7:3</td>
<td class=kL>4:5</td>
<td class=kT>5:5</td>
<td class=kW>9:2</td>
<td class=kW>10:2</td>
<td class=kT>1:1</td>
<td class=kW>8:1</td>
<td class=kW>10:3</td>
<td class=kW>6:4</td>
<td class=kW>9:4</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>12:1</td>
<td class=br>114:39</td><td class=br>+75</td>
<td class=bc>14 - 2 - 1</td>
<td class=br><strong>30</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>An Kimberg</td><td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=br>60:33</td><td class=br>+27</td>
<td class=bc>11 - 4 - 2</td>
<td class=br><strong>26</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ji Chylík ml.</td><td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>2:6</td>
<td class=kW>6:0</td>
<td class=kL>1:4</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>9:1</td>
<td class=kW>7:3</td>
<td class=br>80:33</td><td class=br>+47</td>
<td class=bc>13 - 0 - 4</td>
<td class=br><strong>26</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Da Matýsek</td><td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>8:0</td>
<td class=br>55:27</td><td class=br>+28</td>
<td class=bc>11 - 3 - 3</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Pa Plešák</td><td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kW>6:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kL>2:6</td>
<td class=kL>5:8</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>9:3</td>
<td class=kW>6:0</td>
<td class=kW>13:0</td>
<td class=br>72:43</td><td class=br>+29</td>
<td class=bc>10 - 3 - 4</td>
<td class=br><strong>23</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Mi Kubica</td><td class=kL>3:7</td>
<td class=kT>2:2</td>
<td class=kL>0:6</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=br>60:36</td><td class=br>+24</td>
<td class=bc>10 - 3 - 4</td>
<td class=br><strong>23</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ja Matýsek</td><td class=kW>5:4</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kW>5:1</td>
<td class=kL>0:3</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>9:0</td>
<td class=br>54:26</td><td class=br>+28</td>
<td class=bc>9 - 4 - 4</td>
<td class=br><strong>22</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ar Tseluiko</td><td class=kT>5:5</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>8:1</td>
<td class=kW>3:0</td>
<td class=kW>9:1</td>
<td class=kW>12:0</td>
<td class=br>68:43</td><td class=br>+25</td>
<td class=bc>9 - 2 - 6</td>
<td class=br><strong>20</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Pe Holub</td><td class=kL>2:9</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kT>0:0</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kL>0:2</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>6:4</td>
<td class=kW>5:0</td>
<td class=br>54:49</td><td class=br>+5</td>
<td class=bc>9 - 1 - 7</td>
<td class=br><strong>19</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>Vl Kraus</td><td class=kL>2:10</td>
<td class=kW>5:2</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>8:5</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>9:0</td>
<td class=kW>6:0</td>
<td class=br>55:49</td><td class=br>+6</td>
<td class=bc>9 - 0 - 8</td>
<td class=br><strong>18</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Kr Zemnickis</td><td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kL>0:5</td>
<td class=kL>2:6</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>9:0</td>
<td class=br>41:37</td><td class=br>+4</td>
<td class=bc>6 - 4 - 7</td>
<td class=br><strong>16</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>On Gruncl</td><td class=kL>1:8</td>
<td class=kT>3:3</td>
<td class=kL>1:7</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>0:6</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=br>38:63</td><td class=br>-25</td>
<td class=bc>7 - 2 - 8</td>
<td class=br><strong>16</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Ka Hudec</td><td class=kL>3:10</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>11:0</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=br>47:47</td><td class=br>0</td>
<td class=bc>6 - 2 - 9</td>
<td class=br><strong>14</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>My Razkevich</td><td class=kL>4:6</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>8:0</td>
<td class=br>41:55</td><td class=br>-14</td>
<td class=bc>5 - 1 - 11</td>
<td class=br><strong>11</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>Ol Tabara</td><td class=kL>4:9</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>1:8</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=br>31:65</td><td class=br>-34</td>
<td class=bc>3 - 1 - 13</td>
<td class=br><strong>7</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>C</td><td class=d>16.</td><td class=kt>Vo Kasnar</td><td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>3:9</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>2:6</td>
<td class=kL>3:5</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>0:11</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=br>22:75</td><td class=br>-53</td>
<td class=bc>2 - 1 - 14</td>
<td class=br><strong>5</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Er Bernhauser</td><td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>1:9</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>1:9</td>
<td class=kL>4:6</td>
<td class=kL>0:9</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>7:0</td>
<td class=br>32:84</td><td class=br>-52</td>
<td class=bc>2 - 1 - 14</td>
<td class=br><strong>5</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>D</td><td class=d>18.</td><td class=kt>Ji Kubáč</td><td class=kL>1:12</td>
<td class=kL>0:6</td>
<td class=kL>3:7</td>
<td class=kL>0:8</td>
<td class=kL>0:13</td>
<td class=kL>0:6</td>
<td class=kL>0:9</td>
<td class=kL>0:12</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>0:9</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>0:8</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>0:7</td>
<td class=kx>*</td>
<td class=br>7:127</td><td class=br>-120</td>
<td class=bc>0 - 0 - 17</td>
<td class=br><strong>0</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Razkevich Mykhailo</td><td class=bc>-</td><td class=blW>Tseluiko Artem</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Tabara Oliver</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Hudec Karol</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Zemnickis Krisjanis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kasnar Vojtěch</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Holub Petr</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Kubáč Jiří</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Tseluiko Artem</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Bernhauser Erik</td><td class=bc>-</td><td class=bl>Tabara Oliver</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Razkevich Mykhailo</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Matýsek Jakub</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Hudec Karol</td><td class=bc>-</td><td class=blW>Zemnickis Krisjanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Kasnar Vojtěch</td><td class=bc>-</td><td class=bl>Kubáč Jiří</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Tseluiko Artem</td><td class=bc>-</td><td class=bl>Tabara Oliver</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Razkevich Mykhailo</td><td class=bc>-</td><td class=blW>Zemnickis Krisjanis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Hudec Karol</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Kubáč Jiří</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>10 : 2</tr></td>
<tr><td class=br>Kasnar Vojtěch</td><td class=bc>-</td><td class=blW>Holub Petr</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Tabara Oliver</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Tseluiko Artem</td><td class=bc>-</td><td class=bl>Matýsek Jakub</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Zemnickis Krisjanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Razkevich Mykhailo</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Kubáč Jiří</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Hudec Karol</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Kasnar Vojtěch</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Tabara Oliver</td><td class=bc>-</td><td class=bl>Zemnickis Krisjanis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Tseluiko Artem</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Bernhauser Erik</td><td class=bc>-</td><td class=bl>Kubáč Jiří</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Razkevich Mykhailo</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Hudec Karol</td><td class=bc>-</td><td class=bl>Kasnar Vojtěch</td><td class=bc>11 : 0</tr></td>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=blW>Kalninš Rainers</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Matýsek Jakub</td><td class=bc>-</td><td class=blW>Zemnickis Krisjanis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Tabara Oliver</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Tseluiko Artem</td><td class=bc>-</td><td class=bl>Kubáč Jiří</td><td class=bc>12 : 0</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>5 : 8</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Holub Petr</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Razkevich Mykhailo</td><td class=bc>-</td><td class=bl>Kasnar Vojtěch</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=blW>Kalninš Rainers</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Hudec Karol</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Zemnickis Krisjanis</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Kubáč Jiří</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Tabara Oliver</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Tseluiko Artem</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Kasnar Vojtěch</td><td class=bc>9 : 3</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Kalninš Rainers</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Razkevich Mykhailo</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Hudec Karol</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Zemnickis Krisjanis</td><td class=bc>-</td><td class=bl>Kubáč Jiří</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Holub Petr</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Tabara Oliver</td><td class=bc>-</td><td class=bl>Kasnar Vojtěch</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Tseluiko Artem</td><td class=bc>-</td><td class=bl>Kalninš Rainers</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Hudec Karol</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Razkevich Mykhailo</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Kubáč Jiří</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zemnickis Krisjanis</td><td class=bc>-</td><td class=blW>Holub Petr</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Kasnar Vojtěch</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Kalninš Rainers</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Tabara Oliver</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Tseluiko Artem</td><td class=bc>-</td><td class=bl>Hudec Karol</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Razkevich Mykhailo</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Kubáč Jiří</td><td class=bc>-</td><td class=blW>Holub Petr</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Kasnar Vojtěch</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Kalninš Rainers</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Zemnickis Krisjanis</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Hudec Karol</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Tabara Oliver</td><td class=bc>-</td><td class=blW>Razkevich Mykhailo</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Tseluiko Artem</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Kasnar Vojtěch</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Kubáč Jiří</td><td class=bc>-</td><td class=blW>Kalninš Rainers</td><td class=bc>1 : 12</tr></td>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Hudec Karol</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zemnickis Krisjanis</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Matýsek Jakub</td><td class=bc>-</td><td class=blW>Razkevich Mykhailo</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Tabara Oliver</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Tseluiko Artem</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Kalninš Rainers</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kubáč Jiří</td><td class=bc>-</td><td class=blW>Hudec Karol</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Razkevich Mykhailo</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Zemnickis Krisjanis</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Tseluiko Artem</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Tabara Oliver</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Kasnar Vojtěch</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Hudec Karol</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kubáč Jiří</td><td class=bc>-</td><td class=blW>Razkevich Mykhailo</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Zemnickis Krisjanis</td><td class=bc>-</td><td class=blW>Tseluiko Artem</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Tabara Oliver</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Hudec Karol</td><td class=bc>10 : 3</tr></td>
<tr><td class=br>Kasnar Vojtěch</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Holub Petr</td><td class=bc>-</td><td class=bl>Razkevich Mykhailo</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Kubáč Jiří</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>0 : 13</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Tseluiko Artem</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Tabara Oliver</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Zemnickis Krisjanis</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Matýsek Jakub</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Razkevich Mykhailo</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Kasnar Vojtěch</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Holub Petr</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Tseluiko Artem</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kubáč Jiří</td><td class=bc>-</td><td class=blW>Tabara Oliver</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Matýsek Jakub</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Zemnickis Krisjanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Hudec Karol</td><td class=bc>-</td><td class=bl>Razkevich Mykhailo</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Kasnar Vojtěch</td><td class=bc>-</td><td class=blW>Tseluiko Artem</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Holub Petr</td><td class=bc>-</td><td class=bl>Tabara Oliver</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kubáč Jiří</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Zemnickis Krisjanis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Hudec Karol</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Tseluiko Artem</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Tabara Oliver</td><td class=bc>9 : 4</tr></td>
<tr><td class=br>Kasnar Vojtěch</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=bl>Matýsek Jakub</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Zemnickis Krisjanis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kubáč Jiří</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Razkevich Mykhailo</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Tseluiko Artem</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Hudec Karol</td><td class=bc>-</td><td class=bl>Tabara Oliver</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Kalninš Rainers</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Kasnar Vojtěch</td><td class=bc>-</td><td class=blW>Zemnickis Krisjanis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kubáč Jiří</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Gi Lasmanis</td><td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>6:5</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kT>5:5</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=br>79:32</td><td class=br>+47</td>
<td class=bc>14 - 2 - 1</td>
<td class=br><strong>30</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ev Matantsev</td><td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>7:1</td>
<td class=kT>5:5</td>
<td class=kW>9:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>8:2</td>
<td class=kW>11:0</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>7:0</td>
<td class=kW>7:1</td>
<td class=br>91:35</td><td class=br>+56</td>
<td class=bc>13 - 2 - 2</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>An Božič</td><td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kL>0:6</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=br>68:33</td><td class=br>+35</td>
<td class=bc>13 - 1 - 3</td>
<td class=br><strong>27</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ma Ležík</td><td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>8:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>7:1</td>
<td class=kW>6:1</td>
<td class=kW>7:4</td>
<td class=kW>12:0</td>
<td class=br>77:34</td><td class=br>+43</td>
<td class=bc>13 - 0 - 4</td>
<td class=br><strong>26</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Vi Henttonen</td><td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>8:2</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kL>4:7</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>11:0</td>
<td class=br>72:33</td><td class=br>+39</td>
<td class=bc>11 - 2 - 4</td>
<td class=br><strong>24</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Mi Touš</td><td class=kL>5:6</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>9:0</td>
<td class=br>65:36</td><td class=br>+29</td>
<td class=bc>11 - 1 - 5</td>
<td class=br><strong>23</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ti Dion</td><td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>8:3</td>
<td class=kW>6:0</td>
<td class=br>59:41</td><td class=br>+18</td>
<td class=bc>10 - 1 - 6</td>
<td class=br><strong>21</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ra Pommerenke</td><td class=kL>1:6</td>
<td class=kT>5:5</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=br>43:35</td><td class=br>+8</td>
<td class=bc>8 - 4 - 5</td>
<td class=br><strong>20</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Ne Škrlep</td><td class=kT>5:5</td>
<td class=kL>2:9</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>2:8</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kL>4:6</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>10:1</td>
<td class=kW>8:1</td>
<td class=br>63:51</td><td class=br>+12</td>
<td class=bc>8 - 3 - 6</td>
<td class=br><strong>19</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>Bi Karlsson</td><td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>8:1</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=kW>7:0</td>
<td class=br>53:44</td><td class=br>+9</td>
<td class=bc>8 - 1 - 8</td>
<td class=br><strong>17</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>An Gripp</td><td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>1:8</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>7:2</td>
<td class=br>41:62</td><td class=br>-21</td>
<td class=bc>6 - 2 - 9</td>
<td class=br><strong>14</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>Ji Vácha</td><td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kW>7:4</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kW>8:3</td>
<td class=kW>6:2</td>
<td class=kW>8:1</td>
<td class=br>58:53</td><td class=br>+5</td>
<td class=bc>7 - 0 - 10</td>
<td class=br><strong>14</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Lu Holub</td><td class=kL>3:6</td>
<td class=kL>2:8</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kL>3:4</td>
<td class=kW>6:1</td>
<td class=br>38:51</td><td class=br>-13</td>
<td class=bc>6 - 0 - 11</td>
<td class=br><strong>12</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Pa Pohořalý</td><td class=kL>1:4</td>
<td class=kL>0:11</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kW>6:4</td>
<td class=kL>1:8</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=br>37:66</td><td class=br>-29</td>
<td class=bc>5 - 2 - 10</td>
<td class=br><strong>12</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>Jo Sedláček</td><td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>0:1</td>
<td class=kL>0:6</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=br>36:61</td><td class=br>-25</td>
<td class=bc>4 - 2 - 11</td>
<td class=br><strong>10</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>C</td><td class=d>16.</td><td class=kt>Pe Klazar</td><td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>3:8</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>26:73</td><td class=br>-47</td>
<td class=bc>2 - 1 - 14</td>
<td class=br><strong>5</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Ví Pernica</td><td class=kL>1:6</td>
<td class=kL>0:7</td>
<td class=kL>2:5</td>
<td class=kL>4:7</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>3:8</td>
<td class=kL>2:4</td>
<td class=kL>1:10</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>9:0</td>
<td class=br>39:91</td><td class=br>-52</td>
<td class=bc>2 - 0 - 15</td>
<td class=br><strong>4</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>D</td><td class=d>18.</td><td class=kt>Ji Pošík</td><td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kL>1:7</td>
<td class=kL>0:12</td>
<td class=kL>0:11</td>
<td class=kL>0:9</td>
<td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kL>1:8</td>
<td class=kL>0:7</td>
<td class=kL>2:7</td>
<td class=kL>1:8</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>0:9</td>
<td class=kx>*</td>
<td class=br>9:123</td><td class=br>-114</td>
<td class=bc>0 - 0 - 17</td>
<td class=br><strong>0</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Dion Till</td><td class=bc>-</td><td class=blW>Pommerenke Ralph</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Gripp Annika</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Sedláček Josef</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Škrlep Nejc</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Karlsson Bie</td><td class=bc>-</td><td class=bl>Pohořalý Pavel</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ležík Matěj</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Holub Lukáš</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Dion Till</td><td class=bc>-</td><td class=bl>Sedláček Josef</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Gripp Annika</td><td class=bc>-</td><td class=bl>Škrlep Nejc</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Pohořalý Pavel</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Klazar Petr</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Karlsson Bie</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Ležík Matěj</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Pommerenke Ralph</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Sedláček Josef</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Škrlep Nejc</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Dion Till</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Gripp Annika</td><td class=bc>-</td><td class=bl>Pohořalý Pavel</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Božič Anže</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Karlsson Bie</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Sedláček Josef</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=blW>Škrlep Nejc</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Holub Lukáš</td><td class=bc>-</td><td class=bl>Pohořalý Pavel</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Dion Till</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Gripp Annika</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Božič Anže</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Karlsson Bie</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Sedláček Josef</td><td class=bc>-</td><td class=blW>Škrlep Nejc</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Pommerenke Ralph</td><td class=bc>-</td><td class=bl>Pohořalý Pavel</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Dion Till</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Gripp Annika</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Karlsson Bie</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Škrlep Nejc</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Sedláček Josef</td><td class=bc>-</td><td class=bl>Pohořalý Pavel</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=bl>Matantsev Evgeniy</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Dion Till</td><td class=bc>-</td><td class=bl>Karlsson Bie</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Gripp Annika</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Božič Anže</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Pohořalý Pavel</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Škrlep Nejc</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Sedláček Josef</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>0 : 12</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=blW>Karlsson Bie</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Holub Lukáš</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Dion Till</td><td class=bc>-</td><td class=blW>Božič Anže</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Gripp Annika</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Pohořalý Pavel</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Matantsev Evgeniy</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Škrlep Nejc</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Sedláček Josef</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Karlsson Bie</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=blW>Božič Anže</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Dion Till</td><td class=bc>-</td><td class=bl>Gripp Annika</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Pohořalý Pavel</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Škrlep Nejc</td><td class=bc>-</td><td class=bl>Karlsson Bie</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Sedláček Josef</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Božič Anže</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=blW>Gripp Annika</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Dion Till</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Karlsson Bie</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Pohořalý Pavel</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Božič Anže</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Škrlep Nejc</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Sedláček Josef</td><td class=bc>-</td><td class=bl>Gripp Annika</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Dion Till</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=blW>Holub Lukáš</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Karlsson Bie</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Božič Anže</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pohořalý Pavel</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Gripp Annika</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Škrlep Nejc</td><td class=bc>-</td><td class=bl>Dion Till</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Sedláček Josef</td><td class=bc>-</td><td class=blW>Holub Lukáš</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ležík Matěj</td><td class=bc>-</td><td class=blW>Božič Anže</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Gripp Annika</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Pohořalý Pavel</td><td class=bc>-</td><td class=blW>Dion Till</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Holub Lukáš</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Škrlep Nejc</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sedláček Josef</td><td class=bc>-</td><td class=blW>Pommerenke Ralph</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Karlsson Bie</td><td class=bc>-</td><td class=blW>Božič Anže</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Gripp Annika</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Dion Till</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Holub Lukáš</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pohořalý Pavel</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Škrlep Nejc</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Sedláček Josef</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Karlsson Bie</td><td class=bc>-</td><td class=bl>Gripp Annika</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Dion Till</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Holub Lukáš</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Pommerenke Ralph</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pohořalý Pavel</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Sedláček Josef</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Škrlep Nejc</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Gripp Annika</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Dion Till</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Karlsson Bie</td><td class=bc>-</td><td class=bl>Holub Lukáš</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ležík Matěj</td><td class=bc>-</td><td class=blW>Pommerenke Ralph</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Sedláček Josef</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Pohořalý Pavel</td><td class=bc>-</td><td class=bl>Škrlep Nejc</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Dion Till</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Holub Lukáš</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Karlsson Bie</td><td class=bc>-</td><td class=blW>Pommerenke Ralph</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Sedláček Josef</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Škrlep Nejc</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Pohořalý Pavel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Gripp Annika</td><td class=bc>-</td><td class=bl>Holub Lukáš</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Božič Anže</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Klazar Petr</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Karlsson Bie</td><td class=bc>-</td><td class=bl>Sedláček Josef</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Škrlep Nejc</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Pohořalý Pavel</td><td class=bc>11 : 0</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Dion Till</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Gripp Annika</td><td class=bc>-</td><td class=blW>Pommerenke Ralph</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>11 : 0</tr></td>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Sedláček Josef</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Škrlep Nejc</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Karlsson Bie</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Pohořalý Pavel</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 3</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ed Caics</td><td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>7:4</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>9:1</td>
<td class=br>79:29</td><td class=br>+50</td>
<td class=bc>14 - 3 - 0</td>
<td class=br><strong>31</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Kr Naglis</td><td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>13:1</td>
<td class=kW>5:0</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>7:4</td>
<td class=kW>12:2</td>
<td class=br>87:39</td><td class=br>+48</td>
<td class=bc>13 - 2 - 2</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Mi Boštík</td><td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kW>6:4</td>
<td class=kW>7:1</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>9:3</td>
<td class=br>71:34</td><td class=br>+37</td>
<td class=bc>13 - 2 - 2</td>
<td class=br><strong>28</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Em Larsson</td><td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kW>9:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>10:2</td>
<td class=br>66:35</td><td class=br>+31</td>
<td class=bc>10 - 5 - 2</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Da Šmíd</td><td class=kL>4:7</td>
<td class=kW>5:3</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=kL>3:4</td>
<td class=kT>5:5</td>
<td class=kW>6:0</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>8:1</td>
<td class=br>66:37</td><td class=br>+29</td>
<td class=bc>10 - 2 - 5</td>
<td class=br><strong>22</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ro Jež</td><td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kW>5:4</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>8:2</td>
<td class=br>46:36</td><td class=br>+10</td>
<td class=bc>10 - 1 - 6</td>
<td class=br><strong>21</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Da Dvořáček</td><td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kL>0:2</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>10:3</td>
<td class=br>61:45</td><td class=br>+16</td>
<td class=bc>8 - 4 - 5</td>
<td class=br><strong>20</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Kr Herold</td><td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>4:5</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>8:1</td>
<td class=br>58:30</td><td class=br>+28</td>
<td class=bc>9 - 2 - 6</td>
<td class=br><strong>20</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Zy Remeika</td><td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>9:1</td>
<td class=br>53:34</td><td class=br>+19</td>
<td class=bc>9 - 1 - 7</td>
<td class=br><strong>19</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>My Verbytskyy</td><td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>3:6</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=br>32:43</td><td class=br>-11</td>
<td class=bc>5 - 5 - 7</td>
<td class=br><strong>15</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Li Kondrashevskyi</td><td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>1:9</td>
<td class=kL>0:8</td>
<td class=kL>4:5</td>
<td class=kL>3:6</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>11:2</td>
<td class=br>52:63</td><td class=br>-11</td>
<td class=bc>5 - 4 - 8</td>
<td class=br><strong>14</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>Jo Kůrka</td><td class=kL>0:4</td>
<td class=kL>1:13</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=br>47:66</td><td class=br>-19</td>
<td class=bc>6 - 1 - 10</td>
<td class=br><strong>13</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Fr Marek</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kT>5:5</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>2:5</td>
<td class=kW>3:0</td>
<td class=kW>6:3</td>
<td class=kW>8:1</td>
<td class=br>41:59</td><td class=br>-18</td>
<td class=bc>5 - 2 - 10</td>
<td class=br><strong>12</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ad Herold</td><td class=kL>0:5</td>
<td class=kL>3:6</td>
<td class=kL>4:6</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>0:1</td>
<td class=kW>2:0</td>
<td class=kL>0:6</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>8:2</td>
<td class=kL>0:4</td>
<td class=kW>6:0</td>
<td class=br>38:51</td><td class=br>-13</td>
<td class=bc>5 - 2 - 10</td>
<td class=br><strong>12</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>Ma Moravec</td><td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>1:7</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=br>34:59</td><td class=br>-25</td>
<td class=bc>5 - 1 - 11</td>
<td class=br><strong>11</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>C</td><td class=d>16.</td><td class=kt>Hy Nechutný</td><td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kL>2:8</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>8:3</td>
<td class=br>28:66</td><td class=br>-38</td>
<td class=bc>4 - 1 - 12</td>
<td class=br><strong>9</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Gu Gripp</td><td class=kL>2:6</td>
<td class=kL>4:7</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kL>3:6</td>
<td class=kW>4:0</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>8:1</td>
<td class=br>35:60</td><td class=br>-25</td>
<td class=bc>2 - 2 - 13</td>
<td class=br><strong>6</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>D</td><td class=d>18.</td><td class=kt>Ví Nádvorník</td><td class=kL>1:9</td>
<td class=kL>2:12</td>
<td class=kL>3:9</td>
<td class=kL>2:10</td>
<td class=kL>1:8</td>
<td class=kL>2:8</td>
<td class=kL>3:10</td>
<td class=kL>1:8</td>
<td class=kL>1:9</td>
<td class=kL>1:2</td>
<td class=kL>2:11</td>
<td class=kL>2:5</td>
<td class=kL>1:8</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kL>3:8</td>
<td class=kL>1:8</td>
<td class=kx>*</td>
<td class=br>28:136</td><td class=br>-108</td>
<td class=bc>0 - 0 - 17</td>
<td class=br><strong>0</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=blW>Verbytskyy Mykola</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Gripp Gunnar</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Herold Adam</td><td class=bc>-</td><td class=blW>Šmíd David</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Nádvorník Vít</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Boštík Michal</td><td class=bc>-</td><td class=blW>Marek František</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kůrka Josef</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Šmíd David</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Gripp Gunnar</td><td class=bc>-</td><td class=bl>Nádvorník Vít</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Herold Adam</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Kůrka Josef</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=blW>Šmíd David</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Nádvorník Vít</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Gripp Gunnar</td><td class=bc>-</td><td class=blW>Marek František</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Herold Adam</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Kůrka Josef</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Šmíd David</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Nádvorník Vít</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Gripp Gunnar</td><td class=bc>-</td><td class=blW>Kůrka Josef</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Herold Adam</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Šmíd David</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Nádvorník Vít</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Kůrka Josef</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=bl>Boštík Michal</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Gripp Gunnar</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Herold Adam</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Šmíd David</td><td class=bc>-</td><td class=bl>Nádvorník Vít</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Kůrka Josef</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Caics Edgars</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Gripp Gunnar</td><td class=bc>-</td><td class=bl>Herold Adam</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Nádvorník Vít</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=blW>Kůrka Josef</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Boštík Michal</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Herold Adam</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=bl>Gripp Gunnar</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Nádvorník Vít</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>2 : 10</tr></td>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=blW>Kůrka Josef</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Herold Adam</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=bl>Gripp Gunnar</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Kůrka Josef</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Nádvorník Vít</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>3 : 9</tr></td>
<tr><td class=brW>Šmíd David</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=blW>Herold Adam</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Gripp Gunnar</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=bl>Caics Edgars</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Nádvorník Vít</td><td class=bc>-</td><td class=blW>Herold Adam</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Šmíd David</td><td class=bc>-</td><td class=bl>Gripp Gunnar</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Kondrashevskyi Liubomyr</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Kůrka Josef</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Marek František</td><td class=bc>-</td><td class=bl>Herold Adam</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Gripp Gunnar</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Nádvorník Vít</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>3 : 10</tr></td>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Kondrashevskyi Liubomyr</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kůrka Josef</td><td class=bc>-</td><td class=blW>Herold Adam</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Gripp Gunnar</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Nádvorník Vít</td><td class=bc>-</td><td class=blW>Kondrashevskyi Liubomyr</td><td class=bc>2 : 11</tr></td>
<tr><td class=brW>Šmíd David</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Herold Adam</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Gripp Gunnar</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kůrka Josef</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=bl>Kondrashevskyi Liubomyr</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Nádvorník Vít</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>2 : 12</tr></td>
<tr><td class=brW>Šmíd David</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Gripp Gunnar</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Boštík Michal</td><td class=bc>-</td><td class=bl>Caics Edgars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kůrka Josef</td><td class=bc>-</td><td class=blW>Kondrashevskyi Liubomyr</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Nádvorník Vít</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Herold Adam</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Kondrashevskyi Liubomyr</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kůrka Josef</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>1 : 13</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Marek František</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Šmíd David</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Nádvorník Vít</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Gripp Gunnar</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Herold Adam</td><td class=bc>-</td><td class=bl>Kondrashevskyi Liubomyr</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kůrka Josef</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=bl>Šmíd David</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Marek František</td><td class=bc>-</td><td class=bl>Nádvorník Vít</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Kondrashevskyi Liubomyr</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Gripp Gunnar</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Herold Adam</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Šmíd David</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kůrka Josef</td><td class=bc>-</td><td class=bl>Nádvorník Vít</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Gripp Gunnar</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Herold Adam</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Šmíd David</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Nádvorník Vít</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Kůrka Josef</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 4</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ed Nilsson</td><td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>7:3</td>
<td class=kW>6:1</td>
<td class=kW>10:2</td>
<td class=kW>10:1</td>
<td class=kW>8:1</td>
<td class=kW>11:3</td>
<td class=kW>7:0</td>
<td class=kW>7:0</td>
<td class=kW>5:0</td>
<td class=kW>18:0</td>
<td class=br>118:22</td><td class=br>+96</td>
<td class=bc>15 - 0 - 2</td>
<td class=br><strong>30</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Je Rekis</td><td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>7:3</td>
<td class=kW>5:4</td>
<td class=kW>16:0</td>
<td class=br>88:35</td><td class=br>+53</td>
<td class=bc>13 - 1 - 3</td>
<td class=br><strong>27</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Mi Saulitis</td><td class=kL>2:5</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kL>4:6</td>
<td class=kW>6:4</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=br>65:38</td><td class=br>+27</td>
<td class=bc>13 - 1 - 3</td>
<td class=br><strong>27</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Gu Hermansson</td><td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kL>4:6</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kL>1:4</td>
<td class=kW>8:0</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=br>73:28</td><td class=br>+45</td>
<td class=bc>13 - 1 - 3</td>
<td class=br><strong>27</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Si Thomas</td><td class=kL>1:6</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>7:0</td>
<td class=br>63:37</td><td class=br>+26</td>
<td class=bc>12 - 1 - 4</td>
<td class=br><strong>25</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Pe Fuchs</td><td class=kL>0:6</td>
<td class=kW>4:3</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kL>0:2</td>
<td class=kW>8:3</td>
<td class=br>51:35</td><td class=br>+16</td>
<td class=bc>11 - 2 - 4</td>
<td class=br><strong>24</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>To Kahoun ml.</td><td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kW>6:4</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kT>5:5</td>
<td class=kW>7:2</td>
<td class=br>54:40</td><td class=br>+14</td>
<td class=bc>11 - 2 - 4</td>
<td class=br><strong>24</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Vo Kraus</td><td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kL>4:6</td>
<td class=kW>6:4</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>6:6</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>8:0</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=kW>9:2</td>
<td class=br>76:50</td><td class=br>+26</td>
<td class=bc>8 - 3 - 6</td>
<td class=br><strong>19</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Vá Pikl</td><td class=kL>3:7</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kT>6:6</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>6:0</td>
<td class=kW>5:2</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kW>5:4</td>
<td class=kT>1:1</td>
<td class=kW>8:2</td>
<td class=br>45:47</td><td class=br>-2</td>
<td class=bc>7 - 3 - 7</td>
<td class=br><strong>17</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>Ad Kopřiva</td><td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>7:0</td>
<td class=kW>6:3</td>
<td class=kW>9:0</td>
<td class=br>54:38</td><td class=br>+16</td>
<td class=bc>7 - 3 - 7</td>
<td class=br><strong>17</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ja Janouškovec</td><td class=kL>2:10</td>
<td class=kL>0:8</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kL>0:2</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>7:0</td>
<td class=kW>14:0</td>
<td class=br>57:64</td><td class=br>-7</td>
<td class=bc>5 - 2 - 10</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>Os Tabara</td><td class=kL>1:10</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=br>32:55</td><td class=br>-23</td>
<td class=bc>5 - 2 - 10</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Lu Příhoda</td><td class=kL>1:8</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>0:8</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=br>37:68</td><td class=br>-31</td>
<td class=bc>4 - 2 - 11</td>
<td class=br><strong>10</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Gi Remeika</td><td class=kL>3:11</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kW>3:0</td>
<td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>8:1</td>
<td class=br>37:59</td><td class=br>-22</td>
<td class=bc>4 - 1 - 12</td>
<td class=br><strong>9</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>Ra Hrnčíř</td><td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:8</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>0:8</td>
<td class=kW>1:0</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=br>23:63</td><td class=br>-40</td>
<td class=bc>4 - 1 - 12</td>
<td class=br><strong>9</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>C</td><td class=d>16.</td><td class=kt>Da Jerabek</td><td class=kL>0:7</td>
<td class=kL>3:7</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kL>0:7</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>5:3</td>
<td class=br>36:71</td><td class=br>-35</td>
<td class=bc>3 - 2 - 12</td>
<td class=br><strong>8</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Pa Janouškovec</td><td class=kL>0:5</td>
<td class=kL>4:5</td>
<td class=kL>0:5</td>
<td class=kL>2:6</td>
<td class=kL>2:7</td>
<td class=kW>2:0</td>
<td class=kT>5:5</td>
<td class=kL>1:7</td>
<td class=kT>1:1</td>
<td class=kL>3:6</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=br>31:77</td><td class=br>-46</td>
<td class=bc>2 - 3 - 12</td>
<td class=br><strong>7</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>D</td><td class=d>18.</td><td class=kt>Ma Nádvorník</td><td class=kL>0:18</td>
<td class=kL>0:16</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>3:8</td>
<td class=kL>2:7</td>
<td class=kL>2:9</td>
<td class=kL>2:8</td>
<td class=kL>0:9</td>
<td class=kL>0:14</td>
<td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kL>1:8</td>
<td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=br>23:136</td><td class=br>-113</td>
<td class=bc>1 - 0 - 16</td>
<td class=br><strong>2</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Tabara Oskar</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Saulitis Mikus</td><td class=bc>-</td><td class=blW>Rekis Jekabs</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Jerabek Daniel</td><td class=bc>-</td><td class=bl>Příhoda Luděk</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kopřiva Adam</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Nádvorník Martin</td><td class=bc>9 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=blW>Rekis Jekabs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Příhoda Luděk</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Saulitis Mikus</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Jerabek Daniel</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=bl>Nádvorník Martin</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Kopřiva Adam</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Tabara Oskar</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Rekis Jekabs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Příhoda Luděk</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Saulitis Mikus</td><td class=bc>-</td><td class=bl>Nádvorník Martin</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Jerabek Daniel</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=bl>Kopřiva Adam</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=blW>Rekis Jekabs</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Příhoda Luděk</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Nádvorník Martin</td><td class=bc>18 : 0</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Saulitis Mikus</td><td class=bc>-</td><td class=bl>Kopřiva Adam</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Jerabek Daniel</td><td class=bc>-</td><td class=blW>Kahoun ml. Tomáš</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Rekis Jekabs</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Příhoda Luděk</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Nádvorník Martin</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Kopřiva Adam</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Kahoun ml. Tomáš</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Saulitis Mikus</td><td class=bc>-</td><td class=bl>Jerabek Daniel</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Rekis Jekabs</td><td class=bc>-</td><td class=bl>Příhoda Luděk</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Tabara Oskar</td><td class=bc>-</td><td class=bl>Nádvorník Martin</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Kopřiva Adam</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Kahoun ml. Tomáš</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Jerabek Daniel</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Saulitis Mikus</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Příhoda Luděk</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Rekis Jekabs</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Nádvorník Martin</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=bl>Kopřiva Adam</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Jerabek Daniel</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Saulitis Mikus</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>10 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Příhoda Luděk</td><td class=bc>-</td><td class=bl>Nádvorník Martin</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Rekis Jekabs</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Kopřiva Adam</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=bl>Jerabek Daniel</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=blW>Saulitis Mikus</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>3 : 11</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Nádvorník Martin</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>6 : 6</tr></td>
<tr><td class=br>Příhoda Luděk</td><td class=bc>-</td><td class=bl>Kopřiva Adam</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Rekis Jekabs</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Jerabek Daniel</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Saulitis Mikus</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Nádvorník Martin</td><td class=bc>-</td><td class=blW>Kopřiva Adam</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Kahoun ml. Tomáš</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Jerabek Daniel</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Příhoda Luděk</td><td class=bc>-</td><td class=blW>Saulitis Mikus</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Rekis Jekabs</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Kahoun ml. Tomáš</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Nádvorník Martin</td><td class=bc>-</td><td class=blW>Jerabek Daniel</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Saulitis Mikus</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Příhoda Luděk</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Rekis Jekabs</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Janouškovec Pavel</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Kopřiva Adam</td><td class=bc>-</td><td class=bl>Jerabek Daniel</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Saulitis Mikus</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Nádvorník Martin</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>0 : 14</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Příhoda Luděk</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Rekis Jekabs</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Tabara Oskar</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=bl>Saulitis Mikus</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Kopřiva Adam</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Nádvorník Martin</td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Příhoda Luděk</td><td class=bc>-</td><td class=blW>Tabara Oskar</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Rekis Jekabs</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Jerabek Daniel</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Kopřiva Adam</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Nádvorník Martin</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Příhoda Luděk</td><td class=bc>-</td><td class=blW>Janouškovec Pavel</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Rekis Jekabs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Saulitis Mikus</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Jerabek Daniel</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kopřiva Adam</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Nádvorník Martin</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Rekis Jekabs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Příhoda Luděk</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Saulitis Mikus</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Jerabek Daniel</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kopřiva Adam</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Nádvorník Martin</td><td class=bc>-</td><td class=blW>Rekis Jekabs</td><td class=bc>0 : 16</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Příhoda Luděk</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Saulitis Mikus</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jerabek Daniel</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Kopřiva Adam</td><td class=bc>-</td><td class=blW>Rekis Jekabs</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Příhoda Luděk</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Nádvorník Martin</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Saulitis Mikus</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Jerabek Daniel</td><td class=bc>-</td><td class=blW>Rekis Jekabs</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=bl>Příhoda Luděk</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Kopřiva Adam</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Nádvorník Martin</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 5</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Pa Petr</td><td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>6:4</td>
<td class=kW>7:4</td>
<td class=kT>5:5</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>9:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>11:3</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>9:0</td>
<td class=kW>12:0</td>
<td class=kW>6:0</td>
<td class=br>112:30</td><td class=br>+82</td>
<td class=bc>15 - 2 - 0</td>
<td class=br><strong>32</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ma Maděra</td><td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=kW>6:1</td>
<td class=kW>9:2</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=br>79:33</td><td class=br>+46</td>
<td class=bc>13 - 3 - 1</td>
<td class=br><strong>29</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Kr Lebl</td><td class=kL>4:6</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>5:3</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=br>74:29</td><td class=br>+45</td>
<td class=bc>13 - 2 - 2</td>
<td class=br><strong>28</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ku Sládek</td><td class=kL>4:7</td>
<td class=kL>3:7</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>0:4</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>6:0</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=br>64:29</td><td class=br>+35</td>
<td class=bc>13 - 1 - 3</td>
<td class=br><strong>27</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>To Lahučký</td><td class=kT>5:5</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>3:6</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>8:2</td>
<td class=kW>7:2</td>
<td class=kW>9:0</td>
<td class=br>66:43</td><td class=br>+23</td>
<td class=bc>10 - 3 - 4</td>
<td class=br><strong>23</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ma Klazar</td><td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kL>3:4</td>
<td class=kW>6:2</td>
<td class=kW>7:2</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=br>66:39</td><td class=br>+27</td>
<td class=bc>10 - 2 - 5</td>
<td class=br><strong>22</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Mi Černoch</td><td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:6</td>
<td class=kW>5:1</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>9:0</td>
<td class=br>56:33</td><td class=br>+23</td>
<td class=bc>9 - 4 - 4</td>
<td class=br><strong>22</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ma Ženíšek</td><td class=kL>2:7</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kL>2:7</td>
<td class=kW>5:3</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=br>57:56</td><td class=br>+1</td>
<td class=bc>8 - 4 - 5</td>
<td class=br><strong>20</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>To Růžička</td><td class=kL>1:9</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=br>48:48</td><td class=br>0</td>
<td class=bc>7 - 3 - 7</td>
<td class=br><strong>17</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>Al Krejza</td><td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>11:0</td>
<td class=kW>4:0</td>
<td class=kW>12:0</td>
<td class=br>61:38</td><td class=br>+23</td>
<td class=bc>8 - 1 - 8</td>
<td class=br><strong>17</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Mi Ševr</td><td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kW>6:3</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>9:8</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>6:5</td>
<td class=br>54:56</td><td class=br>-2</td>
<td class=bc>7 - 1 - 9</td>
<td class=br><strong>15</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>Ma Dion</td><td class=kL>1:7</td>
<td class=kL>3:6</td>
<td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>2:7</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>7:0</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=br>43:56</td><td class=br>-13</td>
<td class=bc>6 - 2 - 9</td>
<td class=br><strong>14</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Al Pala</td><td class=kL>3:11</td>
<td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kW>7:2</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>8:9</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kW>6:2</td>
<td class=kW>7:0</td>
<td class=br>59:72</td><td class=br>-13</td>
<td class=bc>6 - 0 - 11</td>
<td class=br><strong>12</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Re Saulitis</td><td class=kL>1:6</td>
<td class=kL>2:9</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=br>33:59</td><td class=br>-26</td>
<td class=bc>5 - 1 - 11</td>
<td class=br><strong>11</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>Ja Zemnickis</td><td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=br>24:57</td><td class=br>-33</td>
<td class=bc>2 - 4 - 11</td>
<td class=br><strong>8</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>C</td><td class=d>16.</td><td class=kt>Fi Werner</td><td class=kL>0:9</td>
<td class=kL>0:8</td>
<td class=kL>0:7</td>
<td class=kL>0:8</td>
<td class=kL>2:8</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kL>0:11</td>
<td class=kL>0:5</td>
<td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=br>15:95</td><td class=br>-80</td>
<td class=bc>1 - 3 - 13</td>
<td class=br><strong>5</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>On Chlebo</td><td class=kL>0:12</td>
<td class=kL>2:5</td>
<td class=kL>1:7</td>
<td class=kL>0:3</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>8:3</td>
<td class=br>27:79</td><td class=br>-52</td>
<td class=bc>1 - 2 - 14</td>
<td class=br><strong>4</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>D</td><td class=d>18.</td><td class=kt>Vo Pošík</td><td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>0:9</td>
<td class=kL>1:6</td>
<td class=kL>0:9</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>0:12</td>
<td class=kL>5:6</td>
<td class=kL>0:5</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>3:8</td>
<td class=kx>*</td>
<td class=br>18:104</td><td class=br>-86</td>
<td class=bc>0 - 0 - 17</td>
<td class=br><strong>0</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Saulitis Renars</td><td class=bc>-</td><td class=blW>Zemnickis Janis</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Dion Martin</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Werner Filip</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Pala Aleš</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Maděra Martin</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Zemnickis Janis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Saulitis Renars</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Dion Martin</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Werner Filip</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Pala Aleš</td><td class=bc>-</td><td class=blW>Maděra Martin</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Zemnickis Janis</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Saulitis Renars</td><td class=bc>-</td><td class=blW>Dion Martin</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=blW>Maděra Martin</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Werner Filip</td><td class=bc>-</td><td class=blW>Pala Aleš</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Zemnickis Janis</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Dion Martin</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Saulitis Renars</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Maděra Martin</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Pala Aleš</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Werner Filip</td><td class=bc>8 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Dion Martin</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Zemnickis Janis</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Saulitis Renars</td><td class=bc>-</td><td class=blW>Maděra Martin</td><td class=bc>2 : 9</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Pala Aleš</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Werner Filip</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Lahučký Tomáš</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=blW>Dion Martin</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Zemnickis Janis</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Maděra Martin</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Pala Aleš</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Saulitis Renars</td><td class=bc>-</td><td class=bl>Werner Filip</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=bl>Lahučký Tomáš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>7 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Dion Martin</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Chlebo Ondřej</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Maděra Martin</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Zemnickis Janis</td><td class=bc>-</td><td class=blW>Pala Aleš</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Werner Filip</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Lahučký Tomáš</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Saulitis Renars</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Dion Martin</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=blW>Maděra Martin</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Pala Aleš</td><td class=bc>9 : 8</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Werner Filip</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Zemnickis Janis</td><td class=bc>-</td><td class=bl>Lahučký Tomáš</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Saulitis Renars</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=blW>Maděra Martin</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Dion Martin</td><td class=bc>-</td><td class=bl>Pala Aleš</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=bl>Werner Filip</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Lahučký Tomáš</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zemnickis Janis</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Saulitis Renars</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Pala Aleš</td><td class=bc>11 : 3</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Werner Filip</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=blW>Lahučký Tomáš</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Dion Martin</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Saulitis Renars</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Zemnickis Janis</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Maděra Martin</td><td class=bc>-</td><td class=bl>Werner Filip</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Petr Patrik</td><td class=bc>-</td><td class=bl>Lahučký Tomáš</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>0 : 12</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Dion Martin</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=blW>Saulitis Renars</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Zemnickis Janis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Pala Aleš</td><td class=bc>-</td><td class=blW>Lahučký Tomáš</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Maděra Martin</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Saulitis Renars</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Dion Martin</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Zemnickis Janis</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Werner Filip</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>0 : 11</tr></td>
<tr><td class=brW>Pala Aleš</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Maděra Martin</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Saulitis Renars</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Dion Martin</td><td class=bc>-</td><td class=bl>Zemnickis Janis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Werner Filip</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Pala Aleš</td><td class=bc>-</td><td class=blW>Saulitis Renars</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Maděra Martin</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Zemnickis Janis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Dion Martin</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Saulitis Renars</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Werner Filip</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Pala Aleš</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Maděra Martin</td><td class=bc>-</td><td class=bl>Zemnickis Janis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Dion Martin</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Saulitis Renars</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Werner Filip</td><td class=bc>-</td><td class=bl>Zemnickis Janis</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Pala Aleš</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Maděra Martin</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>12 : 0</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Dion Martin</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Zemnickis Janis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Werner Filip</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Pala Aleš</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Maděra Martin</td><td class=bc>-</td><td class=bl>Dion Martin</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Saulitis Renars</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Zemnickis Janis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Werner Filip</td><td class=bc>-</td><td class=blW>Dion Martin</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Pala Aleš</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Maděra Martin</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Petr Patrik</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 6</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ed Naglis</td><td class=kx>*</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>15:1</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>9:1</td>
<td class=br>87:28</td><td class=br>+59</td>
<td class=bc>14 - 3 - 0</td>
<td class=br><strong>31</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Gl Storozhenko</td><td class=kL>2:7</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>7:0</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>9:1</td>
<td class=br>71:37</td><td class=br>+34</td>
<td class=bc>13 - 2 - 2</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Mi Kobrle</td><td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>7:5</td>
<td class=kW>7:3</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kL>4:6</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>10:1</td>
<td class=kW>8:4</td>
<td class=kW>9:2</td>
<td class=kW>8:2</td>
<td class=kW>18:1</td>
<td class=kW>9:1</td>
<td class=br>108:44</td><td class=br>+64</td>
<td class=bc>13 - 0 - 4</td>
<td class=br><strong>26</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>He Nilsson</td><td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>5:7</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kL>0:1</td>
<td class=kW>5:4</td>
<td class=kL>0:2</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>7:3</td>
<td class=kW>8:0</td>
<td class=br>70:34</td><td class=br>+36</td>
<td class=bc>11 - 3 - 3</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Sa Kalninš</td><td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kL>3:7</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kT>0:0</td>
<td class=kW>6:1</td>
<td class=kW>8:0</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=kW>6:0</td>
<td class=br>69:28</td><td class=br>+41</td>
<td class=bc>10 - 3 - 4</td>
<td class=br><strong>23</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Be Rjavec</td><td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>6:1</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>6:3</td>
<td class=br>62:43</td><td class=br>+19</td>
<td class=bc>11 - 1 - 5</td>
<td class=br><strong>23</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Tr Mansson</td><td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>3:2</td>
<td class=kW>9:1</td>
<td class=kW>5:1</td>
<td class=br>58:33</td><td class=br>+25</td>
<td class=bc>10 - 3 - 4</td>
<td class=br><strong>23</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Jo Vomáčka</td><td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kW>6:4</td>
<td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>6:3</td>
<td class=kW>9:1</td>
<td class=br>68:44</td><td class=br>+24</td>
<td class=bc>10 - 0 - 7</td>
<td class=br><strong>20</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>An Šurýn</td><td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kL>1:4</td>
<td class=kW>2:0</td>
<td class=kL>0:6</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kW>8:2</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=br>38:41</td><td class=br>-3</td>
<td class=bc>9 - 1 - 7</td>
<td class=br><strong>19</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>To Bucek</td><td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kW>5:1</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>8:2</td>
<td class=kW>8:4</td>
<td class=br>60:46</td><td class=br>+14</td>
<td class=bc>9 - 0 - 8</td>
<td class=br><strong>18</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Zd Lopaur</td><td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=kW>8:3</td>
<td class=br>50:47</td><td class=br>+3</td>
<td class=bc>8 - 1 - 8</td>
<td class=br><strong>17</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>Ro Vomáčka</td><td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kW>3:1</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>7:1</td>
<td class=br>37:46</td><td class=br>-9</td>
<td class=bc>6 - 3 - 8</td>
<td class=br><strong>15</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Do Zupančič</td><td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>1:10</td>
<td class=kL>1:4</td>
<td class=kT>0:0</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=kW>8:0</td>
<td class=br>46:51</td><td class=br>-5</td>
<td class=bc>5 - 2 - 10</td>
<td class=br><strong>12</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Mi Moravec</td><td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>4:8</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=br>31:66</td><td class=br>-35</td>
<td class=bc>5 - 1 - 11</td>
<td class=br><strong>11</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>Vo Vacke</td><td class=kL>1:15</td>
<td class=kL>0:5</td>
<td class=kL>2:9</td>
<td class=kL>2:7</td>
<td class=kL>0:8</td>
<td class=kW>4:3</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>2:8</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=br>20:93</td><td class=br>-73</td>
<td class=bc>3 - 0 - 14</td>
<td class=br><strong>6</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>C</td><td class=d>16.</td><td class=kt>Ja Hansson</td><td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>2:8</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=br>28:65</td><td class=br>-37</td>
<td class=bc>1 - 2 - 14</td>
<td class=br><strong>4</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Da Kadlec</td><td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kL>1:18</td>
<td class=kL>3:7</td>
<td class=kL>0:7</td>
<td class=kL>2:5</td>
<td class=kL>1:9</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kL>2:8</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>0:7</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=br>28:99</td><td class=br>-71</td>
<td class=bc>1 - 1 - 15</td>
<td class=br><strong>3</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>D</td><td class=d>18.</td><td class=kt>Vě Stanzelová</td><td class=kL>1:9</td>
<td class=kL>1:9</td>
<td class=kL>1:9</td>
<td class=kL>0:8</td>
<td class=kL>0:6</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kL>1:9</td>
<td class=kL>1:6</td>
<td class=kL>4:8</td>
<td class=kL>3:8</td>
<td class=kL>1:7</td>
<td class=kL>0:8</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kW>5:3</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=br>25:111</td><td class=br>-86</td>
<td class=bc>1 - 0 - 16</td>
<td class=br><strong>2</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Hansson Jan-Olof</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Vomáčka Josef</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Vacke Vojtěch</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Stanzelová Věra</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mansson Truls</td><td class=bc>-</td><td class=bl>Nilsson Henrik</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Zupančič Domen</td><td class=bc>-</td><td class=blW>Rjavec Bernard</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Kalninš Sandis</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Hansson Jan-Olof</td><td class=bc>-</td><td class=bl>Vacke Vojtěch</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Vomáčka Roman</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Stanzelová Věra</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Nilsson Henrik</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Rjavec Bernard</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Mansson Truls</td><td class=bc>-</td><td class=bl>Kalninš Sandis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Zupančič Domen</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=blW>Vomáčka Josef</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Vacke Vojtěch</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Hansson Jan-Olof</td><td class=bc>-</td><td class=blW>Stanzelová Věra</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Nilsson Henrik</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Kalninš Sandis</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Mansson Truls</td><td class=bc>-</td><td class=bl>Zupančič Domen</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Vacke Vojtěch</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Stanzelová Věra</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Nilsson Henrik</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Hansson Jan-Olof</td><td class=bc>-</td><td class=blW>Rjavec Bernard</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Kalninš Sandis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Zupančič Domen</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Mansson Truls</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Vacke Vojtěch</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Stanzelová Věra</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Nilsson Henrik</td><td class=bc>7 : 5</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Rjavec Bernard</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Kalninš Sandis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Hansson Jan-Olof</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Vomáčka Roman</td><td class=bc>-</td><td class=bl>Zupančič Domen</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Mansson Truls</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Stanzelová Věra</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Vacke Vojtěch</td><td class=bc>-</td><td class=blW>Nilsson Henrik</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Rjavec Bernard</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Kalninš Sandis</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Zupančič Domen</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Hansson Jan-Olof</td><td class=bc>-</td><td class=blW>Mansson Truls</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Vomáčka Roman</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Stanzelová Věra</td><td class=bc>-</td><td class=blW>Nilsson Henrik</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vacke Vojtěch</td><td class=bc>-</td><td class=blW>Kalninš Sandis</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Zupančič Domen</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Mansson Truls</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Hansson Jan-Olof</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Nilsson Henrik</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Stanzelová Věra</td><td class=bc>-</td><td class=blW>Kalninš Sandis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vacke Vojtěch</td><td class=bc>-</td><td class=blW>Zupančič Domen</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Mansson Truls</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>8 : 4</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Hansson Jan-Olof</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Rjavec Bernard</td><td class=bc>-</td><td class=blW>Kalninš Sandis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Nilsson Henrik</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Stanzelová Věra</td><td class=bc>-</td><td class=blW>Zupančič Domen</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Mansson Truls</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vacke Vojtěch</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Hansson Jan-Olof</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Kalninš Sandis</td><td class=bc>-</td><td class=bl>Zupančič Domen</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Rjavec Bernard</td><td class=bc>-</td><td class=bl>Mansson Truls</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Nilsson Henrik</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Stanzelová Věra</td><td class=bc>-</td><td class=blW>Kadlec Daniel</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Vacke Vojtěch</td><td class=bc>-</td><td class=blW>Vomáčka Roman</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Hansson Jan-Olof</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=bl>Mansson Truls</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kalninš Sandis</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Rjavec Bernard</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Nilsson Henrik</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Stanzelová Věra</td><td class=bc>-</td><td class=blW>Vomáčka Roman</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Hansson Jan-Olof</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Vacke Vojtěch</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Zupančič Domen</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kalninš Sandis</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Rjavec Bernard</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Nilsson Henrik</td><td class=bc>-</td><td class=bl>Hansson Jan-Olof</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Stanzelová Věra</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>4 : 8</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vacke Vojtěch</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Mansson Truls</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Zupančič Domen</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kalninš Sandis</td><td class=bc>-</td><td class=bl>Hansson Jan-Olof</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Rjavec Bernard</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Nilsson Henrik</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Stanzelová Věra</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Vomáčka Josef</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vacke Vojtěch</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Mansson Truls</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Zupančič Domen</td><td class=bc>-</td><td class=bl>Hansson Jan-Olof</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kalninš Sandis</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Rjavec Bernard</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Nilsson Henrik</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Stanzelová Věra</td><td class=bc>-</td><td class=blW>Vacke Vojtěch</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Vomáčka Roman</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Hansson Jan-Olof</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mansson Truls</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zupančič Domen</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kalninš Sandis</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Rjavec Bernard</td><td class=bc>-</td><td class=blW>Vacke Vojtěch</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Nilsson Henrik</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Stanzelová Věra</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Hansson Jan-Olof</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mansson Truls</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Zupančič Domen</td><td class=bc>-</td><td class=blW>Vomáčka Josef</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Vacke Vojtěch</td><td class=bc>15 : 1</tr></td>
<tr><td class=brW>Kalninš Sandis</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Rjavec Bernard</td><td class=bc>-</td><td class=bl>Stanzelová Věra</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Nilsson Henrik</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 18</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Vomáčka Josef</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Mansson Truls</td><td class=bc>-</td><td class=bl>Vacke Vojtěch</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Zupančič Domen</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Stanzelová Věra</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Kalninš Sandis</td><td class=bc>-</td><td class=bl>Nilsson Henrik</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Rjavec Bernard</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Hansson Jan-Olof</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Vacke Vojtěch</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Mansson Truls</td><td class=bc>-</td><td class=bl>Stanzelová Věra</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Zupančič Domen</td><td class=bc>-</td><td class=blW>Nilsson Henrik</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kalninš Sandis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<hr><a name="final"><p class=vm>Výkonnostní skupiny (Final groups)</p></a>
<p class=v>Group A1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>25</td>
<td class=ic>26</td>
<td class=ic>27</td>
<td class=ic>28</td>
<td class=ic>29</td>
<td class=ic>30</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt>Ra Kalninš</td><td class=kx>*</td>
<td class=kW>10:4</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kW>5:1 K</td>
<td class=kW>6:4</td>
<td class=kW>7:1</td>
<td class=kW>8:1</td>
<td class=kL>4:5 K</td>
<td class=kW>7:1</td>
<td class=kW>7:3 K</td>
<td class=kW>7:3 K</td>
<td class=kW>4:0 K</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kT>5:5 K</td>
<td class=kW>7:0</td>
<td class=kW>5:2 K</td>
<td class=kW>8:2</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>10:2 K</td>
<td class=kW>8:2</td>
<td class=kW>9:1</td>
<td class=kW>6:1</td>
<td class=kW>8:2</td>
<td class=kW>10:0</td>
<td class=kW>6:0</td>
<td class=kW>9:2 K</td>
<td class=br>188:54</td><td class=br>+134</td>
<td class=bc>27 - 1 - 1</td>
<td class=br><strong>55</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt>Pa Petr</td><td class=kL>4:10</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kT>3:3 K</td>
<td class=kW>5:2</td>
<td class=kW>6:3</td>
<td class=kW>6:4 K</td>
<td class=kW>7:4 K</td>
<td class=kW>5:3</td>
<td class=kW>12:5</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>6:2</td>
<td class=kW>5:1 K</td>
<td class=kW>6:1 K</td>
<td class=kW>5:1</td>
<td class=kT>5:5 K</td>
<td class=kW>6:4</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>6:3</td>
<td class=kW>7:2 K</td>
<td class=kW>6:5</td>
<td class=kW>7:1</td>
<td class=kW>4:2</td>
<td class=kW>9:1 K</td>
<td class=kW>3:2 K</td>
<td class=kW>6:1</td>
<td class=br>158:71</td><td class=br>+87</td>
<td class=bc>26 - 2 - 1</td>
<td class=br><strong>54</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt>Ed Caics</td><td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:3 K</td>
<td class=kW>4:2</td>
<td class=kL>3:7</td>
<td class=kW>4:2 K</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2 K</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>13:0</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1 K</td>
<td class=kW>7:4 K</td>
<td class=kT>4:4 K</td>
<td class=kW>10:3</td>
<td class=kW>11:0</td>
<td class=kW>4:3 K</td>
<td class=kW>3:1 K</td>
<td class=kW>5:3 K</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>9:0</td>
<td class=br>139:61</td><td class=br>+78</td>
<td class=bc>22 - 2 - 5</td>
<td class=br><strong>46</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt>Kr Naglis</td><td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>3:6 K</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kT>3:3 K</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>4:3 K</td>
<td class=kW>2:0</td>
<td class=kW>5:4</td>
<td class=kW>6:0</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>7:4</td>
<td class=kT>3:3</td>
<td class=kW>7:1</td>
<td class=kW>2:0 K</td>
<td class=kL>3:5 K</td>
<td class=kW>3:2 K</td>
<td class=kW>7:3</td>
<td class=kW>3:1</td>
<td class=kW>4:1 K</td>
<td class=kT>2:2 K</td>
<td class=kW>4:3 K</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=br>110:72</td><td class=br>+38</td>
<td class=bc>19 - 5 - 5</td>
<td class=br><strong>43</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>Ma Maděra</td><td class=kL>3:5</td>
<td class=kT>3:3 K</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kL>0:4 K</td>
<td class=kW>7:3 K</td>
<td class=kW>5:3</td>
<td class=kW>6:4</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1 K</td>
<td class=kW>3:0</td>
<td class=kW>3:2 K</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kT>4:4 K</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>6:1 K</td>
<td class=kW>4:2 K</td>
<td class=kW>4:0</td>
<td class=br>100:67</td><td class=br>+33</td>
<td class=bc>18 - 7 - 4</td>
<td class=br><strong>43</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>Ji Chylík ml.</td><td class=kL>1:5 K</td>
<td class=kL>2:5</td>
<td class=kW>7:3</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kL>1:4 K</td>
<td class=kW>6:3</td>
<td class=kL>1:2 K</td>
<td class=kW>6:0 K</td>
<td class=kL>2:6 K</td>
<td class=kW>3:0</td>
<td class=kL>3:5</td>
<td class=kW>6:1 K</td>
<td class=kW>2:1</td>
<td class=kW>4:2 K</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=kW>4:1 K</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>5:0 K</td>
<td class=br>110:68</td><td class=br>+42</td>
<td class=bc>19 - 2 - 8</td>
<td class=br><strong>40</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Em Larsson</td><td class=kL>4:6</td>
<td class=kL>3:6</td>
<td class=kL>2:4 K</td>
<td class=kT>3:3 K</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kL>0:3 K</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>5:4 K</td>
<td class=kT>1:1 K</td>
<td class=kW>4:2 K</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kT>3:3 K</td>
<td class=kW>6:2 K</td>
<td class=kT>2:2 K</td>
<td class=kW>8:0</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=br>99:74</td><td class=br>+25</td>
<td class=bc>17 - 5 - 7</td>
<td class=br><strong>39</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>Kr Lebl</td><td class=kL>1:7</td>
<td class=kL>4:6 K</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kW>4:0 K</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>2:4 K</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kW>5:2</td>
<td class=kT>2:2 K</td>
<td class=kW>3:1 K</td>
<td class=kT>3:3</td>
<td class=kW>5:0 K</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>5:2 K</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kT>3:3 K</td>
<td class=kW>2:1 K</td>
<td class=kW>9:2</td>
<td class=br>94:68</td><td class=br>+26</td>
<td class=bc>16 - 6 - 7</td>
<td class=br><strong>38</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>Ku Sládek</td><td class=kL>1:8</td>
<td class=kL>4:7 K</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>3:7 K</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kW>4:2 K</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kL>2:4</td>
<td class=kL>0:4 K</td>
<td class=kW>4:3 K</td>
<td class=kW>4:1</td>
<td class=kT>2:2 K</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kL>0:4</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>4:0 K</td>
<td class=kW>10:1</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=kW>1:0 K</td>
<td class=kW>6:0 K</td>
<td class=kW>2:1</td>
<td class=br>91:73</td><td class=br>+18</td>
<td class=bc>17 - 3 - 9</td>
<td class=br><strong>37</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Ja Matýsek</td><td class=kW>5:4 K</td>
<td class=kL>3:5</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kW>4:1 K</td>
<td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>0:3 K</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kL>1:3 K</td>
<td class=kT>3:3</td>
<td class=kT>1:1 K</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kL>4:6</td>
<td class=kW>5:1 K</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>9:0</td>
<td class=kT>0:0 K</td>
<td class=br>85:72</td><td class=br>+13</td>
<td class=bc>12 - 9 - 8</td>
<td class=br><strong>33</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>Mi Boštík</td><td class=kL>1:7</td>
<td class=kL>5:12</td>
<td class=kT>2:2 K</td>
<td class=kL>3:4 K</td>
<td class=kL>4:6</td>
<td class=kL>3:6</td>
<td class=kW>3:0 K</td>
<td class=kW>3:2</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kW>7:0</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>5:0</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kW>2:1 K</td>
<td class=kW>4:1 K</td>
<td class=kW>5:1 K</td>
<td class=kL>2:3</td>
<td class=kW>7:1</td>
<td class=kW>3:2 K</td>
<td class=kW>4:1 K</td>
<td class=kT>4:4 K</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>8:0</td>
<td class=br>107:90</td><td class=br>+17</td>
<td class=bc>15 - 3 - 11</td>
<td class=br><strong>33</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>An Kimberg</td><td class=kL>3:7 K</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1 K</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>3:0 K</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=kW>6:2 K</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kW>4:3 K</td>
<td class=kW>5:0</td>
<td class=kT>3:3 K</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=kL>2:5 K</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kW>4:2 K</td>
<td class=br>76:65</td><td class=br>+11</td>
<td class=bc>12 - 7 - 10</td>
<td class=br><strong>31</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt>Mi Kubica</td><td class=kL>3:7 K</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kL>0:6 K</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kL>0:6</td>
<td class=kT>2:2 K</td>
<td class=kW>6:2</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>6:1 K</td>
<td class=kT>6:6</td>
<td class=kW>3:0 K</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>1:2 K</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>0:3 K</td>
<td class=br>79:80</td><td class=br>-1</td>
<td class=bc>11 - 8 - 10</td>
<td class=br><strong>30</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt>Pa Plešák</td><td class=kL>0:4 K</td>
<td class=kL>2:6</td>
<td class=kL>1:7</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kW>6:2 K</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kW>4:2</td>
<td class=kT>2:2 K</td>
<td class=kL>0:7</td>
<td class=kL>2:6 K</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>7:4</td>
<td class=kW>5:2 K</td>
<td class=kW>4:2</td>
<td class=kT>1:1 K</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>5:8 K</td>
<td class=kL>2:6</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>2:6 K</td>
<td class=br>75:99</td><td class=br>-24</td>
<td class=bc>10 - 7 - 12</td>
<td class=br><strong>27</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt>Mi Černoch</td><td class=kL>0:5</td>
<td class=kL>1:5 K</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2 K</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2 K</td>
<td class=kW>4:0 K</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=kL>0:4</td>
<td class=kL>0:1 K</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kW>5:0</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kL>1:6 K</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>5:1 K</td>
<td class=kW>7:3 K</td>
<td class=kW>4:3</td>
<td class=br>66:67</td><td class=br>-1</td>
<td class=bc>9 - 9 - 11</td>
<td class=br><strong>27</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt>Ma Klazar</td><td class=kL>1:3</td>
<td class=kL>1:6 K</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>1:2 K</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3 K</td>
<td class=kL>3:4 K</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>4:7</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>4:3 K</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kT>3:3 K</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>6:2 K</td>
<td class=kL>3:4 K</td>
<td class=kW>6:1</td>
<td class=br>78:81</td><td class=br>-3</td>
<td class=bc>11 - 5 - 13</td>
<td class=br><strong>27</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ar Tseluiko</td><td class=kT>5:5 K</td>
<td class=kL>1:5</td>
<td class=kL>0:13</td>
<td class=kL>4:7</td>
<td class=kL>0:3</td>
<td class=kL>1:6 K</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kW>3:1 K</td>
<td class=kL>0:5</td>
<td class=kL>3:4 K</td>
<td class=kL>1:6 K</td>
<td class=kL>2:5 K</td>
<td class=kW>4:0</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:5 K</td>
<td class=kW>5:4</td>
<td class=kL>0:3</td>
<td class=kW>5:2</td>
<td class=kW>2:1 K</td>
<td class=kW>6:4</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>6:2 K</td>
<td class=br>77:105</td><td class=br>-28</td>
<td class=bc>11 - 4 - 14</td>
<td class=br><strong>26</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>To Lahučký</td><td class=kL>0:7</td>
<td class=kT>5:5 K</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3 K</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>0:5 K</td>
<td class=kT>2:2 K</td>
<td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kL>0:5</td>
<td class=kT>6:6</td>
<td class=kL>2:4</td>
<td class=kW>1:0 K</td>
<td class=kL>3:4 K</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kL>3:5</td>
<td class=kW>5:3</td>
<td class=kW>7:0</td>
<td class=kW>3:1</td>
<td class=kW>4:3 K</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kW>2:1 K</td>
<td class=kW>2:1 K</td>
<td class=kW>4:2</td>
<td class=br>73:88</td><td class=br>-15</td>
<td class=bc>9 - 7 - 13</td>
<td class=br><strong>25</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Da Matýsek</td><td class=kL>2:5 K</td>
<td class=kL>4:6</td>
<td class=kL>1:3</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>2:4 K</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kT>1:1 K</td>
<td class=kL>1:3</td>
<td class=kT>3:3 K</td>
<td class=kL>0:3 K</td>
<td class=kT>1:1 K</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kW>5:2 K</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>2:1 K</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>5:0 K</td>
<td class=br>67:76</td><td class=br>-9</td>
<td class=bc>9 - 6 - 14</td>
<td class=br><strong>24</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Kr Herold</td><td class=kL>2:8</td>
<td class=kL>1:4</td>
<td class=kL>1:4 K</td>
<td class=kL>0:2 K</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>4:5 K</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kL>1:2 K</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kW>5:3</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kW>5:2 K</td>
<td class=kL>1:2 K</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>3:1 K</td>
<td class=kT>2:2 K</td>
<td class=kL>1:2 K</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>71:82</td><td class=br>-11</td>
<td class=bc>10 - 2 - 17</td>
<td class=br><strong>22</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Da Šmíd</td><td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>4:7 K</td>
<td class=kW>5:3 K</td>
<td class=kL>0:2</td>
<td class=kL>2:7</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kL>0:4</td>
<td class=kL>1:4 K</td>
<td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>0:5</td>
<td class=kT>4:4</td>
<td class=kW>3:0</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kL>2:5 K</td>
<td class=kx>*</td>
<td class=kW>2:0 K</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>3:2 K</td>
<td class=kW>4:0 K</td>
<td class=kL>2:3 K</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=br>62:89</td><td class=br>-27</td>
<td class=bc>9 - 4 - 16</td>
<td class=br><strong>22</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Ro Jež</td><td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kT>4:4 K</td>
<td class=kL>2:3 K</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>2:4 K</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kW>6:4</td>
<td class=kL>1:5 K</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kW>2:1 K</td>
<td class=kL>0:2 K</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kL>1:4 K</td>
<td class=kL>0:3 K</td>
<td class=kW>4:0 K</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=br>54:86</td><td class=br>-32</td>
<td class=bc>9 - 2 - 18</td>
<td class=br><strong>20</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Vl Kraus</td><td class=kL>2:10 K</td>
<td class=kL>3:6</td>
<td class=kL>3:10</td>
<td class=kL>3:7</td>
<td class=kL>3:4</td>
<td class=kL>1:4 K</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>1:5 K</td>
<td class=kW>3:2</td>
<td class=kW>5:2 K</td>
<td class=kW>2:1 K</td>
<td class=kW>8:5 K</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>1:2 K</td>
<td class=kL>1:3</td>
<td class=kL>1:2 K</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kW>2:0</td>
<td class=kW>4:2 K</td>
<td class=br>65:102</td><td class=br>-37</td>
<td class=bc>10 - 0 - 19</td>
<td class=br><strong>20</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Ma Ženíšek</td><td class=kL>2:8</td>
<td class=kL>2:7 K</td>
<td class=kL>0:11</td>
<td class=kL>1:3</td>
<td class=kT>4:4 K</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>2:5 K</td>
<td class=kL>0:4 K</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kW>6:2</td>
<td class=kW>6:1 K</td>
<td class=kT>3:3 K</td>
<td class=kL>4:6</td>
<td class=kL>3:4 K</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kL>4:5</td>
<td class=kW>2:1 K</td>
<td class=kW>2:1 K</td>
<td class=kW>3:2</td>
<td class=br>75:114</td><td class=br>-39</td>
<td class=bc>8 - 4 - 17</td>
<td class=br><strong>20</strong></td><td class=d>24.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>25.</td><td class=kt>Zy Remeika</td><td class=kL>1:9</td>
<td class=kL>5:6</td>
<td class=kL>3:4 K</td>
<td class=kL>1:4 K</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kT>3:3 K</td>
<td class=kL>1:4</td>
<td class=kL>1:10</td>
<td class=kL>0:3</td>
<td class=kL>2:3 K</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kW>2:0</td>
<td class=kL>4:5</td>
<td class=kL>1:3 K</td>
<td class=kL>2:3 K</td>
<td class=kW>4:1 K</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>1:0 K</td>
<td class=kW>4:1 K</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=br>59:97</td><td class=br>-38</td>
<td class=bc>7 - 3 - 19</td>
<td class=br><strong>17</strong></td><td class=d>25.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>26.</td><td class=kt>My Verbytskyy</td><td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>1:3 K</td>
<td class=kT>2:2 K</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>2:6 K</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>1:4 K</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kW>3:0</td>
<td class=kL>0:2</td>
<td class=kT>2:2 K</td>
<td class=kL>0:4 K</td>
<td class=kW>3:0 K</td>
<td class=kW>2:0</td>
<td class=kL>1:4</td>
<td class=kL>0:1 K</td>
<td class=kx>*</td>
<td class=kT>3:3 K</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=br>48:87</td><td class=br>-39</td>
<td class=bc>6 - 5 - 18</td>
<td class=br><strong>17</strong></td><td class=d>26.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>27.</td><td class=kt>Da Dvořáček</td><td class=kL>2:8</td>
<td class=kL>2:4</td>
<td class=kL>3:5 K</td>
<td class=kL>3:4 K</td>
<td class=kL>1:7</td>
<td class=kL>3:5</td>
<td class=kT>2:2 K</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kT>4:4 K</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>2:1 K</td>
<td class=kW>3:2 K</td>
<td class=kL>0:4 K</td>
<td class=kW>4:1</td>
<td class=kW>5:4</td>
<td class=kL>1:4 K</td>
<td class=kT>3:3 K</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kL>2:5</td>
<td class=br>64:101</td><td class=br>-37</td>
<td class=bc>7 - 3 - 19</td>
<td class=br><strong>17</strong></td><td class=d>27.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>28.</td><td class=kt>To Růžička</td><td class=kL>0:10</td>
<td class=kL>1:9 K</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kL>1:6 K</td>
<td class=kT>3:3</td>
<td class=kL>0:8</td>
<td class=kT>3:3 K</td>
<td class=kL>0:1 K</td>
<td class=kL>3:4</td>
<td class=kL>2:7</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:5 K</td>
<td class=kL>2:6 K</td>
<td class=kL>2:4</td>
<td class=kL>1:2 K</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>5:0</td>
<td class=kL>0:3</td>
<td class=kW>6:2</td>
<td class=kL>1:2 K</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:0 K</td>
<td class=kT>2:2</td>
<td class=br>57:107</td><td class=br>-50</td>
<td class=bc>5 - 5 - 19</td>
<td class=br><strong>15</strong></td><td class=d>28.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>29.</td><td class=kt>Al Krejza</td><td class=kL>0:6</td>
<td class=kL>2:3 K</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>2:4 K</td>
<td class=kL>1:4</td>
<td class=kL>3:7</td>
<td class=kL>1:2 K</td>
<td class=kL>0:6 K</td>
<td class=kL>0:9</td>
<td class=kL>2:3</td>
<td class=kT>0:0</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>3:7 K</td>
<td class=kW>4:3 K</td>
<td class=kT>1:1</td>
<td class=kL>1:2 K</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kL>1:2 K</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>0:3 K</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=br>45:95</td><td class=br>-50</td>
<td class=bc>4 - 5 - 20</td>
<td class=br><strong>13</strong></td><td class=d>29.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>30.</td><td class=kt>Pe Holub</td><td class=kL>2:9 K</td>
<td class=kL>1:6</td>
<td class=kL>0:9</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>0:5 K</td>
<td class=kL>2:3</td>
<td class=kL>2:9</td>
<td class=kL>1:2</td>
<td class=kT>0:0 K</td>
<td class=kL>0:8</td>
<td class=kL>2:4 K</td>
<td class=kW>3:0 K</td>
<td class=kW>6:2 K</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>2:6 K</td>
<td class=kL>2:4</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>0:1</td>
<td class=kL>2:4 K</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=br>44:125</td><td class=br>-81</td>
<td class=bc>3 - 3 - 23</td>
<td class=br><strong>9</strong></td><td class=d>30.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Caics Edgars</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Boštík Michal</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Šmíd David</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Tseluiko Artem</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Maděra Martin</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>1 : 10</tr></td>
<tr><td class=brW>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Lahučký Tomáš</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Boštík Michal</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Šmíd David</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Tseluiko Artem</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Maděra Martin</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Lahučký Tomáš</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>5 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Šmíd David</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Tseluiko Artem</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Lahučký Tomáš</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=bl>Maděra Martin</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Šmíd David</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Boštík Michal</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Tseluiko Artem</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Lahučký Tomáš</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Maděra Martin</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Šmíd David</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Caics Edgars</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Tseluiko Artem</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Lahučký Tomáš</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Maděra Martin</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Tseluiko Artem</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Caics Edgars</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Maděra Martin</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Larsson Emil</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Šmíd David</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Matýsek Jakub</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Tseluiko Artem</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Holub Petr</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Boštík Michal</td><td class=bc>12 : 5</tr></td>
<tr><td class=brW>Maděra Martin</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Šmíd David</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=blW>Tseluiko Artem</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Verbytskyy Mykola</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Boštík Michal</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Šmíd David</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Maděra Martin</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Matýsek Jakub</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Tseluiko Artem</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Šmíd David</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Maděra Martin</td><td class=bc>-</td><td class=bl>Boštík Michal</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Remeika Zygimantas</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Verbytskyy Mykola</td><td class=bc>-</td><td class=blW>Tseluiko Artem</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Maděra Martin</td><td class=bc>-</td><td class=bl>Šmíd David</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=blW>Caics Edgars</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Larsson Emil</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>10 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Šmíd David</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Maděra Martin</td><td class=bc>-</td><td class=bl>Matýsek Jakub</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Tseluiko Artem</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>11 : 0</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Matýsek Jakub</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Tseluiko Artem</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Maděra Martin</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Boštík Michal</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Tseluiko Artem</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Maděra Martin</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Matýsek Jakub</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Kimberg Anton</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>6 : 6</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Matýsek Jakub</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Maděra Martin</td><td class=bc>-</td><td class=bl>Tseluiko Artem</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Boštík Michal</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Caics Edgars</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kimberg Anton</td><td class=bc>-</td><td class=blW>Verbytskyy Mykola</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Maděra Martin</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Matýsek Jakub</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Tseluiko Artem</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Petr Patrik</td><td class=bc>-</td><td class=blW>Kalninš Rainers</td><td class=bc>4 : 10</tr></td>
<tr><td class=br>Maděra Martin</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Matýsek Jakub</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Tseluiko Artem</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Verbytskyy Mykola</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=blW>Kimberg Anton</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Maděra Martin</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Kalninš Rainers</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Tseluiko Artem</td><td class=bc>13 : 0</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Boštík Michal</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Larsson Emil</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Maděra Martin</td><td class=bc>-</td><td class=blW>Kalninš Rainers</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Tseluiko Artem</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Šmíd David</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>10 : 3</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Boštík Michal</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>4 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=blW>Kalninš Rainers</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Maděra Martin</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Caics Edgars</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Tseluiko Artem</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Remeika Zygimantas</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Maděra Martin</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=blW>Kalninš Rainers</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Kimberg Anton</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Boštík Michal</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Larsson Emil</td><td class=bc>-</td><td class=bl>Matýsek Jakub</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Šmíd David</td><td class=bc>-</td><td class=bl>Tseluiko Artem</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Caics Edgars</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Verbytskyy Mykola</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Remeika Zygimantas</td><td class=bc>1 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group A2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>25</td>
<td class=ic>26</td>
<td class=ic>27</td>
<td class=ic>28</td>
<td class=ic>29</td>
<td class=ic>30</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt>Gi Lasmanis</td><td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kW>5:1 K</td>
<td class=kL>0:3</td>
<td class=kW>4:0</td>
<td class=kW>2:1 K</td>
<td class=kW>6:2 K</td>
<td class=kW>4:0 K</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>4:1 K</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kW>6:5 K</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kT>5:5 K</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>6:1 K</td>
<td class=kW>5:1</td>
<td class=kT>3:3 K</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=br>105:54</td><td class=br>+51</td>
<td class=bc>20 - 7 - 2</td>
<td class=br><strong>47</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt>Ed Nilsson</td><td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>5:4</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2 K</td>
<td class=kL>1:2</td>
<td class=kL>2:3 K</td>
<td class=kL>1:3</td>
<td class=kL>1:2 K</td>
<td class=kW>6:0 K</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kW>6:1 K</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>8:2</td>
<td class=kW>7:3</td>
<td class=kT>3:3</td>
<td class=kW>6:2 K</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>7:3 K</td>
<td class=kW>6:2</td>
<td class=kW>6:1 K</td>
<td class=kW>3:1 K</td>
<td class=br>121:55</td><td class=br>+66</td>
<td class=bc>19 - 6 - 4</td>
<td class=br><strong>44</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt>Ev Matantsev</td><td class=kL>1:5 K</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>7:4</td>
<td class=kW>4:2 K</td>
<td class=kW>5:2 K</td>
<td class=kT>3:3 K</td>
<td class=kT>6:6</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kW>7:1 K</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kL>2:3 K</td>
<td class=kW>7:1</td>
<td class=kW>7:3</td>
<td class=kL>5:6</td>
<td class=kW>9:2 K</td>
<td class=kW>6:2</td>
<td class=kW>6:4</td>
<td class=kT>5:5 K</td>
<td class=kW>3:1</td>
<td class=kW>4:2 K</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=br>128:85</td><td class=br>+43</td>
<td class=bc>20 - 3 - 6</td>
<td class=br><strong>43</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt>Mi Kobrle</td><td class=kW>3:0</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kL>2:3 K</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>7:3 K</td>
<td class=kT>2:2</td>
<td class=kL>3:5 K</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>3:2 K</td>
<td class=kL>7:8</td>
<td class=kW>7:1</td>
<td class=kW>7:5 K</td>
<td class=kL>5:6</td>
<td class=kL>1:6 K</td>
<td class=kW>4:1 K</td>
<td class=kW>4:0 K</td>
<td class=kW>9:5</td>
<td class=kW>8:1</td>
<td class=kL>4:6 K</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>8:1</td>
<td class=kW>4:0</td>
<td class=kT>5:5</td>
<td class=br>137:80</td><td class=br>+57</td>
<td class=bc>19 - 4 - 6</td>
<td class=br><strong>42</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>Ed Naglis</td><td class=kL>0:4</td>
<td class=kL>4:5</td>
<td class=kL>4:7</td>
<td class=kW>3:2 K</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kL>5:8</td>
<td class=kW>3:1 K</td>
<td class=kT>5:5</td>
<td class=kW>7:2 K</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kT>4:4 K</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kT>3:3 K</td>
<td class=kW>4:2</td>
<td class=kT>3:3 K</td>
<td class=kW>4:1 K</td>
<td class=kW>3:1 K</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>4:0 K</td>
<td class=kW>3:0</td>
<td class=kW>8:3</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=br>116:76</td><td class=br>+40</td>
<td class=bc>17 - 6 - 6</td>
<td class=br><strong>40</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>An Božič</td><td class=kL>1:2 K</td>
<td class=kL>0:4</td>
<td class=kL>2:4 K</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:0 K</td>
<td class=kW>5:1 K</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kW>5:2</td>
<td class=kW>4:1 K</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>0:6 K</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kW>4:2 K</td>
<td class=kW>8:2</td>
<td class=kW>5:3</td>
<td class=kT>1:1 K</td>
<td class=kW>3:1</td>
<td class=kW>5:2 K</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=br>88:76</td><td class=br>+12</td>
<td class=bc>17 - 2 - 10</td>
<td class=br><strong>36</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Ma Ležík</td><td class=kL>2:6 K</td>
<td class=kL>1:4</td>
<td class=kL>2:5 K</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kL>0:4 K</td>
<td class=kx>*</td>
<td class=kW>2:1 K</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kW>4:3 K</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>6:2 K</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>4:0 K</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kL>1:2 K</td>
<td class=kL>1:2</td>
<td class=kW>3:2 K</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=br>85:67</td><td class=br>+18</td>
<td class=bc>15 - 6 - 8</td>
<td class=br><strong>36</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>Vi Henttonen</td><td class=kL>0:4 K</td>
<td class=kL>1:4</td>
<td class=kT>3:3 K</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kL>1:5 K</td>
<td class=kL>1:2 K</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kW>2:1 K</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>6:1 K</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kW>8:2 K</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kT>2:2 K</td>
<td class=kW>5:1</td>
<td class=kW>2:0 K</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=br>70:59</td><td class=br>+11</td>
<td class=bc>15 - 6 - 8</td>
<td class=br><strong>36</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>Mi Saulitis</td><td class=kL>2:4</td>
<td class=kL>2:5 K</td>
<td class=kT>6:6</td>
<td class=kL>3:4</td>
<td class=kW>8:5</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>3:6 K</td>
<td class=kW>5:1</td>
<td class=kW>3:2 K</td>
<td class=kW>5:0 K</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>4:3 K</td>
<td class=kT>2:2</td>
<td class=kW>6:5</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kL>4:6 K</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>4:1 K</td>
<td class=kW>5:2</td>
<td class=kT>1:1 K</td>
<td class=kW>6:4 K</td>
<td class=br>103:80</td><td class=br>+23</td>
<td class=bc>14 - 7 - 8</td>
<td class=br><strong>35</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Sa Kalninš</td><td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kL>3:7 K</td>
<td class=kL>1:3 K</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:1 K</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kT>2:2 K</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2</td>
<td class=kW>5:2 K</td>
<td class=kW>6:0 K</td>
<td class=kL>1:5 K</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>4:2 K</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kL>1:5</td>
<td class=br>86:70</td><td class=br>+16</td>
<td class=bc>14 - 7 - 8</td>
<td class=br><strong>35</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>Je Rekis</td><td class=kL>1:3</td>
<td class=kW>3:2 K</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>5:5</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>6:3 K</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>3:3 K</td>
<td class=kL>3:4 K</td>
<td class=kL>0:1</td>
<td class=kW>4:1</td>
<td class=kL>3:4 K</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>8:1</td>
<td class=kW>4:3 K</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kL>2:3 K</td>
<td class=kT>2:2</td>
<td class=kW>4:0 K</td>
<td class=kW>6:3 K</td>
<td class=br>89:61</td><td class=br>+28</td>
<td class=bc>14 - 7 - 8</td>
<td class=br><strong>35</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>Gl Storozhenko</td><td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>5:3 K</td>
<td class=kL>2:7 K</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>1:5 K</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=kW>4:1 K</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kT>2:2 K</td>
<td class=kT>4:4</td>
<td class=kW>3:1 K</td>
<td class=kW>7:0 K</td>
<td class=kW>5:3 K</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>5:3 K</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=br>91:73</td><td class=br>+18</td>
<td class=bc>14 - 7 - 8</td>
<td class=br><strong>35</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt>Gu Hermansson</td><td class=kL>1:3</td>
<td class=kW>2:1 K</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3 K</td>
<td class=kW>6:1</td>
<td class=kT>3:3 K</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>4:2 K</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kW>5:1 K</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>2:0 K</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>5:1 K</td>
<td class=kT>3:3</td>
<td class=kW>5:2 K</td>
<td class=kL>4:6 K</td>
<td class=br>90:74</td><td class=br>+16</td>
<td class=bc>14 - 6 - 9</td>
<td class=br><strong>34</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt>Pe Fuchs</td><td class=kT>1:1</td>
<td class=kL>0:6 K</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kL>0:5 K</td>
<td class=kT>1:1</td>
<td class=kW>4:3 K</td>
<td class=kL>0:4</td>
<td class=kL>2:4 K</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>0:4</td>
<td class=kW>4:1 K</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>5:4</td>
<td class=kT>2:2 K</td>
<td class=kL>4:5</td>
<td class=kW>5:1</td>
<td class=kT>1:1 K</td>
<td class=kW>4:3</td>
<td class=kW>3:1 K</td>
<td class=kW>4:2 K</td>
<td class=br>73:77</td><td class=br>-4</td>
<td class=bc>13 - 6 - 10</td>
<td class=br><strong>32</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt>Tr Mansson</td><td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kL>2:3 K</td>
<td class=kT>4:4 K</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kT>2:2 K</td>
<td class=kW>1:0</td>
<td class=kL>1:4 K</td>
<td class=kW>5:1</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kW>1:0 K</td>
<td class=kW>5:2</td>
<td class=kL>2:3 K</td>
<td class=kT>3:3 K</td>
<td class=kW>2:1 K</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kW>2:1 K</td>
<td class=kW>7:0</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=br>69:70</td><td class=br>-1</td>
<td class=bc>12 - 7 - 10</td>
<td class=br><strong>31</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt>Ti Dion</td><td class=kL>1:4 K</td>
<td class=kT>1:1</td>
<td class=kL>1:7 K</td>
<td class=kW>8:7</td>
<td class=kL>3:4</td>
<td class=kL>1:4 K</td>
<td class=kL>3:4 K</td>
<td class=kL>1:2 K</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>2:8</td>
<td class=kL>2:3</td>
<td class=kW>3:2 K</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kT>2:2 K</td>
<td class=kW>7:1</td>
<td class=kW>4:2</td>
<td class=kL>2:4 K</td>
<td class=kT>3:3</td>
<td class=kW>3:2 K</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=br>87:88</td><td class=br>-1</td>
<td class=bc>12 - 4 - 13</td>
<td class=br><strong>28</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Si Thomas</td><td class=kL>1:5</td>
<td class=kL>1:6 K</td>
<td class=kW>5:3</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>3:4 K</td>
<td class=kL>2:4</td>
<td class=kW>4:3 K</td>
<td class=kW>4:2</td>
<td class=kL>1:5 K</td>
<td class=kL>1:4 K</td>
<td class=kL>3:4</td>
<td class=kW>8:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>3:2 K</td>
<td class=kL>3:5</td>
<td class=kW>6:2</td>
<td class=kW>5:1 K</td>
<td class=kW>5:1</td>
<td class=kW>2:1 K</td>
<td class=kT>4:4 K</td>
<td class=br>87:94</td><td class=br>-7</td>
<td class=bc>12 - 3 - 14</td>
<td class=br><strong>27</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>He Nilsson</td><td class=kL>0:1</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>5:7 K</td>
<td class=kT>3:3 K</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>1:1 K</td>
<td class=kL>2:3</td>
<td class=kT>2:2 K</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>0:1 K</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>6:2 K</td>
<td class=kL>0:2 K</td>
<td class=kW>5:0 K</td>
<td class=kT>3:3</td>
<td class=kW>7:3</td>
<td class=kW>5:4 K</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=br>80:78</td><td class=br>+2</td>
<td class=bc>9 - 8 - 12</td>
<td class=br><strong>26</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Mi Touš</td><td class=kL>5:6 K</td>
<td class=kT>3:3</td>
<td class=kW>3:2 K</td>
<td class=kW>6:5</td>
<td class=kL>2:4</td>
<td class=kW>6:0 K</td>
<td class=kL>2:6 K</td>
<td class=kL>1:6 K</td>
<td class=kL>5:6</td>
<td class=kT>2:2</td>
<td class=kL>3:6</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>2:3 K</td>
<td class=kT>3:3</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kL>0:5</td>
<td class=kT>3:3 K</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1 K</td>
<td class=kT>1:1</td>
<td class=kW>4:0 K</td>
<td class=kW>5:0</td>
<td class=kW>5:4</td>
<td class=br>93:96</td><td class=br>-3</td>
<td class=bc>9 - 8 - 12</td>
<td class=br><strong>26</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Be Rjavec</td><td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kW>6:1 K</td>
<td class=kT>3:3 K</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:5 K</td>
<td class=kL>1:3</td>
<td class=kL>1:3 K</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>3:2 K</td>
<td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kL>2:6 K</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>1:2 K</td>
<td class=kW>5:2 K</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>5:2 K</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=br>78:82</td><td class=br>-4</td>
<td class=bc>11 - 4 - 14</td>
<td class=br><strong>26</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>An Šurýn</td><td class=kL>3:5</td>
<td class=kL>2:8</td>
<td class=kL>3:7</td>
<td class=kL>1:4 K</td>
<td class=kL>1:4 K</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kL>0:6 K</td>
<td class=kL>0:4</td>
<td class=kL>0:7 K</td>
<td class=kW>4:2</td>
<td class=kL>0:3</td>
<td class=kT>3:3 K</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kW>2:0 K</td>
<td class=kW>5:4</td>
<td class=kW>2:1 K</td>
<td class=kx>*</td>
<td class=kW>3:0 K</td>
<td class=kT>5:5</td>
<td class=kL>2:3</td>
<td class=kL>2:5 K</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=br>68:98</td><td class=br>-30</td>
<td class=bc>11 - 3 - 15</td>
<td class=br><strong>25</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>To Bucek</td><td class=kT>3:3</td>
<td class=kL>3:7</td>
<td class=kW>6:5</td>
<td class=kL>0:4 K</td>
<td class=kL>1:3 K</td>
<td class=kW>5:2</td>
<td class=kL>0:4</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kW>5:1 K</td>
<td class=kL>1:2</td>
<td class=kL>3:5 K</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>1:2 K</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>0:5 K</td>
<td class=kW>5:0</td>
<td class=kL>2:5 K</td>
<td class=kL>0:3 K</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1 K</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=br>67:78</td><td class=br>-11</td>
<td class=bc>8 - 8 - 13</td>
<td class=br><strong>24</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Ne Škrlep</td><td class=kT>5:5 K</td>
<td class=kT>3:3</td>
<td class=kL>2:9 K</td>
<td class=kL>5:9</td>
<td class=kL>1:5</td>
<td class=kL>2:4 K</td>
<td class=kL>0:4 K</td>
<td class=kL>2:8 K</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kW>6:0</td>
<td class=kT>2:2 K</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3 K</td>
<td class=kL>2:4</td>
<td class=kT>5:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>2:1 K</td>
<td class=kW>4:2</td>
<td class=kW>6:2 K</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=br>85:119</td><td class=br>-34</td>
<td class=bc>7 - 8 - 14</td>
<td class=br><strong>22</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>To Kahoun ml.</td><td class=kL>3:4</td>
<td class=kL>2:6 K</td>
<td class=kL>2:6</td>
<td class=kL>1:8</td>
<td class=kL>2:6</td>
<td class=kL>2:8</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kW>6:4 K</td>
<td class=kT>2:2</td>
<td class=kL>3:4 K</td>
<td class=kL>1:3</td>
<td class=kL>0:2 K</td>
<td class=kT>2:2 K</td>
<td class=kW>5:2</td>
<td class=kL>1:7</td>
<td class=kL>2:3 K</td>
<td class=kL>3:7</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>3:0 K</td>
<td class=kL>1:2</td>
<td class=kW>2:1 K</td>
<td class=kW>2:1 K</td>
<td class=br>65:109</td><td class=br>-44</td>
<td class=bc>8 - 3 - 18</td>
<td class=br><strong>19</strong></td><td class=d>24.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>25.</td><td class=kt>Jo Vomáčka</td><td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>4:6</td>
<td class=kW>6:4 K</td>
<td class=kL>0:4 K</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>2:4 K</td>
<td class=kL>0:1</td>
<td class=kL>3:5 K</td>
<td class=kL>2:4</td>
<td class=kW>5:4</td>
<td class=kL>1:2 K</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kL>4:5 K</td>
<td class=kL>1:4</td>
<td class=kL>2:5 K</td>
<td class=kW>5:2 K</td>
<td class=kL>1:5 K</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kW>8:2</td>
<td class=kW>3:0</td>
<td class=br>72:96</td><td class=br>-24</td>
<td class=bc>8 - 2 - 19</td>
<td class=br><strong>18</strong></td><td class=d>25.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>26.</td><td class=kt>Ra Pommerenke</td><td class=kL>1:6 K</td>
<td class=kL>1:5</td>
<td class=kT>5:5 K</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kT>1:1 K</td>
<td class=kW>2:1 K</td>
<td class=kT>2:2 K</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kW>4:2 K</td>
<td class=kL>2:6</td>
<td class=kW>4:3</td>
<td class=kL>1:3 K</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>1:2 K</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>3:0 K</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=br>56:97</td><td class=br>-41</td>
<td class=bc>6 - 6 - 17</td>
<td class=br><strong>18</strong></td><td class=d>26.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>27.</td><td class=kt>Vá Pikl</td><td class=kL>1:5</td>
<td class=kL>3:7 K</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>3:8</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kL>1:4 K</td>
<td class=kL>0:6</td>
<td class=kW>3:2 K</td>
<td class=kT>1:1</td>
<td class=kL>1:5 K</td>
<td class=kT>1:1 K</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>1:5 K</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>0:3 K</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:1 K</td>
<td class=kT>6:6 K</td>
<td class=br>50:97</td><td class=br>-47</td>
<td class=bc>4 - 9 - 16</td>
<td class=br><strong>17</strong></td><td class=d>27.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>28.</td><td class=kt>Bi Karlsson</td><td class=kT>3:3 K</td>
<td class=kL>2:6</td>
<td class=kL>2:4 K</td>
<td class=kL>1:8</td>
<td class=kL>2:7</td>
<td class=kL>2:5 K</td>
<td class=kL>2:3 K</td>
<td class=kL>0:2 K</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3 K</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>0:4 K</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>2:6 K</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kL>0:3 K</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>5:3</td>
<td class=br>55:111</td><td class=br>-56</td>
<td class=bc>3 - 6 - 20</td>
<td class=br><strong>12</strong></td><td class=d>28.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>29.</td><td class=kt>Ad Kopřiva</td><td class=kL>0:4</td>
<td class=kL>1:6 K</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kT>1:1 K</td>
<td class=kL>1:4</td>
<td class=kL>0:4 K</td>
<td class=kL>2:4</td>
<td class=kL>2:5 K</td>
<td class=kL>1:3 K</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kL>1:2 K</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kL>1:2 K</td>
<td class=kL>2:8</td>
<td class=kL>2:3</td>
<td class=kL>1:2 K</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>5:1 K</td>
<td class=br>46:97</td><td class=br>-51</td>
<td class=bc>4 - 3 - 22</td>
<td class=br><strong>11</strong></td><td class=d>29.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>30.</td><td class=kt>Vo Kraus</td><td class=kL>2:4</td>
<td class=kL>1:3 K</td>
<td class=kL>2:4</td>
<td class=kT>5:5</td>
<td class=kL>0:4</td>
<td class=kL>3:6</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>4:6 K</td>
<td class=kW>5:1</td>
<td class=kL>3:6 K</td>
<td class=kL>2:4</td>
<td class=kW>6:4 K</td>
<td class=kL>2:4 K</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kT>4:4 K</td>
<td class=kW>4:2</td>
<td class=kL>4:5</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>3:6</td>
<td class=kL>1:2 K</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kT>6:6 K</td>
<td class=kL>3:5</td>
<td class=kL>1:5 K</td>
<td class=kx>*</td>
<td class=br>73:116</td><td class=br>-43</td>
<td class=bc>3 - 4 - 22</td>
<td class=br><strong>10</strong></td><td class=d>30.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Rekis Jekabs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Saulitis Mikus</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Dion Till</td><td class=bc>-</td><td class=bl>Mansson Truls</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=blW>Vomáčka Josef</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Škrlep Nejc</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Karlsson Bie</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=bl>Nilsson Henrik</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kopřiva Adam</td><td class=bc>-</td><td class=blW>Kalninš Sandis</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Rekis Jekabs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Saulitis Mikus</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ležík Matěj</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Karlsson Bie</td><td class=bc>-</td><td class=blW>Mansson Truls</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Dion Till</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Škrlep Nejc</td><td class=bc>-</td><td class=blW>Rjavec Bernard</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kopřiva Adam</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=blW>Nilsson Henrik</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Kalninš Sandis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>3 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ležík Matěj</td><td class=bc>-</td><td class=blW>Saulitis Mikus</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Božič Anže</td><td class=bc>-</td><td class=blW>Rekis Jekabs</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Škrlep Nejc</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Karlsson Bie</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Dion Till</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=blW>Mansson Truls</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kopřiva Adam</td><td class=bc>-</td><td class=blW>Nilsson Henrik</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=bl>Kalninš Sandis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Rekis Jekabs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Saulitis Mikus</td><td class=bc>6 : 6</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Škrlep Nejc</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Karlsson Bie</td><td class=bc>-</td><td class=blW>Rjavec Bernard</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Mansson Truls</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Dion Till</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Nilsson Henrik</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Kalninš Sandis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Kopřiva Adam</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 8</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Božič Anže</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ležík Matěj</td><td class=bc>-</td><td class=bl>Rekis Jekabs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=bl>Saulitis Mikus</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Dion Till</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=blW>Rjavec Bernard</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Škrlep Nejc</td><td class=bc>-</td><td class=bl>Mansson Truls</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Karlsson Bie</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=bl>Kalninš Sandis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kopřiva Adam</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=blW>Nilsson Henrik</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=blW>Dion Till</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Pommerenke Ralph</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Škrlep Nejc</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kopřiva Adam</td><td class=bc>-</td><td class=bl>Karlsson Bie</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Rekis Jekabs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Saulitis Mikus</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Nilsson Henrik</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kalninš Sandis</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Mansson Truls</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Kopřiva Adam</td><td class=bc>-</td><td class=bl>Dion Till</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=bl>Škrlep Nejc</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Karlsson Bie</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kalninš Sandis</td><td class=bc>-</td><td class=bl>Rekis Jekabs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=blW>Saulitis Mikus</td><td class=bc>5 : 8</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Nilsson Henrik</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=bl>Mansson Truls</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Božič Anže</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ležík Matěj</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kopřiva Adam</td><td class=bc>-</td><td class=bl>Škrlep Nejc</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Karlsson Bie</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Dion Till</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Nilsson Henrik</td><td class=bc>-</td><td class=bl>Saulitis Mikus</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kalninš Sandis</td><td class=bc>-</td><td class=blW>Hermansson Gustaf</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Thomas Simon</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Rekis Jekabs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Mansson Truls</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Škrlep Nejc</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=bl>Karlsson Bie</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kopřiva Adam</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=blW>Dion Till</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Nilsson Henrik</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kalninš Sandis</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=bl>Rekis Jekabs</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Saulitis Mikus</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=blW>Mansson Truls</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>6 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=blW>Karlsson Bie</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=bl>Dion Till</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kopřiva Adam</td><td class=bc>-</td><td class=blW>Pommerenke Ralph</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Škrlep Nejc</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Thomas Simon</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Nilsson Eddie</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Nilsson Henrik</td><td class=bc>-</td><td class=blW>Rekis Jekabs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kalninš Sandis</td><td class=bc>-</td><td class=blW>Saulitis Mikus</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=bl>Hermansson Gustaf</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ležík Matěj</td><td class=bc>-</td><td class=bl>Mansson Truls</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Rekis Jekabs</td><td class=bc>-</td><td class=blW>Mansson Truls</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Saulitis Mikus</td><td class=bc>-</td><td class=blW>Vomáčka Josef</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ležík Matěj</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Kopřiva Adam</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Dion Till</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Nilsson Henrik</td><td class=bc>-</td><td class=bl>Škrlep Nejc</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kalninš Sandis</td><td class=bc>-</td><td class=bl>Karlsson Bie</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=blW>Mansson Truls</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Rekis Jekabs</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Saulitis Mikus</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Kopřiva Adam</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ležík Matěj</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kalninš Sandis</td><td class=bc>-</td><td class=blW>Dion Till</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Škrlep Nejc</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Karlsson Bie</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Nilsson Henrik</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Rekis Jekabs</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Saulitis Mikus</td><td class=bc>-</td><td class=bl>Mansson Truls</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Kopřiva Adam</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Nilsson Henrik</td><td class=bc>-</td><td class=blW>Pommerenke Ralph</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Kalninš Sandis</td><td class=bc>-</td><td class=bl>Škrlep Nejc</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Karlsson Bie</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=blW>Dion Till</td><td class=bc>7 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Saulitis Mikus</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Mansson Truls</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Rekis Jekabs</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Kopřiva Adam</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Henttonen Ville</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Škrlep Nejc</td><td class=bc>9 : 5</tr></td>
<tr><td class=br>Nilsson Henrik</td><td class=bc>-</td><td class=bl>Karlsson Bie</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kalninš Sandis</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Dion Till</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Rekis Jekabs</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Saulitis Mikus</td><td class=bc>-</td><td class=bl>Rjavec Bernard</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=blW>Mansson Truls</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=blW>Vomáčka Josef</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Kopřiva Adam</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Božič Anže</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Henttonen Ville</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Lasmanis Gints</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Karlsson Bie</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Nilsson Henrik</td><td class=bc>-</td><td class=bl>Dion Till</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kalninš Sandis</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Škrlep Nejc</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Božič Anže</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Nilsson Henrik</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kalninš Sandis</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Rekis Jekabs</td><td class=bc>-</td><td class=bl>Dion Till</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Saulitis Mikus</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Škrlep Nejc</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Karlsson Bie</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Rjavec Bernard</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mansson Truls</td><td class=bc>-</td><td class=blW>Kahoun ml. Tomáš</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Kopřiva Adam</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Kalninš Sandis</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Božič Anže</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Nilsson Henrik</td><td class=bc>-</td><td class=blW>Lasmanis Gints</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Dion Till</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Rekis Jekabs</td><td class=bc>-</td><td class=bl>Škrlep Nejc</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Saulitis Mikus</td><td class=bc>-</td><td class=bl>Karlsson Bie</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Rjavec Bernard</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mansson Truls</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Kopřiva Adam</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Nilsson Henrik</td><td class=bc>-</td><td class=blW>Božič Anže</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kalninš Sandis</td><td class=bc>-</td><td class=bl>Ležík Matěj</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=blW>Henttonen Ville</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Matantsev Evgeniy</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=blW>Škrlep Nejc</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Karlsson Bie</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Rekis Jekabs</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Saulitis Mikus</td><td class=bc>-</td><td class=bl>Dion Till</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Rjavec Bernard</td><td class=bc>-</td><td class=blW>Kopřiva Adam</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mansson Truls</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Kahoun ml. Tomáš</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Ležík Matěj</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Nilsson Henrik</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kalninš Sandis</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Božič Anže</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Saulitis Mikus</td><td class=bc>-</td><td class=bl>Škrlep Nejc</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Karlsson Bie</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Thomas Simon</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Dion Till</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Rekis Jekabs</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Kopřiva Adam</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Rjavec Bernard</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mansson Truls</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Henttonen Ville</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Lasmanis Gints</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Nilsson Henrik</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kalninš Sandis</td><td class=bc>-</td><td class=bl>Božič Anže</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=bl>Ležík Matěj</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Rekis Jekabs</td><td class=bc>-</td><td class=bl>Karlsson Bie</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Saulitis Mikus</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Hermansson Gustaf</td><td class=bc>-</td><td class=bl>Dion Till</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Thomas Simon</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Škrlep Nejc</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mansson Truls</td><td class=bc>-</td><td class=bl>Kopřiva Adam</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Kahoun ml. Tomáš</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Rjavec Bernard</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>4 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt>Ji Vácha</td><td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>9:4</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>8:1</td>
<td class=kW>6:3</td>
<td class=br>79:31</td><td class=br>+48</td>
<td class=bc>16 - 0 - 1</td>
<td class=br><strong>32</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt>Zd Lopaur</td><td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kT>4:4</td>
<td class=kW>7:2</td>
<td class=br>68:36</td><td class=br>+32</td>
<td class=bc>12 - 4 - 1</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt>Ja Janouškovec</td><td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kL>1:7</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kT>5:5</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kT>6:6</td>
<td class=kW>11:0</td>
<td class=br>63:44</td><td class=br>+19</td>
<td class=bc>9 - 5 - 3</td>
<td class=br><strong>23</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt>Ka Hudec</td><td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kL>4:6</td>
<td class=kT>2:2</td>
<td class=kW>7:3</td>
<td class=kL>1:5</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>7:2</td>
<td class=kL>1:5</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=br>69:46</td><td class=br>+23</td>
<td class=bc>9 - 4 - 4</td>
<td class=br><strong>22</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Kr Zemnickis</td><td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kL>1:7</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>8:0</td>
<td class=br>59:36</td><td class=br>+23</td>
<td class=bc>9 - 4 - 4</td>
<td class=br><strong>22</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Mi Ševr</td><td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kW>6:4</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kT>5:5</td>
<td class=kW>10:1</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>8:2</td>
<td class=br>60:44</td><td class=br>+16</td>
<td class=bc>8 - 4 - 5</td>
<td class=br><strong>20</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Ma Dion</td><td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kL>3:6</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=br>52:47</td><td class=br>+5</td>
<td class=bc>7 - 5 - 5</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>An Gripp</td><td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kW>7:1</td>
<td class=kL>3:7</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kW>6:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>7:1</td>
<td class=br>58:53</td><td class=br>+5</td>
<td class=bc>7 - 3 - 7</td>
<td class=br><strong>17</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Do Zupančič</td><td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kW>5:1</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kW>1:0</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kL>2:5</td>
<td class=kW>5:2</td>
<td class=br>40:41</td><td class=br>-1</td>
<td class=bc>8 - 1 - 8</td>
<td class=br><strong>17</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ro Vomáčka</td><td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=br>33:41</td><td class=br>-8</td>
<td class=bc>4 - 7 - 6</td>
<td class=br><strong>15</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Lu Příhoda</td><td class=kL>4:9</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kW>7:1</td>
<td class=kL>4:5</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kL>2:7</td>
<td class=kW>4:2</td>
<td class=br>58:62</td><td class=br>-4</td>
<td class=bc>7 - 1 - 9</td>
<td class=br><strong>15</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Os Tabara</td><td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>1:7</td>
<td class=kL>3:4</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=br>34:42</td><td class=br>-8</td>
<td class=bc>6 - 3 - 8</td>
<td class=br><strong>15</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Fr Marek</td><td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kW>7:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=br>48:53</td><td class=br>-5</td>
<td class=bc>7 - 0 - 10</td>
<td class=br><strong>14</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Jo Kůrka</td><td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kT>5:5</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kT>5:5</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>8:4</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=br>52:62</td><td class=br>-10</td>
<td class=bc>4 - 4 - 9</td>
<td class=br><strong>12</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Al Pala</td><td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kL>1:10</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kL>4:8</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=br>40:68</td><td class=br>-28</td>
<td class=bc>4 - 2 - 11</td>
<td class=br><strong>10</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>On Gruncl</td><td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=br>35:59</td><td class=br>-24</td>
<td class=bc>3 - 4 - 10</td>
<td class=br><strong>10</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Li Kondrashevskyi</td><td class=kL>1:8</td>
<td class=kT>4:4</td>
<td class=kT>6:6</td>
<td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>7:2</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=br>42:70</td><td class=br>-28</td>
<td class=bc>3 - 4 - 10</td>
<td class=br><strong>10</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Lu Holub</td><td class=kL>3:6</td>
<td class=kL>2:7</td>
<td class=kL>0:11</td>
<td class=kL>2:5</td>
<td class=kL>0:8</td>
<td class=kL>2:8</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=br>28:83</td><td class=br>-55</td>
<td class=bc>2 - 1 - 14</td>
<td class=br><strong>5</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Zemnickis Krisjanis</td><td class=bc>-</td><td class=bl>Zupančič Domen</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Gripp Annika</td><td class=bc>-</td><td class=bl>Pala Aleš</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=bl>Příhoda Luděk</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Holub Lukáš</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Hudec Karol</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Dion Martin</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kůrka Josef</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Zupančič Domen</td><td class=bc>-</td><td class=bl>Pala Aleš</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Zemnickis Krisjanis</td><td class=bc>-</td><td class=blW>Příhoda Luděk</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Gripp Annika</td><td class=bc>-</td><td class=blW>Marek František</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=bl>Holub Lukáš</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Hudec Karol</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Dion Martin</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Tabara Oskar</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Kůrka Josef</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Pala Aleš</td><td class=bc>-</td><td class=bl>Příhoda Luděk</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Zupančič Domen</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Zemnickis Krisjanis</td><td class=bc>-</td><td class=bl>Holub Lukáš</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Gripp Annika</td><td class=bc>-</td><td class=blW>Hudec Karol</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Dion Martin</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Kůrka Josef</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Příhoda Luděk</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Pala Aleš</td><td class=bc>-</td><td class=blW>Holub Lukáš</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Zupančič Domen</td><td class=bc>-</td><td class=bl>Hudec Karol</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Zemnickis Krisjanis</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Gripp Annika</td><td class=bc>-</td><td class=bl>Dion Martin</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=blW>Tabara Oskar</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Kůrka Josef</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Marek František</td><td class=bc>-</td><td class=bl>Holub Lukáš</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Příhoda Luděk</td><td class=bc>-</td><td class=blW>Hudec Karol</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Pala Aleš</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zupančič Domen</td><td class=bc>-</td><td class=blW>Dion Martin</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Zemnickis Krisjanis</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Gripp Annika</td><td class=bc>-</td><td class=bl>Kůrka Josef</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Hudec Karol</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=blW>Vomáčka Roman</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Příhoda Luděk</td><td class=bc>-</td><td class=bl>Dion Martin</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pala Aleš</td><td class=bc>-</td><td class=blW>Tabara Oskar</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Zupančič Domen</td><td class=bc>-</td><td class=bl>Kůrka Josef</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Zemnickis Krisjanis</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Gripp Annika</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Hudec Karol</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Dion Martin</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Marek František</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Příhoda Luděk</td><td class=bc>-</td><td class=blW>Kůrka Josef</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pala Aleš</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Zupančič Domen</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Zemnickis Krisjanis</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Gripp Annika</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>6 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Dion Martin</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Hudec Karol</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Holub Lukáš</td><td class=bc>-</td><td class=bl>Kůrka Josef</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Příhoda Luděk</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pala Aleš</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Zupančič Domen</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Zemnickis Krisjanis</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gripp Annika</td><td class=bc>-</td><td class=bl>Kondrashevskyi Liubomyr</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Dion Martin</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Vomáčka Roman</td><td class=bc>-</td><td class=bl>Kůrka Josef</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Hudec Karol</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Příhoda Luděk</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Pala Aleš</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Zupančič Domen</td><td class=bc>-</td><td class=blW>Kondrashevskyi Liubomyr</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Zemnickis Krisjanis</td><td class=bc>-</td><td class=bl>Gripp Annika</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Dion Martin</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Hudec Karol</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>0 : 11</tr></td>
<tr><td class=brW>Marek František</td><td class=bc>-</td><td class=bl>Kondrashevskyi Liubomyr</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Příhoda Luděk</td><td class=bc>-</td><td class=blW>Gripp Annika</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pala Aleš</td><td class=bc>-</td><td class=blW>Zemnickis Krisjanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Zupančič Domen</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Kůrka Josef</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Dion Martin</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Hudec Karol</td><td class=bc>-</td><td class=bl>Kondrashevskyi Liubomyr</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Gripp Annika</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=blW>Zemnickis Krisjanis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Příhoda Luděk</td><td class=bc>-</td><td class=bl>Zupančič Domen</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pala Aleš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Kůrka Josef</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Tabara Oskar</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Dion Martin</td><td class=bc>-</td><td class=bl>Kondrashevskyi Liubomyr</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=bl>Gripp Annika</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Hudec Karol</td><td class=bc>-</td><td class=bl>Zemnickis Krisjanis</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Zupančič Domen</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Marek František</td><td class=bc>-</td><td class=bl>Pala Aleš</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Příhoda Luděk</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kůrka Josef</td><td class=bc>-</td><td class=bl>Kondrashevskyi Liubomyr</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Tabara Oskar</td><td class=bc>-</td><td class=bl>Gripp Annika</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Dion Martin</td><td class=bc>-</td><td class=bl>Zemnickis Krisjanis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Vomáčka Roman</td><td class=bc>-</td><td class=bl>Zupančič Domen</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Hudec Karol</td><td class=bc>-</td><td class=bl>Pala Aleš</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Příhoda Luděk</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Kondrashevskyi Liubomyr</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Gripp Annika</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kůrka Josef</td><td class=bc>-</td><td class=blW>Zemnickis Krisjanis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=blW>Zupančič Domen</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Dion Martin</td><td class=bc>-</td><td class=blW>Pala Aleš</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Vomáčka Roman</td><td class=bc>-</td><td class=bl>Příhoda Luděk</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Hudec Karol</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Kondrashevskyi Liubomyr</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Gripp Annika</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Zemnickis Krisjanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Zupančič Domen</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kůrka Josef</td><td class=bc>-</td><td class=bl>Pala Aleš</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=blW>Příhoda Luděk</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Dion Martin</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=bl>Holub Lukáš</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hudec Karol</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Gripp Annika</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Zemnickis Krisjanis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Zupančič Domen</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Pala Aleš</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Příhoda Luděk</td><td class=bc>9 : 4</tr></td>
<tr><td class=br>Kůrka Josef</td><td class=bc>-</td><td class=blW>Marek František</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Tabara Oskar</td><td class=bc>-</td><td class=bl>Holub Lukáš</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Dion Martin</td><td class=bc>-</td><td class=bl>Hudec Karol</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=blW>Zemnickis Krisjanis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Zupančič Domen</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Pala Aleš</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Příhoda Luděk</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Marek František</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Holub Lukáš</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Kůrka Josef</td><td class=bc>-</td><td class=blW>Hudec Karol</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Dion Martin</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Gripp Annika</td><td class=bc>-</td><td class=bl>Zupančič Domen</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=blW>Pala Aleš</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Příhoda Luděk</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Holub Lukáš</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Hudec Karol</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kůrka Josef</td><td class=bc>-</td><td class=bl>Dion Martin</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt>My Razkevich</td><td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>8:3</td>
<td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=br>74:30</td><td class=br>+44</td>
<td class=bc>14 - 1 - 2</td>
<td class=br><strong>29</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt>Jo Sedláček</td><td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kL>0:3</td>
<td class=kW>6:4</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=br>50:32</td><td class=br>+18</td>
<td class=bc>10 - 4 - 3</td>
<td class=br><strong>24</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt>Pa Pohořalý</td><td class=kL>3:8</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=br>55:37</td><td class=br>+18</td>
<td class=bc>10 - 3 - 4</td>
<td class=br><strong>23</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt>Ad Herold</td><td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=br>45:31</td><td class=br>+14</td>
<td class=bc>10 - 3 - 4</td>
<td class=br><strong>23</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Gi Remeika</td><td class=kW>6:2</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kL>0:2</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>9:1</td>
<td class=kW>2:1</td>
<td class=br>52:33</td><td class=br>+19</td>
<td class=bc>9 - 3 - 5</td>
<td class=br><strong>21</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Mi Moravec</td><td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kL>0:2</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=br>44:32</td><td class=br>+12</td>
<td class=bc>10 - 1 - 6</td>
<td class=br><strong>21</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Hy Nechutný</td><td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=br>44:30</td><td class=br>+14</td>
<td class=bc>8 - 3 - 6</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ol Tabara</td><td class=kL>3:5</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>3:0</td>
<td class=br>45:32</td><td class=br>+13</td>
<td class=bc>8 - 3 - 6</td>
<td class=br><strong>19</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Vo Vacke</td><td class=kL>0:3</td>
<td class=kL>4:6</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>2:7</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=br>50:50</td><td class=br>0</td>
<td class=bc>6 - 5 - 6</td>
<td class=br><strong>17</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Re Saulitis</td><td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kW>7:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=br>43:37</td><td class=br>+6</td>
<td class=bc>7 - 2 - 8</td>
<td class=br><strong>16</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Ma Moravec</td><td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kL>0:6</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>7:4</td>
<td class=br>38:44</td><td class=br>-6</td>
<td class=bc>6 - 4 - 7</td>
<td class=br><strong>16</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Da Jerabek</td><td class=kL>0:7</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kW>3:0</td>
<td class=kW>7:2</td>
<td class=kW>1:0</td>
<td class=br>38:41</td><td class=br>-3</td>
<td class=bc>7 - 2 - 8</td>
<td class=br><strong>16</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ra Hrnčíř</td><td class=kL>0:6</td>
<td class=kT>1:1</td>
<td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=br>33:54</td><td class=br>-21</td>
<td class=bc>6 - 3 - 8</td>
<td class=br><strong>15</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Ja Zemnickis</td><td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=kW>1:0</td>
<td class=br>23:46</td><td class=br>-23</td>
<td class=bc>6 - 3 - 8</td>
<td class=br><strong>15</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Ja Hansson</td><td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=br>42:44</td><td class=br>-2</td>
<td class=bc>7 - 1 - 9</td>
<td class=br><strong>15</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Pe Klazar</td><td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=br>33:48</td><td class=br>-15</td>
<td class=bc>3 - 5 - 9</td>
<td class=br><strong>11</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Fi Werner</td><td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>1:9</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>2:7</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>20:69</td><td class=br>-49</td>
<td class=bc>2 - 1 - 14</td>
<td class=br><strong>5</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Vo Kasnar</td><td class=kL>0:6</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>4:7</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kL>1:7</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>15:54</td><td class=br>-39</td>
<td class=bc>0 - 1 - 16</td>
<td class=br><strong>1</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Razkevich Mykhailo</td><td class=bc>-</td><td class=bl>Hansson Jan-Olof</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pohořalý Pavel</td><td class=bc>-</td><td class=bl>Werner Filip</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Herold Adam</td><td class=bc>-</td><td class=blW>Jerabek Daniel</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Saulitis Renars</td><td class=bc>-</td><td class=blW>Klazar Petr</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Kasnar Vojtěch</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Tabara Oliver</td><td class=bc>-</td><td class=blW>Vacke Vojtěch</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Sedláček Josef</td><td class=bc>-</td><td class=bl>Zemnickis Janis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Hansson Jan-Olof</td><td class=bc>-</td><td class=bl>Werner Filip</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Razkevich Mykhailo</td><td class=bc>-</td><td class=bl>Jerabek Daniel</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Pohořalý Pavel</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Herold Adam</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Kasnar Vojtěch</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Saulitis Renars</td><td class=bc>-</td><td class=bl>Vacke Vojtěch</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Zemnickis Janis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Tabara Oliver</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Sedláček Josef</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Werner Filip</td><td class=bc>-</td><td class=blW>Jerabek Daniel</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Hansson Jan-Olof</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Razkevich Mykhailo</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pohořalý Pavel</td><td class=bc>-</td><td class=bl>Kasnar Vojtěch</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Herold Adam</td><td class=bc>-</td><td class=bl>Vacke Vojtěch</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Zemnickis Janis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Saulitis Renars</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Tabara Oliver</td><td class=bc>-</td><td class=bl>Sedláček Josef</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Jerabek Daniel</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Werner Filip</td><td class=bc>-</td><td class=blW>Klazar Petr</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Hansson Jan-Olof</td><td class=bc>-</td><td class=bl>Kasnar Vojtěch</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Razkevich Mykhailo</td><td class=bc>-</td><td class=bl>Vacke Vojtěch</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Pohořalý Pavel</td><td class=bc>-</td><td class=bl>Zemnickis Janis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Herold Adam</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Saulitis Renars</td><td class=bc>-</td><td class=bl>Sedláček Josef</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=bl>Tabara Oliver</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Jerabek Daniel</td><td class=bc>-</td><td class=bl>Kasnar Vojtěch</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Werner Filip</td><td class=bc>-</td><td class=bl>Vacke Vojtěch</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hansson Jan-Olof</td><td class=bc>-</td><td class=blW>Zemnickis Janis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Razkevich Mykhailo</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Pohořalý Pavel</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Herold Adam</td><td class=bc>-</td><td class=bl>Sedláček Josef</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Tabara Oliver</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Saulitis Renars</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Klazar Petr</td><td class=bc>-</td><td class=bl>Kasnar Vojtěch</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Vacke Vojtěch</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jerabek Daniel</td><td class=bc>-</td><td class=blW>Zemnickis Janis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Werner Filip</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Hansson Jan-Olof</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Razkevich Mykhailo</td><td class=bc>-</td><td class=bl>Sedláček Josef</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pohořalý Pavel</td><td class=bc>-</td><td class=bl>Tabara Oliver</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Herold Adam</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Saulitis Renars</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Kasnar Vojtěch</td><td class=bc>-</td><td class=bl>Vacke Vojtěch</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Zemnickis Janis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Jerabek Daniel</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Werner Filip</td><td class=bc>-</td><td class=blW>Sedláček Josef</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Hansson Jan-Olof</td><td class=bc>-</td><td class=blW>Tabara Oliver</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Razkevich Mykhailo</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pohořalý Pavel</td><td class=bc>-</td><td class=bl>Saulitis Renars</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Herold Adam</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Vacke Vojtěch</td><td class=bc>-</td><td class=bl>Zemnickis Janis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kasnar Vojtěch</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Sedláček Josef</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jerabek Daniel</td><td class=bc>-</td><td class=blW>Tabara Oliver</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Werner Filip</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Hansson Jan-Olof</td><td class=bc>-</td><td class=bl>Saulitis Renars</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Razkevich Mykhailo</td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Pohořalý Pavel</td><td class=bc>-</td><td class=bl>Herold Adam</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Zemnickis Janis</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vacke Vojtěch</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kasnar Vojtěch</td><td class=bc>-</td><td class=blW>Sedláček Josef</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Tabara Oliver</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jerabek Daniel</td><td class=bc>-</td><td class=bl>Saulitis Renars</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Werner Filip</td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Hansson Jan-Olof</td><td class=bc>-</td><td class=blW>Herold Adam</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Razkevich Mykhailo</td><td class=bc>-</td><td class=bl>Pohořalý Pavel</td><td class=bc>8 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Sedláček Josef</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Zemnickis Janis</td><td class=bc>-</td><td class=blW>Tabara Oliver</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Vacke Vojtěch</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kasnar Vojtěch</td><td class=bc>-</td><td class=blW>Saulitis Renars</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Herold Adam</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Jerabek Daniel</td><td class=bc>-</td><td class=blW>Pohořalý Pavel</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Werner Filip</td><td class=bc>-</td><td class=blW>Razkevich Mykhailo</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Hansson Jan-Olof</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=bl>Tabara Oliver</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Zemnickis Janis</td><td class=bc>-</td><td class=blW>Saulitis Renars</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vacke Vojtěch</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kasnar Vojtěch</td><td class=bc>-</td><td class=blW>Herold Adam</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=bl>Pohořalý Pavel</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Razkevich Mykhailo</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jerabek Daniel</td><td class=bc>-</td><td class=blW>Hansson Jan-Olof</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Werner Filip</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Sedláček Josef</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Saulitis Renars</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Zemnickis Janis</td><td class=bc>-</td><td class=bl>Herold Adam</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vacke Vojtěch</td><td class=bc>-</td><td class=bl>Pohořalý Pavel</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kasnar Vojtěch</td><td class=bc>-</td><td class=blW>Razkevich Mykhailo</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Hansson Jan-Olof</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Werner Filip</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Jerabek Daniel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Tabara Oliver</td><td class=bc>-</td><td class=bl>Saulitis Renars</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Sedláček Josef</td><td class=bc>-</td><td class=bl>Remeika Gintautas</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Herold Adam</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Pohořalý Pavel</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Zemnickis Janis</td><td class=bc>-</td><td class=blW>Razkevich Mykhailo</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Vacke Vojtěch</td><td class=bc>-</td><td class=bl>Hansson Jan-Olof</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Kasnar Vojtěch</td><td class=bc>-</td><td class=blW>Werner Filip</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Jerabek Daniel</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Remeika Gintautas</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Tabara Oliver</td><td class=bc>-</td><td class=blW>Herold Adam</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Sedláček Josef</td><td class=bc>-</td><td class=blW>Pohořalý Pavel</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Razkevich Mykhailo</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Hansson Jan-Olof</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Zemnickis Janis</td><td class=bc>-</td><td class=bl>Werner Filip</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Vacke Vojtěch</td><td class=bc>-</td><td class=blW>Jerabek Daniel</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kasnar Vojtěch</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Saulitis Renars</td><td class=bc>-</td><td class=blW>Herold Adam</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Pohořalý Pavel</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Tabara Oliver</td><td class=bc>-</td><td class=blW>Razkevich Mykhailo</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Sedláček Josef</td><td class=bc>-</td><td class=bl>Hansson Jan-Olof</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Werner Filip</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Jerabek Daniel</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zemnickis Janis</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vacke Vojtěch</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kasnar Vojtěch</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=blW>Pohořalý Pavel</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Saulitis Renars</td><td class=bc>-</td><td class=blW>Razkevich Mykhailo</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Hansson Jan-Olof</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Tabara Oliver</td><td class=bc>-</td><td class=bl>Werner Filip</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Sedláček Josef</td><td class=bc>-</td><td class=bl>Jerabek Daniel</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Zemnickis Janis</td><td class=bc>-</td><td class=bl>Kasnar Vojtěch</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Vacke Vojtěch</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Herold Adam</td><td class=bc>-</td><td class=bl>Razkevich Mykhailo</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Hansson Jan-Olof</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Saulitis Renars</td><td class=bc>-</td><td class=blW>Werner Filip</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Jerabek Daniel</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Tabara Oliver</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Sedláček Josef</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Kasnar Vojtěch</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Vacke Vojtěch</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Zemnickis Janis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Pohořalý Pavel</td><td class=bc>-</td><td class=blW>Hansson Jan-Olof</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Herold Adam</td><td class=bc>-</td><td class=bl>Werner Filip</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Remeika Gintautas</td><td class=bc>-</td><td class=bl>Jerabek Daniel</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Saulitis Renars</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Tabara Oliver</td><td class=bc>-</td><td class=bl>Kasnar Vojtěch</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Sedláček Josef</td><td class=bc>-</td><td class=bl>Vacke Vojtěch</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=bl>Zemnickis Janis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group D</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt>Gu Gripp</td><td class=kx>*</td>
<td class=kW>4:1 + 3:4</td>
<td class=kW>4:1 + 5:2</td>
<td class=kL>2:4 + 5:2</td>
<td class=kW>6:3 + 4:0</td>
<td class=kW>4:1 + 4:3</td>
<td class=kW>9:0 + 8:7</td>
<td class=kW>7:1 + 4:2</td>
<td class=kW>6:2 + 6:2</td>
<td class=kW>8:0 + 6:1</td>
<td class=kW>5:0 + 6:1</td>
<td class=kW>6:0 + 8:0</td>
<td class=br>120:37</td><td class=br>+83</td>
<td class=bc>20 - 0 - 2</td>
<td class=br><strong>40</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt>Er Bernhauser</td><td class=kL>1:4 + 4:3</td>
<td class=kx>*</td>
<td class=kW>8:1 + 6:4</td>
<td class=kL>3:4 + 5:2</td>
<td class=kW>4:2 + 4:4</td>
<td class=kW>7:4 + 6:2</td>
<td class=kW>4:3 + 8:4</td>
<td class=kW>5:3 + 1:2</td>
<td class=kW>5:2 + 11:1</td>
<td class=kW>7:1 + 8:0</td>
<td class=kW>9:0 + 9:1</td>
<td class=kW>9:0 + 7:0</td>
<td class=br>131:47</td><td class=br>+84</td>
<td class=bc>18 - 1 - 3</td>
<td class=br><strong>37</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt>Ví Pernica</td><td class=kL>1:4 + 2:5</td>
<td class=kL>1:8 + 4:6</td>
<td class=kx>*</td>
<td class=kW>4:1 + 5:3</td>
<td class=kW>2:0 + 5:2</td>
<td class=kW>3:2 + 2:2</td>
<td class=kW>8:2 + 1:4</td>
<td class=kW>6:5 + 3:2</td>
<td class=kW>9:2 + 17:1</td>
<td class=kW>4:1 + 8:1</td>
<td class=kW>8:1 + 8:1</td>
<td class=kW>5:0 + 6:1</td>
<td class=br>112:54</td><td class=br>+58</td>
<td class=bc>16 - 1 - 5</td>
<td class=br><strong>33</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt>Da Kadlec</td><td class=kW>4:2 + 2:5</td>
<td class=kW>4:3 + 2:5</td>
<td class=kL>1:4 + 3:5</td>
<td class=kx>*</td>
<td class=kW>4:3 + 4:1</td>
<td class=kL>2:4 + 2:1</td>
<td class=kW>4:0 + 2:1</td>
<td class=kW>2:1 + 1:4</td>
<td class=kW>9:1 + 7:0</td>
<td class=kW>5:3 + 9:2</td>
<td class=kW>9:2 + 8:1</td>
<td class=kW>8:1 + 6:1</td>
<td class=br>98:50</td><td class=br>+48</td>
<td class=bc>16 - 0 - 6</td>
<td class=br><strong>32</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Pa Janouškovec</td><td class=kL>3:6 + 0:4</td>
<td class=kL>2:4 + 4:4</td>
<td class=kL>0:2 + 2:5</td>
<td class=kL>3:4 + 1:4</td>
<td class=kx>*</td>
<td class=kW>2:1 + 5:4</td>
<td class=kW>3:2 + 4:0</td>
<td class=kT>1:1 + 5:2</td>
<td class=kL>2:5 + 5:1</td>
<td class=kW>3:2 + 3:1</td>
<td class=kW>5:1 + 6:0</td>
<td class=kW>6:1 + 3:2</td>
<td class=br>68:56</td><td class=br>+12</td>
<td class=bc>12 - 2 - 8</td>
<td class=br><strong>26</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>On Chlebo</td><td class=kL>1:4 + 3:4</td>
<td class=kL>4:7 + 2:6</td>
<td class=kL>2:3 + 2:2</td>
<td class=kW>4:2 + 1:2</td>
<td class=kL>1:2 + 4:5</td>
<td class=kx>*</td>
<td class=kL>1:3 + 2:0</td>
<td class=kT>2:2 + 3:1</td>
<td class=kW>8:1 + 7:0</td>
<td class=kW>7:2 + 4:2</td>
<td class=kW>5:1 + 1:0</td>
<td class=kW>7:0 + 4:1</td>
<td class=br>75:50</td><td class=br>+25</td>
<td class=bc>11 - 2 - 9</td>
<td class=br><strong>24</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Vě Stanzelová</td><td class=kL>0:9 + 7:8</td>
<td class=kL>3:4 + 4:8</td>
<td class=kL>2:8 + 4:1</td>
<td class=kL>0:4 + 1:2</td>
<td class=kL>2:3 + 0:4</td>
<td class=kW>3:1 + 0:2</td>
<td class=kx>*</td>
<td class=kW>3:2 + 4:5</td>
<td class=kW>5:3 + 3:0</td>
<td class=kT>2:2 + 7:1</td>
<td class=kW>2:0 + 10:1</td>
<td class=kW>6:0 + 3:0</td>
<td class=br>71:68</td><td class=br>+3</td>
<td class=bc>10 - 1 - 11</td>
<td class=br><strong>21</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ma Nádvorník</td><td class=kL>1:7 + 2:4</td>
<td class=kL>3:5 + 2:1</td>
<td class=kL>5:6 + 2:3</td>
<td class=kL>1:2 + 4:1</td>
<td class=kT>1:1 + 2:5</td>
<td class=kT>2:2 + 1:3</td>
<td class=kL>2:3 + 5:4</td>
<td class=kx>*</td>
<td class=kL>2:3 + 4:2</td>
<td class=kW>7:4 + 5:0</td>
<td class=kL>2:3 + 4:0</td>
<td class=kW>4:2 + 4:0</td>
<td class=br>65:61</td><td class=br>+4</td>
<td class=bc>9 - 2 - 11</td>
<td class=br><strong>20</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Vo Pošík</td><td class=kL>2:6 + 2:6</td>
<td class=kL>2:5 + 1:11</td>
<td class=kL>2:9 + 1:17</td>
<td class=kL>1:9 + 0:7</td>
<td class=kW>5:2 + 1:5</td>
<td class=kL>1:8 + 0:7</td>
<td class=kL>3:5 + 0:3</td>
<td class=kW>3:2 + 2:4</td>
<td class=kx>*</td>
<td class=kW>1:0 + 2:3</td>
<td class=kW>3:1 + 3:1</td>
<td class=kT>2:2 + 4:0</td>
<td class=br>41:113</td><td class=br>-72</td>
<td class=bc>6 - 1 - 15</td>
<td class=br><strong>13</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ví Nádvorník</td><td class=kL>0:8 + 1:6</td>
<td class=kL>1:7 + 0:8</td>
<td class=kL>1:4 + 1:8</td>
<td class=kL>3:5 + 2:9</td>
<td class=kL>2:3 + 1:3</td>
<td class=kL>2:7 + 2:4</td>
<td class=kT>2:2 + 1:7</td>
<td class=kL>4:7 + 0:5</td>
<td class=kL>0:1 + 3:2</td>
<td class=kx>*</td>
<td class=kW>6:3 + 6:3</td>
<td class=kW>6:2 + 3:0</td>
<td class=br>47:104</td><td class=br>-57</td>
<td class=bc>5 - 1 - 16</td>
<td class=br><strong>11</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Ji Kubáč</td><td class=kL>0:5 + 1:6</td>
<td class=kL>0:9 + 1:9</td>
<td class=kL>1:8 + 1:8</td>
<td class=kL>2:9 + 1:8</td>
<td class=kL>1:5 + 0:6</td>
<td class=kL>1:5 + 0:1</td>
<td class=kL>0:2 + 1:10</td>
<td class=kW>3:2 + 0:4</td>
<td class=kL>1:3 + 1:3</td>
<td class=kL>3:6 + 3:6</td>
<td class=kx>*</td>
<td class=kT>1:1 + 1:1</td>
<td class=br>23:117</td><td class=br>-94</td>
<td class=bc>1 - 2 - 19</td>
<td class=br><strong>4</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ji Pošík</td><td class=kL>0:6 + 0:8</td>
<td class=kL>0:9 + 0:7</td>
<td class=kL>0:5 + 1:6</td>
<td class=kL>1:8 + 1:6</td>
<td class=kL>1:6 + 2:3</td>
<td class=kL>0:7 + 1:4</td>
<td class=kL>0:6 + 0:3</td>
<td class=kL>2:4 + 0:4</td>
<td class=kT>2:2 + 0:4</td>
<td class=kL>2:6 + 0:3</td>
<td class=kT>1:1 + 1:1</td>
<td class=kx>*</td>
<td class=br>15:109</td><td class=br>-94</td>
<td class=bc>0 - 3 - 19</td>
<td class=br><strong>3</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Bernhauser Erik</td><td class=bc>-</td><td class=bl>Stanzelová Věra</td><td class=bc>4 : 3 + 8 : 4</tr></td>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>9 : 2 + 17 : 1</tr></td>
<tr><td class=brW>Gripp Gunnar</td><td class=bc>-</td><td class=bl>Nádvorník Martin</td><td class=bc>7 : 1 + 4 : 2</tr></td>
<tr><td class=brW>Janouškovec Pavel</td><td class=bc>-</td><td class=bl>Nádvorník Vít</td><td class=bc>3 : 2  + 3 : 1</tr></td>
<tr><td class=brW>Chlebo Ondřej</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>7 : 0 + 4 : 1</tr></td>
<tr><td class=brW>Kadlec Daniel</td><td class=bc>-</td><td class=bl>Kubáč Jiří</td><td class=bc>9 : 2 + 8 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Stanzelová Věra</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>5 : 3 + 3 : 0</tr></td>
<tr><td class=brW>Bernhauser Erik</td><td class=bc>-</td><td class=bl>Nádvorník Martin</td><td class=bc>5 : 3 + 1 : 2</tr></td>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Nádvorník Vít</td><td class=bc>4 : 1 + 8 : 1</tr></td>
<tr><td class=brW>Gripp Gunnar</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>6 : 0 + 8 : 0</tr></td>
<tr><td class=brW>Janouškovec Pavel</td><td class=bc>-</td><td class=bl>Kubáč Jiří</td><td class=bc>5 : 1 + 6 : 0</tr></td>
<tr><td class=brW>Chlebo Ondřej</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>4 : 2 + 1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Pošík Vojtěch</td><td class=bc>-</td><td class=bl>Nádvorník Martin</td><td class=bc>3 : 2+ 2 : 4</tr></td>
<tr><td class=br>Stanzelová Věra</td><td class=bc>-</td><td class=bl>Nádvorník Vít</td><td class=bc>2 : 2 + 7 : 1</tr></td>
<tr><td class=brW>Bernhauser Erik</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>9 : 0 + 7 : 0</tr></td>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Kubáč Jiří</td><td class=bc>8 : 1 + 8 : 1</tr></td>
<tr><td class=br>Gripp Gunnar</td><td class=bc>-</td><td class=blW>Kadlec Daniel</td><td class=bc>2 : 4 + 5 : 2</tr></td>
<tr><td class=brW>Janouškovec Pavel</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>2 : 1 + 5 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Nádvorník Martin</td><td class=bc>-</td><td class=bl>Nádvorník Vít</td><td class=bc>7 : 4 + 5 : 0</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>2 : 2 + 4 : 0</tr></td>
<tr><td class=brW>Stanzelová Věra</td><td class=bc>-</td><td class=bl>Kubáč Jiří</td><td class=bc>2 : 0 + 10 : 1</tr></td>
<tr><td class=br>Bernhauser Erik</td><td class=bc>-</td><td class=blW>Kadlec Daniel</td><td class=bc>3 : 4 + 5 : 2</tr></td>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>3 : 2 + 2 : 2</tr></td>
<tr><td class=brW>Gripp Gunnar</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>6 : 3 + 4 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Nádvorník Vít</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>6 : 2 + 3 : 0</tr></td>
<tr><td class=br>Nádvorník Martin</td><td class=bc>-</td><td class=blW>Kubáč Jiří</td><td class=bc>2 : 3 + 4 : 0</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Kadlec Daniel</td><td class=bc>1 : 9 + 0 : 7</tr></td>
<tr><td class=brW>Stanzelová Věra</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>3 : 1 + 0 : 2</tr></td>
<tr><td class=brW>Bernhauser Erik</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>4 : 2 + 4 : 4</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Gripp Gunnar</td><td class=bc>1 : 4 + 2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=bl>Kubáč Jiří</td><td class=bc>1 : 1 + 1 : 1</tr></td>
<tr><td class=br>Nádvorník Vít</td><td class=bc>-</td><td class=blW>Kadlec Daniel</td><td class=bc>3 : 5  + 2 : 9</tr></td>
<tr><td class=br>Nádvorník Martin</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>2 : 2 + 1 : 3</tr></td>
<tr><td class=brW>Pošík Vojtěch</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>5 : 2 + 1 : 5</tr></td>
<tr><td class=br>Stanzelová Věra</td><td class=bc>-</td><td class=blW>Gripp Gunnar</td><td class=bc>0 : 9+ 7 : 8</tr></td>
<tr><td class=brW>Bernhauser Erik</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>8 : 1 + 6 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Kubáč Jiří</td><td class=bc>-</td><td class=blW>Chlebo Ondřej</td><td class=bc>1 : 5+ 0 : 1</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Janouškovec Pavel</td><td class=bc>1 : 6 + 2 : 3</tr></td>
<tr><td class=br>Nádvorník Vít</td><td class=bc>-</td><td class=blW>Gripp Gunnar</td><td class=bc>0 : 8 + 1 : 6</tr></td>
<tr><td class=br>Nádvorník Martin</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>5 : 6 + 2 : 3</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Bernhauser Erik</td><td class=bc>2 : 5 + 1 : 11</tr></td>
<tr><td class=br>Stanzelová Věra</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Kadlec Daniel</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>4 : 3 + 4 : 1</tr></td>
<tr><td class=br>Kubáč Jiří</td><td class=bc>-</td><td class=blW>Gripp Gunnar</td><td class=bc>0 : 5 + 1 : 6</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>0 : 5 + 1 : 6</tr></td>
<tr><td class=br>Nádvorník Vít</td><td class=bc>-</td><td class=blW>Bernhauser Erik</td><td class=bc>1 : 7 + 0 : 8</tr></td>
<tr><td class=br>Nádvorník Martin</td><td class=bc>-</td><td class=blW>Stanzelová Věra</td><td class=bc>2 : 3 + 5 : 4</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=blW>Gripp Gunnar</td><td class=bc>1 : 4 + 3 : 4</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>1 : 4 + 3 : 5</tr></td>
<tr><td class=br>Kubáč Jiří</td><td class=bc>-</td><td class=blW>Bernhauser Erik</td><td class=bc>0 : 9 + 1 : 9</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Stanzelová Věra</td><td class=bc>0 : 6 + 0 : 3</tr></td>
<tr><td class=br>Nádvorník Vít</td><td class=bc>-</td><td class=blW>Pošík Vojtěch</td><td class=bc>0 : 1 + 3 : 2</tr></td>
<tr><td class=br>Nádvorník Martin</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>0 : 2 + 2 : 5</tr></td>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=blW>Bernhauser Erik</td><td class=bc>4 : 7 + 2 : 6</tr></td>
<tr><td class=brW>Kadlec Daniel</td><td class=bc>-</td><td class=bl>Stanzelová Věra</td><td class=bc>4 : 0 + 2 : 1</tr></td>
<tr><td class=br>Kubáč Jiří</td><td class=bc>-</td><td class=blW>Pošík Vojtěch</td><td class=bc>1 : 3 + 1 : 3</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Nádvorník Martin</td><td class=bc>2 : 4 + 0 : 4</tr></td>
<tr><td class=br>Nádvorník Vít</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Gripp Gunnar</td><td class=bc>-</td><td class=bl>Bernhauser Erik</td><td class=bc>4 : 1 + 3 : 4</tr></td>
<tr><td class=brW>Janouškovec Pavel</td><td class=bc>-</td><td class=bl>Stanzelová Věra</td><td class=bc>3 : 2 + 4 : 0</tr></td>
<tr><td class=brW>Chlebo Ondřej</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>8 : 1 + 7 : 0</tr></td>
<tr><td class=brW>Kadlec Daniel</td><td class=bc>-</td><td class=bl>Nádvorník Martin</td><td class=bc>2 : 1 + 1 : 4</tr></td>
<tr><td class=br>Kubáč Jiří</td><td class=bc>-</td><td class=blW>Nádvorník Vít</td><td class=bc>3 : 6 + 3 : 6</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Stanzelová Věra</td><td class=bc>8 : 2 + 1 : 4</tr></td>
<tr><td class=brW>Gripp Gunnar</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>6 : 2 + 6 : 2</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=bl>Nádvorník Martin</td><td class=bc>1 : 1 + 5 : 2</tr></td>
<tr><td class=brW>Chlebo Ondřej</td><td class=bc>-</td><td class=bl>Nádvorník Vít</td><td class=bc>7 : 2 + 4 : 2</tr></td>
<tr><td class=brW>Kadlec Daniel</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>8 : 1 + 6 : 1</tr></td>
<tr><td class=br>Kubáč Jiří</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
