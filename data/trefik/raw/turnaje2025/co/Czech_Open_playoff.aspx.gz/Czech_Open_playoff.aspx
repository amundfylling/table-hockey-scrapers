<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/pohar13.aspx">U13</a>
&nbsp;<a href="../data/pohar55.aspx">55+</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co/index.aspx">Play-Off</a></span></h2></div></div></div></div><p><div align="center">
<table border=0 cellpadding=2 cellspacing=0>
<tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>Finals</strong></font></th></tr>
<tr><td class=br><b>Kalninš Rainers</b>&nbsp;&nbsp;</td>
<td class=bl>- Naglis Edgars&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>6:4&nbsp;&nbsp;</td>
<td class=bl>5:2&nbsp;&nbsp;</td>
<td class=bl>2:3&nbsp;&nbsp;</td>
<td class=bl>7:2&nbsp;&nbsp;</td>
<td class=bl>10:4&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>1/2</strong></font></th></tr>
<tr><td class=ar><b>Kalninš Rainers</b>&nbsp;&nbsp;</td>
<td class=al>- Caics Edgars&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:4&nbsp;&nbsp;</td>
<td class=al>1:4&nbsp;&nbsp;</td>
<td class=al>5:3&nbsp;&nbsp;</td>
<td class=al>1:2 P&nbsp;&nbsp;</td>
<td class=al>4:3&nbsp;&nbsp;</td>
<td class=al>3:1&nbsp;&nbsp;</td>
<td class=al>4:1&nbsp;&nbsp;</td>
</tr><tr><td class=br>Rekis Jekabs&nbsp;&nbsp;</td>
<td class=bl>- <b>Naglis Edgars</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 4&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:4&nbsp;&nbsp;</td>
<td class=bl>3:9&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>3:4&nbsp;&nbsp;</td>
<td class=bl>6:5&nbsp;&nbsp;</td>
<td class=bl>2:6&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>3rd</strong></font></th></tr>
<tr><td class=ar><b>Caics Edgars</b>&nbsp;&nbsp;</td>
<td class=al>- Rekis Jekabs&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 1&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>8:1&nbsp;&nbsp;</td>
<td class=al>4:0&nbsp;&nbsp;</td>
<td class=al>2:5&nbsp;&nbsp;</td>
<td class=al>3:2 P&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>1/4</strong></font></th></tr>
<tr><td class=br><b>Kalninš Rainers</b>&nbsp;&nbsp;</td>
<td class=bl>- Kobrle Michal&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>8:4&nbsp;&nbsp;</td>
<td class=bl>6:0&nbsp;&nbsp;</td>
<td class=bl>7:2&nbsp;&nbsp;</td>
<td class=bl>6:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Caics Edgars</b>&nbsp;&nbsp;</td>
<td class=al>- Nilsson Eddie&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 1&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>5:4 P&nbsp;&nbsp;</td>
<td class=al>7:3&nbsp;&nbsp;</td>
<td class=al>3:6&nbsp;&nbsp;</td>
<td class=al>7:4&nbsp;&nbsp;</td>
<td class=al>6:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br>Petr Patrik&nbsp;&nbsp;</td>
<td class=bl>- <b>Rekis Jekabs</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;1 : 4&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:3&nbsp;&nbsp;</td>
<td class=bl>4:6&nbsp;&nbsp;</td>
<td class=bl>0:6&nbsp;&nbsp;</td>
<td class=bl>6:4&nbsp;&nbsp;</td>
<td class=bl>5:6&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Naglis Edgars</b>&nbsp;&nbsp;</td>
<td class=al>- Lasmanis Gints&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>6:0&nbsp;&nbsp;</td>
<td class=al>3:4&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>1:2&nbsp;&nbsp;</td>
<td class=al>9:0&nbsp;&nbsp;</td>
<td class=al>6:4&nbsp;&nbsp;</td>
<td class=al>6:3&nbsp;&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>1/8</strong></font></th></tr>
<tr><td class=br><b>Kalninš Rainers</b>&nbsp;&nbsp;</td>
<td class=bl>- Sládek Kuba&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 2&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>6:0&nbsp;&nbsp;</td>
<td class=bl>6:5&nbsp;&nbsp;</td>
<td class=bl>2:1 P&nbsp;&nbsp;</td>
<td class=bl>5:6 P&nbsp;&nbsp;</td>
<td class=bl>2:4&nbsp;&nbsp;</td>
<td class=bl>2:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Kobrle Michal</b>&nbsp;&nbsp;</td>
<td class=al>- Storozhenko Glib&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>4:1&nbsp;&nbsp;</td>
<td class=al>6:4&nbsp;&nbsp;</td>
<td class=al>8:3&nbsp;&nbsp;</td>
<td class=al>7:0&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><b>Caics Edgars</b>&nbsp;&nbsp;</td>
<td class=bl>- Božič Anže&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>6:5 P&nbsp;&nbsp;</td>
<td class=bl>6:5 P&nbsp;&nbsp;</td>
<td class=bl>4:3&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Nilsson Eddie</b>&nbsp;&nbsp;</td>
<td class=al>- Larsson Emil&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 1&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:3 P&nbsp;&nbsp;</td>
<td class=al>6:4&nbsp;&nbsp;</td>
<td class=al>6:1&nbsp;&nbsp;</td>
<td class=al>6:2&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><b>Petr Patrik</b>&nbsp;&nbsp;</td>
<td class=bl>- Ležík Matěj&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>5:3&nbsp;&nbsp;</td>
<td class=bl>4:0&nbsp;&nbsp;</td>
<td class=bl>5:0&nbsp;&nbsp;</td>
<td class=bl>2:5&nbsp;&nbsp;</td>
<td class=bl>6:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar>Matantsev Evgeniy&nbsp;&nbsp;</td>
<td class=al>- <b>Rekis Jekabs</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 4&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>5:2&nbsp;&nbsp;</td>
<td class=al>3:4 P&nbsp;&nbsp;</td>
<td class=al>0:5&nbsp;&nbsp;</td>
<td class=al>5:1&nbsp;&nbsp;</td>
<td class=al>2:5&nbsp;&nbsp;</td>
<td class=al>5:2&nbsp;&nbsp;</td>
<td class=al>0:3&nbsp;&nbsp;</td>
</tr><tr><td class=br>Naglis Kristaps&nbsp;&nbsp;</td>
<td class=bl>- <b>Naglis Edgars</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 4&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:0&nbsp;&nbsp;</td>
<td class=bl>2:5&nbsp;&nbsp;</td>
<td class=bl>3:6&nbsp;&nbsp;</td>
<td class=bl>4:5 P&nbsp;&nbsp;</td>
<td class=bl>5:1&nbsp;&nbsp;</td>
<td class=bl>3:4&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Lasmanis Gints</b>&nbsp;&nbsp;</td>
<td class=al>- Saulitis Mikus&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>4:7&nbsp;&nbsp;</td>
<td class=al>2:3 P&nbsp;&nbsp;</td>
<td class=al>2:0&nbsp;&nbsp;</td>
<td class=al>2:0&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>4:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>1/16</strong></font></th></tr>
<tr><td class=br><b>Kalninš Rainers (A1/1)</b>&nbsp;&nbsp;</td>
<td class=bl>- Dion Till (A2/16)&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>9:0&nbsp;&nbsp;</td>
<td class=bl>5:6&nbsp;&nbsp;</td>
<td class=bl>9:2&nbsp;&nbsp;</td>
<td class=bl>6:2&nbsp;&nbsp;</td>
<td class=bl>8:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Sládek Kuba (A1/9)</b>&nbsp;&nbsp;</td>
<td class=al>- Henttonen Ville (A2/8)&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>4:2&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>6:1&nbsp;&nbsp;</td>
<td class=al>5:0&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><b>Kobrle Michal (A2/4)</b>&nbsp;&nbsp;</td>
<td class=bl>- Kubica Miloslav (A1/13)&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:2&nbsp;&nbsp;</td>
<td class=bl>9:3&nbsp;&nbsp;</td>
<td class=bl>7:4&nbsp;&nbsp;</td>
<td class=bl>4:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar>Maděra Martin (A1/5)&nbsp;&nbsp;</td>
<td class=al>- <b>Storozhenko Glib (A2/12)</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;1 : 4&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:5&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>2:5&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>2:3 P&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><b>Caics Edgars (A1/3)</b>&nbsp;&nbsp;</td>
<td class=bl>- Fuchs Petr (A2/14)&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>5:1&nbsp;&nbsp;</td>
<td class=bl>4:3&nbsp;&nbsp;</td>
<td class=bl>4:3&nbsp;&nbsp;</td>
<td class=bl>6:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Božič Anže (A2/6)</b>&nbsp;&nbsp;</td>
<td class=al>- Boštík Michal (A1/11)&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>1:5&nbsp;&nbsp;</td>
<td class=al>5:4 P&nbsp;&nbsp;</td>
<td class=al>4:1&nbsp;&nbsp;</td>
<td class=al>8:2&nbsp;&nbsp;</td>
<td class=al>9:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><b>Nilsson Eddie (A2/2)</b>&nbsp;&nbsp;</td>
<td class=bl>- Černoch Miroslav (A1/15)&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>5:1&nbsp;&nbsp;</td>
<td class=bl>4:2&nbsp;&nbsp;</td>
<td class=bl>0:5&nbsp;&nbsp;</td>
<td class=bl>6:0&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Larsson Emil (A1/7)</b>&nbsp;&nbsp;</td>
<td class=al>- Kalninš Sandis (A2/10)&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>0:2&nbsp;&nbsp;</td>
<td class=al>5:1&nbsp;&nbsp;</td>
<td class=al>2:1 P&nbsp;&nbsp;</td>
<td class=al>3:1&nbsp;&nbsp;</td>
<td class=al>1:2 P&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
</tr><tr><td class=br><b>Petr Patrik (A1/2)</b>&nbsp;&nbsp;</td>
<td class=bl>- Mansson Truls (A2/15)&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:0&nbsp;&nbsp;</td>
<td class=bl>5:3&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>6:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Ležík Matěj (A2/7)</b>&nbsp;&nbsp;</td>
<td class=al>- Matýsek Jakub (A1/10)&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>0:2&nbsp;&nbsp;</td>
<td class=al>2:5&nbsp;&nbsp;</td>
<td class=al>2:4&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>6:1&nbsp;&nbsp;</td>
<td class=al>3:0&nbsp;&nbsp;</td>
<td class=al>1:0&nbsp;&nbsp;</td>
</tr><tr><td class=br><b>Matantsev Evgeniy (A2/3)</b>&nbsp;&nbsp;</td>
<td class=bl>- Plešák Pavel (A1/14)&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>6:4&nbsp;&nbsp;</td>
<td class=bl>6:2&nbsp;&nbsp;</td>
<td class=bl>5:4 P&nbsp;&nbsp;</td>
<td class=bl>6:4&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar>Chylík ml. Jiří (A1/6)&nbsp;&nbsp;</td>
<td class=al>- <b>Rekis Jekabs (A2/11)</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;2 : 4&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:6&nbsp;&nbsp;</td>
<td class=al>4:6&nbsp;&nbsp;</td>
<td class=al>4:1&nbsp;&nbsp;</td>
<td class=al>6:3&nbsp;&nbsp;</td>
<td class=al>2:5&nbsp;&nbsp;</td>
<td class=al>4:7&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><b>Naglis Kristaps (A1/4)</b>&nbsp;&nbsp;</td>
<td class=bl>- Hermansson Gustaf (A2/13)&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:0&nbsp;&nbsp;</td>
<td class=bl>6:2&nbsp;&nbsp;</td>
<td class=bl>6:2&nbsp;&nbsp;</td>
<td class=bl>3:4&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Naglis Edgars (A2/5)</b>&nbsp;&nbsp;</td>
<td class=al>- Kimberg Anton (A1/12)&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>7:5&nbsp;&nbsp;</td>
<td class=al>3:5&nbsp;&nbsp;</td>
<td class=al>1:4&nbsp;&nbsp;</td>
<td class=al>8:3&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>5:4 P&nbsp;&nbsp;</td>
<td class=al>3:0&nbsp;&nbsp;</td>
</tr><tr><td class=br><b>Lasmanis Gints (A2/1)</b>&nbsp;&nbsp;</td>
<td class=bl>- Klazar Matyáš (A1/16)&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 2&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>6:1&nbsp;&nbsp;</td>
<td class=bl>2:3&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>1:2&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Saulitis Mikus (A2/9)</b>&nbsp;&nbsp;</td>
<td class=al>- Lebl Kryštof (A1/8)&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:2 P&nbsp;&nbsp;</td>
<td class=al>4:2&nbsp;&nbsp;</td>
<td class=al>4:3&nbsp;&nbsp;</td>
<td class=al>5:3&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>B Finals</strong></font></th></tr>
<tr><td class=br><b>Vácha Jiří</b>&nbsp;&nbsp;</td>
<td class=bl>- Lopaur Zdeněk&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:0&nbsp;&nbsp;</td>
<td class=bl>4:2&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>B 1/2</strong></font></th></tr>
<tr><td class=ar><b>Vácha Jiří (1)</b>&nbsp;&nbsp;</td>
<td class=al>- Hudec Karol (4)&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 1&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>7:2&nbsp;&nbsp;</td>
<td class=al>7:1&nbsp;&nbsp;</td>
<td class=al>3:4&nbsp;&nbsp;</td>
<td class=al>7:0&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><b>Lopaur Zdeněk (2)</b>&nbsp;&nbsp;</td>
<td class=bl>- Janouškovec Jan (3)&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:3&nbsp;&nbsp;</td>
<td class=bl>1:3&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>6:0&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>C Finals</strong></font></th></tr>
<tr><td class=br><b>Herold Adam</b>&nbsp;&nbsp;</td>
<td class=bl>- Sedláček Josef&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>5:0&nbsp;&nbsp;</td>
<td class=bl>4:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>C 1/2</strong></font></th></tr>
<tr><td class=ar>Razkevich Mykhailo (1)&nbsp;&nbsp;</td>
<td class=al>- <b>Herold Adam (4)</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;2 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>1:2 P&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><b>Sedláček Josef (2)</b>&nbsp;&nbsp;</td>
<td class=bl>- Pohořalý Pavel (3)&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>5:4&nbsp;&nbsp;</td>
<td class=bl>2:1 P&nbsp;&nbsp;</td>
<td class=bl>5:4 P&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>D Finals</strong></font></th></tr>
<tr><td class=br><b>Gripp Gunnar</b>&nbsp;&nbsp;</td>
<td class=bl>- Bernhauser Erik&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>6:3&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>10:6&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>D 1/2</strong></font></th></tr>
<tr><td class=ar><b>Gripp Gunnar (1)</b>&nbsp;&nbsp;</td>
<td class=al>- Kadlec Daniel (4)&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 1&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>4:1&nbsp;&nbsp;</td>
<td class=al>1:2&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>3:0&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><b>Bernhauser Erik (2)</b>&nbsp;&nbsp;</td>
<td class=bl>- Pernica Vít (3)&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>7:2&nbsp;&nbsp;</td>
<td class=bl>5:3&nbsp;&nbsp;</td>
<td class=bl>1:8&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
