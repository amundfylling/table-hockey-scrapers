<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR družstva</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/pohar13.aspx">U13</a>
&nbsp;<a href="../data/pohar55.aspx">55+</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>MR družstva, 17. květen 2025</span></h2></div></div></div></div><p><div align="center">
<div align=center>
<a href="kriz.aspx">Zápasy ve skupinách (Basic and placement groups)</a><br>
<a href="MR_druzstva_playoff.aspx ">Zápasy o umístění (Placement matches)</a><br>
<br>
<a href="MR_druzstva_players.aspx">Hráči</a><br>
<a href="MR_druzstva_tour_off.aspx">Útok</a><br>
<a href="MR_druzstva_tour_def.aspx">Obrana</a><br>
</div>
<table border=0 cellpadding=2 cellspacing=0 class="rnk">
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">M</th>
<th align="center">+</th>
<th align="center">=</th>
<th align="center">-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al>Big Band "A"</td>
<td class=al>&nbsp;</td>
<td class=ar>9</td>
<td class=ar>9</td>
<td class=ar>0</td>
<td class=ar>0</td>
<td class=ar>147</td>
<td class=al>&nbsp;:&nbsp;40</td>
</tr><tr><td class=br>2.</td>
<td class=bl>THC Stiga Elites</td>
<td class=bl>&nbsp;</td>
<td class=br>9</td>
<td class=br>7</td>
<td class=br>0</td>
<td class=br>2</td>
<td class=br>134</td>
<td class=bl>&nbsp;:&nbsp;55</td>
</tr><tr><td class=ar>3.</td>
<td class=al>HCS Žabka Praha</td>
<td class=al>&nbsp;</td>
<td class=ar>9</td>
<td class=ar>8</td>
<td class=ar>0</td>
<td class=ar>1</td>
<td class=ar>155</td>
<td class=al>&nbsp;:&nbsp;42</td>
</tr><tr><td class=br>4.</td>
<td class=bl>SHC Cheb "A"</td>
<td class=bl>&nbsp;</td>
<td class=br>9</td>
<td class=br>5</td>
<td class=br>0</td>
<td class=br>4</td>
<td class=br>118</td>
<td class=bl>&nbsp;:&nbsp;79</td>
</tr><tr><td class=ar>5.</td>
<td class=al>Gladiators Plzeň</td>
<td class=al>&nbsp;</td>
<td class=ar>9</td>
<td class=ar>7</td>
<td class=ar>0</td>
<td class=ar>2</td>
<td class=ar>126</td>
<td class=al>&nbsp;:&nbsp;63</td>
</tr><tr><td class=br>6.</td>
<td class=bl>THC Třinec</td>
<td class=bl>&nbsp;</td>
<td class=br>9</td>
<td class=br>4</td>
<td class=br>0</td>
<td class=br>5</td>
<td class=br>94</td>
<td class=bl>&nbsp;:&nbsp;98</td>
</tr><tr><td class=ar>7.</td>
<td class=al>Absolut Desperation</td>
<td class=al>&nbsp;</td>
<td class=ar>9</td>
<td class=ar>5</td>
<td class=ar>0</td>
<td class=ar>4</td>
<td class=ar>104</td>
<td class=al>&nbsp;:&nbsp;75</td>
</tr><tr><td class=br>8.</td>
<td class=bl>Stiga HC Benátky</td>
<td class=bl>&nbsp;</td>
<td class=br>9</td>
<td class=br>3</td>
<td class=br>0</td>
<td class=br>6</td>
<td class=br>75</td>
<td class=bl>&nbsp;:&nbsp;102</td>
</tr><tr><td class=ar>9.</td>
<td class=al>BSE United</td>
<td class=al>&nbsp;</td>
<td class=ar>9</td>
<td class=ar>5</td>
<td class=ar>0</td>
<td class=ar>4</td>
<td class=ar>106</td>
<td class=al>&nbsp;:&nbsp;103</td>
</tr><tr><td class=br>10.</td>
<td class=bl>SHC Cheb "B"</td>
<td class=bl>&nbsp;</td>
<td class=br>9</td>
<td class=br>4</td>
<td class=br>0</td>
<td class=br>5</td>
<td class=br>85</td>
<td class=bl>&nbsp;:&nbsp;128</td>
</tr><tr><td class=ar>11.</td>
<td class=al>Big Band "B"</td>
<td class=al>&nbsp;</td>
<td class=ar>9</td>
<td class=ar>3</td>
<td class=ar>0</td>
<td class=ar>6</td>
<td class=ar>83</td>
<td class=al>&nbsp;:&nbsp;117</td>
</tr><tr><td class=br>12.</td>
<td class=bl>SHC Cheb - Veterans</td>
<td class=bl>&nbsp;</td>
<td class=br>9</td>
<td class=br>2</td>
<td class=br>0</td>
<td class=br>7</td>
<td class=br>90</td>
<td class=bl>&nbsp;:&nbsp;117</td>
</tr><tr><td class=ar>13.</td>
<td class=al>Orel Obřany</td>
<td class=al>&nbsp;</td>
<td class=ar>9</td>
<td class=ar>1</td>
<td class=ar>0</td>
<td class=ar>8</td>
<td class=ar>50</td>
<td class=al>&nbsp;:&nbsp;159</td>
</tr><tr><td class=br>14.</td>
<td class=bl>SHC Lions Cheb</td>
<td class=bl>&nbsp;</td>
<td class=br>9</td>
<td class=br>0</td>
<td class=br>0</td>
<td class=br>9</td>
<td class=br>12</td>
<td class=bl>&nbsp;:&nbsp;201</td>
</tr></table></td></tr></table></div></p>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
