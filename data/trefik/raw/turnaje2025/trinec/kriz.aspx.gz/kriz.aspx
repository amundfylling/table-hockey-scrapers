<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Třinec</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/pohar13.aspx">U13</a>
&nbsp;<a href="../data/pohar55.aspx">55+</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../trinec/index.aspx">Třinec, 29. březen 2025</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Základní skupiny (Basic groups)</a><br>
<a href="#final">Výkonnostní skupiny (Final groups)</a><br>
<a name="basic"><p class=vm>Základní skupiny (Basic groups)</p></a>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ji Chylík ml.</td><td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kL>0:1</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>7:4</td>
<td class=kW>6:0</td>
<td class=kW>9:0</td>
<td class=kW>8:0</td>
<td class=kW>6:1</td>
<td class=kW>9:0</td>
<td class=kW>9:0</td>
<td class=kW>9:2</td>
<td class=kW>9:0</td>
<td class=br>124:32</td><td class=br>+92</td>
<td class=bc>19 - 2 - 1</td>
<td class=br><strong>40</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ja Matýsek</td><td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kW>6:2</td>
<td class=kW>10:3</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>9:1</td>
<td class=kW>6:2</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>11:0</td>
<td class=kW>11:1</td>
<td class=kW>12:1</td>
<td class=br>111:30</td><td class=br>+81</td>
<td class=bc>19 - 1 - 2</td>
<td class=br><strong>39</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ku Sládek</td><td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>5:4</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=br>82:30</td><td class=br>+52</td>
<td class=bc>17 - 4 - 1</td>
<td class=br><strong>38</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Pa Petr</td><td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>6:4</td>
<td class=kW>6:4</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kW>9:2</td>
<td class=kW>9:1</td>
<td class=kW>10:1</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>10:2</td>
<td class=kW>9:3</td>
<td class=kW>8:0</td>
<td class=kW>13:3</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>8:0</td>
<td class=kW>12:0</td>
<td class=kW>11:0</td>
<td class=br>152:42</td><td class=br>+110</td>
<td class=bc>19 - 0 - 3</td>
<td class=br><strong>38</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Da Šmíd</td><td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>8:0</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=kW>9:0</td>
<td class=kW>7:0</td>
<td class=br>85:42</td><td class=br>+43</td>
<td class=bc>13 - 4 - 5</td>
<td class=br><strong>30</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Vá Pikl</td><td class=kW>1:0</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>4:6</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kW>8:3</td>
<td class=kW>9:1</td>
<td class=kW>8:0</td>
<td class=kW>7:0</td>
<td class=kW>11:2</td>
<td class=kW>9:0</td>
<td class=kW>11:0</td>
<td class=br>104:42</td><td class=br>+62</td>
<td class=bc>15 - 0 - 7</td>
<td class=br><strong>30</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Mi Černoch</td><td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>4:6</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kL>1:2</td>
<td class=kW>6:0</td>
<td class=kW>9:0</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>16:0</td>
<td class=br>87:36</td><td class=br>+51</td>
<td class=bc>13 - 3 - 6</td>
<td class=br><strong>29</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Da Matýsek</td><td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>8:2</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>8:3</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>7:3</td>
<td class=kW>6:2</td>
<td class=br>80:51</td><td class=br>+29</td>
<td class=bc>12 - 4 - 6</td>
<td class=br><strong>28</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>To Kahoun ml.</td><td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kL>2:8</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>8:1</td>
<td class=kW>8:0</td>
<td class=br>91:53</td><td class=br>+38</td>
<td class=bc>13 - 2 - 7</td>
<td class=br><strong>28</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>Ma Ženíšek</td><td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>2:9</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>2:5</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>8:2</td>
<td class=kW>7:1</td>
<td class=kW>7:2</td>
<td class=br>86:65</td><td class=br>+21</td>
<td class=bc>13 - 1 - 8</td>
<td class=br><strong>27</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>A</td><td class=d>11.</td><td class=kt>Mi Touš</td><td class=kT>4:4</td>
<td class=kL>3:10</td>
<td class=kW>3:2</td>
<td class=kL>1:9</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kT>5:5</td>
<td class=kW>5:1</td>
<td class=kW>11:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>10:0</td>
<td class=kW>7:2</td>
<td class=kW>8:2</td>
<td class=br>89:71</td><td class=br>+18</td>
<td class=bc>11 - 5 - 6</td>
<td class=br><strong>27</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>A</td><td class=d>12.</td><td class=kt>Zd Lopaur</td><td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>1:10</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>9:5</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kW>7:1</td>
<td class=kW>12:1</td>
<td class=kW>7:2</td>
<td class=kW>11:0</td>
<td class=br>91:62</td><td class=br>+29</td>
<td class=bc>12 - 2 - 8</td>
<td class=br><strong>26</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Ro Jež</td><td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kL>1:7</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>2:0</td>
<td class=kW>6:0</td>
<td class=br>53:53</td><td class=br>0</td>
<td class=bc>11 - 1 - 10</td>
<td class=br><strong>23</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>B</td><td class=d>14.</td><td class=kt>Mi Ševr</td><td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kW>7:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>7:1</td>
<td class=kW>11:0</td>
<td class=kL>2:4</td>
<td class=kW>5:4</td>
<td class=kW>4:0</td>
<td class=kW>8:1</td>
<td class=kW>8:0</td>
<td class=kW>8:0</td>
<td class=br>79:59</td><td class=br>+20</td>
<td class=bc>10 - 0 - 12</td>
<td class=br><strong>20</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>B</td><td class=d>15.</td><td class=kt>Ro Pavlica</td><td class=kL>4:7</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>2:10</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kL>3:8</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>7:4</td>
<td class=kW>8:1</td>
<td class=kW>6:1</td>
<td class=kW>8:2</td>
<td class=kW>8:0</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=br>82:81</td><td class=br>+1</td>
<td class=bc>8 - 1 - 13</td>
<td class=br><strong>17</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>B</td><td class=d>16.</td><td class=kt>On Gruncl</td><td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>4:5</td>
<td class=kL>3:9</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>0:6</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kT>5:5</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>1:7</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kW>10:0</td>
<td class=br>57:87</td><td class=br>-30</td>
<td class=bc>5 - 3 - 14</td>
<td class=br><strong>13</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>B</td><td class=d>17.</td><td class=kt>Mi Grepl</td><td class=kL>0:9</td>
<td class=kL>1:9</td>
<td class=kL>0:6</td>
<td class=kL>0:8</td>
<td class=kL>2:6</td>
<td class=kL>3:8</td>
<td class=kL>0:9</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>5:9</td>
<td class=kL>0:5</td>
<td class=kL>0:11</td>
<td class=kL>4:7</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kT>5:5</td>
<td class=kT>4:4</td>
<td class=kW>7:0</td>
<td class=br>52:123</td><td class=br>-71</td>
<td class=bc>5 - 2 - 15</td>
<td class=br><strong>12</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>B</td><td class=d>18.</td><td class=kt>Ví Pernica</td><td class=kL>0:8</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>3:13</td>
<td class=kT>1:1</td>
<td class=kL>1:9</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:11</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kW>4:2</td>
<td class=kL>1:8</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=br>42:108</td><td class=br>-66</td>
<td class=bc>4 - 2 - 16</td>
<td class=br><strong>10</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>B</td><td class=d>19.</td><td class=kt>Pe Klazar</td><td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kL>1:2</td>
<td class=kL>4:5</td>
<td class=kL>1:6</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=br>36:82</td><td class=br>-46</td>
<td class=bc>4 - 2 - 16</td>
<td class=br><strong>10</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>C</td><td class=d>20.</td><td class=kt>Ra Hrnčíř</td><td class=kL>0:9</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>2:8</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>7:0</td>
<td class=br>33:98</td><td class=br>-65</td>
<td class=bc>3 - 2 - 17</td>
<td class=br><strong>8</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>C</td><td class=d>21.</td><td class=kt>Zd Slovák</td><td class=kL>0:9</td>
<td class=kL>0:11</td>
<td class=kL>2:3</td>
<td class=kL>0:8</td>
<td class=kL>0:7</td>
<td class=kL>2:11</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>2:8</td>
<td class=kL>0:10</td>
<td class=kL>1:12</td>
<td class=kL>0:7</td>
<td class=kL>1:8</td>
<td class=kL>0:8</td>
<td class=kL>2:4</td>
<td class=kT>5:5</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>6:3</td>
<td class=br>32:139</td><td class=br>-107</td>
<td class=bc>2 - 3 - 17</td>
<td class=br><strong>7</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>C</td><td class=d>22.</td><td class=kt>Ma Grepl</td><td class=kL>2:9</td>
<td class=kL>1:11</td>
<td class=kL>2:4</td>
<td class=kL>0:12</td>
<td class=kL>0:9</td>
<td class=kL>0:9</td>
<td class=kL>1:6</td>
<td class=kL>3:7</td>
<td class=kL>1:8</td>
<td class=kL>1:7</td>
<td class=kL>2:7</td>
<td class=kL>2:7</td>
<td class=kL>0:2</td>
<td class=kL>0:8</td>
<td class=kL>1:7</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=br>32:138</td><td class=br>-106</td>
<td class=bc>1 - 2 - 19</td>
<td class=br><strong>4</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>C</td><td class=d>23.</td><td class=kt>La Hladík</td><td class=kL>0:9</td>
<td class=kL>1:12</td>
<td class=kL>1:6</td>
<td class=kL>0:11</td>
<td class=kL>0:7</td>
<td class=kL>0:11</td>
<td class=kL>0:16</td>
<td class=kL>2:6</td>
<td class=kL>0:8</td>
<td class=kL>2:7</td>
<td class=kL>2:8</td>
<td class=kL>0:11</td>
<td class=kL>0:6</td>
<td class=kL>0:8</td>
<td class=kL>0:7</td>
<td class=kL>0:10</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>0:7</td>
<td class=kL>3:6</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=br>16:172</td><td class=br>-156</td>
<td class=bc>1 - 0 - 21</td>
<td class=br><strong>2</strong></td><td class=d>23.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Slovák Zdeněk</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Grepl Miroslav</td><td class=bc>-</td><td class=bl>Grepl Matej</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Matýsek Jakub</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=blW>Šmíd David</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Pavlica Roman</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Slovák Zdeněk</td><td class=bc>-</td><td class=bl>Grepl Matej</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Grepl Miroslav</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Šmíd David</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Pavlica Roman</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=bl>Hladík Ladislav</td><td class=bc>8 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Grepl Matej</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Slovák Zdeněk</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Grepl Miroslav</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=bl>Šmíd David</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Pavlica Roman</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Hladík Ladislav</td><td class=bc>11 : 0</tr></td>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Grepl Matej</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>3 : 13</tr></td>
<tr><td class=br>Slovák Zdeněk</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Šmíd David</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Grepl Miroslav</td><td class=bc>-</td><td class=blW>Pavlica Roman</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Hladík Ladislav</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Klazar Petr</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Kahoun ml. Tomáš</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Grepl Matej</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=bl>Šmíd David</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Slovák Zdeněk</td><td class=bc>-</td><td class=blW>Pavlica Roman</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Hladík Ladislav</td><td class=bc>16 : 0</tr></td>
<tr><td class=brW>Grepl Miroslav</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Grepl Matej</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=bl>Šmíd David</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Pavlica Roman</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Hladík Ladislav</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Slovák Zdeněk</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Grepl Miroslav</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Grepl Matej</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 12</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Šmíd David</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Pavlica Roman</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Hladík Ladislav</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Kahoun ml. Tomáš</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Slovák Zdeněk</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Grepl Miroslav</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>5 : 9</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Grepl Matej</td><td class=bc>-</td><td class=blW>Šmíd David</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Pavlica Roman</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Hladík Ladislav</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Klazar Petr</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Kahoun ml. Tomáš</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Slovák Zdeněk</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>1 : 12</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Petr Patrik</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Šmíd David</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Pavlica Roman</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Grepl Matej</td><td class=bc>-</td><td class=blW>Hladík Ladislav</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Slovák Zdeněk</td><td class=bc>-</td><td class=bl>Grepl Miroslav</td><td class=bc>5 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Šmíd David</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Pavlica Roman</td><td class=bc>10 : 2</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Hladík Ladislav</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Grepl Matej</td><td class=bc>-</td><td class=blW>Kahoun ml. Tomáš</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Grepl Miroslav</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Šmíd David</td><td class=bc>-</td><td class=bl>Pavlica Roman</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Hladík Ladislav</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Kahoun ml. Tomáš</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Grepl Matej</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Grepl Miroslav</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Slovák Zdeněk</td><td class=bc>8 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Pavlica Roman</td><td class=bc>-</td><td class=bl>Hladík Ladislav</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Šmíd David</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Petr Patrik</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Grepl Matej</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Grepl Miroslav</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Slovák Zdeněk</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>11 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Hladík Ladislav</td><td class=bc>-</td><td class=blW>Klazar Petr</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pavlica Roman</td><td class=bc>-</td><td class=blW>Kahoun ml. Tomáš</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Grepl Miroslav</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Grepl Matej</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Slovák Zdeněk</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Kahoun ml. Tomáš</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Hladík Ladislav</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>1 : 12</tr></td>
<tr><td class=br>Pavlica Roman</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Grepl Miroslav</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Slovák Zdeněk</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Grepl Matej</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Hladík Ladislav</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>Pavlica Roman</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Šmíd David</td><td class=bc>-</td><td class=bl>Grepl Miroslav</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Slovák Zdeněk</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Grepl Matej</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Hladík Ladislav</td><td class=bc>-</td><td class=blW>Grepl Miroslav</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Pavlica Roman</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Šmíd David</td><td class=bc>-</td><td class=bl>Slovák Zdeněk</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Grepl Matej</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Matýsek Jakub</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=bl>Grepl Miroslav</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Hladík Ladislav</td><td class=bc>-</td><td class=blW>Slovák Zdeněk</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Pavlica Roman</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>9 : 3</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Grepl Miroslav</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=bl>Slovák Zdeněk</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Hladík Ladislav</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Pavlica Roman</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Šmíd David</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Grepl Matej</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Grepl Miroslav</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Slovák Zdeněk</td><td class=bc>11 : 2</tr></td>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Hladík Ladislav</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Pavlica Roman</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Grepl Matej</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Grepl Miroslav</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Slovák Zdeněk</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>10 : 3</tr></td>
<tr><td class=brW>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Hladík Ladislav</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Pavlica Roman</td><td class=bc>-</td><td class=bl>Grepl Matej</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Šmíd David</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Slovák Zdeněk</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Grepl Miroslav</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Klazar Petr</td><td class=bc>-</td><td class=bl>Grepl Matej</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Hladík Ladislav</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Pavlica Roman</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Slovák Zdeněk</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Grepl Miroslav</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Grepl Matej</td><td class=bc>11 : 1</tr></td>
<tr><td class=brW>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Hladík Ladislav</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>Pavlica Roman</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>4 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Slovák Zdeněk</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Grepl Miroslav</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>0 : 11</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Grepl Matej</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Hladík Ladislav</td><td class=bc>-</td><td class=blW>Šmíd David</td><td class=bc>0 : 7</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Mi Kobrle</td><td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=kW>9:2</td>
<td class=kW>7:2</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kW>11:1</td>
<td class=kW>10:1</td>
<td class=kW>9:2</td>
<td class=kW>9:0</td>
<td class=kW>7:0</td>
<td class=br>131:30</td><td class=br>+101</td>
<td class=bc>20 - 1 - 1</td>
<td class=br><strong>41</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Lu Turoň</td><td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>6:2</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>9:3</td>
<td class=kW>7:1</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kW>7:0</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>11:1</td>
<td class=kW>7:1</td>
<td class=br>108:32</td><td class=br>+76</td>
<td class=bc>19 - 1 - 2</td>
<td class=br><strong>39</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Kr Lebl</td><td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>9:0</td>
<td class=kW>2:0</td>
<td class=br>81:34</td><td class=br>+47</td>
<td class=bc>17 - 5 - 0</td>
<td class=br><strong>39</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ja Dryák</td><td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=kW>9:1</td>
<td class=kW>8:0</td>
<td class=kW>6:0</td>
<td class=br>102:39</td><td class=br>+63</td>
<td class=bc>16 - 2 - 4</td>
<td class=br><strong>34</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Pa Plešák</td><td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kW>1:0</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>8:2</td>
<td class=kW>4:1</td>
<td class=kW>8:3</td>
<td class=kW>5:0</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=kW>10:0</td>
<td class=kW>8:0</td>
<td class=br>93:45</td><td class=br>+48</td>
<td class=bc>15 - 4 - 3</td>
<td class=br><strong>34</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Pe Turoň</td><td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kW>6:2</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kW>10:0</td>
<td class=kW>3:0</td>
<td class=br>79:43</td><td class=br>+36</td>
<td class=bc>13 - 5 - 4</td>
<td class=br><strong>31</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>To Waclawek</td><td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=kT>5:5</td>
<td class=kW>6:3</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=br>79:47</td><td class=br>+32</td>
<td class=bc>12 - 5 - 5</td>
<td class=br><strong>29</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>To Bucek</td><td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>7:2</td>
<td class=kW>8:0</td>
<td class=kW>3:1</td>
<td class=br>74:57</td><td class=br>+17</td>
<td class=bc>11 - 4 - 7</td>
<td class=br><strong>26</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Da Dvořáček</td><td class=kL>2:7</td>
<td class=kL>3:9</td>
<td class=kL>0:2</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>9:0</td>
<td class=kW>3:0</td>
<td class=br>66:54</td><td class=br>+12</td>
<td class=bc>11 - 4 - 7</td>
<td class=br><strong>26</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>Vl Kraus</td><td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kT>5:5</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kT>1:1</td>
<td class=kW>9:0</td>
<td class=kW>4:0</td>
<td class=br>71:60</td><td class=br>+11</td>
<td class=bc>9 - 6 - 7</td>
<td class=br><strong>24</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>A</td><td class=d>11.</td><td class=kt>Vo Kraus</td><td class=kL>1:6</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>9:0</td>
<td class=kW>7:0</td>
<td class=br>67:56</td><td class=br>+11</td>
<td class=bc>9 - 5 - 8</td>
<td class=br><strong>23</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>A</td><td class=d>12.</td><td class=kt>Da Cibulka</td><td class=kL>2:9</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kL>0:1</td>
<td class=kW>4:0</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>11:0</td>
<td class=kW>3:0</td>
<td class=br>60:51</td><td class=br>+9</td>
<td class=bc>8 - 6 - 8</td>
<td class=br><strong>22</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Al Krejza</td><td class=kL>2:7</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kT>0:0</td>
<td class=kL>3:4</td>
<td class=kW>7:0</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>9:2</td>
<td class=kW>7:0</td>
<td class=br>73:52</td><td class=br>+21</td>
<td class=bc>8 - 5 - 9</td>
<td class=br><strong>21</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>B</td><td class=d>14.</td><td class=kt>Jo Vomáčka</td><td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>9:4</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kW>2:0</td>
<td class=kW>9:3</td>
<td class=kW>3:0</td>
<td class=br>60:63</td><td class=br>-3</td>
<td class=bc>9 - 2 - 11</td>
<td class=br><strong>20</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>B</td><td class=d>15.</td><td class=kt>Hy Nechutný</td><td class=kL>3:5</td>
<td class=kL>0:7</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kT>0:0</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>8:1</td>
<td class=kW>1:0</td>
<td class=br>42:65</td><td class=br>-23</td>
<td class=bc>7 - 4 - 11</td>
<td class=br><strong>18</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>B</td><td class=d>16.</td><td class=kt>Ro Vomáčka</td><td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>2:8</td>
<td class=kW>4:3</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=br>44:71</td><td class=br>-27</td>
<td class=bc>8 - 2 - 12</td>
<td class=br><strong>18</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>B</td><td class=d>17.</td><td class=kt>An Šurýn</td><td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kL>0:3</td>
<td class=kW>3:0</td>
<td class=kL>0:7</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=br>46:61</td><td class=br>-15</td>
<td class=bc>6 - 3 - 13</td>
<td class=br><strong>15</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>B</td><td class=d>18.</td><td class=kt>To Halama</td><td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kL>3:8</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>4:9</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>9:0</td>
<td class=kW>2:0</td>
<td class=br>47:68</td><td class=br>-21</td>
<td class=bc>5 - 4 - 13</td>
<td class=br><strong>14</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>B</td><td class=d>19.</td><td class=kt>Ji Junek</td><td class=kL>1:11</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kW>6:1</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>13:1</td>
<td class=kW>4:0</td>
<td class=br>54:89</td><td class=br>-35</td>
<td class=bc>5 - 2 - 15</td>
<td class=br><strong>12</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>C</td><td class=d>20.</td><td class=kt>Ma Moravec</td><td class=kL>1:10</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>3:6</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>0:7</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=br>32:97</td><td class=br>-65</td>
<td class=bc>5 - 1 - 16</td>
<td class=br><strong>11</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>C</td><td class=d>21.</td><td class=kt>Mi Moravec</td><td class=kL>2:9</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>1:9</td>
<td class=kL>0:5</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>10:0</td>
<td class=kW>5:0</td>
<td class=br>41:85</td><td class=br>-44</td>
<td class=bc>2 - 3 - 17</td>
<td class=br><strong>7</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>C</td><td class=d>22.</td><td class=kt>Al Fátor</td><td class=kL>0:9</td>
<td class=kL>1:11</td>
<td class=kL>0:9</td>
<td class=kL>0:8</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:7</td>
<td class=kL>0:8</td>
<td class=kL>0:9</td>
<td class=kL>0:9</td>
<td class=kL>0:9</td>
<td class=kL>0:11</td>
<td class=kL>2:9</td>
<td class=kL>3:9</td>
<td class=kL>1:8</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>0:9</td>
<td class=kL>1:13</td>
<td class=kL>1:3</td>
<td class=kL>0:10</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=br>14:177</td><td class=br>-163</td>
<td class=bc>1 - 0 - 21</td>
<td class=br><strong>2</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>C</td><td class=d>23.</td><td class=kt>Ra Hrčková</td><td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>0:2</td>
<td class=kL>0:6</td>
<td class=kL>0:8</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>0:3</td>
<td class=kL>0:7</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=br>6:94</td><td class=br>-88</td>
<td class=bc>0 - 0 - 22</td>
<td class=br><strong>0</strong></td><td class=d>23.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Halama Tomáš</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Fátor Aleš</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Waclawek Tomáš</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Junek Jiří</td><td class=bc>-</td><td class=blW>Turoň Lukáš</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Dryák Jan</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Cibulka David</td><td class=bc>-</td><td class=bl>Turoň Petr</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Hrčková Radka</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Fátor Aleš</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Halama Tomáš</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Turoň Lukáš</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Waclawek Tomáš</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Junek Jiří</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=bl>Turoň Petr</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Dryák Jan</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Cibulka David</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Fátor Aleš</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Turoň Lukáš</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Halama Tomáš</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Waclawek Tomáš</td><td class=bc>-</td><td class=blW>Turoň Petr</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Junek Jiří</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Vomáčka Roman</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Dryák Jan</td><td class=bc>-</td><td class=bl>Hrčková Radka</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Fátor Aleš</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Turoň Lukáš</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Halama Tomáš</td><td class=bc>-</td><td class=blW>Turoň Petr</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Waclawek Tomáš</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Junek Jiří</td><td class=bc>-</td><td class=bl>Hrčková Radka</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Cibulka David</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Fátor Aleš</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Turoň Lukáš</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Turoň Petr</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Halama Tomáš</td><td class=bc>-</td><td class=blW>Vomáčka Roman</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Hrčková Radka</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Waclawek Tomáš</td><td class=bc>-</td><td class=bl>Cibulka David</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Junek Jiří</td><td class=bc>-</td><td class=blW>Dryák Jan</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Fátor Aleš</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=blW>Turoň Lukáš</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Turoň Petr</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Hrčková Radka</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Halama Tomáš</td><td class=bc>-</td><td class=bl>Cibulka David</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Dryák Jan</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Waclawek Tomáš</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Turoň Lukáš</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Fátor Aleš</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Turoň Petr</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Hrčková Radka</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Cibulka David</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Dryák Jan</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Halama Tomáš</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Junek Jiří</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Turoň Lukáš</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Fátor Aleš</td><td class=bc>-</td><td class=blW>Turoň Petr</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Hrčková Radka</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Cibulka David</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Dryák Jan</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Junek Jiří</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Halama Tomáš</td><td class=bc>-</td><td class=blW>Waclawek Tomáš</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Turoň Lukáš</td><td class=bc>-</td><td class=blW>Turoň Petr</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Fátor Aleš</td><td class=bc>-</td><td class=blW>Vomáčka Roman</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Hrčková Radka</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Cibulka David</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Dryák Jan</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Junek Jiří</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Waclawek Tomáš</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Turoň Petr</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Turoň Lukáš</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Hrčková Radka</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Fátor Aleš</td><td class=bc>-</td><td class=blW>Cibulka David</td><td class=bc>0 : 11</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Dryák Jan</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Junek Jiří</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Waclawek Tomáš</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Halama Tomáš</td><td class=bc>9 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Turoň Petr</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Hrčková Radka</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Turoň Lukáš</td><td class=bc>-</td><td class=bl>Cibulka David</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Dryák Jan</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fátor Aleš</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Junek Jiří</td><td class=bc>11 : 1</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Waclawek Tomáš</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Halama Tomáš</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Turoň Petr</td><td class=bc>-</td><td class=bl>Hrčková Radka</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Cibulka David</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Dryák Jan</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Turoň Lukáš</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Junek Jiří</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Fátor Aleš</td><td class=bc>-</td><td class=blW>Waclawek Tomáš</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Halama Tomáš</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Vomáčka Roman</td><td class=bc>-</td><td class=bl>Hrčková Radka</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=bl>Cibulka David</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Turoň Petr</td><td class=bc>-</td><td class=bl>Dryák Jan</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=bl>Junek Jiří</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Turoň Lukáš</td><td class=bc>-</td><td class=bl>Waclawek Tomáš</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Fátor Aleš</td><td class=bc>-</td><td class=blW>Halama Tomáš</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Hrčková Radka</td><td class=bc>-</td><td class=blW>Cibulka David</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Dryák Jan</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Turoň Petr</td><td class=bc>-</td><td class=bl>Junek Jiří</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Waclawek Tomáš</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Turoň Lukáš</td><td class=bc>-</td><td class=bl>Halama Tomáš</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Fátor Aleš</td><td class=bc>-</td><td class=blW>Vomáčka Josef</td><td class=bc>3 : 9</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Cibulka David</td><td class=bc>-</td><td class=bl>Dryák Jan</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Hrčková Radka</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Vomáčka Roman</td><td class=bc>-</td><td class=bl>Junek Jiří</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Waclawek Tomáš</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Turoň Petr</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Halama Tomáš</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Turoň Lukáš</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Fátor Aleš</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Dryák Jan</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Cibulka David</td><td class=bc>-</td><td class=bl>Junek Jiří</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Hrčková Radka</td><td class=bc>-</td><td class=blW>Waclawek Tomáš</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Vomáčka Roman</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=bl>Halama Tomáš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Turoň Petr</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Turoň Lukáš</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Fátor Aleš</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>0 : 9</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Junek Jiří</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Dryák Jan</td><td class=bc>-</td><td class=bl>Waclawek Tomáš</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Cibulka David</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Hrčková Radka</td><td class=bc>-</td><td class=blW>Halama Tomáš</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Turoň Petr</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Turoň Lukáš</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Junek Jiří</td><td class=bc>-</td><td class=blW>Waclawek Tomáš</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Dryák Jan</td><td class=bc>-</td><td class=bl>Halama Tomáš</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Cibulka David</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hrčková Radka</td><td class=bc>-</td><td class=blW>Vomáčka Josef</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Turoň Petr</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 10</tr></td>
<tr><td class=brW>Turoň Lukáš</td><td class=bc>-</td><td class=bl>Fátor Aleš</td><td class=bc>11 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Waclawek Tomáš</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Junek Jiří</td><td class=bc>-</td><td class=bl>Halama Tomáš</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Dryák Jan</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Cibulka David</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Hrčková Radka</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Turoň Petr</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Fátor Aleš</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Halama Tomáš</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Waclawek Tomáš</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Junek Jiří</td><td class=bc>-</td><td class=blW>Vomáčka Josef</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Dryák Jan</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Cibulka David</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Hrčková Radka</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Fátor Aleš</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Turoň Petr</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Turoň Lukáš</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Halama Tomáš</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Vomáčka Josef</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Waclawek Tomáš</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Junek Jiří</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Dryák Jan</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Cibulka David</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Hrčková Radka</td><td class=bc>-</td><td class=blW>Fátor Aleš</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vomáčka Roman</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Turoň Lukáš</td><td class=bc>3 : 9</tr></td>
<tr><td class=brW>Turoň Petr</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Halama Tomáš</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Waclawek Tomáš</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Junek Jiří</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>2 : 9</tr></td>
<tr><td class=brW>Dryák Jan</td><td class=bc>-</td><td class=bl>Fátor Aleš</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Cibulka David</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hrčková Radka</td><td class=bc>-</td><td class=blW>Turoň Lukáš</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Halama Tomáš</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Waclawek Tomáš</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Junek Jiří</td><td class=bc>-</td><td class=bl>Fátor Aleš</td><td class=bc>13 : 1</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Dryák Jan</td><td class=bc>-</td><td class=bl>Turoň Lukáš</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Cibulka David</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Hrčková Radka</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Vomáčka Roman</td><td class=bc>-</td><td class=bl>Turoň Petr</td><td class=bc>4 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<hr><a name="final"><p class=vm>Výkonnostní skupiny (Final groups)</p></a>
<p class=v>Group A</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt>Mi Kobrle</td><td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>3:5 K</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kT>4:4 K</td>
<td class=kW>4:2</td>
<td class=kW>4:2 K</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>5:2 K</td>
<td class=kW>4:0 K</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>9:2 K</td>
<td class=kW>7:0</td>
<td class=kW>4:1</td>
<td class=kW>2:0 K</td>
<td class=kW>6:3</td>
<td class=kW>4:0 K</td>
<td class=kW>5:3</td>
<td class=kW>7:2 K</td>
<td class=kW>5:0 K</td>
<td class=kW>6:1 K</td>
<td class=br>98:40</td><td class=br>+58</td>
<td class=bc>16 - 6 - 1</td>
<td class=br><strong>38</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt>Ji Chylík ml.</td><td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:3 K</td>
<td class=kW>3:2 K</td>
<td class=kT>3:3</td>
<td class=kT>2:2 K</td>
<td class=kW>3:0</td>
<td class=kW>5:2 K</td>
<td class=kW>6:2 K</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kW>4:1 K</td>
<td class=kW>4:3 K</td>
<td class=kW>4:1</td>
<td class=kW>5:2 K</td>
<td class=kL>0:1 K</td>
<td class=kW>3:1</td>
<td class=kW>7:1 K</td>
<td class=kW>3:1</td>
<td class=kT>4:4 K</td>
<td class=kW>6:0</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=br>89:41</td><td class=br>+48</td>
<td class=bc>17 - 4 - 2</td>
<td class=br><strong>38</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt>Lu Turoň</td><td class=kW>5:3 K</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kT>2:2 K</td>
<td class=kW>3:1</td>
<td class=kL>3:4 K</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kL>1:2 K</td>
<td class=kW>6:2 K</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>4:2 K</td>
<td class=kW>10:4</td>
<td class=kW>3:0</td>
<td class=kW>4:0 K</td>
<td class=kW>2:0</td>
<td class=kW>5:2 K</td>
<td class=kW>4:2</td>
<td class=kW>9:3 K</td>
<td class=kW>7:1 K</td>
<td class=kW>7:2 K</td>
<td class=br>98:47</td><td class=br>+51</td>
<td class=bc>18 - 1 - 4</td>
<td class=br><strong>37</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt>Pa Petr</td><td class=kT>3:3</td>
<td class=kL>3:4 K</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kL>2:5 K</td>
<td class=kW>4:0</td>
<td class=kL>2:3 K</td>
<td class=kW>4:1</td>
<td class=kW>6:4 K</td>
<td class=kW>7:2 K</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>10:1 K</td>
<td class=kW>6:1 K</td>
<td class=kW>9:2</td>
<td class=kW>4:2 K</td>
<td class=kW>6:4 K</td>
<td class=kW>4:1</td>
<td class=kW>9:2 K</td>
<td class=kW>5:1</td>
<td class=kW>9:1 K</td>
<td class=kW>8:0</td>
<td class=kW>7:5</td>
<td class=kW>4:1</td>
<td class=br>120:50</td><td class=br>+70</td>
<td class=bc>18 - 1 - 4</td>
<td class=br><strong>37</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>Ja Matýsek</td><td class=kT>3:3</td>
<td class=kL>2:3 K</td>
<td class=kL>2:4</td>
<td class=kW>5:2 K</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kL>0:3 K</td>
<td class=kW>3:1</td>
<td class=kT>1:1 K</td>
<td class=kW>2:1 K</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>3:0 K</td>
<td class=kW>4:1 K</td>
<td class=kL>1:2</td>
<td class=kW>5:4 K</td>
<td class=kW>3:0 K</td>
<td class=kW>4:2</td>
<td class=kW>6:2 K</td>
<td class=kW>4:3</td>
<td class=kW>10:3 K</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=br>74:43</td><td class=br>+31</td>
<td class=bc>15 - 4 - 4</td>
<td class=br><strong>34</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>Kr Lebl</td><td class=kT>4:4 K</td>
<td class=kT>3:3</td>
<td class=kT>2:2 K</td>
<td class=kL>0:4</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>2:1 K</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>3:3 K</td>
<td class=kT>4:4 K</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>4:2 K</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>2:1 K</td>
<td class=kW>5:3</td>
<td class=kW>4:3 K</td>
<td class=kW>2:1</td>
<td class=kW>2:0 K</td>
<td class=kW>4:0 K</td>
<td class=kW>3:2 K</td>
<td class=br>64:44</td><td class=br>+20</td>
<td class=bc>13 - 7 - 3</td>
<td class=br><strong>33</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Ku Sládek</td><td class=kL>2:4</td>
<td class=kT>2:2 K</td>
<td class=kL>1:3</td>
<td class=kW>3:2 K</td>
<td class=kW>3:0 K</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>3:0 K</td>
<td class=kW>3:1 K</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kT>3:3 K</td>
<td class=kT>1:1 K</td>
<td class=kL>1:3</td>
<td class=kT>1:1 K</td>
<td class=kW>5:2 K</td>
<td class=kL>3:4</td>
<td class=kW>4:2 K</td>
<td class=kT>1:1</td>
<td class=kL>2:3 K</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kW>5:1</td>
<td class=br>60:49</td><td class=br>+11</td>
<td class=bc>10 - 7 - 6</td>
<td class=br><strong>27</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>Ja Dryák</td><td class=kL>2:4 K</td>
<td class=kL>0:3</td>
<td class=kW>4:3 K</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>1:2 K</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>1:0</td>
<td class=kL>1:4 K</td>
<td class=kW>6:2 K</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kL>1:3 K</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kT>4:4 K</td>
<td class=kL>1:3</td>
<td class=kW>5:0 K</td>
<td class=kW>8:1</td>
<td class=kW>6:2 K</td>
<td class=kW>4:3 K</td>
<td class=kW>5:3 K</td>
<td class=br>73:59</td><td class=br>+14</td>
<td class=bc>12 - 2 - 9</td>
<td class=br><strong>26</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>Mi Černoch</td><td class=kT>1:1</td>
<td class=kL>2:5 K</td>
<td class=kL>2:3</td>
<td class=kL>4:6 K</td>
<td class=kT>1:1 K</td>
<td class=kW>3:2</td>
<td class=kL>0:3 K</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kT>1:1 K</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kW>3:2 K</td>
<td class=kL>1:3 K</td>
<td class=kW>3:1</td>
<td class=kW>5:2 K</td>
<td class=kL>0:3 K</td>
<td class=kT>2:2</td>
<td class=kW>3:1 K</td>
<td class=kW>2:1</td>
<td class=kT>1:1 K</td>
<td class=kL>1:2</td>
<td class=kW>5:0 K</td>
<td class=kW>2:1</td>
<td class=br>50:48</td><td class=br>+2</td>
<td class=bc>9 - 7 - 7</td>
<td class=br><strong>25</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Da Matýsek</td><td class=kL>2:3</td>
<td class=kL>2:6 K</td>
<td class=kW>3:0</td>
<td class=kL>2:7 K</td>
<td class=kL>1:2 K</td>
<td class=kW>3:2</td>
<td class=kL>1:3 K</td>
<td class=kL>0:1</td>
<td class=kT>1:1 K</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>4:2 K</td>
<td class=kT>1:1 K</td>
<td class=kL>1:3</td>
<td class=kW>8:2 K</td>
<td class=kL>2:3 K</td>
<td class=kL>2:7</td>
<td class=kT>4:4 K</td>
<td class=kL>1:3</td>
<td class=kW>4:1 K</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>5:0 K</td>
<td class=br>61:60</td><td class=br>+1</td>
<td class=bc>9 - 4 - 10</td>
<td class=br><strong>22</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>Pe Turoň</td><td class=kL>2:5 K</td>
<td class=kW>5:3</td>
<td class=kW>2:1 K</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kT>3:3 K</td>
<td class=kL>1:2</td>
<td class=kW>4:1 K</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>4:4 K</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3 K</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kW>4:2 K</td>
<td class=kT>3:3</td>
<td class=kW>2:1 K</td>
<td class=kW>7:1</td>
<td class=kT>2:2 K</td>
<td class=kW>3:1 K</td>
<td class=kW>5:1 K</td>
<td class=br>63:63</td><td class=br>0</td>
<td class=bc>8 - 6 - 9</td>
<td class=br><strong>22</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>Pa Plešák</td><td class=kL>0:4 K</td>
<td class=kL>2:3</td>
<td class=kL>2:6 K</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kT>4:4 K</td>
<td class=kL>4:5</td>
<td class=kL>2:6 K</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kT>4:4 K</td>
<td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kL>1:2</td>
<td class=kW>6:1 K</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>4:3 K</td>
<td class=kT>3:3</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kW>2:1 K</td>
<td class=kT>4:4 K</td>
<td class=kW>1:0 K</td>
<td class=br>62:64</td><td class=br>-2</td>
<td class=bc>7 - 8 - 8</td>
<td class=br><strong>22</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt>Zd Lopaur</td><td class=kL>1:6</td>
<td class=kL>1:4 K</td>
<td class=kL>2:3</td>
<td class=kL>1:10 K</td>
<td class=kL>0:3 K</td>
<td class=kL>0:3</td>
<td class=kT>3:3 K</td>
<td class=kT>3:3</td>
<td class=kL>2:3 K</td>
<td class=kL>2:4 K</td>
<td class=kW>4:2</td>
<td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kW>5:3 K</td>
<td class=kW>4:1</td>
<td class=kT>2:2 K</td>
<td class=kW>4:2 K</td>
<td class=kW>5:2</td>
<td class=kW>5:2 K</td>
<td class=kT>2:2</td>
<td class=kL>3:6 K</td>
<td class=kW>6:2</td>
<td class=kL>1:3</td>
<td class=kW>1:0</td>
<td class=br>60:76</td><td class=br>-16</td>
<td class=bc>8 - 4 - 11</td>
<td class=br><strong>20</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt>Da Šmíd</td><td class=kT>2:2</td>
<td class=kL>3:4 K</td>
<td class=kL>3:4</td>
<td class=kL>1:6 K</td>
<td class=kL>1:4 K</td>
<td class=kL>2:4</td>
<td class=kT>1:1 K</td>
<td class=kL>3:5</td>
<td class=kW>3:1 K</td>
<td class=kT>1:1 K</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kL>3:5 K</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:2 K</td>
<td class=kW>4:3 K</td>
<td class=kW>2:1</td>
<td class=kL>2:5 K</td>
<td class=kW>3:0</td>
<td class=kT>2:2 K</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=br>53:63</td><td class=br>-10</td>
<td class=bc>8 - 4 - 11</td>
<td class=br><strong>20</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt>Da Cibulka</td><td class=kL>2:9 K</td>
<td class=kL>1:4</td>
<td class=kL>2:4 K</td>
<td class=kL>2:9</td>
<td class=kW>2:1</td>
<td class=kL>2:4 K</td>
<td class=kW>3:1</td>
<td class=kW>3:1 K</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1 K</td>
<td class=kL>1:6 K</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kL>0:3 K</td>
<td class=kL>2:6</td>
<td class=kL>3:4 K</td>
<td class=kL>3:5</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2 K</td>
<td class=br>49:74</td><td class=br>-25</td>
<td class=bc>8 - 3 - 12</td>
<td class=br><strong>19</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt>To Kahoun ml.</td><td class=kL>0:7</td>
<td class=kL>2:5 K</td>
<td class=kL>4:10</td>
<td class=kL>2:4 K</td>
<td class=kL>4:5 K</td>
<td class=kL>1:3</td>
<td class=kT>1:1 K</td>
<td class=kL>1:2</td>
<td class=kL>2:5 K</td>
<td class=kL>2:8 K</td>
<td class=kW>4:1</td>
<td class=kL>1:5</td>
<td class=kT>2:2 K</td>
<td class=kL>2:3 K</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:2 K</td>
<td class=kW>3:2</td>
<td class=kW>3:2 K</td>
<td class=kW>3:1</td>
<td class=kW>7:1 K</td>
<td class=kW>4:0</td>
<td class=kW>5:0 K</td>
<td class=kL>3:5</td>
<td class=br>60:78</td><td class=br>-18</td>
<td class=bc>8 - 2 - 13</td>
<td class=br><strong>18</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Vá Pikl</td><td class=kL>1:4</td>
<td class=kW>1:0 K</td>
<td class=kL>0:3</td>
<td class=kL>4:6 K</td>
<td class=kL>0:3 K</td>
<td class=kL>1:5</td>
<td class=kL>2:5 K</td>
<td class=kL>2:5</td>
<td class=kW>3:0 K</td>
<td class=kW>3:2 K</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kL>2:4 K</td>
<td class=kL>3:4 K</td>
<td class=kL>0:3</td>
<td class=kL>2:3 K</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>2:1 K</td>
<td class=kL>1:2</td>
<td class=kW>4:1 K</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=br>48:65</td><td class=br>-17</td>
<td class=bc>9 - 0 - 14</td>
<td class=br><strong>18</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>To Waclawek</td><td class=kL>0:2 K</td>
<td class=kL>1:3</td>
<td class=kL>0:4 K</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2 K</td>
<td class=kW>4:3</td>
<td class=kT>4:4 K</td>
<td class=kT>2:2</td>
<td class=kW>7:2</td>
<td class=kL>2:4 K</td>
<td class=kL>3:4 K</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kW>3:0 K</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kT>3:3 K</td>
<td class=kW>2:0</td>
<td class=kW>6:0 K</td>
<td class=kT>5:5 K</td>
<td class=kW>6:3 K</td>
<td class=br>63:62</td><td class=br>+1</td>
<td class=bc>7 - 4 - 12</td>
<td class=br><strong>18</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Ma Ženíšek</td><td class=kL>3:6</td>
<td class=kL>1:7 K</td>
<td class=kL>0:2</td>
<td class=kL>2:9 K</td>
<td class=kL>2:6 K</td>
<td class=kL>3:5</td>
<td class=kL>2:4 K</td>
<td class=kW>3:1</td>
<td class=kL>1:3 K</td>
<td class=kT>4:4 K</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>2:5 K</td>
<td class=kW>5:2 K</td>
<td class=kW>6:2</td>
<td class=kL>2:3 K</td>
<td class=kL>1:2 K</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:3 K</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kW>5:0 K</td>
<td class=br>61:84</td><td class=br>-23</td>
<td class=bc>7 - 3 - 13</td>
<td class=br><strong>17</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>To Bucek</td><td class=kL>0:4 K</td>
<td class=kL>1:3</td>
<td class=kL>2:5 K</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>3:4 K</td>
<td class=kT>1:1</td>
<td class=kL>0:5 K</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>1:2 K</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kW>4:3 K</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3 K</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kW>5:2 K</td>
<td class=kW>3:1 K</td>
<td class=kT>2:2 K</td>
<td class=br>50:63</td><td class=br>-13</td>
<td class=bc>6 - 5 - 12</td>
<td class=br><strong>17</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Mi Touš</td><td class=kL>3:5</td>
<td class=kT>4:4 K</td>
<td class=kL>2:4</td>
<td class=kL>1:9 K</td>
<td class=kL>3:10 K</td>
<td class=kL>1:2</td>
<td class=kW>3:2 K</td>
<td class=kL>1:8</td>
<td class=kT>1:1 K</td>
<td class=kL>1:4 K</td>
<td class=kL>1:7</td>
<td class=kT>1:1</td>
<td class=kW>6:3 K</td>
<td class=kT>2:2 K</td>
<td class=kW>5:3</td>
<td class=kL>1:7 K</td>
<td class=kL>1:4 K</td>
<td class=kL>0:2</td>
<td class=kL>3:5 K</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=br>49:97</td><td class=br>-48</td>
<td class=bc>5 - 4 - 14</td>
<td class=br><strong>14</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Da Dvořáček</td><td class=kL>2:7 K</td>
<td class=kL>0:6</td>
<td class=kL>3:9 K</td>
<td class=kL>0:8</td>
<td class=kL>1:2</td>
<td class=kL>0:2 K</td>
<td class=kT>2:2</td>
<td class=kL>2:6 K</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kT>2:2 K</td>
<td class=kL>1:2 K</td>
<td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kT>1:1 K</td>
<td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=kL>0:6 K</td>
<td class=kL>1:2</td>
<td class=kL>2:5 K</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:1 K</td>
<td class=kT>1:1 K</td>
<td class=br>40:84</td><td class=br>-44</td>
<td class=bc>4 - 4 - 15</td>
<td class=br><strong>12</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Vl Kraus</td><td class=kL>0:5 K</td>
<td class=kL>0:7</td>
<td class=kL>1:7 K</td>
<td class=kL>5:7</td>
<td class=kL>3:4</td>
<td class=kL>0:4 K</td>
<td class=kL>4:5</td>
<td class=kL>3:4 K</td>
<td class=kL>0:5 K</td>
<td class=kL>1:3</td>
<td class=kL>1:3 K</td>
<td class=kT>4:4 K</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kT>2:2 K</td>
<td class=kL>0:5 K</td>
<td class=kL>1:4</td>
<td class=kT>5:5 K</td>
<td class=kW>5:2</td>
<td class=kL>1:3 K</td>
<td class=kW>4:2</td>
<td class=kL>1:5 K</td>
<td class=kx>*</td>
<td class=kW>7:3 K</td>
<td class=br>54:94</td><td class=br>-40</td>
<td class=bc>4 - 3 - 16</td>
<td class=br><strong>11</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Vo Kraus</td><td class=kL>1:6 K</td>
<td class=kL>1:5</td>
<td class=kL>2:7 K</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3 K</td>
<td class=kL>1:5</td>
<td class=kL>3:5 K</td>
<td class=kL>1:2</td>
<td class=kL>0:5 K</td>
<td class=kL>1:5 K</td>
<td class=kL>0:1 K</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2 K</td>
<td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kL>3:6 K</td>
<td class=kL>0:5 K</td>
<td class=kT>2:2 K</td>
<td class=kL>1:3</td>
<td class=kT>1:1 K</td>
<td class=kL>3:7 K</td>
<td class=kx>*</td>
<td class=br>34:85</td><td class=br>-51</td>
<td class=bc>2 - 3 - 18</td>
<td class=br><strong>7</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Matýsek Jakub</td><td class=bc>-</td><td class=blW>Turoň Lukáš</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Dryák Jan</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Šmíd David</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Turoň Petr</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Waclawek Tomáš</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Cibulka David</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Turoň Lukáš</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Dryák Jan</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Turoň Petr</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Šmíd David</td><td class=bc>-</td><td class=bl>Waclawek Tomáš</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Cibulka David</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Dryák Jan</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Turoň Petr</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Waclawek Tomáš</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Cibulka David</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Turoň Lukáš</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Dryák Jan</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Turoň Petr</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Waclawek Tomáš</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>7 : 5</tr></td>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Cibulka David</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Turoň Lukáš</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Turoň Petr</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Waclawek Tomáš</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Cibulka David</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Turoň Lukáš</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Dryák Jan</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Turoň Petr</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=bl>Waclawek Tomáš</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Matýsek Jakub</td><td class=bc>-</td><td class=blW>Cibulka David</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Petr Patrik</td><td class=bc>-</td><td class=blW>Turoň Lukáš</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Dryák Jan</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Turoň Petr</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Waclawek Tomáš</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Kahoun ml. Tomáš</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Cibulka David</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Matýsek Jakub</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Turoň Lukáš</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Dryák Jan</td><td class=bc>-</td><td class=bl>Šmíd David</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Turoň Petr</td><td class=bc>-</td><td class=blW>Kahoun ml. Tomáš</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Waclawek Tomáš</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Cibulka David</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Turoň Lukáš</td><td class=bc>-</td><td class=bl>Šmíd David</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Dryák Jan</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Dryák Jan</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Turoň Petr</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Waclawek Tomáš</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Cibulka David</td><td class=bc>-</td><td class=bl>Šmíd David</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Turoň Lukáš</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Dryák Jan</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Turoň Petr</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Waclawek Tomáš</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Šmíd David</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Cibulka David</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Turoň Lukáš</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>10 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Turoň Lukáš</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Dryák Jan</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=bl>Matýsek Jakub</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Turoň Petr</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Waclawek Tomáš</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Šmíd David</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Cibulka David</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Turoň Lukáš</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Matýsek Jakub</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Dryák Jan</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Turoň Petr</td><td class=bc>-</td><td class=blW>Šmíd David</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Waclawek Tomáš</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Kahoun ml. Tomáš</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Cibulka David</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>3 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Ro Pavlica</td><td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kL>3:5</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>9:1</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>9:2</td>
<td class=br>56:17</td><td class=br>+39</td>
<td class=bc>11 - 1 - 1</td>
<td class=br><strong>23</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>An Šurýn</td><td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kL>2:8</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=br>44:25</td><td class=br>+19</td>
<td class=bc>9 - 2 - 2</td>
<td class=br><strong>20</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Ro Jež</td><td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>8:0</td>
<td class=br>45:23</td><td class=br>+22</td>
<td class=bc>9 - 2 - 2</td>
<td class=br><strong>20</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Al Krejza</td><td class=kW>5:3</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>8:1</td>
<td class=br>44:24</td><td class=br>+20</td>
<td class=bc>9 - 1 - 3</td>
<td class=br><strong>19</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=d>5.</td><td class=kt>Mi Ševr</td><td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>3:6</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>8:5</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=br>46:31</td><td class=br>+15</td>
<td class=bc>8 - 1 - 4</td>
<td class=br><strong>17</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=d>6.</td><td class=kt>Jo Vomáčka</td><td class=kL>0:3</td>
<td class=kW>8:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=br>43:31</td><td class=br>+12</td>
<td class=bc>7 - 1 - 5</td>
<td class=br><strong>15</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/4</td><td class=d>7.</td><td class=kt>Hy Nechutný</td><td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=br>23:24</td><td class=br>-1</td>
<td class=bc>5 - 3 - 5</td>
<td class=br><strong>13</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/4</td><td class=d>8.</td><td class=kt>Pe Klazar</td><td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=br>29:37</td><td class=br>-8</td>
<td class=bc>5 - 1 - 7</td>
<td class=br><strong>11</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Ví Pernica</td><td class=kL>1:9</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=br>30:37</td><td class=br>-7</td>
<td class=bc>5 - 1 - 7</td>
<td class=br><strong>11</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>To Halama</td><td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=br>22:31</td><td class=br>-9</td>
<td class=bc>4 - 3 - 6</td>
<td class=br><strong>11</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>On Gruncl</td><td class=kL>1:6</td>
<td class=kT>4:4</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=br>21:32</td><td class=br>-11</td>
<td class=bc>4 - 2 - 7</td>
<td class=br><strong>10</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ji Junek</td><td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kL>5:8</td>
<td class=kL>1:6</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=br>21:45</td><td class=br>-24</td>
<td class=bc>3 - 0 - 10</td>
<td class=br><strong>6</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ro Vomáčka</td><td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=br>20:33</td><td class=br>-13</td>
<td class=bc>2 - 2 - 9</td>
<td class=br><strong>6</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Mi Grepl</td><td class=kL>2:9</td>
<td class=kL>1:6</td>
<td class=kL>0:8</td>
<td class=kL>1:8</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=br>10:64</td><td class=br>-54</td>
<td class=bc>0 - 0 - 13</td>
<td class=br><strong>0</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Junek Jiří</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Halama Tomáš</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pavlica Roman</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Grepl Miroslav</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Junek Jiří</td><td class=bc>-</td><td class=blW>Klazar Petr</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=bl>Halama Tomáš</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Grepl Miroslav</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pavlica Roman</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=bl>Halama Tomáš</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Junek Jiří</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Grepl Miroslav</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pavlica Roman</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Halama Tomáš</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Junek Jiří</td><td class=bc>-</td><td class=bl>Grepl Miroslav</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Pavlica Roman</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Halama Tomáš</td><td class=bc>-</td><td class=bl>Grepl Miroslav</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Klazar Petr</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Junek Jiří</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Pavlica Roman</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Grepl Miroslav</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Vomáčka Roman</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Halama Tomáš</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Junek Jiří</td><td class=bc>-</td><td class=blW>Pavlica Roman</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Grepl Miroslav</td><td class=bc>-</td><td class=blW>Vomáčka Roman</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Halama Tomáš</td><td class=bc>-</td><td class=blW>Pavlica Roman</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Vomáčka Josef</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Junek Jiří</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>5 : 8</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Grepl Miroslav</td><td class=bc>-</td><td class=blW>Pavlica Roman</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Vomáčka Josef</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Halama Tomáš</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Junek Jiří</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Pavlica Roman</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Vomáčka Josef</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Grepl Miroslav</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Halama Tomáš</td><td class=bc>-</td><td class=bl>Junek Jiří</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Grepl Miroslav</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Junek Jiří</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Klazar Petr</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Halama Tomáš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Pavlica Roman</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Junek Jiří</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Grepl Miroslav</td><td class=bc>-</td><td class=blW>Klazar Petr</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Halama Tomáš</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pavlica Roman</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Junek Jiří</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Klazar Petr</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Halama Tomáš</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Grepl Miroslav</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Junek Jiří</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Pavlica Roman</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Halama Tomáš</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Grepl Miroslav</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Junek Jiří</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Halama Tomáš</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pavlica Roman</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Grepl Miroslav</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Ma Moravec</td><td class=kx>*</td>
<td class=kT>2:2 + 3:2</td>
<td class=kW>4:2 + 6:3</td>
<td class=kT>2:2 + 6:4</td>
<td class=kW>5:2 + 4:1</td>
<td class=kW>3:1 + 7:1</td>
<td class=kW>4:1 + 5:1</td>
<td class=kW>3:1 + 3:0</td>
<td class=br>57:23</td><td class=br>+34</td>
<td class=bc>12 - 2 - 0</td>
<td class=br><strong>26</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Mi Moravec</td><td class=kT>2:2 + 2:3</td>
<td class=kx>*</td>
<td class=kT>4:4 + 4:3</td>
<td class=kW>5:1 + 0:2</td>
<td class=kW>2:0 + 4:1</td>
<td class=kW>8:0 + 7:2</td>
<td class=kW>7:0 + 6:0</td>
<td class=kW>7:0 + 9:0</td>
<td class=br>67:18</td><td class=br>+49</td>
<td class=bc>10 - 2 - 2</td>
<td class=br><strong>22</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Ra Hrnčíř</td><td class=kL>2:4 + 3:6</td>
<td class=kT>4:4 + 3:4</td>
<td class=kx>*</td>
<td class=kW>3:2 + 4:3</td>
<td class=kW>4:1 + 1:3</td>
<td class=kW>6:1 + 3:1</td>
<td class=kW>7:0 + 6:0</td>
<td class=kW>2:0 + 7:1</td>
<td class=br>55:30</td><td class=br>+25</td>
<td class=bc>9 - 1 - 4</td>
<td class=br><strong>19</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Zd Slovák</td><td class=kT>2:2 + 4:6</td>
<td class=kL>1:5 + 2:0</td>
<td class=kL>2:3 + 3:4</td>
<td class=kx>*</td>
<td class=kW>1:0 + 3:2</td>
<td class=kW>4:3 + 3:2</td>
<td class=kW>5:2 + 7:2</td>
<td class=kW>2:0 + 3:0</td>
<td class=br>42:31</td><td class=br>+11</td>
<td class=bc>9 - 1 - 4</td>
<td class=br><strong>19</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=d>5.</td><td class=kt>Ma Grepl</td><td class=kL>2:5 + 1:4</td>
<td class=kL>0:2 + 1:4</td>
<td class=kL>1:4 + 3:1</td>
<td class=kL>0:1 + 2:3</td>
<td class=kx>*</td>
<td class=kW>3:1 + 6:2</td>
<td class=kL>1:2 + 5:0</td>
<td class=kW>2:0 + 4:1</td>
<td class=br>31:30</td><td class=br>+1</td>
<td class=bc>6 - 0 - 8</td>
<td class=br><strong>12</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=d>6.</td><td class=kt>La Hladík</td><td class=kL>1:3 + 1:7</td>
<td class=kL>0:8 + 2:7</td>
<td class=kL>1:6 + 1:3</td>
<td class=kL>3:4 + 2:3</td>
<td class=kL>1:3 + 2:6</td>
<td class=kx>*</td>
<td class=kT>3:3 + 4:2</td>
<td class=kL>2:3 + 3:0</td>
<td class=br>26:58</td><td class=br>-32</td>
<td class=bc>2 - 1 - 11</td>
<td class=br><strong>5</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/4</td><td class=d>7.</td><td class=kt>Al Fátor</td><td class=kL>1:4 + 1:5</td>
<td class=kL>0:7 + 0:6</td>
<td class=kL>0:7 + 0:6</td>
<td class=kL>2:5 + 2:7</td>
<td class=kW>2:1 + 0:5</td>
<td class=kT>3:3 + 2:4</td>
<td class=kx>*</td>
<td class=kW>1:0 + 0:2</td>
<td class=br>14:62</td><td class=br>-48</td>
<td class=bc>2 - 1 - 11</td>
<td class=br><strong>5</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/4</td><td class=d>8.</td><td class=kt>Ra Hrčková</td><td class=kL>1:3 + 0:3</td>
<td class=kL>0:7 + 0:9</td>
<td class=kL>0:2 + 1:7</td>
<td class=kL>0:2 + 0:3</td>
<td class=kL>0:2 + 1:4</td>
<td class=kW>3:2 + 0:3</td>
<td class=kL>0:1 + 2:0</td>
<td class=kx>*</td>
<td class=br>8:48</td><td class=br>-40</td>
<td class=bc>2 - 0 - 12</td>
<td class=br><strong>4</strong></td><td class=d>8.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Hrčková Radka</td><td class=bc>2 : 0 + 7 : 1</tr></td>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Hladík Ladislav</td><td class=bc>3 : 1 + 7 : 1</tr></td>
<tr><td class=brW>Slovák Zdeněk</td><td class=bc>-</td><td class=bl>Fátor Aleš</td><td class=bc>5 : 2 + 7 : 2</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Grepl Matej</td><td class=bc>2 : 0 + 4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Hrčková Radka</td><td class=bc>-</td><td class=bl>Hladík Ladislav</td><td class=bc>3 : 2 + 0 : 3</tr></td>
<tr><td class=brW>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Fátor Aleš</td><td class=bc>7 : 0 + 6 : 0</tr></td>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Grepl Matej</td><td class=bc>5 : 2 + 4 : 1</tr></td>
<tr><td class=br>Slovák Zdeněk</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>1 : 5 + 2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Hladík Ladislav</td><td class=bc>-</td><td class=bl>Fátor Aleš</td><td class=bc>3 : 3 + 4 : 2</tr></td>
<tr><td class=br>Hrčková Radka</td><td class=bc>-</td><td class=blW>Grepl Matej</td><td class=bc>0 : 2 + 1 : 4</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>4 : 4 + 3 : 4</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=bl>Slovák Zdeněk</td><td class=bc>2 : 2 + 6 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Fátor Aleš</td><td class=bc>-</td><td class=bl>Grepl Matej</td><td class=bc>2 : 1 + 0 : 5</tr></td>
<tr><td class=br>Hladík Ladislav</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>0 : 8 + 2 : 7</tr></td>
<tr><td class=br>Hrčková Radka</td><td class=bc>-</td><td class=blW>Slovák Zdeněk</td><td class=bc>0 : 2 + 0 : 3</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>2 : 4 + 3 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Grepl Matej</td><td class=bc>-</td><td class=blW>Slovák Zdeněk</td><td class=bc>0 : 1 + 2 : 3</tr></td>
<tr><td class=br>Fátor Aleš</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>1 : 4 + 1 : 5</tr></td>
<tr><td class=br>Hladík Ladislav</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>1 : 6 + 1 : 3</tr></td>
<tr><td class=br>Hrčková Radka</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>2 : 2 + 2 : 3</tr></td>
<tr><td class=br>Grepl Matej</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>1 : 4 + 3 : 1</tr></td>
<tr><td class=brW>Fátor Aleš</td><td class=bc>-</td><td class=bl>Hrčková Radka</td><td class=bc>1 : 0 + 0 : 2</tr></td>
<tr><td class=br>Hladík Ladislav</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Slovák Zdeněk</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>2 : 3 + 3 : 4</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Hrčková Radka</td><td class=bc>7 : 0+ 9 : 0</tr></td>
<tr><td class=brW>Grepl Matej</td><td class=bc>-</td><td class=bl>Hladík Ladislav</td><td class=bc>3 : 1 + 6 : 2</tr></td>
<tr><td class=br>Fátor Aleš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Hrčková Radka</td><td class=bc>3 : 1 + 3 : 0</tr></td>
<tr><td class=brW>Slovák Zdeněk</td><td class=bc>-</td><td class=bl>Hladík Ladislav</td><td class=bc>4 : 3 + 3 : 2</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Fátor Aleš</td><td class=bc>7 : 0 + 6 : 0</tr></td>
<tr><td class=br>Grepl Matej</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
