<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR junioři</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/pohar13.aspx">U13</a>
&nbsp;<a href="../data/pohar55.aspx">55+</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../mrj/index.aspx">MR junioři, 18. květen 2025</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<p class=v>Group 19</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt>Ma Klazar</td><td class=ic>CZE</td><td class=kx>*</td>
<td class=kW>1:0 + 5:3</td>
<td class=kW>2:1 + 5:2</td>
<td class=kW>2:1 + 5:1</td>
<td class=kW>8:2 + 4:1</td>
<td class=kW>4:3 + 6:1</td>
<td class=kW>6:3 + 4:1</td>
<td class=kW>8:0 + 7:0</td>
<td class=br>67:19</td><td class=br>+48</td>
<td class=bc>14 - 0 - 0</td>
<td class=br><strong>28</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt>Mi Touš</td><td class=ic>CZE</td><td class=kL>0:1 + 3:5</td>
<td class=kx>*</td>
<td class=kW>3:2 + 2:2</td>
<td class=kW>8:3 + 2:2</td>
<td class=kW>4:2 K + 6:1 K</td>
<td class=kW>4:2 + 7:1</td>
<td class=kW>4:1 + 4:0</td>
<td class=kW>10:2 + 8:0</td>
<td class=br>65:24</td><td class=br>+41</td>
<td class=bc>10 - 2 - 2</td>
<td class=br><strong>22</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt>Vo Kraus</td><td class=ic>CZE</td><td class=kL>1:2 + 2:5</td>
<td class=kL>2:3 + 2:2</td>
<td class=kx>*</td>
<td class=kW>6:2 + 2:1</td>
<td class=kW>7:2 + 5:3</td>
<td class=kW>4:2 + 3:0</td>
<td class=kW>5:1 + 3:1</td>
<td class=kW>6:1 + 8:0</td>
<td class=br>56:25</td><td class=br>+31</td>
<td class=bc>10 - 1 - 3</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt>On Gruncl</td><td class=ic>CZE</td><td class=kL>1:2 + 1:5</td>
<td class=kL>3:8 + 2:2</td>
<td class=kL>2:6 + 1:2</td>
<td class=kx>*</td>
<td class=kW>4:1 + 3:1</td>
<td class=kW>4:2 + 4:3</td>
<td class=kW>3:1 + 6:1</td>
<td class=kW>7:0 + 5:1</td>
<td class=br>46:35</td><td class=br>+11</td>
<td class=bc>8 - 1 - 5</td>
<td class=br><strong>17</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ví Pernica</td><td class=ic>CZE</td><td class=kL>2:8 + 1:4</td>
<td class=kL>2:4 K + 1:6 K</td>
<td class=kL>2:7 + 3:5</td>
<td class=kL>1:4 + 1:3</td>
<td class=kx>*</td>
<td class=kW>2:0 + 4:1</td>
<td class=kW>5:1 + 3:3</td>
<td class=kW>8:2 + 0:0</td>
<td class=br>35:48</td><td class=br>-13</td>
<td class=bc>4 - 2 - 8</td>
<td class=br><strong>10</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Mi Moravec</td><td class=ic>CZE</td><td class=kL>3:4 + 1:6</td>
<td class=kL>2:4 + 1:7</td>
<td class=kL>2:4 + 0:3</td>
<td class=kL>2:4 + 3:4</td>
<td class=kL>0:2 + 1:4</td>
<td class=kx>*</td>
<td class=kW>4:0 + 3:1</td>
<td class=kW>4:0 + 3:0</td>
<td class=br>29:43</td><td class=br>-14</td>
<td class=bc>4 - 0 - 10</td>
<td class=br><strong>8</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Lu Holub</td><td class=ic>CZE</td><td class=kL>3:6 + 1:4</td>
<td class=kL>1:4 + 0:4</td>
<td class=kL>1:5 + 1:3</td>
<td class=kL>1:3 + 1:6</td>
<td class=kL>1:5 + 3:3</td>
<td class=kL>0:4 + 1:3</td>
<td class=kx>*</td>
<td class=kW>4:1 + 2:1</td>
<td class=br>20:52</td><td class=br>-32</td>
<td class=bc>2 - 1 - 11</td>
<td class=br><strong>5</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Vo Pošík</td><td class=ic>CZE</td><td class=kL>0:8 + 0:7</td>
<td class=kL>2:10 + 0:8</td>
<td class=kL>1:6 + 0:8</td>
<td class=kL>0:7 + 1:5</td>
<td class=kL>2:8 + 0:0</td>
<td class=kL>0:4 + 0:3</td>
<td class=kL>1:4 + 1:2</td>
<td class=kx>*</td>
<td class=br>8:80</td><td class=br>-72</td>
<td class=bc>0 - 1 - 13</td>
<td class=br><strong>1</strong></td><td class=d>8.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>1 : 3 + 1 : 6</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>0 : 1 + 3 : 5</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>1 : 6 + 0 : 8</tr></td>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>2 : 0 + 4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>3 : 8 + 2 : 2</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>8 : 0 + 7 : 0</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>7 : 2 + 5 : 3</tr></td>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>0 : 4 + 1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>1 : 4 + 0 : 4</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>0 : 7 + 1 : 5</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>2 : 8 + 1 : 4</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>2 : 4 + 0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>10 : 2 + 8 : 0</tr></td>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>4 : 1 + 3 : 1</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>4 : 3 + 6 : 1</tr></td>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>1 : 5 + 1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Holub Lukáš</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>4 : 1 + 2 : 1</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>2 : 4 K + 1 : 6 K</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>2 : 4 + 3 : 4</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>1 : 2 + 2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>2 : 8 + 0 : 0</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>4 : 2 + 7 : 1</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>2 : 6 + 1 : 2</tr></td>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>3 : 6 + 1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>1 : 5 + 3 : 3</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>4 : 0 + 3 : 0</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>2 : 3 + 2 : 2</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>2 : 1 + 5 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
