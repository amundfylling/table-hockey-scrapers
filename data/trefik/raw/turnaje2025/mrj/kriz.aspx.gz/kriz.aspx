<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR jednotlivci</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/pohar13.aspx">U13</a>
&nbsp;<a href="../data/pohar55.aspx">55+</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../mr/index.aspx">MR jednotlivci, 18. květen 2025</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Základní skupiny (Basic groups)</a><br>
<a href="#final">Výkonnostní skupiny (Final groups)</a><br>
<a name="basic"><p class=vm>Základní skupiny (Basic groups)</p></a>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Mi Kobrle</td><td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>7:4</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=br>55:18</td><td class=br>+37</td>
<td class=bc>12 - 1 - 0</td>
<td class=br><strong>25</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>To Bucek</td><td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=br>36:24</td><td class=br>+12</td>
<td class=bc>9 - 1 - 3</td>
<td class=br><strong>19</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ma Ženíšek</td><td class=kL>4:7</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=br>42:33</td><td class=br>+9</td>
<td class=bc>6 - 5 - 2</td>
<td class=br><strong>17</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Da Matýsek</td><td class=kL>1:6</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>35:28</td><td class=br>+7</td>
<td class=bc>8 - 1 - 4</td>
<td class=br><strong>17</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Kr Lebl</td><td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>5:6</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=br>41:31</td><td class=br>+10</td>
<td class=bc>6 - 4 - 3</td>
<td class=br><strong>16</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Mi Kubica</td><td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=br>34:26</td><td class=br>+8</td>
<td class=bc>7 - 2 - 4</td>
<td class=br><strong>16</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Kr Herold</td><td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>6:5</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>7:0</td>
<td class=kW>6:0</td>
<td class=br>39:27</td><td class=br>+12</td>
<td class=bc>6 - 2 - 5</td>
<td class=br><strong>14</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Mi Černoch</td><td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=br>28:31</td><td class=br>-3</td>
<td class=bc>5 - 3 - 5</td>
<td class=br><strong>13</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Vl Kraus</td><td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=br>31:29</td><td class=br>+2</td>
<td class=bc>6 - 1 - 6</td>
<td class=br><strong>13</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Vo Kraus</td><td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=br>34:32</td><td class=br>+2</td>
<td class=bc>5 - 2 - 6</td>
<td class=br><strong>12</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Pe Holub</td><td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kT>4:4</td>
<td class=kL>0:4</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=br>18:36</td><td class=br>-18</td>
<td class=bc>2 - 4 - 7</td>
<td class=br><strong>8</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>On Gruncl</td><td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kW>3:1</td>
<td class=br>23:42</td><td class=br>-19</td>
<td class=bc>2 - 2 - 9</td>
<td class=br><strong>6</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Pe Klazar</td><td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>0:7</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=br>15:45</td><td class=br>-30</td>
<td class=bc>1 - 3 - 9</td>
<td class=br><strong>5</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Hy Nechutný</td><td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=br>14:43</td><td class=br>-29</td>
<td class=bc>0 - 1 - 12</td>
<td class=br><strong>1</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Klazar Petr</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Holub Petr</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>5 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Holub Petr</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ji Chylík ml.</td><td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>8:1</td>
<td class=kW>10:0</td>
<td class=br>64:18</td><td class=br>+46</td>
<td class=bc>12 - 0 - 1</td>
<td class=br><strong>24</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Pa Petr</td><td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>8:1</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>6:4</td>
<td class=kW>9:1</td>
<td class=kW>9:2</td>
<td class=kW>6:3</td>
<td class=kW>9:1</td>
<td class=kW>2:1</td>
<td class=br>69:26</td><td class=br>+43</td>
<td class=bc>11 - 0 - 2</td>
<td class=br><strong>22</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ku Sládek</td><td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>6:3</td>
<td class=kW>6:0</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=br>47:20</td><td class=br>+27</td>
<td class=bc>10 - 1 - 2</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Pe Fuchs</td><td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>9:1</td>
<td class=br>47:25</td><td class=br>+22</td>
<td class=bc>8 - 2 - 3</td>
<td class=br><strong>18</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Vá Pikl</td><td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=br>31:24</td><td class=br>+7</td>
<td class=bc>7 - 2 - 4</td>
<td class=br><strong>16</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Mi Touš</td><td class=kL>3:6</td>
<td class=kL>1:8</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=br>49:41</td><td class=br>+8</td>
<td class=bc>6 - 3 - 4</td>
<td class=br><strong>15</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ji Vácha</td><td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kW>7:3</td>
<td class=br>39:38</td><td class=br>+1</td>
<td class=bc>7 - 0 - 6</td>
<td class=br><strong>14</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Al Krejza</td><td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kW>5:0</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=br>32:33</td><td class=br>-1</td>
<td class=bc>5 - 1 - 7</td>
<td class=br><strong>11</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Da Dvořáček</td><td class=kL>0:3</td>
<td class=kL>4:6</td>
<td class=kL>0:3</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>5:5</td>
<td class=kW>4:0</td>
<td class=kL>3:4</td>
<td class=kW>6:2</td>
<td class=br>40:44</td><td class=br>-4</td>
<td class=bc>5 - 1 - 7</td>
<td class=br><strong>11</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Zd Lopaur</td><td class=kL>0:4</td>
<td class=kL>1:9</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=br>35:42</td><td class=br>-7</td>
<td class=bc>5 - 1 - 7</td>
<td class=br><strong>11</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Vá Macek</td><td class=kL>2:4</td>
<td class=kL>2:9</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kT>5:5</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kW>9:3</td>
<td class=br>37:56</td><td class=br>-19</td>
<td class=bc>3 - 1 - 9</td>
<td class=br><strong>7</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ro Vomáčka</td><td class=kL>2:6</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=br>22:49</td><td class=br>-27</td>
<td class=bc>3 - 0 - 10</td>
<td class=br><strong>6</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Mi Moravec</td><td class=kL>1:8</td>
<td class=kL>1:9</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>0:7</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kL>0:6</td>
<td class=kL>3:6</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=br>19:63</td><td class=br>-44</td>
<td class=bc>2 - 1 - 10</td>
<td class=br><strong>5</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Ra Hrnčíř</td><td class=kL>0:10</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>1:9</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>3:7</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kL>3:9</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=br>19:71</td><td class=br>-52</td>
<td class=bc>0 - 1 - 12</td>
<td class=br><strong>1</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Macek Václav</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Petr Patrik</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Macek Václav</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Vomáčka Roman</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Macek Václav</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Macek Václav</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Vomáčka Roman</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Macek Václav</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Macek Václav</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Macek Václav</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Petr Patrik</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>4 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Macek Václav</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Macek Václav</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Macek Václav</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>2 : 9</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Vomáčka Roman</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Macek Václav</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>9 : 3</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Macek Václav</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Macek Václav</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Macek Václav</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<hr><a name="final"><p class=vm>Výkonnostní skupiny (Final groups)</p></a>
<p class=v>Group A</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/8</td><td class=d>1.</td><td class=kt>Pa Petr</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:2 K</td>
<td class=kL>4:6 K</td>
<td class=kW>3:1</td>
<td class=kW>8:1 K</td>
<td class=kW>5:1</td>
<td class=kW>3:0 K</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>3:0 K</td>
<td class=kW>6:2</td>
<td class=kW>3:2 K</td>
<td class=kL>2:3 K</td>
<td class=br>64:25</td><td class=br>+39</td>
<td class=bc>12 - 1 - 2</td>
<td class=br><strong>25</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/8</td><td class=d>2.</td><td class=kt>Mi Kobrle</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:6</td>
<td class=kW>8:4</td>
<td class=kW>6:1 K</td>
<td class=kW>6:3</td>
<td class=kW>3:0 K</td>
<td class=kL>3:6</td>
<td class=kT>2:2 K</td>
<td class=kW>3:2 K</td>
<td class=kW>3:1 K</td>
<td class=kW>7:4 K</td>
<td class=kW>3:0</td>
<td class=kW>4:2 K</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=br>61:36</td><td class=br>+25</td>
<td class=bc>11 - 2 - 2</td>
<td class=br><strong>24</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/8</td><td class=d>3.</td><td class=kt>Ku Sládek</td><td class=kL>2:5 K</td>
<td class=kW>6:1</td>
<td class=kx>*</td>
<td class=kW>3:2 K</td>
<td class=kL>0:1</td>
<td class=kW>6:3 K</td>
<td class=kW>2:1</td>
<td class=kW>3:1 K</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kL>1:2 K</td>
<td class=kW>5:1</td>
<td class=kW>3:0 K</td>
<td class=kW>6:0 K</td>
<td class=br>46:23</td><td class=br>+23</td>
<td class=bc>10 - 1 - 4</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/8</td><td class=d>4.</td><td class=kt>Ji Chylík ml.</td><td class=kW>6:4 K</td>
<td class=kL>4:8</td>
<td class=kL>2:3 K</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>6:3 K</td>
<td class=kL>1:3</td>
<td class=kW>4:0 K</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>2:0 K</td>
<td class=kW>5:1</td>
<td class=kW>5:2 K</td>
<td class=kW>4:1 K</td>
<td class=br>56:38</td><td class=br>+18</td>
<td class=bc>9 - 2 - 4</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/8</td><td class=d>5.</td><td class=kt>Da Matýsek</td><td class=kL>1:3</td>
<td class=kL>1:6 K</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:4 K</td>
<td class=kL>0:2</td>
<td class=kL>1:3 K</td>
<td class=kW>2:1 K</td>
<td class=kW>3:0 K</td>
<td class=kT>4:4 K</td>
<td class=kT>1:1</td>
<td class=kW>2:1 K</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=br>33:31</td><td class=br>+2</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/8</td><td class=d>6.</td><td class=kt>Mi Touš</td><td class=kL>1:8 K</td>
<td class=kL>3:6</td>
<td class=kL>3:6 K</td>
<td class=kL>3:6 K</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3 K</td>
<td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kT>2:2 K</td>
<td class=kW>4:1</td>
<td class=kW>5:2 K</td>
<td class=kW>5:2 K</td>
<td class=br>49:48</td><td class=br>+1</td>
<td class=bc>7 - 3 - 5</td>
<td class=br><strong>17</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/8</td><td class=d>7.</td><td class=kt>Kr Herold</td><td class=kL>1:5</td>
<td class=kL>0:3 K</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1 K</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>6:5 K</td>
<td class=kL>2:4 K</td>
<td class=kT>3:3 K</td>
<td class=kT>1:1 K</td>
<td class=kW>6:1</td>
<td class=kL>0:1 K</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=br>41:30</td><td class=br>+11</td>
<td class=bc>7 - 2 - 6</td>
<td class=br><strong>16</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/8</td><td class=d>8.</td><td class=kt>Pe Fuchs</td><td class=kL>0:3 K</td>
<td class=kW>6:3</td>
<td class=kL>1:3 K</td>
<td class=kL>0:4 K</td>
<td class=kW>2:0</td>
<td class=kT>3:3 K</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kT>3:3 K</td>
<td class=kL>1:5</td>
<td class=kW>4:0 K</td>
<td class=kW>3:1 K</td>
<td class=br>33:35</td><td class=br>-2</td>
<td class=bc>6 - 4 - 5</td>
<td class=br><strong>16</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Kr Lebl</td><td class=kL>2:4</td>
<td class=kT>2:2 K</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kW>3:1 K</td>
<td class=kL>3:5</td>
<td class=kL>5:6 K</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:0 K</td>
<td class=kW>2:1 K</td>
<td class=kL>2:4 K</td>
<td class=kW>3:0</td>
<td class=kW>4:2 K</td>
<td class=kL>2:4</td>
<td class=kW>6:2</td>
<td class=br>44:42</td><td class=br>+2</td>
<td class=bc>6 - 2 - 7</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>To Bucek</td><td class=kL>0:4</td>
<td class=kL>2:3 K</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>1:2 K</td>
<td class=kL>0:4</td>
<td class=kW>4:2 K</td>
<td class=kT>2:2</td>
<td class=kL>0:3 K</td>
<td class=kx>*</td>
<td class=kW>3:2 K</td>
<td class=kW>3:1 K</td>
<td class=kW>3:2</td>
<td class=kT>2:2 K</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=br>28:39</td><td class=br>-11</td>
<td class=bc>4 - 5 - 6</td>
<td class=br><strong>13</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Mi Černoch</td><td class=kL>1:6</td>
<td class=kL>1:3 K</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>0:3 K</td>
<td class=kT>3:3</td>
<td class=kT>3:3 K</td>
<td class=kL>0:1</td>
<td class=kL>1:2 K</td>
<td class=kL>2:3 K</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2</td>
<td class=kW>4:3 K</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=br>31:35</td><td class=br>-4</td>
<td class=bc>4 - 5 - 6</td>
<td class=br><strong>13</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ma Ženíšek</td><td class=kL>2:6</td>
<td class=kL>4:7 K</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kT>4:4 K</td>
<td class=kL>2:5</td>
<td class=kT>1:1 K</td>
<td class=kL>1:4</td>
<td class=kW>4:2 K</td>
<td class=kL>1:3 K</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>4:4 K</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=br>35:52</td><td class=br>-17</td>
<td class=bc>3 - 5 - 7</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Vá Pikl</td><td class=kL>0:3 K</td>
<td class=kL>0:3</td>
<td class=kW>2:1 K</td>
<td class=kL>0:2 K</td>
<td class=kT>1:1</td>
<td class=kT>2:2 K</td>
<td class=kL>1:6</td>
<td class=kT>3:3 K</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:1 K</td>
<td class=kL>2:4 K</td>
<td class=br>23:40</td><td class=br>-17</td>
<td class=bc>2 - 6 - 7</td>
<td class=br><strong>10</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Mi Kubica</td><td class=kL>2:6</td>
<td class=kL>2:4 K</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:2 K</td>
<td class=kL>1:4</td>
<td class=kW>1:0 K</td>
<td class=kW>5:1</td>
<td class=kL>2:4 K</td>
<td class=kT>2:2 K</td>
<td class=kL>3:4 K</td>
<td class=kT>4:4 K</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=br>34:50</td><td class=br>-16</td>
<td class=bc>3 - 3 - 9</td>
<td class=br><strong>9</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Al Krejza</td><td class=kL>2:3 K</td>
<td class=kL>1:5</td>
<td class=kL>0:3 K</td>
<td class=kL>2:5 K</td>
<td class=kL>1:5</td>
<td class=kL>2:5 K</td>
<td class=kL>0:3</td>
<td class=kL>0:4 K</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>1:2 K</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>5:0 K</td>
<td class=br>25:45</td><td class=br>-20</td>
<td class=bc>3 - 1 - 11</td>
<td class=br><strong>7</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Ji Vácha</td><td class=kW>3:2 K</td>
<td class=kL>2:5</td>
<td class=kL>0:6 K</td>
<td class=kL>1:4 K</td>
<td class=kL>2:4</td>
<td class=kL>2:5 K</td>
<td class=kL>1:6</td>
<td class=kL>1:3 K</td>
<td class=kL>2:6</td>
<td class=kW>5:1</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kW>4:2 K</td>
<td class=kL>3:5</td>
<td class=kL>0:5 K</td>
<td class=kx>*</td>
<td class=br>28:62</td><td class=br>-34</td>
<td class=bc>3 - 0 - 12</td>
<td class=br><strong>6</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Petr Patrik</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>3 : 6</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
