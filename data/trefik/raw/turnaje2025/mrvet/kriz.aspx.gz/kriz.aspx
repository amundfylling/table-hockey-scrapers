<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR veteráni</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/pohar13.aspx">U13</a>
&nbsp;<a href="../data/pohar55.aspx">55+</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../mrv/index.aspx">MR veteráni, 18. květen 2025</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Základní skupiny (Basic groups)</a><br>
<a href="#final">Výkonnostní skupiny (Final groups)</a><br>
<a name="basic"><p class=vm>Základní skupiny (Basic groups)</p></a>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ja Dryák</td><td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>9:0</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=kW>9:3</td>
<td class=br>40:6</td><td class=br>+34</td>
<td class=bc>6 - 0 - 0</td>
<td class=br><strong>12</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Al Krejza</td><td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>6:3</td>
<td class=br>25:14</td><td class=br>+11</td>
<td class=bc>4 - 1 - 1</td>
<td class=br><strong>9</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Jo Sedláček</td><td class=kL>0:9</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=br>16:24</td><td class=br>-8</td>
<td class=bc>2 - 2 - 2</td>
<td class=br><strong>6</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Vl Kraus</td><td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>9:1</td>
<td class=br>23:19</td><td class=br>+4</td>
<td class=bc>2 - 2 - 2</td>
<td class=br><strong>6</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt>Da Hrachovec</td><td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=br>20:24</td><td class=br>-4</td>
<td class=bc>2 - 1 - 3</td>
<td class=br><strong>5</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>C</td><td class=d>6.</td><td class=kt>Ma Moravec</td><td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=br>14:25</td><td class=br>-11</td>
<td class=bc>1 - 1 - 4</td>
<td class=br><strong>3</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>D</td><td class=d>7.</td><td class=kt>Mi Horáková</td><td class=kL>3:9</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kL>1:9</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=br>11:37</td><td class=br>-26</td>
<td class=bc>0 - 1 - 5</td>
<td class=br><strong>1</strong></td><td class=d>7.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Horáková Miroslava</td><td class=bc>-</td><td class=bl>Sedláček Josef</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Hrachovec Daniel</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Dryák Jan</td><td class=bc>-</td><td class=bl>Horáková Miroslava</td><td class=bc>9 : 3</tr></td>
<tr><td class=br>Sedláček Josef</td><td class=bc>-</td><td class=bl>Hrachovec Daniel</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Hrachovec Daniel</td><td class=bc>-</td><td class=blW>Dryák Jan</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Sedláček Josef</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Horáková Miroslava</td><td class=bc>-</td><td class=blW>Hrachovec Daniel</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Dryák Jan</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Sedláček Josef</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Horáková Miroslava</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Dryák Jan</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Sedláček Josef</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Hrachovec Daniel</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Horáková Miroslava</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Dryák Jan</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Hrachovec Daniel</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Horáková Miroslava</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Sedláček Josef</td><td class=bc>-</td><td class=blW>Dryák Jan</td><td class=bc>0 : 9</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Zd Lopaur</td><td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=br>25:9</td><td class=br>+16</td>
<td class=bc>5 - 0 - 1</td>
<td class=br><strong>10</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>To Bucek</td><td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>8:0</td>
<td class=br>27:9</td><td class=br>+18</td>
<td class=bc>4 - 1 - 1</td>
<td class=br><strong>9</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Mi Černoch</td><td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>9:1</td>
<td class=br>23:11</td><td class=br>+12</td>
<td class=bc>4 - 0 - 2</td>
<td class=br><strong>8</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>St Srba</td><td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=br>14:11</td><td class=br>+3</td>
<td class=bc>3 - 2 - 1</td>
<td class=br><strong>8</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt>Ro Vomáčka</td><td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=br>13:18</td><td class=br>-5</td>
<td class=bc>2 - 1 - 3</td>
<td class=br><strong>5</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>C</td><td class=d>6.</td><td class=kt>Ja Kopecký</td><td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=br>9:23</td><td class=br>-14</td>
<td class=bc>1 - 0 - 5</td>
<td class=br><strong>2</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>D</td><td class=d>7.</td><td class=kt>Ja Kubica</td><td class=kL>1:5</td>
<td class=kL>0:8</td>
<td class=kL>1:9</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=br>2:32</td><td class=br>-30</td>
<td class=bc>0 - 0 - 6</td>
<td class=br><strong>0</strong></td><td class=d>7.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Kopecký Jaroslav</td><td class=bc>-</td><td class=blW>Srba Stanislav</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Vomáčka Roman</td><td class=bc>-</td><td class=bl>Kopecký Jaroslav</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Srba Stanislav</td><td class=bc>-</td><td class=bl>Kubica Jan</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Kopecký Jaroslav</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=blW>Vomáčka Roman</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Srba Stanislav</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Kopecký Jaroslav</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Kubica Jan</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Srba Stanislav</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Kopecký Jaroslav</td><td class=bc>-</td><td class=bl>Kubica Jan</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Srba Stanislav</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Kopecký Jaroslav</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Srba Stanislav</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>0 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 3</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Da Cibulka</td><td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>12:1</td>
<td class=br>33:13</td><td class=br>+20</td>
<td class=bc>5 - 0 - 1</td>
<td class=br><strong>10</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Pa Plešák</td><td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>14:2</td>
<td class=br>33:15</td><td class=br>+18</td>
<td class=bc>4 - 1 - 1</td>
<td class=br><strong>9</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Da Matýsek</td><td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>8:3</td>
<td class=br>20:10</td><td class=br>+10</td>
<td class=bc>3 - 2 - 1</td>
<td class=br><strong>8</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Hy Nechutný</td><td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=br>15:8</td><td class=br>+7</td>
<td class=bc>3 - 2 - 1</td>
<td class=br><strong>8</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt>Mi Mašika</td><td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>9:0</td>
<td class=br>21:15</td><td class=br>+6</td>
<td class=bc>2 - 1 - 3</td>
<td class=br><strong>5</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>C</td><td class=d>6.</td><td class=kt>Pe Klazar</td><td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>8:2</td>
<td class=br>11:25</td><td class=br>-14</td>
<td class=bc>1 - 0 - 5</td>
<td class=br><strong>2</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>D</td><td class=d>7.</td><td class=kt>Ro Kubinec</td><td class=kL>1:12</td>
<td class=kL>2:14</td>
<td class=kL>3:8</td>
<td class=kL>0:4</td>
<td class=kL>0:9</td>
<td class=kL>2:8</td>
<td class=kx>*</td>
<td class=br>8:55</td><td class=br>-47</td>
<td class=bc>0 - 0 - 6</td>
<td class=br><strong>0</strong></td><td class=d>7.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Kubinec Roman</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Cibulka David</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Kubinec Roman</td><td class=bc>14 : 2</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Kubinec Roman</td><td class=bc>-</td><td class=blW>Cibulka David</td><td class=bc>1 : 12</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Klazar Petr</td><td class=bc>-</td><td class=bl>Kubinec Roman</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Cibulka David</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Mašika Michal</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Cibulka David</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Kubinec Roman</td><td class=bc>-</td><td class=blW>Mašika Michal</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Cibulka David</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Kubinec Roman</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Cibulka David</td><td class=bc>5 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 4</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ma Ženíšek</td><td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>7:1</td>
<td class=kW>6:3</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=br>38:9</td><td class=br>+29</td>
<td class=bc>6 - 1 - 0</td>
<td class=br><strong>13</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Vá Pikl</td><td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>8:1</td>
<td class=kW>3:0</td>
<td class=br>24:8</td><td class=br>+16</td>
<td class=bc>6 - 0 - 1</td>
<td class=br><strong>12</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ji Vácha</td><td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>6:3</td>
<td class=kW>9:2</td>
<td class=kW>8:1</td>
<td class=kW>7:1</td>
<td class=br>37:14</td><td class=br>+23</td>
<td class=bc>5 - 1 - 1</td>
<td class=br><strong>11</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ja Medvec</td><td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=br>24:21</td><td class=br>+3</td>
<td class=bc>4 - 0 - 3</td>
<td class=br><strong>8</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt>Pe Holub</td><td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>8:1</td>
<td class=kW>5:1</td>
<td class=br>28:21</td><td class=br>+7</td>
<td class=bc>3 - 0 - 4</td>
<td class=br><strong>6</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>C</td><td class=d>6.</td><td class=kt>Ra Hrnčíř</td><td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kL>2:9</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=br>18:31</td><td class=br>-13</td>
<td class=bc>2 - 0 - 5</td>
<td class=br><strong>4</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>D</td><td class=d>7.</td><td class=kt>Ja Fiedlerova</td><td class=kL>0:6</td>
<td class=kL>1:8</td>
<td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kL>1:8</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=br>4:41</td><td class=br>-37</td>
<td class=bc>1 - 0 - 6</td>
<td class=br><strong>2</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>E</td><td class=d>8.</td><td class=kt>Ji Pošík</td><td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=br>3:31</td><td class=br>-28</td>
<td class=bc>0 - 0 - 7</td>
<td class=br><strong>0</strong></td><td class=d>8.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Fiedlerova Jana</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Medvec Jan</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Fiedlerova Jana</td><td class=bc>-</td><td class=blW>Holub Petr</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Medvec Jan</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Fiedlerova Jana</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Medvec Jan</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Holub Petr</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Fiedlerova Jana</td><td class=bc>-</td><td class=blW>Medvec Jan</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Medvec Jan</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Fiedlerova Jana</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Medvec Jan</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Fiedlerova Jana</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Medvec Jan</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Holub Petr</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Fiedlerova Jana</td><td class=bc>8 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<hr><a name="final"><p class=vm>Výkonnostní skupiny (Final groups)</p></a>
<p class=v>Group A1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Ja Dryák</td><td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>3:1 K</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kW>9:0 K</td>
<td class=kW>6:1 K</td>
<td class=kW>7:1</td>
<td class=br>33:9</td><td class=br>+24</td>
<td class=bc>5 - 1 - 1</td>
<td class=br><strong>11</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Da Matýsek</td><td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kL>2:4 K</td>
<td class=kT>2:2 K</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kT>0:0 K</td>
<td class=br>14:6</td><td class=br>+8</td>
<td class=bc>3 - 3 - 1</td>
<td class=br><strong>9</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Al Krejza</td><td class=kL>1:3 K</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kW>4:2 K</td>
<td class=kT>3:3 K</td>
<td class=kW>4:3</td>
<td class=br>19:16</td><td class=br>+3</td>
<td class=bc>3 - 3 - 1</td>
<td class=br><strong>9</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Da Cibulka</td><td class=kL>0:5</td>
<td class=kW>4:2 K</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>4:5 K</td>
<td class=kW>7:3</td>
<td class=kW>3:1</td>
<td class=kW>5:1 K</td>
<td class=br>24:20</td><td class=br>+4</td>
<td class=bc>4 - 0 - 3</td>
<td class=br><strong>8</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Pa Plešák</td><td class=kT>3:3</td>
<td class=kT>2:2 K</td>
<td class=kT>4:4</td>
<td class=kW>5:4 K</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>3:5</td>
<td class=kL>1:3 K</td>
<td class=br>22:25</td><td class=br>-3</td>
<td class=bc>1 - 4 - 2</td>
<td class=br><strong>6</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Jo Sedláček</td><td class=kL>0:9 K</td>
<td class=kL>0:3</td>
<td class=kL>2:4 K</td>
<td class=kL>3:7</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>3:2 K</td>
<td class=kW>3:2</td>
<td class=br>15:31</td><td class=br>-16</td>
<td class=bc>2 - 1 - 4</td>
<td class=br><strong>5</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Vl Kraus</td><td class=kL>1:6 K</td>
<td class=kL>0:4</td>
<td class=kT>3:3 K</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kL>2:3 K</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=br>15:24</td><td class=br>-9</td>
<td class=bc>2 - 1 - 4</td>
<td class=br><strong>5</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Hy Nechutný</td><td class=kL>1:7</td>
<td class=kT>0:0 K</td>
<td class=kL>3:4</td>
<td class=kL>1:5 K</td>
<td class=kW>3:1 K</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=br>12:23</td><td class=br>-11</td>
<td class=bc>1 - 1 - 5</td>
<td class=br><strong>3</strong></td><td class=d>8.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Dryák Jan</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Sedláček Josef</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Cibulka David</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Cibulka David</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Sedláček Josef</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Dryák Jan</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Sedláček Josef</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Dryák Jan</td><td class=bc>-</td><td class=bl>Cibulka David</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Sedláček Josef</td><td class=bc>-</td><td class=blW>Cibulka David</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Dryák Jan</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>0 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group A2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Ma Ženíšek</td><td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>2:2 K</td>
<td class=kW>5:3</td>
<td class=kW>4:1 K</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>7:1 K</td>
<td class=br>30:13</td><td class=br>+17</td>
<td class=bc>6 - 1 - 0</td>
<td class=br><strong>13</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Zd Lopaur</td><td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>0:5</td>
<td class=kW>5:3 K</td>
<td class=kW>4:1</td>
<td class=kW>3:1 K</td>
<td class=kL>1:2 K</td>
<td class=kW>3:2</td>
<td class=br>18:18</td><td class=br>0</td>
<td class=bc>4 - 0 - 3</td>
<td class=br><strong>8</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Ji Vácha</td><td class=kT>2:2 K</td>
<td class=kW>5:0</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:2 K</td>
<td class=kL>0:5</td>
<td class=kW>6:0</td>
<td class=kW>4:3 K</td>
<td class=br>21:15</td><td class=br>+6</td>
<td class=bc>3 - 2 - 2</td>
<td class=br><strong>8</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>To Bucek</td><td class=kL>3:5</td>
<td class=kL>3:5 K</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>6:0 K</td>
<td class=kT>2:2 K</td>
<td class=kW>5:3</td>
<td class=br>26:19</td><td class=br>+7</td>
<td class=bc>3 - 2 - 2</td>
<td class=br><strong>8</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Vá Pikl</td><td class=kL>1:4 K</td>
<td class=kL>1:4</td>
<td class=kW>2:1 K</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>6:1</td>
<td class=kW>5:0 K</td>
<td class=br>17:14</td><td class=br>+3</td>
<td class=bc>4 - 0 - 3</td>
<td class=br><strong>8</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Mi Černoch</td><td class=kL>3:4</td>
<td class=kL>1:3 K</td>
<td class=kW>5:0</td>
<td class=kL>0:6 K</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>4:1 K</td>
<td class=kW>3:1</td>
<td class=br>16:16</td><td class=br>0</td>
<td class=bc>3 - 0 - 4</td>
<td class=br><strong>6</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>St Srba</td><td class=kL>1:4</td>
<td class=kW>2:1 K</td>
<td class=kL>0:6</td>
<td class=kT>2:2 K</td>
<td class=kL>1:6</td>
<td class=kL>1:4 K</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=br>12:23</td><td class=br>-11</td>
<td class=bc>2 - 1 - 4</td>
<td class=br><strong>5</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ja Medvec</td><td class=kL>1:7 K</td>
<td class=kL>2:3</td>
<td class=kL>3:4 K</td>
<td class=kL>3:5</td>
<td class=kL>0:5 K</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=br>10:32</td><td class=br>-22</td>
<td class=bc>0 - 0 - 7</td>
<td class=br><strong>0</strong></td><td class=d>8.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Medvec Jan</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Srba Stanislav</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Medvec Jan</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Srba Stanislav</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Srba Stanislav</td><td class=bc>-</td><td class=bl>Medvec Jan</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Medvec Jan</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Srba Stanislav</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>0 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Pe Holub</td><td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=br>13:5</td><td class=br>+8</td>
<td class=bc>2 - 1 - 0</td>
<td class=br><strong>5</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Mi Mašika</td><td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>1:2</td>
<td class=br>5:5</td><td class=br>0</td>
<td class=bc>1 - 1 - 1</td>
<td class=br><strong>3</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Ro Vomáčka</td><td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=br>5:7</td><td class=br>-2</td>
<td class=bc>1 - 0 - 2</td>
<td class=br><strong>2</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Da Hrachovec</td><td class=kL>1:7</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=br>6:12</td><td class=br>-6</td>
<td class=bc>1 - 0 - 2</td>
<td class=br><strong>2</strong></td><td class=d>4.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Hrachovec Daniel</td><td class=bc>-</td><td class=blW>Holub Petr</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Mašika Michal</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Hrachovec Daniel</td><td class=bc>-</td><td class=blW>Vomáčka Roman</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Holub Petr</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Hrachovec Daniel</td><td class=bc>1 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Ja Kopecký</td><td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=br>11:3</td><td class=br>+8</td>
<td class=bc>3 - 0 - 0</td>
<td class=br><strong>6</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Ra Hrnčíř</td><td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>8:0</td>
<td class=br>14:4</td><td class=br>+10</td>
<td class=bc>2 - 0 - 1</td>
<td class=br><strong>4</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Ma Moravec</td><td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=br>7:12</td><td class=br>-5</td>
<td class=bc>1 - 0 - 2</td>
<td class=br><strong>2</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Pe Klazar</td><td class=kL>2:3</td>
<td class=kL>0:8</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=br>2:15</td><td class=br>-13</td>
<td class=bc>0 - 0 - 3</td>
<td class=br><strong>0</strong></td><td class=d>4.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Kopecký Jaroslav</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Kopecký Jaroslav</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>8 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Kopecký Jaroslav</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>0 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group D</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Mi Horáková</td><td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>7:3</td>
<td class=kW>4:2</td>
<td class=br>16:7</td><td class=br>+9</td>
<td class=bc>3 - 0 - 0</td>
<td class=br><strong>6</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Ja Kubica</td><td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=br>6:6</td><td class=br>0</td>
<td class=bc>2 - 0 - 1</td>
<td class=br><strong>4</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Ja Fiedlerova</td><td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>6:10</td><td class=br>-4</td>
<td class=bc>1 - 0 - 2</td>
<td class=br><strong>2</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Ro Kubinec</td><td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>3:8</td><td class=br>-5</td>
<td class=bc>0 - 0 - 3</td>
<td class=br><strong>0</strong></td><td class=d>4.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Horáková Miroslava</td><td class=bc>-</td><td class=bl>Fiedlerova Jana</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Kubica Jan</td><td class=bc>-</td><td class=bl>Kubinec Roman</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Horáková Miroslava</td><td class=bc>-</td><td class=bl>Kubica Jan</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Fiedlerova Jana</td><td class=bc>-</td><td class=bl>Kubinec Roman</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Kubica Jan</td><td class=bc>-</td><td class=bl>Fiedlerova Jana</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kubinec Roman</td><td class=bc>-</td><td class=blW>Horáková Miroslava</td><td class=bc>2 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
