<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Olomouc</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/pohar13.aspx">U13</a>
&nbsp;<a href="../data/pohar55.aspx">55+</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../olomouc/index.aspx">Play-Off</a></span></h2></div></div></div></div><p><div align="center">
<table border=0 cellpadding=2 cellspacing=0>
<tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>Finals</strong></font></th></tr>
<tr><td class=br><b>Petr Patrik</b>&nbsp;&nbsp;</td>
<td class=bl>- Chylík ml. Jiří&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>6:3&nbsp;&nbsp;</td>
<td class=bl>4:2&nbsp;&nbsp;</td>
<td class=bl>3:4 P&nbsp;&nbsp;</td>
<td class=bl>8:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>1/2</strong></font></th></tr>
<tr><td class=ar><b>Petr Patrik</b>&nbsp;&nbsp;</td>
<td class=al>- Matýsek Jakub&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>5:3&nbsp;&nbsp;</td>
<td class=al>5:0&nbsp;&nbsp;</td>
<td class=al>3:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><b>Chylík ml. Jiří</b>&nbsp;&nbsp;</td>
<td class=bl>- Kobrle Michal&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 2&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:3&nbsp;&nbsp;</td>
<td class=bl>4:3&nbsp;&nbsp;</td>
<td class=bl>2:3&nbsp;&nbsp;</td>
<td class=bl>4:6&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>1/4</strong></font></th></tr>
<tr><td class=br><b>Petr Patrik</b>&nbsp;&nbsp;</td>
<td class=bl>- Touš Michal&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>9:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Matýsek Jakub</b>&nbsp;&nbsp;</td>
<td class=al>- Dryák Jan&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>6:3&nbsp;&nbsp;</td>
<td class=al>3:7&nbsp;&nbsp;</td>
<td class=al>3:8&nbsp;&nbsp;</td>
<td class=al>4:3&nbsp;&nbsp;</td>
<td class=al>4:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br>Ležík Matěj&nbsp;&nbsp;</td>
<td class=bl>- <b>Chylík ml. Jiří</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:3 P&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>2:3&nbsp;&nbsp;</td>
<td class=bl>1:6&nbsp;&nbsp;</td>
<td class=bl>1:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar>Herold Kryštof&nbsp;&nbsp;</td>
<td class=al>- <b>Kobrle Michal</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;0 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>0:5&nbsp;&nbsp;</td>
<td class=al>3:7&nbsp;&nbsp;</td>
<td class=al>4:5 P&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>1/8</strong></font></th></tr>
<tr><td class=br><b>Petr Patrik (1)</b>&nbsp;&nbsp;</td>
<td class=bl>- Lebl Kryštof (16)&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>7:2&nbsp;&nbsp;</td>
<td class=bl>4:3&nbsp;&nbsp;</td>
<td class=bl>7:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar>Matýsek Daniel (8)&nbsp;&nbsp;</td>
<td class=al>- <b>Touš Michal (9)</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;0 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>1:2 P&nbsp;&nbsp;</td>
<td class=al>1:3&nbsp;&nbsp;</td>
<td class=al>3:4 P&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><b>Matýsek Jakub (5)</b>&nbsp;&nbsp;</td>
<td class=bl>- Černoch Miroslav (12)&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 2&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>5:1&nbsp;&nbsp;</td>
<td class=bl>0:3&nbsp;&nbsp;</td>
<td class=bl>2:3 P&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Dryák Jan (4)</b>&nbsp;&nbsp;</td>
<td class=al>- Sládek Kuba (13)&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:4&nbsp;&nbsp;</td>
<td class=al>1:3&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>5:3&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><b>Ležík Matěj (3)</b>&nbsp;&nbsp;</td>
<td class=bl>- Šmíd David (14)&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:3 P&nbsp;&nbsp;</td>
<td class=bl>6:2&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Chylík ml. Jiří (6)</b>&nbsp;&nbsp;</td>
<td class=al>- Bucek Tomáš (11)&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:1&nbsp;&nbsp;</td>
<td class=al>4:0&nbsp;&nbsp;</td>
<td class=al>4:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br>Plešák Pavel (7)&nbsp;&nbsp;</td>
<td class=bl>- <b>Herold Kryštof (10)</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>1:0&nbsp;&nbsp;</td>
<td class=bl>1:3&nbsp;&nbsp;</td>
<td class=bl>6:3&nbsp;&nbsp;</td>
<td class=bl>1:2&nbsp;&nbsp;</td>
<td class=bl>2:4&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Kobrle Michal (2)</b>&nbsp;&nbsp;</td>
<td class=al>- Turoň Petr (15)&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>5:4&nbsp;&nbsp;</td>
<td class=al>4:3 P&nbsp;&nbsp;</td>
<td class=al>6:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>B Finals</strong></font></th></tr>
<tr><td class=br><b>Lopaur Zdeněk</b>&nbsp;&nbsp;</td>
<td class=bl>- Krejza Aleš&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:3&nbsp;&nbsp;</td>
<td class=bl>2:3 P&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>3:0&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>B 1/2</strong></font></th></tr>
<tr><td class=ar><b>Lopaur Zdeněk</b>&nbsp;&nbsp;</td>
<td class=al>- Ševr Miloš&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>4:2&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>6:5 P&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><b>Krejza Aleš</b>&nbsp;&nbsp;</td>
<td class=bl>- Vomáčka Josef&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:0&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>2:0&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td colspan=11>&nbsp;</td></tr>
<tr><th colspan=11 class="hh"><font size="+1"><strong>B 1/4</strong></font></th></tr>
<tr><td class=ar><b>Krejza Aleš (3)</b>&nbsp;&nbsp;</td>
<td class=al>- Lahučký Tomáš (6)&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>3:2 P&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>4:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br>Cibulka David (2)&nbsp;&nbsp;</td>
<td class=bl>- <b>Vomáčka Josef (7)</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;1 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:5&nbsp;&nbsp;</td>
<td class=bl>4:2&nbsp;&nbsp;</td>
<td class=bl>3:4&nbsp;&nbsp;</td>
<td class=bl>1:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Ševr Miloš (4)</b>&nbsp;&nbsp;</td>
<td class=al>- Nechutný Hynek (5)&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>4:1&nbsp;&nbsp;</td>
<td class=al>4:2&nbsp;&nbsp;</td>
<td class=al>5:3&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
