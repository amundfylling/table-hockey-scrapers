<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Turnov</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/pohar13.aspx">U13</a>
&nbsp;<a href="../data/pohar55.aspx">55+</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../tur/index.aspx">Turnov, 21. září 2024</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>25</td>
<td class=ic>26</td>
<td class=ic>27</td>
<td class=ic>28</td>
<td class=ic>29</td>
<td class=ic>30</td>
<td class=ic>31</td>
<td class=ic>32</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=409&x=-423&p=Pa%20Petr">Pa Petr</a></td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kL>5:6</td>
<td class=kW>7:3</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>6:3</td>
<td class=kW>6:1</td>
<td class=kW>6:3</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>7:4</td>
<td class=kW>7:0</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=kW>5:0 K</td>
<td class=br>153:50</td><td class=br>+103</td>
<td class=bc>29 - 1 - 1</td>
<td class=br><strong>59</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1477&x=-423&p=Mi%20Kobrle">Mi Kobrle</a></td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>6:3</td>
<td class=kT>4:4</td>
<td class=kL>1:6</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>5:4</td>
<td class=kW>4:1</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kW>7:5</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>8:1</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>10:1</td>
<td class=kW>4:2</td>
<td class=kW>8:0</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>10:0</td>
<td class=kW>5:0 K</td>
<td class=br>140:58</td><td class=br>+82</td>
<td class=bc>24 - 3 - 4</td>
<td class=br><strong>51</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=386&x=-423&p=Ku%20Sl%C3%A1dek">Ku Sládek</a></td><td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kW>2:0</td>
<td class=kL>0:3</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kL>4:5</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>8:0</td>
<td class=kW>5:0 K</td>
<td class=br>112:42</td><td class=br>+70</td>
<td class=bc>25 - 1 - 5</td>
<td class=br><strong>51</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=567&x=-423&p=Kr%20Lebl">Kr Lebl</a></td><td class=kL>4:5</td>
<td class=kL>3:6</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kL>4:6</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>6:4</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>4:3</td>
<td class=kW>8:0</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=kW>5:0 K</td>
<td class=br>113:69</td><td class=br>+44</td>
<td class=bc>19 - 8 - 4</td>
<td class=br><strong>46</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=961&x=-423&p=Mi%20Bo%C5%A1t%C3%ADk">Mi Boštík</a></td><td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kL>0:3</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>6:3</td>
<td class=kW>4:3</td>
<td class=kW>1:0</td>
<td class=kW>6:0</td>
<td class=kL>0:4</td>
<td class=kW>6:1</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>7:6</td>
<td class=kW>6:4</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>9:0</td>
<td class=kW>5:0 K</td>
<td class=br>118:69</td><td class=br>+49</td>
<td class=bc>20 - 5 - 6</td>
<td class=br><strong>45</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=993&x=-423&p=Ji%20Chyl%C3%ADk%20ml.">Ji Chylík ml.</a></td><td class=kL>2:5</td>
<td class=kW>6:1</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>7:0</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kL>0:4</td>
<td class=kW>2:0</td>
<td class=kL>3:5</td>
<td class=kW>6:2</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>9:1</td>
<td class=kW>6:1</td>
<td class=kW>8:1</td>
<td class=kW>5:0 K</td>
<td class=br>115:48</td><td class=br>+67</td>
<td class=bc>19 - 6 - 6</td>
<td class=br><strong>44</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1065&x=-423&p=Kr%20Herold">Kr Herold</a></td><td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kW>2:1</td>
<td class=kW>6:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kL>3:5</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0 K</td>
<td class=br>107:57</td><td class=br>+50</td>
<td class=bc>18 - 6 - 7</td>
<td class=br><strong>42</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=841&x=-423&p=Ma%20Le%C5%BE%C3%ADk">Ma Ležík</a></td><td class=kL>3:6</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kL>0:7</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kT>5:5</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>7:0</td>
<td class=kW>9:3</td>
<td class=kW>5:0</td>
<td class=kW>5:0 K</td>
<td class=br>111:70</td><td class=br>+41</td>
<td class=bc>18 - 6 - 7</td>
<td class=br><strong>42</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1&x=-423&p=Pa%20Ple%C5%A1%C3%A1k">Pa Plešák</a></td><td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kT>6:6</td>
<td class=kW>6:2</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>9:1</td>
<td class=kW>12:0</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>5:0 K</td>
<td class=br>117:71</td><td class=br>+46</td>
<td class=bc>16 - 9 - 6</td>
<td class=br><strong>41</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1912&x=-423&p=Al%20Krejza">Al Krejza</a></td><td class=kL>3:6</td>
<td class=kL>4:5</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kW>5:0</td>
<td class=kL>0:4</td>
<td class=kL>4:5</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kW>6:3</td>
<td class=kW>8:1</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=kW>5:0 K</td>
<td class=br>101:72</td><td class=br>+29</td>
<td class=bc>17 - 4 - 10</td>
<td class=br><strong>38</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=201&x=-423&p=To%20Bucek">To Bucek</a></td><td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>3:6</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>4:5</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=kW>9:0</td>
<td class=kW>8:0</td>
<td class=kW>5:0 K</td>
<td class=br>108:81</td><td class=br>+27</td>
<td class=bc>16 - 4 - 11</td>
<td class=br><strong>36</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=4&x=-423&p=Vl%20Kraus">Vl Kraus</a></td><td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kW>4:0</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>6:3</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kT>5:5</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0 K</td>
<td class=br>102:62</td><td class=br>+40</td>
<td class=bc>16 - 4 - 11</td>
<td class=br><strong>36</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=64&x=-423&p=Da%20%C5%A0m%C3%ADd">Da Šmíd</a></td><td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>5:4</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>8:1</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=kW>5:0 K</td>
<td class=br>92:70</td><td class=br>+22</td>
<td class=bc>16 - 4 - 11</td>
<td class=br><strong>36</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=248&x=-423&p=Ma%20%C5%BDen%C3%AD%C5%A1ek">Ma Ženíšek</a></td><td class=kW>6:5</td>
<td class=kT>4:4</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kT>4:4</td>
<td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kL>1:5</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kL>2:5</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kW>9:1</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>5:0 K</td>
<td class=br>113:84</td><td class=br>+29</td>
<td class=bc>14 - 8 - 9</td>
<td class=br><strong>36</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1268&x=-423&p=Da%20Dvo%C5%99%C3%A1%C4%8Dek">Da Dvořáček</a></td><td class=kL>3:7</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>4:6</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>0:5</td>
<td class=kW>5:4</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>4:5</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>11:0</td>
<td class=kW>7:2</td>
<td class=kW>7:1</td>
<td class=kW>9:1</td>
<td class=kW>5:0 K</td>
<td class=br>118:87</td><td class=br>+31</td>
<td class=bc>15 - 6 - 10</td>
<td class=br><strong>36</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=40&x=-423&p=Da%20Mat%C3%BDsek">Da Matýsek</a></td><td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kW>5:4</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>1:6</td>
<td class=kW>2:0</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kW>5:1</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>5:0 K</td>
<td class=br>74:61</td><td class=br>+13</td>
<td class=bc>16 - 3 - 12</td>
<td class=br><strong>35</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=53&x=-423&p=V%C3%A1%20Pikl">Vá Pikl</a></td><td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>0:6</td>
<td class=kW>4:0</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kW>5:4</td>
<td class=kW>7:3</td>
<td class=kW>7:0</td>
<td class=kW>2:1</td>
<td class=kW>5:0 K</td>
<td class=br>76:71</td><td class=br>+5</td>
<td class=bc>14 - 7 - 10</td>
<td class=br><strong>35</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1641&x=-423&p=Ma%20Klazar">Ma Klazar</a></td><td class=kL>0:3</td>
<td class=kW>5:1</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kT>6:6</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kW>6:2</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=kW>5:0 K</td>
<td class=br>86:69</td><td class=br>+17</td>
<td class=bc>14 - 4 - 13</td>
<td class=br><strong>32</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1927&x=-423&p=Vo%20Kraus">Vo Kraus</a></td><td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kW>5:3</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kT>5:5</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>6:5</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0 K</td>
<td class=br>97:99</td><td class=br>-2</td>
<td class=bc>13 - 5 - 13</td>
<td class=br><strong>31</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=818&x=-423&p=Ro%20Je%C5%BE">Ro Jež</a></td><td class=kL>1:6</td>
<td class=kL>5:7</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>2:6</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kW>5:0</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>0:1</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kT>0:0</td>
<td class=kL>1:4</td>
<td class=kW>6:3</td>
<td class=kW>1:0</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=kW>5:0 K</td>
<td class=br>94:75</td><td class=br>+19</td>
<td class=bc>13 - 5 - 13</td>
<td class=br><strong>31</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=310&x=-423&p=Mi%20%C4%8Cernoch">Mi Černoch</a></td><td class=kL>3:6</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kT>5:5</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kW>5:2</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kL>5:6</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kW>7:0</td>
<td class=kW>7:0</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0 K</td>
<td class=br>85:75</td><td class=br>+10</td>
<td class=bc>11 - 8 - 12</td>
<td class=br><strong>30</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=18&x=-423&p=An%20%C5%A0ur%C3%BDn">An Šurýn</a></td><td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>6:5</td>
<td class=kW>9:1</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>5:0 K</td>
<td class=br>67:76</td><td class=br>-9</td>
<td class=bc>11 - 5 - 15</td>
<td class=br><strong>27</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2018&x=-423&p=Ja%20Janou%C5%A1kovec">Ja Janouškovec</a></td><td class=kL>1:7</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>6:7</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kL>0:7</td>
<td class=kL>1:8</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kT>0:0</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0 K</td>
<td class=br>83:109</td><td class=br>-26</td>
<td class=bc>11 - 3 - 17</td>
<td class=br><strong>25</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=26&x=-423&p=Mi%20%C5%A0evr">Mi Ševr</a></td><td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>4:6</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kL>2:6</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>8:1</td>
<td class=kW>9:0</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>5:0 K</td>
<td class=br>72:84</td><td class=br>-12</td>
<td class=bc>10 - 4 - 17</td>
<td class=br><strong>24</strong></td><td class=d>24.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>25.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=215&x=-423&p=Jo%20Vom%C3%A1%C4%8Dka">Jo Vomáčka</a></td><td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kW>5:3</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>5:0 K</td>
<td class=br>69:94</td><td class=br>-25</td>
<td class=bc>8 - 3 - 20</td>
<td class=br><strong>19</strong></td><td class=d>25.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>26.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=204&x=-423&p=Hy%20Nechutn%C3%BD">Hy Nechutný</a></td><td class=kL>1:6</td>
<td class=kL>1:10</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>0:7</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kL>0:5</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kL>4:6</td>
<td class=kW>4:1</td>
<td class=kW>5:0 K</td>
<td class=br>57:103</td><td class=br>-46</td>
<td class=bc>7 - 4 - 20</td>
<td class=br><strong>18</strong></td><td class=d>26.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>27.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=216&x=-423&p=Ro%20Vom%C3%A1%C4%8Dka">Ro Vomáčka</a></td><td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kW>5:4</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>0:0</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>5:0 K</td>
<td class=br>47:114</td><td class=br>-67</td>
<td class=bc>7 - 3 - 21</td>
<td class=br><strong>17</strong></td><td class=d>27.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>28.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1896&x=-423&p=Ra%20Hrn%C4%8D%C3%AD%C5%99">Ra Hrnčíř</a></td><td class=kL>4:7</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:9</td>
<td class=kL>3:6</td>
<td class=kL>3:6</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kL>0:11</td>
<td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>0:7</td>
<td class=kL>5:6</td>
<td class=kL>0:2</td>
<td class=kL>1:8</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>5:0 K</td>
<td class=br>58:145</td><td class=br>-87</td>
<td class=bc>3 - 3 - 25</td>
<td class=br><strong>9</strong></td><td class=d>28.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>29.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1430&x=-423&p=Da%20Kadlec">Da Kadlec</a></td><td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kL>0:8</td>
<td class=kL>2:6</td>
<td class=kL>1:9</td>
<td class=kL>0:5</td>
<td class=kL>0:7</td>
<td class=kL>0:12</td>
<td class=kL>1:8</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>1:9</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kL>3:7</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kL>1:9</td>
<td class=kL>2:6</td>
<td class=kL>0:9</td>
<td class=kL>0:2</td>
<td class=kT>4:4</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>5:0 K</td>
<td class=br>42:173</td><td class=br>-131</td>
<td class=bc>2 - 4 - 25</td>
<td class=br><strong>8</strong></td><td class=d>29.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>30.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2019&x=-423&p=Pa%20Janou%C5%A1kovec">Pa Janouškovec</a></td><td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>3:9</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>0:9</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>0:7</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kW>6:4</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:0 K</td>
<td class=br>48:151</td><td class=br>-103</td>
<td class=bc>3 - 2 - 26</td>
<td class=br><strong>8</strong></td><td class=d>30.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>31.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2029&x=-423&p=On%20Gruncl">On Gruncl</a></td><td class=kL>0:7</td>
<td class=kL>0:10</td>
<td class=kL>0:8</td>
<td class=kL>0:7</td>
<td class=kL>0:9</td>
<td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kL>1:7</td>
<td class=kL>0:8</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>1:9</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:0 K</td>
<td class=br>25:156</td><td class=br>-131</td>
<td class=bc>2 - 0 - 29</td>
<td class=br><strong>4</strong></td><td class=d>31.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>32.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2133&x=-423&p=Pe%20Kobrle">Pe Kobrle</a></td><td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kx>*</td>
<td class=br>0:155</td><td class=br>-155</td>
<td class=bc>0 - 0 - 31</td>
<td class=br><strong>0</strong></td><td class=d>32.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Kobrle Petr</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Janouškovec Pavel</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Vomáčka Roman</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Šmíd David</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Kobrle Petr</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Ležík Matěj</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>7 : 5</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Vomáčka Roman</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Šmíd David</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Kobrle Petr</td><td class=bc>-</td><td class=blW>Janouškovec Pavel</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Ležík Matěj</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Šmíd David</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Boštík Michal</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Kobrle Petr</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Ležík Matěj</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Vomáčka Josef</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kobrle Petr</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Ležík Matěj</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Šmíd David</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Kobrle Petr</td><td class=bc>-</td><td class=blW>Vomáčka Josef</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Ležík Matěj</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Boštík Michal</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Šmíd David</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Vomáčka Roman</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Kobrle Petr</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Boštík Michal</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Šmíd David</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Kobrle Petr</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>6 : 7</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=blW>Šmíd David</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Kobrle Petr</td><td class=bc>-</td><td class=blW>Kadlec Daniel</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Ležík Matěj</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Šmíd David</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>4 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Boštík Michal</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Kobrle Petr</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Šmíd David</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Vomáčka Josef</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Boštík Michal</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Šmíd David</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kobrle Petr</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Šmíd David</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Kobrle Petr</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 10</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Boštík Michal</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Šmíd David</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kobrle Petr</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Ležík Matěj</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=bl>Šmíd David</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Vomáčka Roman</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Kobrle Petr</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Šmíd David</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kobrle Petr</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Šmíd David</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kobrle Petr</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>0 : 5 K</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Šmíd David</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Ležík Matěj</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Kobrle Petr</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Šmíd David</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>3 : 9</tr></td>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Kobrle Petr</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Šmíd David</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Vomáčka Roman</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=bl>Ležík Matěj</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Kobrle Petr</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Kobrle Petr</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=bl>Vomáčka Roman</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Kobrle Petr</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Šmíd David</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Boštík Michal</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Kobrle Petr</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Petr Patrik</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Šmíd David</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Boštík Michal</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=bl>Ležík Matěj</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Kobrle Petr</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Šmíd David</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Kobrle Petr</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Kobrle Petr</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Janouškovec Pavel</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>26</td></tr>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Ležík Matěj</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Šmíd David</td><td class=bc>-</td><td class=bl>Kobrle Petr</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>0 : 11</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>27</td></tr>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Vomáčka Roman</td><td class=bc>-</td><td class=bl>Kobrle Petr</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kadlec Daniel</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>28</td></tr>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Kobrle Petr</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Šmíd David</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Boštík Michal</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>0 : 12</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Vomáčka Josef</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>29</td></tr>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Ležík Matěj</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Kobrle Petr</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>6 : 6</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Vomáčka Josef</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>30</td></tr>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Kobrle Petr</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Boštík Michal</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Vomáčka Josef</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>31</td></tr>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Kobrle Petr</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Vomáčka Roman</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Vomáčka Josef</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Boštík Michal</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>32</td></tr>
<tr><td class=br>Ležík Matěj</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Vomáčka Roman</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Šmíd David</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
