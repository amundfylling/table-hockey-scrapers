<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN">
<html lang="cz">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<title>MR veteráni</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
</head>
<body class="neop">
<a name="Zac"><p class=l>MR veteráni, 4. červen 2017</p></a>
<div align=center><p>
<a href="mrvet.aspx">Tabulka</a><br>
<a href="MR_veterani_umisteni.aspx">Play-off</a><br>
<a href="index.aspx">Zpět / Back</a></p></div>
<a name="basic"><p class=vm>Základní skupiny (Basic groups)</p></a>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=2 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>25</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>J</td><td class=ir>1</td><td class=kt>Da Šmíd</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0 K</td>
<td class=br>94:30</td><td class=br>+64</td>
<td class=bc>20 - 2 - 2</td>
<td class=br>42</td><td class=d>1.</td>
</tr><tr><td class=ir>J</td><td class=ir>2</td><td class=kt>Pa Plešák</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>6:1</td>
<td class=kL>3:4</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>6:3</td>
<td class=kW>6:2</td>
<td class=kW>5:4</td>
<td class=kW>7:2</td>
<td class=kW>9:1</td>
<td class=kW>8:3</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>8:0</td>
<td class=kW>4:0</td>
<td class=kW>5:0 K</td>
<td class=br>114:40</td><td class=br>+74</td>
<td class=bc>19 - 3 - 2</td>
<td class=br>41</td><td class=d>2.</td>
</tr><tr><td class=ir>J</td><td class=ir>3</td><td class=kt>Pe Turoň</td><td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kW>6:3</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>8:2</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>6:2</td>
<td class=kW>5:0 K</td>
<td class=br>99:35</td><td class=br>+64</td>
<td class=bc>19 - 3 - 2</td>
<td class=br>41</td><td class=d>3.</td>
</tr><tr><td class=ir>J</td><td class=ir>4</td><td class=kt>Vá Pikl</td><td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>8:2</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>5:0 K</td>
<td class=br>87:30</td><td class=br>+57</td>
<td class=bc>17 - 3 - 4</td>
<td class=br>37</td><td class=d>4.</td>
</tr><tr><td class=ir>J</td><td class=ir>5</td><td class=kt>Da Matýsek</td><td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kL>4:5</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>7:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>5:0 K</td>
<td class=br>78:34</td><td class=br>+44</td>
<td class=bc>17 - 3 - 4</td>
<td class=br>37</td><td class=d>5.</td>
</tr><tr><td class=ir>J</td><td class=ir>6</td><td class=kt>Da Cibulka</td><td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0 K</td>
<td class=br>74:41</td><td class=br>+33</td>
<td class=bc>16 - 2 - 6</td>
<td class=br>34</td><td class=d>6.</td>
</tr><tr><td class=ir>J</td><td class=ir>7</td><td class=kt>Vl Kraus</td><td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kW>4:0</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>8:0</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kW>5:0 K</td>
<td class=br>90:55</td><td class=br>+35</td>
<td class=bc>16 - 0 - 8</td>
<td class=br>32</td><td class=d>7.</td>
</tr><tr><td class=ir>J</td><td class=ir>8</td><td class=kt>Zd Lopaur</td><td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0 K</td>
<td class=br>62:52</td><td class=br>+10</td>
<td class=bc>12 - 4 - 8</td>
<td class=br>28</td><td class=d>8.</td>
</tr><tr><td class=ir>J</td><td class=ir>9</td><td class=kt>Ka Krejčík</td><td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kL>1:2</td>
<td class=kW>5:0 K</td>
<td class=br>69:50</td><td class=br>+19</td>
<td class=bc>11 - 5 - 8</td>
<td class=br>27</td><td class=d>9.</td>
</tr><tr><td class=ir>J</td><td class=ir>10</td><td class=kt>Zb Froněk</td><td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kL>3:7</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kL>0:7</td>
<td class=kT>4:4</td>
<td class=kW>8:3</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>5:0 K</td>
<td class=br>67:64</td><td class=br>+3</td>
<td class=bc>12 - 3 - 9</td>
<td class=br>27</td><td class=d>10.</td>
</tr><tr><td class=ir>J</td><td class=ir>11</td><td class=kt>Ro Jež</td><td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kT>0:0</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>5:0 K</td>
<td class=br>65:66</td><td class=br>-1</td>
<td class=bc>12 - 2 - 10</td>
<td class=br>26</td><td class=d>11.</td>
</tr><tr><td class=ir>J</td><td class=ir>12</td><td class=kt>Zd Matoušek st.</td><td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>5:0 K</td>
<td class=br>55:53</td><td class=br>+2</td>
<td class=bc>11 - 3 - 10</td>
<td class=br>25</td><td class=d>12.</td>
</tr><tr><td class=ir>J</td><td class=ir>13</td><td class=kt>Jo Kůrka</td><td class=kL>3:4</td>
<td class=kL>3:6</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>3:6</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kW>7:3</td>
<td class=kW>4:2</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>8:4</td>
<td class=kL>3:6</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>6:3</td>
<td class=kW>3:0</td>
<td class=kL>3:7</td>
<td class=kW>5:0</td>
<td class=kW>5:0 K</td>
<td class=br>83:72</td><td class=br>+11</td>
<td class=bc>12 - 1 - 11</td>
<td class=br>25</td><td class=d>13.</td>
</tr><tr><td class=ir>J</td><td class=ir>14</td><td class=kt>To Bucek</td><td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>8:1</td>
<td class=kW>8:0</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kL>3:6</td>
<td class=kW>3:1</td>
<td class=kW>5:0 K</td>
<td class=br>75:66</td><td class=br>+9</td>
<td class=bc>11 - 3 - 10</td>
<td class=br>25</td><td class=d>14.</td>
</tr><tr><td class=ir>J</td><td class=ir>15</td><td class=kt>Fr Marek</td><td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>5:0 K</td>
<td class=br>68:64</td><td class=br>+4</td>
<td class=bc>9 - 3 - 12</td>
<td class=br>21</td><td class=d>15.</td>
</tr><tr><td class=ir>J</td><td class=ir>16</td><td class=kt>Da Hrachovec</td><td class=kL>0:6</td>
<td class=kL>2:7</td>
<td class=kL>2:8</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kW>7:0</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>4:8</td>
<td class=kL>1:8</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>5:0 K</td>
<td class=br>65:83</td><td class=br>-18</td>
<td class=bc>10 - 0 - 14</td>
<td class=br>20</td><td class=d>16.</td>
</tr><tr><td class=ir>J</td><td class=ir>17</td><td class=kt>Ja Medvec</td><td class=kL>1:6</td>
<td class=kL>1:9</td>
<td class=kL>2:7</td>
<td class=kL>0:6</td>
<td class=kL>3:7</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kL>0:8</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>5:0 K</td>
<td class=br>47:91</td><td class=br>-44</td>
<td class=bc>8 - 3 - 13</td>
<td class=br>19</td><td class=d>17.</td>
</tr><tr><td class=ir>J</td><td class=ir>18</td><td class=kt>To Kahoun st.</td><td class=kL>1:4</td>
<td class=kL>3:8</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>3:8</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0 K</td>
<td class=br>47:72</td><td class=br>-25</td>
<td class=bc>9 - 1 - 14</td>
<td class=br>19</td><td class=d>18.</td>
</tr><tr><td class=ir>J</td><td class=ir>19</td><td class=kt>To Halama</td><td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kL>1:7</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>4:5</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>5:0 K</td>
<td class=br>55:71</td><td class=br>-16</td>
<td class=bc>8 - 2 - 14</td>
<td class=br>18</td><td class=d>19.</td>
</tr><tr><td class=ir>J</td><td class=ir>20</td><td class=kt>St Srba</td><td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>5:0 K</td>
<td class=br>44:65</td><td class=br>-21</td>
<td class=bc>6 - 5 - 13</td>
<td class=br>17</td><td class=d>20.</td>
</tr><tr><td class=ir>J</td><td class=ir>21</td><td class=kt>Ja Klokan</td><td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kL>3:6</td>
<td class=kW>5:1</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>5:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0 K</td>
<td class=br>52:76</td><td class=br>-24</td>
<td class=bc>7 - 2 - 15</td>
<td class=br>16</td><td class=d>21.</td>
</tr><tr><td class=ir>J</td><td class=ir>22</td><td class=kt>Da Hejnoch</td><td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>2:8</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>0:8</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>5:0 K</td>
<td class=br>25:77</td><td class=br>-52</td>
<td class=bc>4 - 1 - 19</td>
<td class=br>9</td><td class=d>22.</td>
</tr><tr><td class=ir>J</td><td class=ir>23</td><td class=kt>Ja Ouřada</td><td class=kL>1:7</td>
<td class=kL>0:8</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kW>7:3</td>
<td class=kW>6:3</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:0 K</td>
<td class=br>45:100</td><td class=br>-55</td>
<td class=bc>4 - 0 - 20</td>
<td class=br>8</td><td class=d>23.</td>
</tr><tr><td class=ir>J</td><td class=ir>24</td><td class=kt>Pe Sládek</td><td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:0 K</td>
<td class=br>28:81</td><td class=br>-53</td>
<td class=bc>3 - 0 - 21</td>
<td class=br>6</td><td class=d>24.</td>
</tr><tr><td class=ir>J</td><td class=ir>25</td><td class=kt>Mi Ševr</td><td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kx>*</td>
<td class=br>0:120</td><td class=br>-120</td>
<td class=bc>0 - 0 - 24</td>
<td class=br>0</td><td class=d>25.</td>
</tr></table></td></tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Zb Froněk</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Da Hejnoch</td><td class=bc>-</td><td class=bl>Pe Sládek</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ja Klokan</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ka Krejčík</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Zb Froněk</td><td class=bc>-</td><td class=bl>Pe Sládek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ja Klokan</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ka Krejčík</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Pe Sládek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Zb Froněk</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Ja Medvec</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ja Klokan</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Pe Sládek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pe Turoň</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Zb Froněk</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Jo Kůrka</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Klokan</td><td class=bc>-</td><td class=blW>Ka Krejčík</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Pe Sládek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Zb Froněk</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Jo Kůrka</td><td class=bc>4 : 8</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Ka Krejčík</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Ja Ouřada</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Pe Turoň</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zb Froněk</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Jo Kůrka</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Ka Krejčík</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>Ja Klokan</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=blW>Ja Ouřada</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zb Froněk</td><td class=bc>-</td><td class=blW>Ka Krejčík</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Da Hejnoch</td><td class=bc>-</td><td class=bl>Ja Klokan</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Ka Krejčík</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Zb Froněk</td><td class=bc>-</td><td class=bl>Ja Klokan</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Ja Medvec</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Jo Kůrka</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ka Krejčík</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ja Klokan</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Zb Froněk</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=blW>Jo Kůrka</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Ka Krejčík</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ja Klokan</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Zb Froněk</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ka Krejčík</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Ja Klokan</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ja Medvec</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Ka Krejčík</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ja Klokan</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Zb Froněk</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Ka Krejčík</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Ja Klokan</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Zb Froněk</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Pe Turoň</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Jo Kůrka</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>Ka Krejčík</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ja Klokan</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ja Medvec</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Zb Froněk</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Jo Kůrka</td><td class=bc>-</td><td class=blW>Ka Krejčík</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Ja Klokan</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Da Hejnoch</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Zb Froněk</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>0 : 5 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Ka Krejčík</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>Ja Klokan</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Zb Froněk</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ja Klokan</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ka Krejčík</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Zb Froněk</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ja Ouřada</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Pe Turoň</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pe Sládek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 0 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ja Klokan</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ka Krejčík</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Zb Froněk</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ja Klokan</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Ka Krejčík</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>Zb Froněk</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ja Medvec</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Pe Sládek</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ja Klokan</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Zb Froněk</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ka Krejčík</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ja Medvec</td><td class=bc>-</td><td class=bl>Pe Sládek</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Zb Froněk</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Ja Klokan</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ka Krejčík</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Jo Kůrka</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Pe Sládek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Zb Froněk</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Klokan</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ka Krejčík</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Jo Kůrka</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Pe Sládek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Zb Froněk</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ja Klokan</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ka Krejčík</td><td class=bc>-</td><td class=blW>Pe Sládek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jo Kůrka</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Ja Medvec</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Zb Froněk</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ja Klokan</td><td class=bc>-</td><td class=bl>Pe Sládek</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ka Krejčík</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jo Kůrka</td><td class=bc>-</td><td class=blW>Ja Ouřada</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Zb Froněk</td><td class=bc>-</td><td class=bl>Pe Turoň</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Da Hejnoch</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Pe Sládek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Ja Klokan</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ka Krejčík</td><td class=bc>-</td><td class=blW>Ja Medvec</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Jo Kůrka</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>3 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p>&nbsp;</p>
<div align=center><p>Created by <b>Trefik</b>, table hockey edition. Copyright 2003-2017 Vladimír Kraus<br><a href="http://www.trefik.cz">www.trefik.cz</a></p></div>
</body></html>
