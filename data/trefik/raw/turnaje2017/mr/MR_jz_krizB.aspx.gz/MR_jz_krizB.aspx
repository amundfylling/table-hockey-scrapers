<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN">
<html lang="cz">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<title>MR junioři</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
</head>
<body class="neop">
<a name="Zac"><p class=l>MR junioři + ženy, 4. červen 2017</p></a>
<div align=center><p>
<a href="index.aspx">Zpět / Back</a></p></div>

<h3 align="center">Play-off ženy</h3>
<p align="center">
<b>sf</b>
<br>
Gobyová - Horáková 6-0 6-2 5-0
<br>
Mašková - Marešová 1-2 0-2 2-1p 1-3
<br><br>
<b>o 3.</b>
<br>
Mašková - Horáková 6-3 7-2 5-1
<br><br>
<b>finále</b>
<br>
Gobyová - Marešová 1-0 5-2 3-1 

</p>

<h3 align="center">Konečné pořadí - ženy</h3>
<p align="center">
<b>1. Vlasta Gobyová</b><br>
<b>2. Hana Marešová</b><br>
<b>3. Iva Mašková</b><br>
4. Miroslava Horáková<br>
5. Anita Grimová <br>

</p>



<h3 align="center">Play-off junioři</h3>
<p align="center">
Kobrle - Komárek 8-2 9-1 8-1
<br>
Matýsek - Blažek 2-0 5-0 1-0
<br>
Sládek - Bernát 6-2 7-0 9-3
<br>
Kahoun - Růžička 4-1 3-1 2-1
<br><br>
semifinále
<br>
Kobrle - Kahoun 4-2 5-2 4-2
<br>
Matýsek - Sládek 1-2 2-3p 1-5
<br>
<br>
o 3.
<br>
Matýsek - Kahoun 2-0 1-0 2-1
<br><br>
finále
<br>
Kobrle - Sládek 2-5 6-2 7-1 4-3 
</p>

<h3 align="center">Konečné pořadí - junioři</h3>
<p align="center">
<b>1. Michal Kobrle</b><br>
<b>2. Jan Sládek</b><br>
<b>3. Jakub Matýsek</b><br>
4. Lukáš Kahoun<br>
5. Tomáš Růžička <br>
6. Vojtěch Bernát <br>
7. Michal Blažek<br>
8. Pavel Komárek<br>
9. Vít Perkner<br>
10. Matyáš Klazar<br>
11. Ondřej Pulec<br>
12. Pavel Hráský <br>
13. Jonáš Perkner<br>
14. Anita Grimová <br>
15. Vojtěch Fiřt<br>
</p>


<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=2 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>J</td><td class=ir>1</td><td class=kt>Mi Kobrle</td><td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kT>4:4</td>
<td class=kT>4:4</td>
<td class=kW>6:5</td>
<td class=kW>8:3</td>
<td class=kW>9:0</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>7:3</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=br>95:30</td><td class=br>+65</td>
<td class=bc>15 - 2 - 1</td>
<td class=br>32</td><td class=d>1.</td>
</tr><tr><td class=ir>J</td><td class=ir>2</td><td class=kt>Ja Matýsek</td><td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>7:4</td>
<td class=kW>6:0</td>
<td class=kW>7:3</td>
<td class=kL>1:2</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=kW>9:2</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=br>91:26</td><td class=br>+65</td>
<td class=bc>16 - 0 - 2</td>
<td class=br>32</td><td class=d>2.</td>
</tr><tr><td class=ir>J</td><td class=ir>3</td><td class=kt>Ho Sládek</td><td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>7:2</td>
<td class=kW>9:2</td>
<td class=kW>11:2</td>
<td class=kW>5:1</td>
<td class=kW>10:0</td>
<td class=kW>6:0</td>
<td class=kW>9:1</td>
<td class=kW>7:1</td>
<td class=kW>10:0</td>
<td class=kW>8:0</td>
<td class=kW>6:1</td>
<td class=kW>13:0</td>
<td class=kW>7:1</td>
<td class=kW>13:1</td>
<td class=br>135:26</td><td class=br>+109</td>
<td class=bc>15 - 2 - 1</td>
<td class=br>32</td><td class=d>3.</td>
</tr><tr><td class=ir>J</td><td class=ir>4</td><td class=kt>Lu Kahoun</td><td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=br>71:22</td><td class=br>+49</td>
<td class=bc>13 - 3 - 2</td>
<td class=br>29</td><td class=d>4.</td>
</tr><tr><td class=ir>J</td><td class=ir>5</td><td class=kt>Vl Gobyová</td><td class=kL>5:6</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=br>65:28</td><td class=br>+37</td>
<td class=bc>14 - 0 - 4</td>
<td class=br>28</td><td class=d>5.</td>
</tr><tr><td class=ir>J</td><td class=ir>6</td><td class=kt>Iv Mašková</td><td class=kL>3:8</td>
<td class=kL>4:7</td>
<td class=kL>2:7</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>11:1</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=br>66:43</td><td class=br>+23</td>
<td class=bc>14 - 0 - 4</td>
<td class=br>28</td><td class=d>6.</td>
</tr><tr><td class=ir>J</td><td class=ir>7</td><td class=kt>To Růžička</td><td class=kL>0:9</td>
<td class=kL>0:6</td>
<td class=kL>2:9</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=br>35:41</td><td class=br>-6</td>
<td class=bc>11 - 1 - 6</td>
<td class=br>23</td><td class=d>7.</td>
</tr><tr><td class=ir>J</td><td class=ir>8</td><td class=kt>Vo Bernát</td><td class=kL>1:5</td>
<td class=kL>3:7</td>
<td class=kL>2:11</td>
<td class=kL>1:7</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kT>5:5</td>
<td class=kW>3:2</td>
<td class=kW>8:0</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>11:1</td>
<td class=kW>2:1</td>
<td class=kW>8:0</td>
<td class=br>67:59</td><td class=br>+8</td>
<td class=bc>10 - 1 - 7</td>
<td class=br>21</td><td class=d>8.</td>
</tr><tr><td class=ir>J</td><td class=ir>9</td><td class=kt>Ha Marešová</td><td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=br>35:34</td><td class=br>+1</td>
<td class=bc>9 - 1 - 8</td>
<td class=br>19</td><td class=d>9.</td>
</tr><tr><td class=ir>J</td><td class=ir>10</td><td class=kt>Mi Blažek</td><td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>0:10</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>7:0</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=br>45:53</td><td class=br>-8</td>
<td class=bc>8 - 0 - 10</td>
<td class=br>16</td><td class=d>10.</td>
</tr><tr><td class=ir>J</td><td class=ir>11</td><td class=kt>Pa Komárek</td><td class=kL>3:7</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=br>42:47</td><td class=br>-5</td>
<td class=bc>7 - 1 - 10</td>
<td class=br>15</td><td class=d>11.</td>
</tr><tr><td class=ir>J</td><td class=ir>12</td><td class=kt>Ví Perkner</td><td class=kL>0:7</td>
<td class=kL>2:9</td>
<td class=kL>1:9</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kT>5:5</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kW>8:1</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=br>37:66</td><td class=br>-29</td>
<td class=bc>5 - 4 - 9</td>
<td class=br>14</td><td class=d>12.</td>
</tr><tr><td class=ir>J</td><td class=ir>13</td><td class=kt>Mi Horáková</td><td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>1:11</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>1:8</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kL>1:4</td>
<td class=kW>7:1</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=br>36:68</td><td class=br>-32</td>
<td class=bc>5 - 1 - 12</td>
<td class=br>11</td><td class=d>13.</td>
</tr><tr><td class=ir>J</td><td class=ir>14</td><td class=kt>Ma Klazar</td><td class=kW>3:0</td>
<td class=kL>0:3</td>
<td class=kL>0:10</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kL>0:8</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kT>0:0</td>
<td class=kW>4:1</td>
<td class=br>13:49</td><td class=br>-36</td>
<td class=bc>4 - 2 - 12</td>
<td class=br>10</td><td class=d>14.</td>
</tr><tr><td class=ir>J</td><td class=ir>15</td><td class=kt>On Pulec</td><td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>0:8</td>
<td class=kL>0:2</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=br>12:52</td><td class=br>-40</td>
<td class=bc>3 - 2 - 13</td>
<td class=br>8</td><td class=d>15.</td>
</tr><tr><td class=ir>J</td><td class=ir>16</td><td class=kt>Pa Hráský</td><td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=br>22:53</td><td class=br>-31</td>
<td class=bc>2 - 4 - 12</td>
<td class=br>8</td><td class=d>16.</td>
</tr><tr><td class=ir>J</td><td class=ir>17</td><td class=kt>Jo Perkner</td><td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>0:13</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>1:11</td>
<td class=kL>0:3</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=br>15:80</td><td class=br>-65</td>
<td class=bc>2 - 2 - 14</td>
<td class=br>6</td><td class=d>17.</td>
</tr><tr><td class=ir>J</td><td class=ir>18</td><td class=kt>An Grimová</td><td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kT>0:0</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=br>25:54</td><td class=br>-29</td>
<td class=bc>2 - 2 - 14</td>
<td class=br>6</td><td class=d>18.</td>
</tr><tr><td class=ir>J</td><td class=ir>19</td><td class=kt>Vo Fiřt</td><td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>1:13</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>0:8</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=br>9:85</td><td class=br>-76</td>
<td class=bc>1 - 2 - 15</td>
<td class=br>4</td><td class=d>19.</td>
</tr></table></td></tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>2 : 11</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vo Fiřt</td><td class=bc>-</td><td class=blW>On Pulec</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Pa Komárek</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>On Pulec</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Vo Fiřt</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ha Marešová</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Pa Komárek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>On Pulec</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>11 : 1</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Vo Fiřt</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Pa Komárek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>On Pulec</td><td class=bc>-</td><td class=blW>Ví Perkner</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vo Fiřt</td><td class=bc>-</td><td class=blW>Pa Komárek</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>On Pulec</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Pa Komárek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Vo Fiřt</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>On Pulec</td><td class=bc>-</td><td class=blW>Ha Marešová</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Pa Komárek</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vo Fiřt</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ha Marešová</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Pa Komárek</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>On Pulec</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Vo Fiřt</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Pa Komárek</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>On Pulec</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ha Marešová</td><td class=bc>-</td><td class=bl>Pa Komárek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>On Pulec</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Vo Fiřt</td><td class=bc>8 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Pa Komárek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Ha Marešová</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>On Pulec</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Vo Fiřt</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>10 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Pa Komárek</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ha Marešová</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>11 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=bl>Vo Fiřt</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>On Pulec</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Pa Komárek</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ha Marešová</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Vo Fiřt</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>On Pulec</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Pa Komárek</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ha Marešová</td><td class=bc>-</td><td class=bl>Vo Fiřt</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 13</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vo Fiřt</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Pa Komárek</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>On Pulec</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Vo Fiřt</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pa Komárek</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>On Pulec</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>9 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Vo Fiřt</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Pa Komárek</td><td class=bc>-</td><td class=bl>On Pulec</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=blW>Ví Perkner</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Vo Fiřt</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>On Pulec</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Pa Komárek</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ha Marešová</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Vo Fiřt</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>On Pulec</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Pa Komárek</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Vo Fiřt</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 13</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>On Pulec</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ví Perkner</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>3 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p>&nbsp;</p>
<div align=center><p>Created by <b>Trefik</b>, table hockey edition. Copyright 2003-2017 Vladimír Kraus<br><a href="http://www.trefik.cz">www.trefik.cz</a></p></div>
</body></html>
