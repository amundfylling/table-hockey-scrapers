<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN">
<html lang="cz">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<title>MR veteráni</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
</head>
<body class="neop">
<p class=l>MR veteráni, 4. červen 2017</p>
<div align=center><p><a href="index.aspx">Back</a><br></p></div>
<p class=v>Play-off<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><th colspan=11><font size="+1"><strong>Finals</strong></font></th></tr>
<tr><td class=br>Šmíd David&nbsp;&nbsp;</td>
<td class=bl><b>- Plešák Pavel</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>1:6&nbsp;&nbsp;</td>
<td class=bl>5:3&nbsp;&nbsp;</td>
<td class=bl>3:2 P&nbsp;&nbsp;</td>
<td class=bl>1:2&nbsp;&nbsp;</td>
<td class=bl>3:5&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>Semifinals</strong></font></th></tr>
<tr><td class=ar><b>Šmíd David</b>&nbsp;&nbsp;</td>
<td class=al>- Matýsek Daniel&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 1&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:2 P&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>0:1 P&nbsp;&nbsp;</td>
<td class=al>4:3 P&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br>Cibulka David&nbsp;&nbsp;</td>
<td class=bl><b>- Plešák Pavel</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;0 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:4&nbsp;&nbsp;</td>
<td class=bl>2:6&nbsp;&nbsp;</td>
<td class=bl>3:4&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>3rd</strong></font></th></tr>
<tr><td class=ar><b>Matýsek Daniel</b>&nbsp;&nbsp;</td>
<td class=al>- Cibulka David&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:1 P&nbsp;&nbsp;</td>
<td class=al>3:2 P&nbsp;&nbsp;</td>
<td class=al>4:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>Quarterfinals</strong></font></th></tr>
<tr><td class=br><b>Šmíd David (1)</b>&nbsp;&nbsp;</td>
<td class=bl>- Lopaur Zdeněk (8)&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>6:0&nbsp;&nbsp;</td>
<td class=bl>5:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar>Pikl Václav (4)&nbsp;&nbsp;</td>
<td class=al><b>- Matýsek Daniel (5)</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;2 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>1:3&nbsp;&nbsp;</td>
<td class=al>3:0&nbsp;&nbsp;</td>
<td class=al>3:0&nbsp;&nbsp;</td>
<td class=al>1:2 P&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br>Turoň Petr (3)&nbsp;&nbsp;</td>
<td class=bl><b>- Cibulka David (6)</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;1 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:2 P&nbsp;&nbsp;</td>
<td class=bl>3:4 P&nbsp;&nbsp;</td>
<td class=bl>3:4&nbsp;&nbsp;</td>
<td class=bl>0:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Plešák Pavel (2)</b>&nbsp;&nbsp;</td>
<td class=al>- Kraus Vladimír (7)&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:0&nbsp;&nbsp;</td>
<td class=al>3:2 P&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>3:4&nbsp;&nbsp;</td>
<td class=al>4:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr></table></td></tr></table></div></p>
<p>&nbsp;</p>
<div align=center><p>Created by <b>Trefik</b>, table hockey edition. Copyright 2003-2017 Vladimír Kraus<br><a href="http://www.trefik.cz">www.trefik.cz</a></p></div>
</body></html>
