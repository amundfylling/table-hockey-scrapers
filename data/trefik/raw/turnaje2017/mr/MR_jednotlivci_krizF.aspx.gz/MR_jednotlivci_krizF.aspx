<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN">
<html lang="cz">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<title>MR jednotlivci</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
</head>
<body class="neop">
<a name="Zac"><p class=l>MR jednotlivci, 4. červen 2017</p></a>
<div align=center><p><a href="MRjedn.aspx">Pořadí</a><br>
<a href="MR_jednotlivci_krizB.aspx#basic">Základní skupiny (Basic groups)</a><br>
<a href="MR_jednotlivci_krizF.aspx#final">Výkonnostní skupiny (Final groups)</a><br>
<a href="MR_jednotlivci_umisteni.aspx">Play-off</a><br>
<a href="index.aspx">Zpět / Back</a></p></div>
<hr><a name="final"><p class=vm>Výkonnostní skupiny (Final groups)</p></a>
<p class=v>Group A</br><div align=center>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=2 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/8</td><td class=ir>1</td><td class=kt>Lu Turoň</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>5:2 K</td>
<td class=kT>2:2</td>
<td class=kT>1:1 K</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>3:1 K</td>
<td class=kW>3:0 K</td>
<td class=kW>6:1 K</td>
<td class=kW>7:0</td>
<td class=kT>3:3 K</td>
<td class=kT>2:2 K</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=br>53:23</td><td class=br>+30</td>
<td class=bc>9 - 6 - 0</td>
<td class=br>24</td><td class=d>1.</td>
</tr><tr><td class=ir>1/8</td><td class=ir>2</td><td class=kt>Le Hvižď ml.</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=kW>4:2</td>
<td class=kW>4:0 K</td>
<td class=kL>1:2</td>
<td class=kT>3:3 K</td>
<td class=kW>2:0 K</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>4:2 K</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kW>2:0 K</td>
<td class=kW>5:1 K</td>
<td class=br>43:22</td><td class=br>+21</td>
<td class=bc>9 - 3 - 3</td>
<td class=br>21</td><td class=d>2.</td>
</tr><tr><td class=ir>1/8</td><td class=ir>3</td><td class=kt>Ja Dryák</td><td class=kT>1:1</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:0 K</td>
<td class=kW>3:1</td>
<td class=kW>6:3 K</td>
<td class=kL>1:2 K</td>
<td class=kW>5:1</td>
<td class=kL>1:4</td>
<td class=kW>7:4</td>
<td class=kW>3:1 K</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1 K</td>
<td class=kW>6:0 K</td>
<td class=br>48:26</td><td class=br>+22</td>
<td class=bc>9 - 3 - 3</td>
<td class=br>21</td><td class=d>3.</td>
</tr><tr><td class=ir>1/8</td><td class=ir>4</td><td class=kt>Kr Lebl</td><td class=kL>2:5 K</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>2:1 K</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kT>2:2 K</td>
<td class=kW>3:0 K</td>
<td class=kW>5:0 K</td>
<td class=kW>2:1</td>
<td class=kT>0:0 K</td>
<td class=kT>2:2 K</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=br>39:21</td><td class=br>+18</td>
<td class=bc>9 - 3 - 3</td>
<td class=br>21</td><td class=d>4.</td>
</tr><tr><td class=ir>1/8</td><td class=ir>5</td><td class=kt>ml Chylík</td><td class=kT>2:2</td>
<td class=kL>0:4 K</td>
<td class=kL>0:3 K</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:2 K</td>
<td class=kT>2:2 K</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kL>0:4 K</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kW>5:3 K</td>
<td class=kW>3:2 K</td>
<td class=br>35:27</td><td class=br>+8</td>
<td class=bc>9 - 3 - 3</td>
<td class=br>21</td><td class=d>5.</td>
</tr><tr><td class=ir>1/8</td><td class=ir>6</td><td class=kt>Mi Hvižď</td><td class=kT>1:1 K</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>1:2 K</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kT>1:1 K</td>
<td class=kW>3:0 K</td>
<td class=kL>1:3 K</td>
<td class=kW>5:4</td>
<td class=kL>2:3 K</td>
<td class=kW>1:0 K</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=br>31:24</td><td class=br>+7</td>
<td class=bc>7 - 3 - 5</td>
<td class=br>17</td><td class=d>6.</td>
</tr><tr><td class=ir>1/8</td><td class=ir>7</td><td class=kt>Pa Petr</td><td class=kL>2:4</td>
<td class=kT>3:3 K</td>
<td class=kL>3:6 K</td>
<td class=kL>1:2</td>
<td class=kL>2:4 K</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3 K</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kT>3:3 K</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kT>2:2 K</td>
<td class=kW>5:0 K</td>
<td class=br>38:35</td><td class=br>+3</td>
<td class=bc>5 - 5 - 5</td>
<td class=br>15</td><td class=d>7.</td>
</tr><tr><td class=ir>1/8</td><td class=ir>8</td><td class=kt>Ma Maděra</td><td class=kL>3:4</td>
<td class=kL>0:2 K</td>
<td class=kW>2:1 K</td>
<td class=kL>0:1</td>
<td class=kT>2:2 K</td>
<td class=kL>0:3</td>
<td class=kT>3:3 K</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>5:2 K</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3 K</td>
<td class=kW>1:0 K</td>
<td class=br>34:33</td><td class=br>+1</td>
<td class=bc>5 - 5 - 5</td>
<td class=br>15</td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>9</td><td class=kt>Mi Kobrle</td><td class=kL>1:3 K</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kT>2:2 K</td>
<td class=kL>0:4</td>
<td class=kT>1:1 K</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:0 K</td>
<td class=kL>1:3 K</td>
<td class=kL>1:4</td>
<td class=kT>4:4 K</td>
<td class=kW>2:1 K</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=br>31:37</td><td class=br>-6</td>
<td class=bc>5 - 4 - 6</td>
<td class=br>14</td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>10</td><td class=kt>An Šurýn</td><td class=kL>0:3 K</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kL>0:3 K</td>
<td class=kL>0:1</td>
<td class=kL>0:3 K</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kL>0:2 K</td>
<td class=kx>*</td>
<td class=kW>3:2 K</td>
<td class=kW>4:3</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2 K</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=br>27:33</td><td class=br>-6</td>
<td class=bc>5 - 3 - 7</td>
<td class=br>13</td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>11</td><td class=kt>Ma Ženíšek</td><td class=kL>1:6 K</td>
<td class=kL>0:5</td>
<td class=kL>4:7</td>
<td class=kL>0:5 K</td>
<td class=kL>1:4</td>
<td class=kW>3:1 K</td>
<td class=kL>0:1</td>
<td class=kL>3:5</td>
<td class=kW>3:1 K</td>
<td class=kL>2:3 K</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3 K</td>
<td class=kW>5:3 K</td>
<td class=kL>1:5</td>
<td class=kW>6:1</td>
<td class=br>34:51</td><td class=br>-17</td>
<td class=bc>5 - 1 - 9</td>
<td class=br>11</td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>12</td><td class=kt>St Kraus</td><td class=kL>0:7</td>
<td class=kL>2:4 K</td>
<td class=kL>1:3 K</td>
<td class=kL>1:2</td>
<td class=kW>4:0 K</td>
<td class=kL>4:5</td>
<td class=kT>3:3 K</td>
<td class=kL>2:5 K</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>4:3 K</td>
<td class=kL>1:5 K</td>
<td class=br>39:47</td><td class=br>-8</td>
<td class=bc>5 - 1 - 9</td>
<td class=br>11</td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>13</td><td class=kt>Pa Plešák</td><td class=kT>3:3 K</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kT>0:0 K</td>
<td class=kL>0:3</td>
<td class=kW>3:2 K</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4 K</td>
<td class=kT>2:2 K</td>
<td class=kT>3:3 K</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kT>3:3 K</td>
<td class=kL>2:3</td>
<td class=kW>8:2</td>
<td class=br>33:40</td><td class=br>-7</td>
<td class=bc>2 - 7 - 6</td>
<td class=br>11</td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>14</td><td class=kt>Ad Zielinský</td><td class=kT>2:2 K</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kL>0:1 K</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>1:2 K</td>
<td class=kT>2:2 K</td>
<td class=kL>3:5 K</td>
<td class=kL>3:5</td>
<td class=kT>3:3 K</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>6:3</td>
<td class=br>34:39</td><td class=br>-5</td>
<td class=bc>2 - 7 - 6</td>
<td class=br>11</td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>15</td><td class=kt>Da Dvořáček</td><td class=kL>1:5</td>
<td class=kL>0:2 K</td>
<td class=kL>1:4 K</td>
<td class=kL>0:5</td>
<td class=kL>3:5 K</td>
<td class=kL>0:4</td>
<td class=kT>2:2 K</td>
<td class=kW>3:2 K</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kW>5:1</td>
<td class=kL>3:4 K</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>2:3 K</td>
<td class=br>27:49</td><td class=br>-22</td>
<td class=bc>4 - 1 - 10</td>
<td class=br>9</td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>16</td><td class=kt>Ja Matýsek</td><td class=kL>2:5</td>
<td class=kL>1:5 K</td>
<td class=kL>0:6 K</td>
<td class=kL>0:7</td>
<td class=kL>2:3 K</td>
<td class=kL>1:2</td>
<td class=kL>0:5 K</td>
<td class=kL>0:1 K</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kW>5:1 K</td>
<td class=kL>2:8</td>
<td class=kL>3:6</td>
<td class=kW>3:2 K</td>
<td class=kx>*</td>
<td class=br>26:65</td><td class=br>-39</td>
<td class=bc>2 - 1 - 12</td>
<td class=br>5</td><td class=d>16.</td>
</tr></table></td></tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ja Dryák</td><td class=bc>-</td><td class=bl>Lu Turoň</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ja Dryák</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ja Dryák</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=bl>Lu Turoň</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Lu Turoň</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>4 : 7</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<div align=center><p>Created by <b>Trefik</b>, table hockey edition. Copyright 2003-2017 Vladimír Kraus<br><a href="http://www.trefik.cz">www.trefik.cz</a></p></div>
</body></html>
