<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN">
<html lang="cz">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<title>MR jednotlivci</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
</head>
<body class="neop">
<a name="Zac"><p class=l>MR jednotlivci, 4. červen 2017</p></a>
<div align=center><p><a href="MRjedn.aspx">Pořadí</a><br>
<a href="MR_jednotlivci_krizB.aspx#basic">Základní skupiny (Basic groups)</a><br>
<a href="MR_jednotlivci_krizF.aspx#final">Výkonnostní skupiny (Final groups)</a><br>
<a href="MR_jednotlivci_umisteni.aspx">Play-off</a><br>
<a href="index.aspx">Zpět / Back</a></p></div>
<a name="basic"><p class=vm>Základní skupiny (Basic groups)</p></a>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=2 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=ir>1</td><td class=kt>Ja Dryák</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kW>6:3</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kW>5:0</td>
<td class=kW>9:2</td>
<td class=kW>4:0</td>
<td class=kW>8:1</td>
<td class=kW>7:1</td>
<td class=kW>8:0</td>
<td class=kW>6:2</td>
<td class=kW>5:0 K</td>
<td class=br>108:28</td><td class=br>+80</td>
<td class=bc>20 - 2 - 1</td>
<td class=br>42</td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=ir>2</td><td class=kt>Le Hvižď ml.</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kL>1:4</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>7:1</td>
<td class=kW>5:0 K</td>
<td class=br>97:25</td><td class=br>+72</td>
<td class=bc>19 - 3 - 1</td>
<td class=br>41</td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=ir>3</td><td class=kt>ml Chylík</td><td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kW>5:3</td>
<td class=kL>0:4</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0 K</td>
<td class=br>81:41</td><td class=br>+40</td>
<td class=bc>17 - 2 - 4</td>
<td class=br>36</td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=ir>4</td><td class=kt>Ma Maděra</td><td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>8:4</td>
<td class=kW>7:1</td>
<td class=kW>6:2</td>
<td class=kW>7:2</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0 K</td>
<td class=br>96:46</td><td class=br>+50</td>
<td class=bc>16 - 4 - 3</td>
<td class=br>36</td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=ir>5</td><td class=kt>Pa Petr</td><td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>11:0</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>11:4</td>
<td class=kW>3:2</td>
<td class=kW>11:2</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>5:0 K</td>
<td class=br>112:46</td><td class=br>+66</td>
<td class=bc>15 - 6 - 2</td>
<td class=br>36</td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=ir>6</td><td class=kt>Ja Matýsek</td><td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>1:0</td>
<td class=kW>9:3</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>10:3</td>
<td class=kW>6:4</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>5:0 K</td>
<td class=br>83:55</td><td class=br>+28</td>
<td class=bc>17 - 1 - 5</td>
<td class=br>35</td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=ir>7</td><td class=kt>St Kraus</td><td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>8:1</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>5:0 K</td>
<td class=br>98:42</td><td class=br>+56</td>
<td class=bc>17 - 1 - 5</td>
<td class=br>35</td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=ir>8</td><td class=kt>Da Dvořáček</td><td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>10:1</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=kW>8:1</td>
<td class=kW>5:0 K</td>
<td class=br>90:41</td><td class=br>+49</td>
<td class=bc>14 - 2 - 7</td>
<td class=br>30</td><td class=d>8.</td>
</tr><tr><td class=ir>J</td><td class=ir>9</td><td class=kt>Ho Sládek</td><td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kW>8:2</td>
<td class=kW>1:0</td>
<td class=kW>11:2</td>
<td class=kW>8:2</td>
<td class=kW>10:0</td>
<td class=kW>9:1</td>
<td class=kW>5:0 K</td>
<td class=br>91:48</td><td class=br>+43</td>
<td class=bc>14 - 2 - 7</td>
<td class=br>30</td><td class=d>9.</td>
</tr><tr><td class=ir>J</td><td class=ir>10</td><td class=kt>To Waclawek</td><td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>8:0</td>
<td class=kW>10:1</td>
<td class=kW>5:0 K</td>
<td class=br>93:59</td><td class=br>+34</td>
<td class=bc>13 - 1 - 9</td>
<td class=br>27</td><td class=d>10.</td>
</tr><tr><td class=ir>J</td><td class=ir>11</td><td class=kt>Vá Pikl</td><td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>10:0</td>
<td class=kW>9:0</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=kW>5:0 K</td>
<td class=br>78:44</td><td class=br>+34</td>
<td class=bc>12 - 2 - 9</td>
<td class=br>26</td><td class=d>11.</td>
</tr><tr><td class=ir>J</td><td class=ir>12</td><td class=kt>Vl Kraus</td><td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>3:9</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kT>6:6</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>8:0</td>
<td class=kW>9:0</td>
<td class=kW>5:0 K</td>
<td class=br>83:67</td><td class=br>+16</td>
<td class=bc>12 - 2 - 9</td>
<td class=br>26</td><td class=d>12.</td>
</tr><tr><td class=ir>J</td><td class=ir>13</td><td class=kt>Ro Jež</td><td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>6:4</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kW>8:1</td>
<td class=kW>7:0</td>
<td class=kW>5:0 K</td>
<td class=br>75:61</td><td class=br>+14</td>
<td class=bc>12 - 1 - 10</td>
<td class=br>25</td><td class=d>13.</td>
</tr><tr><td class=ir>J</td><td class=ir>14</td><td class=kt>To Jedlička</td><td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kL>0:11</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>9:1</td>
<td class=kW>9:0</td>
<td class=kW>10:1</td>
<td class=kW>7:1</td>
<td class=kW>5:0 K</td>
<td class=br>81:62</td><td class=br>+19</td>
<td class=bc>10 - 3 - 10</td>
<td class=br>23</td><td class=d>14.</td>
</tr><tr><td class=ir>J</td><td class=ir>15</td><td class=kt>Zd Lopaur</td><td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kL>4:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>7:4</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kW>5:0 K</td>
<td class=br>64:66</td><td class=br>-2</td>
<td class=bc>11 - 1 - 11</td>
<td class=br>23</td><td class=d>15.</td>
</tr><tr><td class=ir>J</td><td class=ir>16</td><td class=kt>To Halama</td><td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>5:0 K</td>
<td class=br>48:66</td><td class=br>-18</td>
<td class=bc>8 - 4 - 11</td>
<td class=br>20</td><td class=d>16.</td>
</tr><tr><td class=ir>J</td><td class=ir>17</td><td class=kt>Mi Slepička</td><td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>0:6</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>6:4</td>
<td class=kW>3:0</td>
<td class=kW>7:0</td>
<td class=kW>5:0 K</td>
<td class=br>54:85</td><td class=br>-31</td>
<td class=bc>6 - 1 - 16</td>
<td class=br>13</td><td class=d>17.</td>
</tr><tr><td class=ir>J</td><td class=ir>18</td><td class=kt>Mi Uhlíř</td><td class=kL>2:9</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>4:8</td>
<td class=kL>4:11</td>
<td class=kL>3:4</td>
<td class=kL>1:8</td>
<td class=kL>1:3</td>
<td class=kL>2:8</td>
<td class=kW>4:3</td>
<td class=kL>1:5</td>
<td class=kT>6:6</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>4:8</td>
<td class=kW>6:4</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0 K</td>
<td class=br>69:109</td><td class=br>-40</td>
<td class=bc>6 - 1 - 16</td>
<td class=br>13</td><td class=d>18.</td>
</tr><tr><td class=ir>J</td><td class=ir>19</td><td class=kt>Fr Marek</td><td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>2:7</td>
<td class=kL>0:4</td>
<td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kW>8:4</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>9:1</td>
<td class=kW>5:0 K</td>
<td class=br>58:76</td><td class=br>-18</td>
<td class=bc>5 - 2 - 16</td>
<td class=br>12</td><td class=d>19.</td>
</tr><tr><td class=ir>J</td><td class=ir>20</td><td class=kt>Ra Bidlo</td><td class=kL>1:8</td>
<td class=kL>1:7</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kL>2:11</td>
<td class=kL>3:10</td>
<td class=kL>0:6</td>
<td class=kL>1:10</td>
<td class=kL>2:11</td>
<td class=kL>1:5</td>
<td class=kL>0:10</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>1:9</td>
<td class=kL>4:7</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kL>4:6</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0 K</td>
<td class=br>47:133</td><td class=br>-86</td>
<td class=bc>5 - 1 - 17</td>
<td class=br>11</td><td class=d>20.</td>
</tr><tr><td class=ir>J</td><td class=ir>21</td><td class=kt>To Růžička</td><td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kL>4:6</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>2:8</td>
<td class=kL>1:6</td>
<td class=kL>0:9</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kL>0:9</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>4:6</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>5:0 K</td>
<td class=br>38:113</td><td class=br>-75</td>
<td class=bc>3 - 0 - 20</td>
<td class=br>6</td><td class=d>21.</td>
</tr><tr><td class=ir>J</td><td class=ir>22</td><td class=kt>Pa Hráský</td><td class=kL>0:8</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>0:7</td>
<td class=kL>0:10</td>
<td class=kL>0:8</td>
<td class=kL>0:4</td>
<td class=kL>0:8</td>
<td class=kL>1:8</td>
<td class=kL>1:10</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:0 K</td>
<td class=br>19:126</td><td class=br>-107</td>
<td class=bc>1 - 1 - 21</td>
<td class=br>3</td><td class=d>22.</td>
</tr><tr><td class=ir>J</td><td class=ir>23</td><td class=kt>An Grimová</td><td class=kL>2:6</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>1:8</td>
<td class=kL>1:9</td>
<td class=kL>1:10</td>
<td class=kL>0:8</td>
<td class=kL>0:9</td>
<td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>1:9</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>5:0 K</td>
<td class=br>19:128</td><td class=br>-109</td>
<td class=bc>1 - 1 - 21</td>
<td class=br>3</td><td class=d>23.</td>
</tr><tr><td class=ir>J</td><td class=ir>24</td><td class=kt>Ku Sládek</td><td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kx>*</td>
<td class=br>0:115</td><td class=br>-115</td>
<td class=bc>0 - 0 - 23</td>
<td class=br>0</td><td class=d>24.</td>
</tr></table></td></tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>11 : 4</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Mi Slepička</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Mi Slepička</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>11 : 2</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Mi Slepička</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Ra Bidlo</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Mi Slepička</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Ra Bidlo</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Mi Slepička</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>4 : 8</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>11 : 0</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Mi Slepička</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 5 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Mi Slepička</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ra Bidlo</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>5 : 0 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mi Slepička</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>3 : 10</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Slepička</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Ja Dryák</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Slepička</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Slepička</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>9 : 3</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Slepička</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ra Bidlo</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Slepička</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Slepička</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Slepička</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Slepička</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ra Bidlo</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Slepička</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Slepička</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>6 : 6</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>Mi Slepička</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Mi Slepička</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Mi Slepička</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Pa Hráský</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Mi Slepička</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>11 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Mi Slepička</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Mi Slepička</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=2 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=ir>1</td><td class=kt>Lu Turoň</td><td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kW>6:3</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=br>95:23</td><td class=br>+72</td>
<td class=bc>20 - 3 - 0</td>
<td class=br>43</td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=ir>2</td><td class=kt>Mi Hvižď</td><td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>7:4</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>7:0</td>
<td class=kW>9:2</td>
<td class=kW>5:3</td>
<td class=kW>7:1</td>
<td class=br>94:34</td><td class=br>+60</td>
<td class=bc>17 - 3 - 3</td>
<td class=br>37</td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=ir>3</td><td class=kt>Mi Kobrle</td><td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kW>9:2</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>7:2</td>
<td class=kW>8:0</td>
<td class=kW>8:1</td>
<td class=kW>4:0</td>
<td class=br>95:44</td><td class=br>+51</td>
<td class=bc>15 - 5 - 3</td>
<td class=br>35</td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=ir>4</td><td class=kt>Pa Plešák</td><td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>2:8</td>
<td class=kW>8:6</td>
<td class=kT>1:1</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>7:2</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>7:2</td>
<td class=kW>3:0</td>
<td class=kW>7:0</td>
<td class=br>93:53</td><td class=br>+40</td>
<td class=bc>14 - 7 - 2</td>
<td class=br>35</td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=ir>5</td><td class=kt>Kr Lebl</td><td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>5:3</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>67:28</td><td class=br>+39</td>
<td class=bc>16 - 3 - 4</td>
<td class=br>35</td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=ir>6</td><td class=kt>Ma Ženíšek</td><td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kW>8:2</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>6:2</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=br>89:50</td><td class=br>+39</td>
<td class=bc>14 - 4 - 5</td>
<td class=br>32</td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=ir>7</td><td class=kt>Ad Zielinský</td><td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>5:4</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=br>74:44</td><td class=br>+30</td>
<td class=bc>13 - 6 - 4</td>
<td class=br>32</td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=ir>8</td><td class=kt>An Šurýn</td><td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>7:4</td>
<td class=kW>8:1</td>
<td class=kW>4:3</td>
<td class=br>65:45</td><td class=br>+20</td>
<td class=bc>13 - 4 - 6</td>
<td class=br>30</td><td class=d>8.</td>
</tr><tr><td class=ir>J</td><td class=ir>9</td><td class=kt>Da Matýsek</td><td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kW>8:2</td>
<td class=kL>0:1</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=kL>3:7</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>76:47</td><td class=br>+29</td>
<td class=bc>14 - 1 - 8</td>
<td class=br>29</td><td class=d>9.</td>
</tr><tr><td class=ir>J</td><td class=ir>10</td><td class=kt>Mi Boštík</td><td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>6:8</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>65:56</td><td class=br>+9</td>
<td class=bc>13 - 2 - 8</td>
<td class=br>28</td><td class=d>10.</td>
</tr><tr><td class=ir>J</td><td class=ir>11</td><td class=kt>Mi Černoch</td><td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=kW>3:2</td>
<td class=br>58:45</td><td class=br>+13</td>
<td class=bc>11 - 6 - 6</td>
<td class=br>28</td><td class=d>11.</td>
</tr><tr><td class=ir>J</td><td class=ir>12</td><td class=kt>To Bucek</td><td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kL>3:6</td>
<td class=kW>5:3</td>
<td class=kL>0:4</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kL>1:5</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kW>8:0</td>
<td class=kW>6:3</td>
<td class=kW>4:0</td>
<td class=br>80:54</td><td class=br>+26</td>
<td class=bc>12 - 4 - 7</td>
<td class=br>28</td><td class=d>12.</td>
</tr><tr><td class=ir>J</td><td class=ir>13</td><td class=kt>Lu Paclík</td><td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=br>63:55</td><td class=br>+8</td>
<td class=bc>11 - 3 - 9</td>
<td class=br>25</td><td class=d>13.</td>
</tr><tr><td class=ir>J</td><td class=ir>14</td><td class=kt>To Kahoun ml.</td><td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=br>55:61</td><td class=br>-6</td>
<td class=bc>11 - 2 - 10</td>
<td class=br>24</td><td class=d>14.</td>
</tr><tr><td class=ir>J</td><td class=ir>15</td><td class=kt>Sa Hána</td><td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>2:8</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kL>0:8</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=br>63:73</td><td class=br>-10</td>
<td class=bc>10 - 3 - 10</td>
<td class=br>23</td><td class=d>15.</td>
</tr><tr><td class=ir>J</td><td class=ir>16</td><td class=kt>Lu Kahoun</td><td class=kL>1:7</td>
<td class=kL>4:7</td>
<td class=kL>2:9</td>
<td class=kL>1:4</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>7:3</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=br>61:71</td><td class=br>-10</td>
<td class=bc>10 - 1 - 12</td>
<td class=br>21</td><td class=d>16.</td>
</tr><tr><td class=ir>J</td><td class=ir>17</td><td class=kt>Hy Nechutný</td><td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=br>41:49</td><td class=br>-8</td>
<td class=bc>8 - 4 - 11</td>
<td class=br>20</td><td class=d>17.</td>
</tr><tr><td class=ir>J</td><td class=ir>18</td><td class=kt>To Kahoun st.</td><td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>2:7</td>
<td class=kL>2:7</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>4:5</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=br>39:80</td><td class=br>-41</td>
<td class=bc>5 - 2 - 16</td>
<td class=br>12</td><td class=d>18.</td>
</tr><tr><td class=ir>J</td><td class=ir>19</td><td class=kt>Jo Malý</td><td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kL>2:7</td>
<td class=kW>4:3</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=br>43:79</td><td class=br>-36</td>
<td class=bc>4 - 3 - 16</td>
<td class=br>11</td><td class=d>19.</td>
</tr><tr><td class=ir>J</td><td class=ir>20</td><td class=kt>Da Hejnoch</td><td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=br>36:66</td><td class=br>-30</td>
<td class=bc>4 - 2 - 17</td>
<td class=br>10</td><td class=d>20.</td>
</tr><tr><td class=ir>J</td><td class=ir>21</td><td class=kt>Ví Perkner</td><td class=kL>3:5</td>
<td class=kL>0:7</td>
<td class=kL>2:7</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=br>34:90</td><td class=br>-56</td>
<td class=bc>2 - 2 - 19</td>
<td class=br>6</td><td class=d>21.</td>
</tr><tr><td class=ir>J</td><td class=ir>22</td><td class=kt>Vo Bernát</td><td class=kL>1:3</td>
<td class=kL>2:9</td>
<td class=kL>0:8</td>
<td class=kL>2:7</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>4:7</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>0:8</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>2:0</td>
<td class=br>40:100</td><td class=br>-60</td>
<td class=bc>2 - 2 - 19</td>
<td class=br>6</td><td class=d>22.</td>
</tr><tr><td class=ir>J</td><td class=ir>23</td><td class=kt>Jo Perkner</td><td class=kL>0:6</td>
<td class=kL>3:5</td>
<td class=kL>1:8</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kL>1:8</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>0:7</td>
<td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=br>22:114</td><td class=br>-92</td>
<td class=bc>1 - 0 - 22</td>
<td class=br>2</td><td class=d>23.</td>
</tr><tr><td class=ir>J</td><td class=ir>24</td><td class=kt>Ji Zapletal</td><td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=br>12:99</td><td class=br>-87</td>
<td class=bc>0 - 0 - 23</td>
<td class=br>0</td><td class=d>24.</td>
</tr></table></td></tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ji Zapletal</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Lu Paclík</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Sa Hána</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ví Perkner</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Ji Zapletal</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Sa Hána</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Lu Paclík</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>Ji Zapletal</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Lu Paclík</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ji Zapletal</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Da Hejnoch</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Lu Paclík</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ji Zapletal</td><td class=bc>-</td><td class=blW>Da Hejnoch</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Lu Paclík</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Da Hejnoch</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ji Zapletal</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Lu Paclík</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>8 : 6</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ji Zapletal</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Sa Hána</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Lu Paclík</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ji Zapletal</td><td class=bc>-</td><td class=blW>Sa Hána</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Lu Paclík</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 8</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Sa Hána</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Ji Zapletal</td><td class=bc>-</td><td class=blW>Lu Paclík</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Lu Turoň</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Sa Hána</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Lu Paclík</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ji Zapletal</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Lu Paclík</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ji Zapletal</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Lu Paclík</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ji Zapletal</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Lu Turoň</td><td class=bc>-</td><td class=bl>Mi Hvižď</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=bl>Lu Paclík</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ji Zapletal</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ji Zapletal</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Lu Paclík</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ji Zapletal</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Lu Paclík</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Ji Zapletal</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Lu Paclík</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Ji Zapletal</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Da Hejnoch</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Lu Paclík</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Ji Zapletal</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Lu Paclík</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ji Zapletal</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Lu Paclík</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ji Zapletal</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ji Zapletal</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Lu Paclík</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Hvižď</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Lu Turoň</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Ji Zapletal</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Lu Paclík</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ji Zapletal</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lu Paclík</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ji Zapletal</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Lu Paclík</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p>&nbsp;</p>
<div align=center><p>Created by <b>Trefik</b>, table hockey edition. Copyright 2003-2017 Vladimír Kraus<br><a href="http://www.trefik.cz">www.trefik.cz</a></p></div>
</body></html>
