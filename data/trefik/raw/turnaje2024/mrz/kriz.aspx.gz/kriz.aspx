<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR ženy</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../mrz/index.aspx">MR ženy, 19. květen 2024</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<p class=v>Group L</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=496&x=-417&p=An%20Poho%C5%99al%C3%A1">An Pohořalá</a></td><td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=br>22:7</td><td class=br>+15</td>
<td class=bc>5 - 0 - 0</td>
<td class=br><strong>10</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2039&x=-417&p=Ma%20Dry%C3%A1kov%C3%A1">Ma Dryáková</a></td><td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=br>18:9</td><td class=br>+9</td>
<td class=bc>4 - 0 - 1</td>
<td class=br><strong>8</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1626&x=-417&p=Mi%20Hor%C3%A1kov%C3%A1">Mi Horáková</a></td><td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=br>16:11</td><td class=br>+5</td>
<td class=bc>2 - 1 - 2</td>
<td class=br><strong>5</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2130&x=-417&p=V%C4%9B%20Stanzelov%C3%A1">Vě Stanzelová</a></td><td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>0:0</td>
<td class=br>6:8</td><td class=br>-2</td>
<td class=bc>1 - 2 - 2</td>
<td class=br><strong>4</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2128&x=-417&p=Zu%20Vargov%C3%A1">Zu Vargová</a></td><td class=kL>3:5</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=br>6:20</td><td class=br>-14</td>
<td class=bc>1 - 0 - 4</td>
<td class=br><strong>2</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2127&x=-417&p=Ra%20Hr%C4%8Dkov%C3%A1">Ra Hrčková</a></td><td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kT>0:0</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=br>1:14</td><td class=br>-13</td>
<td class=bc>0 - 1 - 4</td>
<td class=br><strong>1</strong></td><td class=d>6.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>An Pohořalá</td><td class=bc>-</td><td class=bl>Zu Vargová</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=bl>Vě Stanzelová</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ra Hrčková</td><td class=bc>-</td><td class=blW>Ma Dryáková</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>An Pohořalá</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Vě Stanzelová</td><td class=bc>-</td><td class=bl>Ra Hrčková</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Zu Vargová</td><td class=bc>-</td><td class=blW>Ma Dryáková</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Zu Vargová</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ra Hrčková</td><td class=bc>-</td><td class=blW>An Pohořalá</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Dryáková</td><td class=bc>-</td><td class=bl>Vě Stanzelová</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Ra Hrčková</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>An Pohořalá</td><td class=bc>-</td><td class=bl>Ma Dryáková</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Zu Vargová</td><td class=bc>-</td><td class=blW>Vě Stanzelová</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ra Hrčková</td><td class=bc>-</td><td class=blW>Zu Vargová</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ma Dryáková</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Vě Stanzelová</td><td class=bc>-</td><td class=blW>An Pohořalá</td><td class=bc>1 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
