<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Olomouc</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../olomouc">Olomouc, 16. prosinec 2023</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Základní skupiny (Basic groups)</a><br>
<a href="#final">Výkonnostní skupiny (Final groups)</a><br>
<a name="basic"><p class=vm>Základní skupiny (Basic groups)</p></a>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=409&x=-404&p=Pa%20Petr">Pa Petr</a></td><td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kW>7:4</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=kW>9:1</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kW>10:1</td>
<td class=kW>14:0</td>
<td class=kW>10:0</td>
<td class=kW>10:0</td>
<td class=kW>10:0</td>
<td class=br>124:25</td><td class=br>+99</td>
<td class=bc>16 - 2 - 0</td>
<td class=br><strong>34</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=310&x=-404&p=Mi%20%C4%8Cernoch">Mi Černoch</a></td><td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>6:4</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>8:1</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=kW>8:0</td>
<td class=kW>7:1</td>
<td class=br>75:22</td><td class=br>+53</td>
<td class=bc>14 - 2 - 2</td>
<td class=br><strong>30</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=40&x=-404&p=Da%20Mat%C3%BDsek">Da Matýsek</a></td><td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>7:3</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>9:2</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>8:1</td>
<td class=br>68:28</td><td class=br>+40</td>
<td class=bc>13 - 2 - 3</td>
<td class=br><strong>28</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=961&x=-404&p=Mi%20Bo%C5%A1t%C3%ADk">Mi Boštík</a></td><td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>7:1</td>
<td class=kW>7:2</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>5:4</td>
<td class=kW>6:0</td>
<td class=kW>5:4</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=br>71:32</td><td class=br>+39</td>
<td class=bc>12 - 3 - 3</td>
<td class=br><strong>27</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=53&x=-404&p=V%C3%A1%20Pikl">Vá Pikl</a></td><td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>8:0</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>11:0</td>
<td class=kW>8:1</td>
<td class=br>72:23</td><td class=br>+49</td>
<td class=bc>12 - 2 - 4</td>
<td class=br><strong>26</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=818&x=-404&p=Ro%20Je%C5%BE">Ro Jež</a></td><td class=kL>4:7</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>7:0</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>9:1</td>
<td class=kW>9:0</td>
<td class=br>69:39</td><td class=br>+30</td>
<td class=bc>11 - 3 - 4</td>
<td class=br><strong>25</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1876&x=-404&p=Ad%20Kop%C5%99iva">Ad Kopřiva</a></td><td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=br>50:31</td><td class=br>+19</td>
<td class=bc>10 - 3 - 5</td>
<td class=br><strong>23</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1912&x=-404&p=Al%20Krejza">Al Krejza</a></td><td class=kL>2:5</td>
<td class=kL>4:6</td>
<td class=kW>5:1</td>
<td class=kL>1:7</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>8:1</td>
<td class=kW>7:1</td>
<td class=kW>8:0</td>
<td class=kW>6:0</td>
<td class=kW>7:0</td>
<td class=br>73:44</td><td class=br>+29</td>
<td class=bc>10 - 2 - 6</td>
<td class=br><strong>22</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=204&x=-404&p=Hy%20Nechutn%C3%BD">Hy Nechutný</a></td><td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>0:1</td>
<td class=kL>2:7</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=br>45:36</td><td class=br>+9</td>
<td class=bc>9 - 3 - 6</td>
<td class=br><strong>21</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=261&x=-404&p=Da%20Cibulka">Da Cibulka</a></td><td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>9:0</td>
<td class=kW>10:1</td>
<td class=br>57:35</td><td class=br>+22</td>
<td class=bc>8 - 4 - 6</td>
<td class=br><strong>20</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1871&x=-404&p=Mi%20L%C3%A9vy">Mi Lévy</a></td><td class=kL>1:9</td>
<td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>5:4</td>
<td class=kW>6:5</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>8:0</td>
<td class=br>54:63</td><td class=br>-9</td>
<td class=bc>8 - 2 - 8</td>
<td class=br><strong>18</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1058&x=-404&p=Fr%20Marek">Fr Marek</a></td><td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>8:1</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>9:1</td>
<td class=br>48:43</td><td class=br>+5</td>
<td class=bc>7 - 3 - 8</td>
<td class=br><strong>17</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1318&x=-404&p=Jo%20Sedl%C3%A1%C4%8Dek">Jo Sedláček</a></td><td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kL>3:7</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kW>6:3</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=br>54:61</td><td class=br>-7</td>
<td class=bc>6 - 3 - 9</td>
<td class=br><strong>15</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>B</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2014&x=-404&p=Ma%20Hlava%C4%8Dka">Ma Hlavačka</a></td><td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kW>2:1</td>
<td class=kL>4:5</td>
<td class=kL>1:6</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kL>4:5</td>
<td class=kL>1:8</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>9:0</td>
<td class=kW>4:0</td>
<td class=br>47:61</td><td class=br>-14</td>
<td class=bc>5 - 3 - 10</td>
<td class=br><strong>13</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=271&x=-404&p=Ra%20Hejtman">Ra Hejtman</a></td><td class=kL>1:10</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>0:8</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>1:8</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>5:6</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=br>32:76</td><td class=br>-44</td>
<td class=bc>3 - 3 - 12</td>
<td class=br><strong>9</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>C</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1269&x=-404&p=Ja%20Dvo%C5%99%C3%A1%C4%8Dek">Ja Dvořáček</a></td><td class=kL>0:14</td>
<td class=kL>0:4</td>
<td class=kL>2:9</td>
<td class=kL>4:5</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kL>3:6</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>8:1</td>
<td class=kW>3:1</td>
<td class=br>39:93</td><td class=br>-54</td>
<td class=bc>3 - 1 - 14</td>
<td class=br><strong>7</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>C</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1635&x=-404&p=Ji%20Zapletal">Ji Zapletal</a></td><td class=kL>0:10</td>
<td class=kL>0:8</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>0:8</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=br>13:82</td><td class=br>-69</td>
<td class=bc>2 - 0 - 16</td>
<td class=br><strong>4</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>C</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2051&x=-404&p=Ma%20%C4%8Cernohous">Ma Černohous</a></td><td class=kL>0:10</td>
<td class=kL>0:8</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>0:11</td>
<td class=kL>1:9</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>2:7</td>
<td class=kL>0:9</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>0:9</td>
<td class=kL>2:4</td>
<td class=kL>1:8</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=br>13:105</td><td class=br>-92</td>
<td class=bc>1 - 1 - 16</td>
<td class=br><strong>3</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>C</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2050&x=-404&p=Ad%20Huspeka">Ad Huspeka</a></td><td class=kL>0:10</td>
<td class=kL>1:7</td>
<td class=kL>1:8</td>
<td class=kL>1:6</td>
<td class=kL>1:8</td>
<td class=kL>0:9</td>
<td class=kL>0:7</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>1:10</td>
<td class=kL>0:8</td>
<td class=kL>1:9</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=br>10:115</td><td class=br>-105</td>
<td class=bc>0 - 0 - 18</td>
<td class=br><strong>0</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ad Huspeka</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Ma Černohous</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ja Dvořáček</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ji Zapletal</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ra Hejtman</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ad Huspeka</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Ma Černohous</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ja Dvořáček</td><td class=bc>-</td><td class=bl>Ji Zapletal</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ad Huspeka</td><td class=bc>-</td><td class=blW>Ma Černohous</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Ji Zapletal</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ja Dvořáček</td><td class=bc>-</td><td class=blW>Ma Hlavačka</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ra Hejtman</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Černohous</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ad Huspeka</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Ji Zapletal</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ra Hejtman</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ja Dvořáček</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ma Černohous</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ad Huspeka</td><td class=bc>-</td><td class=blW>Ji Zapletal</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ra Hejtman</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ma Černohous</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ji Zapletal</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ad Huspeka</td><td class=bc>-</td><td class=blW>Ma Hlavačka</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ra Hejtman</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Ja Dvořáček</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Ji Zapletal</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Černohous</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Ra Hejtman</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ad Huspeka</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Ja Dvořáček</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ji Zapletal</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ma Černohous</td><td class=bc>-</td><td class=blW>Ra Hejtman</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ad Huspeka</td><td class=bc>-</td><td class=blW>Ja Dvořáček</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ji Zapletal</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ra Hejtman</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Černohous</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ja Dvořáček</td><td class=bc>14 : 0</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ad Huspeka</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Ji Zapletal</td><td class=bc>-</td><td class=blW>Ra Hejtman</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Ja Dvořáček</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Černohous</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ad Huspeka</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 9</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=bl>Ra Hejtman</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ji Zapletal</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ja Dvořáček</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Černohous</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ra Hejtman</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Ja Dvořáček</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ji Zapletal</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Černohous</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 11</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ad Huspeka</td><td class=bc>10 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ra Hejtman</td><td class=bc>-</td><td class=bl>Ja Dvořáček</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Hlavačka</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ji Zapletal</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Ad Huspeka</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Ma Černohous</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ja Dvořáček</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ra Hejtman</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ji Zapletal</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ad Huspeka</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ja Dvořáček</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ra Hejtman</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Ad Huspeka</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Ji Zapletal</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ma Černohous</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ja Dvořáček</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ra Hejtman</td><td class=bc>-</td><td class=bl>Ad Huspeka</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ji Zapletal</td><td class=bc>-</td><td class=bl>Ma Černohous</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ja Dvořáček</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ad Huspeka</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ra Hejtman</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 10</tr></td>
<tr><td class=brW>Ma Hlavačka</td><td class=bc>-</td><td class=bl>Ma Černohous</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ji Zapletal</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ad Huspeka</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Ja Dvořáček</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ma Černohous</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ra Hejtman</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ad Huspeka</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ja Dvořáček</td><td class=bc>-</td><td class=bl>Ma Černohous</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ra Hejtman</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ma Hlavačka</td><td class=bc>-</td><td class=bl>Ji Zapletal</td><td class=bc>3 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1406&x=-404&p=Ja%20Mat%C3%BDsek">Ja Matýsek</a></td><td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>6:0</td>
<td class=kW>5:4</td>
<td class=kW>10:3</td>
<td class=kW>7:1</td>
<td class=kW>6:1</td>
<td class=br>76:26</td><td class=br>+50</td>
<td class=bc>15 - 1 - 1</td>
<td class=br><strong>31</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=993&x=-404&p=Ji%20Chyl%C3%ADk%20ml.">Ji Chylík ml.</a></td><td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>10:3</td>
<td class=kW>12:0</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=br>80:23</td><td class=br>+57</td>
<td class=bc>14 - 1 - 2</td>
<td class=br><strong>29</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1065&x=-404&p=Kr%20Herold">Kr Herold</a></td><td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>9:1</td>
<td class=kW>6:2</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=br>73:27</td><td class=br>+46</td>
<td class=bc>12 - 3 - 2</td>
<td class=br><strong>27</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1641&x=-404&p=Ma%20Klazar">Ma Klazar</a></td><td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>9:1</td>
<td class=br>63:31</td><td class=br>+32</td>
<td class=bc>10 - 3 - 4</td>
<td class=br><strong>23</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=4&x=-404&p=Vl%20Kraus">Vl Kraus</a></td><td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>5:4</td>
<td class=kW>6:0</td>
<td class=kW>8:3</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=br>63:36</td><td class=br>+27</td>
<td class=bc>11 - 1 - 5</td>
<td class=br><strong>23</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=26&x=-404&p=Mi%20%C5%A0evr">Mi Ševr</a></td><td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>6:4</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>9:0</td>
<td class=kW>9:2</td>
<td class=kW>3:1</td>
<td class=kW>8:2</td>
<td class=br>73:40</td><td class=br>+33</td>
<td class=bc>10 - 3 - 4</td>
<td class=br><strong>23</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1268&x=-404&p=Da%20Dvo%C5%99%C3%A1%C4%8Dek">Da Dvořáček</a></td><td class=kL>0:6</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>9:0</td>
<td class=kW>7:0</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=br>64:37</td><td class=br>+27</td>
<td class=bc>11 - 1 - 5</td>
<td class=br><strong>23</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=176&x=-404&p=Zd%20Lopaur">Zd Lopaur</a></td><td class=kL>0:6</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>0:1</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>9:1</td>
<td class=kW>8:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>9:1</td>
<td class=br>67:41</td><td class=br>+26</td>
<td class=bc>9 - 2 - 6</td>
<td class=br><strong>20</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=448&x=-404&p=To%20Waclawek">To Waclawek</a></td><td class=kL>3:5</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>4:6</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>6:3</td>
<td class=kW>6:4</td>
<td class=kL>2:4</td>
<td class=kW>8:0</td>
<td class=br>61:48</td><td class=br>+13</td>
<td class=bc>8 - 2 - 7</td>
<td class=br><strong>18</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1657&x=-404&p=Jo%20Perkner">Jo Perkner</a></td><td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kW>7:3</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=br>42:50</td><td class=br>-8</td>
<td class=bc>7 - 3 - 7</td>
<td class=br><strong>17</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=215&x=-404&p=Jo%20Vom%C3%A1%C4%8Dka">Jo Vomáčka</a></td><td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kW>5:0</td>
<td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kL>1:5</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=br>39:47</td><td class=br>-8</td>
<td class=bc>7 - 2 - 8</td>
<td class=br><strong>16</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1940&x=-404&p=Ma%20Ko%C5%A1%C5%88ar">Ma Košňar</a></td><td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=br>46:48</td><td class=br>-2</td>
<td class=bc>5 - 5 - 7</td>
<td class=br><strong>15</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1896&x=-404&p=Ra%20Hrn%C4%8D%C3%AD%C5%99">Ra Hrnčíř</a></td><td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kL>1:9</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=br>32:62</td><td class=br>-30</td>
<td class=bc>6 - 0 - 11</td>
<td class=br><strong>12</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>B</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=131&x=-404&p=Da%20Pavelka">Da Pavelka</a></td><td class=kL>0:6</td>
<td class=kL>3:10</td>
<td class=kL>2:6</td>
<td class=kL>1:7</td>
<td class=kL>3:8</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>1:9</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=br>38:72</td><td class=br>-34</td>
<td class=bc>4 - 2 - 11</td>
<td class=br><strong>10</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2046&x=-404&p=Ma%20Voj%C3%A1%C4%8Dek">Ma Vojáček</a></td><td class=kL>4:5</td>
<td class=kL>0:12</td>
<td class=kL>1:7</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>0:9</td>
<td class=kL>0:9</td>
<td class=kL>1:8</td>
<td class=kL>3:6</td>
<td class=kW>4:2</td>
<td class=kL>0:3</td>
<td class=kL>4:5</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=br>30:91</td><td class=br>-61</td>
<td class=bc>3 - 1 - 13</td>
<td class=br><strong>7</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>C</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1252&x=-404&p=Ma%20Moravec">Ma Moravec</a></td><td class=kL>3:10</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>2:9</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>4:6</td>
<td class=kL>3:7</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=br>23:74</td><td class=br>-51</td>
<td class=bc>2 - 2 - 13</td>
<td class=br><strong>6</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>C</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1076&x=-404&p=Mi%20Zeman">Mi Zeman</a></td><td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kW>4:2</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=br>21:58</td><td class=br>-37</td>
<td class=bc>2 - 2 - 13</td>
<td class=br><strong>6</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>C</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2049&x=-404&p=Ma%20Dvo%C5%99%C3%A1k">Ma Dvořák</a></td><td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>0:6</td>
<td class=kL>1:9</td>
<td class=kL>1:7</td>
<td class=kL>2:8</td>
<td class=kL>1:4</td>
<td class=kL>1:9</td>
<td class=kL>0:8</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=br>20:100</td><td class=br>-80</td>
<td class=bc>0 - 0 - 17</td>
<td class=br><strong>0</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ma Dvořák</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Pavelka</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ma Moravec</td><td class=bc>-</td><td class=bl>Da Pavelka</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Dvořák</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Da Pavelka</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Dvořák</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Dvořák</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Jo Vomáčka</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Da Pavelka</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ma Vojáček</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 12</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Dvořák</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>Da Pavelka</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ma Vojáček</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ma Dvořák</td><td class=bc>-</td><td class=blW>Da Pavelka</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ma Vojáček</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ma Dvořák</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=bl>Da Pavelka</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ma Vojáček</td><td class=bc>-</td><td class=blW>Da Pavelka</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ma Dvořák</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Da Pavelka</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ma Vojáček</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Dvořák</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Jo Vomáčka</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Da Pavelka</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ma Vojáček</td><td class=bc>-</td><td class=blW>Jo Vomáčka</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Ma Dvořák</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ma Moravec</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>3 : 10</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ma Vojáček</td><td class=bc>-</td><td class=bl>Ma Dvořák</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Da Pavelka</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Moravec</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Jo Vomáčka</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Ma Dvořák</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Da Pavelka</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Ma Moravec</td><td class=bc>-</td><td class=blW>Jo Vomáčka</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Ma Dvořák</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Da Pavelka</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Ma Moravec</td><td class=bc>-</td><td class=bl>Ma Dvořák</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ma Vojáček</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ma Dvořák</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Da Pavelka</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ma Moravec</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Ma Dvořák</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Da Pavelka</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ma Moravec</td><td class=bc>-</td><td class=blW>Ma Vojáček</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Jo Vomáčka</td><td class=bc>-</td><td class=bl>Ma Dvořák</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Da Pavelka</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>3 : 10</tr></td>
<tr><td class=br>Ma Moravec</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Pavelka</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ma Moravec</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Jo Vomáčka</td><td class=bc>2 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 3</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1477&x=-404&p=Mi%20Kobrle">Mi Kobrle</a></td><td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>7:4</td>
<td class=kW>3:1</td>
<td class=kW>8:2</td>
<td class=kW>6:1</td>
<td class=kW>9:4</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>8:1</td>
<td class=kW>8:4</td>
<td class=kW>8:0</td>
<td class=kW>10:2</td>
<td class=kW>7:1</td>
<td class=kW>9:0</td>
<td class=kW>8:1</td>
<td class=br>117:33</td><td class=br>+84</td>
<td class=bc>16 - 1 - 0</td>
<td class=br><strong>33</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=567&x=-404&p=Kr%20Lebl">Kr Lebl</a></td><td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>7:4</td>
<td class=kW>9:0</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=kW>9:0</td>
<td class=kW>5:0</td>
<td class=br>94:15</td><td class=br>+79</td>
<td class=bc>15 - 2 - 0</td>
<td class=br><strong>32</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1&x=-404&p=Pa%20Ple%C5%A1%C3%A1k">Pa Plešák</a></td><td class=kL>4:7</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kL>4:6</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=kW>10:0</td>
<td class=kW>6:2</td>
<td class=kW>9:1</td>
<td class=kW>7:3</td>
<td class=kW>10:2</td>
<td class=kW>11:0</td>
<td class=kW>10:0</td>
<td class=br>100:40</td><td class=br>+60</td>
<td class=bc>13 - 1 - 3</td>
<td class=br><strong>27</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=841&x=-404&p=Ma%20Le%C5%BE%C3%ADk">Ma Ležík</a></td><td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>13:2</td>
<td class=kW>6:2</td>
<td class=kW>9:0</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>12:2</td>
<td class=kW>13:1</td>
<td class=br>99:32</td><td class=br>+67</td>
<td class=bc>13 - 1 - 3</td>
<td class=br><strong>27</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=201&x=-404&p=To%20Bucek">To Bucek</a></td><td class=kL>2:8</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>8:2</td>
<td class=kT>1:1</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=kW>9:2</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kW>8:0</td>
<td class=kW>12:1</td>
<td class=kW>9:0</td>
<td class=br>91:35</td><td class=br>+56</td>
<td class=bc>11 - 4 - 2</td>
<td class=br><strong>26</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1872&x=-404&p=Pe%20Fuchs">Pe Fuchs</a></td><td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kW>6:4</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kT>6:6</td>
<td class=kW>9:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>7:3</td>
<td class=kW>6:0</td>
<td class=br>68:40</td><td class=br>+28</td>
<td class=bc>11 - 2 - 4</td>
<td class=br><strong>24</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=248&x=-404&p=Ma%20%C5%BDen%C3%AD%C5%A1ek">Ma Ženíšek</a></td><td class=kL>4:9</td>
<td class=kL>4:7</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kW>9:3</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=br>76:49</td><td class=br>+27</td>
<td class=bc>9 - 5 - 3</td>
<td class=br><strong>23</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=270&x=-404&p=Vl%20Hejtman">Vl Hejtman</a></td><td class=kL>2:6</td>
<td class=kL>0:9</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>6:3</td>
<td class=kW>7:1</td>
<td class=kT>1:1</td>
<td class=kW>9:1</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kW>9:1</td>
<td class=kW>3:1</td>
<td class=br>64:53</td><td class=br>+11</td>
<td class=bc>9 - 1 - 7</td>
<td class=br><strong>19</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=999&x=-404&p=To%20Halama">To Halama</a></td><td class=kL>3:5</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>3:6</td>
<td class=kL>2:8</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kW>6:3</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=br>54:45</td><td class=br>+9</td>
<td class=bc>7 - 3 - 7</td>
<td class=br><strong>17</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1173&x=-404&p=Jo%20Mal%C3%BD">Jo Malý</a></td><td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kT>6:6</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=br>34:52</td><td class=br>-18</td>
<td class=bc>4 - 5 - 8</td>
<td class=br><strong>13</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1000&x=-404&p=Iv%20Halama">Iv Halama</a></td><td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>1:9</td>
<td class=kL>2:6</td>
<td class=kL>3:6</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=kT>2:2</td>
<td class=kW>7:0</td>
<td class=kW>8:1</td>
<td class=kW>8:1</td>
<td class=br>58:59</td><td class=br>-1</td>
<td class=bc>6 - 1 - 10</td>
<td class=br><strong>13</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1430&x=-404&p=Da%20Kadlec">Da Kadlec</a></td><td class=kL>1:8</td>
<td class=kL>0:6</td>
<td class=kL>0:10</td>
<td class=kL>2:13</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>3:9</td>
<td class=kL>1:7</td>
<td class=kL>3:6</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>5:3</td>
<td class=br>37:86</td><td class=br>-49</td>
<td class=bc>6 - 1 - 10</td>
<td class=br><strong>13</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2044&x=-404&p=Ja%20Tom%C3%A1%C5%A1t%C3%ADk">Ja Tomáštík</a></td><td class=kL>4:8</td>
<td class=kL>0:5</td>
<td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kL>2:9</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kW>7:2</td>
<td class=kL>0:5</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>10:1</td>
<td class=kW>3:2</td>
<td class=br>46:72</td><td class=br>-26</td>
<td class=bc>4 - 2 - 11</td>
<td class=br><strong>10</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>B</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2038&x=-404&p=Mi%20Moravec">Mi Moravec</a></td><td class=kL>0:8</td>
<td class=kL>0:7</td>
<td class=kL>1:9</td>
<td class=kL>0:9</td>
<td class=kL>2:7</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>1:9</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kL>0:8</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=br>25:89</td><td class=br>-64</td>
<td class=bc>4 - 1 - 12</td>
<td class=br><strong>9</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=216&x=-404&p=Ro%20Vom%C3%A1%C4%8Dka">Ro Vomáčka</a></td><td class=kL>2:10</td>
<td class=kL>0:4</td>
<td class=kL>3:7</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>3:6</td>
<td class=kW>4:0</td>
<td class=br>31:67</td><td class=br>-36</td>
<td class=bc>3 - 3 - 11</td>
<td class=br><strong>9</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>C</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1869&x=-404&p=Pe%20Klazar">Pe Klazar</a></td><td class=kL>1:7</td>
<td class=kL>0:7</td>
<td class=kL>2:10</td>
<td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>0:7</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kW>7:1</td>
<td class=br>34:80</td><td class=br>-46</td>
<td class=bc>2 - 2 - 13</td>
<td class=br><strong>6</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>C</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2047&x=-404&p=Mi%20Vurbal">Mi Vurbal</a></td><td class=kL>0:9</td>
<td class=kL>0:9</td>
<td class=kL>0:11</td>
<td class=kL>2:12</td>
<td class=kL>1:12</td>
<td class=kL>3:7</td>
<td class=kL>2:6</td>
<td class=kL>1:9</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kL>1:8</td>
<td class=kL>3:6</td>
<td class=kL>1:10</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=br>30:120</td><td class=br>-90</td>
<td class=bc>2 - 1 - 14</td>
<td class=br><strong>5</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>C</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2048&x=-404&p=Mi%20Proch%C3%A1ska">Mi Procháska</a></td><td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kL>0:10</td>
<td class=kL>1:13</td>
<td class=kL>0:9</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>1:8</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=br>15:106</td><td class=br>-91</td>
<td class=bc>0 - 0 - 17</td>
<td class=br><strong>0</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Vurbal</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Vl Hejtman</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Iv Halama</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ja Tomáštík</td><td class=bc>-</td><td class=bl>Mi Procháska</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Mi Vurbal</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>2 : 12</tr></td>
<tr><td class=br>Vl Hejtman</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Iv Halama</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>Mi Procháska</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Da Kadlec</td><td class=bc>-</td><td class=bl>Ja Tomáštík</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>4 : 9</tr></td>
<tr><td class=br>Mi Vurbal</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vl Hejtman</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Iv Halama</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Mi Procháska</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ja Tomáštík</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Da Kadlec</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Mi Moravec</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Vurbal</td><td class=bc>-</td><td class=blW>Iv Halama</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Vl Hejtman</td><td class=bc>-</td><td class=bl>Mi Procháska</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Ja Tomáštík</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>10 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ro Vomáčka</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=blW>Iv Halama</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Procháska</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Mi Vurbal</td><td class=bc>-</td><td class=blW>Ja Tomáštík</td><td class=bc>1 : 10</tr></td>
<tr><td class=brW>Vl Hejtman</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=bl>Iv Halama</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Procháska</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=blW>Ja Tomáštík</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>9 : 3</tr></td>
<tr><td class=br>Mi Vurbal</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Vl Hejtman</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>6 : 6</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Iv Halama</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Mi Procháska</td><td class=bc>13 : 1</tr></td>
<tr><td class=brW>Ro Vomáčka</td><td class=bc>-</td><td class=bl>Ja Tomáštík</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Mi Moravec</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Vurbal</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 12</tr></td>
<tr><td class=brW>Vl Hejtman</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Iv Halama</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Mi Procháska</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ja Tomáštík</td><td class=bc>8 : 4</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>13 : 2</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mi Vurbal</td><td class=bc>-</td><td class=blW>Vl Hejtman</td><td class=bc>1 : 9</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Iv Halama</td><td class=bc>-</td><td class=bl>Mi Procháska</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ja Tomáštík</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=blW>Vl Hejtman</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Vurbal</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Mi Procháska</td><td class=bc>-</td><td class=blW>Da Kadlec</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Iv Halama</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Vl Hejtman</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Mi Vurbal</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ja Tomáštík</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Procháska</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Iv Halama</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Vl Hejtman</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Vurbal</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Mi Moravec</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Ja Tomáštík</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Mi Procháska</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Iv Halama</td><td class=bc>-</td><td class=blW>Vl Hejtman</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Mi Vurbal</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ja Tomáštík</td><td class=bc>-</td><td class=bl>Vl Hejtman</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Procháska</td><td class=bc>-</td><td class=blW>Mi Vurbal</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Iv Halama</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>10 : 2</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Vl Hejtman</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Da Kadlec</td><td class=bc>-</td><td class=bl>Mi Vurbal</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ja Tomáštík</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Procháska</td><td class=bc>-</td><td class=blW>Mi Moravec</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Iv Halama</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Vl Hejtman</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Vurbal</td><td class=bc>11 : 0</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Da Kadlec</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ja Tomáštík</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Mi Procháska</td><td class=bc>-</td><td class=blW>Ro Vomáčka</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Iv Halama</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Mi Vurbal</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Da Kadlec</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ja Tomáštík</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Mi Procháska</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Iv Halama</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Vl Hejtman</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Ja Tomáštík</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Mi Procháska</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Iv Halama</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Mi Vurbal</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vl Hejtman</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ja Tomáštík</td><td class=bc>-</td><td class=blW>Iv Halama</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Mi Procháska</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<hr><a name="final"><p class=vm>Výkonnostní skupiny (Final groups)</p></a>
<p class=v>Group A</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=567&x=-404&p=Kr%20Lebl">Kr Lebl</a></td><td class=kx>*</td>
<td class=kT>4:4 K</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kW>5:2 K</td>
<td class=kT>3:3 K</td>
<td class=kW>2:0</td>
<td class=kW>6:0 K</td>
<td class=kW>4:1</td>
<td class=kW>7:4 K</td>
<td class=kW>1:0</td>
<td class=kT>3:3 K</td>
<td class=kW>5:1</td>
<td class=kW>3:1 K</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>9:0 K</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=br>90:42</td><td class=br>+48</td>
<td class=bc>17 - 5 - 1</td>
<td class=br><strong>39</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1477&x=-404&p=Mi%20Kobrle">Mi Kobrle</a></td><td class=kT>4:4 K</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1 K</td>
<td class=kT>2:2</td>
<td class=kW>7:4</td>
<td class=kW>7:4 K</td>
<td class=kW>7:1</td>
<td class=kW>9:4 K</td>
<td class=kW>7:1</td>
<td class=kW>8:2 K</td>
<td class=kW>3:1</td>
<td class=kW>6:1 K</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kT>5:5</td>
<td class=kW>7:0</td>
<td class=kW>6:1</td>
<td class=kW>6:2 K</td>
<td class=kW>8:0</td>
<td class=kW>6:2</td>
<td class=br>118:45</td><td class=br>+73</td>
<td class=bc>17 - 5 - 1</td>
<td class=br><strong>39</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=409&x=-404&p=Pa%20Petr">Pa Petr</a></td><td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>2:7</td>
<td class=kW>5:2</td>
<td class=kT>3:3 K</td>
<td class=kW>5:2</td>
<td class=kT>3:3 K</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>6:2 K</td>
<td class=kW>4:0</td>
<td class=kW>10:1</td>
<td class=kW>5:3</td>
<td class=kW>3:2 K</td>
<td class=kW>6:1 K</td>
<td class=kW>6:2</td>
<td class=kW>7:4 K</td>
<td class=kT>5:5</td>
<td class=kW>7:1</td>
<td class=kW>5:2 K</td>
<td class=kW>6:1</td>
<td class=br>112:51</td><td class=br>+61</td>
<td class=bc>17 - 5 - 1</td>
<td class=br><strong>39</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1406&x=-404&p=Ja%20Mat%C3%BDsek">Ja Matýsek</a></td><td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kx>*</td>
<td class=kW>1:0 K</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kT>1:1 K</td>
<td class=kT>8:8</td>
<td class=kW>4:3 K</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kL>1:2 K</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>3:1 K</td>
<td class=kW>4:3</td>
<td class=kW>6:0 K</td>
<td class=kW>9:1</td>
<td class=kW>3:2</td>
<td class=kW>6:0 K</td>
<td class=br>85:42</td><td class=br>+43</td>
<td class=bc>16 - 4 - 3</td>
<td class=br><strong>36</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=993&x=-404&p=Ji%20Chyl%C3%ADk%20ml.">Ji Chylík ml.</a></td><td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>0:1 K</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kL>2:8</td>
<td class=kW>2:1</td>
<td class=kW>3:0 K</td>
<td class=kW>6:1</td>
<td class=kW>3:1 K</td>
<td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=kW>3:1 K</td>
<td class=kW>3:0</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kL>1:4 K</td>
<td class=kW>2:1</td>
<td class=kW>4:3 K</td>
<td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kW>5:3 K</td>
<td class=br>70:51</td><td class=br>+19</td>
<td class=bc>16 - 2 - 5</td>
<td class=br><strong>34</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=40&x=-404&p=Da%20Mat%C3%BDsek">Da Matýsek</a></td><td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kT>3:3 K</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>1:2 K</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kW>3:1 K</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>1:1 K</td>
<td class=kW>2:1 K</td>
<td class=kW>4:1</td>
<td class=kW>5:1 K</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kL>1:5 K</td>
<td class=kW>8:4</td>
<td class=br>61:46</td><td class=br>+15</td>
<td class=bc>12 - 5 - 6</td>
<td class=br><strong>29</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=841&x=-404&p=Ma%20Le%C5%BE%C3%ADk">Ma Ležík</a></td><td class=kL>2:5 K</td>
<td class=kL>1:3 K</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kW>8:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>3:6 K</td>
<td class=kT>4:4</td>
<td class=kT>2:2 K</td>
<td class=kL>1:7</td>
<td class=kW>2:1 K</td>
<td class=kL>3:5</td>
<td class=kW>5:1 K</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>6:2 K</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=br>77:65</td><td class=br>+12</td>
<td class=bc>12 - 3 - 8</td>
<td class=br><strong>27</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=961&x=-404&p=Mi%20Bo%C5%A1t%C3%ADk">Mi Boštík</a></td><td class=kT>3:3 K</td>
<td class=kT>2:2</td>
<td class=kT>3:3 K</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>2:1 K</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>6:5</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kL>1:2 K</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3 K</td>
<td class=kT>2:2 K</td>
<td class=kW>3:0</td>
<td class=kL>2:3 K</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kW>7:1 K</td>
<td class=kW>4:1</td>
<td class=br>64:58</td><td class=br>+6</td>
<td class=bc>10 - 5 - 8</td>
<td class=br><strong>25</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1065&x=-404&p=Kr%20Herold">Kr Herold</a></td><td class=kL>0:2</td>
<td class=kL>4:7</td>
<td class=kL>3:4</td>
<td class=kT>1:1 K</td>
<td class=kL>0:3 K</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>5:6</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>4:5 K</td>
<td class=kL>4:8</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kW>5:2 K</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>4:2 K</td>
<td class=kL>3:4</td>
<td class=kT>4:4 K</td>
<td class=kW>6:3</td>
<td class=kW>5:3</td>
<td class=kW>4:2 K</td>
<td class=br>77:70</td><td class=br>+7</td>
<td class=bc>11 - 3 - 9</td>
<td class=br><strong>25</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1&x=-404&p=Pa%20Ple%C5%A1%C3%A1k">Pa Plešák</a></td><td class=kL>0:6 K</td>
<td class=kL>4:7 K</td>
<td class=kL>0:3</td>
<td class=kT>8:8</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kW>6:3 K</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:1 K</td>
<td class=kT>1:1</td>
<td class=kT>3:3 K</td>
<td class=kL>0:3</td>
<td class=kL>4:6 K</td>
<td class=kW>7:3</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kW>4:2 K</td>
<td class=kW>4:2</td>
<td class=kW>8:3</td>
<td class=br>73:74</td><td class=br>-1</td>
<td class=bc>10 - 4 - 9</td>
<td class=br><strong>24</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1641&x=-404&p=Ma%20Klazar">Ma Klazar</a></td><td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>1:7</td>
<td class=kL>3:4 K</td>
<td class=kL>1:3 K</td>
<td class=kW>5:3</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kW>5:4 K</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kW>6:1 K</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2</td>
<td class=kW>5:0 K</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>1:0 K</td>
<td class=br>63:65</td><td class=br>-2</td>
<td class=bc>10 - 3 - 10</td>
<td class=br><strong>23</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=248&x=-404&p=Ma%20%C5%BDen%C3%AD%C5%A1ek">Ma Ženíšek</a></td><td class=kL>4:7 K</td>
<td class=kL>4:9 K</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kT>2:2 K</td>
<td class=kL>3:4</td>
<td class=kW>8:4</td>
<td class=kL>1:4 K</td>
<td class=kW>7:2</td>
<td class=kx>*</td>
<td class=kW>7:2</td>
<td class=kT>3:3 K</td>
<td class=kL>0:3</td>
<td class=kT>3:3 K</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kW>3:0</td>
<td class=kW>11:4</td>
<td class=kW>5:3</td>
<td class=kW>4:2 K</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=br>85:81</td><td class=br>+4</td>
<td class=bc>9 - 4 - 10</td>
<td class=br><strong>22</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=53&x=-404&p=V%C3%A1%20Pikl">Vá Pikl</a></td><td class=kL>0:1</td>
<td class=kL>1:7</td>
<td class=kL>2:6 K</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3 K</td>
<td class=kW>7:1</td>
<td class=kW>2:1 K</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>2:7</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kL>1:2 K</td>
<td class=kT>1:1 K</td>
<td class=kL>1:2</td>
<td class=kW>3:0 K</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kL>2:3 K</td>
<td class=kW>3:1</td>
<td class=br>49:50</td><td class=br>-1</td>
<td class=bc>10 - 2 - 11</td>
<td class=br><strong>22</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=201&x=-404&p=To%20Bucek">To Bucek</a></td><td class=kT>3:3 K</td>
<td class=kL>2:8 K</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kL>1:2 K</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kT>3:3 K</td>
<td class=kL>0:1</td>
<td class=kT>3:3 K</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:3 K</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kL>1:2</td>
<td class=kW>5:2 K</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=br>55:61</td><td class=br>-6</td>
<td class=bc>8 - 5 - 10</td>
<td class=br><strong>21</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=4&x=-404&p=Vl%20Kraus">Vl Kraus</a></td><td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>1:10</td>
<td class=kW>2:1 K</td>
<td class=kL>1:3 K</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kL>2:5 K</td>
<td class=kW>3:0</td>
<td class=kL>1:6 K</td>
<td class=kW>3:0</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>1:6</td>
<td class=kL>0:1</td>
<td class=kT>3:3 K</td>
<td class=kW>5:3</td>
<td class=kW>4:2 K</td>
<td class=kT>4:4</td>
<td class=kL>0:1</td>
<td class=kL>2:4 K</td>
<td class=br>49:71</td><td class=br>-22</td>
<td class=bc>8 - 3 - 12</td>
<td class=br><strong>19</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1872&x=-404&p=Pe%20Fuchs">Pe Fuchs</a></td><td class=kL>1:3 K</td>
<td class=kL>1:6 K</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>1:5 K</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>6:4 K</td>
<td class=kL>2:5</td>
<td class=kT>3:3 K</td>
<td class=kL>0:3</td>
<td class=kL>3:4 K</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kW>1:0</td>
<td class=kW>3:1 K</td>
<td class=kW>6:0</td>
<td class=kW>7:5</td>
<td class=br>58:69</td><td class=br>-11</td>
<td class=bc>8 - 2 - 13</td>
<td class=br><strong>18</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=310&x=-404&p=Mi%20%C4%8Cernoch">Mi Černoch</a></td><td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>2:3 K</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kT>1:1 K</td>
<td class=kL>1:3</td>
<td class=kW>3:2 K</td>
<td class=kL>1:4</td>
<td class=kL>3:7</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kW>2:1 K</td>
<td class=kL>2:4</td>
<td class=kW>6:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>2:3 K</td>
<td class=kW>4:1</td>
<td class=kT>1:1 K</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kW>6:4 K</td>
<td class=kW>3:2</td>
<td class=br>50:60</td><td class=br>-10</td>
<td class=bc>7 - 4 - 12</td>
<td class=br><strong>18</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1876&x=-404&p=Ad%20Kop%C5%99iva">Ad Kopřiva</a></td><td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>1:6 K</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2 K</td>
<td class=kL>1:2</td>
<td class=kT>2:2 K</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kT>1:1 K</td>
<td class=kL>2:6</td>
<td class=kW>1:0</td>
<td class=kL>0:4</td>
<td class=kW>3:2 K</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kL>2:4 K</td>
<td class=kW>3:0</td>
<td class=kW>10:0</td>
<td class=kW>2:1 K</td>
<td class=kW>4:3</td>
<td class=br>51:61</td><td class=br>-10</td>
<td class=bc>8 - 2 - 13</td>
<td class=br><strong>18</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=26&x=-404&p=Mi%20%C5%A0evr">Mi Ševr</a></td><td class=kL>1:5</td>
<td class=kT>5:5</td>
<td class=kL>2:6</td>
<td class=kL>1:3 K</td>
<td class=kW>4:1 K</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kL>2:4 K</td>
<td class=kL>1:6</td>
<td class=kT>1:1 K</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kT>3:3 K</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>6:5</td>
<td class=kL>2:4 K</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>5:2 K</td>
<td class=br>54:76</td><td class=br>-22</td>
<td class=bc>7 - 4 - 12</td>
<td class=br><strong>18</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=818&x=-404&p=Ro%20Je%C5%BE">Ro Jež</a></td><td class=kL>1:3</td>
<td class=kL>0:7</td>
<td class=kL>4:7 K</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>1:5 K</td>
<td class=kL>1:6</td>
<td class=kW>3:2 K</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>4:11</td>
<td class=kL>0:3 K</td>
<td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kT>4:4</td>
<td class=kT>1:1 K</td>
<td class=kW>4:2 K</td>
<td class=kL>5:6</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3 K</td>
<td class=kL>2:4</td>
<td class=br>56:91</td><td class=br>-35</td>
<td class=bc>5 - 4 - 14</td>
<td class=br><strong>14</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1268&x=-404&p=Da%20Dvo%C5%99%C3%A1%C4%8Dek">Da Dvořáček</a></td><td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kT>5:5</td>
<td class=kL>0:6 K</td>
<td class=kL>3:4 K</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kW>5:0</td>
<td class=kT>4:4 K</td>
<td class=kL>1:4</td>
<td class=kL>0:5 K</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>2:4 K</td>
<td class=kL>0:1</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kW>4:2 K</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>4:3 K</td>
<td class=br>47:77</td><td class=br>-30</td>
<td class=bc>6 - 2 - 15</td>
<td class=br><strong>14</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=270&x=-404&p=Vl%20Hejtman">Vl Hejtman</a></td><td class=kL>0:9 K</td>
<td class=kL>2:6 K</td>
<td class=kL>1:7</td>
<td class=kL>1:9</td>
<td class=kL>4:5</td>
<td class=kL>1:6</td>
<td class=kL>2:6 K</td>
<td class=kW>3:0</td>
<td class=kL>3:6</td>
<td class=kL>2:4 K</td>
<td class=kL>2:6</td>
<td class=kL>2:4 K</td>
<td class=kL>1:2</td>
<td class=kL>2:5 K</td>
<td class=kT>4:4</td>
<td class=kL>1:3 K</td>
<td class=kT>2:2</td>
<td class=kL>0:10</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>0:7</td>
<td class=br>44:111</td><td class=br>-67</td>
<td class=bc>4 - 2 - 17</td>
<td class=br><strong>10</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1912&x=-404&p=Al%20Krejza">Al Krejza</a></td><td class=kL>3:4</td>
<td class=kL>0:8</td>
<td class=kL>2:5 K</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>5:1 K</td>
<td class=kL>3:4</td>
<td class=kL>1:7 K</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>3:2 K</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kL>0:6</td>
<td class=kL>4:6 K</td>
<td class=kL>1:2 K</td>
<td class=kL>1:3</td>
<td class=kT>3:3 K</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>47:83</td><td class=br>-36</td>
<td class=bc>4 - 1 - 18</td>
<td class=br><strong>9</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=176&x=-404&p=Zd%20Lopaur">Zd Lopaur</a></td><td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>0:6 K</td>
<td class=kL>3:5 K</td>
<td class=kL>4:8</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>2:4 K</td>
<td class=kL>3:8</td>
<td class=kL>0:1 K</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>4:2 K</td>
<td class=kL>5:7</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>2:5 K</td>
<td class=kW>4:2</td>
<td class=kL>3:4 K</td>
<td class=kW>7:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>57:92</td><td class=br>-35</td>
<td class=bc>4 - 1 - 18</td>
<td class=br><strong>9</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Vl Hejtman</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Vl Hejtman</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>8 : 8</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Vl Hejtman</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Vl Hejtman</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Vl Hejtman</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>8 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Vl Hejtman</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>4 : 8</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Vl Hejtman</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Vl Hejtman</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Vl Hejtman</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>4 : 11</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Vl Hejtman</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Vl Hejtman</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Vl Hejtman</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Vl Hejtman</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vl Hejtman</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Vl Hejtman</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>7 : 5</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Vl Hejtman</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 3 K</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>5 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=448&x=-404&p=To%20Waclawek">To Waclawek</a></td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>7:3</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>9:0</td>
<td class=br>76:26</td><td class=br>+50</td>
<td class=bc>14 - 1 - 1</td>
<td class=br><strong>29</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=261&x=-404&p=Da%20Cibulka">Da Cibulka</a></td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>5:4</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kW>13:1</td>
<td class=br>68:28</td><td class=br>+40</td>
<td class=bc>12 - 3 - 1</td>
<td class=br><strong>27</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1940&x=-404&p=Ma%20Ko%C5%A1%C5%88ar">Ma Košňar</a></td><td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kW>2:0</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>4:0</td>
<td class=br>50:34</td><td class=br>+16</td>
<td class=bc>11 - 0 - 5</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1058&x=-404&p=Fr%20Marek">Fr Marek</a></td><td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>9:3</td>
<td class=kT>3:3</td>
<td class=kW>8:3</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>57:42</td><td class=br>+15</td>
<td class=bc>9 - 3 - 4</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1318&x=-404&p=Jo%20Sedl%C3%A1%C4%8Dek">Jo Sedláček</a></td><td class=kL>3:7</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kL>4:6</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=br>49:40</td><td class=br>+9</td>
<td class=bc>9 - 2 - 5</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=215&x=-404&p=Jo%20Vom%C3%A1%C4%8Dka">Jo Vomáčka</a></td><td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=br>46:33</td><td class=br>+13</td>
<td class=bc>9 - 2 - 5</td>
<td class=br><strong>20</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/4</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1657&x=-404&p=Jo%20Perkner">Jo Perkner</a></td><td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=br>42:36</td><td class=br>+6</td>
<td class=bc>9 - 2 - 5</td>
<td class=br><strong>20</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/4</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=204&x=-404&p=Hy%20Nechutn%C3%BD">Hy Nechutný</a></td><td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=br>44:35</td><td class=br>+9</td>
<td class=bc>7 - 4 - 5</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1173&x=-404&p=Jo%20Mal%C3%BD">Jo Malý</a></td><td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kW>9:4</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kT>0:0</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=br>39:35</td><td class=br>+4</td>
<td class=bc>8 - 2 - 6</td>
<td class=br><strong>18</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1871&x=-404&p=Mi%20L%C3%A9vy">Mi Lévy</a></td><td class=kL>2:6</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kL>1:4</td>
<td class=kW>5:0</td>
<td class=kL>3:4</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=br>54:45</td><td class=br>+9</td>
<td class=bc>7 - 1 - 8</td>
<td class=br><strong>15</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=999&x=-404&p=To%20Halama">To Halama</a></td><td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>4:9</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>9:1</td>
<td class=kW>7:2</td>
<td class=br>56:55</td><td class=br>+1</td>
<td class=bc>5 - 4 - 7</td>
<td class=br><strong>14</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2014&x=-404&p=Ma%20Hlava%C4%8Dka">Ma Hlavačka</a></td><td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=br>36:36</td><td class=br>0</td>
<td class=bc>7 - 0 - 9</td>
<td class=br><strong>14</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1896&x=-404&p=Ra%20Hrn%C4%8D%C3%AD%C5%99">Ra Hrnčíř</a></td><td class=kL>3:4</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kL>3:9</td>
<td class=kW>6:4</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=br>33:54</td><td class=br>-21</td>
<td class=bc>4 - 3 - 9</td>
<td class=br><strong>11</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=131&x=-404&p=Da%20Pavelka">Da Pavelka</a></td><td class=kL>2:7</td>
<td class=kL>1:6</td>
<td class=kL>2:7</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kW>10:0</td>
<td class=br>41:55</td><td class=br>-14</td>
<td class=bc>3 - 3 - 10</td>
<td class=br><strong>9</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1430&x=-404&p=Da%20Kadlec">Da Kadlec</a></td><td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>3:8</td>
<td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kT>0:0</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=br>24:55</td><td class=br>-31</td>
<td class=bc>3 - 2 - 11</td>
<td class=br><strong>8</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2044&x=-404&p=Ja%20Tom%C3%A1%C5%A1t%C3%ADk">Ja Tomáštík</a></td><td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kL>1:9</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=br>25:65</td><td class=br>-40</td>
<td class=bc>1 - 3 - 12</td>
<td class=br><strong>5</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2038&x=-404&p=Mi%20Moravec">Mi Moravec</a></td><td class=kL>0:9</td>
<td class=kL>1:13</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>0:10</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=br>16:82</td><td class=br>-66</td>
<td class=bc>0 - 1 - 15</td>
<td class=br><strong>1</strong></td><td class=d>17.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Da Pavelka</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Ja Tomáštík</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Jo Vomáčka</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Da Pavelka</td><td class=bc>-</td><td class=blW>Ma Hlavačka</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ja Tomáštík</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Ja Tomáštík</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Pavelka</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Jo Vomáčka</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ja Tomáštík</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Pavelka</td><td class=bc>-</td><td class=blW>Da Kadlec</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Ja Tomáštík</td><td class=bc>-</td><td class=blW>Da Kadlec</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Da Pavelka</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Tomáštík</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ma Hlavačka</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Pavelka</td><td class=bc>-</td><td class=blW>Jo Vomáčka</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ja Tomáštík</td><td class=bc>-</td><td class=blW>Jo Vomáčka</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ma Hlavačka</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Da Pavelka</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Da Kadlec</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Jo Vomáčka</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ja Tomáštík</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Da Pavelka</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Jo Vomáčka</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ja Tomáštík</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Da Pavelka</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=blW>Jo Vomáčka</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ja Tomáštík</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ma Hlavačka</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ja Tomáštík</td><td class=bc>-</td><td class=blW>Da Pavelka</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>1 : 13</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Da Pavelka</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ma Hlavačka</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Da Pavelka</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Ma Hlavačka</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Ja Tomáštík</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>9 : 4</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=blW>Da Pavelka</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Ja Tomáštík</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Da Pavelka</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>Ma Hlavačka</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=bl>Ja Tomáštík</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>9 : 3</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>Da Pavelka</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Ja Tomáštík</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Jo Vomáčka</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>8 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Da Pavelka</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Ja Tomáštík</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Jo Vomáčka</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>0 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2046&x=-404&p=Ma%20Voj%C3%A1%C4%8Dek">Ma Vojáček</a></td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=br>39:21</td><td class=br>+18</td>
<td class=bc>10 - 1 - 1</td>
<td class=br><strong>21</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1269&x=-404&p=Ja%20Dvo%C5%99%C3%A1%C4%8Dek">Ja Dvořáček</a></td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>9:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=br>49:24</td><td class=br>+25</td>
<td class=bc>8 - 3 - 1</td>
<td class=br><strong>19</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1252&x=-404&p=Ma%20Moravec">Ma Moravec</a></td><td class=kL>3:4</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=br>47:27</td><td class=br>+20</td>
<td class=bc>9 - 0 - 3</td>
<td class=br><strong>18</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=216&x=-404&p=Ro%20Vom%C3%A1%C4%8Dka">Ro Vomáčka</a></td><td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=br>36:19</td><td class=br>+17</td>
<td class=bc>8 - 1 - 3</td>
<td class=br><strong>17</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=271&x=-404&p=Ra%20Hejtman">Ra Hejtman</a></td><td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=br>42:26</td><td class=br>+16</td>
<td class=bc>7 - 2 - 3</td>
<td class=br><strong>16</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1869&x=-404&p=Pe%20Klazar">Pe Klazar</a></td><td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=br>34:26</td><td class=br>+8</td>
<td class=bc>6 - 2 - 4</td>
<td class=br><strong>14</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/4</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2047&x=-404&p=Mi%20Vurbal">Mi Vurbal</a></td><td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>8:1</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>7:3</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=br>39:32</td><td class=br>+7</td>
<td class=bc>6 - 0 - 6</td>
<td class=br><strong>12</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/4</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1076&x=-404&p=Mi%20Zeman">Mi Zeman</a></td><td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>1:8</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>7:1</td>
<td class=br>35:34</td><td class=br>+1</td>
<td class=bc>5 - 2 - 5</td>
<td class=br><strong>12</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2049&x=-404&p=Ma%20Dvo%C5%99%C3%A1k">Ma Dvořák</a></td><td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=br>29:22</td><td class=br>+7</td>
<td class=bc>6 - 0 - 6</td>
<td class=br><strong>12</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2048&x=-404&p=Mi%20Proch%C3%A1ska">Mi Procháska</a></td><td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=br>19:44</td><td class=br>-25</td>
<td class=bc>2 - 1 - 9</td>
<td class=br><strong>5</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2051&x=-404&p=Ma%20%C4%8Cernohous">Ma Černohous</a></td><td class=kL>0:3</td>
<td class=kL>1:9</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>3:7</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=br>17:49</td><td class=br>-32</td>
<td class=bc>1 - 2 - 9</td>
<td class=br><strong>4</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1635&x=-404&p=Ji%20Zapletal">Ji Zapletal</a></td><td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>3:7</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>16:46</td><td class=br>-30</td>
<td class=bc>1 - 2 - 9</td>
<td class=br><strong>4</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2050&x=-404&p=Ad%20Huspeka">Ad Huspeka</a></td><td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>14:46</td><td class=br>-32</td>
<td class=bc>0 - 2 - 10</td>
<td class=br><strong>2</strong></td><td class=d>13.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ra Hejtman</td><td class=bc>-</td><td class=bl>Ad Huspeka</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Vojáček</td><td class=bc>-</td><td class=bl>Mi Procháska</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Ma Dvořák</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ja Dvořáček</td><td class=bc>-</td><td class=bl>Ma Černohous</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Ma Moravec</td><td class=bc>-</td><td class=bl>Mi Vurbal</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ad Huspeka</td><td class=bc>-</td><td class=blW>Mi Procháska</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ra Hejtman</td><td class=bc>-</td><td class=bl>Ma Dvořák</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ma Vojáček</td><td class=bc>-</td><td class=bl>Ma Černohous</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ro Vomáčka</td><td class=bc>-</td><td class=bl>Mi Vurbal</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ji Zapletal</td><td class=bc>-</td><td class=blW>Ma Moravec</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=bl>Ja Dvořáček</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Mi Procháska</td><td class=bc>-</td><td class=blW>Ma Dvořák</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ad Huspeka</td><td class=bc>-</td><td class=bl>Ma Černohous</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ra Hejtman</td><td class=bc>-</td><td class=bl>Mi Vurbal</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ja Dvořáček</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ro Vomáčka</td><td class=bc>-</td><td class=bl>Ji Zapletal</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ma Dvořák</td><td class=bc>-</td><td class=bl>Ma Černohous</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mi Procháska</td><td class=bc>-</td><td class=blW>Mi Vurbal</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ma Moravec</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ra Hejtman</td><td class=bc>-</td><td class=bl>Ji Zapletal</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ma Vojáček</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Ad Huspeka</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ma Černohous</td><td class=bc>-</td><td class=blW>Mi Vurbal</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ja Dvořáček</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Procháska</td><td class=bc>-</td><td class=bl>Ji Zapletal</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ad Huspeka</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ra Hejtman</td><td class=bc>-</td><td class=blW>Ma Moravec</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Ma Dvořák</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ro Vomáčka</td><td class=bc>-</td><td class=bl>Ra Hejtman</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ma Černohous</td><td class=bc>-</td><td class=bl>Ji Zapletal</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ma Dvořák</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Procháska</td><td class=bc>-</td><td class=blW>Ma Moravec</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ad Huspeka</td><td class=bc>-</td><td class=blW>Ja Dvořáček</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Mi Vurbal</td><td class=bc>1 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ad Huspeka</td><td class=bc>-</td><td class=blW>Ma Vojáček</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Vurbal</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Černohous</td><td class=bc>-</td><td class=blW>Ma Moravec</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Dvořák</td><td class=bc>-</td><td class=blW>Ja Dvořáček</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Procháska</td><td class=bc>-</td><td class=blW>Ro Vomáčka</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=bl>Ji Zapletal</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ji Zapletal</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Procháska</td><td class=bc>-</td><td class=blW>Ra Hejtman</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Mi Vurbal</td><td class=bc>-</td><td class=blW>Ja Dvořáček</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Černohous</td><td class=bc>-</td><td class=blW>Ro Vomáčka</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ma Dvořák</td><td class=bc>-</td><td class=blW>Ma Vojáček</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ma Moravec</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ji Zapletal</td><td class=bc>-</td><td class=blW>Ja Dvořáček</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Dvořák</td><td class=bc>-</td><td class=bl>Ad Huspeka</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Vurbal</td><td class=bc>-</td><td class=blW>Ma Vojáček</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Černohous</td><td class=bc>-</td><td class=blW>Ra Hejtman</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ro Vomáčka</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ma Moravec</td><td class=bc>-</td><td class=blW>Ja Dvořáček</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ji Zapletal</td><td class=bc>-</td><td class=blW>Ma Vojáček</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Černohous</td><td class=bc>-</td><td class=blW>Mi Procháska</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Mi Vurbal</td><td class=bc>-</td><td class=bl>Ad Huspeka</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ra Hejtman</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ja Dvořáček</td><td class=bc>-</td><td class=blW>Ro Vomáčka</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Moravec</td><td class=bc>-</td><td class=blW>Ma Vojáček</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ra Hejtman</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ji Zapletal</td><td class=bc>-</td><td class=bl>Ad Huspeka</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Vurbal</td><td class=bc>-</td><td class=bl>Ma Dvořák</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Mi Procháska</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Ma Vojáček</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ja Dvořáček</td><td class=bc>-</td><td class=bl>Ra Hejtman</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ma Moravec</td><td class=bc>-</td><td class=bl>Ad Huspeka</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>Mi Procháska</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ji Zapletal</td><td class=bc>-</td><td class=blW>Ma Dvořák</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Ma Černohous</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ma Vojáček</td><td class=bc>-</td><td class=bl>Ra Hejtman</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ro Vomáčka</td><td class=bc>-</td><td class=bl>Ad Huspeka</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ja Dvořáček</td><td class=bc>-</td><td class=bl>Mi Procháska</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Moravec</td><td class=bc>-</td><td class=bl>Ma Dvořák</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=bl>Ma Černohous</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ji Zapletal</td><td class=bc>-</td><td class=blW>Mi Vurbal</td><td class=bc>3 : 7</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
