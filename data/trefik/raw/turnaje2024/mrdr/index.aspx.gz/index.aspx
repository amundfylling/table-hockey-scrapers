<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR družstva</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../mrdr/index.aspx">MR družstva</a></span></h2></div></div></div></div><h3 align="right">14 Participants&nbsp;&nbsp;</h3>
<p><div align="center">
<a href="MR_druzstva_ranking.aspx">Final Rank.</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="MR_druzstva_crossB.aspx">Basic Groups</a>&nbsp;&nbsp;
<a href="MR_druzstva_cross_1.aspx">A</a>&nbsp;&nbsp;<a href="MR_druzstva_cross_2.aspx">B</a>&nbsp;&nbsp;<a href="MR_druzstva_playoff.aspx">Play-Off</a>&nbsp;&nbsp;&nbsp;<a href="players.aspx">Players</a>&nbsp;&nbsp;&nbsp;<a href="offence.aspx">Offence</a>&nbsp;&nbsp;&nbsp;<a href="defence.aspx">Defence</a><br><br><table class="part_bck" align="center">
<tr><td><table class="part" width="100%">
<tr class="nat_head"><td class="nat_header" colspan="7"></td></tr>
<tr class="pl"><td class="name">&nbsp;<font size="+2">THC Stiga Elites</font>&nbsp;<br>Patrik Petr (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70409">8</a>), Michal Kobrle (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=660939">16</a>), Michal Boštík (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=79012">75</a>), <br>Václav Pikl (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70053">117</a>), Miloš Ševr (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70026">184</a>), Petr Tměj (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70418">1309</a>)</td>
<td class="plwr">&nbsp;11084&nbsp;</td>
<td class="bg"><a href="MR_druzstva_cross_2.aspx">B</a></td><td class="bgr">1.</td><td class="bgp">12 pts</td><td class="bgs">116:21</td><td class="fg"><a href="MR_druzstva_playoff.aspx">p-o</a></td></tr><tr class="pl"><td class="name">&nbsp;<font size="+2">Žabka Praha</font>&nbsp;<br>Jiří Chylík ml. (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=79394">35</a>), Miroslav Černoch (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70310">73</a>), Kryštof Herold (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=652033">95</a>), <br>Daniel Matýsek (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70040">119</a>), Zdeněk Matoušek ml. (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70057">210</a>), Zdeněk Matoušek st. (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70029">965</a>)</td>
<td class="plwr">&nbsp;9412&nbsp;</td>
<td class="bg"><a href="MR_druzstva_cross_1.aspx">A</a></td><td class="bgr">1.</td><td class="bgp">12 pts</td><td class="bgs">119:19</td><td class="fg"><a href="MR_druzstva_playoff.aspx">p-o</a></td></tr><tr class="pl"><td class="name">&nbsp;<font size="+2">Big Band "A"</font>&nbsp;<br>Kryštof Lebl (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=79263">51</a>), Petr Fuchs (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=668630">108</a>), Jan Dryák (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70083">142</a>), <br>Adam Kopřiva (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=669205">154</a>), Simon Thomas (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=120426">182</a>), Radek Hrnčíř (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=668860">613</a>)</td>
<td class="plwr">&nbsp;8692&nbsp;</td>
<td class="bg"><a href="MR_druzstva_cross_2.aspx">B</a></td><td class="bgr">2.</td><td class="bgp">10 pts</td><td class="bgs">102:35</td><td class="fg"><a href="MR_druzstva_playoff.aspx">p-o</a></td></tr><tr class="pl"><td class="name">&nbsp;<font size="+2">Gladiators Plzeň "A"</font>&nbsp;<br>Kuba Sládek (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70386">82</a>), Pavel Plešák (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70001">93</a>), Bjarne Axelsen (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=80004">107</a>), <br>Martin Ženíšek (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70248">122</a>), Matyáš Klazar (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=667258">132</a>), Miroslav Uhlíř (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=664431">255</a>)</td>
<td class="plwr">&nbsp;8652&nbsp;</td>
<td class="bg"><a href="MR_druzstva_cross_1.aspx">A</a></td><td class="bgr">2.</td><td class="bgp">10 pts</td><td class="bgs">99:30</td><td class="fg"><a href="MR_druzstva_playoff.aspx">p-o</a></td></tr><tr class="pl"><td class="name">&nbsp;<font size="+2">Absolut Desperation</font>&nbsp;<br>David Šmíd (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70064">123</a>), Matěj Ležík (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=79354">127</a>), Vladimír Kraus (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70004">160</a>), <br>Vojtěch Kraus (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=671458">316</a>), Zbyněk Pilař (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70024">617</a>), Stanislav Kraus (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70005">793</a>)</td>
<td class="plwr">&nbsp;7836&nbsp;</td>
<td class="bg"><a href="MR_druzstva_cross_2.aspx">B</a></td><td class="bgr">3.</td><td class="bgp">8 pts</td><td class="bgs">87:48</td><td class="fg"><a href="MR_druzstva_playoff.aspx">p-o</a></td></tr><tr class="pl"><td class="name">&nbsp;<font size="+2">THC Třinec</font>&nbsp;<br>Tomáš Waclawek (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70448">162</a>), Aleš Krejza (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=671068">176</a>), David Cibulka (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70261">218</a>), <br>Branislav Sabo (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=673525">610</a>), Roman Pavlica (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70447">614</a>)</td>
<td class="plwr">&nbsp;7103&nbsp;</td>
<td class="bg"><a href="MR_druzstva_cross_1.aspx">A</a></td><td class="bgr">3.</td><td class="bgp">8 pts</td><td class="bgs">79:51</td><td class="fg"><a href="MR_druzstva_playoff.aspx">p-o</a></td></tr><tr class="pl"><td class="name">&nbsp;<font size="+2">SHC Cheb "A"</font>&nbsp;<br>Miloslav Kubica (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70101">157</a>), Jiří Vácha (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70318">221</a>), Jiří Kropáček (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70032">311</a>), <br>Petr Holub (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=665195">387</a>), Laima Kamzola (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=654847">393</a>), Michal Mašika (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=79164">430</a>), <br>Václav Macek (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70416">557</a>)</td>
<td class="plwr">&nbsp;6650&nbsp;</td>
<td class="bg"><a href="MR_druzstva_cross_2.aspx">B</a></td><td class="bgr">4.</td><td class="bgp">6 pts</td><td class="bgs">70:62</td><td class="fg"><a href="MR_druzstva_playoff.aspx">p-o</a></td></tr><tr class="pl"><td class="name">&nbsp;<font size="+2">Stiga HC Benátky</font>&nbsp;<br>Tomáš Bucek (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70201">167</a>), Zdeněk Lopaur (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70176">203</a>), Josef Sedláček (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=656534">417</a>), <br>Jiří Malík (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=659475">945</a>), Radek Bidlo (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=664433">1168</a>)</td>
<td class="plwr">&nbsp;6431&nbsp;</td>
<td class="bg"><a href="MR_druzstva_cross_1.aspx">A</a></td><td class="bgr">4.</td><td class="bgp">6 pts</td><td class="bgs">55:77</td><td class="fg"><a href="MR_druzstva_playoff.aspx">p-o</a></td></tr><tr class="pl"><td class="name">&nbsp;<font size="+2">BSE United</font>&nbsp;<br>Tomáš Kahoun ml. (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=652518">261</a>), Michal Blažek (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=667895">335</a>), František Marek (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=651218">422</a>), <br>Tomáš Kahoun st. (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=652517">619</a>), Tibor Varga (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70354">633</a>), Ondřej Chlebo (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=670142">985</a>), <br>Aneta Pohořalá (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70496">1007</a>), Zuzana Vargová (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=676037">2786</a>)</td>
<td class="plwr">&nbsp;5617&nbsp;</td>
<td class="bg"><a href="MR_druzstva_cross_2.aspx">B</a></td><td class="bgr">5.</td><td class="bgp">4 pts</td><td class="bgs">39:101</td><td class="fg"><a href="MR_druzstva_playoff.aspx">p-o</a></td></tr><tr class="pl"><td class="name">&nbsp;<font size="+2">SHC Cheb - Veterans</font>&nbsp;<br>Stanislav Srba (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70070">294</a>), Daniel Hrachovec (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70041">414</a>), Roman Hejda (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70108">425</a>), <br>Jan Medvec (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70010">495</a>), Jaroslav Ouřada (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=667118">546</a>), Jaroslav Kopecký (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=672001">650</a>), <br>Jan Klokan (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70009">840</a>), Martin Musil (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=79104">1053</a>)</td>
<td class="plwr">&nbsp;5324&nbsp;</td>
<td class="bg"><a href="MR_druzstva_cross_2.aspx">B</a></td><td class="bgr">6.</td><td class="bgp">2 pts</td><td class="bgs">36:96</td><td class="fg"><a href="MR_druzstva_playoff.aspx">p-o</a></td></tr><tr class="pl"><td class="name">&nbsp;<font size="+2">Gladiators Plzeň "B"</font>&nbsp;<br>Hynek Nechutný (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70204">339</a>), Michal Touš (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=673514">360</a>), Jan Janouškovec (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=674879">471</a>), <br>Petr Klazar (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=667794">773</a>), Pavel Janouškovec (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=674880">1378</a>), Josef Rejzek (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=675703">2796</a>)</td>
<td class="plwr">&nbsp;5139&nbsp;</td>
<td class="bg"><a href="MR_druzstva_cross_2.aspx">B</a></td><td class="bgr">7.</td><td class="bgp">0 pts</td><td class="bgs">26:113</td><td class="fg"><a href="MR_druzstva_playoff.aspx">p-o</a></td></tr><tr class="pl"><td class="name">&nbsp;<font size="+2">SHC Vědátoři Olomouc</font>&nbsp;<br>David Dvořáček (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=656209">199</a>), Vlastimil Hejtman (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70270">540</a>), Radek Hejtman (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70271">759</a>), <br>Jan Tomáštík (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=675022">892</a>), Jonáš Andreas (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=675917">1573</a>), Radka Hrčková (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=676008">7231</a>)</td>
<td class="plwr">&nbsp;4506&nbsp;</td>
<td class="bg"><a href="MR_druzstva_cross_1.aspx">A</a></td><td class="bgr">5.</td><td class="bgp">4 pts</td><td class="bgs">49:82</td><td class="fg"><a href="MR_druzstva_playoff.aspx">p-o</a></td></tr><tr class="pl"><td class="name">&nbsp;<font size="+2">Big Band "B"</font>&nbsp;<br>Antonín Šurýn (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70018">234</a>), Jonáš Perkner (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=667720">449</a>), Daniel Kadlec (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=659624">969</a>), <br>Stanislav Suchý (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70036">1010</a>), Marie Dryáková (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=675142">1317</a>)</td>
<td class="plwr">&nbsp;4269&nbsp;</td>
<td class="bg"><a href="MR_druzstva_cross_1.aspx">A</a></td><td class="bgr">6.</td><td class="bgp">2 pts</td><td class="bgs">43:94</td><td class="fg"><a href="MR_druzstva_playoff.aspx">p-o</a></td></tr><tr class="pl"><td class="name">&nbsp;<font size="+2">SHC Lions Cheb</font>&nbsp;<br>Josef Gruncl (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70089">569</a>), Miroslava Horáková (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=665175">786</a>), Antonín Ouřada (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=673262">835</a>), <br>Lukáš Holub (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=672335">1004</a>), Jan Kubica (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=70106">1250</a>), Jiří Macek (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=670986">1404</a>), <br>Ondřej Gruncl (<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=674678">1948</a>)</td>
<td class="plwr">&nbsp;2824&nbsp;</td>
<td class="bg"><a href="MR_druzstva_cross_1.aspx">A</a></td><td class="bgr">7.</td><td class="bgp">0 pts</td><td class="bgs">25:116</td><td class="fg"><a href="MR_druzstva_playoff.aspx">p-o</a></td></tr><tr class="nat_sum"><td class="nat_sum" colspan="7">&nbsp;</td></tr></table></td></tr>
</table></div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
