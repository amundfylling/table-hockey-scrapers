<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR U13</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>MR U13, 19. květen 2024</span></h2></div></div></div></div><p><div align="center">
<div align=center>
<a href="kriz.aspx">Zápasy ve skupinách (Basic and placement groups)</a><br>
<a href="MR_U13_playoff.aspx ">Zápasy o umístění (Placement matches)</a><br>
<a href="utokturnaje.aspx">Tabulka útočníků (Best forwards)</a><br>
<a href="obranaturnaje.aspx">Tabulka obránců (Best defenders)</a>
</div>
<p class=v>Konečné pořadí turnaje (Final table)<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0 class="rnk">
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">M</th>
<th align="center">+</th>
<th align="center">=</th>
<th align="center">-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">Pts</th>
<th align="center">CZ pts</th>
<th>&nbsp;</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=2018&x=-419&p=Janou%C5%A1kovec%20Jan">Janouškovec Jan</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>10</td>
<td class=ar>10</td>
<td class=ar>0</td>
<td class=ar>0</td>
<td class=ar>37</td>
<td class=al>&nbsp;:&nbsp;14</td>
<td class=ar>20</td>
<td class=art>160</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>2.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=2053&x=-419&p=%C5%A0per%C5%88%C3%A1k%20Marek">Šperňák Marek</a></td>
<td class=bl>České Budějovice</td>
<td class=br>10</td>
<td class=br>6</td>
<td class=br>1</td>
<td class=br>3</td>
<td class=br>30</td>
<td class=bl>&nbsp;:&nbsp;17</td>
<td class=br>13</td>
<td class=brt>152</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>3.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=2128&x=-419&p=Vargov%C3%A1%20Zuzana">Vargová Zuzana</a></td>
<td class=al>BSE United</td>
<td class=ar>10</td>
<td class=ar>5</td>
<td class=ar>1</td>
<td class=ar>4</td>
<td class=ar>22</td>
<td class=al>&nbsp;:&nbsp;20</td>
<td class=ar>11</td>
<td class=art>146</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>4.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=2122&x=-419&p=Kraus%20V%C3%ADt%C4%9Bzslav">Kraus Vítězslav</a></td>
<td class=bl>Plzeň</td>
<td class=br>10</td>
<td class=br>3</td>
<td class=br>1</td>
<td class=br>6</td>
<td class=br>20</td>
<td class=bl>&nbsp;:&nbsp;24</td>
<td class=br>7</td>
<td class=brt>141</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>5.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=2027&x=-419&p=Kubrt%20Vendel%C3%ADn">Kubrt Vendelín</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>6</td>
<td class=ar>2</td>
<td class=ar>1</td>
<td class=ar>3</td>
<td class=ar>11</td>
<td class=al>&nbsp;:&nbsp;11</td>
<td class=ar>5</td>
<td class=art>137</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>6.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=2129&x=-419&p=Poho%C5%99al%C3%BD%20Anton%C3%ADn">Pohořalý Antonín</a></td>
<td class=bl>České Budějovice</td>
<td class=br>6</td>
<td class=br>1</td>
<td class=br>0</td>
<td class=br>5</td>
<td class=br>7</td>
<td class=bl>&nbsp;:&nbsp;18</td>
<td class=br>2</td>
<td class=brt>134</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>7.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=2123&x=-419&p=Krausov%C3%A1%20Zuzana">Krausová Zuzana</a></td>
<td class=al>Plzeň</td>
<td class=ar>6</td>
<td class=ar>0</td>
<td class=ar>0</td>
<td class=ar>6</td>
<td class=ar>4</td>
<td class=al>&nbsp;:&nbsp;27</td>
<td class=ar>0</td>
<td class=art>132</td>
<td class=ar>&nbsp;</td>
</tr></table></td></tr></table></div></p>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
