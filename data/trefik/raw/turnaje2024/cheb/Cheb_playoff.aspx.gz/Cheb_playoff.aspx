<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Cheb</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../cheb/index.aspx">Play-Off</a></span></h2></div></div></div></div><p><div align="center">
<table border=0 cellpadding=2 cellspacing=0>
<tr><th colspan=11 class="hh"><font size="+1"><strong>Finals</strong></font></th></tr>
<tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=409&x=-403&p=Petr%20Patrik"><b>Petr Patrik</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=1477&x=-403&p=Kobrle%20Michal">Kobrle Michal</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>7:6&nbsp;&nbsp;</td>
<td class=bl>10:5&nbsp;&nbsp;</td>
<td class=bl>7:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>1/2</strong></font></th></tr>
<tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=409&x=-403&p=Petr%20Patrik"><b>Petr Patrik</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=961&x=-403&p=Bo%C5%A1t%C3%ADk%20Michal">Boštík Michal</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>6:2&nbsp;&nbsp;</td>
<td class=al>5:2&nbsp;&nbsp;</td>
<td class=al>6:3&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=993&x=-403&p=Chyl%C3%ADk%20ml.%20Ji%C5%99%C3%AD">Chylík ml. Jiří</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=1477&x=-403&p=Kobrle%20Michal"><b>Kobrle Michal</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:3&nbsp;&nbsp;</td>
<td class=bl>6:7 P&nbsp;&nbsp;</td>
<td class=bl>5:2&nbsp;&nbsp;</td>
<td class=bl>5:1&nbsp;&nbsp;</td>
<td class=bl>2:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>1/4</strong></font></th></tr>
<tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=409&x=-403&p=Petr%20Patrik"><b>Petr Patrik</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=310&x=-403&p=%C4%8Cernoch%20Miroslav">Černoch Miroslav</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>6:2&nbsp;&nbsp;</td>
<td class=bl>6:1&nbsp;&nbsp;</td>
<td class=bl>6:0&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=961&x=-403&p=Bo%C5%A1t%C3%ADk%20Michal"><b>Boštík Michal</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=567&x=-403&p=Lebl%20Kry%C5%A1tof">Lebl Kryštof</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>4:2&nbsp;&nbsp;</td>
<td class=al>3:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=993&x=-403&p=Chyl%C3%ADk%20ml.%20Ji%C5%99%C3%AD"><b>Chylík ml. Jiří</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=40&x=-403&p=Mat%C3%BDsek%20Daniel">Matýsek Daniel</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>1:2 P&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>4:3 P&nbsp;&nbsp;</td>
<td class=bl>1:0&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=1065&x=-403&p=Herold%20Kry%C5%A1tof">Herold Kryštof</a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=1477&x=-403&p=Kobrle%20Michal"><b>Kobrle Michal</b></a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;0 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:5&nbsp;&nbsp;</td>
<td class=al>3:4 P&nbsp;&nbsp;</td>
<td class=al>2:7&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>1/8</strong></font></th></tr>
<tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=409&x=-403&p=Petr%20Patrik%20%281%29"><b>Petr Patrik (1)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=201&x=-403&p=Bucek%20Tom%C3%A1%C5%A1%20%2816%29">Bucek Tomáš (16)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>7:2&nbsp;&nbsp;</td>
<td class=bl>7:1&nbsp;&nbsp;</td>
<td class=bl>8:0&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=310&x=-403&p=%C4%8Cernoch%20Miroslav%20%288%29"><b>Černoch Miroslav (8)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=1406&x=-403&p=Mat%C3%BDsek%20Jakub%20%289%29">Matýsek Jakub (9)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>4:1&nbsp;&nbsp;</td>
<td class=al>3:2 P&nbsp;&nbsp;</td>
<td class=al>3:2 P&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=961&x=-403&p=Bo%C5%A1t%C3%ADk%20Michal%20%285%29"><b>Boštík Michal (5)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=1872&x=-403&p=Fuchs%20Petr%20%2812%29">Fuchs Petr (12)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:3&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>4:0&nbsp;&nbsp;</td>
<td class=bl>3:2 P&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=567&x=-403&p=Lebl%20Kry%C5%A1tof%20%284%29"><b>Lebl Kryštof (4)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=1641&x=-403&p=Klazar%20Maty%C3%A1%C5%A1%20%2813%29">Klazar Matyáš (13)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>5:1&nbsp;&nbsp;</td>
<td class=al>5:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=993&x=-403&p=Chyl%C3%ADk%20ml.%20Ji%C5%99%C3%AD%20%283%29"><b>Chylík ml. Jiří (3)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=1&x=-403&p=Ple%C5%A1%C3%A1k%20Pavel%20%2814%29">Plešák Pavel (14)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 2&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:5&nbsp;&nbsp;</td>
<td class=bl>4:3&nbsp;&nbsp;</td>
<td class=bl>2:1&nbsp;&nbsp;</td>
<td class=bl>2:3 P&nbsp;&nbsp;</td>
<td class=bl>5:4&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=40&x=-403&p=Mat%C3%BDsek%20Daniel%20%286%29"><b>Matýsek Daniel (6)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=248&x=-403&p=%C5%BDen%C3%AD%C5%A1ek%20Martin%20%2811%29">Ženíšek Martin (11)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 1&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>5:0&nbsp;&nbsp;</td>
<td class=al>1:2&nbsp;&nbsp;</td>
<td class=al>5:1&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=1065&x=-403&p=Herold%20Kry%C5%A1tof%20%287%29"><b>Herold Kryštof (7)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=841&x=-403&p=Le%C5%BE%C3%ADk%20Mat%C4%9Bj%20%2810%29">Ležík Matěj (10)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:1&nbsp;&nbsp;</td>
<td class=bl>1:2 P&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=1477&x=-403&p=Kobrle%20Michal%20%282%29"><b>Kobrle Michal (2)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=101&x=-403&p=Kubica%20Miloslav%20%2815%29">Kubica Miloslav (15)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>5:3&nbsp;&nbsp;</td>
<td class=al>4:3&nbsp;&nbsp;</td>
<td class=al>7:3&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>B Finals</strong></font></th></tr>
<tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=204&x=-403&p=Nechutn%C3%BD%20Hynek">Nechutný Hynek</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=26&x=-403&p=%C5%A0evr%20Milo%C5%A1"><b>Ševr Miloš</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;0 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>1:8&nbsp;&nbsp;</td>
<td class=bl>3:4 P&nbsp;&nbsp;</td>
<td class=bl>1:5&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>B 1/2</strong></font></th></tr>
<tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=204&x=-403&p=Nechutn%C3%BD%20Hynek"><b>Nechutný Hynek</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=1630&x=-403&p=Holub%20Petr">Holub Petr</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>6:4&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=318&x=-403&p=V%C3%A1cha%20Ji%C5%99%C3%AD">Vácha Jiří</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=26&x=-403&p=%C5%A0evr%20Milo%C5%A1"><b>Ševr Miloš</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:5 P&nbsp;&nbsp;</td>
<td class=bl>0:6&nbsp;&nbsp;</td>
<td class=bl>4:2&nbsp;&nbsp;</td>
<td class=bl>5:2&nbsp;&nbsp;</td>
<td class=bl>1:4&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>B 1/4</strong></font></th></tr>
<tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=70&x=-403&p=Srba%20Stanislav%20%281%29">Srba Stanislav (1)</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=204&x=-403&p=Nechutn%C3%BD%20Hynek%20%288%29"><b>Nechutný Hynek (8)</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>1:0 P&nbsp;&nbsp;</td>
<td class=bl>1:2&nbsp;&nbsp;</td>
<td class=bl>2:3 P&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>1:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=318&x=-403&p=V%C3%A1cha%20Ji%C5%99%C3%AD%20%283%29"><b>Vácha Jiří (3)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=1639&x=-403&p=Ou%C5%99ada%20Jaroslav%20%286%29">Ouřada Jaroslav (6)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>4:3&nbsp;&nbsp;</td>
<td class=al>6:3&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=26&x=-403&p=%C5%A0evr%20Milo%C5%A1%20%282%29"><b>Ševr Miloš (2)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=9&x=-403&p=Klokan%20Jan%20%287%29">Klokan Jan (7)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>5:0&nbsp;&nbsp;</td>
<td class=bl>5:2&nbsp;&nbsp;</td>
<td class=bl>5:0&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=2018&x=-403&p=Janou%C5%A1kovec%20Jan%20%284%29">Janouškovec Jan (4)</a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=1630&x=-403&p=Holub%20Petr%20%285%29"><b>Holub Petr (5)</b></a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;0 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:3 P&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>1:4&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong> Finals</strong></font></th></tr>
<tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=0&x=-403&p="></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=0&x=-403&p="><b></b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong> 1/2</strong></font></th></tr>
<tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=0&x=-403&p="></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=0&x=-403&p="><b></b></a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=0&x=-403&p="></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=0&x=-403&p="><b></b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong> 3rd - NOT PLAYED</strong></font></th></tr>
<tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=0&x=-403&p="></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=0&x=-403&p="><b></b></a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong> 1/4</strong></font></th></tr>
<tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=0&x=-403&p="></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=0&x=-403&p="><b></b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=0&x=-403&p="></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=0&x=-403&p="><b></b></a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=0&x=-403&p="></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=0&x=-403&p="><b></b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=0&x=-403&p="></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=0&x=-403&p="><b></b></a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
