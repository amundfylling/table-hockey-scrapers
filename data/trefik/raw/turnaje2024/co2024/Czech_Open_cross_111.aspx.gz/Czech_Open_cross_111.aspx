<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2024">Czech Open</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group F</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2044&x=-409&p=Ja%20Tom%C3%A1%C5%A1t%C3%ADk">Ja Tomáštík</a></td><td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>5:4</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=br>56:26</td><td class=br>+30</td>
<td class=bc>13 - 0 - 2</td>
<td class=br><strong>26</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2099&x=-409&p=Ol%20Pylypenko">Ol Pylypenko</a></td><td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>7:3</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>7:3</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=br>63:29</td><td class=br>+34</td>
<td class=bc>12 - 2 - 1</td>
<td class=br><strong>26</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=910&x=-409&p=Vl%20Gobyov%C3%A1">Vl Gobyová</a></td><td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>6:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=br>53:30</td><td class=br>+23</td>
<td class=bc>11 - 3 - 1</td>
<td class=br><strong>25</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1957&x=-409&p=Er%20Bernhauser">Er Bernhauser</a></td><td class=kL>2:4</td>
<td class=kL>3:7</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kW>7:0</td>
<td class=kW>4:2</td>
<td class=kW>10:1</td>
<td class=br>59:40</td><td class=br>+19</td>
<td class=bc>8 - 3 - 4</td>
<td class=br><strong>19</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1896&x=-409&p=Ra%20Hrn%C4%8D%C3%AD%C5%99">Ra Hrnčíř</a></td><td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kL>3:6</td>
<td class=br>39:41</td><td class=br>-2</td>
<td class=bc>7 - 3 - 5</td>
<td class=br><strong>17</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1967&x=-409&p=An%20Ou%C5%99ada">An Ouřada</a></td><td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>4:6</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=br>46:39</td><td class=br>+7</td>
<td class=bc>7 - 3 - 5</td>
<td class=br><strong>17</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2020&x=-409&p=Da%20Jerabek">Da Jerabek</a></td><td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>45:37</td><td class=br>+8</td>
<td class=bc>7 - 3 - 5</td>
<td class=br><strong>17</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2096&x=-409&p=Vo%20Kvasnikov">Vo Kvasnikov</a></td><td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>4:6</td>
<td class=kL>3:6</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kL>0:1</td>
<td class=kW>8:0</td>
<td class=kW>8:0</td>
<td class=kL>1:3</td>
<td class=kW>8:2</td>
<td class=br>57:39</td><td class=br>+18</td>
<td class=bc>6 - 3 - 6</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2095&x=-409&p=Ja%20Hansson">Ja Hansson</a></td><td class=kW>3:1</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>8:2</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=br>40:32</td><td class=br>+8</td>
<td class=bc>7 - 0 - 8</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2046&x=-409&p=Ma%20Voj%C3%A1%C4%8Dek">Ma Vojáček</a></td><td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kW>8:2</td>
<td class=br>40:44</td><td class=br>-4</td>
<td class=bc>5 - 2 - 8</td>
<td class=br><strong>12</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1970&x=-409&p=Ji%20P%C3%ADse%C4%8Dka">Ji Písečka</a></td><td class=kL>4:5</td>
<td class=kL>3:7</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kW>6:4</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kL>2:8</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=br>45:58</td><td class=br>-13</td>
<td class=bc>4 - 4 - 7</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1252&x=-409&p=Ma%20Moravec">Ma Moravec</a></td><td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kW>1:0</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>0:0</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=br>22:32</td><td class=br>-10</td>
<td class=bc>5 - 2 - 8</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1869&x=-409&p=Pe%20Klazar">Pe Klazar</a></td><td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kL>0:8</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=br>37:49</td><td class=br>-12</td>
<td class=bc>5 - 2 - 8</td>
<td class=br><strong>12</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2101&x=-409&p=Ge%20Brunner">Ge Brunner</a></td><td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>3:7</td>
<td class=kL>0:8</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=br>19:55</td><td class=br>-36</td>
<td class=bc>1 - 5 - 9</td>
<td class=br><strong>7</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2015&x=-409&p=Mo%20Tich%C3%A1">Mo Tichá</a></td><td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=br>26:53</td><td class=br>-27</td>
<td class=bc>2 - 1 - 12</td>
<td class=br><strong>5</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1626&x=-409&p=Mi%20Hor%C3%A1kov%C3%A1">Mi Horáková</a></td><td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:10</td>
<td class=kW>6:3</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>2:8</td>
<td class=kL>0:7</td>
<td class=kL>2:8</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=br>24:67</td><td class=br>-43</td>
<td class=bc>2 - 0 - 13</td>
<td class=br><strong>4</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ge Brunner</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mo Tichá</td><td class=bc>-</td><td class=blW>Ma Vojáček</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ja Tomáštík</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Ol Pylypenko</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Da Jerabek</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ji Písečka</td><td class=bc>-</td><td class=bl>Mo Tichá</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Ge Brunner</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ma Vojáček</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Moravec</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>An Ouřada</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Ja Tomáštík</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ol Pylypenko</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ji Písečka</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>Mo Tichá</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ge Brunner</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>An Ouřada</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Da Jerabek</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ja Tomáštík</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Ol Pylypenko</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ji Písečka</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ma Moravec</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Mo Tichá</td><td class=bc>-</td><td class=blW>An Ouřada</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Er Bernhauser</td><td class=bc>-</td><td class=bl>Ge Brunner</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ma Vojáček</td><td class=bc>-</td><td class=blW>Da Jerabek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>4 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ja Hansson</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ol Pylypenko</td><td class=bc>-</td><td class=blW>Ja Tomáštík</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ma Moravec</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>An Ouřada</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Er Bernhauser</td><td class=bc>1 : 10</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Da Jerabek</td><td class=bc>-</td><td class=bl>Mo Tichá</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ge Brunner</td><td class=bc>-</td><td class=blW>Vo Kvasnikov</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Ol Pylypenko</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Tomáštík</td><td class=bc>-</td><td class=blW>Ja Hansson</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ji Písečka</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Er Bernhauser</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Mo Tichá</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ol Pylypenko</td><td class=bc>-</td><td class=bl>Ge Brunner</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ma Vojáček</td><td class=bc>-</td><td class=blW>Ja Tomáštík</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Er Bernhauser</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Da Jerabek</td><td class=bc>-</td><td class=blW>An Ouřada</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ma Moravec</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ol Pylypenko</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ja Tomáštík</td><td class=bc>-</td><td class=bl>Mo Tichá</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ge Brunner</td><td class=bc>-</td><td class=blW>Ja Hansson</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=blW>Er Bernhauser</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ol Pylypenko</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ja Tomáštík</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ja Hansson</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Mo Tichá</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ma Vojáček</td><td class=bc>-</td><td class=blW>Ge Brunner</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Ol Pylypenko</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Ja Tomáštík</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Moravec</td><td class=bc>-</td><td class=blW>Ja Hansson</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ma Vojáček</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Ge Brunner</td><td class=bc>-</td><td class=bl>Mo Tichá</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ol Pylypenko</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Da Jerabek</td><td class=bc>-</td><td class=blW>Ja Tomáštík</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Er Bernhauser</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ma Vojáček</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=bl>Ge Brunner</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mo Tichá</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ol Pylypenko</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Ja Tomáštík</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Er Bernhauser</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ge Brunner</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Moravec</td><td class=bc>-</td><td class=bl>Mo Tichá</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=blW>Ja Tomáštík</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Ol Pylypenko</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Vojáček</td><td class=bc>-</td><td class=blW>Vo Kvasnikov</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Da Jerabek</td><td class=bc>-</td><td class=bl>Ge Brunner</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Mo Tichá</td><td class=bc>-</td><td class=blW>Er Bernhauser</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>An Ouřada</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ma Moravec</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ja Hansson</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Ja Tomáštík</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ol Pylypenko</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ge Brunner</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=blW>Mo Tichá</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Da Jerabek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Moravec</td><td class=bc>-</td><td class=blW>An Ouřada</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=brW>Ma Vojáček</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ja Tomáštík</td><td class=bc>-</td><td class=bl>Ge Brunner</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Mo Tichá</td><td class=bc>-</td><td class=blW>Ol Pylypenko</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Vo Kvasnikov</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=brW>Da Jerabek</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ma Vojáček</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ge Brunner</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ja Hansson</td><td class=bc>-</td><td class=bl>Mo Tichá</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ja Tomáštík</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ol Pylypenko</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ma Moravec</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>3 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
