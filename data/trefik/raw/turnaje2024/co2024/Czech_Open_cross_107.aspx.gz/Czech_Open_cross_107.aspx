<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2024">Czech Open</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group D</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=320&x=-409&p=To%20Hudec">To Hudec</a></td><td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kW>6:0</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0 K</td>
<td class=kL>3:4</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=br>51:23</td><td class=br>+28</td>
<td class=bc>11 - 1 - 3</td>
<td class=br><strong>23</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=447&x=-409&p=Ro%20Pavlica">Ro Pavlica</a></td><td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kT>5:5</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kL>5:6</td>
<td class=kL>2:6</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>7:3</td>
<td class=kW>7:3</td>
<td class=br>63:39</td><td class=br>+24</td>
<td class=bc>10 - 2 - 3</td>
<td class=br><strong>22</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=319&x=-409&p=Ka%20Hudec">Ka Hudec</a></td><td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=br>39:27</td><td class=br>+12</td>
<td class=bc>7 - 6 - 2</td>
<td class=br><strong>20</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1657&x=-409&p=Jo%20Perkner">Jo Perkner</a></td><td class=kW>3:0</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=br>40:28</td><td class=br>+12</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1527&x=-409&p=Mi%20Mitro%20ml.">Mi Mitro ml.</a></td><td class=kW>3:2</td>
<td class=kT>5:5</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kW>6:2</td>
<td class=br>44:37</td><td class=br>+7</td>
<td class=bc>6 - 5 - 4</td>
<td class=br><strong>17</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1173&x=-409&p=Jo%20Mal%C3%BD">Jo Malý</a></td><td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kW>8:2</td>
<td class=kL>1:3</td>
<td class=br>40:34</td><td class=br>+6</td>
<td class=bc>7 - 3 - 5</td>
<td class=br><strong>17</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1599&x=-409&p=Mi%20Uhl%C3%AD%C5%99">Mi Uhlíř</a></td><td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kW>7:4</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=br>49:45</td><td class=br>+4</td>
<td class=bc>7 - 2 - 6</td>
<td class=br><strong>16</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=204&x=-409&p=Hy%20Nechutn%C3%BD">Hy Nechutný</a></td><td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kL>0:5</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kW>4:1</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=br>28:33</td><td class=br>-5</td>
<td class=bc>7 - 1 - 7</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=41&x=-409&p=Da%20Hrachovec">Da Hrachovec</a></td><td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=br>37:36</td><td class=br>+1</td>
<td class=bc>6 - 3 - 6</td>
<td class=br><strong>15</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1968&x=-409&p=Mi%20Tou%C5%A1">Mi Touš</a></td><td class=kL>2:3</td>
<td class=kW>6:5</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>4:7</td>
<td class=kW>5:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>3:6</td>
<td class=kW>3:1</td>
<td class=kW>6:4</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=br>50:52</td><td class=br>-2</td>
<td class=bc>7 - 1 - 7</td>
<td class=br><strong>15</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1291&x=-409&p=Ma%20Dion">Ma Dion</a></td><td class=kL>1:3</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=br>44:46</td><td class=br>-2</td>
<td class=bc>5 - 3 - 7</td>
<td class=br><strong>13</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1746&x=-409&p=An%20Gripp">An Gripp</a></td><td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>6:3</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=br>35:47</td><td class=br>-12</td>
<td class=bc>4 - 4 - 7</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=108&x=-409&p=Ro%20Hejda">Ro Hejda</a></td><td class=kL>0:5 K</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=br>30:49</td><td class=br>-19</td>
<td class=bc>4 - 3 - 8</td>
<td class=br><strong>11</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2014&x=-409&p=Ma%20Hlava%C4%8Dka">Ma Hlavačka</a></td><td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>4:6</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=br>34:43</td><td class=br>-9</td>
<td class=bc>4 - 2 - 9</td>
<td class=br><strong>10</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1318&x=-409&p=Jo%20Sedl%C3%A1%C4%8Dek">Jo Sedláček</a></td><td class=kL>1:6</td>
<td class=kL>3:7</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kW>2:0</td>
<td class=kL>2:8</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=br>35:57</td><td class=br>-22</td>
<td class=bc>4 - 1 - 10</td>
<td class=br><strong>9</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1917&x=-409&p=Fr%20Rasche">Fr Rasche</a></td><td class=kL>0:3</td>
<td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kL>3:6</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=br>33:56</td><td class=br>-23</td>
<td class=bc>2 - 3 - 10</td>
<td class=br><strong>7</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>An Gripp</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Mi Mitro ml.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Dion</td><td class=bc>-</td><td class=blW>Mi Touš</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Ro Pavlica</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ro Hejda</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>An Gripp</td><td class=bc>-</td><td class=blW>To Hudec</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ro Pavlica</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ma Hlavačka</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>To Hudec</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Fr Rasche</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Mi Mitro ml.</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ma Dion</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ro Pavlica</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>An Gripp</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Mi Touš</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Mi Mitro ml.</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro Pavlica</td><td class=bc>-</td><td class=blW>Ma Dion</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>An Gripp</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>To Hudec</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>Ro Pavlica</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Dion</td><td class=bc>-</td><td class=bl>Mi Mitro ml.</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>An Gripp</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=blW>Mi Touš</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ma Hlavačka</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ro Pavlica</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>Ma Dion</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ro Hejda</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Mi Touš</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Ro Pavlica</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ma Dion</td><td class=bc>-</td><td class=blW>To Hudec</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Mi Mitro ml.</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Gripp</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Ro Hejda</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ro Pavlica</td><td class=bc>-</td><td class=blW>Mi Touš</td><td class=bc>5 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mi Mitro ml.</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>To Hudec</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=blW>Ro Pavlica</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Dion</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=bl>Mi Mitro ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>An Gripp</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ro Pavlica</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>Mi Touš</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ro Pavlica</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ma Dion</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Mi Mitro ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>To Hudec</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>An Gripp</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>Ro Pavlica</td><td class=bc>5 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>Ma Hlavačka</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>8 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ro Pavlica</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>Ma Hlavačka</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Gripp</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>Mi Mitro ml.</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ma Dion</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Ro Pavlica</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Ro Hejda</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Fr Rasche</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Ma Dion</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ro Pavlica</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Touš</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>3 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
