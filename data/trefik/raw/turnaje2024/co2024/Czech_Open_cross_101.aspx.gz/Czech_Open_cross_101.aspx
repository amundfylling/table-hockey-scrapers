<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2024">Czech Open</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group A1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>25</td>
<td class=ic>26</td>
<td class=ic>27</td>
<td class=ic>28</td>
<td class=ic>29</td>
<td class=ic>30</td>
<td class=ic>31</td>
<td class=ic>32</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1838&x=-409&p=Ev%20Matantsev">Ev Matantsev</a></td><td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kW>4:1 K</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kL>4:5 K</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>8:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2 K</td>
<td class=kL>2:5</td>
<td class=kW>9:2</td>
<td class=kW>4:2</td>
<td class=kW>8:3</td>
<td class=kW>5:4 K</td>
<td class=kW>4:1</td>
<td class=kW>2:0 K</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kW>3:2 K</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=kT>5:5 K</td>
<td class=kW>6:2</td>
<td class=br>130:70</td><td class=br>+60</td>
<td class=bc>23 - 4 - 4</td>
<td class=br><strong>50</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1648&x=-409&p=Sa%20Lagzdins">Sa Lagzdins</a></td><td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>5:3 K</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kW>6:1 K</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kL>3:4 K</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kL>0:1</td>
<td class=kW>6:2 K</td>
<td class=kW>3:2 K</td>
<td class=kT>2:2</td>
<td class=kW>2:0 K</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kL>2:3</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>6:5</td>
<td class=kW>10:1</td>
<td class=br>116:59</td><td class=br>+57</td>
<td class=bc>22 - 3 - 6</td>
<td class=br><strong>47</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2024&x=-409&p=Em%20Liepins">Em Liepins</a></td><td class=kL>3:5</td>
<td class=kL>3:5 K</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kW>6:2</td>
<td class=kW>4:1 K</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>2:1 K</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>3:7</td>
<td class=kW>6:3 K</td>
<td class=kW>2:1 K</td>
<td class=kW>2:1</td>
<td class=kW>5:3 K</td>
<td class=kL>2:4</td>
<td class=kW>6:4</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kW>5:1 K</td>
<td class=kL>2:3</td>
<td class=kW>6:0</td>
<td class=kW>6:3</td>
<td class=kW>9:1</td>
<td class=kW>6:1</td>
<td class=br>125:74</td><td class=br>+51</td>
<td class=bc>21 - 2 - 8</td>
<td class=br><strong>44</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2111&x=-409&p=Ru%20Kamzols">Ru Kamzols</a></td><td class=kL>1:4 K</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kW>6:2 K</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>5:3 K</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>3:2 K</td>
<td class=kW>5:3</td>
<td class=kW>4:0 K</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=kW>3:2</td>
<td class=kW>4:1 K</td>
<td class=kL>2:6</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>6:3 K</td>
<td class=kW>8:3</td>
<td class=br>118:78</td><td class=br>+40</td>
<td class=bc>21 - 2 - 8</td>
<td class=br><strong>44</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2074&x=-409&p=Ma%20Jakseboga">Ma Jakseboga</a></td><td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kT>1:1 K</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kT>0:0</td>
<td class=kW>4:2 K</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kW>3:0 K</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>4:7</td>
<td class=kW>7:1 K</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>6:0 K</td>
<td class=kW>4:3</td>
<td class=kT>3:3 K</td>
<td class=kW>3:0</td>
<td class=kW>2:0 K</td>
<td class=br>94:61</td><td class=br>+33</td>
<td class=bc>16 - 9 - 6</td>
<td class=br><strong>41</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1649&x=-409&p=Ra%20Miglinieks">Ra Miglinieks</a></td><td class=kL>2:4</td>
<td class=kW>6:1</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kT>1:1 K</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kL>3:4 K</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kT>1:1 K</td>
<td class=kW>4:1</td>
<td class=kT>5:5</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>4:2 K</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>6:2 K</td>
<td class=kW>3:2</td>
<td class=kT>3:3 K</td>
<td class=kW>3:2</td>
<td class=kW>4:1 K</td>
<td class=br>93:72</td><td class=br>+21</td>
<td class=bc>14 - 9 - 8</td>
<td class=br><strong>37</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=993&x=-409&p=Ji%20Chyl%C3%ADk%20ml.">Ji Chylík ml.</a></td><td class=kW>3:1</td>
<td class=kL>1:6 K</td>
<td class=kL>1:4 K</td>
<td class=kL>4:5</td>
<td class=kW>4:1</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kW>1:0 K</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1 K</td>
<td class=kL>2:5 K</td>
<td class=kL>0:5</td>
<td class=kW>5:1 K</td>
<td class=kL>4:6</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>7:3</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kT>2:2 K</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=br>96:78</td><td class=br>+18</td>
<td class=bc>15 - 7 - 9</td>
<td class=br><strong>37</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2085&x=-409&p=He%20Prokuratovs">He Prokuratovs</a></td><td class=kW>5:4 K</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>2:6 K</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kW>5:0</td>
<td class=kT>3:3 K</td>
<td class=kW>1:0</td>
<td class=kL>2:6</td>
<td class=kW>4:1</td>
<td class=kL>3:7</td>
<td class=kW>4:1 K</td>
<td class=kW>5:2</td>
<td class=kL>1:4 K</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kW>5:2</td>
<td class=kW>2:1 K</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kW>3:1 K</td>
<td class=kW>5:2</td>
<td class=br>97:89</td><td class=br>+8</td>
<td class=bc>17 - 3 - 11</td>
<td class=br><strong>37</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2081&x=-409&p=Je%20Rekis">Je Rekis</a></td><td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>3:2 K</td>
<td class=kT>4:4 K</td>
<td class=kT>3:3</td>
<td class=kW>10:1 K</td>
<td class=kW>4:1</td>
<td class=kW>8:4</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>4:5 K</td>
<td class=kL>2:3</td>
<td class=kW>6:1 K</td>
<td class=kW>5:1 K</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kW>4:3 K</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=br>104:81</td><td class=br>+23</td>
<td class=bc>14 - 7 - 10</td>
<td class=br><strong>35</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1826&x=-409&p=Ol%20Blume">Ol Blume</a></td><td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kL>2:3 K</td>
<td class=kx>*</td>
<td class=kT>3:3 K</td>
<td class=kW>4:0</td>
<td class=kW>3:2 K</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>5:4</td>
<td class=kW>5:4</td>
<td class=kW>4:3 K</td>
<td class=kL>2:3</td>
<td class=kL>1:3 K</td>
<td class=kL>1:7 K</td>
<td class=kW>7:3</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kT>1:1 K</td>
<td class=kL>0:4</td>
<td class=kW>5:2</td>
<td class=kT>5:5</td>
<td class=br>96:85</td><td class=br>+11</td>
<td class=bc>16 - 3 - 12</td>
<td class=br><strong>35</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1872&x=-409&p=Pe%20Fuchs">Pe Fuchs</a></td><td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kL>2:4</td>
<td class=kT>4:4 K</td>
<td class=kT>3:3 K</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>9:3 K</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kW>2:0 K</td>
<td class=kW>6:4</td>
<td class=kW>5:2 K</td>
<td class=kL>1:5 K</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kT>3:3 K</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=br>97:86</td><td class=br>+11</td>
<td class=bc>14 - 7 - 10</td>
<td class=br><strong>35</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1406&x=-409&p=Ja%20Mat%C3%BDsek">Ja Matýsek</a></td><td class=kL>1:8</td>
<td class=kW>4:3 K</td>
<td class=kL>1:2 K</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>0:1 K</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>3:0 K</td>
<td class=kW>3:1 K</td>
<td class=kW>2:0</td>
<td class=kL>1:5 K</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3 K</td>
<td class=kW>6:2</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=br>70:68</td><td class=br>+2</td>
<td class=bc>14 - 7 - 10</td>
<td class=br><strong>35</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1766&x=-409&p=Al%20Silin%C5%A1">Al Silinš</a></td><td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kT>4:4</td>
<td class=kL>1:7</td>
<td class=kT>4:4</td>
<td class=kL>1:10 K</td>
<td class=kL>2:3 K</td>
<td class=kL>3:9 K</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>7:3</td>
<td class=kW>7:3</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kW>5:1 K</td>
<td class=kL>0:5</td>
<td class=kT>2:2 K</td>
<td class=kW>4:2 K</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kW>6:1 K</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=br>89:90</td><td class=br>-1</td>
<td class=bc>14 - 6 - 11</td>
<td class=br><strong>34</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1153&x=-409&p=Ot%20Pesala">Ot Pesala</a></td><td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>2:4 K</td>
<td class=kW>4:3 K</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>4:1 K</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kL>0:3 K</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kT>2:2 K</td>
<td class=kW>3:2</td>
<td class=kL>3:4 K</td>
<td class=kW>3:0</td>
<td class=kW>2:0 K</td>
<td class=br>71:73</td><td class=br>-2</td>
<td class=bc>13 - 7 - 11</td>
<td class=br><strong>33</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2076&x=-409&p=Ed%20Naglis">Ed Naglis</a></td><td class=kL>2:3 K</td>
<td class=kW>1:0</td>
<td class=kW>7:3</td>
<td class=kL>3:5 K</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3 K</td>
<td class=kL>4:8</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>3:4 K</td>
<td class=kL>2:3</td>
<td class=kT>2:2 K</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>5:2 K</td>
<td class=kW>6:1</td>
<td class=kL>4:5</td>
<td class=kW>5:0</td>
<td class=kL>1:3</td>
<td class=kW>8:0 K</td>
<td class=kW>5:3</td>
<td class=br>102:83</td><td class=br>+19</td>
<td class=bc>14 - 4 - 13</td>
<td class=br><strong>32</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1786&x=-409&p=Am%20Fylling">Am Fylling</a></td><td class=kW>5:2</td>
<td class=kL>2:6 K</td>
<td class=kL>3:6 K</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1 K</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kL>0:3 K</td>
<td class=kL>3:7</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>6:1 K</td>
<td class=kW>5:2</td>
<td class=kT>2:2 K</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kW>5:1 K</td>
<td class=kW>6:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=br>84:90</td><td class=br>-6</td>
<td class=bc>12 - 6 - 13</td>
<td class=br><strong>30</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=961&x=-409&p=Mi%20Bo%C5%A1t%C3%ADk">Mi Boštík</a></td><td class=kL>2:9</td>
<td class=kL>2:3 K</td>
<td class=kL>1:2 K</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kW>5:2 K</td>
<td class=kW>6:2</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kW>4:3</td>
<td class=kL>1:3 K</td>
<td class=kL>3:7</td>
<td class=kL>0:1</td>
<td class=kL>3:5</td>
<td class=kL>1:6 K</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>4:3 K</td>
<td class=kT>5:5</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kW>6:4</td>
<td class=kL>1:6</td>
<td class=kT>3:3 K</td>
<td class=kT>3:3</td>
<td class=kT>5:5</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=br>89:105</td><td class=br>-16</td>
<td class=bc>13 - 4 - 14</td>
<td class=br><strong>30</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2077&x=-409&p=Pe%20Miettinen">Pe Miettinen</a></td><td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>0:3 K</td>
<td class=kT>1:1 K</td>
<td class=kW>5:0</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>1:4 K</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>5:4</td>
<td class=kW>6:2 K</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>3:4 K</td>
<td class=kT>3:3</td>
<td class=kW>5:2 K</td>
<td class=kW>5:0</td>
<td class=kW>3:1 K</td>
<td class=br>80:81</td><td class=br>-1</td>
<td class=bc>11 - 8 - 12</td>
<td class=br><strong>30</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1203&x=-409&p=Da%20Mitro">Da Mitro</a></td><td class=kL>3:8</td>
<td class=kL>0:2 K</td>
<td class=kL>3:5 K</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>1:5 K</td>
<td class=kW>7:3</td>
<td class=kW>4:1</td>
<td class=kL>4:5</td>
<td class=kT>4:4</td>
<td class=kW>5:1 K</td>
<td class=kW>3:0</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2 K</td>
<td class=kL>3:4 K</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>7:0</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>5:1 K</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=br>86:83</td><td class=br>+3</td>
<td class=bc>13 - 4 - 14</td>
<td class=br><strong>30</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1770&x=-409&p=Gi%20Lasmanis">Gi Lasmanis</a></td><td class=kL>4:5 K</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kL>2:3 K</td>
<td class=kT>3:3</td>
<td class=kT>5:5</td>
<td class=kW>6:4</td>
<td class=kL>1:4 K</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kL>2:6</td>
<td class=kW>4:3 K</td>
<td class=kL>2:5</td>
<td class=kT>5:5</td>
<td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>4:4 K</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>6:0</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>5:1 K</td>
<td class=kL>1:6</td>
<td class=br>100:98</td><td class=br>+2</td>
<td class=bc>11 - 8 - 12</td>
<td class=br><strong>30</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2079&x=-409&p=Di%20Ziemelis">Di Ziemelis</a></td><td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>4:6</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kW>5:4 K</td>
<td class=kL>3:4 K</td>
<td class=kL>0:2 K</td>
<td class=kL>1:2</td>
<td class=kL>1:5 K</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>5:2 K</td>
<td class=kT>3:3 K</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>6:0</td>
<td class=kW>1:0</td>
<td class=kL>0:2 K</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=br>83:88</td><td class=br>-5</td>
<td class=bc>12 - 4 - 15</td>
<td class=br><strong>28</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1844&x=-409&p=Ha%20Ivantsova">Ha Ivantsova</a></td><td class=kL>0:2 K</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>0:4 K</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kL>2:5</td>
<td class=kW>4:1 K</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>4:6</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kT>4:4 K</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>4:5</td>
<td class=kW>4:0</td>
<td class=kL>1:3 K</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>4:3 K</td>
<td class=kW>7:2</td>
<td class=br>73:80</td><td class=br>-7</td>
<td class=bc>12 - 4 - 15</td>
<td class=br><strong>28</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1876&x=-409&p=Ad%20Kop%C5%99iva">Ad Kopřiva</a></td><td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kL>1:6 K</td>
<td class=kW>3:1 K</td>
<td class=kL>2:5 K</td>
<td class=kL>0:1</td>
<td class=kT>2:2 K</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>3:6</td>
<td class=kL>0:7</td>
<td class=kW>3:2</td>
<td class=kL>2:5 K</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>6:2 K</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kW>6:0</td>
<td class=kW>3:1 K</td>
<td class=kW>4:3</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=br>68:91</td><td class=br>-23</td>
<td class=bc>12 - 4 - 15</td>
<td class=br><strong>28</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1650&x=-409&p=Va%20Dietze">Va Dietze</a></td><td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>4:5</td>
<td class=kW>7:4</td>
<td class=kT>4:4</td>
<td class=kL>3:7</td>
<td class=kW>5:3</td>
<td class=kL>1:5 K</td>
<td class=kW>7:1 K</td>
<td class=kW>5:1 K</td>
<td class=kT>1:1</td>
<td class=kL>2:4 K</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kT>3:3 K</td>
<td class=kW>5:4</td>
<td class=kL>2:6 K</td>
<td class=kx>*</td>
<td class=kW>8:1</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kW>5:2</td>
<td class=kL>3:5 K</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=br>104:109</td><td class=br>-5</td>
<td class=bc>10 - 5 - 16</td>
<td class=br><strong>25</strong></td><td class=d>24.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>25.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1976&x=-409&p=Jo%20Astrom">Jo Astrom</a></td><td class=kT>4:4</td>
<td class=kL>0:7</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>1:7 K</td>
<td class=kL>2:4 K</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kL>3:7</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>3:0 K</td>
<td class=kT>4:4</td>
<td class=kW>6:3</td>
<td class=kL>4:6</td>
<td class=kL>2:6 K</td>
<td class=kL>3:5</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kW>3:1</td>
<td class=kL>1:8</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2 K</td>
<td class=kL>2:4</td>
<td class=kW>5:2 K</td>
<td class=kW>3:1</td>
<td class=kT>2:2 K</td>
<td class=br>79:113</td><td class=br>-34</td>
<td class=bc>10 - 5 - 16</td>
<td class=br><strong>25</strong></td><td class=d>25.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>26.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1641&x=-409&p=Ma%20Klazar">Ma Klazar</a></td><td class=kL>2:3 K</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kL>1:4 K</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>1:2 K</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>2:5 K</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2 K</td>
<td class=kL>3:5</td>
<td class=kW>3:1 K</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1 K</td>
<td class=kL>2:3</td>
<td class=br>68:80</td><td class=br>-12</td>
<td class=bc>9 - 6 - 16</td>
<td class=br><strong>24</strong></td><td class=d>26.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>27.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=40&x=-409&p=Da%20Mat%C3%BDsek">Da Matýsek</a></td><td class=kL>3:6</td>
<td class=kT>2:2 K</td>
<td class=kL>1:5 K</td>
<td class=kW>6:2</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kT>2:2 K</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kT>3:3 K</td>
<td class=kW>4:0</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>1:5 K</td>
<td class=kT>3:3 K</td>
<td class=kT>1:1</td>
<td class=kL>1:5 K</td>
<td class=kT>1:1</td>
<td class=kL>0:6</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kL>3:5</td>
<td class=br>61:96</td><td class=br>-35</td>
<td class=bc>7 - 9 - 15</td>
<td class=br><strong>23</strong></td><td class=d>27.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>28.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2083&x=-409&p=Da%20Nygard">Da Nygard</a></td><td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>0:6 K</td>
<td class=kL>2:6 K</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kT>2:2 K</td>
<td class=kW>5:4</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kW>4:3 K</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kT>2:2 K</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kT>0:0 K</td>
<td class=kT>3:3</td>
<td class=kT>2:2 K</td>
<td class=br>63:107</td><td class=br>-44</td>
<td class=bc>6 - 8 - 17</td>
<td class=br><strong>20</strong></td><td class=d>28.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>29.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1764&x=-409&p=Sa%20Kalnin%C5%A1">Sa Kalninš</a></td><td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>3:4 K</td>
<td class=kT>1:1 K</td>
<td class=kT>3:3 K</td>
<td class=kL>0:1</td>
<td class=kL>1:6 K</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kW>3:1</td>
<td class=kT>5:5</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kW>2:0 K</td>
<td class=kL>2:3</td>
<td class=kL>1:3 K</td>
<td class=kW>5:3 K</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=br>64:99</td><td class=br>-35</td>
<td class=bc>7 - 5 - 19</td>
<td class=br><strong>19</strong></td><td class=d>29.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>30.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1194&x=-409&p=He%20Steen">He Steen</a></td><td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kT>3:3 K</td>
<td class=kT>3:3 K</td>
<td class=kL>3:6</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kW>4:3 K</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>2:5 K</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>2:5 K</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kT>0:0 K</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>1:3 K</td>
<td class=br>63:89</td><td class=br>-26</td>
<td class=bc>7 - 5 - 19</td>
<td class=br><strong>19</strong></td><td class=d>30.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>31.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1845&x=-409&p=My%20Shalomayev">My Shalomayev</a></td><td class=kT>5:5 K</td>
<td class=kL>5:6</td>
<td class=kL>1:9</td>
<td class=kL>3:6 K</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3 K</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kL>0:3</td>
<td class=kL>0:8 K</td>
<td class=kL>1:3</td>
<td class=kW>6:2</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kL>1:5 K</td>
<td class=kT>1:1</td>
<td class=kL>3:4 K</td>
<td class=kL>0:1</td>
<td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kL>1:3 K</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=br>55:107</td><td class=br>-52</td>
<td class=bc>5 - 4 - 22</td>
<td class=br><strong>14</strong></td><td class=d>31.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>32.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2104&x=-409&p=Ro%20Kerns">Ro Kerns</a></td><td class=kL>2:6</td>
<td class=kL>1:10</td>
<td class=kL>1:6</td>
<td class=kL>3:8</td>
<td class=kL>0:2 K</td>
<td class=kL>1:4 K</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kT>5:5</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>0:2 K</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>1:3 K</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kT>2:2 K</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2</td>
<td class=kW>3:1 K</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=br>65:120</td><td class=br>-55</td>
<td class=bc>4 - 5 - 22</td>
<td class=br><strong>13</strong></td><td class=d>32.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ru Kamzols</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=blW>Pe Miettinen</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>He Steen</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ot Pesala</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Da Nygard</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Em Liepins</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Al Silinš</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Ol Blume</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Pe Miettinen</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ru Kamzols</td><td class=bc>-</td><td class=bl>He Steen</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=blW>Ot Pesala</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Da Nygard</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Al Silinš</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Ol Blume</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Je Rekis</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=blW>Pe Miettinen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>He Steen</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ot Pesala</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ru Kamzols</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=blW>Da Nygard</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Ol Blume</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Al Silinš</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>He Steen</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Ot Pesala</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Da Nygard</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ru Kamzols</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Pe Miettinen</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Ol Blume</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Al Silinš</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Da Nygard</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ru Kamzols</td><td class=bc>-</td><td class=blW>Pe Miettinen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=bl>He Steen</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ot Pesala</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Em Liepins</td><td class=bc>-</td><td class=blW>Al Silinš</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Ol Blume</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Da Nygard</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Pe Miettinen</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>He Steen</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ru Kamzols</td><td class=bc>-</td><td class=bl>Ot Pesala</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Sa Kalninš</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Al Silinš</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Ol Blume</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Pe Miettinen</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=blW>He Steen</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ot Pesala</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ru Kamzols</td><td class=bc>-</td><td class=bl>Da Nygard</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Je Rekis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Al Silinš</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ol Blume</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ru Kamzols</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Pe Miettinen</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>He Steen</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Ot Pesala</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=bl>Da Nygard</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Al Silinš</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Ol Blume</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Sa Kalninš</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Em Liepins</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Sa Lagzdins</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ot Pesala</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Je Rekis</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Silinš</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ol Blume</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Sa Lagzdins</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pe Miettinen</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>He Steen</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ot Pesala</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Da Nygard</td><td class=bc>-</td><td class=bl>Em Liepins</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Je Rekis</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Silinš</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ol Blume</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ot Pesala</td><td class=bc>-</td><td class=bl>Em Liepins</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=blW>Sa Lagzdins</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Sa Kalninš</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Je Rekis</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Al Silinš</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ol Blume</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=blW>Em Liepins</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Sa Lagzdins</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ot Pesala</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Je Rekis</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Silinš</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ol Blume</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ot Pesala</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Em Liepins</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Sa Lagzdins</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ol Blume</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Je Rekis</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Silinš</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ot Pesala</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Em Liepins</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=blW>Sa Lagzdins</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pe Miettinen</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ol Blume</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Je Rekis</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Al Silinš</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Em Liepins</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ot Pesala</td><td class=bc>-</td><td class=blW>Sa Lagzdins</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ol Blume</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Je Rekis</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Al Silinš</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Em Liepins</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=bl>Sa Lagzdins</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ot Pesala</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Al Silinš</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ol Blume</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Je Rekis</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Em Liepins</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Sa Lagzdins</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Al Silinš</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ot Pesala</td><td class=bc>-</td><td class=blW>Ol Blume</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Da Nygard</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Em Liepins</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Sa Lagzdins</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Al Silinš</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=blW>Ol Blume</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ot Pesala</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=blW>Je Rekis</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Sa Lagzdins</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ol Blume</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ot Pesala</td><td class=bc>-</td><td class=blW>Je Rekis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=blW>Al Silinš</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=blW>Ol Blume</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Al Silinš</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ot Pesala</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Sa Lagzdins</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ot Pesala</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=blW>Sa Kalninš</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Je Rekis</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Al Silinš</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pe Miettinen</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>He Steen</td><td class=bc>-</td><td class=bl>Ol Blume</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Em Liepins</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Sa Kalninš</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ot Pesala</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=blW>Al Silinš</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Ol Blume</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pe Miettinen</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>He Steen</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ot Pesala</td><td class=bc>-</td><td class=blW>Al Silinš</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Ol Blume</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>26</td></tr>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=bl>Al Silinš</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ot Pesala</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=blW>Ol Blume</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>3 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
