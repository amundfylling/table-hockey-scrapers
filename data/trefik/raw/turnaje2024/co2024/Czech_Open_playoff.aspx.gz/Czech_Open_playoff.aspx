<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2024/index.aspx">Play-Off</a></span></h2></div></div></div></div><p><div align="center">
<table border=0 cellpadding=2 cellspacing=0>
<tr><th colspan=11 class="hh"><font size="+1"><strong>Finals</strong></font></th></tr>
<tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=1838&x=-409&p=Matantsev%20Evgeniy">Matantsev Evgeniy</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=1761&x=-409&p=Kalnin%C5%A1%20Rainers"><b>Kalninš Rainers</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;1 : 4&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>3:4 P&nbsp;&nbsp;</td>
<td class=bl>1:3&nbsp;&nbsp;</td>
<td class=bl>1:6&nbsp;&nbsp;</td>
<td class=bl>2:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>1/2</strong></font></th></tr>
<tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=1838&x=-409&p=Matantsev%20Evgeniy"><b>Matantsev Evgeniy</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=1518&x=-409&p=Korabel%20Oleksii">Korabel Oleksii</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 1&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>7:5&nbsp;&nbsp;</td>
<td class=al>0:7&nbsp;&nbsp;</td>
<td class=al>4:3&nbsp;&nbsp;</td>
<td class=al>4:3&nbsp;&nbsp;</td>
<td class=al>5:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=1649&x=-409&p=Miglinieks%20Raivis">Miglinieks Raivis</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=1761&x=-409&p=Kalnin%C5%A1%20Rainers"><b>Kalninš Rainers</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 4&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:2 P&nbsp;&nbsp;</td>
<td class=bl>2:5&nbsp;&nbsp;</td>
<td class=bl>0:3&nbsp;&nbsp;</td>
<td class=bl>3:4&nbsp;&nbsp;</td>
<td class=bl>2:1 P&nbsp;&nbsp;</td>
<td class=bl>1:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>3rd</strong></font></th></tr>
<tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=1518&x=-409&p=Korabel%20Oleksii">Korabel Oleksii</a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=1649&x=-409&p=Miglinieks%20Raivis"><b>Miglinieks Raivis</b></a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;0 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>3:6&nbsp;&nbsp;</td>
<td class=al>3:4&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>1/4</strong></font></th></tr>
<tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=1838&x=-409&p=Matantsev%20Evgeniy"><b>Matantsev Evgeniy</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=1784&x=-409&p=Klippen%20Magnus">Klippen Magnus</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>5:4&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>4:3 P&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=1503&x=-409&p=Huotelin%20Vesa">Huotelin Vesa</a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=1518&x=-409&p=Korabel%20Oleksii"><b>Korabel Oleksii</b></a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;0 : 4&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>2:6&nbsp;&nbsp;</td>
<td class=al>1:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=1826&x=-409&p=Blume%20Olof">Blume Olof</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=1649&x=-409&p=Miglinieks%20Raivis"><b>Miglinieks Raivis</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 4&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>1:2&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>1:4&nbsp;&nbsp;</td>
<td class=bl>2:1 P&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>1:4&nbsp;&nbsp;</td>
<td class=bl>1:3&nbsp;&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=2111&x=-409&p=Kamzols%20Rudolfs">Kamzols Rudolfs</a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=1761&x=-409&p=Kalnin%C5%A1%20Rainers"><b>Kalninš Rainers</b></a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;1 : 4&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:5&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>4:6&nbsp;&nbsp;</td>
<td class=al>1:4&nbsp;&nbsp;</td>
<td class=al>0:3&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>1/8</strong></font></th></tr>
<tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=1838&x=-409&p=Matantsev%20Evgeniy"><b>Matantsev Evgeniy</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=2081&x=-409&p=Rekis%20Jekabs">Rekis Jekabs</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:3&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>8:3&nbsp;&nbsp;</td>
<td class=bl>2:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=1784&x=-409&p=Klippen%20Magnus"><b>Klippen Magnus</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=2075&x=-409&p=Baumanis%20Toms">Baumanis Toms</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>1:2 P&nbsp;&nbsp;</td>
<td class=al>3:2 P&nbsp;&nbsp;</td>
<td class=al>4:1&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>6:0&nbsp;&nbsp;</td>
<td class=al>2:1 P&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=2024&x=-409&p=Liepins%20Emils">Liepins Emils</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=1503&x=-409&p=Huotelin%20Vesa"><b>Huotelin Vesa</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 4&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>0:8&nbsp;&nbsp;</td>
<td class=bl>4:5&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>1:2 P&nbsp;&nbsp;</td>
<td class=bl>4:5&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=1518&x=-409&p=Korabel%20Oleksii"><b>Korabel Oleksii</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=993&x=-409&p=Chyl%C3%ADk%20ml.%20Ji%C5%99%C3%AD">Chylík ml. Jiří</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 1&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>5:2&nbsp;&nbsp;</td>
<td class=al>5:1&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>4:2&nbsp;&nbsp;</td>
<td class=al>6:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=1648&x=-409&p=Lagzdins%20Sandis%20Kristaps">Lagzdins Sandis Kristaps</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=1826&x=-409&p=Blume%20Olof"><b>Blume Olof</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 4&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:2 P&nbsp;&nbsp;</td>
<td class=bl>4:3&nbsp;&nbsp;</td>
<td class=bl>1:2&nbsp;&nbsp;</td>
<td class=bl>0:3&nbsp;&nbsp;</td>
<td class=bl>2:3&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>2:3 P&nbsp;&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=409&x=-409&p=Petr%20Patrik">Petr Patrik</a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=1649&x=-409&p=Miglinieks%20Raivis"><b>Miglinieks Raivis</b></a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 4&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:2 P&nbsp;&nbsp;</td>
<td class=al>1:2 P&nbsp;&nbsp;</td>
<td class=al>4:5 P&nbsp;&nbsp;</td>
<td class=al>8:3&nbsp;&nbsp;</td>
<td class=al>0:5&nbsp;&nbsp;</td>
<td class=al>4:3 P&nbsp;&nbsp;</td>
<td class=al>1:3&nbsp;&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=2111&x=-409&p=Kamzols%20Rudolfs"><b>Kamzols Rudolfs</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=1406&x=-409&p=Mat%C3%BDsek%20Jakub">Matýsek Jakub</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:3&nbsp;&nbsp;</td>
<td class=bl>2:1&nbsp;&nbsp;</td>
<td class=bl>6:1&nbsp;&nbsp;</td>
<td class=bl>3:2 P&nbsp;&nbsp;</td>
<td class=bl>4:5 P&nbsp;&nbsp;</td>
<td class=bl>2:5&nbsp;&nbsp;</td>
<td class=bl>5:2&nbsp;&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=1761&x=-409&p=Kalnin%C5%A1%20Rainers"><b>Kalninš Rainers</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=2080&x=-409&p=Naglis%20Kristaps">Naglis Kristaps</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>7:4&nbsp;&nbsp;</td>
<td class=al>10:2&nbsp;&nbsp;</td>
<td class=al>5:2&nbsp;&nbsp;</td>
<td class=al>4:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>1/16</strong></font></th></tr>
<tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=1838&x=-409&p=Matantsev%20Evgeniy%20%28A1%2F1%29"><b>Matantsev Evgeniy (A1/1)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=1&x=-409&p=Ple%C5%A1%C3%A1k%20Pavel%20%28A2%2F16%29">Plešák Pavel (A2/16)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>5:3&nbsp;&nbsp;</td>
<td class=bl>5:3&nbsp;&nbsp;</td>
<td class=bl>4:0&nbsp;&nbsp;</td>
<td class=bl>5:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=2081&x=-409&p=Rekis%20Jekabs%20%28A1%2F9%29"><b>Rekis Jekabs (A1/9)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=2090&x=-409&p=Kalnevics%20Janis%20%28A2%2F8%29">Kalnevics Janis (A2/8)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>1:3&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>2:3 P&nbsp;&nbsp;</td>
<td class=al>6:2&nbsp;&nbsp;</td>
<td class=al>4:3&nbsp;&nbsp;</td>
<td class=al>1:3&nbsp;&nbsp;</td>
<td class=al>5:1&nbsp;&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=1784&x=-409&p=Klippen%20Magnus%20%28A2%2F4%29"><b>Klippen Magnus (A2/4)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=1766&x=-409&p=Silin%C5%A1%20Alvis%20%28A1%2F13%29">Silinš Alvis (A1/13)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:1&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>1:3&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=2074&x=-409&p=Jakseboga%20Matiss%20%28A1%2F5%29">Jakseboga Matiss (A1/5)</a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=2075&x=-409&p=Baumanis%20Toms%20%28A2%2F12%29"><b>Baumanis Toms (A2/12)</b></a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;1 : 4&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:1 P&nbsp;&nbsp;</td>
<td class=al>1:3&nbsp;&nbsp;</td>
<td class=al>1:8&nbsp;&nbsp;</td>
<td class=al>0:1&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=2024&x=-409&p=Liepins%20Emils%20%28A1%2F3%29"><b>Liepins Emils (A1/3)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=1174&x=-409&p=Mad%C4%9Bra%20Martin%20%28A2%2F14%29">Maděra Martin (A2/14)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 2&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>1:6&nbsp;&nbsp;</td>
<td class=bl>5:4 P&nbsp;&nbsp;</td>
<td class=bl>5:2&nbsp;&nbsp;</td>
<td class=bl>4:5 P&nbsp;&nbsp;</td>
<td class=bl>4:3 P&nbsp;&nbsp;</td>
<td class=bl>5:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=1503&x=-409&p=Huotelin%20Vesa%20%28A2%2F6%29"><b>Huotelin Vesa (A2/6)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=1872&x=-409&p=Fuchs%20Petr%20%28A1%2F11%29">Fuchs Petr (A1/11)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>1:2&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>0:1&nbsp;&nbsp;</td>
<td class=al>5:2&nbsp;&nbsp;</td>
<td class=al>1:3&nbsp;&nbsp;</td>
<td class=al>5:0&nbsp;&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=1518&x=-409&p=Korabel%20Oleksii%20%28A2%2F2%29"><b>Korabel Oleksii (A2/2)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=2076&x=-409&p=Naglis%20Edgars%20%28A1%2F15%29">Naglis Edgars (A1/15)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:0&nbsp;&nbsp;</td>
<td class=bl>3:4&nbsp;&nbsp;</td>
<td class=bl>3:4 P&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>4:3 P&nbsp;&nbsp;</td>
<td class=bl>3:5&nbsp;&nbsp;</td>
<td class=bl>7:2&nbsp;&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=993&x=-409&p=Chyl%C3%ADk%20ml.%20Ji%C5%99%C3%AD%20%28A1%2F7%29"><b>Chylík ml. Jiří (A1/7)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=2078&x=-409&p=Lagzdina%20Krista%20Annija%20%28A2%2F10%29">Lagzdina Krista Annija (A2/10)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 1&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>2:3 P&nbsp;&nbsp;</td>
<td class=al>6:2&nbsp;&nbsp;</td>
<td class=al>2:1 P&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=1648&x=-409&p=Lagzdins%20Sandis%20Kristaps%20%28A1%2F2%29"><b>Lagzdins Sandis Kristaps (A1/2)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=850&x=-409&p=Bla%C5%A1ko%20Imrich%20%28A2%2F15%29">Blaško Imrich (A2/15)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 2&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>6:4&nbsp;&nbsp;</td>
<td class=bl>2:4&nbsp;&nbsp;</td>
<td class=bl>1:3&nbsp;&nbsp;</td>
<td class=bl>3:0&nbsp;&nbsp;</td>
<td class=bl>4:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=1846&x=-409&p=Matantsev%20Artem%20%28A2%2F7%29">Matantsev Artem (A2/7)</a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=1826&x=-409&p=Blume%20Olof%20%28A1%2F10%29"><b>Blume Olof (A1/10)</b></a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 4&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>4:3&nbsp;&nbsp;</td>
<td class=al>3:4 P&nbsp;&nbsp;</td>
<td class=al>7:2&nbsp;&nbsp;</td>
<td class=al>5:4&nbsp;&nbsp;</td>
<td class=al>1:2&nbsp;&nbsp;</td>
<td class=al>1:4&nbsp;&nbsp;</td>
<td class=al>1:2&nbsp;&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=409&x=-409&p=Petr%20Patrik%20%28A2%2F3%29"><b>Petr Patrik (A2/3)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=1153&x=-409&p=Pesala%20Otto%20%28A1%2F14%29">Pesala Otto (A1/14)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:3&nbsp;&nbsp;</td>
<td class=bl>3:0&nbsp;&nbsp;</td>
<td class=bl>7:2&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=1649&x=-409&p=Miglinieks%20Raivis%20%28A1%2F6%29"><b>Miglinieks Raivis (A1/6)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=1772&x=-409&p=Silin%C5%A1%20Elvijs%20%28A2%2F11%29">Silinš Elvijs (A2/11)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 1&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>5:3&nbsp;&nbsp;</td>
<td class=al>0:4&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>3:0&nbsp;&nbsp;</td>
<td class=al>3:2 P&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=2111&x=-409&p=Kamzols%20Rudolfs%20%28A1%2F4%29"><b>Kamzols Rudolfs (A1/4)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=2112&x=-409&p=Kaneps%20Edzus%20%28A2%2F13%29">Kaneps Edzus (A2/13)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 2&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>2:3&nbsp;&nbsp;</td>
<td class=bl>6:3&nbsp;&nbsp;</td>
<td class=bl>3:2 P&nbsp;&nbsp;</td>
<td class=bl>4:5 P&nbsp;&nbsp;</td>
<td class=bl>5:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=1477&x=-409&p=Kobrle%20Michal%20%28A2%2F5%29">Kobrle Michal (A2/5)</a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=1406&x=-409&p=Mat%C3%BDsek%20Jakub%20%28A1%2F12%29"><b>Matýsek Jakub (A1/12)</b></a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 4&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>4:2&nbsp;&nbsp;</td>
<td class=al>2:4&nbsp;&nbsp;</td>
<td class=al>3:2 P&nbsp;&nbsp;</td>
<td class=al>4:5 P&nbsp;&nbsp;</td>
<td class=al>4:3 P&nbsp;&nbsp;</td>
<td class=al>1:5&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=1761&x=-409&p=Kalnin%C5%A1%20Rainers%20%28A2%2F1%29"><b>Kalninš Rainers (A2/1)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=1786&x=-409&p=Fylling%20Amund%20Risa%20%28A1%2F16%29">Fylling Amund Risa (A1/16)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>8:2&nbsp;&nbsp;</td>
<td class=bl>9:3&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>5:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=2080&x=-409&p=Naglis%20Kristaps%20%28A2%2F9%29"><b>Naglis Kristaps (A2/9)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=2085&x=-409&p=Prokuratovs%20Henrijs%20%28A1%2F8%29">Prokuratovs Henrijs (A1/8)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>6:2&nbsp;&nbsp;</td>
<td class=al>3:1&nbsp;&nbsp;</td>
<td class=al>2:1 P&nbsp;&nbsp;</td>
<td class=al>3:4&nbsp;&nbsp;</td>
<td class=al>1:4&nbsp;&nbsp;</td>
<td class=al>5:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>B Finals</strong></font></th></tr>
<tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=2087&x=-409&p=Hellstrom%20Sami"><b>Hellstrom Sami</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=1790&x=-409&p=Fjermestad%20Andreas">Fjermestad Andreas</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>6:4&nbsp;&nbsp;</td>
<td class=bl>1:3&nbsp;&nbsp;</td>
<td class=bl>5:4 P&nbsp;&nbsp;</td>
<td class=bl>4:3 P&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>B 1/2</strong></font></th></tr>
<tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=2087&x=-409&p=Hellstrom%20Sami%20%281%29"><b>Hellstrom Sami (1)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=201&x=-409&p=Bucek%20Tom%C3%A1%C5%A1%20%284%29">Bucek Tomáš (4)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 1&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>4:1&nbsp;&nbsp;</td>
<td class=al>1:5&nbsp;&nbsp;</td>
<td class=al>6:5 P&nbsp;&nbsp;</td>
<td class=al>3:0&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=1065&x=-409&p=Herold%20Kry%C5%A1tof%20%282%29">Herold Kryštof (2)</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=1790&x=-409&p=Fjermestad%20Andreas%20%283%29"><b>Fjermestad Andreas (3)</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:2 P&nbsp;&nbsp;</td>
<td class=bl>1:4&nbsp;&nbsp;</td>
<td class=bl>4:5&nbsp;&nbsp;</td>
<td class=bl>4:3&nbsp;&nbsp;</td>
<td class=bl>1:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>C Finals</strong></font></th></tr>
<tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=2086&x=-409&p=Lacis%20Niks"><b>Lacis Niks</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=1709&x=-409&p=Bla%C5%BEek%20Michal">Blažek Michal</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>1:0&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>C 1/2</strong></font></th></tr>
<tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=2086&x=-409&p=Lacis%20Niks%20%281%29"><b>Lacis Niks (1)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=53&x=-409&p=Pikl%20V%C3%A1clav%20%284%29">Pikl Václav (4)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 1&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>4:5 P&nbsp;&nbsp;</td>
<td class=al>3:2 P&nbsp;&nbsp;</td>
<td class=al>4:3&nbsp;&nbsp;</td>
<td class=al>4:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=1709&x=-409&p=Bla%C5%BEek%20Michal%20%282%29"><b>Blažek Michal (2)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=559&x=-409&p=Axelsen%20Bjarne%20%283%29">Axelsen Bjarne (3)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 2&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:4 P&nbsp;&nbsp;</td>
<td class=bl>1:5&nbsp;&nbsp;</td>
<td class=bl>2:0&nbsp;&nbsp;</td>
<td class=bl>4:3&nbsp;&nbsp;</td>
<td class=bl>8:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>D Finals</strong></font></th></tr>
<tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=320&x=-409&p=Hudec%20Tom%C3%A1%C5%A1"><b>Hudec Tomáš</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=447&x=-409&p=Pavlica%20Roman">Pavlica Roman</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 2&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:6&nbsp;&nbsp;</td>
<td class=bl>1:0&nbsp;&nbsp;</td>
<td class=bl>1:3&nbsp;&nbsp;</td>
<td class=bl>7:3&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>D 1/2</strong></font></th></tr>
<tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=320&x=-409&p=Hudec%20Tom%C3%A1%C5%A1%20%281%29"><b>Hudec Tomáš (1)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=1657&x=-409&p=Perkner%20Jon%C3%A1%C5%A1%20%284%29">Perkner Jonáš (4)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>4:3 P&nbsp;&nbsp;</td>
<td class=al>1:4&nbsp;&nbsp;</td>
<td class=al>1:0 P&nbsp;&nbsp;</td>
<td class=al>2:5&nbsp;&nbsp;</td>
<td class=al>5:4&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=447&x=-409&p=Pavlica%20Roman%20%282%29"><b>Pavlica Roman (2)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=319&x=-409&p=Hudec%20Karol%20%283%29">Hudec Karol (3)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:3&nbsp;&nbsp;</td>
<td class=bl>3:5&nbsp;&nbsp;</td>
<td class=bl>4:2&nbsp;&nbsp;</td>
<td class=bl>2:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>E Finals</strong></font></th></tr>
<tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=2005&x=-409&p=Zupan%C4%8Di%C4%8D%20Domen">Zupančič Domen</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=2018&x=-409&p=Janou%C5%A1kovec%20Jan"><b>Janouškovec Jan</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;0 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:4&nbsp;&nbsp;</td>
<td class=bl>1:6&nbsp;&nbsp;</td>
<td class=bl>0:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>E 1/2</strong></font></th></tr>
<tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=2005&x=-409&p=Zupan%C4%8Di%C4%8D%20Domen%20%281%29"><b>Zupančič Domen (1)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=2094&x=-409&p=Gripp%20Gunnar%20%284%29">Gripp Gunnar (4)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:1 P&nbsp;&nbsp;</td>
<td class=al>3:2 P&nbsp;&nbsp;</td>
<td class=al>2:1 P&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=818&x=-409&p=Je%C5%BE%20Robert%20%282%29">Jež Robert (2)</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=2018&x=-409&p=Janou%C5%A1kovec%20Jan%20%283%29"><b>Janouškovec Jan (3)</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>1:2&nbsp;&nbsp;</td>
<td class=bl>4:0&nbsp;&nbsp;</td>
<td class=bl>1:2&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>3:6&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>F Finals</strong></font></th></tr>
<tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=2044&x=-409&p=Tom%C3%A1%C5%A1t%C3%ADk%20Jan">Tomáštík Jan</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=2099&x=-409&p=Pylypenko%20Oleksandr"><b>Pylypenko Oleksandr</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;0 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:4&nbsp;&nbsp;</td>
<td class=bl>0:7&nbsp;&nbsp;</td>
<td class=bl>2:5&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>F 1/2</strong></font></th></tr>
<tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=2044&x=-409&p=Tom%C3%A1%C5%A1t%C3%ADk%20Jan%20%281%29"><b>Tomáštík Jan (1)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=1957&x=-409&p=Bernhauser%20Erik%20%284%29">Bernhauser Erik (4)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>5:4&nbsp;&nbsp;</td>
<td class=al>4:5&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>1:4&nbsp;&nbsp;</td>
<td class=al>4:0&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=2099&x=-409&p=Pylypenko%20Oleksandr%20%282%29"><b>Pylypenko Oleksandr (2)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=910&x=-409&p=Gobyov%C3%A1%20Vlasta%20%283%29">Gobyová Vlasta (3)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>5:3&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>4:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>G Finals</strong></font></th></tr>
<tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=1749&x=-409&p=Gripp%20Ida">Gripp Ida</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=2038&x=-409&p=Moravec%20Michael"><b>Moravec Michael</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;1 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>1:2 P&nbsp;&nbsp;</td>
<td class=bl>0:2&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>0:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>G 1/2</strong></font></th></tr>
<tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=1749&x=-409&p=Gripp%20Ida%20%281%29"><b>Gripp Ida (1)</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=1959&x=-409&p=Chlebo%20Ond%C5%99ej%20%284%29">Chlebo Ondřej (4)</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 1&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>1:2 P&nbsp;&nbsp;</td>
<td class=al>1:0&nbsp;&nbsp;</td>
<td class=al>3:0&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=2038&x=-409&p=Moravec%20Michael%20%282%29"><b>Moravec Michael (2)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=1076&x=-409&p=Zeman%20Milan%20%283%29">Zeman Milan (3)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>6:1&nbsp;&nbsp;</td>
<td class=bl>2:0&nbsp;&nbsp;</td>
<td class=bl>3:0&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
