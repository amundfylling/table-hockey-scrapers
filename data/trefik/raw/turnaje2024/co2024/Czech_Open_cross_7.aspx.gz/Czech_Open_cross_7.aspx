<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2024">Czech Open</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 7</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2081&x=-409&p=Je%20Rekis">Je Rekis</a></td><td class=kx>*</td>
<td class=kW>10:1</td>
<td class=kL>4:5</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=br>96:39</td><td class=br>+57</td>
<td class=bc>15 - 1 - 3</td>
<td class=br><strong>31</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1766&x=-409&p=Al%20Silin%C5%A1">Al Silinš</a></td><td class=kL>1:10</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>3:9</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>7:3</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=br>84:48</td><td class=br>+36</td>
<td class=bc>13 - 3 - 3</td>
<td class=br><strong>29</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2079&x=-409&p=Di%20Ziemelis">Di Ziemelis</a></td><td class=kW>5:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=kW>3:0</td>
<td class=kW>6:3</td>
<td class=kW>6:0</td>
<td class=br>68:38</td><td class=br>+30</td>
<td class=bc>13 - 2 - 4</td>
<td class=br><strong>28</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1650&x=-409&p=Va%20Dietze">Va Dietze</a></td><td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kW>8:3</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kW>5:4</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=br>86:49</td><td class=br>+37</td>
<td class=bc>12 - 2 - 5</td>
<td class=br><strong>26</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1826&x=-409&p=Ol%20Blume">Ol Blume</a></td><td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>8:3</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>7:3</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>7:2</td>
<td class=br>71:42</td><td class=br>+29</td>
<td class=bc>11 - 4 - 4</td>
<td class=br><strong>26</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1872&x=-409&p=Pe%20Fuchs">Pe Fuchs</a></td><td class=kT>4:4</td>
<td class=kW>9:3</td>
<td class=kW>2:0</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=br>66:46</td><td class=br>+20</td>
<td class=bc>10 - 5 - 4</td>
<td class=br><strong>25</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1764&x=-409&p=Sa%20Kalnin%C5%A1">Sa Kalninš</a></td><td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kW>2:0</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kL>3:6</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=kW>6:0</td>
<td class=br>61:40</td><td class=br>+21</td>
<td class=bc>9 - 6 - 4</td>
<td class=br><strong>24</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1876&x=-409&p=Ad%20Kop%C5%99iva">Ad Kopřiva</a></td><td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>3:7</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>6:5</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kW>7:0</td>
<td class=kW>3:0</td>
<td class=br>65:56</td><td class=br>+9</td>
<td class=bc>11 - 1 - 7</td>
<td class=br><strong>23</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1033&x=-409&p=Si%20Thomas">Si Thomas</a></td><td class=kL>2:7</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>3:8</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>7:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>6:0</td>
<td class=kW>2:0</td>
<td class=kW>7:0</td>
<td class=kW>3:0</td>
<td class=br>62:51</td><td class=br>+11</td>
<td class=bc>10 - 2 - 7</td>
<td class=br><strong>22</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=248&x=-409&p=Ma%20%C5%BDen%C3%AD%C5%A1ek">Ma Ženíšek</a></td><td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kL>1:4</td>
<td class=kW>8:3</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kW>3:0</td>
<td class=br>57:50</td><td class=br>+7</td>
<td class=bc>7 - 6 - 6</td>
<td class=br><strong>20</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2098&x=-409&p=Ni%20Lyksholm">Ni Lyksholm</a></td><td class=kW>5:2</td>
<td class=kL>3:7</td>
<td class=kL>2:5</td>
<td class=kL>3:6</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>9:1</td>
<td class=kW>8:1</td>
<td class=br>62:50</td><td class=br>+12</td>
<td class=bc>8 - 4 - 7</td>
<td class=br><strong>20</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1940&x=-409&p=Ma%20Ko%C5%A1%C5%88ar">Ma Košňar</a></td><td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>3:8</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=br>54:59</td><td class=br>-5</td>
<td class=bc>8 - 3 - 8</td>
<td class=br><strong>19</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=261&x=-409&p=Da%20Cibulka">Da Cibulka</a></td><td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>3:8</td>
<td class=kL>0:1</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=br>48:54</td><td class=br>-6</td>
<td class=bc>8 - 2 - 9</td>
<td class=br><strong>18</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>D</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=204&x=-409&p=Hy%20Nechutn%C3%BD">Hy Nechutný</a></td><td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=br>43:50</td><td class=br>-7</td>
<td class=bc>6 - 5 - 8</td>
<td class=br><strong>17</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=320&x=-409&p=To%20Hudec">To Hudec</a></td><td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=br>52:60</td><td class=br>-8</td>
<td class=bc>6 - 4 - 9</td>
<td class=br><strong>16</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>E</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=215&x=-409&p=Jo%20Vom%C3%A1%C4%8Dka">Jo Vomáčka</a></td><td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kL>3:7</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>5:6</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kW>6:0</td>
<td class=kW>8:2</td>
<td class=kW>5:0</td>
<td class=br>55:59</td><td class=br>-4</td>
<td class=bc>6 - 3 - 10</td>
<td class=br><strong>15</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>E</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2018&x=-409&p=Ja%20Janou%C5%A1kovec">Ja Janouškovec</a></td><td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kW>6:1</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=br>41:75</td><td class=br>-34</td>
<td class=bc>5 - 2 - 12</td>
<td class=br><strong>12</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>F</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1896&x=-409&p=Ra%20Hrn%C4%8D%C3%AD%C5%99">Ra Hrnčíř</a></td><td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=br>23:75</td><td class=br>-52</td>
<td class=bc>2 - 3 - 14</td>
<td class=br><strong>7</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>F</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2015&x=-409&p=Mo%20Tich%C3%A1">Mo Tichá</a></td><td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>0:7</td>
<td class=kL>0:7</td>
<td class=kL>0:7</td>
<td class=kL>3:6</td>
<td class=kL>1:9</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>2:8</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=br>28:104</td><td class=br>-76</td>
<td class=bc>1 - 0 - 18</td>
<td class=br><strong>2</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>G</td><td class=d>20.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2038&x=-409&p=Mi%20Moravec">Mi Moravec</a></td><td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>1:8</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=br>11:88</td><td class=br>-77</td>
<td class=bc>0 - 0 - 19</td>
<td class=br><strong>0</strong></td><td class=d>20.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Ol Blume</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Mo Tichá</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Al Silinš</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Je Rekis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ol Blume</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Mo Tichá</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Al Silinš</td><td class=bc>9 : 3</tr></td>
<tr><td class=brW>Je Rekis</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=blW>Ja Janouškovec</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>Ol Blume</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Mo Tichá</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Al Silinš</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Je Rekis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ni Lyksholm</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ja Janouškovec</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ol Blume</td><td class=bc>-</td><td class=bl>Mo Tichá</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Jo Vomáčka</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Al Silinš</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Je Rekis</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>To Hudec</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Sa Kalninš</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=bl>Ol Blume</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Al Silinš</td><td class=bc>-</td><td class=bl>Mo Tichá</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>Je Rekis</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ni Lyksholm</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Sa Kalninš</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>To Hudec</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ol Blume</td><td class=bc>-</td><td class=bl>Al Silinš</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Je Rekis</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Mo Tichá</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=blW>Jo Vomáčka</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Al Silinš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ni Lyksholm</td><td class=bc>-</td><td class=bl>Mo Tichá</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Sa Kalninš</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>To Hudec</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Je Rekis</td><td class=bc>-</td><td class=bl>Ol Blume</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ol Blume</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=blW>Je Rekis</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Jo Vomáčka</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Sa Kalninš</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>To Hudec</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Al Silinš</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mo Tichá</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Je Rekis</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Al Silinš</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Sa Kalninš</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ja Janouškovec</td><td class=bc>-</td><td class=bl>Mo Tichá</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=blW>Ol Blume</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ol Blume</td><td class=bc>-</td><td class=blW>Ni Lyksholm</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=blW>Je Rekis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Al Silinš</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>To Hudec</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Mo Tichá</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Ol Blume</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=blW>Sa Kalninš</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Je Rekis</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Al Silinš</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Mo Tichá</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Jo Vomáčka</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ol Blume</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Mo Tichá</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ni Lyksholm</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Al Silinš</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Je Rekis</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Al Silinš</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=bl>Ol Blume</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>To Hudec</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ni Lyksholm</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Jo Vomáčka</td><td class=bc>-</td><td class=bl>Mo Tichá</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ol Blume</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Mo Tichá</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>To Hudec</td><td class=bc>-</td><td class=blW>Ol Blume</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ja Janouškovec</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Al Silinš</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Je Rekis</td><td class=bc>-</td><td class=bl>Mo Tichá</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=bl>Al Silinš</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ol Blume</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Sa Kalninš</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mo Tichá</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Al Silinš</td><td class=bc>-</td><td class=blW>Je Rekis</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ol Blume</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>To Hudec</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Sa Kalninš</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Mo Tichá</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=blW>Al Silinš</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Je Rekis</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ol Blume</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ja Janouškovec</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Mo Tichá</td><td class=bc>-</td><td class=blW>Sa Kalninš</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Al Silinš</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ni Lyksholm</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Ol Blume</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Jo Vomáčka</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Mo Tichá</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=blW>Al Silinš</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Je Rekis</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=blW>Ni Lyksholm</td><td class=bc>1 : 8</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
