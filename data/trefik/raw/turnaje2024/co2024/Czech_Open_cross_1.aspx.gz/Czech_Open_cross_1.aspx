<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2024">Czech Open</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1838&x=-409&p=Ev%20Matantsev">Ev Matantsev</a></td><td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>5:4</td>
<td class=kW>3:2</td>
<td class=kL>4:5</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kT>5:5</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>8:2</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>9:1</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>7:0</td>
<td class=br>101:40</td><td class=br>+61</td>
<td class=bc>17 - 2 - 1</td>
<td class=br><strong>36</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2111&x=-409&p=Ru%20Kamzols">Ru Kamzols</a></td><td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>6:3</td>
<td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kT>4:4</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kT>4:4</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=kW>9:0</td>
<td class=kW>8:0</td>
<td class=br>93:38</td><td class=br>+55</td>
<td class=bc>15 - 3 - 2</td>
<td class=br><strong>33</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1770&x=-409&p=Gi%20Lasmanis">Gi Lasmanis</a></td><td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>7:2</td>
<td class=kW>5:3</td>
<td class=kW>7:3</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>8:4</td>
<td class=kW>8:0</td>
<td class=kW>7:2</td>
<td class=kW>7:4</td>
<td class=kW>7:0</td>
<td class=br>96:45</td><td class=br>+51</td>
<td class=bc>14 - 2 - 4</td>
<td class=br><strong>30</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2076&x=-409&p=Ed%20Naglis">Ed Naglis</a></td><td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>8:0</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>8:1</td>
<td class=kW>8:4</td>
<td class=br>91:44</td><td class=br>+47</td>
<td class=bc>14 - 2 - 4</td>
<td class=br><strong>30</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2085&x=-409&p=He%20Prokuratovs">He Prokuratovs</a></td><td class=kW>5:4</td>
<td class=kL>2:6</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>9:0</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>6:3</td>
<td class=kW>7:2</td>
<td class=br>73:45</td><td class=br>+28</td>
<td class=bc>13 - 3 - 4</td>
<td class=br><strong>29</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1641&x=-409&p=Ma%20Klazar">Ma Klazar</a></td><td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>8:2</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=kW>8:1</td>
<td class=br>70:41</td><td class=br>+29</td>
<td class=bc>12 - 3 - 5</td>
<td class=br><strong>27</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1844&x=-409&p=Ha%20Ivantsova">Ha Ivantsova</a></td><td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>8:0</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=br>62:41</td><td class=br>+21</td>
<td class=bc>10 - 6 - 4</td>
<td class=br><strong>26</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1845&x=-409&p=My%20Shalomayev">My Shalomayev</a></td><td class=kT>5:5</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kL>0:8</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kW>10:1</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>10:1</td>
<td class=kW>7:2</td>
<td class=kW>2:1</td>
<td class=kW>10:1</td>
<td class=kW>8:2</td>
<td class=br>90:49</td><td class=br>+41</td>
<td class=bc>12 - 2 - 6</td>
<td class=br><strong>26</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1790&x=-409&p=An%20Fjermestad">An Fjermestad</a></td><td class=kL>2:6</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kL>0:1</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=br>66:49</td><td class=br>+17</td>
<td class=bc>12 - 1 - 7</td>
<td class=br><strong>25</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=26&x=-409&p=Mi%20%C5%A0evr">Mi Ševr</a></td><td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>3:6</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>5:3</td>
<td class=kW>14:1</td>
<td class=kW>5:0</td>
<td class=br>72:48</td><td class=br>+24</td>
<td class=bc>12 - 1 - 7</td>
<td class=br><strong>25</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2087&x=-409&p=Sa%20Hellstrom">Sa Hellstrom</a></td><td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>6:0</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kL>0:4</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=br>62:46</td><td class=br>+16</td>
<td class=bc>10 - 4 - 6</td>
<td class=br><strong>24</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1619&x=-409&p=Mi%20Borgh">Mi Borgh</a></td><td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kL>2:7</td>
<td class=kL>2:7</td>
<td class=kW>5:1</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kL>1:10</td>
<td class=kL>2:3</td>
<td class=kW>6:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>6:4</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=br>60:70</td><td class=br>-10</td>
<td class=bc>8 - 4 - 8</td>
<td class=br><strong>20</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1630&x=-409&p=Pe%20Holub">Pe Holub</a></td><td class=kL>3:6</td>
<td class=kL>2:6</td>
<td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>7:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>8:2</td>
<td class=kW>5:0</td>
<td class=br>54:50</td><td class=br>+4</td>
<td class=bc>8 - 3 - 9</td>
<td class=br><strong>19</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>D</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1746&x=-409&p=An%20Gripp">An Gripp</a></td><td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>3:7</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kL>2:7</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>6:5</td>
<td class=kL>0:1</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=br>45:63</td><td class=br>-18</td>
<td class=bc>5 - 4 - 11</td>
<td class=br><strong>14</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1599&x=-409&p=Mi%20Uhl%C3%AD%C5%99">Mi Uhlíř</a></td><td class=kL>2:8</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kL>2:7</td>
<td class=kL>5:6</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>6:3</td>
<td class=kW>8:3</td>
<td class=kW>6:2</td>
<td class=br>60:76</td><td class=br>-16</td>
<td class=bc>5 - 4 - 11</td>
<td class=br><strong>14</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>E</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2094&x=-409&p=Gu%20Gripp">Gu Gripp</a></td><td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=br>34:64</td><td class=br>-30</td>
<td class=bc>5 - 3 - 12</td>
<td class=br><strong>13</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>E</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2093&x=-409&p=Jo%20Brunner">Jo Brunner</a></td><td class=kL>1:6</td>
<td class=kT>4:4</td>
<td class=kL>4:8</td>
<td class=kL>1:4</td>
<td class=kL>0:9</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>1:10</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=br>43:84</td><td class=br>-41</td>
<td class=bc>3 - 4 - 13</td>
<td class=br><strong>10</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>F</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1970&x=-409&p=Ji%20P%C3%ADse%C4%8Dka">Ji Písečka</a></td><td class=kL>1:9</td>
<td class=kL>2:7</td>
<td class=kL>0:8</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kL>2:8</td>
<td class=kL>0:8</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>4:6</td>
<td class=kL>0:3</td>
<td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=br>42:106</td><td class=br>-64</td>
<td class=bc>3 - 1 - 16</td>
<td class=br><strong>7</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>F</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2020&x=-409&p=Da%20Jerabek">Da Jerabek</a></td><td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kL>2:7</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kW>4:0</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kL>3:6</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=br>32:76</td><td class=br>-44</td>
<td class=bc>3 - 1 - 16</td>
<td class=br><strong>7</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>G</td><td class=d>20.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1430&x=-409&p=Da%20Kadlec">Da Kadlec</a></td><td class=kL>2:6</td>
<td class=kL>0:9</td>
<td class=kL>4:7</td>
<td class=kL>1:8</td>
<td class=kL>3:6</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kL>1:10</td>
<td class=kL>0:4</td>
<td class=kL>1:14</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>2:8</td>
<td class=kT>2:2</td>
<td class=kL>3:8</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>1:7</td>
<td class=br>33:120</td><td class=br>-87</td>
<td class=bc>0 - 3 - 17</td>
<td class=br><strong>3</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>G</td><td class=d>21.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2019&x=-409&p=Pa%20Janou%C5%A1kovec">Pa Janouškovec</a></td><td class=kL>0:7</td>
<td class=kL>0:8</td>
<td class=kL>0:7</td>
<td class=kL>4:8</td>
<td class=kL>2:7</td>
<td class=kL>1:8</td>
<td class=kL>1:7</td>
<td class=kL>2:8</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>2:7</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>0:1</td>
<td class=kL>0:6</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kW>7:1</td>
<td class=kx>*</td>
<td class=br>28:112</td><td class=br>-84</td>
<td class=bc>1 - 0 - 19</td>
<td class=br><strong>2</strong></td><td class=d>21.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Jo Brunner</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Gu Gripp</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Sa Hellstrom</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Gu Gripp</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Sa Hellstrom</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Da Jerabek</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>Jo Brunner</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>An Gripp</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Gu Gripp</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Sa Hellstrom</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Da Jerabek</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Ru Kamzols</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Jo Brunner</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>4 : 8</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ji Písečka</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Gu Gripp</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Sa Hellstrom</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=bl>Gu Gripp</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Sa Hellstrom</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ha Ivantsova</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Da Jerabek</td><td class=bc>-</td><td class=blW>Ji Písečka</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Jo Brunner</td><td class=bc>-</td><td class=blW>An Gripp</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ru Kamzols</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Jo Brunner</td><td class=bc>-</td><td class=bl>Gu Gripp</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=blW>Sa Hellstrom</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>8 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ji Písečka</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Gu Gripp</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Jo Brunner</td><td class=bc>-</td><td class=bl>Sa Hellstrom</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>An Gripp</td><td class=bc>-</td><td class=blW>Gu Gripp</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Sa Hellstrom</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Da Jerabek</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ru Kamzols</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>4 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Jo Brunner</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>10 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Da Jerabek</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 14</tr></td>
<tr><td class=brW>Ru Kamzols</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Gripp</td><td class=bc>-</td><td class=blW>Sa Hellstrom</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Jo Brunner</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=blW>Mi Borgh</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>An Gripp</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Jo Brunner</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Gu Gripp</td><td class=bc>-</td><td class=blW>Sa Hellstrom</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Gu Gripp</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Gripp</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Da Jerabek</td><td class=bc>-</td><td class=bl>Jo Brunner</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ru Kamzols</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Sa Hellstrom</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Gu Gripp</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Mi Borgh</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>An Gripp</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Jo Brunner</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Sa Hellstrom</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Gu Gripp</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>An Gripp</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ru Kamzols</td><td class=bc>-</td><td class=bl>Jo Brunner</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Mi Borgh</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Jo Brunner</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Sa Hellstrom</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Gu Gripp</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>An Gripp</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Sa Hellstrom</td><td class=bc>-</td><td class=blW>Da Jerabek</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Gu Gripp</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ru Kamzols</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Jo Brunner</td><td class=bc>8 : 4</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Mi Borgh</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Jo Brunner</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Sa Hellstrom</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Gu Gripp</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>An Gripp</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Sa Hellstrom</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Gu Gripp</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Jo Brunner</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=blW>Mi Borgh</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>8 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=blW>Da Jerabek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Sa Hellstrom</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Gu Gripp</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>An Gripp</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Jo Brunner</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pa Janouškovec</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Sa Hellstrom</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=bl>Gu Gripp</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Jo Brunner</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Mi Borgh</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Da Jerabek</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=br>Jo Brunner</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 10</tr></td>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Sa Hellstrom</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Gu Gripp</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>An Gripp</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>26</td></tr>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=blW>Gu Gripp</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Jerabek</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Sa Hellstrom</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>27</td></tr>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Jo Brunner</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Mi Borgh</td><td class=bc>4 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
