<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2024">Czech Open</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2087&x=-409&p=Sa%20Hellstrom">Sa Hellstrom</a></td><td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kW>5:2 K</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>6:2</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=kL>1:2 K</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=br>71:39</td><td class=br>+32</td>
<td class=bc>17 - 1 - 5</td>
<td class=br><strong>35</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1065&x=-409&p=Kr%20Herold">Kr Herold</a></td><td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:3 K</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>2:4 K</td>
<td class=kT>5:5</td>
<td class=kL>0:1</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=br>64:48</td><td class=br>+16</td>
<td class=bc>15 - 4 - 4</td>
<td class=br><strong>34</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1790&x=-409&p=An%20Fjermestad">An Fjermestad</a></td><td class=kL>2:5 K</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>5:4</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>5:3 K</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kL>3:9</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=br>84:56</td><td class=br>+28</td>
<td class=bc>16 - 1 - 6</td>
<td class=br><strong>33</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=201&x=-409&p=To%20Bucek">To Bucek</a></td><td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>5:5</td>
<td class=kW>4:1</td>
<td class=kL>0:2</td>
<td class=kW>2:1 K</td>
<td class=kL>1:2</td>
<td class=kW>5:4</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kW>7:2</td>
<td class=kL>1:3 K</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>0:6</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=br>70:57</td><td class=br>+13</td>
<td class=bc>13 - 3 - 7</td>
<td class=br><strong>29</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2082&x=-409&p=La%20Metsala">La Metsala</a></td><td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>2:0 K</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kW>3:0</td>
<td class=kW>4:0 K</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=br>67:41</td><td class=br>+26</td>
<td class=bc>13 - 3 - 7</td>
<td class=br><strong>29</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=248&x=-409&p=Ma%20%C5%BDen%C3%AD%C5%A1ek">Ma Ženíšek</a></td><td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kT>5:5</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kL>5:6</td>
<td class=kW>6:3</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kL>2:3 K</td>
<td class=kW>5:4</td>
<td class=kW>7:6</td>
<td class=kW>6:3 K</td>
<td class=br>81:74</td><td class=br>+7</td>
<td class=bc>13 - 3 - 7</td>
<td class=br><strong>29</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1977&x=-409&p=Ti%20Dion">Ti Dion</a></td><td class=kW>1:0</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kL>2:5 K</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>4:2 K</td>
<td class=kW>6:2</td>
<td class=kW>8:2</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kL>0:5</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=br>74:61</td><td class=br>+13</td>
<td class=bc>12 - 5 - 6</td>
<td class=br><strong>29</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1828&x=-409&p=Tr%20Mansson">Tr Mansson</a></td><td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kW>2:0</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1 K</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kT>5:5</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kL>1:2 K</td>
<td class=kW>3:2</td>
<td class=br>61:48</td><td class=br>+13</td>
<td class=bc>12 - 4 - 7</td>
<td class=br><strong>28</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2084&x=-409&p=Ha%20Gals">Ha Gals</a></td><td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>1:2 K</td>
<td class=kL>3:4</td>
<td class=kW>4:0</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kL>4:5</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>3:0 K</td>
<td class=kW>6:2</td>
<td class=kT>5:5</td>
<td class=kL>1:3</td>
<td class=kW>7:1</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>7:0</td>
<td class=br>79:49</td><td class=br>+30</td>
<td class=bc>12 - 3 - 8</td>
<td class=br><strong>27</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1579&x=-409&p=Vi%20Henttonen">Vi Henttonen</a></td><td class=kL>1:5</td>
<td class=kL>3:4 K</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kL>3:4 K</td>
<td class=kL>3:4</td>
<td class=kT>0:0</td>
<td class=kL>1:2</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=br>58:48</td><td class=br>+10</td>
<td class=bc>11 - 4 - 8</td>
<td class=br><strong>26</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=893&x=-409&p=Ne%20%C5%A0krlep">Ne Škrlep</a></td><td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kW>5:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kW>5:3</td>
<td class=kW>5:4</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>4:3 K</td>
<td class=kW>4:1</td>
<td class=kW>2:1 K</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=br>72:65</td><td class=br>+7</td>
<td class=bc>12 - 1 - 10</td>
<td class=br><strong>25</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=18&x=-409&p=An%20%C5%A0ur%C3%BDn">An Šurýn</a></td><td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>6:1</td>
<td class=kL>0:2 K</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>6:2 K</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=br>58:55</td><td class=br>+3</td>
<td class=bc>11 - 1 - 11</td>
<td class=br><strong>23</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1974&x=-409&p=Ja%20Obadi%C4%8D">Ja Obadič</a></td><td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>6:5</td>
<td class=kL>0:3</td>
<td class=kL>1:4 K</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>5:4</td>
<td class=kL>0:3 K</td>
<td class=kW>3:1</td>
<td class=br>65:65</td><td class=br>0</td>
<td class=bc>10 - 3 - 10</td>
<td class=br><strong>23</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1268&x=-409&p=Da%20Dvo%C5%99%C3%A1%C4%8Dek">Da Dvořáček</a></td><td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>2:7</td>
<td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=kW>5:2 K</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>3:6</td>
<td class=kW>4:2 K</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=br>62:65</td><td class=br>-3</td>
<td class=bc>10 - 2 - 11</td>
<td class=br><strong>22</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=354&x=-409&p=Ti%20Varga">Ti Varga</a></td><td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>3:1 K</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>0:3 K</td>
<td class=kL>4:5</td>
<td class=kL>3:5</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kW>4:2</td>
<td class=br>53:68</td><td class=br>-15</td>
<td class=bc>9 - 2 - 12</td>
<td class=br><strong>20</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1622&x=-409&p=He%20Petuch">He Petuch</a></td><td class=kL>3:5</td>
<td class=kW>4:2 K</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>5:5</td>
<td class=kL>2:6</td>
<td class=kW>4:3 K</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>6:5</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=br>67:80</td><td class=br>-13</td>
<td class=bc>7 - 6 - 10</td>
<td class=br><strong>20</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=101&x=-409&p=Mi%20Kubica">Mi Kubica</a></td><td class=kL>0:6</td>
<td class=kT>5:5</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kW>5:2</td>
<td class=kL>2:4 K</td>
<td class=kW>5:3</td>
<td class=kT>5:5</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>2:4 K</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>7:1</td>
<td class=kL>5:7</td>
<td class=br>67:78</td><td class=br>-11</td>
<td class=bc>8 - 4 - 11</td>
<td class=br><strong>20</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1978&x=-409&p=My%20Verbytskyy">My Verbytskyy</a></td><td class=kL>1:3</td>
<td class=kW>1:0</td>
<td class=kL>1:5</td>
<td class=kW>6:0</td>
<td class=kL>0:4 K</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kT>0:0</td>
<td class=kL>0:4</td>
<td class=kL>2:6 K</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>0:6</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=br>43:66</td><td class=br>-23</td>
<td class=bc>8 - 2 - 13</td>
<td class=br><strong>18</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=26&x=-409&p=Mi%20%C5%A0evr">Mi Ševr</a></td><td class=kW>2:1 K</td>
<td class=kL>0:2</td>
<td class=kL>3:5 K</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>2:8</td>
<td class=kL>1:7</td>
<td class=kL>1:7</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>5:6</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=br>44:74</td><td class=br>-30</td>
<td class=bc>7 - 3 - 13</td>
<td class=br><strong>17</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2001&x=-409&p=Gl%20Storozhenko">Gl Storozhenko</a></td><td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>3:4 K</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>3:3 K</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>55:63</td><td class=br>-8</td>
<td class=bc>5 - 5 - 13</td>
<td class=br><strong>15</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1033&x=-409&p=Si%20Thomas">Si Thomas</a></td><td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kW>3:2 K</td>
<td class=kL>3:6</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kW>6:0</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>4:3 K</td>
<td class=br>50:69</td><td class=br>-19</td>
<td class=bc>6 - 3 - 14</td>
<td class=br><strong>15</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=176&x=-409&p=Zd%20Lopaur">Zd Lopaur</a></td><td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kW>9:3</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kL>4:5</td>
<td class=kW>5:0</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2 K</td>
<td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kT>3:3 K</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=br>68:75</td><td class=br>-7</td>
<td class=bc>5 - 4 - 14</td>
<td class=br><strong>14</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=547&x=-409&p=To%20Lahu%C4%8Dk%C3%BD">To Lahučký</a></td><td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>6:7</td>
<td class=kL>2:6</td>
<td class=kW>2:1 K</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kW>3:0 K</td>
<td class=kL>0:4</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=br>48:74</td><td class=br>-26</td>
<td class=bc>6 - 1 - 16</td>
<td class=br><strong>13</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2098&x=-409&p=Ni%20Lyksholm">Ni Lyksholm</a></td><td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kL>3:6 K</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>0:7</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>7:5</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>3:4 K</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=br>43:86</td><td class=br>-43</td>
<td class=bc>3 - 2 - 18</td>
<td class=br><strong>8</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>To Lahučký</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ja Obadič</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Sa Hellstrom</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ti Varga</td><td class=bc>-</td><td class=blW>La Metsala</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 3 K</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Sa Hellstrom</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ja Obadič</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ha Gals</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Ti Varga</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>La Metsala</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Sa Hellstrom</td><td class=bc>2 : 5 K</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ni Lyksholm</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>7 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>La Metsala</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>2 : 0 K</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ja Obadič</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ha Gals</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ti Varga</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Ja Obadič</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ha Gals</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>La Metsala</td><td class=bc>0 : 4 K</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Sa Hellstrom</td><td class=bc>2 : 1 K</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>7 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>6 : 2 K</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Sa Hellstrom</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>To Lahučký</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ja Obadič</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ha Gals</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ti Varga</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>La Metsala</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Ha Gals</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>La Metsala</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Sa Hellstrom</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=blW>Ja Obadič</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ha Gals</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ti Varga</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Sa Hellstrom</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>La Metsala</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Sa Hellstrom</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=blW>Ha Gals</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>2 : 5 K</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>La Metsala</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Sa Hellstrom</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>La Metsala</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>2 : 1 K</tr></td>
<tr><td class=brW>Sa Hellstrom</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Ja Obadič</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>4 : 2 K</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ha Gals</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ti Varga</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>4 : 2 K</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ni Lyksholm</td><td class=bc>-</td><td class=bl>La Metsala</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>3 : 4 K</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Sa Hellstrom</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ha Gals</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ti Varga</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>La Metsala</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Sa Hellstrom</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Ha Gals</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>La Metsala</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>3 : 3 K</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Ja Obadič</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Sa Hellstrom</td><td class=bc>-</td><td class=blW>Ha Gals</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ti Varga</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>La Metsala</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Sa Hellstrom</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Ha Gals</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=blW>To Lahučký</td><td class=bc>1 : 2 K</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>La Metsala</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>La Metsala</td><td class=bc>-</td><td class=bl>Sa Hellstrom</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 2 K</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>4 : 1 K</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>To Lahučký</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>To Lahučký</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>3 : 0 K</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=bl>La Metsala</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Sa Hellstrom</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Sa Hellstrom</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>9 : 3</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>3 : 4 K</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Ti Varga</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>La Metsala</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=blW>Ha Gals</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>La Metsala</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Sa Hellstrom</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Ja Obadič</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>6 : 3 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>To Lahučký</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=blW>La Metsala</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ja Obadič</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=blW>La Metsala</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Sa Hellstrom</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ni Lyksholm</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=brW>Sa Hellstrom</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>3 : 4 K</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=blW>Ti Varga</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>2 : 1 K</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=bl>La Metsala</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Sa Hellstrom</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ti Varga</td><td class=bc>1 : 3 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>26</td></tr>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>4 : 2 K</tr></td>
<tr><td class=brW>Ha Gals</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>3 : 0 K</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>La Metsala</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>27</td></tr>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Sa Hellstrom</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>3 : 4 K</tr></td>
<tr><td class=br>Ha Gals</td><td class=bc>-</td><td class=blW>La Metsala</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>28</td></tr>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=blW>Sa Hellstrom</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>6 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
