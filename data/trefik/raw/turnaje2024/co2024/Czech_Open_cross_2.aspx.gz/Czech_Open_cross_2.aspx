<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2024">Czech Open</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2090&x=-409&p=Ja%20Kalnevics">Ja Kalnevics</a></td><td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=kW>5:0</td>
<td class=kW>10:0</td>
<td class=br>77:20</td><td class=br>+57</td>
<td class=bc>16 - 3 - 1</td>
<td class=br><strong>35</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1761&x=-409&p=Ra%20Kalnin%C5%A1">Ra Kalninš</a></td><td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kT>5:5</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>12:1</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>8:0</td>
<td class=kW>11:0</td>
<td class=kW>7:2</td>
<td class=kW>12:1</td>
<td class=br>116:38</td><td class=br>+78</td>
<td class=bc>17 - 1 - 2</td>
<td class=br><strong>35</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1518&x=-409&p=Ol%20Korabel">Ol Korabel</a></td><td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>2:0</td>
<td class=kL>3:5</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=kW>10:0</td>
<td class=kW>6:0</td>
<td class=kW>8:4</td>
<td class=kW>10:1</td>
<td class=kW>9:1</td>
<td class=kW>10:1</td>
<td class=kW>9:0</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=br>116:25</td><td class=br>+91</td>
<td class=bc>17 - 0 - 3</td>
<td class=br><strong>34</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1815&x=-409&p=An%20Bo%C5%BEi%C4%8D">An Božič</a></td><td class=kL>0:2</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>7:3</td>
<td class=kW>6:0</td>
<td class=kW>8:3</td>
<td class=kW>7:0</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=br>81:34</td><td class=br>+47</td>
<td class=bc>15 - 0 - 5</td>
<td class=br><strong>30</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=850&x=-409&p=Im%20Bla%C5%A1ko">Im Blaško</a></td><td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>11:2</td>
<td class=br>77:35</td><td class=br>+42</td>
<td class=bc>14 - 2 - 4</td>
<td class=br><strong>30</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2112&x=-409&p=Ed%20Kaneps">Ed Kaneps</a></td><td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>1:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=kW>3:1</td>
<td class=kW>10:1</td>
<td class=br>68:31</td><td class=br>+37</td>
<td class=bc>14 - 1 - 5</td>
<td class=br><strong>29</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1&x=-409&p=Pa%20Ple%C5%A1%C3%A1k">Pa Plešák</a></td><td class=kL>1:3</td>
<td class=kT>5:5</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>2:7</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>9:0</td>
<td class=kW>5:0</td>
<td class=kW>9:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>10:2</td>
<td class=br>85:42</td><td class=br>+43</td>
<td class=bc>12 - 4 - 4</td>
<td class=br><strong>28</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2105&x=-409&p=Ro%20Livmanis">Ro Livmanis</a></td><td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kT>5:5</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>4:3</td>
<td class=kW>5:4</td>
<td class=kW>6:3</td>
<td class=br>67:49</td><td class=br>+18</td>
<td class=bc>12 - 2 - 6</td>
<td class=br><strong>26</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1977&x=-409&p=Ti%20Dion">Ti Dion</a></td><td class=kL>2:5</td>
<td class=kL>3:6</td>
<td class=kL>2:7</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>8:2</td>
<td class=kW>3:1</td>
<td class=kW>7:3</td>
<td class=kW>8:2</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=br>85:56</td><td class=br>+29</td>
<td class=bc>12 - 1 - 7</td>
<td class=br><strong>25</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1268&x=-409&p=Da%20Dvo%C5%99%C3%A1%C4%8Dek">Da Dvořáček</a></td><td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>3:5</td>
<td class=kW>5:3</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=kW>11:0</td>
<td class=br>70:50</td><td class=br>+20</td>
<td class=bc>12 - 0 - 8</td>
<td class=br><strong>24</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=101&x=-409&p=Mi%20Kubica">Mi Kubica</a></td><td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=br>55:59</td><td class=br>-4</td>
<td class=bc>9 - 2 - 9</td>
<td class=br><strong>20</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2089&x=-409&p=Ju%20Itkonen">Ju Itkonen</a></td><td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>8:2</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=br>53:51</td><td class=br>+2</td>
<td class=bc>8 - 2 - 10</td>
<td class=br><strong>18</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2091&x=-409&p=Ma%20Kyllergard">Ma Kyllergard</a></td><td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>0:10</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kL>0:2</td>
<td class=kL>2:7</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kW>10:0</td>
<td class=br>49:57</td><td class=br>-8</td>
<td class=bc>7 - 3 - 10</td>
<td class=br><strong>17</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>D</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1917&x=-409&p=Fr%20Rasche">Fr Rasche</a></td><td class=kL>0:2</td>
<td class=kL>1:12</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kW>7:3</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kW>9:2</td>
<td class=br>53:77</td><td class=br>-24</td>
<td class=bc>7 - 2 - 11</td>
<td class=br><strong>16</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=108&x=-409&p=Ro%20Hejda">Ro Hejda</a></td><td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kL>4:8</td>
<td class=kL>3:7</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kT>2:2</td>
<td class=kT>5:5</td>
<td class=kL>1:7</td>
<td class=kW>5:3</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kW>7:1</td>
<td class=br>69:77</td><td class=br>-8</td>
<td class=bc>6 - 4 - 10</td>
<td class=br><strong>16</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>E</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1871&x=-409&p=Mi%20L%C3%A9vy">Mi Lévy</a></td><td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kL>1:10</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>0:9</td>
<td class=kL>1:5</td>
<td class=kL>2:8</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>12:0</td>
<td class=br>46:91</td><td class=br>-45</td>
<td class=bc>4 - 2 - 14</td>
<td class=br><strong>10</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>E</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=216&x=-409&p=Ro%20Vom%C3%A1%C4%8Dka">Ro Vomáčka</a></td><td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kL>1:9</td>
<td class=kL>3:8</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>4:5</td>
<td class=kL>2:8</td>
<td class=kL>2:5</td>
<td class=kW>1:0</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>38:87</td><td class=br>-49</td>
<td class=bc>3 - 3 - 14</td>
<td class=br><strong>9</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>F</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2046&x=-409&p=Ma%20Voj%C3%A1%C4%8Dek">Ma Vojáček</a></td><td class=kL>1:3</td>
<td class=kL>0:8</td>
<td class=kL>1:10</td>
<td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>1:9</td>
<td class=kL>0:6</td>
<td class=kL>3:7</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>3:7</td>
<td class=kL>3:6</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=br>33:94</td><td class=br>-61</td>
<td class=bc>3 - 3 - 14</td>
<td class=br><strong>9</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>F</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1957&x=-409&p=Er%20Bernhauser">Er Bernhauser</a></td><td class=kL>0:7</td>
<td class=kL>0:11</td>
<td class=kL>0:9</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kL>0:7</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>2:8</td>
<td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>3:6</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>11:1</td>
<td class=br>45:101</td><td class=br>-56</td>
<td class=bc>2 - 2 - 16</td>
<td class=br><strong>6</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>G</td><td class=d>20.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1076&x=-409&p=Mi%20Zeman">Mi Zeman</a></td><td class=kL>0:5</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=br>26:88</td><td class=br>-62</td>
<td class=bc>1 - 1 - 18</td>
<td class=br><strong>3</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>G</td><td class=d>21.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2107&x=-409&p=Os%20Tabara">Os Tabara</a></td><td class=kL>0:10</td>
<td class=kL>1:12</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>2:11</td>
<td class=kL>1:10</td>
<td class=kL>2:10</td>
<td class=kL>3:6</td>
<td class=kL>0:7</td>
<td class=kL>0:11</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>0:10</td>
<td class=kL>2:9</td>
<td class=kL>1:7</td>
<td class=kL>0:12</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>1:11</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=br>16:163</td><td class=br>-147</td>
<td class=bc>0 - 0 - 20</td>
<td class=br><strong>0</strong></td><td class=d>21.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Ma Vojáček</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Os Tabara</td><td class=bc>11 : 0</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=blW>Fr Rasche</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ju Itkonen</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ja Kalnevics</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ed Kaneps</td><td class=bc>-</td><td class=bl>Ma Kyllergard</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Fr Rasche</td><td class=bc>-</td><td class=bl>Ju Itkonen</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Vojáček</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Os Tabara</td><td class=bc>-</td><td class=blW>Ro Hejda</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ja Kalnevics</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ma Kyllergard</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ro Hejda</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ed Kaneps</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Ma Kyllergard</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Ju Itkonen</td><td class=bc>-</td><td class=bl>Os Tabara</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ja Kalnevics</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ra Kalninš</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>5 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Ro Hejda</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ma Vojáček</td><td class=bc>-</td><td class=blW>Ju Itkonen</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Os Tabara</td><td class=bc>-</td><td class=blW>Ja Kalnevics</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>1 : 12</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ju Itkonen</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Ja Kalnevics</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Os Tabara</td><td class=bc>12 : 1</tr></td>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=blW>Fr Rasche</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ro Hejda</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Kyllergard</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Vojáček</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=bl>Ja Kalnevics</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ju Itkonen</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Os Tabara</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ro Livmanis</td><td class=bc>-</td><td class=bl>Ma Kyllergard</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Ju Itkonen</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ja Kalnevics</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ed Kaneps</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Os Tabara</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ma Kyllergard</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=bl>Ju Itkonen</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Ja Kalnevics</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Vojáček</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Os Tabara</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=bl>Ma Kyllergard</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>Ju Itkonen</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=bl>Ja Kalnevics</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>11 : 0</tr></td>
<tr><td class=br>Os Tabara</td><td class=bc>-</td><td class=blW>Ma Kyllergard</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Ju Itkonen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=blW>Ja Kalnevics</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Ro Hejda</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Os Tabara</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>0 : 12</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Ju Itkonen</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Ja Kalnevics</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ma Vojáček</td><td class=bc>-</td><td class=bl>Ma Kyllergard</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Ja Kalnevics</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ma Kyllergard</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ro Livmanis</td><td class=bc>-</td><td class=bl>Os Tabara</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=blW>Ju Itkonen</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Os Tabara</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 10</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Vojáček</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=bl>Ma Kyllergard</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=blW>Ja Kalnevics</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ma Kyllergard</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>Ma Kyllergard</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Fr Rasche</td><td class=bc>-</td><td class=bl>Os Tabara</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Ju Itkonen</td><td class=bc>-</td><td class=blW>Ja Kalnevics</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ma Vojáček</td><td class=bc>-</td><td class=blW>Fr Rasche</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ju Itkonen</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>4 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Ma Kyllergard</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ro Livmanis</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ed Kaneps</td><td class=bc>-</td><td class=bl>Ju Itkonen</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>Ro Vomáčka</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Os Tabara</td><td class=bc>-</td><td class=blW>Ma Vojáček</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ja Kalnevics</td><td class=bc>-</td><td class=bl>Ra Kalninš</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>4 : 8</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Ma Kyllergard</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ro Vomáčka</td><td class=bc>-</td><td class=bl>Os Tabara</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Fr Rasche</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Kyllergard</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Ro Livmanis</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Fr Rasche</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ja Kalnevics</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ju Itkonen</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Vojáček</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ra Kalninš</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ja Kalnevics</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ju Itkonen</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=blW>Ma Kyllergard</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Os Tabara</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Er Bernhauser</td><td class=bc>-</td><td class=bl>Os Tabara</td><td class=bc>11 : 1</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Ro Hejda</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ja Kalnevics</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ju Itkonen</td><td class=bc>-</td><td class=blW>Ma Kyllergard</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ma Vojáček</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=brW>Ro Livmanis</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Os Tabara</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>2 : 11</tr></td>
<tr><td class=brW>Ma Vojáček</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ed Kaneps</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ro Vomáčka</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ja Kalnevics</td><td class=bc>-</td><td class=bl>Ma Kyllergard</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ju Itkonen</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>Os Tabara</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>26</td></tr>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Os Tabara</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ma Vojáček</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Ma Kyllergard</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ja Kalnevics</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ro Livmanis</td><td class=bc>-</td><td class=bl>Ju Itkonen</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>27</td></tr>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Er Bernhauser</td><td class=bc>0 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
