<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2024">Czech Open</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 8</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1784&x=-409&p=Ma%20Klippen">Ma Klippen</a></td><td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kW>6:4</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=kW>4:0</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>8:0</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=kW>8:2</td>
<td class=br>96:26</td><td class=br>+70</td>
<td class=bc>18 - 0 - 1</td>
<td class=br><strong>36</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1477&x=-409&p=Mi%20Kobrle">Mi Kobrle</a></td><td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>9:0</td>
<td class=kW>8:3</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>8:3</td>
<td class=kW>10:2</td>
<td class=br>99:25</td><td class=br>+74</td>
<td class=bc>17 - 1 - 1</td>
<td class=br><strong>35</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1503&x=-409&p=Ve%20Huotelin">Ve Huotelin</a></td><td class=kW>5:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>12:1</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>8:2</td>
<td class=kW>5:2</td>
<td class=kW>8:0</td>
<td class=kW>6:2</td>
<td class=br>93:32</td><td class=br>+61</td>
<td class=bc>16 - 1 - 2</td>
<td class=br><strong>33</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=386&x=-409&p=Ku%20Sl%C3%A1dek">Ku Sládek</a></td><td class=kL>4:6</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kW>6:0</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>8:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>6:5</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kW>8:1</td>
<td class=br>80:42</td><td class=br>+38</td>
<td class=bc>14 - 2 - 3</td>
<td class=br><strong>30</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=567&x=-409&p=Kr%20Lebl">Kr Lebl</a></td><td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kW>7:1</td>
<td class=kW>4:2</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=br>62:26</td><td class=br>+36</td>
<td class=bc>13 - 4 - 2</td>
<td class=br><strong>30</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1193&x=-409&p=La%20Svensson">La Svensson</a></td><td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>8:1</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kW>5:3</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kL>0:2</td>
<td class=kW>7:0</td>
<td class=kW>7:0</td>
<td class=br>58:36</td><td class=br>+22</td>
<td class=bc>10 - 2 - 7</td>
<td class=br><strong>22</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2092&x=-409&p=Ar%20Tseluiko">Ar Tseluiko</a></td><td class=kL>1:4</td>
<td class=kL>0:9</td>
<td class=kL>2:6</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>7:0</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=br>57:54</td><td class=br>+3</td>
<td class=bc>10 - 2 - 7</td>
<td class=br><strong>22</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1979&x=-409&p=Ga%20Bohinc">Ga Bohinc</a></td><td class=kL>0:8</td>
<td class=kL>3:8</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kW>6:1</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=br>58:46</td><td class=br>+12</td>
<td class=bc>9 - 3 - 7</td>
<td class=br><strong>21</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1622&x=-409&p=He%20Petuch">He Petuch</a></td><td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:8</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>7:3</td>
<td class=kW>8:0</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kW>5:2</td>
<td class=br>56:56</td><td class=br>0</td>
<td class=bc>9 - 2 - 8</td>
<td class=br><strong>20</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1065&x=-409&p=Kr%20Herold">Kr Herold</a></td><td class=kL>3:7</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=br>61:50</td><td class=br>+11</td>
<td class=bc>9 - 1 - 9</td>
<td class=br><strong>19</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1579&x=-409&p=Vi%20Henttonen">Vi Henttonen</a></td><td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>2:8</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kT>0:0</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kW>6:0</td>
<td class=kW>7:1</td>
<td class=kW>4:3</td>
<td class=br>58:56</td><td class=br>+2</td>
<td class=bc>7 - 4 - 8</td>
<td class=br><strong>18</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1709&x=-409&p=Mi%20Bla%C5%BEek">Mi Blažek</a></td><td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=br>57:59</td><td class=br>-2</td>
<td class=bc>8 - 1 - 10</td>
<td class=br><strong>17</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=227&x=-409&p=Mi%20Ma%C5%A1ika">Mi Mašika</a></td><td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>1:12</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>3:7</td>
<td class=kL>1:4</td>
<td class=kT>0:0</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=br>40:62</td><td class=br>-22</td>
<td class=bc>7 - 2 - 10</td>
<td class=br><strong>16</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>D</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2014&x=-409&p=Ma%20Hlava%C4%8Dka">Ma Hlavačka</a></td><td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>2:7</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=br>39:69</td><td class=br>-30</td>
<td class=bc>5 - 3 - 11</td>
<td class=br><strong>13</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1657&x=-409&p=Jo%20Perkner">Jo Perkner</a></td><td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kW>6:2</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>8:3</td>
<td class=kT>5:5</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=br>50:66</td><td class=br>-16</td>
<td class=bc>5 - 3 - 11</td>
<td class=br><strong>13</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>E</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=818&x=-409&p=Ro%20Je%C5%BE">Ro Jež</a></td><td class=kL>2:6</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>5:6</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kL>3:8</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=br>49:74</td><td class=br>-25</td>
<td class=bc>5 - 1 - 13</td>
<td class=br><strong>11</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>E</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=318&x=-409&p=Ji%20V%C3%A1cha">Ji Vácha</a></td><td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>2:8</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kW>5:3</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kT>5:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>8:1</td>
<td class=kW>5:2</td>
<td class=br>48:76</td><td class=br>-28</td>
<td class=bc>4 - 2 - 13</td>
<td class=br><strong>10</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>F</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2096&x=-409&p=Vo%20Kvasnikov">Vo Kvasnikov</a></td><td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>0:7</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=br>38:76</td><td class=br>-38</td>
<td class=bc>3 - 4 - 12</td>
<td class=br><strong>10</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>F</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2101&x=-409&p=Ge%20Brunner">Ge Brunner</a></td><td class=kL>0:7</td>
<td class=kL>3:8</td>
<td class=kL>0:8</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kL>0:7</td>
<td class=kW>5:3</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>1:8</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>22:104</td><td class=br>-82</td>
<td class=bc>2 - 0 - 17</td>
<td class=br><strong>4</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>G</td><td class=d>20.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2004&x=-409&p=Ur%20Me%C5%BEek">Ur Mežek</a></td><td class=kL>2:8</td>
<td class=kL>2:10</td>
<td class=kL>2:6</td>
<td class=kL>1:8</td>
<td class=kL>2:6</td>
<td class=kL>0:7</td>
<td class=kL>2:7</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>1:7</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>1:7</td>
<td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>26:112</td><td class=br>-86</td>
<td class=bc>0 - 0 - 19</td>
<td class=br><strong>0</strong></td><td class=d>20.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ge Brunner</td><td class=bc>-</td><td class=blW>La Svensson</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ma Hlavačka</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Mi Mašika</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Ar Tseluiko</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>La Svensson</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Ge Brunner</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ur Mežek</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>La Svensson</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ge Brunner</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>La Svensson</td><td class=bc>1 : 8</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ar Tseluiko</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ur Mežek</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ga Bohinc</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ge Brunner</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>La Svensson</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Ar Tseluiko</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ge Brunner</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ur Mežek</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Ge Brunner</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ur Mežek</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ge Brunner</td><td class=bc>-</td><td class=blW>Ma Hlavačka</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>La Svensson</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>La Svensson</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ma Hlavačka</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ga Bohinc</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Ge Brunner</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>4 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ur Mežek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 10</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>La Svensson</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Ar Tseluiko</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ge Brunner</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ar Tseluiko</td><td class=bc>-</td><td class=bl>Ge Brunner</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>12 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ur Mežek</td><td class=bc>-</td><td class=blW>Ma Hlavačka</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ge Brunner</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>La Svensson</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Ar Tseluiko</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>La Svensson</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Ge Brunner</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ge Brunner</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ur Mežek</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>Ge Brunner</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Ar Tseluiko</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>La Svensson</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Hlavačka</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ge Brunner</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Mi Mašika</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ar Tseluiko</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>La Svensson</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ur Mežek</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Ga Bohinc</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ge Brunner</td><td class=bc>8 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ge Brunner</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ar Tseluiko</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>La Svensson</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ur Mežek</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Ge Brunner</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ar Tseluiko</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>6 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ga Bohinc</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Ge Brunner</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>La Svensson</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Ur Mežek</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>7 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
