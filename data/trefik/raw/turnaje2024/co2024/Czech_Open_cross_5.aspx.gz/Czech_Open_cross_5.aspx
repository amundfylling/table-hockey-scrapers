<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2024">Czech Open</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 5</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2024&x=-409&p=Em%20Liepins">Em Liepins</a></td><td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>6:4</td>
<td class=kW>8:1</td>
<td class=kW>6:1</td>
<td class=kW>8:1</td>
<td class=kW>9:0</td>
<td class=br>91:36</td><td class=br>+55</td>
<td class=bc>17 - 0 - 2</td>
<td class=br><strong>34</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1648&x=-409&p=Sa%20Lagzdins">Sa Lagzdins</a></td><td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>9:1</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=br>84:35</td><td class=br>+49</td>
<td class=bc>15 - 1 - 3</td>
<td class=br><strong>31</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1406&x=-409&p=Ja%20Mat%C3%BDsek">Ja Matýsek</a></td><td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>13:2</td>
<td class=br>71:28</td><td class=br>+43</td>
<td class=bc>14 - 2 - 3</td>
<td class=br><strong>30</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1786&x=-409&p=Am%20Fylling">Am Fylling</a></td><td class=kL>3:6</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kL>0:1</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>10:1</td>
<td class=kW>4:3</td>
<td class=kW>8:2</td>
<td class=kW>7:0</td>
<td class=br>76:32</td><td class=br>+44</td>
<td class=bc>13 - 2 - 4</td>
<td class=br><strong>28</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=993&x=-409&p=Ji%20Chyl%C3%ADk%20ml.">Ji Chylík ml.</a></td><td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=br>58:28</td><td class=br>+30</td>
<td class=bc>13 - 2 - 4</td>
<td class=br><strong>28</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1203&x=-409&p=Da%20Mitro">Da Mitro</a></td><td class=kL>3:5</td>
<td class=kL>0:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>6:4</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>10:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>8:3</td>
<td class=kW>5:2</td>
<td class=kW>8:0</td>
<td class=br>82:40</td><td class=br>+42</td>
<td class=bc>12 - 3 - 4</td>
<td class=br><strong>27</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=961&x=-409&p=Mi%20Bo%C5%A1t%C3%ADk">Mi Boštík</a></td><td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=br>60:34</td><td class=br>+26</td>
<td class=bc>11 - 4 - 4</td>
<td class=br><strong>26</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=40&x=-409&p=Da%20Mat%C3%BDsek">Da Matýsek</a></td><td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=br>50:39</td><td class=br>+11</td>
<td class=bc>8 - 8 - 3</td>
<td class=br><strong>24</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2082&x=-409&p=La%20Metsala">La Metsala</a></td><td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kW>2:0</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kL>0:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=br>49:29</td><td class=br>+20</td>
<td class=bc>10 - 2 - 7</td>
<td class=br><strong>22</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=18&x=-409&p=An%20%C5%A0ur%C3%BDn">An Šurýn</a></td><td class=kL>1:6</td>
<td class=kL>1:9</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=kW>1:0</td>
<td class=kW>6:0</td>
<td class=kW>8:1</td>
<td class=kW>8:2</td>
<td class=kW>10:1</td>
<td class=br>59:41</td><td class=br>+18</td>
<td class=bc>10 - 2 - 7</td>
<td class=br><strong>22</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1978&x=-409&p=My%20Verbytskyy">My Verbytskyy</a></td><td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>4:6</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=br>44:51</td><td class=br>-7</td>
<td class=bc>9 - 2 - 8</td>
<td class=br><strong>20</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=53&x=-409&p=V%C3%A1%20Pikl">Vá Pikl</a></td><td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kL>0:6</td>
<td class=kT>0:0</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>10:1</td>
<td class=br>44:43</td><td class=br>+1</td>
<td class=bc>6 - 6 - 7</td>
<td class=br><strong>18</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2017&x=-409&p=Ka%20Pirumshoeva">Ka Pirumshoeva</a></td><td class=kW>4:3</td>
<td class=kL>0:6</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=br>29:50</td><td class=br>-21</td>
<td class=bc>7 - 4 - 8</td>
<td class=br><strong>18</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>D</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1291&x=-409&p=Ma%20Dion">Ma Dion</a></td><td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kT>0:0</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=br>44:53</td><td class=br>-9</td>
<td class=bc>6 - 1 - 12</td>
<td class=br><strong>13</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=41&x=-409&p=Da%20Hrachovec">Da Hrachovec</a></td><td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>1:10</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kL>1:5</td>
<td class=kW>6:3</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=br>41:63</td><td class=br>-22</td>
<td class=bc>5 - 2 - 12</td>
<td class=br><strong>12</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>E</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1058&x=-409&p=Fr%20Marek">Fr Marek</a></td><td class=kL>4:6</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>7:0</td>
<td class=br>35:50</td><td class=br>-15</td>
<td class=bc>3 - 3 - 13</td>
<td class=br><strong>9</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>E</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1941&x=-409&p=Ja%20Kopeck%C3%BD">Ja Kopecký</a></td><td class=kL>1:8</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>1:10</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kT>0:0</td>
<td class=br>22:77</td><td class=br>-55</td>
<td class=bc>2 - 2 - 15</td>
<td class=br><strong>6</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>F</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2044&x=-409&p=Ja%20Tom%C3%A1%C5%A1t%C3%ADk">Ja Tomáštík</a></td><td class=kL>1:6</td>
<td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>3:8</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=br>38:83</td><td class=br>-45</td>
<td class=bc>3 - 0 - 16</td>
<td class=br><strong>6</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>F</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1869&x=-409&p=Pe%20Klazar">Pe Klazar</a></td><td class=kL>1:8</td>
<td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kL>2:8</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kL>2:8</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=br>30:88</td><td class=br>-58</td>
<td class=bc>2 - 1 - 16</td>
<td class=br><strong>5</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>G</td><td class=d>20.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2106&x=-409&p=Ol%20Tabara">Ol Tabara</a></td><td class=kL>0:9</td>
<td class=kL>2:4</td>
<td class=kL>2:13</td>
<td class=kL>0:7</td>
<td class=kL>0:7</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>1:10</td>
<td class=kL>0:5</td>
<td class=kL>1:10</td>
<td class=kL>0:1</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>0:7</td>
<td class=kT>0:0</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=br>9:116</td><td class=br>-107</td>
<td class=bc>0 - 1 - 18</td>
<td class=br><strong>1</strong></td><td class=d>20.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ja Tomáštík</td><td class=bc>-</td><td class=blW>Ma Dion</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Ol Tabara</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>La Metsala</td><td class=bc>-</td><td class=bl>Sa Lagzdins</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ja Tomáštík</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ol Tabara</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ma Dion</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>La Metsala</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Em Liepins</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ol Tabara</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ja Tomáštík</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ma Dion</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>La Metsala</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Em Liepins</td><td class=bc>-</td><td class=blW>Sa Lagzdins</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ka Pirumshoeva</td><td class=bc>-</td><td class=bl>Ol Tabara</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ja Tomáštík</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Ma Dion</td><td class=bc>-</td><td class=blW>La Metsala</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Em Liepins</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ol Tabara</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>La Metsala</td><td class=bc>-</td><td class=blW>Ja Tomáštík</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ja Tomáštík</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Sa Lagzdins</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>La Metsala</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ol Tabara</td><td class=bc>13 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>La Metsala</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Dion</td><td class=bc>-</td><td class=blW>Em Liepins</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Ja Kopecký</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>La Metsala</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ol Tabara</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Ja Tomáštík</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Sa Lagzdins</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Ma Dion</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Ol Tabara</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ja Tomáštík</td><td class=bc>-</td><td class=blW>Ja Kopecký</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Dion</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Em Liepins</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Sa Lagzdins</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ol Tabara</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ja Tomáštík</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>La Metsala</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>La Metsala</td><td class=bc>-</td><td class=blW>Em Liepins</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ka Pirumshoeva</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Ol Tabara</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ja Tomáštík</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Dion</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Sa Lagzdins</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>La Metsala</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ka Pirumshoeva</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ol Tabara</td><td class=bc>-</td><td class=blW>Ma Dion</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Ja Tomáštík</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Em Liepins</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ja Tomáštík</td><td class=bc>-</td><td class=bl>Ol Tabara</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>La Metsala</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Dion</td><td class=bc>-</td><td class=blW>Ka Pirumshoeva</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>La Metsala</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Em Liepins</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Dion</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ka Pirumshoeva</td><td class=bc>-</td><td class=bl>Ja Tomáštík</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ol Tabara</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 10</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Sa Lagzdins</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Em Liepins</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>La Metsala</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ja Tomáštík</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ol Tabara</td><td class=bc>10 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ja Tomáštík</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ol Tabara</td><td class=bc>-</td><td class=blW>La Metsala</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ma Dion</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Ma Dion</td><td class=bc>-</td><td class=blW>Sa Lagzdins</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ja Tomáštík</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ol Tabara</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>La Metsala</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 10</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ma Dion</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Ja Tomáštík</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ol Tabara</td><td class=bc>-</td><td class=blW>Em Liepins</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>La Metsala</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ma Dion</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ja Tomáštík</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=bl>Ol Tabara</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Sa Lagzdins</td><td class=bc>1 : 9</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Em Liepins</td><td class=bc>-</td><td class=blW>Ka Pirumshoeva</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>La Metsala</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ma Dion</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Ja Tomáštík</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ol Tabara</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Ka Pirumshoeva</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Em Liepins</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>La Metsala</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
