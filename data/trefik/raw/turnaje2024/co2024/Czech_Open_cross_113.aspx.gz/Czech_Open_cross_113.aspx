<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2024">Czech Open</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group G</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1749&x=-409&p=Id%20Gripp">Id Gripp</a></td><td class=kx>*</td>
<td class=kW>1:0 + 3:1</td>
<td class=kT>2:2 + 0:1</td>
<td class=kW>2:1 + 3:1</td>
<td class=kW>2:0 + 2:1</td>
<td class=kW>3:0 + 2:4</td>
<td class=kW>3:2 + 3:2</td>
<td class=kW>4:1 + 4:1</td>
<td class=kT>1:1 + 4:2</td>
<td class=kL>2:3 + 2:3</td>
<td class=kW>5:1 + 4:0</td>
<td class=br>52:27</td><td class=br>+25</td>
<td class=bc>14 - 2 - 4</td>
<td class=br><strong>30</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2038&x=-409&p=Mi%20Moravec">Mi Moravec</a></td><td class=kL>0:1 + 1:3</td>
<td class=kx>*</td>
<td class=kW>6:1 + 3:2</td>
<td class=kL>0:1 + 4:0</td>
<td class=kW>5:0 + 5:0</td>
<td class=kT>2:2 + 3:3</td>
<td class=kW>5:2 + 5:2</td>
<td class=kW>1:0 + 3:3</td>
<td class=kT>3:3 + 3:3</td>
<td class=kW>4:1 + 3:2</td>
<td class=kW>7:0 + 5:0</td>
<td class=br>68:29</td><td class=br>+39</td>
<td class=bc>12 - 5 - 3</td>
<td class=br><strong>29</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1076&x=-409&p=Mi%20Zeman">Mi Zeman</a></td><td class=kT>2:2 + 1:0</td>
<td class=kL>1:6 + 2:3</td>
<td class=kx>*</td>
<td class=kW>2:0 + 2:1</td>
<td class=kL>1:2 + 3:1</td>
<td class=kW>3:1 + 2:2</td>
<td class=kW>8:1 + 4:3</td>
<td class=kW>4:3 + 2:5</td>
<td class=kT>0:0 + 5:1</td>
<td class=kW>6:2 + 6:1</td>
<td class=kW>7:1 + 4:3</td>
<td class=br>65:38</td><td class=br>+27</td>
<td class=bc>13 - 3 - 4</td>
<td class=br><strong>29</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1959&x=-409&p=On%20Chlebo">On Chlebo</a></td><td class=kL>1:2 + 1:3</td>
<td class=kW>1:0 + 0:4</td>
<td class=kL>0:2 + 1:2</td>
<td class=kx>*</td>
<td class=kW>1:0 + 4:0</td>
<td class=kT>0:0 + 1:0</td>
<td class=kL>0:1 + 1:0</td>
<td class=kW>5:0 + 5:0</td>
<td class=kW>2:0 + 2:0</td>
<td class=kW>4:0 + 4:0</td>
<td class=kW>3:1 + 6:0</td>
<td class=br>42:15</td><td class=br>+27</td>
<td class=bc>13 - 1 - 6</td>
<td class=br><strong>27</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1430&x=-409&p=Da%20Kadlec">Da Kadlec</a></td><td class=kL>0:2 + 1:2</td>
<td class=kL>0:5 + 0:5</td>
<td class=kW>2:1 + 1:3</td>
<td class=kL>0:1 + 0:4</td>
<td class=kx>*</td>
<td class=kW>4:2 + 4:2</td>
<td class=kW>4:2 + 3:5</td>
<td class=kL>2:4 + 2:1</td>
<td class=kW>3:1 + 3:1</td>
<td class=kW>8:2 + 7:0</td>
<td class=kW>7:0 + 4:0</td>
<td class=br>55:43</td><td class=br>+12</td>
<td class=bc>11 - 0 - 9</td>
<td class=br><strong>22</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2019&x=-409&p=Pa%20Janou%C5%A1kovec">Pa Janouškovec</a></td><td class=kL>0:3 + 4:2</td>
<td class=kT>2:2 + 3:3</td>
<td class=kL>1:3 + 2:2</td>
<td class=kT>0:0 + 0:1</td>
<td class=kL>2:4 + 2:4</td>
<td class=kx>*</td>
<td class=kT>2:2 + 2:4</td>
<td class=kW>2:1 + 2:1</td>
<td class=kW>4:2 + 2:2</td>
<td class=kW>8:2 + 2:1</td>
<td class=kW>7:1 + 7:1</td>
<td class=br>54:41</td><td class=br>+13</td>
<td class=bc>8 - 6 - 6</td>
<td class=br><strong>22</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2004&x=-409&p=Ur%20Me%C5%BEek">Ur Mežek</a></td><td class=kL>2:3 + 2:3</td>
<td class=kL>2:5 + 2:5</td>
<td class=kL>1:8 + 3:4</td>
<td class=kW>1:0 + 0:1</td>
<td class=kL>2:4 + 5:3</td>
<td class=kT>2:2 + 4:2</td>
<td class=kx>*</td>
<td class=kT>2:2 + 2:2</td>
<td class=kW>4:2 + 4:2</td>
<td class=kW>4:1 + 4:1</td>
<td class=kW>1:0 + 4:1</td>
<td class=br>51:51</td><td class=br>0</td>
<td class=bc>9 - 3 - 8</td>
<td class=br><strong>21</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2107&x=-409&p=Os%20Tabara">Os Tabara</a></td><td class=kL>1:4 + 1:4</td>
<td class=kL>0:1 + 3:3</td>
<td class=kL>3:4 + 5:2</td>
<td class=kL>0:5 + 0:5</td>
<td class=kW>4:2 + 1:2</td>
<td class=kL>1:2 + 1:2</td>
<td class=kT>2:2 + 2:2</td>
<td class=kx>*</td>
<td class=kL>0:6 + 2:2</td>
<td class=kW>5:3 + 3:3</td>
<td class=kL>0:3 + 6:1</td>
<td class=br>40:58</td><td class=br>-18</td>
<td class=bc>4 - 5 - 11</td>
<td class=br><strong>13</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2106&x=-409&p=Ol%20Tabara">Ol Tabara</a></td><td class=kT>1:1 + 2:4</td>
<td class=kT>3:3 + 3:3</td>
<td class=kT>0:0 + 1:5</td>
<td class=kL>0:2 + 0:2</td>
<td class=kL>1:3 + 1:3</td>
<td class=kL>2:4 + 2:2</td>
<td class=kL>2:4 + 2:4</td>
<td class=kW>6:0 + 2:2</td>
<td class=kx>*</td>
<td class=kL>1:3 + 1:3</td>
<td class=kW>5:1 + 3:1</td>
<td class=br>38:50</td><td class=br>-12</td>
<td class=bc>3 - 6 - 11</td>
<td class=br><strong>12</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2108&x=-409&p=Jo%20Andreas">Jo Andreas</a></td><td class=kW>3:2 + 3:2</td>
<td class=kL>1:4 + 2:3</td>
<td class=kL>2:6 + 1:6</td>
<td class=kL>0:4 + 0:4</td>
<td class=kL>2:8 + 0:7</td>
<td class=kL>2:8 + 1:2</td>
<td class=kL>1:4 + 1:4</td>
<td class=kL>3:5 + 3:3</td>
<td class=kW>3:1 + 3:1</td>
<td class=kx>*</td>
<td class=kW>3:1 + 0:2</td>
<td class=br>34:77</td><td class=br>-43</td>
<td class=bc>5 - 1 - 14</td>
<td class=br><strong>11</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2037&x=-409&p=Be%20Ponert">Be Ponert</a></td><td class=kL>1:5 + 0:4</td>
<td class=kL>0:7 + 0:5</td>
<td class=kL>1:7 + 3:4</td>
<td class=kL>1:3 + 0:6</td>
<td class=kL>0:7 + 0:4</td>
<td class=kL>1:7 + 1:7</td>
<td class=kL>0:1 + 1:4</td>
<td class=kW>3:0 + 1:6</td>
<td class=kL>1:5 + 1:3</td>
<td class=kL>1:3 + 2:0</td>
<td class=kx>*</td>
<td class=br>18:88</td><td class=br>-70</td>
<td class=bc>2 - 0 - 18</td>
<td class=br><strong>4</strong></td><td class=d>11.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=blW>On Chlebo</td><td class=bc>0 : 1 + 4 : 0</tr></td>
<tr><td class=br>Jo Andreas</td><td class=bc>-</td><td class=blW>Os Tabara</td><td class=bc>3 : 5 + 3 : 3</tr></td>
<tr><td class=brW>Id Gripp</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>3 : 0 + 2 : 4</tr></td>
<tr><td class=br>Ol Tabara</td><td class=bc>-</td><td class=blW>Ur Mežek</td><td class=bc>2 : 4 + 2 : 4</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Be Ponert</td><td class=bc>7 : 1 + 4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Ur Mežek</td><td class=bc>0 : 1 + 1 : 0</tr></td>
<tr><td class=br>Be Ponert</td><td class=bc>-</td><td class=blW>Jo Andreas</td><td class=bc>1 : 3 + 2 : 0</tr></td>
<tr><td class=br>Os Tabara</td><td class=bc>-</td><td class=blW>Id Gripp</td><td class=bc>1 : 4 + 1 : 4</tr></td>
<tr><td class=brW>Pa Janouškovec</td><td class=bc>-</td><td class=bl>Ol Tabara</td><td class=bc>4 : 2 + 2 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Da Kadlec</td><td class=bc>1 : 2 + 3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Da Kadlec</td><td class=bc>-</td><td class=bl>Jo Andreas</td><td class=bc>8 : 2 + 7 : 0</tr></td>
<tr><td class=brW>Id Gripp</td><td class=bc>-</td><td class=bl>Be Ponert</td><td class=bc>5 : 1 + 4 : 0</tr></td>
<tr><td class=brW>Ol Tabara</td><td class=bc>-</td><td class=bl>Os Tabara</td><td class=bc>6 : 0 + 2 : 2</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>0 : 0 + 1 : 0</tr></td>
<tr><td class=brW>Mi Moravec</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>5 : 2 + 5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>2 : 2 + 3 : 3</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Id Gripp</td><td class=bc>0 : 2 + 1 : 2</tr></td>
<tr><td class=br>Be Ponert</td><td class=bc>-</td><td class=blW>Ol Tabara</td><td class=bc>1 : 5 + 1 : 3</tr></td>
<tr><td class=br>Os Tabara</td><td class=bc>-</td><td class=blW>On Chlebo</td><td class=bc>0 : 5 + 0 : 5</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Jo Andreas</td><td class=bc>6 : 2 + 6 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ur Mežek</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>2 : 2 + 4 : 2</tr></td>
<tr><td class=br>Ol Tabara</td><td class=bc>-</td><td class=blW>Da Kadlec</td><td class=bc>1 : 3 + 1 : 3</tr></td>
<tr><td class=brW>On Chlebo</td><td class=bc>-</td><td class=bl>Be Ponert</td><td class=bc>3 : 1 + 6 : 0</tr></td>
<tr><td class=brW>Mi Moravec</td><td class=bc>-</td><td class=bl>Os Tabara</td><td class=bc>1 : 0 + 3 : 3</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=bl>Id Gripp</td><td class=bc>2 : 2 + 1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Jo Andreas</td><td class=bc>-</td><td class=bl>Id Gripp</td><td class=bc>3 : 2 + 3 : 2</tr></td>
<tr><td class=br>Os Tabara</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>2 : 2 + 2 : 2</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>On Chlebo</td><td class=bc>0 : 1 + 0 : 4</tr></td>
<tr><td class=br>Be Ponert</td><td class=bc>-</td><td class=blW>Mi Moravec</td><td class=bc>0 : 7 + 0 : 5</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=bl>Ol Tabara</td><td class=bc>0 : 0 + 5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Jo Andreas</td><td class=bc>-</td><td class=bl>Ol Tabara</td><td class=bc>3 : 1 + 3 : 1</tr></td>
<tr><td class=br>Os Tabara</td><td class=bc>-</td><td class=blW>Pa Janouškovec</td><td class=bc>1 : 2 + 1 : 2</tr></td>
<tr><td class=brW>Mi Moravec</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>5 : 0 + 5 : 0</tr></td>
<tr><td class=brW>Ur Mežek</td><td class=bc>-</td><td class=bl>Be Ponert</td><td class=bc>1 : 0 + 4 : 1</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>2 : 0 + 2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Id Gripp</td><td class=bc>-</td><td class=bl>Ol Tabara</td><td class=bc>1 : 1 + 4 : 2</tr></td>
<tr><td class=br>Jo Andreas</td><td class=bc>-</td><td class=blW>On Chlebo</td><td class=bc>0 : 4 + 0 : 4</tr></td>
<tr><td class=br>Be Ponert</td><td class=bc>-</td><td class=blW>Pa Janouškovec</td><td class=bc>1 : 7 + 1 : 7</tr></td>
<tr><td class=brW>Da Kadlec</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>4 : 2 + 3 : 5</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Mi Moravec</td><td class=bc>1 : 6 + 2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Id Gripp</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>2 : 1 + 3 : 1</tr></td>
<tr><td class=brW>Mi Moravec</td><td class=bc>-</td><td class=bl>Jo Andreas</td><td class=bc>4 : 1 + 3 : 2</tr></td>
<tr><td class=brW>Be Ponert</td><td class=bc>-</td><td class=bl>Os Tabara</td><td class=bc>3 : 0 + 1 : 6</tr></td>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=blW>Da Kadlec</td><td class=bc>2 : 4 + 2 : 4</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>8 : 1 + 4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ol Tabara</td><td class=bc>-</td><td class=blW>On Chlebo</td><td class=bc>0 : 2 + 0 : 2</tr></td>
<tr><td class=brW>Id Gripp</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>1 : 0 + 3 : 1</tr></td>
<tr><td class=br>Jo Andreas</td><td class=bc>-</td><td class=blW>Ur Mežek</td><td class=bc>1 : 4 + 1 : 4</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Os Tabara</td><td class=bc>2 : 4 + 2 : 1</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>3 : 1 + 2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ol Tabara</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>3 : 3 + 3 : 3</tr></td>
<tr><td class=br>Ur Mežek</td><td class=bc>-</td><td class=blW>Id Gripp</td><td class=bc>2 : 3 + 2 : 3</tr></td>
<tr><td class=brW>Pa Janouškovec</td><td class=bc>-</td><td class=bl>Jo Andreas</td><td class=bc>8 : 2 + 2 : 1</tr></td>
<tr><td class=brW>Da Kadlec</td><td class=bc>-</td><td class=bl>Be Ponert</td><td class=bc>7 : 0 + 4 : 0</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Os Tabara</td><td class=bc>4 : 3 + 2 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
