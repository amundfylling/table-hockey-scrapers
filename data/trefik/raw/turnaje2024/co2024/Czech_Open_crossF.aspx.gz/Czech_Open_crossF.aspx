<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2023">Czech Open</a></span></h2></div></div></div></div><h3 align="right">Final Groups&nbsp;&nbsp;</h3>
<p><div align="center">
<div align=center><a href="Czech_Open_crossB.aspx#basic">Basic Groups</a><br>
<p class=v>Group A1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>25</td>
<td class=ic>26</td>
<td class=ic>27</td>
<td class=ic>28</td>
<td class=ic>29</td>
<td class=ic>30</td>
<td class=ic>31</td>
<td class=ic>32</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1838&x=-409&p=Ev%20Matantsev">Ev Matantsev</a></td><td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kW>4:1 K</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kL>4:5 K</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>8:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2 K</td>
<td class=kL>2:5</td>
<td class=kW>9:2</td>
<td class=kW>4:2</td>
<td class=kW>8:3</td>
<td class=kW>5:4 K</td>
<td class=kW>4:1</td>
<td class=kW>2:0 K</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kW>3:2 K</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=kT>5:5 K</td>
<td class=kW>6:2</td>
<td class=br>130:70</td><td class=br>+60</td>
<td class=bc>23 - 4 - 4</td>
<td class=br><strong>50</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1648&x=-409&p=Sa%20Lagzdins">Sa Lagzdins</a></td><td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>5:3 K</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kW>6:1 K</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kL>3:4 K</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kL>0:1</td>
<td class=kW>6:2 K</td>
<td class=kW>3:2 K</td>
<td class=kT>2:2</td>
<td class=kW>2:0 K</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kL>2:3</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>6:5</td>
<td class=kW>10:1</td>
<td class=br>116:59</td><td class=br>+57</td>
<td class=bc>22 - 3 - 6</td>
<td class=br><strong>47</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2024&x=-409&p=Em%20Liepins">Em Liepins</a></td><td class=kL>3:5</td>
<td class=kL>3:5 K</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kW>6:2</td>
<td class=kW>4:1 K</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>2:1 K</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>3:7</td>
<td class=kW>6:3 K</td>
<td class=kW>2:1 K</td>
<td class=kW>2:1</td>
<td class=kW>5:3 K</td>
<td class=kL>2:4</td>
<td class=kW>6:4</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kW>5:1 K</td>
<td class=kL>2:3</td>
<td class=kW>6:0</td>
<td class=kW>6:3</td>
<td class=kW>9:1</td>
<td class=kW>6:1</td>
<td class=br>125:74</td><td class=br>+51</td>
<td class=bc>21 - 2 - 8</td>
<td class=br><strong>44</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2111&x=-409&p=Ru%20Kamzols">Ru Kamzols</a></td><td class=kL>1:4 K</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kW>6:2 K</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>5:3 K</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>3:2 K</td>
<td class=kW>5:3</td>
<td class=kW>4:0 K</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=kW>3:2</td>
<td class=kW>4:1 K</td>
<td class=kL>2:6</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>6:3 K</td>
<td class=kW>8:3</td>
<td class=br>118:78</td><td class=br>+40</td>
<td class=bc>21 - 2 - 8</td>
<td class=br><strong>44</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2074&x=-409&p=Ma%20Jakseboga">Ma Jakseboga</a></td><td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kT>1:1 K</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kT>0:0</td>
<td class=kW>4:2 K</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kW>3:0 K</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>4:7</td>
<td class=kW>7:1 K</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>6:0 K</td>
<td class=kW>4:3</td>
<td class=kT>3:3 K</td>
<td class=kW>3:0</td>
<td class=kW>2:0 K</td>
<td class=br>94:61</td><td class=br>+33</td>
<td class=bc>16 - 9 - 6</td>
<td class=br><strong>41</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1649&x=-409&p=Ra%20Miglinieks">Ra Miglinieks</a></td><td class=kL>2:4</td>
<td class=kW>6:1</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kT>1:1 K</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kL>3:4 K</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kT>1:1 K</td>
<td class=kW>4:1</td>
<td class=kT>5:5</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>4:2 K</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>6:2 K</td>
<td class=kW>3:2</td>
<td class=kT>3:3 K</td>
<td class=kW>3:2</td>
<td class=kW>4:1 K</td>
<td class=br>93:72</td><td class=br>+21</td>
<td class=bc>14 - 9 - 8</td>
<td class=br><strong>37</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=993&x=-409&p=Ji%20Chyl%C3%ADk%20ml.">Ji Chylík ml.</a></td><td class=kW>3:1</td>
<td class=kL>1:6 K</td>
<td class=kL>1:4 K</td>
<td class=kL>4:5</td>
<td class=kW>4:1</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kW>1:0 K</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1 K</td>
<td class=kL>2:5 K</td>
<td class=kL>0:5</td>
<td class=kW>5:1 K</td>
<td class=kL>4:6</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>7:3</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kT>2:2 K</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=br>96:78</td><td class=br>+18</td>
<td class=bc>15 - 7 - 9</td>
<td class=br><strong>37</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2085&x=-409&p=He%20Prokuratovs">He Prokuratovs</a></td><td class=kW>5:4 K</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>2:6 K</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kW>5:0</td>
<td class=kT>3:3 K</td>
<td class=kW>1:0</td>
<td class=kL>2:6</td>
<td class=kW>4:1</td>
<td class=kL>3:7</td>
<td class=kW>4:1 K</td>
<td class=kW>5:2</td>
<td class=kL>1:4 K</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kW>5:2</td>
<td class=kW>2:1 K</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kW>3:1 K</td>
<td class=kW>5:2</td>
<td class=br>97:89</td><td class=br>+8</td>
<td class=bc>17 - 3 - 11</td>
<td class=br><strong>37</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2081&x=-409&p=Je%20Rekis">Je Rekis</a></td><td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>3:2 K</td>
<td class=kT>4:4 K</td>
<td class=kT>3:3</td>
<td class=kW>10:1 K</td>
<td class=kW>4:1</td>
<td class=kW>8:4</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>4:5 K</td>
<td class=kL>2:3</td>
<td class=kW>6:1 K</td>
<td class=kW>5:1 K</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kW>4:3 K</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=br>104:81</td><td class=br>+23</td>
<td class=bc>14 - 7 - 10</td>
<td class=br><strong>35</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1826&x=-409&p=Ol%20Blume">Ol Blume</a></td><td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kL>2:3 K</td>
<td class=kx>*</td>
<td class=kT>3:3 K</td>
<td class=kW>4:0</td>
<td class=kW>3:2 K</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>5:4</td>
<td class=kW>5:4</td>
<td class=kW>4:3 K</td>
<td class=kL>2:3</td>
<td class=kL>1:3 K</td>
<td class=kL>1:7 K</td>
<td class=kW>7:3</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kT>1:1 K</td>
<td class=kL>0:4</td>
<td class=kW>5:2</td>
<td class=kT>5:5</td>
<td class=br>96:85</td><td class=br>+11</td>
<td class=bc>16 - 3 - 12</td>
<td class=br><strong>35</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1872&x=-409&p=Pe%20Fuchs">Pe Fuchs</a></td><td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kL>2:4</td>
<td class=kT>4:4 K</td>
<td class=kT>3:3 K</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>9:3 K</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kW>2:0 K</td>
<td class=kW>6:4</td>
<td class=kW>5:2 K</td>
<td class=kL>1:5 K</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kT>3:3 K</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=br>97:86</td><td class=br>+11</td>
<td class=bc>14 - 7 - 10</td>
<td class=br><strong>35</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1406&x=-409&p=Ja%20Mat%C3%BDsek">Ja Matýsek</a></td><td class=kL>1:8</td>
<td class=kW>4:3 K</td>
<td class=kL>1:2 K</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>0:1 K</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>3:0 K</td>
<td class=kW>3:1 K</td>
<td class=kW>2:0</td>
<td class=kL>1:5 K</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3 K</td>
<td class=kW>6:2</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=br>70:68</td><td class=br>+2</td>
<td class=bc>14 - 7 - 10</td>
<td class=br><strong>35</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1766&x=-409&p=Al%20Silin%C5%A1">Al Silinš</a></td><td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kT>4:4</td>
<td class=kL>1:7</td>
<td class=kT>4:4</td>
<td class=kL>1:10 K</td>
<td class=kL>2:3 K</td>
<td class=kL>3:9 K</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>7:3</td>
<td class=kW>7:3</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kW>5:1 K</td>
<td class=kL>0:5</td>
<td class=kT>2:2 K</td>
<td class=kW>4:2 K</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kW>6:1 K</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=br>89:90</td><td class=br>-1</td>
<td class=bc>14 - 6 - 11</td>
<td class=br><strong>34</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1153&x=-409&p=Ot%20Pesala">Ot Pesala</a></td><td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>2:4 K</td>
<td class=kW>4:3 K</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>4:1 K</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kL>0:3 K</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kT>2:2 K</td>
<td class=kW>3:2</td>
<td class=kL>3:4 K</td>
<td class=kW>3:0</td>
<td class=kW>2:0 K</td>
<td class=br>71:73</td><td class=br>-2</td>
<td class=bc>13 - 7 - 11</td>
<td class=br><strong>33</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2076&x=-409&p=Ed%20Naglis">Ed Naglis</a></td><td class=kL>2:3 K</td>
<td class=kW>1:0</td>
<td class=kW>7:3</td>
<td class=kL>3:5 K</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3 K</td>
<td class=kL>4:8</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>3:4 K</td>
<td class=kL>2:3</td>
<td class=kT>2:2 K</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>5:2 K</td>
<td class=kW>6:1</td>
<td class=kL>4:5</td>
<td class=kW>5:0</td>
<td class=kL>1:3</td>
<td class=kW>8:0 K</td>
<td class=kW>5:3</td>
<td class=br>102:83</td><td class=br>+19</td>
<td class=bc>14 - 4 - 13</td>
<td class=br><strong>32</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1786&x=-409&p=Am%20Fylling">Am Fylling</a></td><td class=kW>5:2</td>
<td class=kL>2:6 K</td>
<td class=kL>3:6 K</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1 K</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kL>0:3 K</td>
<td class=kL>3:7</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>6:1 K</td>
<td class=kW>5:2</td>
<td class=kT>2:2 K</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kW>5:1 K</td>
<td class=kW>6:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=br>84:90</td><td class=br>-6</td>
<td class=bc>12 - 6 - 13</td>
<td class=br><strong>30</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=961&x=-409&p=Mi%20Bo%C5%A1t%C3%ADk">Mi Boštík</a></td><td class=kL>2:9</td>
<td class=kL>2:3 K</td>
<td class=kL>1:2 K</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kW>5:2 K</td>
<td class=kW>6:2</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kW>4:3</td>
<td class=kL>1:3 K</td>
<td class=kL>3:7</td>
<td class=kL>0:1</td>
<td class=kL>3:5</td>
<td class=kL>1:6 K</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>4:3 K</td>
<td class=kT>5:5</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kW>6:4</td>
<td class=kL>1:6</td>
<td class=kT>3:3 K</td>
<td class=kT>3:3</td>
<td class=kT>5:5</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=br>89:105</td><td class=br>-16</td>
<td class=bc>13 - 4 - 14</td>
<td class=br><strong>30</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2077&x=-409&p=Pe%20Miettinen">Pe Miettinen</a></td><td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>0:3 K</td>
<td class=kT>1:1 K</td>
<td class=kW>5:0</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>1:4 K</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>5:4</td>
<td class=kW>6:2 K</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>3:4 K</td>
<td class=kT>3:3</td>
<td class=kW>5:2 K</td>
<td class=kW>5:0</td>
<td class=kW>3:1 K</td>
<td class=br>80:81</td><td class=br>-1</td>
<td class=bc>11 - 8 - 12</td>
<td class=br><strong>30</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1203&x=-409&p=Da%20Mitro">Da Mitro</a></td><td class=kL>3:8</td>
<td class=kL>0:2 K</td>
<td class=kL>3:5 K</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>1:5 K</td>
<td class=kW>7:3</td>
<td class=kW>4:1</td>
<td class=kL>4:5</td>
<td class=kT>4:4</td>
<td class=kW>5:1 K</td>
<td class=kW>3:0</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2 K</td>
<td class=kL>3:4 K</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>7:0</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>5:1 K</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=br>86:83</td><td class=br>+3</td>
<td class=bc>13 - 4 - 14</td>
<td class=br><strong>30</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1770&x=-409&p=Gi%20Lasmanis">Gi Lasmanis</a></td><td class=kL>4:5 K</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kL>2:3 K</td>
<td class=kT>3:3</td>
<td class=kT>5:5</td>
<td class=kW>6:4</td>
<td class=kL>1:4 K</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kL>2:6</td>
<td class=kW>4:3 K</td>
<td class=kL>2:5</td>
<td class=kT>5:5</td>
<td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>4:4 K</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>6:0</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>5:1 K</td>
<td class=kL>1:6</td>
<td class=br>100:98</td><td class=br>+2</td>
<td class=bc>11 - 8 - 12</td>
<td class=br><strong>30</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2079&x=-409&p=Di%20Ziemelis">Di Ziemelis</a></td><td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>4:6</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kW>5:4 K</td>
<td class=kL>3:4 K</td>
<td class=kL>0:2 K</td>
<td class=kL>1:2</td>
<td class=kL>1:5 K</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>5:2 K</td>
<td class=kT>3:3 K</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>6:0</td>
<td class=kW>1:0</td>
<td class=kL>0:2 K</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=br>83:88</td><td class=br>-5</td>
<td class=bc>12 - 4 - 15</td>
<td class=br><strong>28</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1844&x=-409&p=Ha%20Ivantsova">Ha Ivantsova</a></td><td class=kL>0:2 K</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>0:4 K</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kL>2:5</td>
<td class=kW>4:1 K</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>4:6</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kT>4:4 K</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>4:5</td>
<td class=kW>4:0</td>
<td class=kL>1:3 K</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>4:3 K</td>
<td class=kW>7:2</td>
<td class=br>73:80</td><td class=br>-7</td>
<td class=bc>12 - 4 - 15</td>
<td class=br><strong>28</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1876&x=-409&p=Ad%20Kop%C5%99iva">Ad Kopřiva</a></td><td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kL>1:6 K</td>
<td class=kW>3:1 K</td>
<td class=kL>2:5 K</td>
<td class=kL>0:1</td>
<td class=kT>2:2 K</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>3:6</td>
<td class=kL>0:7</td>
<td class=kW>3:2</td>
<td class=kL>2:5 K</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>6:2 K</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kW>6:0</td>
<td class=kW>3:1 K</td>
<td class=kW>4:3</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=br>68:91</td><td class=br>-23</td>
<td class=bc>12 - 4 - 15</td>
<td class=br><strong>28</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1650&x=-409&p=Va%20Dietze">Va Dietze</a></td><td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>4:5</td>
<td class=kW>7:4</td>
<td class=kT>4:4</td>
<td class=kL>3:7</td>
<td class=kW>5:3</td>
<td class=kL>1:5 K</td>
<td class=kW>7:1 K</td>
<td class=kW>5:1 K</td>
<td class=kT>1:1</td>
<td class=kL>2:4 K</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kT>3:3 K</td>
<td class=kW>5:4</td>
<td class=kL>2:6 K</td>
<td class=kx>*</td>
<td class=kW>8:1</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kW>5:2</td>
<td class=kL>3:5 K</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=br>104:109</td><td class=br>-5</td>
<td class=bc>10 - 5 - 16</td>
<td class=br><strong>25</strong></td><td class=d>24.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>25.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1976&x=-409&p=Jo%20Astrom">Jo Astrom</a></td><td class=kT>4:4</td>
<td class=kL>0:7</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>1:7 K</td>
<td class=kL>2:4 K</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kL>3:7</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>3:0 K</td>
<td class=kT>4:4</td>
<td class=kW>6:3</td>
<td class=kL>4:6</td>
<td class=kL>2:6 K</td>
<td class=kL>3:5</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kW>3:1</td>
<td class=kL>1:8</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2 K</td>
<td class=kL>2:4</td>
<td class=kW>5:2 K</td>
<td class=kW>3:1</td>
<td class=kT>2:2 K</td>
<td class=br>79:113</td><td class=br>-34</td>
<td class=bc>10 - 5 - 16</td>
<td class=br><strong>25</strong></td><td class=d>25.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>26.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1641&x=-409&p=Ma%20Klazar">Ma Klazar</a></td><td class=kL>2:3 K</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kL>1:4 K</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>1:2 K</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>2:5 K</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2 K</td>
<td class=kL>3:5</td>
<td class=kW>3:1 K</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1 K</td>
<td class=kL>2:3</td>
<td class=br>68:80</td><td class=br>-12</td>
<td class=bc>9 - 6 - 16</td>
<td class=br><strong>24</strong></td><td class=d>26.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>27.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=40&x=-409&p=Da%20Mat%C3%BDsek">Da Matýsek</a></td><td class=kL>3:6</td>
<td class=kT>2:2 K</td>
<td class=kL>1:5 K</td>
<td class=kW>6:2</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kT>2:2 K</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kT>3:3 K</td>
<td class=kW>4:0</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>1:5 K</td>
<td class=kT>3:3 K</td>
<td class=kT>1:1</td>
<td class=kL>1:5 K</td>
<td class=kT>1:1</td>
<td class=kL>0:6</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kL>3:5</td>
<td class=br>61:96</td><td class=br>-35</td>
<td class=bc>7 - 9 - 15</td>
<td class=br><strong>23</strong></td><td class=d>27.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>28.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2083&x=-409&p=Da%20Nygard">Da Nygard</a></td><td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>0:6 K</td>
<td class=kL>2:6 K</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kT>2:2 K</td>
<td class=kW>5:4</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kW>4:3 K</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kT>2:2 K</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kT>0:0 K</td>
<td class=kT>3:3</td>
<td class=kT>2:2 K</td>
<td class=br>63:107</td><td class=br>-44</td>
<td class=bc>6 - 8 - 17</td>
<td class=br><strong>20</strong></td><td class=d>28.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>29.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1764&x=-409&p=Sa%20Kalnin%C5%A1">Sa Kalninš</a></td><td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>3:4 K</td>
<td class=kT>1:1 K</td>
<td class=kT>3:3 K</td>
<td class=kL>0:1</td>
<td class=kL>1:6 K</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kW>3:1</td>
<td class=kT>5:5</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kW>2:0 K</td>
<td class=kL>2:3</td>
<td class=kL>1:3 K</td>
<td class=kW>5:3 K</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=br>64:99</td><td class=br>-35</td>
<td class=bc>7 - 5 - 19</td>
<td class=br><strong>19</strong></td><td class=d>29.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>30.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1194&x=-409&p=He%20Steen">He Steen</a></td><td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kT>3:3 K</td>
<td class=kT>3:3 K</td>
<td class=kL>3:6</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kW>4:3 K</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>2:5 K</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>2:5 K</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kT>0:0 K</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>1:3 K</td>
<td class=br>63:89</td><td class=br>-26</td>
<td class=bc>7 - 5 - 19</td>
<td class=br><strong>19</strong></td><td class=d>30.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>31.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1845&x=-409&p=My%20Shalomayev">My Shalomayev</a></td><td class=kT>5:5 K</td>
<td class=kL>5:6</td>
<td class=kL>1:9</td>
<td class=kL>3:6 K</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3 K</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kL>0:3</td>
<td class=kL>0:8 K</td>
<td class=kL>1:3</td>
<td class=kW>6:2</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kL>1:5 K</td>
<td class=kT>1:1</td>
<td class=kL>3:4 K</td>
<td class=kL>0:1</td>
<td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kL>1:3 K</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=br>55:107</td><td class=br>-52</td>
<td class=bc>5 - 4 - 22</td>
<td class=br><strong>14</strong></td><td class=d>31.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>32.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2104&x=-409&p=Ro%20Kerns">Ro Kerns</a></td><td class=kL>2:6</td>
<td class=kL>1:10</td>
<td class=kL>1:6</td>
<td class=kL>3:8</td>
<td class=kL>0:2 K</td>
<td class=kL>1:4 K</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kT>5:5</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>0:2 K</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>1:3 K</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kT>2:2 K</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2</td>
<td class=kW>3:1 K</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=br>65:120</td><td class=br>-55</td>
<td class=bc>4 - 5 - 22</td>
<td class=br><strong>13</strong></td><td class=d>32.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ru Kamzols</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=blW>Pe Miettinen</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>He Steen</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ot Pesala</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Da Nygard</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Em Liepins</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Al Silinš</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Ol Blume</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Pe Miettinen</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ru Kamzols</td><td class=bc>-</td><td class=bl>He Steen</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=blW>Ot Pesala</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Da Nygard</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Al Silinš</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Ol Blume</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Je Rekis</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=blW>Pe Miettinen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>He Steen</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ot Pesala</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ru Kamzols</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=blW>Da Nygard</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Ol Blume</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Al Silinš</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>He Steen</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Ot Pesala</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Da Nygard</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ru Kamzols</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Pe Miettinen</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Ol Blume</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Al Silinš</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Da Nygard</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ru Kamzols</td><td class=bc>-</td><td class=blW>Pe Miettinen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=bl>He Steen</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ot Pesala</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Em Liepins</td><td class=bc>-</td><td class=blW>Al Silinš</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Ol Blume</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Da Nygard</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Pe Miettinen</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>He Steen</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ru Kamzols</td><td class=bc>-</td><td class=bl>Ot Pesala</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Sa Kalninš</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Al Silinš</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Ol Blume</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Pe Miettinen</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=blW>He Steen</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ot Pesala</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ru Kamzols</td><td class=bc>-</td><td class=bl>Da Nygard</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Je Rekis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Al Silinš</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ol Blume</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ru Kamzols</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Pe Miettinen</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>He Steen</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Ot Pesala</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=bl>Da Nygard</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Al Silinš</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Ol Blume</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Sa Kalninš</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Em Liepins</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Sa Lagzdins</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ot Pesala</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Je Rekis</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Silinš</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ol Blume</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Sa Lagzdins</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pe Miettinen</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>He Steen</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ot Pesala</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Da Nygard</td><td class=bc>-</td><td class=bl>Em Liepins</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Je Rekis</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Silinš</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ol Blume</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ot Pesala</td><td class=bc>-</td><td class=bl>Em Liepins</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=blW>Sa Lagzdins</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Sa Kalninš</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Je Rekis</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Al Silinš</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ol Blume</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=blW>Em Liepins</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Sa Lagzdins</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ot Pesala</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Je Rekis</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Silinš</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ol Blume</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ot Pesala</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Em Liepins</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Sa Lagzdins</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ol Blume</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Je Rekis</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Silinš</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ot Pesala</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Em Liepins</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=blW>Sa Lagzdins</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pe Miettinen</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ol Blume</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Je Rekis</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Al Silinš</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Em Liepins</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ot Pesala</td><td class=bc>-</td><td class=blW>Sa Lagzdins</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ol Blume</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Je Rekis</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Al Silinš</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Em Liepins</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=bl>Sa Lagzdins</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ot Pesala</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Al Silinš</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ol Blume</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Je Rekis</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Em Liepins</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Sa Lagzdins</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Al Silinš</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ot Pesala</td><td class=bc>-</td><td class=blW>Ol Blume</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Da Nygard</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Em Liepins</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Sa Lagzdins</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Al Silinš</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=blW>Ol Blume</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ot Pesala</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=blW>Je Rekis</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Sa Lagzdins</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ol Blume</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ot Pesala</td><td class=bc>-</td><td class=blW>Je Rekis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=blW>Al Silinš</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=blW>Ol Blume</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Al Silinš</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ot Pesala</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Sa Lagzdins</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ot Pesala</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=blW>Sa Kalninš</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Je Rekis</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Al Silinš</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pe Miettinen</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>He Steen</td><td class=bc>-</td><td class=bl>Ol Blume</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Em Liepins</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Sa Kalninš</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ot Pesala</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=blW>Al Silinš</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Ol Blume</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pe Miettinen</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>He Steen</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ot Pesala</td><td class=bc>-</td><td class=blW>Al Silinš</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Ol Blume</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>26</td></tr>
<tr><td class=brW>Sa Lagzdins</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=bl>Al Silinš</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ot Pesala</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=blW>Ol Blume</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>3 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group A2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>25</td>
<td class=ic>26</td>
<td class=ic>27</td>
<td class=ic>28</td>
<td class=ic>29</td>
<td class=ic>30</td>
<td class=ic>31</td>
<td class=ic>32</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1761&x=-409&p=Ra%20Kalnin%C5%A1">Ra Kalninš</a></td><td class=kx>*</td>
<td class=kW>4:3 K</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kL>2:4 K</td>
<td class=kL>3:8</td>
<td class=kW>5:4</td>
<td class=kL>2:6</td>
<td class=kW>4:1</td>
<td class=kL>1:2 K</td>
<td class=kW>3:2</td>
<td class=kW>5:1 K</td>
<td class=kT>5:5 K</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kT>4:4</td>
<td class=kW>3:1 K</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kW>5:3 K</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>9:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=br>120:81</td><td class=br>+39</td>
<td class=bc>22 - 2 - 7</td>
<td class=br><strong>46</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1518&x=-409&p=Ol%20Korabel">Ol Korabel</a></td><td class=kL>3:4 K</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>2:1 K</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kW>7:2</td>
<td class=kL>3:5 K</td>
<td class=kW>5:4</td>
<td class=kW>2:0 K</td>
<td class=kW>6:2 K</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>4:0 K</td>
<td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kL>1:4 K</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=kW>4:0</td>
<td class=kW>6:4</td>
<td class=kW>7:3</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=br>113:67</td><td class=br>+46</td>
<td class=bc>22 - 2 - 7</td>
<td class=br><strong>46</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=409&x=-409&p=Pa%20Petr">Pa Petr</a></td><td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kL>2:7</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kW>4:3 K</td>
<td class=kT>4:4 K</td>
<td class=kL>2:4</td>
<td class=kW>8:3</td>
<td class=kW>2:0</td>
<td class=kW>8:3</td>
<td class=kW>6:1</td>
<td class=kL>1:2 K</td>
<td class=kW>5:1 K</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>2:1 K</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kW>6:0 K</td>
<td class=kW>7:0</td>
<td class=kT>2:2 K</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=br>131:69</td><td class=br>+62</td>
<td class=bc>21 - 4 - 6</td>
<td class=br><strong>46</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1784&x=-409&p=Ma%20Klippen">Ma Klippen</a></td><td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>2:1 K</td>
<td class=kL>0:5 K</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1 K</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>8:0 K</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>6:4 K</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>4:1 K</td>
<td class=kW>4:1 K</td>
<td class=br>96:62</td><td class=br>+34</td>
<td class=bc>21 - 1 - 9</td>
<td class=br><strong>43</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1477&x=-409&p=Mi%20Kobrle">Mi Kobrle</a></td><td class=kW>5:2</td>
<td class=kL>0:4</td>
<td class=kW>3:1</td>
<td class=kL>1:2 K</td>
<td class=kx>*</td>
<td class=kW>2:1 K</td>
<td class=kW>8:3</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kL>5:6</td>
<td class=kW>6:0</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kT>1:1 K</td>
<td class=kW>5:4</td>
<td class=kW>5:0</td>
<td class=kW>8:3 K</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>4:5</td>
<td class=kW>5:1 K</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kT>5:5</td>
<td class=kW>6:5</td>
<td class=kW>5:1 K</td>
<td class=kW>9:0 K</td>
<td class=br>117:73</td><td class=br>+44</td>
<td class=bc>19 - 5 - 7</td>
<td class=br><strong>43</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1503&x=-409&p=Ve%20Huotelin">Ve Huotelin</a></td><td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kW>5:0 K</td>
<td class=kL>1:2 K</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>8:1</td>
<td class=kL>2:4</td>
<td class=kT>1:1 K</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2 K</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kL>2:4 K</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kL>2:5</td>
<td class=kW>4:2</td>
<td class=kW>3:1 K</td>
<td class=kW>6:2 K</td>
<td class=br>101:66</td><td class=br>+35</td>
<td class=bc>19 - 2 - 10</td>
<td class=br><strong>40</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1846&x=-409&p=Ar%20Matantsev">Ar Matantsev</a></td><td class=kL>4:5</td>
<td class=kL>0:3</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kL>3:8</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>3:3 K</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kL>3:4 K</td>
<td class=kT>1:1</td>
<td class=kW>3:2 K</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kT>4:4 K</td>
<td class=kW>6:1</td>
<td class=kL>2:5 K</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>5:4 K</td>
<td class=kW>6:4</td>
<td class=kT>3:3 K</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=br>113:76</td><td class=br>+37</td>
<td class=bc>17 - 6 - 8</td>
<td class=br><strong>40</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2090&x=-409&p=Ja%20Kalnevics">Ja Kalnevics</a></td><td class=kW>4:2 K</td>
<td class=kL>1:2 K</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kW>2:0 K</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kW>3:1 K</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kT>2:2 K</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kW>2:0 K</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=br>79:57</td><td class=br>+22</td>
<td class=bc>15 - 9 - 7</td>
<td class=br><strong>39</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2080&x=-409&p=Kr%20Naglis">Kr Naglis</a></td><td class=kW>8:3</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kT>3:3 K</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kL>2:3 K</td>
<td class=kW>6:2</td>
<td class=kL>1:3 K</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>7:1 K</td>
<td class=kW>2:1</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>5:2 K</td>
<td class=kW>2:1</td>
<td class=kW>4:3 K</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=br>102:78</td><td class=br>+24</td>
<td class=bc>16 - 7 - 8</td>
<td class=br><strong>39</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2078&x=-409&p=Kr%20Lagzdina">Kr Lagzdina</a></td><td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kL>3:4 K</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>3:4 K</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>4:6</td>
<td class=kL>1:6 K</td>
<td class=kT>3:3 K</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kW>2:0 K</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>4:2 K</td>
<td class=kW>3:2</td>
<td class=kW>3:2 K</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=br>89:74</td><td class=br>+15</td>
<td class=bc>15 - 8 - 8</td>
<td class=br><strong>38</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1772&x=-409&p=El%20Silin%C5%A1">El Silinš</a></td><td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kT>4:4 K</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>4:3 K</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kW>6:4</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>1:3 K</td>
<td class=kW>5:2 K</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>2:4 K</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>4:2 K</td>
<td class=kW>5:0</td>
<td class=kW>4:2 K</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=br>86:76</td><td class=br>+10</td>
<td class=bc>15 - 6 - 10</td>
<td class=br><strong>36</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2075&x=-409&p=To%20Baumanis">To Baumanis</a></td><td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kW>4:3 K</td>
<td class=kT>3:3</td>
<td class=kW>3:2 K</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kW>4:1 K</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kL>0:5 K</td>
<td class=kW>5:2</td>
<td class=kW>2:1 K</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2 K</td>
<td class=kW>4:2</td>
<td class=kL>1:4 K</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=br>97:83</td><td class=br>+14</td>
<td class=bc>17 - 2 - 12</td>
<td class=br><strong>36</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2112&x=-409&p=Ed%20Kaneps">Ed Kaneps</a></td><td class=kW>2:1 K</td>
<td class=kW>5:3 K</td>
<td class=kL>3:8</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>0:2 K</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:2 K</td>
<td class=kL>1:4 K</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2 K</td>
<td class=kW>3:0</td>
<td class=kL>0:1</td>
<td class=kT>4:4</td>
<td class=kL>3:5</td>
<td class=kW>1:0 K</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>7:4</td>
<td class=kW>5:1</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kL>4:7</td>
<td class=br>88:79</td><td class=br>+9</td>
<td class=bc>16 - 3 - 12</td>
<td class=br><strong>35</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1174&x=-409&p=Ma%20Mad%C4%9Bra">Ma Maděra</a></td><td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kW>6:5</td>
<td class=kW>6:2</td>
<td class=kL>2:3 K</td>
<td class=kT>2:2</td>
<td class=kW>3:1 K</td>
<td class=kT>3:3</td>
<td class=kL>4:6</td>
<td class=kL>1:4 K</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>1:4 K</td>
<td class=kW>3:2</td>
<td class=kW>3:0 K</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3 K</td>
<td class=kW>5:0</td>
<td class=kW>6:5 K</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=br>95:87</td><td class=br>+8</td>
<td class=bc>14 - 7 - 10</td>
<td class=br><strong>35</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=850&x=-409&p=Im%20Bla%C5%A1ko">Im Blaško</a></td><td class=kL>1:5 K</td>
<td class=kL>0:2 K</td>
<td class=kL>3:8</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2 K</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kW>2:1 K</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>7:2 K</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2 K</td>
<td class=kW>5:0</td>
<td class=kW>7:3</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kL>0:4 K</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=br>80:74</td><td class=br>+6</td>
<td class=bc>15 - 3 - 13</td>
<td class=br><strong>33</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1&x=-409&p=Pa%20Ple%C5%A1%C3%A1k">Pa Plešák</a></td><td class=kT>5:5 K</td>
<td class=kL>2:6 K</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3 K</td>
<td class=kL>2:4</td>
<td class=kW>6:4</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1 K</td>
<td class=kW>4:1</td>
<td class=kL>2:7 K</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kW>5:2 K</td>
<td class=kT>1:1</td>
<td class=kL>0:7</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>1:2 K</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=br>80:91</td><td class=br>-11</td>
<td class=bc>13 - 6 - 12</td>
<td class=br><strong>32</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=882&x=-409&p=Mi%20Saulitis">Mi Saulitis</a></td><td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1 K</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>6:1 K</td>
<td class=kW>3:1 K</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kL>0:2</td>
<td class=kL>3:5</td>
<td class=kW>2:1 K</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kT>1:1 K</td>
<td class=kW>7:3</td>
<td class=kW>5:2 K</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=br>71:72</td><td class=br>-1</td>
<td class=bc>13 - 6 - 12</td>
<td class=br><strong>32</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1151&x=-409&p=Ju%20Rautio">Ju Rautio</a></td><td class=kW>5:4</td>
<td class=kL>3:4</td>
<td class=kL>1:5 K</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kT>3:3 K</td>
<td class=kL>2:5 K</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kT>1:1 K</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kT>4:4</td>
<td class=kW>2:1 K</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>8:1</td>
<td class=kT>2:2 K</td>
<td class=kW>5:1</td>
<td class=kW>1:0 K</td>
<td class=kW>5:4</td>
<td class=kW>4:3</td>
<td class=br>84:88</td><td class=br>-4</td>
<td class=bc>13 - 6 - 12</td>
<td class=br><strong>32</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=567&x=-409&p=Kr%20Lebl">Kr Lebl</a></td><td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3 K</td>
<td class=kT>1:1 K</td>
<td class=kT>1:1 K</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kL>0:1</td>
<td class=kW>2:1 K</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>2:4 K</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kW>3:2 K</td>
<td class=kW>3:2 K</td>
<td class=br>76:75</td><td class=br>+1</td>
<td class=bc>10 - 11 - 10</td>
<td class=br><strong>31</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2105&x=-409&p=Ro%20Livmanis">Ro Livmanis</a></td><td class=kL>1:3 K</td>
<td class=kL>0:4 K</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kT>2:2 K</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>2:3 K</td>
<td class=kW>4:1</td>
<td class=kL>2:4 K</td>
<td class=kL>2:5 K</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kT>4:4</td>
<td class=kW>4:2 K</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=br>85:74</td><td class=br>+11</td>
<td class=bc>13 - 3 - 15</td>
<td class=br><strong>29</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=310&x=-409&p=Mi%20%C4%8Cernoch">Mi Černoch</a></td><td class=kL>1:4</td>
<td class=kW>5:4</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kT>4:4 K</td>
<td class=kT>3:3</td>
<td class=kL>1:7 K</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>5:0 K</td>
<td class=kL>0:3</td>
<td class=kW>4:1 K</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>4:5 K</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kW>3:1 K</td>
<td class=kW>4:2</td>
<td class=kW>3:1 K</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kL>1:2</td>
<td class=br>64:86</td><td class=br>-22</td>
<td class=bc>11 - 5 - 15</td>
<td class=br><strong>27</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1979&x=-409&p=Ga%20Bohinc">Ga Bohinc</a></td><td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>0:8 K</td>
<td class=kL>3:8 K</td>
<td class=kL>2:4 K</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kL>3:7</td>
<td class=kW>7:0</td>
<td class=kW>2:0</td>
<td class=kL>0:4</td>
<td class=kL>1:2 K</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kT>1:1 K</td>
<td class=kL>0:3</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kL>2:4 K</td>
<td class=kW>2:0 K</td>
<td class=br>61:83</td><td class=br>-22</td>
<td class=bc>10 - 6 - 15</td>
<td class=br><strong>26</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1975&x=-409&p=Gu%20Hermansson">Gu Hermansson</a></td><td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kW>5:2 K</td>
<td class=kL>1:4</td>
<td class=kT>2:2 K</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:2 K</td>
<td class=kT>4:4</td>
<td class=kL>0:3 K</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kW>5:4 K</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kT>4:4 K</td>
<td class=kW>4:2</td>
<td class=kL>2:4 K</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=br>75:97</td><td class=br>-22</td>
<td class=bc>9 - 8 - 14</td>
<td class=br><strong>26</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1189&x=-409&p=Ka%20Balodis">Ka Balodis</a></td><td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>1:2 K</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>0:5</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>0:2 K</td>
<td class=kW>4:2 K</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kL>1:2 K</td>
<td class=kL>1:2 K</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kW>5:2</td>
<td class=kT>1:1 K</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=br>67:76</td><td class=br>-9</td>
<td class=bc>8 - 10 - 13</td>
<td class=br><strong>26</strong></td><td class=d>24.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>25.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1815&x=-409&p=An%20Bo%C5%BEi%C4%8D">An Božič</a></td><td class=kL>3:5 K</td>
<td class=kW>4:1 K</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>0:2 K</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>0:1 K</td>
<td class=kL>2:3</td>
<td class=kW>4:0 K</td>
<td class=kW>2:1 K</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>2:4 K</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=br>69:86</td><td class=br>-17</td>
<td class=bc>9 - 4 - 18</td>
<td class=br><strong>22</strong></td><td class=d>25.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>26.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=386&x=-409&p=Ku%20Sl%C3%A1dek">Ku Sládek</a></td><td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>4:6 K</td>
<td class=kL>1:5 K</td>
<td class=kW>4:2 K</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>4:2 K</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kT>1:1 K</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>0:2 K</td>
<td class=kW>6:0 K</td>
<td class=br>60:90</td><td class=br>-30</td>
<td class=bc>7 - 7 - 17</td>
<td class=br><strong>21</strong></td><td class=d>26.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>27.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=64&x=-409&p=Da%20%C5%A0m%C3%ADd">Da Šmíd</a></td><td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kL>4:5 K</td>
<td class=kL>0:4</td>
<td class=kL>2:5 K</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kL>2:5 K</td>
<td class=kL>0:5</td>
<td class=kT>3:3 K</td>
<td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kL>1:8</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>1:3 K</td>
<td class=kW>3:0</td>
<td class=kT>4:4 K</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>7:1 K</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=br>74:106</td><td class=br>-32</td>
<td class=bc>8 - 5 - 18</td>
<td class=br><strong>21</strong></td><td class=d>27.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>28.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1981&x=-409&p=Po%20Kvasnikova">Po Kvasnikova</a></td><td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>0:6 K</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>4:6</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>2:4 K</td>
<td class=kL>2:4 K</td>
<td class=kL>2:4</td>
<td class=kL>4:7</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kW>1:0</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:0 K</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=br>47:98</td><td class=br>-51</td>
<td class=bc>5 - 6 - 20</td>
<td class=br><strong>16</strong></td><td class=d>28.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>29.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=4&x=-409&p=Vl%20Kraus">Vl Kraus</a></td><td class=kL>1:9</td>
<td class=kL>4:6</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kT>5:5</td>
<td class=kW>5:2</td>
<td class=kT>3:3 K</td>
<td class=kL>1:6</td>
<td class=kL>3:4 K</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kW>4:1 K</td>
<td class=kL>1:5</td>
<td class=kL>5:6 K</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>3:7</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>1:3 K</td>
<td class=kL>0:2</td>
<td class=kW>4:2 K</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>1:7 K</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=br>67:125</td><td class=br>-58</td>
<td class=bc>5 - 6 - 20</td>
<td class=br><strong>16</strong></td><td class=d>29.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>30.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=841&x=-409&p=Ma%20Le%C5%BE%C3%ADk">Ma Ležík</a></td><td class=kL>1:2</td>
<td class=kL>3:7</td>
<td class=kT>2:2 K</td>
<td class=kL>2:4</td>
<td class=kL>5:6</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>2:3 K</td>
<td class=kL>2:4 K</td>
<td class=kL>2:5</td>
<td class=kW>4:1</td>
<td class=kL>3:5</td>
<td class=kL>0:3</td>
<td class=kW>6:1</td>
<td class=kL>2:5 K</td>
<td class=kL>0:1 K</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kT>1:1 K</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kL>0:2 K</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=br>72:98</td><td class=br>-26</td>
<td class=bc>7 - 2 - 22</td>
<td class=br><strong>16</strong></td><td class=d>30.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>31.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1193&x=-409&p=La%20Svensson">La Svensson</a></td><td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:4 K</td>
<td class=kL>1:5 K</td>
<td class=kL>1:3 K</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kL>2:3 K</td>
<td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kW>4:2 K</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>2:0 K</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>4:2 K</td>
<td class=br>49:102</td><td class=br>-53</td>
<td class=bc>5 - 3 - 23</td>
<td class=br><strong>13</strong></td><td class=d>31.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>32.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2092&x=-409&p=Ar%20Tseluiko">Ar Tseluiko</a></td><td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>1:4 K</td>
<td class=kL>0:9 K</td>
<td class=kL>2:6 K</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kW>7:4</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>2:3 K</td>
<td class=kL>0:6</td>
<td class=kW>2:1</td>
<td class=kL>0:2 K</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>0:6 K</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>2:4 K</td>
<td class=kx>*</td>
<td class=br>63:122</td><td class=br>-59</td>
<td class=bc>4 - 3 - 24</td>
<td class=br><strong>11</strong></td><td class=d>32.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ja Kalnevics</td><td class=bc>-</td><td class=bl>Mi Saulitis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=blW>Kr Lagzdina</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>Ka Balodis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=blW>Ju Rautio</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Po Kvasnikova</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ro Livmanis</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>La Svensson</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Kalnevics</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Kr Lagzdina</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Ka Balodis</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=blW>Ju Rautio</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Saulitis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ar Tseluiko</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=blW>Kr Lagzdina</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ja Kalnevics</td><td class=bc>-</td><td class=blW>Ka Balodis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ra Kalninš</td><td class=bc>-</td><td class=blW>Ju Rautio</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Mi Saulitis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=blW>Kr Lagzdina</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Ka Balodis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ro Livmanis</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ja Kalnevics</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=blW>Mi Saulitis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ed Kaneps</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=blW>Mi Saulitis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Kalnevics</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ra Kalninš</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=bl>Kr Lagzdina</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>Ka Balodis</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=blW>Po Kvasnikova</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=blW>Mi Saulitis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ro Livmanis</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ja Kalnevics</td><td class=bc>-</td><td class=bl>Kr Lagzdina</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Ka Balodis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=bl>Mi Saulitis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Ed Kaneps</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Kr Lagzdina</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=bl>Ka Balodis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ja Kalnevics</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Mi Saulitis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>Kr Lagzdina</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=blW>Ka Balodis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=blW>Po Kvasnikova</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ja Kalnevics</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Mi Saulitis</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Ja Kalnevics</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ra Kalninš</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>La Svensson</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Mi Saulitis</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>La Svensson</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Ja Kalnevics</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Mi Saulitis</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Ja Kalnevics</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>La Svensson</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Saulitis</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>La Svensson</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ga Bohinc</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ja Kalnevics</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Mi Saulitis</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>La Svensson</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=bl>Ja Kalnevics</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Ra Kalninš</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ka Balodis</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Saulitis</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>La Svensson</td><td class=bc>-</td><td class=blW>Ja Kalnevics</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Saulitis</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Ja Kalnevics</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Ra Kalninš</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>La Svensson</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ma Klippen</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Saulitis</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ja Kalnevics</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>La Svensson</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ar Tseluiko</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Ga Bohinc</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Ja Kalnevics</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Mi Saulitis</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Ja Kalnevics</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Mi Saulitis</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Ja Kalnevics</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Saulitis</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ka Balodis</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Ja Kalnevics</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Mi Saulitis</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ka Balodis</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ja Kalnevics</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ka Balodis</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Saulitis</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ja Kalnevics</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=blW>Ar Tseluiko</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Saulitis</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ja Kalnevics</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Saulitis</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>26</td></tr>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=bl>Ja Kalnevics</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Ra Kalninš</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>La Svensson</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Ar Tseluiko</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Saulitis</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>0 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2087&x=-409&p=Sa%20Hellstrom">Sa Hellstrom</a></td><td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kW>5:2 K</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>6:2</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=kL>1:2 K</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=br>71:39</td><td class=br>+32</td>
<td class=bc>17 - 1 - 5</td>
<td class=br><strong>35</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1065&x=-409&p=Kr%20Herold">Kr Herold</a></td><td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:3 K</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>2:4 K</td>
<td class=kT>5:5</td>
<td class=kL>0:1</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=br>64:48</td><td class=br>+16</td>
<td class=bc>15 - 4 - 4</td>
<td class=br><strong>34</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1790&x=-409&p=An%20Fjermestad">An Fjermestad</a></td><td class=kL>2:5 K</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>5:4</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>5:3 K</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kL>3:9</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=br>84:56</td><td class=br>+28</td>
<td class=bc>16 - 1 - 6</td>
<td class=br><strong>33</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=201&x=-409&p=To%20Bucek">To Bucek</a></td><td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>5:5</td>
<td class=kW>4:1</td>
<td class=kL>0:2</td>
<td class=kW>2:1 K</td>
<td class=kL>1:2</td>
<td class=kW>5:4</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kW>7:2</td>
<td class=kL>1:3 K</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>0:6</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=br>70:57</td><td class=br>+13</td>
<td class=bc>13 - 3 - 7</td>
<td class=br><strong>29</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2082&x=-409&p=La%20Metsala">La Metsala</a></td><td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>2:0 K</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kW>3:0</td>
<td class=kW>4:0 K</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=br>67:41</td><td class=br>+26</td>
<td class=bc>13 - 3 - 7</td>
<td class=br><strong>29</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=248&x=-409&p=Ma%20%C5%BDen%C3%AD%C5%A1ek">Ma Ženíšek</a></td><td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kT>5:5</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kL>5:6</td>
<td class=kW>6:3</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kL>2:3 K</td>
<td class=kW>5:4</td>
<td class=kW>7:6</td>
<td class=kW>6:3 K</td>
<td class=br>81:74</td><td class=br>+7</td>
<td class=bc>13 - 3 - 7</td>
<td class=br><strong>29</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1977&x=-409&p=Ti%20Dion">Ti Dion</a></td><td class=kW>1:0</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kL>2:5 K</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>4:2 K</td>
<td class=kW>6:2</td>
<td class=kW>8:2</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kL>0:5</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=br>74:61</td><td class=br>+13</td>
<td class=bc>12 - 5 - 6</td>
<td class=br><strong>29</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1828&x=-409&p=Tr%20Mansson">Tr Mansson</a></td><td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kW>2:0</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1 K</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kT>5:5</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kL>1:2 K</td>
<td class=kW>3:2</td>
<td class=br>61:48</td><td class=br>+13</td>
<td class=bc>12 - 4 - 7</td>
<td class=br><strong>28</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2084&x=-409&p=Ha%20Gals">Ha Gals</a></td><td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>1:2 K</td>
<td class=kL>3:4</td>
<td class=kW>4:0</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kL>4:5</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>3:0 K</td>
<td class=kW>6:2</td>
<td class=kT>5:5</td>
<td class=kL>1:3</td>
<td class=kW>7:1</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>7:0</td>
<td class=br>79:49</td><td class=br>+30</td>
<td class=bc>12 - 3 - 8</td>
<td class=br><strong>27</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1579&x=-409&p=Vi%20Henttonen">Vi Henttonen</a></td><td class=kL>1:5</td>
<td class=kL>3:4 K</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kL>3:4 K</td>
<td class=kL>3:4</td>
<td class=kT>0:0</td>
<td class=kL>1:2</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=br>58:48</td><td class=br>+10</td>
<td class=bc>11 - 4 - 8</td>
<td class=br><strong>26</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=893&x=-409&p=Ne%20%C5%A0krlep">Ne Škrlep</a></td><td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kW>5:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kW>5:3</td>
<td class=kW>5:4</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>4:3 K</td>
<td class=kW>4:1</td>
<td class=kW>2:1 K</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=br>72:65</td><td class=br>+7</td>
<td class=bc>12 - 1 - 10</td>
<td class=br><strong>25</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=18&x=-409&p=An%20%C5%A0ur%C3%BDn">An Šurýn</a></td><td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>6:1</td>
<td class=kL>0:2 K</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>6:2 K</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=br>58:55</td><td class=br>+3</td>
<td class=bc>11 - 1 - 11</td>
<td class=br><strong>23</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1974&x=-409&p=Ja%20Obadi%C4%8D">Ja Obadič</a></td><td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>6:5</td>
<td class=kL>0:3</td>
<td class=kL>1:4 K</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>5:4</td>
<td class=kL>0:3 K</td>
<td class=kW>3:1</td>
<td class=br>65:65</td><td class=br>0</td>
<td class=bc>10 - 3 - 10</td>
<td class=br><strong>23</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1268&x=-409&p=Da%20Dvo%C5%99%C3%A1%C4%8Dek">Da Dvořáček</a></td><td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>2:7</td>
<td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=kW>5:2 K</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>3:6</td>
<td class=kW>4:2 K</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=br>62:65</td><td class=br>-3</td>
<td class=bc>10 - 2 - 11</td>
<td class=br><strong>22</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=354&x=-409&p=Ti%20Varga">Ti Varga</a></td><td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>3:1 K</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>0:3 K</td>
<td class=kL>4:5</td>
<td class=kL>3:5</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kW>4:2</td>
<td class=br>53:68</td><td class=br>-15</td>
<td class=bc>9 - 2 - 12</td>
<td class=br><strong>20</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1622&x=-409&p=He%20Petuch">He Petuch</a></td><td class=kL>3:5</td>
<td class=kW>4:2 K</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>5:5</td>
<td class=kL>2:6</td>
<td class=kW>4:3 K</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>6:5</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=br>67:80</td><td class=br>-13</td>
<td class=bc>7 - 6 - 10</td>
<td class=br><strong>20</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=101&x=-409&p=Mi%20Kubica">Mi Kubica</a></td><td class=kL>0:6</td>
<td class=kT>5:5</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kW>5:2</td>
<td class=kL>2:4 K</td>
<td class=kW>5:3</td>
<td class=kT>5:5</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>2:4 K</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>7:1</td>
<td class=kL>5:7</td>
<td class=br>67:78</td><td class=br>-11</td>
<td class=bc>8 - 4 - 11</td>
<td class=br><strong>20</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1978&x=-409&p=My%20Verbytskyy">My Verbytskyy</a></td><td class=kL>1:3</td>
<td class=kW>1:0</td>
<td class=kL>1:5</td>
<td class=kW>6:0</td>
<td class=kL>0:4 K</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kT>0:0</td>
<td class=kL>0:4</td>
<td class=kL>2:6 K</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>0:6</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=br>43:66</td><td class=br>-23</td>
<td class=bc>8 - 2 - 13</td>
<td class=br><strong>18</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=26&x=-409&p=Mi%20%C5%A0evr">Mi Ševr</a></td><td class=kW>2:1 K</td>
<td class=kL>0:2</td>
<td class=kL>3:5 K</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>2:8</td>
<td class=kL>1:7</td>
<td class=kL>1:7</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>5:6</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=br>44:74</td><td class=br>-30</td>
<td class=bc>7 - 3 - 13</td>
<td class=br><strong>17</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2001&x=-409&p=Gl%20Storozhenko">Gl Storozhenko</a></td><td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>3:4 K</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>3:3 K</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>55:63</td><td class=br>-8</td>
<td class=bc>5 - 5 - 13</td>
<td class=br><strong>15</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1033&x=-409&p=Si%20Thomas">Si Thomas</a></td><td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kW>3:2 K</td>
<td class=kL>3:6</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kW>6:0</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>4:3 K</td>
<td class=br>50:69</td><td class=br>-19</td>
<td class=bc>6 - 3 - 14</td>
<td class=br><strong>15</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=176&x=-409&p=Zd%20Lopaur">Zd Lopaur</a></td><td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kW>9:3</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kL>4:5</td>
<td class=kW>5:0</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2 K</td>
<td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kT>3:3 K</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=br>68:75</td><td class=br>-7</td>
<td class=bc>5 - 4 - 14</td>
<td class=br><strong>14</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=547&x=-409&p=To%20Lahu%C4%8Dk%C3%BD">To Lahučký</a></td><td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>6:7</td>
<td class=kL>2:6</td>
<td class=kW>2:1 K</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kW>3:0 K</td>
<td class=kL>0:4</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=br>48:74</td><td class=br>-26</td>
<td class=bc>6 - 1 - 16</td>
<td class=br><strong>13</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2098&x=-409&p=Ni%20Lyksholm">Ni Lyksholm</a></td><td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kL>3:6 K</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>0:7</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>7:5</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>3:4 K</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=br>43:86</td><td class=br>-43</td>
<td class=bc>3 - 2 - 18</td>
<td class=br><strong>8</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>To Lahučký</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ja Obadič</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Sa Hellstrom</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ti Varga</td><td class=bc>-</td><td class=blW>La Metsala</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 3 K</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Sa Hellstrom</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ja Obadič</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ha Gals</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Ti Varga</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>La Metsala</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Sa Hellstrom</td><td class=bc>2 : 5 K</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ni Lyksholm</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>7 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>La Metsala</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>2 : 0 K</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ja Obadič</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ha Gals</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ti Varga</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Ja Obadič</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ha Gals</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>La Metsala</td><td class=bc>0 : 4 K</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Sa Hellstrom</td><td class=bc>2 : 1 K</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>7 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>6 : 2 K</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Sa Hellstrom</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>To Lahučký</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ja Obadič</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ha Gals</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ti Varga</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>La Metsala</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Ha Gals</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>La Metsala</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Sa Hellstrom</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=blW>Ja Obadič</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ha Gals</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ti Varga</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Sa Hellstrom</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>La Metsala</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Sa Hellstrom</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=blW>Ha Gals</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>2 : 5 K</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>La Metsala</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Sa Hellstrom</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>La Metsala</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>2 : 1 K</tr></td>
<tr><td class=brW>Sa Hellstrom</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Ja Obadič</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>4 : 2 K</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ha Gals</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ti Varga</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>4 : 2 K</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ni Lyksholm</td><td class=bc>-</td><td class=bl>La Metsala</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>3 : 4 K</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Sa Hellstrom</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ha Gals</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ti Varga</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>La Metsala</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Sa Hellstrom</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Ha Gals</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>La Metsala</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>3 : 3 K</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Ja Obadič</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Sa Hellstrom</td><td class=bc>-</td><td class=blW>Ha Gals</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ti Varga</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>La Metsala</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Sa Hellstrom</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Ha Gals</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=blW>To Lahučký</td><td class=bc>1 : 2 K</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>La Metsala</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>La Metsala</td><td class=bc>-</td><td class=bl>Sa Hellstrom</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 2 K</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>4 : 1 K</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>To Lahučký</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>To Lahučký</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>3 : 0 K</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=bl>La Metsala</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Sa Hellstrom</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Sa Hellstrom</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>9 : 3</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>3 : 4 K</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Ti Varga</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>La Metsala</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=blW>Ha Gals</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>La Metsala</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Sa Hellstrom</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Ja Obadič</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>6 : 3 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>To Lahučký</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=blW>La Metsala</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ja Obadič</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=blW>La Metsala</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Sa Hellstrom</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ni Lyksholm</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=brW>Sa Hellstrom</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>3 : 4 K</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=blW>Ti Varga</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>2 : 1 K</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=bl>La Metsala</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Sa Hellstrom</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ti Varga</td><td class=bc>1 : 3 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>26</td></tr>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>4 : 2 K</tr></td>
<tr><td class=brW>Ha Gals</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>3 : 0 K</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>La Metsala</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>27</td></tr>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Sa Hellstrom</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ni Lyksholm</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>3 : 4 K</tr></td>
<tr><td class=br>Ha Gals</td><td class=bc>-</td><td class=blW>La Metsala</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>28</td></tr>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ni Lyksholm</td><td class=bc>-</td><td class=blW>Sa Hellstrom</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>6 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2086&x=-409&p=Ni%20Lacis">Ni Lacis</a></td><td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>6:4</td>
<td class=br>60:30</td><td class=br>+30</td>
<td class=bc>13 - 1 - 1</td>
<td class=br><strong>27</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1709&x=-409&p=Mi%20Bla%C5%BEek">Mi Blažek</a></td><td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kW>6:2</td>
<td class=kW>7:2</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=br>49:26</td><td class=br>+23</td>
<td class=bc>11 - 1 - 3</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=559&x=-409&p=Bj%20Axelsen">Bj Axelsen</a></td><td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>8:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=br>53:28</td><td class=br>+25</td>
<td class=bc>11 - 1 - 3</td>
<td class=br><strong>23</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=53&x=-409&p=V%C3%A1%20Pikl">Vá Pikl</a></td><td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=br>38:24</td><td class=br>+14</td>
<td class=bc>9 - 3 - 3</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=261&x=-409&p=Da%20Cibulka">Da Cibulka</a></td><td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>7:2</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=br>41:32</td><td class=br>+9</td>
<td class=bc>7 - 4 - 4</td>
<td class=br><strong>18</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1912&x=-409&p=Al%20Krejza">Al Krejza</a></td><td class=kT>3:3</td>
<td class=kL>2:7</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=br>43:37</td><td class=br>+6</td>
<td class=bc>6 - 5 - 4</td>
<td class=br><strong>17</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1619&x=-409&p=Mi%20Borgh">Mi Borgh</a></td><td class=kL>4:5</td>
<td class=kL>0:2</td>
<td class=kL>1:8</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kL>2:4</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=br>44:44</td><td class=br>0</td>
<td class=bc>6 - 3 - 6</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1927&x=-409&p=Vo%20Kraus">Vo Kraus</a></td><td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=br>35:38</td><td class=br>-3</td>
<td class=bc>6 - 2 - 7</td>
<td class=br><strong>14</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1488&x=-409&p=Ra%20Pommerenke">Ra Pommerenke</a></td><td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:7</td>
<td class=kT>0:0</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=br>35:44</td><td class=br>-9</td>
<td class=bc>5 - 4 - 6</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2103&x=-409&p=Gu%20Nilsson">Gu Nilsson</a></td><td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=br>40:42</td><td class=br>-2</td>
<td class=bc>6 - 2 - 7</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2091&x=-409&p=Ma%20Kyllergard">Ma Kyllergard</a></td><td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kW>7:1</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=br>37:38</td><td class=br>-1</td>
<td class=bc>6 - 0 - 9</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1940&x=-409&p=Ma%20Ko%C5%A1%C5%88ar">Ma Košňar</a></td><td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kT>0:0</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=br>27:42</td><td class=br>-15</td>
<td class=bc>5 - 2 - 8</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=227&x=-409&p=Mi%20Ma%C5%A1ika">Mi Mašika</a></td><td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kL>3:6</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>0:5</td>
<td class=br>30:52</td><td class=br>-22</td>
<td class=bc>4 - 1 - 10</td>
<td class=br><strong>9</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2017&x=-409&p=Ka%20Pirumshoeva">Ka Pirumshoeva</a></td><td class=kW>3:2</td>
<td class=kL>4:5</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=br>22:46</td><td class=br>-24</td>
<td class=bc>3 - 2 - 10</td>
<td class=br><strong>8</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2089&x=-409&p=Ju%20Itkonen">Ju Itkonen</a></td><td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=br>30:43</td><td class=br>-13</td>
<td class=bc>2 - 3 - 10</td>
<td class=br><strong>7</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1630&x=-409&p=Pe%20Holub">Pe Holub</a></td><td class=kL>4:6</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=br>31:49</td><td class=br>-18</td>
<td class=bc>3 - 0 - 12</td>
<td class=br><strong>6</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Mi Borgh</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Ju Itkonen</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Gu Nilsson</td><td class=bc>-</td><td class=blW>Ni Lacis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Ma Kyllergard</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Vo Kraus</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ju Itkonen</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Gu Nilsson</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Kyllergard</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ni Lacis</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>6 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Mi Borgh</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Gu Nilsson</td><td class=bc>-</td><td class=bl>Ju Itkonen</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ma Kyllergard</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Ni Lacis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Vo Kraus</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>Gu Nilsson</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Kyllergard</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ju Itkonen</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ni Lacis</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Mi Borgh</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Gu Nilsson</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Vo Kraus</td><td class=bc>-</td><td class=bl>Ma Kyllergard</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=bl>Ju Itkonen</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>Ni Lacis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>Gu Nilsson</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Kyllergard</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ka Pirumshoeva</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ni Lacis</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ju Itkonen</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Kyllergard</td><td class=bc>-</td><td class=blW>Mi Borgh</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Gu Nilsson</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Ni Lacis</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ju Itkonen</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Ma Kyllergard</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Gu Nilsson</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ni Lacis</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ju Itkonen</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Mi Borgh</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ma Kyllergard</td><td class=bc>-</td><td class=blW>Ni Lacis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Gu Nilsson</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Vo Kraus</td><td class=bc>-</td><td class=bl>Ju Itkonen</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ni Lacis</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Ma Kyllergard</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Gu Nilsson</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ju Itkonen</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ni Lacis</td><td class=bc>-</td><td class=bl>Mi Borgh</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ma Kyllergard</td><td class=bc>-</td><td class=bl>Ju Itkonen</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Mi Mašika</td><td class=bc>-</td><td class=bl>Gu Nilsson</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Ka Pirumshoeva</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=blW>Ni Lacis</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ju Itkonen</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Ma Kyllergard</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Gu Nilsson</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Mi Borgh</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ni Lacis</td><td class=bc>-</td><td class=bl>Ju Itkonen</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Vo Kraus</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Kyllergard</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Gu Nilsson</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Ju Itkonen</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Ni Lacis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Vo Kraus</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>4 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Gu Nilsson</td><td class=bc>-</td><td class=blW>Ma Kyllergard</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ju Itkonen</td><td class=bc>-</td><td class=bl>Mi Borgh</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ni Lacis</td><td class=bc>-</td><td class=blW>Ka Pirumshoeva</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Gu Nilsson</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ma Kyllergard</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>3 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group D</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=320&x=-409&p=To%20Hudec">To Hudec</a></td><td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kW>6:0</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0 K</td>
<td class=kL>3:4</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=br>51:23</td><td class=br>+28</td>
<td class=bc>11 - 1 - 3</td>
<td class=br><strong>23</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=447&x=-409&p=Ro%20Pavlica">Ro Pavlica</a></td><td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kT>5:5</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kL>5:6</td>
<td class=kL>2:6</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>7:3</td>
<td class=kW>7:3</td>
<td class=br>63:39</td><td class=br>+24</td>
<td class=bc>10 - 2 - 3</td>
<td class=br><strong>22</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=319&x=-409&p=Ka%20Hudec">Ka Hudec</a></td><td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=br>39:27</td><td class=br>+12</td>
<td class=bc>7 - 6 - 2</td>
<td class=br><strong>20</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1657&x=-409&p=Jo%20Perkner">Jo Perkner</a></td><td class=kW>3:0</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=br>40:28</td><td class=br>+12</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1527&x=-409&p=Mi%20Mitro%20ml.">Mi Mitro ml.</a></td><td class=kW>3:2</td>
<td class=kT>5:5</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kW>6:2</td>
<td class=br>44:37</td><td class=br>+7</td>
<td class=bc>6 - 5 - 4</td>
<td class=br><strong>17</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1173&x=-409&p=Jo%20Mal%C3%BD">Jo Malý</a></td><td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kW>8:2</td>
<td class=kL>1:3</td>
<td class=br>40:34</td><td class=br>+6</td>
<td class=bc>7 - 3 - 5</td>
<td class=br><strong>17</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1599&x=-409&p=Mi%20Uhl%C3%AD%C5%99">Mi Uhlíř</a></td><td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kW>7:4</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=br>49:45</td><td class=br>+4</td>
<td class=bc>7 - 2 - 6</td>
<td class=br><strong>16</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=204&x=-409&p=Hy%20Nechutn%C3%BD">Hy Nechutný</a></td><td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kL>0:5</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kW>4:1</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=br>28:33</td><td class=br>-5</td>
<td class=bc>7 - 1 - 7</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=41&x=-409&p=Da%20Hrachovec">Da Hrachovec</a></td><td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=br>37:36</td><td class=br>+1</td>
<td class=bc>6 - 3 - 6</td>
<td class=br><strong>15</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1968&x=-409&p=Mi%20Tou%C5%A1">Mi Touš</a></td><td class=kL>2:3</td>
<td class=kW>6:5</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>4:7</td>
<td class=kW>5:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>3:6</td>
<td class=kW>3:1</td>
<td class=kW>6:4</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=br>50:52</td><td class=br>-2</td>
<td class=bc>7 - 1 - 7</td>
<td class=br><strong>15</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1291&x=-409&p=Ma%20Dion">Ma Dion</a></td><td class=kL>1:3</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=br>44:46</td><td class=br>-2</td>
<td class=bc>5 - 3 - 7</td>
<td class=br><strong>13</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1746&x=-409&p=An%20Gripp">An Gripp</a></td><td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>6:3</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=br>35:47</td><td class=br>-12</td>
<td class=bc>4 - 4 - 7</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=108&x=-409&p=Ro%20Hejda">Ro Hejda</a></td><td class=kL>0:5 K</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=br>30:49</td><td class=br>-19</td>
<td class=bc>4 - 3 - 8</td>
<td class=br><strong>11</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2014&x=-409&p=Ma%20Hlava%C4%8Dka">Ma Hlavačka</a></td><td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>4:6</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=br>34:43</td><td class=br>-9</td>
<td class=bc>4 - 2 - 9</td>
<td class=br><strong>10</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1318&x=-409&p=Jo%20Sedl%C3%A1%C4%8Dek">Jo Sedláček</a></td><td class=kL>1:6</td>
<td class=kL>3:7</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kW>2:0</td>
<td class=kL>2:8</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=br>35:57</td><td class=br>-22</td>
<td class=bc>4 - 1 - 10</td>
<td class=br><strong>9</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1917&x=-409&p=Fr%20Rasche">Fr Rasche</a></td><td class=kL>0:3</td>
<td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kL>3:6</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=br>33:56</td><td class=br>-23</td>
<td class=bc>2 - 3 - 10</td>
<td class=br><strong>7</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>An Gripp</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Mi Mitro ml.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Dion</td><td class=bc>-</td><td class=blW>Mi Touš</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Ro Pavlica</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ro Hejda</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>An Gripp</td><td class=bc>-</td><td class=blW>To Hudec</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ro Pavlica</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ma Hlavačka</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>To Hudec</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Fr Rasche</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Mi Mitro ml.</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ma Dion</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ro Pavlica</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>An Gripp</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Mi Touš</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Mi Mitro ml.</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro Pavlica</td><td class=bc>-</td><td class=blW>Ma Dion</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>An Gripp</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>To Hudec</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>Ro Pavlica</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Dion</td><td class=bc>-</td><td class=bl>Mi Mitro ml.</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>An Gripp</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=blW>Mi Touš</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ma Hlavačka</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ro Pavlica</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>Ma Dion</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ro Hejda</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Mi Touš</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Ro Pavlica</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ma Dion</td><td class=bc>-</td><td class=blW>To Hudec</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Mi Mitro ml.</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Gripp</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Ro Hejda</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ro Pavlica</td><td class=bc>-</td><td class=blW>Mi Touš</td><td class=bc>5 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mi Mitro ml.</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>To Hudec</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=blW>Ro Pavlica</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Dion</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=bl>Mi Mitro ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>An Gripp</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ro Pavlica</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>Mi Touš</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ro Pavlica</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ma Dion</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Mi Mitro ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>To Hudec</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>An Gripp</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>Ro Pavlica</td><td class=bc>5 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>Ma Hlavačka</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>8 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ro Pavlica</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>Ma Hlavačka</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Gripp</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>Mi Mitro ml.</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ma Dion</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Ro Pavlica</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Ro Hejda</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Fr Rasche</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Ma Dion</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ro Pavlica</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Touš</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>3 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group E</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2005&x=-409&p=Do%20Zupan%C4%8Di%C4%8D">Do Zupančič</a></td><td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=br>46:24</td><td class=br>+22</td>
<td class=bc>11 - 4 - 0</td>
<td class=br><strong>26</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=818&x=-409&p=Ro%20Je%C5%BE">Ro Jež</a></td><td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kW>5:4</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kW>6:0</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>8:0</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=br>62:25</td><td class=br>+37</td>
<td class=bc>11 - 1 - 3</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2018&x=-409&p=Ja%20Janou%C5%A1kovec">Ja Janouškovec</a></td><td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kW>5:2</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>5:4</td>
<td class=br>46:34</td><td class=br>+12</td>
<td class=bc>10 - 2 - 3</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2094&x=-409&p=Gu%20Gripp">Gu Gripp</a></td><td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=br>36:25</td><td class=br>+11</td>
<td class=bc>9 - 3 - 3</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=215&x=-409&p=Jo%20Vom%C3%A1%C4%8Dka">Jo Vomáčka</a></td><td class=kL>2:5</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=br>44:29</td><td class=br>+15</td>
<td class=bc>9 - 2 - 4</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=318&x=-409&p=Ji%20V%C3%A1cha">Ji Vácha</a></td><td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>7:0</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>9:2</td>
<td class=kW>7:1</td>
<td class=kT>3:3</td>
<td class=br>64:41</td><td class=br>+23</td>
<td class=bc>7 - 4 - 4</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2110&x=-409&p=My%20Razkevich">My Razkevich</a></td><td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kW>6:1</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kL>0:7</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>7:4</td>
<td class=kW>4:1</td>
<td class=br>47:46</td><td class=br>+1</td>
<td class=bc>7 - 2 - 6</td>
<td class=br><strong>16</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2093&x=-409&p=Jo%20Brunner">Jo Brunner</a></td><td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kL>5:6</td>
<td class=kW>6:4</td>
<td class=kW>5:3</td>
<td class=kT>4:4</td>
<td class=kW>4:0</td>
<td class=br>47:47</td><td class=br>0</td>
<td class=bc>5 - 5 - 5</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1058&x=-409&p=Fr%20Marek">Fr Marek</a></td><td class=kT>2:2</td>
<td class=kL>0:6</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>6:0</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=br>31:34</td><td class=br>-3</td>
<td class=bc>4 - 6 - 5</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=442&x=-409&p=Pa%20Poho%C5%99al%C3%BD">Pa Pohořalý</a></td><td class=kL>0:3</td>
<td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>3:6</td>
<td class=kW>5:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=br>39:48</td><td class=br>-9</td>
<td class=bc>5 - 3 - 7</td>
<td class=br><strong>13</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1871&x=-409&p=Mi%20L%C3%A9vy">Mi Lévy</a></td><td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=br>34:35</td><td class=br>-1</td>
<td class=bc>5 - 2 - 8</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=271&x=-409&p=Ra%20Hejtman">Ra Hejtman</a></td><td class=kT>4:4</td>
<td class=kL>0:8</td>
<td class=kL>2:7</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kW>6:5</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kL>1:4</td>
<td class=br>36:60</td><td class=br>-24</td>
<td class=bc>4 - 2 - 9</td>
<td class=br><strong>10</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1639&x=-409&p=Ja%20Ou%C5%99ada">Ja Ouřada</a></td><td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kW>2:1</td>
<td class=kL>4:6</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>7:3</td>
<td class=kL>2:3</td>
<td class=br>40:48</td><td class=br>-8</td>
<td class=bc>4 - 1 - 10</td>
<td class=br><strong>9</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1941&x=-409&p=Ja%20Kopeck%C3%BD">Ja Kopecký</a></td><td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>2:9</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>5:0</td>
<td class=br>27:52</td><td class=br>-25</td>
<td class=bc>3 - 2 - 10</td>
<td class=br><strong>8</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1907&x=-409&p=Al%20Pala">Al Pala</a></td><td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>4:7</td>
<td class=kT>4:4</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>3:7</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=br>29:57</td><td class=br>-28</td>
<td class=bc>3 - 1 - 11</td>
<td class=br><strong>7</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=216&x=-409&p=Ro%20Vom%C3%A1%C4%8Dka">Ro Vomáčka</a></td><td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=br>29:52</td><td class=br>-23</td>
<td class=bc>2 - 2 - 11</td>
<td class=br><strong>6</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Gu Gripp</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ja Janouškovec</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Ra Hejtman</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ja Kopecký</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Al Pala</td><td class=bc>-</td><td class=blW>Do Zupančič</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Jo Brunner</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Gu Gripp</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ra Hejtman</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Ja Kopecký</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>My Razkevich</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ja Ouřada</td><td class=bc>-</td><td class=bl>Al Pala</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Do Zupančič</td><td class=bc>-</td><td class=bl>Jo Brunner</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Jo Vomáčka</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ra Hejtman</td><td class=bc>-</td><td class=blW>Gu Gripp</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Ja Janouškovec</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Al Pala</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Jo Brunner</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>Do Zupančič</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Gu Gripp</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>My Razkevich</td><td class=bc>-</td><td class=bl>Ra Hejtman</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ja Janouškovec</td><td class=bc>-</td><td class=bl>Al Pala</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=bl>Jo Brunner</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Jo Vomáčka</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Do Zupančič</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=blW>Gu Gripp</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Al Pala</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ra Hejtman</td><td class=bc>-</td><td class=blW>Ro Vomáčka</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Jo Brunner</td><td class=bc>-</td><td class=blW>Ja Janouškovec</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Jo Vomáčka</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Do Zupančič</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ja Ouřada</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Gu Gripp</td><td class=bc>-</td><td class=bl>Al Pala</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>My Razkevich</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Jo Brunner</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Ra Hejtman</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Ja Janouškovec</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Do Zupančič</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Gu Gripp</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Jo Brunner</td><td class=bc>-</td><td class=bl>Al Pala</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Jo Vomáčka</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ra Hejtman</td><td class=bc>-</td><td class=bl>Do Zupančič</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ja Janouškovec</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Gu Gripp</td><td class=bc>-</td><td class=bl>Jo Brunner</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Al Pala</td><td class=bc>-</td><td class=blW>Jo Vomáčka</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Do Zupančič</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ja Ouřada</td><td class=bc>-</td><td class=bl>Ra Hejtman</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ja Janouškovec</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Gu Gripp</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Jo Vomáčka</td><td class=bc>-</td><td class=bl>Jo Brunner</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Do Zupančič</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Al Pala</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=blW>Ja Ouřada</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ra Hejtman</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Gu Gripp</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Do Zupančič</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Jo Brunner</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Ro Vomáčka</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Al Pala</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>My Razkevich</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>2 : 9</tr></td>
<tr><td class=brW>Ja Janouškovec</td><td class=bc>-</td><td class=bl>Ra Hejtman</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Do Zupančič</td><td class=bc>-</td><td class=bl>Gu Gripp</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Jo Vomáčka</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Jo Brunner</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Al Pala</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>My Razkevich</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ra Hejtman</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Gu Gripp</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Do Zupančič</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Jo Brunner</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ja Janouškovec</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Al Pala</td><td class=bc>-</td><td class=blW>Ra Hejtman</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Gu Gripp</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Do Zupančič</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Jo Vomáčka</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ra Hejtman</td><td class=bc>-</td><td class=bl>Jo Brunner</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Ja Kopecký</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>My Razkevich</td><td class=bc>-</td><td class=bl>Al Pala</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Gu Gripp</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Do Zupančič</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Jo Vomáčka</td><td class=bc>-</td><td class=bl>Ra Hejtman</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=brW>Jo Brunner</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Al Pala</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Gu Gripp</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Pa Pohořalý</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Ja Janouškovec</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Ra Hejtman</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Do Zupančič</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>My Razkevich</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Al Pala</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Jo Brunner</td><td class=bc>0 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group F</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2044&x=-409&p=Ja%20Tom%C3%A1%C5%A1t%C3%ADk">Ja Tomáštík</a></td><td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>5:4</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=br>56:26</td><td class=br>+30</td>
<td class=bc>13 - 0 - 2</td>
<td class=br><strong>26</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2099&x=-409&p=Ol%20Pylypenko">Ol Pylypenko</a></td><td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>7:3</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>7:3</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=br>63:29</td><td class=br>+34</td>
<td class=bc>12 - 2 - 1</td>
<td class=br><strong>26</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=910&x=-409&p=Vl%20Gobyov%C3%A1">Vl Gobyová</a></td><td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>6:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=br>53:30</td><td class=br>+23</td>
<td class=bc>11 - 3 - 1</td>
<td class=br><strong>25</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1957&x=-409&p=Er%20Bernhauser">Er Bernhauser</a></td><td class=kL>2:4</td>
<td class=kL>3:7</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kW>7:0</td>
<td class=kW>4:2</td>
<td class=kW>10:1</td>
<td class=br>59:40</td><td class=br>+19</td>
<td class=bc>8 - 3 - 4</td>
<td class=br><strong>19</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1896&x=-409&p=Ra%20Hrn%C4%8D%C3%AD%C5%99">Ra Hrnčíř</a></td><td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kL>3:6</td>
<td class=br>39:41</td><td class=br>-2</td>
<td class=bc>7 - 3 - 5</td>
<td class=br><strong>17</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1967&x=-409&p=An%20Ou%C5%99ada">An Ouřada</a></td><td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>4:6</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=br>46:39</td><td class=br>+7</td>
<td class=bc>7 - 3 - 5</td>
<td class=br><strong>17</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2020&x=-409&p=Da%20Jerabek">Da Jerabek</a></td><td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>45:37</td><td class=br>+8</td>
<td class=bc>7 - 3 - 5</td>
<td class=br><strong>17</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2096&x=-409&p=Vo%20Kvasnikov">Vo Kvasnikov</a></td><td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>4:6</td>
<td class=kL>3:6</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kL>0:1</td>
<td class=kW>8:0</td>
<td class=kW>8:0</td>
<td class=kL>1:3</td>
<td class=kW>8:2</td>
<td class=br>57:39</td><td class=br>+18</td>
<td class=bc>6 - 3 - 6</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2095&x=-409&p=Ja%20Hansson">Ja Hansson</a></td><td class=kW>3:1</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>8:2</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=br>40:32</td><td class=br>+8</td>
<td class=bc>7 - 0 - 8</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2046&x=-409&p=Ma%20Voj%C3%A1%C4%8Dek">Ma Vojáček</a></td><td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kW>8:2</td>
<td class=br>40:44</td><td class=br>-4</td>
<td class=bc>5 - 2 - 8</td>
<td class=br><strong>12</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1970&x=-409&p=Ji%20P%C3%ADse%C4%8Dka">Ji Písečka</a></td><td class=kL>4:5</td>
<td class=kL>3:7</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kW>6:4</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kL>2:8</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=br>45:58</td><td class=br>-13</td>
<td class=bc>4 - 4 - 7</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1252&x=-409&p=Ma%20Moravec">Ma Moravec</a></td><td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kW>1:0</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>0:0</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=br>22:32</td><td class=br>-10</td>
<td class=bc>5 - 2 - 8</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1869&x=-409&p=Pe%20Klazar">Pe Klazar</a></td><td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kL>0:8</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=br>37:49</td><td class=br>-12</td>
<td class=bc>5 - 2 - 8</td>
<td class=br><strong>12</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2101&x=-409&p=Ge%20Brunner">Ge Brunner</a></td><td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>3:7</td>
<td class=kL>0:8</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=br>19:55</td><td class=br>-36</td>
<td class=bc>1 - 5 - 9</td>
<td class=br><strong>7</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2015&x=-409&p=Mo%20Tich%C3%A1">Mo Tichá</a></td><td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=br>26:53</td><td class=br>-27</td>
<td class=bc>2 - 1 - 12</td>
<td class=br><strong>5</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1626&x=-409&p=Mi%20Hor%C3%A1kov%C3%A1">Mi Horáková</a></td><td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:10</td>
<td class=kW>6:3</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>2:8</td>
<td class=kL>0:7</td>
<td class=kL>2:8</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=br>24:67</td><td class=br>-43</td>
<td class=bc>2 - 0 - 13</td>
<td class=br><strong>4</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ge Brunner</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mo Tichá</td><td class=bc>-</td><td class=blW>Ma Vojáček</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ja Tomáštík</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Ol Pylypenko</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Da Jerabek</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ji Písečka</td><td class=bc>-</td><td class=bl>Mo Tichá</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Ge Brunner</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ma Vojáček</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Moravec</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>An Ouřada</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Ja Tomáštík</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ol Pylypenko</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ji Písečka</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>Mo Tichá</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ge Brunner</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>An Ouřada</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Da Jerabek</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ja Tomáštík</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Ol Pylypenko</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ji Písečka</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ma Moravec</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Mo Tichá</td><td class=bc>-</td><td class=blW>An Ouřada</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Er Bernhauser</td><td class=bc>-</td><td class=bl>Ge Brunner</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ma Vojáček</td><td class=bc>-</td><td class=blW>Da Jerabek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>4 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ja Hansson</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ol Pylypenko</td><td class=bc>-</td><td class=blW>Ja Tomáštík</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ma Moravec</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>An Ouřada</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Er Bernhauser</td><td class=bc>1 : 10</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Da Jerabek</td><td class=bc>-</td><td class=bl>Mo Tichá</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ge Brunner</td><td class=bc>-</td><td class=blW>Vo Kvasnikov</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Ol Pylypenko</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Tomáštík</td><td class=bc>-</td><td class=blW>Ja Hansson</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ji Písečka</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Er Bernhauser</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Mo Tichá</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ol Pylypenko</td><td class=bc>-</td><td class=bl>Ge Brunner</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ma Vojáček</td><td class=bc>-</td><td class=blW>Ja Tomáštík</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Er Bernhauser</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Da Jerabek</td><td class=bc>-</td><td class=blW>An Ouřada</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ma Moravec</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ol Pylypenko</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ja Tomáštík</td><td class=bc>-</td><td class=bl>Mo Tichá</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ge Brunner</td><td class=bc>-</td><td class=blW>Ja Hansson</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=blW>Er Bernhauser</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ol Pylypenko</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ja Tomáštík</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ja Hansson</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Mo Tichá</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ma Vojáček</td><td class=bc>-</td><td class=blW>Ge Brunner</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Ol Pylypenko</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Ja Tomáštík</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Moravec</td><td class=bc>-</td><td class=blW>Ja Hansson</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ma Vojáček</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Ge Brunner</td><td class=bc>-</td><td class=bl>Mo Tichá</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ol Pylypenko</td><td class=bc>-</td><td class=bl>Vo Kvasnikov</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Da Jerabek</td><td class=bc>-</td><td class=blW>Ja Tomáštík</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Er Bernhauser</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ma Vojáček</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=bl>Ge Brunner</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mo Tichá</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ol Pylypenko</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Ja Tomáštík</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Er Bernhauser</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ge Brunner</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Moravec</td><td class=bc>-</td><td class=bl>Mo Tichá</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=blW>Ja Tomáštík</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Ol Pylypenko</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Vojáček</td><td class=bc>-</td><td class=blW>Vo Kvasnikov</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Da Jerabek</td><td class=bc>-</td><td class=bl>Ge Brunner</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Mo Tichá</td><td class=bc>-</td><td class=blW>Er Bernhauser</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>An Ouřada</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ma Moravec</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ja Hansson</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Ja Tomáštík</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ol Pylypenko</td><td class=bc>-</td><td class=bl>Ma Vojáček</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ge Brunner</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=blW>Mo Tichá</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Da Jerabek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Moravec</td><td class=bc>-</td><td class=blW>An Ouřada</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=brW>Ma Vojáček</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ja Tomáštík</td><td class=bc>-</td><td class=bl>Ge Brunner</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Mo Tichá</td><td class=bc>-</td><td class=blW>Ol Pylypenko</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Vo Kvasnikov</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=brW>Da Jerabek</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ma Vojáček</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ge Brunner</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ja Hansson</td><td class=bc>-</td><td class=bl>Mo Tichá</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ja Tomáštík</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ol Pylypenko</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ma Moravec</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vo Kvasnikov</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>3 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group G</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1749&x=-409&p=Id%20Gripp">Id Gripp</a></td><td class=kx>*</td>
<td class=kW>1:0 + 3:1</td>
<td class=kT>2:2 + 0:1</td>
<td class=kW>2:1 + 3:1</td>
<td class=kW>2:0 + 2:1</td>
<td class=kW>3:0 + 2:4</td>
<td class=kW>3:2 + 3:2</td>
<td class=kW>4:1 + 4:1</td>
<td class=kT>1:1 + 4:2</td>
<td class=kL>2:3 + 2:3</td>
<td class=kW>5:1 + 4:0</td>
<td class=br>52:27</td><td class=br>+25</td>
<td class=bc>14 - 2 - 4</td>
<td class=br><strong>30</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2038&x=-409&p=Mi%20Moravec">Mi Moravec</a></td><td class=kL>0:1 + 1:3</td>
<td class=kx>*</td>
<td class=kW>6:1 + 3:2</td>
<td class=kL>0:1 + 4:0</td>
<td class=kW>5:0 + 5:0</td>
<td class=kT>2:2 + 3:3</td>
<td class=kW>5:2 + 5:2</td>
<td class=kW>1:0 + 3:3</td>
<td class=kT>3:3 + 3:3</td>
<td class=kW>4:1 + 3:2</td>
<td class=kW>7:0 + 5:0</td>
<td class=br>68:29</td><td class=br>+39</td>
<td class=bc>12 - 5 - 3</td>
<td class=br><strong>29</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1076&x=-409&p=Mi%20Zeman">Mi Zeman</a></td><td class=kT>2:2 + 1:0</td>
<td class=kL>1:6 + 2:3</td>
<td class=kx>*</td>
<td class=kW>2:0 + 2:1</td>
<td class=kL>1:2 + 3:1</td>
<td class=kW>3:1 + 2:2</td>
<td class=kW>8:1 + 4:3</td>
<td class=kW>4:3 + 2:5</td>
<td class=kT>0:0 + 5:1</td>
<td class=kW>6:2 + 6:1</td>
<td class=kW>7:1 + 4:3</td>
<td class=br>65:38</td><td class=br>+27</td>
<td class=bc>13 - 3 - 4</td>
<td class=br><strong>29</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1959&x=-409&p=On%20Chlebo">On Chlebo</a></td><td class=kL>1:2 + 1:3</td>
<td class=kW>1:0 + 0:4</td>
<td class=kL>0:2 + 1:2</td>
<td class=kx>*</td>
<td class=kW>1:0 + 4:0</td>
<td class=kT>0:0 + 1:0</td>
<td class=kL>0:1 + 1:0</td>
<td class=kW>5:0 + 5:0</td>
<td class=kW>2:0 + 2:0</td>
<td class=kW>4:0 + 4:0</td>
<td class=kW>3:1 + 6:0</td>
<td class=br>42:15</td><td class=br>+27</td>
<td class=bc>13 - 1 - 6</td>
<td class=br><strong>27</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1430&x=-409&p=Da%20Kadlec">Da Kadlec</a></td><td class=kL>0:2 + 1:2</td>
<td class=kL>0:5 + 0:5</td>
<td class=kW>2:1 + 1:3</td>
<td class=kL>0:1 + 0:4</td>
<td class=kx>*</td>
<td class=kW>4:2 + 4:2</td>
<td class=kW>4:2 + 3:5</td>
<td class=kL>2:4 + 2:1</td>
<td class=kW>3:1 + 3:1</td>
<td class=kW>8:2 + 7:0</td>
<td class=kW>7:0 + 4:0</td>
<td class=br>55:43</td><td class=br>+12</td>
<td class=bc>11 - 0 - 9</td>
<td class=br><strong>22</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2019&x=-409&p=Pa%20Janou%C5%A1kovec">Pa Janouškovec</a></td><td class=kL>0:3 + 4:2</td>
<td class=kT>2:2 + 3:3</td>
<td class=kL>1:3 + 2:2</td>
<td class=kT>0:0 + 0:1</td>
<td class=kL>2:4 + 2:4</td>
<td class=kx>*</td>
<td class=kT>2:2 + 2:4</td>
<td class=kW>2:1 + 2:1</td>
<td class=kW>4:2 + 2:2</td>
<td class=kW>8:2 + 2:1</td>
<td class=kW>7:1 + 7:1</td>
<td class=br>54:41</td><td class=br>+13</td>
<td class=bc>8 - 6 - 6</td>
<td class=br><strong>22</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2004&x=-409&p=Ur%20Me%C5%BEek">Ur Mežek</a></td><td class=kL>2:3 + 2:3</td>
<td class=kL>2:5 + 2:5</td>
<td class=kL>1:8 + 3:4</td>
<td class=kW>1:0 + 0:1</td>
<td class=kL>2:4 + 5:3</td>
<td class=kT>2:2 + 4:2</td>
<td class=kx>*</td>
<td class=kT>2:2 + 2:2</td>
<td class=kW>4:2 + 4:2</td>
<td class=kW>4:1 + 4:1</td>
<td class=kW>1:0 + 4:1</td>
<td class=br>51:51</td><td class=br>0</td>
<td class=bc>9 - 3 - 8</td>
<td class=br><strong>21</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2107&x=-409&p=Os%20Tabara">Os Tabara</a></td><td class=kL>1:4 + 1:4</td>
<td class=kL>0:1 + 3:3</td>
<td class=kL>3:4 + 5:2</td>
<td class=kL>0:5 + 0:5</td>
<td class=kW>4:2 + 1:2</td>
<td class=kL>1:2 + 1:2</td>
<td class=kT>2:2 + 2:2</td>
<td class=kx>*</td>
<td class=kL>0:6 + 2:2</td>
<td class=kW>5:3 + 3:3</td>
<td class=kL>0:3 + 6:1</td>
<td class=br>40:58</td><td class=br>-18</td>
<td class=bc>4 - 5 - 11</td>
<td class=br><strong>13</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2106&x=-409&p=Ol%20Tabara">Ol Tabara</a></td><td class=kT>1:1 + 2:4</td>
<td class=kT>3:3 + 3:3</td>
<td class=kT>0:0 + 1:5</td>
<td class=kL>0:2 + 0:2</td>
<td class=kL>1:3 + 1:3</td>
<td class=kL>2:4 + 2:2</td>
<td class=kL>2:4 + 2:4</td>
<td class=kW>6:0 + 2:2</td>
<td class=kx>*</td>
<td class=kL>1:3 + 1:3</td>
<td class=kW>5:1 + 3:1</td>
<td class=br>38:50</td><td class=br>-12</td>
<td class=bc>3 - 6 - 11</td>
<td class=br><strong>12</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2108&x=-409&p=Jo%20Andreas">Jo Andreas</a></td><td class=kW>3:2 + 3:2</td>
<td class=kL>1:4 + 2:3</td>
<td class=kL>2:6 + 1:6</td>
<td class=kL>0:4 + 0:4</td>
<td class=kL>2:8 + 0:7</td>
<td class=kL>2:8 + 1:2</td>
<td class=kL>1:4 + 1:4</td>
<td class=kL>3:5 + 3:3</td>
<td class=kW>3:1 + 3:1</td>
<td class=kx>*</td>
<td class=kW>3:1 + 0:2</td>
<td class=br>34:77</td><td class=br>-43</td>
<td class=bc>5 - 1 - 14</td>
<td class=br><strong>11</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2037&x=-409&p=Be%20Ponert">Be Ponert</a></td><td class=kL>1:5 + 0:4</td>
<td class=kL>0:7 + 0:5</td>
<td class=kL>1:7 + 3:4</td>
<td class=kL>1:3 + 0:6</td>
<td class=kL>0:7 + 0:4</td>
<td class=kL>1:7 + 1:7</td>
<td class=kL>0:1 + 1:4</td>
<td class=kW>3:0 + 1:6</td>
<td class=kL>1:5 + 1:3</td>
<td class=kL>1:3 + 2:0</td>
<td class=kx>*</td>
<td class=br>18:88</td><td class=br>-70</td>
<td class=bc>2 - 0 - 18</td>
<td class=br><strong>4</strong></td><td class=d>11.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Mi Moravec</td><td class=bc>-</td><td class=blW>On Chlebo</td><td class=bc>0 : 1 + 4 : 0</tr></td>
<tr><td class=br>Jo Andreas</td><td class=bc>-</td><td class=blW>Os Tabara</td><td class=bc>3 : 5 + 3 : 3</tr></td>
<tr><td class=brW>Id Gripp</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>3 : 0 + 2 : 4</tr></td>
<tr><td class=br>Ol Tabara</td><td class=bc>-</td><td class=blW>Ur Mežek</td><td class=bc>2 : 4 + 2 : 4</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Be Ponert</td><td class=bc>7 : 1 + 4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Ur Mežek</td><td class=bc>0 : 1 + 1 : 0</tr></td>
<tr><td class=br>Be Ponert</td><td class=bc>-</td><td class=blW>Jo Andreas</td><td class=bc>1 : 3 + 2 : 0</tr></td>
<tr><td class=br>Os Tabara</td><td class=bc>-</td><td class=blW>Id Gripp</td><td class=bc>1 : 4 + 1 : 4</tr></td>
<tr><td class=brW>Pa Janouškovec</td><td class=bc>-</td><td class=bl>Ol Tabara</td><td class=bc>4 : 2 + 2 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Da Kadlec</td><td class=bc>1 : 2 + 3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Da Kadlec</td><td class=bc>-</td><td class=bl>Jo Andreas</td><td class=bc>8 : 2 + 7 : 0</tr></td>
<tr><td class=brW>Id Gripp</td><td class=bc>-</td><td class=bl>Be Ponert</td><td class=bc>5 : 1 + 4 : 0</tr></td>
<tr><td class=brW>Ol Tabara</td><td class=bc>-</td><td class=bl>Os Tabara</td><td class=bc>6 : 0 + 2 : 2</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>0 : 0 + 1 : 0</tr></td>
<tr><td class=brW>Mi Moravec</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>5 : 2 + 5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>2 : 2 + 3 : 3</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Id Gripp</td><td class=bc>0 : 2 + 1 : 2</tr></td>
<tr><td class=br>Be Ponert</td><td class=bc>-</td><td class=blW>Ol Tabara</td><td class=bc>1 : 5 + 1 : 3</tr></td>
<tr><td class=br>Os Tabara</td><td class=bc>-</td><td class=blW>On Chlebo</td><td class=bc>0 : 5 + 0 : 5</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Jo Andreas</td><td class=bc>6 : 2 + 6 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ur Mežek</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>2 : 2 + 4 : 2</tr></td>
<tr><td class=br>Ol Tabara</td><td class=bc>-</td><td class=blW>Da Kadlec</td><td class=bc>1 : 3 + 1 : 3</tr></td>
<tr><td class=brW>On Chlebo</td><td class=bc>-</td><td class=bl>Be Ponert</td><td class=bc>3 : 1 + 6 : 0</tr></td>
<tr><td class=brW>Mi Moravec</td><td class=bc>-</td><td class=bl>Os Tabara</td><td class=bc>1 : 0 + 3 : 3</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=bl>Id Gripp</td><td class=bc>2 : 2 + 1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Jo Andreas</td><td class=bc>-</td><td class=bl>Id Gripp</td><td class=bc>3 : 2 + 3 : 2</tr></td>
<tr><td class=br>Os Tabara</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>2 : 2 + 2 : 2</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>On Chlebo</td><td class=bc>0 : 1 + 0 : 4</tr></td>
<tr><td class=br>Be Ponert</td><td class=bc>-</td><td class=blW>Mi Moravec</td><td class=bc>0 : 7 + 0 : 5</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=bl>Ol Tabara</td><td class=bc>0 : 0 + 5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Jo Andreas</td><td class=bc>-</td><td class=bl>Ol Tabara</td><td class=bc>3 : 1 + 3 : 1</tr></td>
<tr><td class=br>Os Tabara</td><td class=bc>-</td><td class=blW>Pa Janouškovec</td><td class=bc>1 : 2 + 1 : 2</tr></td>
<tr><td class=brW>Mi Moravec</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>5 : 0 + 5 : 0</tr></td>
<tr><td class=brW>Ur Mežek</td><td class=bc>-</td><td class=bl>Be Ponert</td><td class=bc>1 : 0 + 4 : 1</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>2 : 0 + 2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Id Gripp</td><td class=bc>-</td><td class=bl>Ol Tabara</td><td class=bc>1 : 1 + 4 : 2</tr></td>
<tr><td class=br>Jo Andreas</td><td class=bc>-</td><td class=blW>On Chlebo</td><td class=bc>0 : 4 + 0 : 4</tr></td>
<tr><td class=br>Be Ponert</td><td class=bc>-</td><td class=blW>Pa Janouškovec</td><td class=bc>1 : 7 + 1 : 7</tr></td>
<tr><td class=brW>Da Kadlec</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>4 : 2 + 3 : 5</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Mi Moravec</td><td class=bc>1 : 6 + 2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Id Gripp</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>2 : 1 + 3 : 1</tr></td>
<tr><td class=brW>Mi Moravec</td><td class=bc>-</td><td class=bl>Jo Andreas</td><td class=bc>4 : 1 + 3 : 2</tr></td>
<tr><td class=brW>Be Ponert</td><td class=bc>-</td><td class=bl>Os Tabara</td><td class=bc>3 : 0 + 1 : 6</tr></td>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=blW>Da Kadlec</td><td class=bc>2 : 4 + 2 : 4</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>8 : 1 + 4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ol Tabara</td><td class=bc>-</td><td class=blW>On Chlebo</td><td class=bc>0 : 2 + 0 : 2</tr></td>
<tr><td class=brW>Id Gripp</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>1 : 0 + 3 : 1</tr></td>
<tr><td class=br>Jo Andreas</td><td class=bc>-</td><td class=blW>Ur Mežek</td><td class=bc>1 : 4 + 1 : 4</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Os Tabara</td><td class=bc>2 : 4 + 2 : 1</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>3 : 1 + 2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ol Tabara</td><td class=bc>-</td><td class=bl>Mi Moravec</td><td class=bc>3 : 3 + 3 : 3</tr></td>
<tr><td class=br>Ur Mežek</td><td class=bc>-</td><td class=blW>Id Gripp</td><td class=bc>2 : 3 + 2 : 3</tr></td>
<tr><td class=brW>Pa Janouškovec</td><td class=bc>-</td><td class=bl>Jo Andreas</td><td class=bc>8 : 2 + 2 : 1</tr></td>
<tr><td class=brW>Da Kadlec</td><td class=bc>-</td><td class=bl>Be Ponert</td><td class=bc>7 : 0 + 4 : 0</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Os Tabara</td><td class=bc>4 : 3 + 2 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</table></div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
