<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2024">Czech Open</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 3</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2074&x=-409&p=Ma%20Jakseboga">Ma Jakseboga</a></td><td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=kW>2:0</td>
<td class=kL>0:1</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>14:1</td>
<td class=kW>7:0</td>
<td class=br>93:24</td><td class=br>+69</td>
<td class=bc>17 - 2 - 1</td>
<td class=br><strong>36</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1649&x=-409&p=Ra%20Miglinieks">Ra Miglinieks</a></td><td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>5:4</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>8:2</td>
<td class=kW>5:4</td>
<td class=kW>8:1</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=br>89:39</td><td class=br>+50</td>
<td class=bc>15 - 4 - 1</td>
<td class=br><strong>34</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2077&x=-409&p=Pe%20Miettinen">Pe Miettinen</a></td><td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>1:4</td>
<td class=kW>6:2</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>9:0</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>9:1</td>
<td class=kW>2:1</td>
<td class=br>89:29</td><td class=br>+60</td>
<td class=bc>16 - 1 - 3</td>
<td class=br><strong>33</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1194&x=-409&p=He%20Steen">He Steen</a></td><td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>2:5</td>
<td class=kT>0:0</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kW>7:1</td>
<td class=kW>9:1</td>
<td class=kW>4:3</td>
<td class=kW>8:2</td>
<td class=kW>6:0</td>
<td class=kW>7:2</td>
<td class=br>89:42</td><td class=br>+47</td>
<td class=bc>13 - 4 - 3</td>
<td class=br><strong>30</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1153&x=-409&p=Ot%20Pesala">Ot Pesala</a></td><td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kW>8:0</td>
<td class=kW>6:2</td>
<td class=kW>7:1</td>
<td class=kW>9:1</td>
<td class=kW>7:1</td>
<td class=br>81:38</td><td class=br>+43</td>
<td class=bc>14 - 2 - 4</td>
<td class=br><strong>30</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1976&x=-409&p=Jo%20Astrom">Jo Astrom</a></td><td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kW>9:0</td>
<td class=kW>9:1</td>
<td class=br>78:38</td><td class=br>+40</td>
<td class=bc>12 - 4 - 4</td>
<td class=br><strong>28</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2083&x=-409&p=Da%20Nygard">Da Nygard</a></td><td class=kL>0:6</td>
<td class=kL>2:6</td>
<td class=kW>4:3</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=br>54:41</td><td class=br>+13</td>
<td class=bc>11 - 5 - 4</td>
<td class=br><strong>27</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2104&x=-409&p=Ro%20Kerns">Ro Kerns</a></td><td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>8:0</td>
<td class=kW>2:0</td>
<td class=br>52:34</td><td class=br>+18</td>
<td class=bc>10 - 5 - 5</td>
<td class=br><strong>25</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1828&x=-409&p=Tr%20Mansson">Tr Mansson</a></td><td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kW>9:2</td>
<td class=kW>7:0</td>
<td class=br>64:41</td><td class=br>+23</td>
<td class=bc>11 - 1 - 8</td>
<td class=br><strong>23</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=547&x=-409&p=To%20Lahu%C4%8Dk%C3%BD">To Lahučký</a></td><td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=kW>9:1</td>
<td class=kW>4:0</td>
<td class=br>57:51</td><td class=br>+6</td>
<td class=bc>9 - 3 - 8</td>
<td class=br><strong>21</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1974&x=-409&p=Ja%20Obadi%C4%8D">Ja Obadič</a></td><td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kT>0:0</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>7:3</td>
<td class=kW>7:2</td>
<td class=kW>8:0</td>
<td class=br>61:44</td><td class=br>+17</td>
<td class=bc>8 - 5 - 7</td>
<td class=br><strong>21</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1912&x=-409&p=Al%20Krejza">Al Krejza</a></td><td class=kL>0:4</td>
<td class=kL>4:5</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kT>5:5</td>
<td class=kW>9:3</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>9:1</td>
<td class=br>67:65</td><td class=br>+2</td>
<td class=bc>8 - 3 - 9</td>
<td class=br><strong>19</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2103&x=-409&p=Gu%20Nilsson">Gu Nilsson</a></td><td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kW>8:0</td>
<td class=kW>4:1</td>
<td class=br>53:55</td><td class=br>-2</td>
<td class=bc>8 - 2 - 10</td>
<td class=br><strong>18</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>D</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=319&x=-409&p=Ka%20Hudec">Ka Hudec</a></td><td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kW>7:3</td>
<td class=kW>4:2</td>
<td class=kW>6:4</td>
<td class=kW>10:0</td>
<td class=kW>4:0</td>
<td class=br>56:57</td><td class=br>-1</td>
<td class=bc>6 - 4 - 10</td>
<td class=br><strong>16</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1173&x=-409&p=Jo%20Mal%C3%BD">Jo Malý</a></td><td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=br>54:64</td><td class=br>-10</td>
<td class=bc>6 - 4 - 10</td>
<td class=br><strong>16</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>E</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=442&x=-409&p=Pa%20Poho%C5%99al%C3%BD">Pa Pohořalý</a></td><td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kT>5:5</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kW>7:3</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=br>46:67</td><td class=br>-21</td>
<td class=bc>5 - 3 - 12</td>
<td class=br><strong>13</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>E</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1907&x=-409&p=Al%20Pala">Al Pala</a></td><td class=kL>3:6</td>
<td class=kL>2:8</td>
<td class=kL>0:9</td>
<td class=kL>1:9</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>3:9</td>
<td class=kL>1:5</td>
<td class=kL>3:7</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=br>37:102</td><td class=br>-65</td>
<td class=bc>5 - 0 - 15</td>
<td class=br><strong>10</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>F</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=910&x=-409&p=Vl%20Gobyov%C3%A1">Vl Gobyová</a></td><td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>2:6</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=br>45:73</td><td class=br>-28</td>
<td class=bc>4 - 1 - 15</td>
<td class=br><strong>9</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>F</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1967&x=-409&p=An%20Ou%C5%99ada">An Ouřada</a></td><td class=kL>2:5</td>
<td class=kL>1:8</td>
<td class=kL>1:3</td>
<td class=kL>2:8</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>1:5</td>
<td class=kL>3:7</td>
<td class=kL>1:6</td>
<td class=kW>5:2</td>
<td class=kL>4:6</td>
<td class=kL>1:6</td>
<td class=kL>3:7</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kW>10:0</td>
<td class=br>51:97</td><td class=br>-46</td>
<td class=bc>3 - 2 - 15</td>
<td class=br><strong>8</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>G</td><td class=d>20.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2108&x=-409&p=Jo%20Andreas">Jo Andreas</a></td><td class=kL>1:14</td>
<td class=kL>0:6</td>
<td class=kL>1:9</td>
<td class=kL>0:6</td>
<td class=kL>1:9</td>
<td class=kL>0:9</td>
<td class=kL>2:6</td>
<td class=kL>0:8</td>
<td class=kL>2:9</td>
<td class=kL>1:9</td>
<td class=kL>2:7</td>
<td class=kL>2:6</td>
<td class=kL>0:8</td>
<td class=kL>0:10</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=br>21:136</td><td class=br>-115</td>
<td class=bc>1 - 1 - 18</td>
<td class=br><strong>3</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>G</td><td class=d>21.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2037&x=-409&p=Be%20Ponert">Be Ponert</a></td><td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>2:7</td>
<td class=kL>1:7</td>
<td class=kL>1:9</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>0:8</td>
<td class=kL>1:9</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>3:6</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>0:10</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=br>12:112</td><td class=br>-100</td>
<td class=bc>0 - 0 - 20</td>
<td class=br><strong>0</strong></td><td class=d>21.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>To Lahučký</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=bl>Da Nygard</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Be Ponert</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ot Pesala</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Al Pala</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ot Pesala</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Al Pala</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>3 : 9</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=blW>Gu Nilsson</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Jo Andreas</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>He Steen</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Be Ponert</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Jo Andreas</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>He Steen</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Be Ponert</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>To Lahučký</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ja Obadič</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Gu Nilsson</td><td class=bc>-</td><td class=blW>Pe Miettinen</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=blW>Da Nygard</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Gu Nilsson</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Jo Andreas</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Ot Pesala</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>To Lahučký</td><td class=bc>-</td><td class=bl>Al Pala</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ot Pesala</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Al Pala</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>An Ouřada</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=blW>Pe Miettinen</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Be Ponert</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Jo Andreas</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>1 : 14</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Be Ponert</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>To Lahučký</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Ot Pesala</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>Al Pala</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Pe Miettinen</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Gu Nilsson</td><td class=bc>-</td><td class=blW>Da Nygard</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Jo Andreas</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>He Steen</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Be Ponert</td><td class=bc>-</td><td class=blW>To Lahučký</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=blW>He Steen</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ot Pesala</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Al Pala</td><td class=bc>-</td><td class=blW>Pe Miettinen</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=bl>Gu Nilsson</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jo Andreas</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Be Ponert</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pe Miettinen</td><td class=bc>-</td><td class=blW>Ot Pesala</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Al Pala</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Gu Nilsson</td><td class=bc>-</td><td class=blW>An Ouřada</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Da Nygard</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ot Pesala</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Al Pala</td><td class=bc>-</td><td class=blW>Gu Nilsson</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Da Nygard</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Jo Andreas</td><td class=bc>-</td><td class=blW>To Lahučký</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>He Steen</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Be Ponert</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Pe Miettinen</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=blW>He Steen</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pe Miettinen</td><td class=bc>-</td><td class=bl>Be Ponert</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Gu Nilsson</td><td class=bc>-</td><td class=blW>Ot Pesala</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Jo Andreas</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>To Lahučký</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Jo Andreas</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=blW>Pe Miettinen</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Da Nygard</td><td class=bc>-</td><td class=bl>Al Pala</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ja Obadič</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ot Pesala</td><td class=bc>-</td><td class=bl>Da Nygard</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Pala</td><td class=bc>-</td><td class=blW>Ja Obadič</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Be Ponert</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Gu Nilsson</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>He Steen</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Gu Nilsson</td><td class=bc>-</td><td class=bl>Be Ponert</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Da Nygard</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=bl>Ot Pesala</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Al Pala</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pe Miettinen</td><td class=bc>-</td><td class=bl>Jo Andreas</td><td class=bc>9 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=blW>Pe Miettinen</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Jo Andreas</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>He Steen</td><td class=bc>-</td><td class=bl>Gu Nilsson</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Be Ponert</td><td class=bc>-</td><td class=blW>Da Nygard</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Ja Obadič</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ot Pesala</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Ja Obadič</td><td class=bc>-</td><td class=bl>Be Ponert</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pe Miettinen</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Gu Nilsson</td><td class=bc>-</td><td class=bl>Jo Andreas</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=bl>He Steen</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Gu Nilsson</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Pa Pohořalý</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Al Pala</td><td class=bc>-</td><td class=blW>Ot Pesala</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>To Lahučký</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>Pe Miettinen</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Pe Miettinen</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jo Andreas</td><td class=bc>-</td><td class=blW>Da Nygard</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>He Steen</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Be Ponert</td><td class=bc>-</td><td class=blW>An Ouřada</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Al Pala</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Al Pala</td><td class=bc>-</td><td class=bl>Be Ponert</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ot Pesala</td><td class=bc>-</td><td class=blW>Pa Pohořalý</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Gu Nilsson</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ja Obadič</td><td class=bc>-</td><td class=bl>Jo Andreas</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>He Steen</td><td class=bc>2 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Da Nygard</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Jo Andreas</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>He Steen</td><td class=bc>-</td><td class=bl>Al Pala</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Be Ponert</td><td class=bc>-</td><td class=blW>Ot Pesala</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Pe Miettinen</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>Gu Nilsson</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Gu Nilsson</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Da Nygard</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ja Obadič</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Al Pala</td><td class=bc>-</td><td class=bl>Jo Andreas</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>To Lahučký</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Pe Miettinen</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Be Ponert</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=blW>Pe Miettinen</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Gu Nilsson</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Da Nygard</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ot Pesala</td><td class=bc>-</td><td class=blW>He Steen</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Al Pala</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Jo Andreas</td><td class=bc>-</td><td class=blW>Ot Pesala</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>He Steen</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Pe Miettinen</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Gu Nilsson</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Da Nygard</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Al Pala</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ot Pesala</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Jo Andreas</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Be Ponert</td><td class=bc>-</td><td class=blW>He Steen</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=blW>Pe Miettinen</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Jo Andreas</td><td class=bc>-</td><td class=bl>Be Ponert</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=blW>Gu Nilsson</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Da Nygard</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Ja Obadič</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Al Pala</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Ot Pesala</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>26</td></tr>
<tr><td class=br>Al Pala</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ot Pesala</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Gu Nilsson</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=blW>Da Nygard</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>27</td></tr>
<tr><td class=br>Be Ponert</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>He Steen</td><td class=bc>-</td><td class=bl>Jo Andreas</td><td class=bc>6 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
