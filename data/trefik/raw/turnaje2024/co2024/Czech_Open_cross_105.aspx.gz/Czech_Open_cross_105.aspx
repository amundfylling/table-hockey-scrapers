<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2024">Czech Open</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2086&x=-409&p=Ni%20Lacis">Ni Lacis</a></td><td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>6:4</td>
<td class=br>60:30</td><td class=br>+30</td>
<td class=bc>13 - 1 - 1</td>
<td class=br><strong>27</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1709&x=-409&p=Mi%20Bla%C5%BEek">Mi Blažek</a></td><td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kW>6:2</td>
<td class=kW>7:2</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=br>49:26</td><td class=br>+23</td>
<td class=bc>11 - 1 - 3</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=559&x=-409&p=Bj%20Axelsen">Bj Axelsen</a></td><td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>8:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=br>53:28</td><td class=br>+25</td>
<td class=bc>11 - 1 - 3</td>
<td class=br><strong>23</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=53&x=-409&p=V%C3%A1%20Pikl">Vá Pikl</a></td><td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=br>38:24</td><td class=br>+14</td>
<td class=bc>9 - 3 - 3</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=261&x=-409&p=Da%20Cibulka">Da Cibulka</a></td><td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>7:2</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=br>41:32</td><td class=br>+9</td>
<td class=bc>7 - 4 - 4</td>
<td class=br><strong>18</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1912&x=-409&p=Al%20Krejza">Al Krejza</a></td><td class=kT>3:3</td>
<td class=kL>2:7</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=br>43:37</td><td class=br>+6</td>
<td class=bc>6 - 5 - 4</td>
<td class=br><strong>17</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1619&x=-409&p=Mi%20Borgh">Mi Borgh</a></td><td class=kL>4:5</td>
<td class=kL>0:2</td>
<td class=kL>1:8</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kL>2:4</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=br>44:44</td><td class=br>0</td>
<td class=bc>6 - 3 - 6</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1927&x=-409&p=Vo%20Kraus">Vo Kraus</a></td><td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=br>35:38</td><td class=br>-3</td>
<td class=bc>6 - 2 - 7</td>
<td class=br><strong>14</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1488&x=-409&p=Ra%20Pommerenke">Ra Pommerenke</a></td><td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:7</td>
<td class=kT>0:0</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=br>35:44</td><td class=br>-9</td>
<td class=bc>5 - 4 - 6</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2103&x=-409&p=Gu%20Nilsson">Gu Nilsson</a></td><td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=br>40:42</td><td class=br>-2</td>
<td class=bc>6 - 2 - 7</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2091&x=-409&p=Ma%20Kyllergard">Ma Kyllergard</a></td><td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kW>7:1</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=br>37:38</td><td class=br>-1</td>
<td class=bc>6 - 0 - 9</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1940&x=-409&p=Ma%20Ko%C5%A1%C5%88ar">Ma Košňar</a></td><td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kT>0:0</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=br>27:42</td><td class=br>-15</td>
<td class=bc>5 - 2 - 8</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=227&x=-409&p=Mi%20Ma%C5%A1ika">Mi Mašika</a></td><td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kL>3:6</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>0:5</td>
<td class=br>30:52</td><td class=br>-22</td>
<td class=bc>4 - 1 - 10</td>
<td class=br><strong>9</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2017&x=-409&p=Ka%20Pirumshoeva">Ka Pirumshoeva</a></td><td class=kW>3:2</td>
<td class=kL>4:5</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=br>22:46</td><td class=br>-24</td>
<td class=bc>3 - 2 - 10</td>
<td class=br><strong>8</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2089&x=-409&p=Ju%20Itkonen">Ju Itkonen</a></td><td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=br>30:43</td><td class=br>-13</td>
<td class=bc>2 - 3 - 10</td>
<td class=br><strong>7</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1630&x=-409&p=Pe%20Holub">Pe Holub</a></td><td class=kL>4:6</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=br>31:49</td><td class=br>-18</td>
<td class=bc>3 - 0 - 12</td>
<td class=br><strong>6</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Mi Borgh</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Ju Itkonen</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Gu Nilsson</td><td class=bc>-</td><td class=blW>Ni Lacis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Ma Kyllergard</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Vo Kraus</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ju Itkonen</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Gu Nilsson</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Kyllergard</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ni Lacis</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>6 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Mi Borgh</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Gu Nilsson</td><td class=bc>-</td><td class=bl>Ju Itkonen</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ma Kyllergard</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Ni Lacis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Vo Kraus</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>Gu Nilsson</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Kyllergard</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ju Itkonen</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ni Lacis</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Mi Borgh</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Gu Nilsson</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Vo Kraus</td><td class=bc>-</td><td class=bl>Ma Kyllergard</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=bl>Ju Itkonen</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>Ni Lacis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>Gu Nilsson</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Kyllergard</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ka Pirumshoeva</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ni Lacis</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ju Itkonen</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Kyllergard</td><td class=bc>-</td><td class=blW>Mi Borgh</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Gu Nilsson</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Ni Lacis</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ju Itkonen</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Ma Kyllergard</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Gu Nilsson</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ni Lacis</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ju Itkonen</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Mi Borgh</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ma Kyllergard</td><td class=bc>-</td><td class=blW>Ni Lacis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Gu Nilsson</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Vo Kraus</td><td class=bc>-</td><td class=bl>Ju Itkonen</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ni Lacis</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Ma Kyllergard</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Gu Nilsson</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ju Itkonen</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ni Lacis</td><td class=bc>-</td><td class=bl>Mi Borgh</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ma Kyllergard</td><td class=bc>-</td><td class=bl>Ju Itkonen</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Mi Mašika</td><td class=bc>-</td><td class=bl>Gu Nilsson</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Ka Pirumshoeva</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=blW>Ni Lacis</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ju Itkonen</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Ma Kyllergard</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Gu Nilsson</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Mi Borgh</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ni Lacis</td><td class=bc>-</td><td class=bl>Ju Itkonen</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Vo Kraus</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Kyllergard</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Gu Nilsson</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Ju Itkonen</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Ni Lacis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Vo Kraus</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>4 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Gu Nilsson</td><td class=bc>-</td><td class=blW>Ma Kyllergard</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ju Itkonen</td><td class=bc>-</td><td class=bl>Mi Borgh</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ni Lacis</td><td class=bc>-</td><td class=blW>Ka Pirumshoeva</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Gu Nilsson</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ma Kyllergard</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>3 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
