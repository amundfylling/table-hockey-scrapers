<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2024">Czech Open</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 4</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=882&x=-409&p=Mi%20Saulitis">Mi Saulitis</a></td><td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kL>0:5</td>
<td class=kW>5:3</td>
<td class=kW>5:3</td>
<td class=kW>7:5</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=br>76:35</td><td class=br>+41</td>
<td class=bc>16 - 2 - 1</td>
<td class=br><strong>34</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=409&x=-409&p=Pa%20Petr">Pa Petr</a></td><td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>8:1</td>
<td class=kW>6:2</td>
<td class=kW>7:0</td>
<td class=kW>10:1</td>
<td class=kW>8:1</td>
<td class=br>95:23</td><td class=br>+72</td>
<td class=bc>16 - 2 - 1</td>
<td class=br><strong>34</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1772&x=-409&p=El%20Silin%C5%A1">El Silinš</a></td><td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kW>3:2</td>
<td class=br>70:39</td><td class=br>+31</td>
<td class=bc>15 - 2 - 2</td>
<td class=br><strong>32</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2078&x=-409&p=Kr%20Lagzdina">Kr Lagzdina</a></td><td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>8:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=br>66:36</td><td class=br>+30</td>
<td class=bc>13 - 1 - 5</td>
<td class=br><strong>27</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1189&x=-409&p=Ka%20Balodis">Ka Balodis</a></td><td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>7:4</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>7:3</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=br>62:37</td><td class=br>+25</td>
<td class=bc>11 - 4 - 4</td>
<td class=br><strong>26</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1151&x=-409&p=Ju%20Rautio">Ju Rautio</a></td><td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kW>5:4</td>
<td class=kW>7:0</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>9:0</td>
<td class=kT>1:1</td>
<td class=kW>6:0</td>
<td class=kW>8:0</td>
<td class=br>68:32</td><td class=br>+36</td>
<td class=bc>10 - 5 - 4</td>
<td class=br><strong>25</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1981&x=-409&p=Po%20Kvasnikova">Po Kvasnikova</a></td><td class=kT>1:1</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>0:0</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=kW>6:3</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=br>50:32</td><td class=br>+18</td>
<td class=bc>10 - 4 - 5</td>
<td class=br><strong>24</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=841&x=-409&p=Ma%20Le%C5%BE%C3%ADk">Ma Ležík</a></td><td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kW>7:1</td>
<td class=kW>5:3</td>
<td class=kW>7:0</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>7:6</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=br>66:41</td><td class=br>+25</td>
<td class=bc>11 - 2 - 6</td>
<td class=br><strong>24</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=201&x=-409&p=To%20Bucek">To Bucek</a></td><td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kT>0:0</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>4:6</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>5:7</td>
<td class=kW>7:1</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=br>59:46</td><td class=br>+13</td>
<td class=bc>9 - 3 - 7</td>
<td class=br><strong>21</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2084&x=-409&p=Ha%20Gals">Ha Gals</a></td><td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kL>0:1</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=br>52:35</td><td class=br>+17</td>
<td class=bc>9 - 3 - 7</td>
<td class=br><strong>21</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=354&x=-409&p=Ti%20Varga">Ti Varga</a></td><td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>4:7</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kT>0:0</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>7:0</td>
<td class=kW>6:1</td>
<td class=br>57:48</td><td class=br>+9</td>
<td class=bc>9 - 2 - 8</td>
<td class=br><strong>20</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=559&x=-409&p=Bj%20Axelsen">Bj Axelsen</a></td><td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kW>6:4</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>55:57</td><td class=br>-2</td>
<td class=bc>8 - 2 - 9</td>
<td class=br><strong>18</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1488&x=-409&p=Ra%20Pommerenke">Ra Pommerenke</a></td><td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>7:1</td>
<td class=br>49:52</td><td class=br>-3</td>
<td class=bc>8 - 0 - 11</td>
<td class=br><strong>16</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>D</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1527&x=-409&p=Mi%20Mitro%20ml.">Mi Mitro ml.</a></td><td class=kW>5:0</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:8</td>
<td class=kL>2:3</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kT>0:0</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kT>0:0</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=br>25:52</td><td class=br>-27</td>
<td class=bc>6 - 3 - 10</td>
<td class=br><strong>15</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1968&x=-409&p=Mi%20Tou%C5%A1">Mi Touš</a></td><td class=kL>3:5</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kW>7:5</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kT>5:5</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=br>53:62</td><td class=br>-9</td>
<td class=bc>6 - 2 - 11</td>
<td class=br><strong>14</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>E</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1639&x=-409&p=Ja%20Ou%C5%99ada">Ja Ouřada</a></td><td class=kL>3:5</td>
<td class=kL>1:8</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>1:7</td>
<td class=kW>1:0</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=br>33:75</td><td class=br>-42</td>
<td class=bc>5 - 0 - 14</td>
<td class=br><strong>10</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>E</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2110&x=-409&p=My%20Razkevich">My Razkevich</a></td><td class=kL>5:7</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>3:7</td>
<td class=kL>0:9</td>
<td class=kL>3:6</td>
<td class=kL>6:7</td>
<td class=kL>2:6</td>
<td class=kL>0:6</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kT>5:5</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>7:4</td>
<td class=br>49:89</td><td class=br>-40</td>
<td class=bc>4 - 1 - 14</td>
<td class=br><strong>9</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>F</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2095&x=-409&p=Ja%20Hansson">Ja Hansson</a></td><td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kT>0:0</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=br>22:65</td><td class=br>-43</td>
<td class=bc>2 - 3 - 14</td>
<td class=br><strong>7</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>F</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1252&x=-409&p=Ma%20Moravec">Ma Moravec</a></td><td class=kL>1:4</td>
<td class=kL>1:10</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>0:1</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=br>12:91</td><td class=br>-79</td>
<td class=bc>1 - 1 - 17</td>
<td class=br><strong>3</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>G</td><td class=d>20.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1749&x=-409&p=Id%20Gripp">Id Gripp</a></td><td class=kL>2:6</td>
<td class=kL>1:8</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>0:8</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>4:7</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=br>20:92</td><td class=br>-72</td>
<td class=bc>0 - 0 - 19</td>
<td class=br><strong>0</strong></td><td class=d>20.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ti Varga</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Ka Balodis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Saulitis</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Id Gripp</td><td class=bc>-</td><td class=blW>My Razkevich</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Kr Lagzdina</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Moravec</td><td class=bc>-</td><td class=blW>Mi Mitro ml.</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=blW>Mi Saulitis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ha Gals</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Id Gripp</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Po Kvasnikova</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mi Mitro ml.</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mi Saulitis</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ti Varga</td><td class=bc>-</td><td class=blW>My Razkevich</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Ka Balodis</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Id Gripp</td><td class=bc>-</td><td class=blW>Ja Ouřada</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Moravec</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Mi Mitro ml.</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Kr Lagzdina</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=blW>Mi Saulitis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Ju Rautio</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Ti Varga</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ha Gals</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>Id Gripp</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=bl>Mi Saulitis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ti Varga</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ma Moravec</td><td class=bc>-</td><td class=blW>Ka Balodis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Mi Mitro ml.</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Mi Touš</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Id Gripp</td><td class=bc>-</td><td class=blW>Kr Lagzdina</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Saulitis</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=blW>Ja Ouřada</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ma Moravec</td><td class=bc>-</td><td class=blW>Mi Saulitis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ha Gals</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ja Hansson</td><td class=bc>-</td><td class=bl>Id Gripp</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Id Gripp</td><td class=bc>-</td><td class=blW>Ha Gals</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Mi Mitro ml.</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ti Varga</td><td class=bc>-</td><td class=blW>Kr Lagzdina</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Ka Balodis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Po Kvasnikova</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Ti Varga</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ka Balodis</td><td class=bc>-</td><td class=bl>Id Gripp</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ha Gals</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Saulitis</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Mi Mitro ml.</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Ju Rautio</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=blW>Kr Lagzdina</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Mi Saulitis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Id Gripp</td><td class=bc>-</td><td class=blW>Mi Touš</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Moravec</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 10</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ti Varga</td><td class=bc>-</td><td class=blW>Ha Gals</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Ka Balodis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>My Razkevich</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Mi Saulitis</td><td class=bc>-</td><td class=bl>Id Gripp</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ha Gals</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Touš</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>7 : 5</tr></td>
<tr><td class=brW>Ka Balodis</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Kr Lagzdina</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Mi Mitro ml.</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Id Gripp</td><td class=bc>-</td><td class=blW>Ju Rautio</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=blW>Ha Gals</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Mi Saulitis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=blW>Ka Balodis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ti Varga</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Mi Saulitis</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Moravec</td><td class=bc>-</td><td class=blW>Po Kvasnikova</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ja Hansson</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Id Gripp</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Ha Gals</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ka Balodis</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>7 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Ka Balodis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ti Varga</td><td class=bc>-</td><td class=blW>Ju Rautio</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Id Gripp</td><td class=bc>-</td><td class=blW>Ma Moravec</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ja Ouřada</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Id Gripp</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ha Gals</td><td class=bc>-</td><td class=bl>Mi Mitro ml.</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Moravec</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ka Balodis</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=blW>Mi Saulitis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=blW>Po Kvasnikova</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Kr Lagzdina</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Mi Saulitis</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>7 : 5</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Id Gripp</td><td class=bc>-</td><td class=blW>Po Kvasnikova</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Mi Touš</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Ja Ouřada</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Mi Saulitis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=blW>Ju Rautio</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Id Gripp</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ha Gals</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mi Mitro ml.</td><td class=bc>-</td><td class=blW>Ka Balodis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ti Varga</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=blW>Kr Lagzdina</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Ti Varga</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Touš</td><td class=bc>-</td><td class=bl>Mi Mitro ml.</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ma Moravec</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Mi Saulitis</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>Ha Gals</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Id Gripp</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Ka Balodis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ti Varga</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>Mi Saulitis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>My Razkevich</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Ju Rautio</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=bl>Ha Gals</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Id Gripp</td><td class=bc>-</td><td class=blW>Ti Varga</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Mi Touš</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Saulitis</td><td class=bc>-</td><td class=bl>Kr Lagzdina</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>My Razkevich</td><td class=bc>7 : 6</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Mi Mitro ml.</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ma Moravec</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ka Balodis</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ti Varga</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ha Gals</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Id Gripp</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Mi Saulitis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>My Razkevich</td><td class=bc>-</td><td class=blW>Po Kvasnikova</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Mi Mitro ml.</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ja Ouřada</td><td class=bc>-</td><td class=bl>Ma Moravec</td><td class=bc>5 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
