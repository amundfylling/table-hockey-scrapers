<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2024">Czech Open</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group A2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>25</td>
<td class=ic>26</td>
<td class=ic>27</td>
<td class=ic>28</td>
<td class=ic>29</td>
<td class=ic>30</td>
<td class=ic>31</td>
<td class=ic>32</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1761&x=-409&p=Ra%20Kalnin%C5%A1">Ra Kalninš</a></td><td class=kx>*</td>
<td class=kW>4:3 K</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kL>2:4 K</td>
<td class=kL>3:8</td>
<td class=kW>5:4</td>
<td class=kL>2:6</td>
<td class=kW>4:1</td>
<td class=kL>1:2 K</td>
<td class=kW>3:2</td>
<td class=kW>5:1 K</td>
<td class=kT>5:5 K</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kT>4:4</td>
<td class=kW>3:1 K</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kW>5:3 K</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>9:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=br>120:81</td><td class=br>+39</td>
<td class=bc>22 - 2 - 7</td>
<td class=br><strong>46</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1518&x=-409&p=Ol%20Korabel">Ol Korabel</a></td><td class=kL>3:4 K</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>2:1 K</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kW>7:2</td>
<td class=kL>3:5 K</td>
<td class=kW>5:4</td>
<td class=kW>2:0 K</td>
<td class=kW>6:2 K</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>4:0 K</td>
<td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kL>1:4 K</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=kW>4:0</td>
<td class=kW>6:4</td>
<td class=kW>7:3</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=br>113:67</td><td class=br>+46</td>
<td class=bc>22 - 2 - 7</td>
<td class=br><strong>46</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=409&x=-409&p=Pa%20Petr">Pa Petr</a></td><td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kL>2:7</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kW>4:3 K</td>
<td class=kT>4:4 K</td>
<td class=kL>2:4</td>
<td class=kW>8:3</td>
<td class=kW>2:0</td>
<td class=kW>8:3</td>
<td class=kW>6:1</td>
<td class=kL>1:2 K</td>
<td class=kW>5:1 K</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>2:1 K</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kW>6:0 K</td>
<td class=kW>7:0</td>
<td class=kT>2:2 K</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=br>131:69</td><td class=br>+62</td>
<td class=bc>21 - 4 - 6</td>
<td class=br><strong>46</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1784&x=-409&p=Ma%20Klippen">Ma Klippen</a></td><td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>2:1 K</td>
<td class=kL>0:5 K</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1 K</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>8:0 K</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>6:4 K</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>4:1 K</td>
<td class=kW>4:1 K</td>
<td class=br>96:62</td><td class=br>+34</td>
<td class=bc>21 - 1 - 9</td>
<td class=br><strong>43</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1477&x=-409&p=Mi%20Kobrle">Mi Kobrle</a></td><td class=kW>5:2</td>
<td class=kL>0:4</td>
<td class=kW>3:1</td>
<td class=kL>1:2 K</td>
<td class=kx>*</td>
<td class=kW>2:1 K</td>
<td class=kW>8:3</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kL>5:6</td>
<td class=kW>6:0</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kT>1:1 K</td>
<td class=kW>5:4</td>
<td class=kW>5:0</td>
<td class=kW>8:3 K</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>4:5</td>
<td class=kW>5:1 K</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kT>5:5</td>
<td class=kW>6:5</td>
<td class=kW>5:1 K</td>
<td class=kW>9:0 K</td>
<td class=br>117:73</td><td class=br>+44</td>
<td class=bc>19 - 5 - 7</td>
<td class=br><strong>43</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1503&x=-409&p=Ve%20Huotelin">Ve Huotelin</a></td><td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kW>5:0 K</td>
<td class=kL>1:2 K</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>8:1</td>
<td class=kL>2:4</td>
<td class=kT>1:1 K</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2 K</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kL>2:4 K</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kL>2:5</td>
<td class=kW>4:2</td>
<td class=kW>3:1 K</td>
<td class=kW>6:2 K</td>
<td class=br>101:66</td><td class=br>+35</td>
<td class=bc>19 - 2 - 10</td>
<td class=br><strong>40</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1846&x=-409&p=Ar%20Matantsev">Ar Matantsev</a></td><td class=kL>4:5</td>
<td class=kL>0:3</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kL>3:8</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>3:3 K</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kL>3:4 K</td>
<td class=kT>1:1</td>
<td class=kW>3:2 K</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kT>4:4 K</td>
<td class=kW>6:1</td>
<td class=kL>2:5 K</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>5:4 K</td>
<td class=kW>6:4</td>
<td class=kT>3:3 K</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=br>113:76</td><td class=br>+37</td>
<td class=bc>17 - 6 - 8</td>
<td class=br><strong>40</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2090&x=-409&p=Ja%20Kalnevics">Ja Kalnevics</a></td><td class=kW>4:2 K</td>
<td class=kL>1:2 K</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kW>2:0 K</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kW>3:1 K</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kT>2:2 K</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kW>2:0 K</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=br>79:57</td><td class=br>+22</td>
<td class=bc>15 - 9 - 7</td>
<td class=br><strong>39</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2080&x=-409&p=Kr%20Naglis">Kr Naglis</a></td><td class=kW>8:3</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kT>3:3 K</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kL>2:3 K</td>
<td class=kW>6:2</td>
<td class=kL>1:3 K</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>7:1 K</td>
<td class=kW>2:1</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>5:2 K</td>
<td class=kW>2:1</td>
<td class=kW>4:3 K</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=br>102:78</td><td class=br>+24</td>
<td class=bc>16 - 7 - 8</td>
<td class=br><strong>39</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2078&x=-409&p=Kr%20Lagzdina">Kr Lagzdina</a></td><td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kL>3:4 K</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>3:4 K</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>4:6</td>
<td class=kL>1:6 K</td>
<td class=kT>3:3 K</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kW>2:0 K</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>4:2 K</td>
<td class=kW>3:2</td>
<td class=kW>3:2 K</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=br>89:74</td><td class=br>+15</td>
<td class=bc>15 - 8 - 8</td>
<td class=br><strong>38</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1772&x=-409&p=El%20Silin%C5%A1">El Silinš</a></td><td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kT>4:4 K</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>4:3 K</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kW>6:4</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>1:3 K</td>
<td class=kW>5:2 K</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>2:4 K</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>4:2 K</td>
<td class=kW>5:0</td>
<td class=kW>4:2 K</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=br>86:76</td><td class=br>+10</td>
<td class=bc>15 - 6 - 10</td>
<td class=br><strong>36</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2075&x=-409&p=To%20Baumanis">To Baumanis</a></td><td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kW>4:3 K</td>
<td class=kT>3:3</td>
<td class=kW>3:2 K</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kW>4:1 K</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kL>0:5 K</td>
<td class=kW>5:2</td>
<td class=kW>2:1 K</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2 K</td>
<td class=kW>4:2</td>
<td class=kL>1:4 K</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=br>97:83</td><td class=br>+14</td>
<td class=bc>17 - 2 - 12</td>
<td class=br><strong>36</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2112&x=-409&p=Ed%20Kaneps">Ed Kaneps</a></td><td class=kW>2:1 K</td>
<td class=kW>5:3 K</td>
<td class=kL>3:8</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>0:2 K</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:2 K</td>
<td class=kL>1:4 K</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2 K</td>
<td class=kW>3:0</td>
<td class=kL>0:1</td>
<td class=kT>4:4</td>
<td class=kL>3:5</td>
<td class=kW>1:0 K</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>7:4</td>
<td class=kW>5:1</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kL>4:7</td>
<td class=br>88:79</td><td class=br>+9</td>
<td class=bc>16 - 3 - 12</td>
<td class=br><strong>35</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1174&x=-409&p=Ma%20Mad%C4%9Bra">Ma Maděra</a></td><td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kW>6:5</td>
<td class=kW>6:2</td>
<td class=kL>2:3 K</td>
<td class=kT>2:2</td>
<td class=kW>3:1 K</td>
<td class=kT>3:3</td>
<td class=kL>4:6</td>
<td class=kL>1:4 K</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>1:4 K</td>
<td class=kW>3:2</td>
<td class=kW>3:0 K</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3 K</td>
<td class=kW>5:0</td>
<td class=kW>6:5 K</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=br>95:87</td><td class=br>+8</td>
<td class=bc>14 - 7 - 10</td>
<td class=br><strong>35</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=850&x=-409&p=Im%20Bla%C5%A1ko">Im Blaško</a></td><td class=kL>1:5 K</td>
<td class=kL>0:2 K</td>
<td class=kL>3:8</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2 K</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kW>2:1 K</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>7:2 K</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2 K</td>
<td class=kW>5:0</td>
<td class=kW>7:3</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kL>0:4 K</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=br>80:74</td><td class=br>+6</td>
<td class=bc>15 - 3 - 13</td>
<td class=br><strong>33</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1&x=-409&p=Pa%20Ple%C5%A1%C3%A1k">Pa Plešák</a></td><td class=kT>5:5 K</td>
<td class=kL>2:6 K</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3 K</td>
<td class=kL>2:4</td>
<td class=kW>6:4</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1 K</td>
<td class=kW>4:1</td>
<td class=kL>2:7 K</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kW>5:2 K</td>
<td class=kT>1:1</td>
<td class=kL>0:7</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>1:2 K</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=br>80:91</td><td class=br>-11</td>
<td class=bc>13 - 6 - 12</td>
<td class=br><strong>32</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=882&x=-409&p=Mi%20Saulitis">Mi Saulitis</a></td><td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1 K</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>6:1 K</td>
<td class=kW>3:1 K</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kL>0:2</td>
<td class=kL>3:5</td>
<td class=kW>2:1 K</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kT>1:1 K</td>
<td class=kW>7:3</td>
<td class=kW>5:2 K</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=br>71:72</td><td class=br>-1</td>
<td class=bc>13 - 6 - 12</td>
<td class=br><strong>32</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1151&x=-409&p=Ju%20Rautio">Ju Rautio</a></td><td class=kW>5:4</td>
<td class=kL>3:4</td>
<td class=kL>1:5 K</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kT>3:3 K</td>
<td class=kL>2:5 K</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kT>1:1 K</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kT>4:4</td>
<td class=kW>2:1 K</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>8:1</td>
<td class=kT>2:2 K</td>
<td class=kW>5:1</td>
<td class=kW>1:0 K</td>
<td class=kW>5:4</td>
<td class=kW>4:3</td>
<td class=br>84:88</td><td class=br>-4</td>
<td class=bc>13 - 6 - 12</td>
<td class=br><strong>32</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=567&x=-409&p=Kr%20Lebl">Kr Lebl</a></td><td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3 K</td>
<td class=kT>1:1 K</td>
<td class=kT>1:1 K</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kL>0:1</td>
<td class=kW>2:1 K</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>2:4 K</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kW>3:2 K</td>
<td class=kW>3:2 K</td>
<td class=br>76:75</td><td class=br>+1</td>
<td class=bc>10 - 11 - 10</td>
<td class=br><strong>31</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2105&x=-409&p=Ro%20Livmanis">Ro Livmanis</a></td><td class=kL>1:3 K</td>
<td class=kL>0:4 K</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kT>2:2 K</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>2:3 K</td>
<td class=kW>4:1</td>
<td class=kL>2:4 K</td>
<td class=kL>2:5 K</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kT>4:4</td>
<td class=kW>4:2 K</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=br>85:74</td><td class=br>+11</td>
<td class=bc>13 - 3 - 15</td>
<td class=br><strong>29</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=310&x=-409&p=Mi%20%C4%8Cernoch">Mi Černoch</a></td><td class=kL>1:4</td>
<td class=kW>5:4</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kT>4:4 K</td>
<td class=kT>3:3</td>
<td class=kL>1:7 K</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>5:0 K</td>
<td class=kL>0:3</td>
<td class=kW>4:1 K</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>4:5 K</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kW>3:1 K</td>
<td class=kW>4:2</td>
<td class=kW>3:1 K</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kL>1:2</td>
<td class=br>64:86</td><td class=br>-22</td>
<td class=bc>11 - 5 - 15</td>
<td class=br><strong>27</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1979&x=-409&p=Ga%20Bohinc">Ga Bohinc</a></td><td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>0:8 K</td>
<td class=kL>3:8 K</td>
<td class=kL>2:4 K</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kL>3:7</td>
<td class=kW>7:0</td>
<td class=kW>2:0</td>
<td class=kL>0:4</td>
<td class=kL>1:2 K</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kT>1:1 K</td>
<td class=kL>0:3</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kL>2:4 K</td>
<td class=kW>2:0 K</td>
<td class=br>61:83</td><td class=br>-22</td>
<td class=bc>10 - 6 - 15</td>
<td class=br><strong>26</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1975&x=-409&p=Gu%20Hermansson">Gu Hermansson</a></td><td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kW>5:2 K</td>
<td class=kL>1:4</td>
<td class=kT>2:2 K</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:2 K</td>
<td class=kT>4:4</td>
<td class=kL>0:3 K</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kW>5:4 K</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kT>4:4 K</td>
<td class=kW>4:2</td>
<td class=kL>2:4 K</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=br>75:97</td><td class=br>-22</td>
<td class=bc>9 - 8 - 14</td>
<td class=br><strong>26</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1189&x=-409&p=Ka%20Balodis">Ka Balodis</a></td><td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>1:2 K</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>0:5</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>0:2 K</td>
<td class=kW>4:2 K</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kL>1:2 K</td>
<td class=kL>1:2 K</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kW>5:2</td>
<td class=kT>1:1 K</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=br>67:76</td><td class=br>-9</td>
<td class=bc>8 - 10 - 13</td>
<td class=br><strong>26</strong></td><td class=d>24.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>25.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1815&x=-409&p=An%20Bo%C5%BEi%C4%8D">An Božič</a></td><td class=kL>3:5 K</td>
<td class=kW>4:1 K</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>0:2 K</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>0:1 K</td>
<td class=kL>2:3</td>
<td class=kW>4:0 K</td>
<td class=kW>2:1 K</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>2:4 K</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=br>69:86</td><td class=br>-17</td>
<td class=bc>9 - 4 - 18</td>
<td class=br><strong>22</strong></td><td class=d>25.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>26.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=386&x=-409&p=Ku%20Sl%C3%A1dek">Ku Sládek</a></td><td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>4:6 K</td>
<td class=kL>1:5 K</td>
<td class=kW>4:2 K</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>4:2 K</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kT>1:1 K</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>0:2 K</td>
<td class=kW>6:0 K</td>
<td class=br>60:90</td><td class=br>-30</td>
<td class=bc>7 - 7 - 17</td>
<td class=br><strong>21</strong></td><td class=d>26.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>27.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=64&x=-409&p=Da%20%C5%A0m%C3%ADd">Da Šmíd</a></td><td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kL>4:5 K</td>
<td class=kL>0:4</td>
<td class=kL>2:5 K</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kL>2:5 K</td>
<td class=kL>0:5</td>
<td class=kT>3:3 K</td>
<td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kL>1:8</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>1:3 K</td>
<td class=kW>3:0</td>
<td class=kT>4:4 K</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>7:1 K</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=br>74:106</td><td class=br>-32</td>
<td class=bc>8 - 5 - 18</td>
<td class=br><strong>21</strong></td><td class=d>27.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>28.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1981&x=-409&p=Po%20Kvasnikova">Po Kvasnikova</a></td><td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>0:6 K</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>4:6</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>2:4 K</td>
<td class=kL>2:4 K</td>
<td class=kL>2:4</td>
<td class=kL>4:7</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kW>1:0</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:0 K</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=br>47:98</td><td class=br>-51</td>
<td class=bc>5 - 6 - 20</td>
<td class=br><strong>16</strong></td><td class=d>28.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>29.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=4&x=-409&p=Vl%20Kraus">Vl Kraus</a></td><td class=kL>1:9</td>
<td class=kL>4:6</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kT>5:5</td>
<td class=kW>5:2</td>
<td class=kT>3:3 K</td>
<td class=kL>1:6</td>
<td class=kL>3:4 K</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kW>4:1 K</td>
<td class=kL>1:5</td>
<td class=kL>5:6 K</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>3:7</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>1:3 K</td>
<td class=kL>0:2</td>
<td class=kW>4:2 K</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>1:7 K</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=br>67:125</td><td class=br>-58</td>
<td class=bc>5 - 6 - 20</td>
<td class=br><strong>16</strong></td><td class=d>29.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>30.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=841&x=-409&p=Ma%20Le%C5%BE%C3%ADk">Ma Ležík</a></td><td class=kL>1:2</td>
<td class=kL>3:7</td>
<td class=kT>2:2 K</td>
<td class=kL>2:4</td>
<td class=kL>5:6</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>2:3 K</td>
<td class=kL>2:4 K</td>
<td class=kL>2:5</td>
<td class=kW>4:1</td>
<td class=kL>3:5</td>
<td class=kL>0:3</td>
<td class=kW>6:1</td>
<td class=kL>2:5 K</td>
<td class=kL>0:1 K</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kT>1:1 K</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kL>0:2 K</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=br>72:98</td><td class=br>-26</td>
<td class=bc>7 - 2 - 22</td>
<td class=br><strong>16</strong></td><td class=d>30.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>31.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1193&x=-409&p=La%20Svensson">La Svensson</a></td><td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:4 K</td>
<td class=kL>1:5 K</td>
<td class=kL>1:3 K</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kL>2:3 K</td>
<td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kW>4:2 K</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>2:0 K</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>4:2 K</td>
<td class=br>49:102</td><td class=br>-53</td>
<td class=bc>5 - 3 - 23</td>
<td class=br><strong>13</strong></td><td class=d>31.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>32.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2092&x=-409&p=Ar%20Tseluiko">Ar Tseluiko</a></td><td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>1:4 K</td>
<td class=kL>0:9 K</td>
<td class=kL>2:6 K</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kW>7:4</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>2:3 K</td>
<td class=kL>0:6</td>
<td class=kW>2:1</td>
<td class=kL>0:2 K</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>0:6 K</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>2:4 K</td>
<td class=kx>*</td>
<td class=br>63:122</td><td class=br>-59</td>
<td class=bc>4 - 3 - 24</td>
<td class=br><strong>11</strong></td><td class=d>32.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ja Kalnevics</td><td class=bc>-</td><td class=bl>Mi Saulitis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=blW>Kr Lagzdina</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>Ka Balodis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=blW>Ju Rautio</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Po Kvasnikova</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ro Livmanis</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>La Svensson</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Kalnevics</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Kr Lagzdina</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Ka Balodis</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=blW>Ju Rautio</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Saulitis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ar Tseluiko</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=blW>Kr Lagzdina</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ja Kalnevics</td><td class=bc>-</td><td class=blW>Ka Balodis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ra Kalninš</td><td class=bc>-</td><td class=blW>Ju Rautio</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Mi Saulitis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=blW>Kr Lagzdina</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Ka Balodis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ro Livmanis</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ja Kalnevics</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=blW>Mi Saulitis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ed Kaneps</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=blW>Mi Saulitis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Kalnevics</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ra Kalninš</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=bl>Kr Lagzdina</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>Ka Balodis</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=blW>Po Kvasnikova</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=blW>Mi Saulitis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ro Livmanis</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ja Kalnevics</td><td class=bc>-</td><td class=bl>Kr Lagzdina</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Ka Balodis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=bl>Mi Saulitis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Ed Kaneps</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Kr Lagzdina</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=bl>Ka Balodis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ja Kalnevics</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Mi Saulitis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>Kr Lagzdina</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=blW>Ka Balodis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=blW>Po Kvasnikova</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ja Kalnevics</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Mi Saulitis</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Ja Kalnevics</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ra Kalninš</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>La Svensson</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Mi Saulitis</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>La Svensson</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Ja Kalnevics</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Mi Saulitis</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Ja Kalnevics</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>La Svensson</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Saulitis</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>La Svensson</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ga Bohinc</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ja Kalnevics</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Mi Saulitis</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>La Svensson</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=bl>Ja Kalnevics</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Ra Kalninš</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ka Balodis</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Saulitis</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>La Svensson</td><td class=bc>-</td><td class=blW>Ja Kalnevics</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Saulitis</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Ja Kalnevics</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Ra Kalninš</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>La Svensson</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ar Tseluiko</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ma Klippen</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Saulitis</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ja Kalnevics</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>La Svensson</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ar Tseluiko</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Ga Bohinc</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Ja Kalnevics</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Mi Saulitis</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Ja Kalnevics</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Mi Saulitis</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Ja Kalnevics</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Saulitis</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ka Balodis</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Ja Kalnevics</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Mi Saulitis</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ka Balodis</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ja Kalnevics</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ka Balodis</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Saulitis</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ja Kalnevics</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=blW>Ar Tseluiko</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Saulitis</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ja Kalnevics</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Saulitis</td><td class=bc>-</td><td class=bl>La Svensson</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ar Tseluiko</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>26</td></tr>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=bl>Ja Kalnevics</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Ra Kalninš</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka Balodis</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>La Svensson</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Ar Tseluiko</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Saulitis</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>0 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
