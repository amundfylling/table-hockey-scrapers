<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Turnov</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Turnov, 24. únor 2024</span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>25</td>
<td class=ic>26</td>
<td class=ic>27</td>
<td class=ic>28</td>
<td class=ic>29</td>
<td class=ic>30</td>
<td class=ic>31</td>
<td class=ic>32</td>
<td class=ic>33</td>
<td class=ic>34</td>
<td class=ic>35</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=409&x=-407&p=Pa%20Petr">Pa Petr</a></td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>6:4</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kT>6:6</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kT>7:7</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kW>7:3</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>13:1</td>
<td class=kL>4:5</td>
<td class=kW>3:0</td>
<td class=kW>8:1</td>
<td class=kW>7:1</td>
<td class=kW>12:0</td>
<td class=kW>12:1</td>
<td class=kW>13:1</td>
<td class=br>184:62</td><td class=br>+122</td>
<td class=bc>27 - 4 - 3</td>
<td class=br><strong>58</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1477&x=-407&p=Mi%20Kobrle">Mi Kobrle</a></td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kW>7:5</td>
<td class=kW>3:0</td>
<td class=kL>0:3</td>
<td class=kW>5:0</td>
<td class=kT>4:4</td>
<td class=kW>7:3</td>
<td class=kW>6:5</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>7:3</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>9:2</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kW>5:0</td>
<td class=kW>9:3</td>
<td class=kW>9:2</td>
<td class=br>166:66</td><td class=br>+100</td>
<td class=bc>27 - 3 - 4</td>
<td class=br><strong>57</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=841&x=-407&p=Ma%20Le%C5%BE%C3%ADk">Ma Ležík</a></td><td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kL>4:5</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>6:0</td>
<td class=kT>0:0</td>
<td class=kW>6:3</td>
<td class=kW>5:0</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>7:3</td>
<td class=kW>8:0</td>
<td class=br>135:72</td><td class=br>+63</td>
<td class=bc>22 - 4 - 8</td>
<td class=br><strong>48</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=961&x=-407&p=Mi%20Bo%C5%A1t%C3%ADk">Mi Boštík</a></td><td class=kL>4:6</td>
<td class=kL>0:6</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kT>0:0</td>
<td class=kL>0:3</td>
<td class=kW>5:2</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kT>5:5</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=br>125:83</td><td class=br>+42</td>
<td class=bc>21 - 6 - 7</td>
<td class=br><strong>48</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1406&x=-407&p=Ja%20Mat%C3%BDsek">Ja Matýsek</a></td><td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>7:3</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kL>3:5</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>10:4</td>
<td class=kW>5:3</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=br>133:82</td><td class=br>+51</td>
<td class=bc>22 - 3 - 9</td>
<td class=br><strong>47</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=567&x=-407&p=Kr%20Lebl">Kr Lebl</a></td><td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kL>4:7</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kL>0:1</td>
<td class=br>120:76</td><td class=br>+44</td>
<td class=bc>21 - 4 - 9</td>
<td class=br><strong>46</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=40&x=-407&p=Da%20Mat%C3%BDsek">Da Matýsek</a></td><td class=kT>3:3</td>
<td class=kL>5:7</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kW>4:2</td>
<td class=kW>6:4</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>6:3</td>
<td class=kW>8:1</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=br>112:76</td><td class=br>+36</td>
<td class=bc>20 - 6 - 8</td>
<td class=br><strong>46</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1&x=-407&p=Pa%20Ple%C5%A1%C3%A1k">Pa Plešák</a></td><td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>1:7</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kT>5:5</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=kW>6:5</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=br>109:80</td><td class=br>+29</td>
<td class=bc>16 - 12 - 6</td>
<td class=br><strong>44</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1065&x=-407&p=Kr%20Herold">Kr Herold</a></td><td class=kT>6:6</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>3:7</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>0:1</td>
<td class=kW>4:1</td>
<td class=kL>4:7</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=br>104:82</td><td class=br>+22</td>
<td class=bc>18 - 6 - 10</td>
<td class=br><strong>42</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=310&x=-407&p=Mi%20%C4%8Cernoch">Mi Černoch</a></td><td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kT>0:0</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>9:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=br>87:52</td><td class=br>+35</td>
<td class=bc>16 - 10 - 8</td>
<td class=br><strong>42</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1872&x=-407&p=Pe%20Fuchs">Pe Fuchs</a></td><td class=kL>0:2</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kW>7:3</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>6:0</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kW>7:3</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>9:0</td>
<td class=br>101:65</td><td class=br>+36</td>
<td class=bc>17 - 7 - 10</td>
<td class=br><strong>41</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=248&x=-407&p=Ma%20%C5%BDen%C3%AD%C5%A1ek">Ma Ženíšek</a></td><td class=kL>1:4</td>
<td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kW>7:4</td>
<td class=kW>6:1</td>
<td class=kT>5:5</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kW>5:4</td>
<td class=kW>5:2</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>7:0</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=br>120:91</td><td class=br>+29</td>
<td class=bc>17 - 6 - 11</td>
<td class=br><strong>40</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=64&x=-407&p=Da%20%C5%A0m%C3%ADd">Da Šmíd</a></td><td class=kT>7:7</td>
<td class=kL>5:6</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kT>0:0</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>3:7</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kW>8:1</td>
<td class=kW>8:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=br>103:78</td><td class=br>+25</td>
<td class=bc>15 - 10 - 9</td>
<td class=br><strong>40</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1876&x=-407&p=Ad%20Kop%C5%99iva">Ad Kopřiva</a></td><td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kW>5:4</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>6:4</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>8:2</td>
<td class=kW>6:2</td>
<td class=kW>10:2</td>
<td class=br>106:93</td><td class=br>+13</td>
<td class=bc>17 - 5 - 12</td>
<td class=br><strong>39</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=201&x=-407&p=To%20Bucek">To Bucek</a></td><td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>7:3</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=kW>6:0</td>
<td class=kW>8:0</td>
<td class=br>102:86</td><td class=br>+16</td>
<td class=bc>17 - 4 - 13</td>
<td class=br><strong>38</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=386&x=-407&p=Ku%20Sl%C3%A1dek">Ku Sládek</a></td><td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kL>0:7</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=br>89:88</td><td class=br>+1</td>
<td class=bc>16 - 6 - 12</td>
<td class=br><strong>38</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=818&x=-407&p=Ro%20Je%C5%BE">Ro Jež</a></td><td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>4:3</td>
<td class=kW>7:3</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=br>96:86</td><td class=br>+10</td>
<td class=bc>16 - 6 - 12</td>
<td class=br><strong>38</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=26&x=-407&p=Mi%20%C5%A0evr">Mi Ševr</a></td><td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kT>5:5</td>
<td class=kL>3:7</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kL>2:7</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>3:8</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kL>0:2</td>
<td class=kW>8:3</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=br>109:104</td><td class=br>+5</td>
<td class=bc>15 - 7 - 12</td>
<td class=br><strong>37</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1268&x=-407&p=Da%20Dvo%C5%99%C3%A1%C4%8Dek">Da Dvořáček</a></td><td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kL>0:1</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kW>7:3</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>4:7</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kL>4:7</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>7:2</td>
<td class=kW>6:2</td>
<td class=kL>4:7</td>
<td class=kW>6:1</td>
<td class=kW>7:4</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=br>130:91</td><td class=br>+39</td>
<td class=bc>16 - 5 - 13</td>
<td class=br><strong>37</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=448&x=-407&p=To%20Waclawek">To Waclawek</a></td><td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kL>3:7</td>
<td class=kW>7:1</td>
<td class=kT>2:2</td>
<td class=kW>8:3</td>
<td class=kW>7:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>7:5</td>
<td class=kW>9:1</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=br>118:101</td><td class=br>+17</td>
<td class=bc>14 - 7 - 13</td>
<td class=br><strong>35</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=527&x=-407&p=Ad%20Zielinsk%C3%BD">Ad Zielinský</a></td><td class=kL>1:3</td>
<td class=kL>1:7</td>
<td class=kT>0:0</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kL>4:6</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=br>77:83</td><td class=br>-6</td>
<td class=bc>14 - 7 - 13</td>
<td class=br><strong>35</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=4&x=-407&p=Vl%20Kraus">Vl Kraus</a></td><td class=kW>5:4</td>
<td class=kL>3:7</td>
<td class=kL>3:6</td>
<td class=kL>0:6</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>0:6</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>7:3</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=br>102:101</td><td class=br>+1</td>
<td class=bc>13 - 7 - 14</td>
<td class=br><strong>33</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=176&x=-407&p=Zd%20Lopaur">Zd Lopaur</a></td><td class=kL>3:7</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kW>4:1</td>
<td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kL>1:6</td>
<td class=kW>7:4</td>
<td class=kL>0:4</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kL>4:5</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=br>92:107</td><td class=br>-15</td>
<td class=bc>14 - 4 - 16</td>
<td class=br><strong>32</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=547&x=-407&p=To%20Lahu%C4%8Dk%C3%BD">To Lahučký</a></td><td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kW>6:1</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kL>3:5</td>
<td class=kW>7:4</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>3:7</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>9:4</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=br>105:104</td><td class=br>+1</td>
<td class=bc>14 - 4 - 16</td>
<td class=br><strong>32</strong></td><td class=d>24.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>25.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1912&x=-407&p=Al%20Krejza">Al Krejza</a></td><td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kL>4:6</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>7:3</td>
<td class=kL>1:4</td>
<td class=kW>7:0</td>
<td class=kW>7:3</td>
<td class=kW>6:1</td>
<td class=br>98:101</td><td class=br>-3</td>
<td class=bc>13 - 5 - 16</td>
<td class=br><strong>31</strong></td><td class=d>25.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>26.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=18&x=-407&p=An%20%C5%A0ur%C3%BDn">An Šurýn</a></td><td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>8:1</td>
<td class=br>81:90</td><td class=br>-9</td>
<td class=bc>12 - 7 - 15</td>
<td class=br><strong>31</strong></td><td class=d>26.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>27.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=53&x=-407&p=V%C3%A1%20Pikl">Vá Pikl</a></td><td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kL>2:7</td>
<td class=kW>2:1</td>
<td class=kW>6:4</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>9:0</td>
<td class=kW>6:1</td>
<td class=kW>8:0</td>
<td class=br>92:94</td><td class=br>-2</td>
<td class=bc>14 - 2 - 18</td>
<td class=br><strong>30</strong></td><td class=d>27.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>28.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1599&x=-407&p=Mi%20Uhl%C3%AD%C5%99">Mi Uhlíř</a></td><td class=kL>1:13</td>
<td class=kL>2:9</td>
<td class=kL>0:7</td>
<td class=kL>2:7</td>
<td class=kL>4:10</td>
<td class=kL>1:7</td>
<td class=kL>3:5</td>
<td class=kL>5:6</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kL>1:8</td>
<td class=kL>4:6</td>
<td class=kL>3:4</td>
<td class=kW>7:0</td>
<td class=kL>3:7</td>
<td class=kL>3:8</td>
<td class=kL>2:6</td>
<td class=kL>5:7</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>4:9</td>
<td class=kW>6:1</td>
<td class=kL>1:6</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>6:4</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>6:5</td>
<td class=kW>9:0</td>
<td class=br>115:169</td><td class=br>-54</td>
<td class=bc>11 - 1 - 22</td>
<td class=br><strong>23</strong></td><td class=d>28.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>29.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1927&x=-407&p=Vo%20Kraus">Vo Kraus</a></td><td class=kW>5:4</td>
<td class=kL>0:7</td>
<td class=kL>3:4</td>
<td class=kL>1:7</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>3:7</td>
<td class=kL>2:4</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kW>7:4</td>
<td class=kL>1:9</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=br>74:125</td><td class=br>-51</td>
<td class=bc>8 - 5 - 21</td>
<td class=br><strong>21</strong></td><td class=d>29.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>30.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=24&x=-407&p=Zb%20Pila%C5%99">Zb Pilař</a></td><td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>4:6</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kW>7:3</td>
<td class=br>63:119</td><td class=br>-56</td>
<td class=bc>5 - 6 - 23</td>
<td class=br><strong>16</strong></td><td class=d>30.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>31.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=204&x=-407&p=Hy%20Nechutn%C3%BD">Hy Nechutný</a></td><td class=kL>1:8</td>
<td class=kW>2:1</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>4:7</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>2:6</td>
<td class=kL>3:6</td>
<td class=kL>1:6</td>
<td class=kL>3:7</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=br>53:129</td><td class=br>-76</td>
<td class=bc>6 - 3 - 25</td>
<td class=br><strong>15</strong></td><td class=d>31.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>32.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=215&x=-407&p=Jo%20Vom%C3%A1%C4%8Dka">Jo Vomáčka</a></td><td class=kL>1:7</td>
<td class=kT>4:4</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kW>5:4</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=br>63:131</td><td class=br>-68</td>
<td class=bc>5 - 3 - 26</td>
<td class=br><strong>13</strong></td><td class=d>32.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>33.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=216&x=-407&p=Ro%20Vom%C3%A1%C4%8Dka">Ro Vomáčka</a></td><td class=kL>0:12</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>1:8</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>1:9</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>2:8</td>
<td class=kL>0:8</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>0:9</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=br>31:157</td><td class=br>-126</td>
<td class=bc>3 - 3 - 28</td>
<td class=br><strong>9</strong></td><td class=d>33.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>34.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1896&x=-407&p=Ra%20Hrn%C4%8D%C3%AD%C5%99">Ra Hrnčíř</a></td><td class=kL>1:12</td>
<td class=kL>3:9</td>
<td class=kL>3:7</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kL>2:7</td>
<td class=kL>2:6</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kL>2:7</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kL>3:7</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>5:6</td>
<td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=br>60:185</td><td class=br>-125</td>
<td class=bc>2 - 0 - 32</td>
<td class=br><strong>4</strong></td><td class=d>34.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>35.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1959&x=-407&p=On%20Chlebo">On Chlebo</a></td><td class=kL>1:13</td>
<td class=kL>2:9</td>
<td class=kL>0:8</td>
<td class=kL>0:2</td>
<td class=kL>2:6</td>
<td class=kW>1:0</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>0:9</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>2:10</td>
<td class=kL>0:8</td>
<td class=kL>2:5</td>
<td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>0:7</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>1:8</td>
<td class=kL>0:8</td>
<td class=kL>0:9</td>
<td class=kL>0:7</td>
<td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=br>36:182</td><td class=br>-146</td>
<td class=bc>2 - 0 - 32</td>
<td class=br><strong>4</strong></td><td class=d>35.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>To Lahučký</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Jo Vomáčka</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>To Lahučký</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>7 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Jo Vomáčka</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>To Lahučký</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>3 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Zb Pilař</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>6 : 6</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 9</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>9 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>To Lahučký</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>On Chlebo</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Jo Vomáčka</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>12 : 0</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>5 : 7</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Vo Kraus</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>13 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>To Lahučký</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Vo Kraus</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Jo Vomáčka</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>To Lahučký</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Vo Kraus</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>On Chlebo</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>To Lahučký</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>To Lahučký</td><td class=bc>4 : 9</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ro Vomáčka</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Zb Pilař</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Vo Kraus</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Vo Kraus</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 12</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Vo Kraus</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Vo Kraus</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>7 : 7</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>To Lahučký</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Ro Vomáčka</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>10 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>10 : 4</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Ro Vomáčka</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>26</td></tr>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>Zb Pilař</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>27</td></tr>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ro Vomáčka</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>28</td></tr>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>To Lahučký</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Jo Vomáčka</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>29</td></tr>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Vo Kraus</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>To Lahučký</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>30</td></tr>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>To Lahučký</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>5 : 7</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>31</td></tr>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>To Lahučký</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>32</td></tr>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>To Lahučký</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>13 : 1</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>33</td></tr>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Zb Pilař</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>34</td></tr>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>To Lahučký</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Zb Pilař</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Jo Vomáčka</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>35</td></tr>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>To Lahučký</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 9</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ro Vomáčka</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Jo Vomáčka</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>7 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
