<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR junioři</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../mrj/index.aspx">MR junioři, 19. květen 2024</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<p class=v>Group J</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1968&x=-418&p=Mi%20Tou%C5%A1">Mi Touš</a></td><td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>7:3</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>8:1</td>
<td class=br>41:16</td><td class=br>+25</td>
<td class=bc>8 - 0 - 1</td>
<td class=br><strong>16</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1641&x=-418&p=Ma%20Klazar">Ma Klazar</a></td><td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kW>1:0</td>
<td class=kW>7:1</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>9:0</td>
<td class=br>46:15</td><td class=br>+31</td>
<td class=bc>8 - 0 - 1</td>
<td class=br><strong>16</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1927&x=-418&p=Vo%20Kraus">Vo Kraus</a></td><td class=kW>4:1</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>10:0</td>
<td class=br>31:9</td><td class=br>+22</td>
<td class=bc>6 - 2 - 1</td>
<td class=br><strong>14</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2018&x=-418&p=Ja%20Janou%C5%A1kovec">Ja Janouškovec</a></td><td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>8:0</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=br>35:14</td><td class=br>+21</td>
<td class=bc>6 - 0 - 3</td>
<td class=br><strong>12</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2039&x=-418&p=Ma%20Dry%C3%A1kov%C3%A1">Ma Dryáková</a></td><td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>7:4</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=br>26:20</td><td class=br>+6</td>
<td class=bc>4 - 1 - 4</td>
<td class=br><strong>9</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1947&x=-418&p=Lu%20Holub">Lu Holub</a></td><td class=kL>0:1</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=br>23:14</td><td class=br>+9</td>
<td class=bc>4 - 1 - 4</td>
<td class=br><strong>9</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2053&x=-418&p=Ma%20%C5%A0per%C5%88%C3%A1k">Ma Šperňák</a></td><td class=kL>3:7</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>4:7</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=br>21:40</td><td class=br>-19</td>
<td class=bc>2 - 1 - 6</td>
<td class=br><strong>5</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2029&x=-418&p=On%20Gruncl">On Gruncl</a></td><td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>0:8</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>7:3</td>
<td class=br>18:38</td><td class=br>-20</td>
<td class=bc>2 - 1 - 6</td>
<td class=br><strong>5</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2126&x=-418&p=Jo%20Rejzek">Jo Rejzek</a></td><td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=br>10:35</td><td class=br>-25</td>
<td class=bc>0 - 3 - 6</td>
<td class=br><strong>3</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2027&x=-418&p=Ve%20Kubrt">Ve Kubrt</a></td><td class=kL>1:8</td>
<td class=kL>0:9</td>
<td class=kL>0:10</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>3:7</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=br>6:56</td><td class=br>-50</td>
<td class=bc>0 - 1 - 8</td>
<td class=br><strong>1</strong></td><td class=d>10.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Vo Kraus</td><td class=bc>-</td><td class=bl>Ma Dryáková</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ve Kubrt</td><td class=bc>-</td><td class=blW>Ma Šperňák</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Lu Holub</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ja Janouškovec</td><td class=bc>-</td><td class=bl>Jo Rejzek</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Mi Touš</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ma Dryáková</td><td class=bc>-</td><td class=bl>Ve Kubrt</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ma Šperňák</td><td class=bc>-</td><td class=blW>Lu Holub</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=blW>Ja Janouškovec</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Jo Rejzek</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Vo Kraus</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Vo Kraus</td><td class=bc>-</td><td class=bl>Ve Kubrt</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Ma Dryáková</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ja Janouškovec</td><td class=bc>-</td><td class=bl>Ma Šperňák</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Touš</td><td class=bc>-</td><td class=bl>Jo Rejzek</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ve Kubrt</td><td class=bc>-</td><td class=blW>Lu Holub</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Dryáková</td><td class=bc>-</td><td class=blW>Ja Janouškovec</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Šperňák</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=blW>Mi Touš</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=bl>Jo Rejzek</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ja Janouškovec</td><td class=bc>-</td><td class=bl>Ve Kubrt</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ma Dryáková</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mi Touš</td><td class=bc>-</td><td class=bl>Ma Šperňák</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Jo Rejzek</td><td class=bc>-</td><td class=blW>On Gruncl</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Ja Janouškovec</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ve Kubrt</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Ma Dryáková</td><td class=bc>-</td><td class=blW>Mi Touš</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Šperňák</td><td class=bc>-</td><td class=bl>Jo Rejzek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Vo Kraus</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Vo Kraus</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Mi Touš</td><td class=bc>-</td><td class=bl>Ve Kubrt</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Jo Rejzek</td><td class=bc>-</td><td class=blW>Ma Dryáková</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=blW>Ma Šperňák</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Mi Touš</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ve Kubrt</td><td class=bc>-</td><td class=bl>Jo Rejzek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Dryáková</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Vo Kraus</td><td class=bc>-</td><td class=bl>Ma Šperňák</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Mi Touš</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Jo Rejzek</td><td class=bc>-</td><td class=blW>Lu Holub</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>On Gruncl</td><td class=bc>-</td><td class=bl>Ve Kubrt</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ma Šperňák</td><td class=bc>-</td><td class=blW>Ma Dryáková</td><td class=bc>4 : 7</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
