<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR veteráni</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Play-Off</span></h2></div></div></div></div><p><div align="center">
<table border=0 cellpadding=2 cellspacing=0>
<tr><th colspan=11 class="hh"><font size="+1"><strong>Finals</strong></font></th></tr>
<tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=310&x=-415&p=%C4%8Cernoch%20Miroslav">Černoch Miroslav</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=40&x=-415&p=Mat%C3%BDsek%20Daniel"><b>Matýsek Daniel</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;0 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:4&nbsp;&nbsp;</td>
<td class=bl>1:3&nbsp;&nbsp;</td>
<td class=bl>1:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>1/2</strong></font></th></tr>
<tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=83&x=-415&p=Dry%C3%A1k%20Jan">Dryák Jan</a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=310&x=-415&p=%C4%8Cernoch%20Miroslav"><b>Černoch Miroslav</b></a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;2 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>2:3 P&nbsp;&nbsp;</td>
<td class=al>1:2&nbsp;&nbsp;</td>
<td class=al>5:0&nbsp;&nbsp;</td>
<td class=al>3:4&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=64&x=-415&p=%C5%A0m%C3%ADd%20David">Šmíd David</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=40&x=-415&p=Mat%C3%BDsek%20Daniel"><b>Matýsek Daniel</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:2 P&nbsp;&nbsp;</td>
<td class=bl>0:1&nbsp;&nbsp;</td>
<td class=bl>2:1&nbsp;&nbsp;</td>
<td class=bl>1:3&nbsp;&nbsp;</td>
<td class=bl>3:4 P&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>3rd</strong></font></th></tr>
<tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=64&x=-415&p=%C5%A0m%C3%ADd%20David">Šmíd David</a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=83&x=-415&p=Dry%C3%A1k%20Jan"><b>Dryák Jan</b></a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;1 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>5:4&nbsp;&nbsp;</td>
<td class=al>2:5&nbsp;&nbsp;</td>
<td class=al>1:6&nbsp;&nbsp;</td>
<td class=al>2:7&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>1/4</strong></font></th></tr>
<tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=83&x=-415&p=Dry%C3%A1k%20Jan%20%281%29"><b>Dryák Jan (1)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=818&x=-415&p=Je%C5%BE%20Robert%20%284%29">Jež Robert (4)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>5:0&nbsp;&nbsp;</td>
<td class=bl>8:3&nbsp;&nbsp;</td>
<td class=bl>7:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=24&x=-415&p=Pila%C5%99%20Zbyn%C4%9Bk%20%283%29">Pilař Zbyněk (3)</a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=310&x=-415&p=%C4%8Cernoch%20Miroslav%20%282%29"><b>Černoch Miroslav (2)</b></a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;0 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>1:2 P&nbsp;&nbsp;</td>
<td class=al>1:4&nbsp;&nbsp;</td>
<td class=al>1:5&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=40&x=-415&p=Mat%C3%BDsek%20Daniel%20%282%29"><b>Matýsek Daniel (2)</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=248&x=-415&p=%C5%BDen%C3%AD%C5%A1ek%20Martin%20%283%29">Ženíšek Martin (3)</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>4:0&nbsp;&nbsp;</td>
<td class=bl>5:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=32&x=-415&p=Krop%C3%A1%C4%8Dek%20Ji%C5%99%C3%AD%20%284%29">Kropáček Jiří (4)</a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=64&x=-415&p=%C5%A0m%C3%ADd%20David%20%281%29"><b>Šmíd David (1)</b></a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;0 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>1:4&nbsp;&nbsp;</td>
<td class=al>1:3&nbsp;&nbsp;</td>
<td class=al>1:6&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
