<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR veteráni</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>MR veteráni, 19. květen 2024</span></h2></div></div></div></div><p><div align="center">
<div align=center>
<a href="kriz.aspx">Zápasy ve skupinách (Basic and placement groups)</a><br>
<a href="MR_veterani_playoff.aspx ">Zápasy o umístění (Placement matches)</a><br>
<a href="utokturnaje.aspx">Tabulka útočníků (Best forwards)</a><br>
<a href="obranaturnaje.aspx">Tabulka obránců (Best defenders)</a>
</div>
<p class=v>Konečné pořadí turnaje (Final table)<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0 class="rnk">
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">M</th>
<th align="center">+</th>
<th align="center">=</th>
<th align="center">-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">Pts</th>
<th align="center">CZ pts</th>
<th>&nbsp;</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=40&x=-415&p=Mat%C3%BDsek%20Daniel">Matýsek Daniel</a></td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>22</td>
<td class=ar>18</td>
<td class=ar>1</td>
<td class=ar>3</td>
<td class=ar>70</td>
<td class=al>&nbsp;:&nbsp;28</td>
<td class=ar>37</td>
<td class=art>160</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>2.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=310&x=-415&p=%C4%8Cernoch%20Miroslav">Černoch Miroslav</a></td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>21</td>
<td class=br>12</td>
<td class=br>3</td>
<td class=br>6</td>
<td class=br>54</td>
<td class=bl>&nbsp;:&nbsp;40</td>
<td class=br>27</td>
<td class=brt>152</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>3.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=83&x=-415&p=Dry%C3%A1k%20Jan">Dryák Jan</a></td>
<td class=al>Big Band</td>
<td class=ar>22</td>
<td class=ar>16</td>
<td class=ar>1</td>
<td class=ar>5</td>
<td class=ar>105</td>
<td class=al>&nbsp;:&nbsp;44</td>
<td class=ar>33</td>
<td class=art>146</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>4.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=64&x=-415&p=%C5%A0m%C3%ADd%20David">Šmíd David</a></td>
<td class=bl>Absolut Desperation</td>
<td class=br>23</td>
<td class=br>14</td>
<td class=br>1</td>
<td class=br>8</td>
<td class=br>72</td>
<td class=bl>&nbsp;:&nbsp;53</td>
<td class=br>29</td>
<td class=brt>141</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>5.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=248&x=-415&p=%C5%BDen%C3%AD%C5%A1ek%20Martin">Ženíšek Martin</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>14</td>
<td class=ar>7</td>
<td class=ar>2</td>
<td class=ar>5</td>
<td class=ar>48</td>
<td class=al>&nbsp;:&nbsp;33</td>
<td class=ar>16</td>
<td class=art>137</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>6.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=24&x=-415&p=Pila%C5%99%20Zbyn%C4%9Bk">Pilař Zbyněk</a></td>
<td class=bl>Absolut Desperation</td>
<td class=br>13</td>
<td class=br>4</td>
<td class=br>3</td>
<td class=br>6</td>
<td class=br>22</td>
<td class=bl>&nbsp;:&nbsp;32</td>
<td class=br>11</td>
<td class=brt>134</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>7.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=818&x=-415&p=Je%C5%BE%20Robert">Jež Robert</a></td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>14</td>
<td class=ar>7</td>
<td class=ar>1</td>
<td class=ar>6</td>
<td class=ar>39</td>
<td class=al>&nbsp;:&nbsp;38</td>
<td class=ar>15</td>
<td class=art>132</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>8.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=32&x=-415&p=Krop%C3%A1%C4%8Dek%20Ji%C5%99%C3%AD">Kropáček Jiří</a></td>
<td class=bl>SHC Cheb</td>
<td class=br>13</td>
<td class=br>4</td>
<td class=br>4</td>
<td class=br>5</td>
<td class=br>24</td>
<td class=bl>&nbsp;:&nbsp;39</td>
<td class=br>12</td>
<td class=brt>131</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>9.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=4&x=-415&p=Kraus%20Vladim%C3%ADr">Kraus Vladimír</a></td>
<td class=al>Absolut Desperation</td>
<td class=ar>10</td>
<td class=ar>6</td>
<td class=ar>1</td>
<td class=ar>3</td>
<td class=ar>30</td>
<td class=al>&nbsp;:&nbsp;26</td>
<td class=ar>13</td>
<td class=art>128</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>10.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1318&x=-415&p=Sedl%C3%A1%C4%8Dek%20Josef">Sedláček Josef</a></td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>11</td>
<td class=br>6</td>
<td class=br>2</td>
<td class=br>3</td>
<td class=br>27</td>
<td class=bl>&nbsp;:&nbsp;29</td>
<td class=br>14</td>
<td class=brt>127</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>11.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=318&x=-415&p=V%C3%A1cha%20Ji%C5%99%C3%AD">Vácha Jiří</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>11</td>
<td class=ar>6</td>
<td class=ar>1</td>
<td class=ar>4</td>
<td class=ar>42</td>
<td class=al>&nbsp;:&nbsp;29</td>
<td class=ar>13</td>
<td class=art>126</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>12.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=201&x=-415&p=Bucek%20Tom%C3%A1%C5%A1">Bucek Tomáš</a></td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>10</td>
<td class=br>5</td>
<td class=br>1</td>
<td class=br>4</td>
<td class=br>35</td>
<td class=bl>&nbsp;:&nbsp;24</td>
<td class=br>11</td>
<td class=brt>125</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>13.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=261&x=-415&p=Cibulka%20David">Cibulka David</a></td>
<td class=al>THC Třinec</td>
<td class=ar>10</td>
<td class=ar>4</td>
<td class=ar>1</td>
<td class=ar>5</td>
<td class=ar>27</td>
<td class=al>&nbsp;:&nbsp;29</td>
<td class=ar>9</td>
<td class=art>124</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>14.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=176&x=-415&p=Lopaur%20Zden%C4%9Bk">Lopaur Zdeněk</a></td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>11</td>
<td class=br>4</td>
<td class=br>3</td>
<td class=br>4</td>
<td class=br>28</td>
<td class=bl>&nbsp;:&nbsp;27</td>
<td class=br>11</td>
<td class=brt>123</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>15.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=270&x=-415&p=Hejtman%20Vlastimil">Hejtman Vlastimil</a></td>
<td class=al>SHC Vědátoři Olomouc</td>
<td class=ar>10</td>
<td class=ar>4</td>
<td class=ar>0</td>
<td class=ar>6</td>
<td class=ar>27</td>
<td class=al>&nbsp;:&nbsp;30</td>
<td class=ar>8</td>
<td class=art>0</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>16.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=70&x=-415&p=Srba%20Stanislav">Srba Stanislav</a></td>
<td class=bl>SHC Cheb</td>
<td class=br>11</td>
<td class=br>4</td>
<td class=br>4</td>
<td class=br>3</td>
<td class=br>32</td>
<td class=bl>&nbsp;:&nbsp;27</td>
<td class=br>12</td>
<td class=brt>0</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>17.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1912&x=-415&p=Krejza%20Ale%C5%A1">Krejza Aleš</a></td>
<td class=al>THC Třinec</td>
<td class=ar>9</td>
<td class=ar>5</td>
<td class=ar>1</td>
<td class=ar>3</td>
<td class=ar>24</td>
<td class=al>&nbsp;:&nbsp;19</td>
<td class=ar>11</td>
<td class=art>119</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>18.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=53&x=-415&p=Pikl%20V%C3%A1clav">Pikl Václav</a></td>
<td class=bl>THC Stiga Elites</td>
<td class=br>10</td>
<td class=br>5</td>
<td class=br>0</td>
<td class=br>5</td>
<td class=br>24</td>
<td class=bl>&nbsp;:&nbsp;20</td>
<td class=br>10</td>
<td class=brt>118</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>19.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=204&x=-415&p=Nechutn%C3%BD%20Hynek">Nechutný Hynek</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>9</td>
<td class=ar>3</td>
<td class=ar>1</td>
<td class=ar>5</td>
<td class=ar>17</td>
<td class=al>&nbsp;:&nbsp;22</td>
<td class=ar>7</td>
<td class=art>117</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>20.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=41&x=-415&p=Hrachovec%20Daniel">Hrachovec Daniel</a></td>
<td class=bl>SHC Cheb</td>
<td class=br>10</td>
<td class=br>4</td>
<td class=br>0</td>
<td class=br>6</td>
<td class=br>20</td>
<td class=bl>&nbsp;:&nbsp;32</td>
<td class=br>8</td>
<td class=brt>116</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>21.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=227&x=-415&p=Ma%C5%A1ika%20Michal">Mašika Michal</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>10</td>
<td class=ar>6</td>
<td class=ar>0</td>
<td class=ar>4</td>
<td class=ar>31</td>
<td class=al>&nbsp;:&nbsp;26</td>
<td class=ar>12</td>
<td class=art>115</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>22.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=216&x=-415&p=Vom%C3%A1%C4%8Dka%20Roman">Vomáčka Roman</a></td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>10</td>
<td class=br>4</td>
<td class=br>1</td>
<td class=br>5</td>
<td class=br>23</td>
<td class=bl>&nbsp;:&nbsp;26</td>
<td class=br>9</td>
<td class=brt>114</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>23.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=271&x=-415&p=Hejtman%20Radek">Hejtman Radek</a></td>
<td class=al>SHC Vědátoři Olomouc</td>
<td class=ar>9</td>
<td class=ar>3</td>
<td class=ar>1</td>
<td class=ar>5</td>
<td class=ar>20</td>
<td class=al>&nbsp;:&nbsp;29</td>
<td class=ar>7</td>
<td class=art>113</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>24.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=89&x=-415&p=Gruncl%20Josef">Gruncl Josef</a></td>
<td class=bl>SHC Cheb</td>
<td class=br>9</td>
<td class=br>0</td>
<td class=br>1</td>
<td class=br>8</td>
<td class=br>9</td>
<td class=bl>&nbsp;:&nbsp;32</td>
<td class=br>1</td>
<td class=brt>112</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>25.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1405&x=-415&p=Kubrt%20Pavel">Kubrt Pavel</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>9</td>
<td class=ar>2</td>
<td class=ar>2</td>
<td class=ar>5</td>
<td class=ar>26</td>
<td class=al>&nbsp;:&nbsp;29</td>
<td class=ar>6</td>
<td class=art>111</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>26.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1896&x=-415&p=Hrn%C4%8D%C3%AD%C5%99%20Radek">Hrnčíř Radek</a></td>
<td class=bl>Big Band</td>
<td class=br>10</td>
<td class=br>3</td>
<td class=br>0</td>
<td class=br>7</td>
<td class=br>25</td>
<td class=bl>&nbsp;:&nbsp;37</td>
<td class=br>6</td>
<td class=brt>109</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>27.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1639&x=-415&p=Ou%C5%99ada%20Jaroslav">Ouřada Jaroslav</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>9</td>
<td class=ar>1</td>
<td class=ar>2</td>
<td class=ar>6</td>
<td class=ar>15</td>
<td class=al>&nbsp;:&nbsp;28</td>
<td class=ar>4</td>
<td class=art>107</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>28.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1869&x=-415&p=Klazar%20Petr">Klazar Petr</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>10</td>
<td class=br>1</td>
<td class=br>0</td>
<td class=br>9</td>
<td class=br>14</td>
<td class=bl>&nbsp;:&nbsp;50</td>
<td class=br>2</td>
<td class=brt>106</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>29.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1058&x=-415&p=Marek%20Franti%C5%A1ek">Marek František</a></td>
<td class=al>BSE United</td>
<td class=ar>9</td>
<td class=ar>2</td>
<td class=ar>0</td>
<td class=ar>7</td>
<td class=ar>26</td>
<td class=al>&nbsp;:&nbsp;38</td>
<td class=ar>4</td>
<td class=art>105</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>30.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1626&x=-415&p=Hor%C3%A1kov%C3%A1%20Miroslava">Horáková Miroslava</a></td>
<td class=bl>SHC Cheb</td>
<td class=br>9</td>
<td class=br>0</td>
<td class=br>0</td>
<td class=br>9</td>
<td class=br>14</td>
<td class=bl>&nbsp;:&nbsp;54</td>
<td class=br>0</td>
<td class=brt>104</td>
<td class=br>&nbsp;</td>
</tr></table></td></tr></table></div></p>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
