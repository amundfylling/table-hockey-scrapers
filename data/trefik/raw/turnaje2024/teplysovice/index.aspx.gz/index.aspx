<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Teplýšovice</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Teplýšovice, 23. září 2023</span></h2></div></div></div></div><p><div align="center">
<div align=center>
<a href="kriz.aspx">Zápasy ve skupinách (Basic and placement groups)</a><br>
<a href="Teplysovice_playoff.aspx ">Zápasy o umístění (Placement matches)</a><br>
<a href="utokturnaje.aspx">Tabulka útočníků (Best forwards)</a><br>
<a href="obranaturnaje.aspx">Tabulka obránců (Best defenders)</a><br>
<a href="kluby.aspx">Soutěž klubů</a><br>
</div>
<p class=v>Konečné pořadí turnaje (Final table)<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0 class="rnk">
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">M</th>
<th align="center">+</th>
<th align="center">=</th>
<th align="center">-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">Pts</th>
<th align="center">CZ pts</th>
<th>&nbsp;</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1477&x=-400&p=Kobrle%20Michal">Kobrle Michal</a></td>
<td class=al>THC Stiga Elites</td>
<td class=ar>44</td>
<td class=ar>35</td>
<td class=ar>6</td>
<td class=ar>3</td>
<td class=ar>243</td>
<td class=al>&nbsp;:&nbsp;99</td>
<td class=ar>76</td>
<td class=art>160</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>2.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=961&x=-400&p=Bo%C5%A1t%C3%ADk%20Michal">Boštík Michal</a></td>
<td class=bl>THC Stiga Elites</td>
<td class=br>48</td>
<td class=br>29</td>
<td class=br>9</td>
<td class=br>10</td>
<td class=br>174</td>
<td class=bl>&nbsp;:&nbsp;110</td>
<td class=br>67</td>
<td class=brt>152</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>3.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1065&x=-400&p=Herold%20Kry%C5%A1tof">Herold Kryštof</a></td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>43</td>
<td class=ar>28</td>
<td class=ar>5</td>
<td class=ar>10</td>
<td class=ar>142</td>
<td class=al>&nbsp;:&nbsp;83</td>
<td class=ar>61</td>
<td class=art>146</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>4.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=841&x=-400&p=Le%C5%BE%C3%ADk%20Mat%C4%9Bj">Ležík Matěj</a></td>
<td class=bl>Absolut Desperation</td>
<td class=br>44</td>
<td class=br>24</td>
<td class=br>5</td>
<td class=br>15</td>
<td class=br>153</td>
<td class=bl>&nbsp;:&nbsp;100</td>
<td class=br>53</td>
<td class=brt>141</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>5.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1&x=-400&p=Ple%C5%A1%C3%A1k%20Pavel">Plešák Pavel</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>41</td>
<td class=ar>25</td>
<td class=ar>6</td>
<td class=ar>10</td>
<td class=ar>173</td>
<td class=al>&nbsp;:&nbsp;106</td>
<td class=ar>56</td>
<td class=art>137</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>6.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=310&x=-400&p=%C4%8Cernoch%20Miroslav">Černoch Miroslav</a></td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>40</td>
<td class=br>24</td>
<td class=br>5</td>
<td class=br>11</td>
<td class=br>135</td>
<td class=bl>&nbsp;:&nbsp;64</td>
<td class=br>53</td>
<td class=brt>134</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>7.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1876&x=-400&p=Kop%C5%99iva%20Adam">Kopřiva Adam</a></td>
<td class=al>BSE United</td>
<td class=ar>38</td>
<td class=ar>23</td>
<td class=ar>4</td>
<td class=ar>11</td>
<td class=ar>146</td>
<td class=al>&nbsp;:&nbsp;91</td>
<td class=ar>50</td>
<td class=art>132</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>8.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=40&x=-400&p=Mat%C3%BDsek%20Daniel">Matýsek Daniel</a></td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>41</td>
<td class=br>21</td>
<td class=br>11</td>
<td class=br>9</td>
<td class=br>112</td>
<td class=bl>&nbsp;:&nbsp;71</td>
<td class=br>53</td>
<td class=brt>131</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>9.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=567&x=-400&p=Lebl%20Kry%C5%A1tof">Lebl Kryštof</a></td>
<td class=al>Big Band</td>
<td class=ar>35</td>
<td class=ar>23</td>
<td class=ar>7</td>
<td class=ar>5</td>
<td class=ar>120</td>
<td class=al>&nbsp;:&nbsp;60</td>
<td class=ar>53</td>
<td class=art>128</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>10.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=993&x=-400&p=Chyl%C3%ADk%20ml.%20Ji%C5%99%C3%AD">Chylík ml. Jiří</a></td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>36</td>
<td class=br>24</td>
<td class=br>2</td>
<td class=br>10</td>
<td class=br>118</td>
<td class=bl>&nbsp;:&nbsp;56</td>
<td class=br>50</td>
<td class=brt>127</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>11.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=53&x=-400&p=Pikl%20V%C3%A1clav">Pikl Václav</a></td>
<td class=al>THC Stiga Elites</td>
<td class=ar>34</td>
<td class=ar>18</td>
<td class=ar>5</td>
<td class=ar>11</td>
<td class=ar>92</td>
<td class=al>&nbsp;:&nbsp;68</td>
<td class=ar>41</td>
<td class=art>126</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>12.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=248&x=-400&p=%C5%BDen%C3%AD%C5%A1ek%20Martin">Ženíšek Martin</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>36</td>
<td class=br>20</td>
<td class=br>5</td>
<td class=br>11</td>
<td class=br>138</td>
<td class=bl>&nbsp;:&nbsp;99</td>
<td class=br>45</td>
<td class=brt>125</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>13.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1641&x=-400&p=Klazar%20Maty%C3%A1%C5%A1">Klazar Matyáš</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>35</td>
<td class=ar>18</td>
<td class=ar>4</td>
<td class=ar>13</td>
<td class=ar>112</td>
<td class=al>&nbsp;:&nbsp;90</td>
<td class=ar>40</td>
<td class=art>124</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>14.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=26&x=-400&p=%C5%A0evr%20Milo%C5%A1">Ševr Miloš</a></td>
<td class=bl>THC Stiga Elites</td>
<td class=br>36</td>
<td class=br>18</td>
<td class=br>7</td>
<td class=br>11</td>
<td class=br>139</td>
<td class=bl>&nbsp;:&nbsp;80</td>
<td class=br>43</td>
<td class=brt>123</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>15.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1912&x=-400&p=Krejza%20Ale%C5%A1">Krejza Aleš</a></td>
<td class=al>THC Třinec</td>
<td class=ar>35</td>
<td class=ar>16</td>
<td class=ar>6</td>
<td class=ar>13</td>
<td class=ar>111</td>
<td class=al>&nbsp;:&nbsp;110</td>
<td class=ar>38</td>
<td class=art>122</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>16.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=4&x=-400&p=Kraus%20Vladim%C3%ADr">Kraus Vladimír</a></td>
<td class=bl>Absolut Desperation</td>
<td class=br>35</td>
<td class=br>17</td>
<td class=br>4</td>
<td class=br>14</td>
<td class=br>131</td>
<td class=bl>&nbsp;:&nbsp;110</td>
<td class=br>38</td>
<td class=brt>121</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>17.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=18&x=-400&p=%C5%A0ur%C3%BDn%20Anton%C3%ADn">Šurýn Antonín</a></td>
<td class=al>Big Band</td>
<td class=ar>31</td>
<td class=ar>12</td>
<td class=ar>7</td>
<td class=ar>12</td>
<td class=ar>67</td>
<td class=al>&nbsp;:&nbsp;80</td>
<td class=ar>31</td>
<td class=art>119</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>18.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=201&x=-400&p=Bucek%20Tom%C3%A1%C5%A1">Bucek Tomáš</a></td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>31</td>
<td class=br>14</td>
<td class=br>5</td>
<td class=br>12</td>
<td class=br>89</td>
<td class=bl>&nbsp;:&nbsp;82</td>
<td class=br>33</td>
<td class=brt>118</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>19.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=818&x=-400&p=Je%C5%BE%20Robert">Jež Robert</a></td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>32</td>
<td class=ar>15</td>
<td class=ar>2</td>
<td class=ar>15</td>
<td class=ar>105</td>
<td class=al>&nbsp;:&nbsp;88</td>
<td class=ar>32</td>
<td class=art>117</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>20.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1940&x=-400&p=Ko%C5%A1%C5%88ar%20Martin">Košňar Martin</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>32</td>
<td class=br>12</td>
<td class=br>8</td>
<td class=br>12</td>
<td class=br>94</td>
<td class=bl>&nbsp;:&nbsp;88</td>
<td class=br>32</td>
<td class=brt>116</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>21.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1599&x=-400&p=Uhl%C3%AD%C5%99%20Miroslav">Uhlíř Miroslav</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>30</td>
<td class=ar>11</td>
<td class=ar>2</td>
<td class=ar>17</td>
<td class=ar>86</td>
<td class=al>&nbsp;:&nbsp;106</td>
<td class=ar>24</td>
<td class=art>115</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>22.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1927&x=-400&p=Kraus%20Vojt%C4%9Bch">Kraus Vojtěch</a></td>
<td class=bl>Absolut Desperation</td>
<td class=br>32</td>
<td class=br>13</td>
<td class=br>4</td>
<td class=br>15</td>
<td class=br>87</td>
<td class=bl>&nbsp;:&nbsp;99</td>
<td class=br>30</td>
<td class=brt>114</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>23.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1058&x=-400&p=Marek%20Franti%C5%A1ek">Marek František</a></td>
<td class=al>BSE United</td>
<td class=ar>31</td>
<td class=ar>11</td>
<td class=ar>1</td>
<td class=ar>19</td>
<td class=ar>78</td>
<td class=al>&nbsp;:&nbsp;98</td>
<td class=ar>23</td>
<td class=art>113</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>24.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=176&x=-400&p=Lopaur%20Zden%C4%9Bk">Lopaur Zdeněk</a></td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>31</td>
<td class=br>9</td>
<td class=br>3</td>
<td class=br>19</td>
<td class=br>88</td>
<td class=bl>&nbsp;:&nbsp;96</td>
<td class=br>21</td>
<td class=brt>112</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>25.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1465&x=-400&p=Martinec%20Martin">Martinec Martin</a></td>
<td class=al>*THC Predators (SVK)</td>
<td class=ar>46</td>
<td class=ar>29</td>
<td class=ar>4</td>
<td class=ar>13</td>
<td class=ar>209</td>
<td class=al>&nbsp;:&nbsp;118</td>
<td class=ar>62</td>
<td class=art>111</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>26.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=910&x=-400&p=Gobyov%C3%A1%20Vlasta">Gobyová Vlasta</a></td>
<td class=bl>THC Teplýšovice</td>
<td class=br>47</td>
<td class=br>24</td>
<td class=br>4</td>
<td class=br>19</td>
<td class=br>130</td>
<td class=bl>&nbsp;:&nbsp;113</td>
<td class=br>52</td>
<td class=brt>109</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>27.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=204&x=-400&p=Nechutn%C3%BD%20Hynek">Nechutný Hynek</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>44</td>
<td class=ar>21</td>
<td class=ar>9</td>
<td class=ar>14</td>
<td class=ar>111</td>
<td class=al>&nbsp;:&nbsp;83</td>
<td class=ar>51</td>
<td class=art>107</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>28.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1657&x=-400&p=Perkner%20Jon%C3%A1%C5%A1">Perkner Jonáš</a></td>
<td class=bl>Big Band</td>
<td class=br>42</td>
<td class=br>22</td>
<td class=br>4</td>
<td class=br>16</td>
<td class=br>124</td>
<td class=bl>&nbsp;:&nbsp;109</td>
<td class=br>48</td>
<td class=brt>106</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>29.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=442&x=-400&p=Poho%C5%99al%C3%BD%20Pavel">Pohořalý Pavel</a></td>
<td class=al>THC Teplýšovice</td>
<td class=ar>40</td>
<td class=ar>17</td>
<td class=ar>7</td>
<td class=ar>16</td>
<td class=ar>108</td>
<td class=al>&nbsp;:&nbsp;113</td>
<td class=ar>41</td>
<td class=art>105</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>30.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1968&x=-400&p=Tou%C5%A1%20Michal">Touš Michal</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>39</td>
<td class=br>15</td>
<td class=br>8</td>
<td class=br>16</td>
<td class=br>155</td>
<td class=bl>&nbsp;:&nbsp;132</td>
<td class=br>38</td>
<td class=brt>104</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>31.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1896&x=-400&p=Hrn%C4%8D%C3%AD%C5%99%20Radek">Hrnčíř Radek</a></td>
<td class=al>Big Band</td>
<td class=ar>39</td>
<td class=ar>13</td>
<td class=ar>2</td>
<td class=ar>24</td>
<td class=ar>90</td>
<td class=al>&nbsp;:&nbsp;153</td>
<td class=ar>28</td>
<td class=art>103</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>32.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1869&x=-400&p=Klazar%20Petr">Klazar Petr</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>39</td>
<td class=br>10</td>
<td class=br>2</td>
<td class=br>27</td>
<td class=br>78</td>
<td class=bl>&nbsp;:&nbsp;136</td>
<td class=br>22</td>
<td class=brt>102</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>33.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=436&x=-400&p=Goby%20Vojt%C4%9Bch">Goby Vojtěch</a></td>
<td class=al>THC Teplýšovice</td>
<td class=ar>36</td>
<td class=ar>13</td>
<td class=ar>4</td>
<td class=ar>19</td>
<td class=ar>123</td>
<td class=al>&nbsp;:&nbsp;127</td>
<td class=ar>30</td>
<td class=art>100</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>34.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1252&x=-400&p=Moravec%20Martin">Moravec Martin</a></td>
<td class=bl>Brno</td>
<td class=br>35</td>
<td class=br>8</td>
<td class=br>4</td>
<td class=br>23</td>
<td class=br>61</td>
<td class=bl>&nbsp;:&nbsp;109</td>
<td class=br>20</td>
<td class=brt>99</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>35.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1372&x=-400&p=Sta%C5%99eck%C3%A1%20Kate%C5%99ina">Stařecká Kateřina</a></td>
<td class=al>THC Teplýšovice</td>
<td class=ar>34</td>
<td class=ar>7</td>
<td class=ar>6</td>
<td class=ar>21</td>
<td class=ar>63</td>
<td class=al>&nbsp;:&nbsp;128</td>
<td class=ar>20</td>
<td class=art>98</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>36.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1959&x=-400&p=Chlebo%20Ond%C5%99ej">Chlebo Ondřej</a></td>
<td class=bl>BSE United</td>
<td class=br>36</td>
<td class=br>8</td>
<td class=br>3</td>
<td class=br>25</td>
<td class=br>51</td>
<td class=bl>&nbsp;:&nbsp;126</td>
<td class=br>19</td>
<td class=brt>97</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>37.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=2038&x=-400&p=Moravec%20Michael">Moravec Michael</a></td>
<td class=al>Brno</td>
<td class=ar>36</td>
<td class=ar>7</td>
<td class=ar>4</td>
<td class=ar>25</td>
<td class=ar>61</td>
<td class=al>&nbsp;:&nbsp;157</td>
<td class=ar>18</td>
<td class=art>96</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>38.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=435&x=-400&p=Goby%20Pavel">Goby Pavel</a></td>
<td class=bl>THC Teplýšovice</td>
<td class=br>35</td>
<td class=br>5</td>
<td class=br>5</td>
<td class=br>25</td>
<td class=br>58</td>
<td class=bl>&nbsp;:&nbsp;144</td>
<td class=br>15</td>
<td class=brt>95</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>39.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1879&x=-400&p=Kupka%20Nikolas">Kupka Nikolas</a></td>
<td class=al>Big Band</td>
<td class=ar>36</td>
<td class=ar>5</td>
<td class=ar>2</td>
<td class=ar>29</td>
<td class=ar>58</td>
<td class=al>&nbsp;:&nbsp;185</td>
<td class=ar>12</td>
<td class=art>94</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>40.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=2021&x=-400&p=Novotn%C3%BD%20Kry%C5%A1tof">Novotný Kryštof</a></td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>36</td>
<td class=br>2</td>
<td class=br>2</td>
<td class=br>32</td>
<td class=br>24</td>
<td class=bl>&nbsp;:&nbsp;200</td>
<td class=br>6</td>
<td class=brt>93</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>41.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=2037&x=-400&p=Ponert%20Bek">Ponert Bek</a></td>
<td class=al>Praha</td>
<td class=ar>35</td>
<td class=ar>0</td>
<td class=ar>1</td>
<td class=ar>34</td>
<td class=ar>15</td>
<td class=al>&nbsp;:&nbsp;185</td>
<td class=ar>1</td>
<td class=art>92</td>
<td class=ar>&nbsp;</td>
</tr></table></td></tr></table></div></p>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
