<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR veteráni</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.stolnihokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="../../pohar.aspx">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>MR veteráni 2. červen 2019</span></h2></div></div></div></div><p><div align="center">
<div align=center>
<a href="kriz.aspx">Zápasy ve skupinách (Basic and placement groups)</a><br>
<a href="MR_veterani_umisteni.aspx ">Zápasy o umístění (Placement matches)</a><br>
<a href="utokturnaje.aspx">Tabulka útočníků (Best forwards)</a><br>
<a href="obranaturnaje.aspx">Tabulka obránců (Best defenders)</a><br>
</div>
<table border=0 cellpadding=2 cellspacing=0 class="rnk">
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">Z</th>
<th align="center">+</th>
<th align="center">=</th>
<th align="center">-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al>Jan Dryák</td>
<td class=al>Big Band</td>
<td class=ar>22</td>
<td class=ar>20</td>
<td class=ar>1</td>
<td class=ar>1</td>
<td class=ar>103</td>
<td class=al>&nbsp;:&nbsp;38</td>
</tr><tr><td class=br>2.</td>
<td class=bl>David Šmíd</td>
<td class=bl>Absolut Desperation</td>
<td class=br>21</td>
<td class=br>15</td>
<td class=br>1</td>
<td class=br>5</td>
<td class=br>73</td>
<td class=bl>&nbsp;:&nbsp;43</td>
</tr><tr><td class=ar>3.</td>
<td class=al>Pavel Plešák</td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>19</td>
<td class=ar>12</td>
<td class=ar>2</td>
<td class=ar>5</td>
<td class=ar>77</td>
<td class=al>&nbsp;:&nbsp;37</td>
</tr><tr><td class=br>4.</td>
<td class=bl>Daniel Matýsek</td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>23</td>
<td class=br>16</td>
<td class=br>0</td>
<td class=br>7</td>
<td class=br>73</td>
<td class=bl>&nbsp;:&nbsp;39</td>
</tr><tr><td class=ar>5.</td>
<td class=al>Václav Pikl</td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>12</td>
<td class=ar>8</td>
<td class=ar>1</td>
<td class=ar>3</td>
<td class=ar>41</td>
<td class=al>&nbsp;:&nbsp;19</td>
</tr><tr><td class=br>6.</td>
<td class=bl>František Marek</td>
<td class=bl>BSE United</td>
<td class=br>14</td>
<td class=br>7</td>
<td class=br>1</td>
<td class=br>6</td>
<td class=br>34</td>
<td class=bl>&nbsp;:&nbsp;32</td>
</tr><tr><td class=ar>7.</td>
<td class=al>Zbyněk Pilař</td>
<td class=al>Absolut Desperation</td>
<td class=ar>15</td>
<td class=ar>7</td>
<td class=ar>1</td>
<td class=ar>7</td>
<td class=ar>40</td>
<td class=al>&nbsp;:&nbsp;34</td>
</tr><tr><td class=br>8.</td>
<td class=bl>Robert Jež</td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>14</td>
<td class=br>7</td>
<td class=br>1</td>
<td class=br>6</td>
<td class=br>37</td>
<td class=bl>&nbsp;:&nbsp;30</td>
</tr><tr><td class=ar>9.</td>
<td class=al>Tomáš Bucek</td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>12</td>
<td class=ar>6</td>
<td class=ar>3</td>
<td class=ar>3</td>
<td class=ar>38</td>
<td class=al>&nbsp;:&nbsp;26</td>
</tr><tr><td class=br>10.</td>
<td class=bl>David Cibulka</td>
<td class=bl>THC Třinec</td>
<td class=br>11</td>
<td class=br>6</td>
<td class=br>2</td>
<td class=br>3</td>
<td class=br>27</td>
<td class=bl>&nbsp;:&nbsp;22</td>
</tr><tr><td class=ar>11.</td>
<td class=al>Jan Klokan</td>
<td class=al>SHC Cheb</td>
<td class=ar>12</td>
<td class=ar>5</td>
<td class=ar>1</td>
<td class=ar>6</td>
<td class=ar>24</td>
<td class=al>&nbsp;:&nbsp;34</td>
</tr><tr><td class=br>12.</td>
<td class=bl>Stanislav Srba</td>
<td class=bl>SHC Cheb</td>
<td class=br>11</td>
<td class=br>4</td>
<td class=br>2</td>
<td class=br>5</td>
<td class=br>20</td>
<td class=bl>&nbsp;:&nbsp;30</td>
</tr><tr><td class=ar>13.</td>
<td class=al>Josef Kůrka</td>
<td class=al>THC Stiga-Game Příbram</td>
<td class=ar>11</td>
<td class=ar>5</td>
<td class=ar>0</td>
<td class=ar>6</td>
<td class=ar>44</td>
<td class=al>&nbsp;:&nbsp;30</td>
</tr><tr><td class=br>14.</td>
<td class=bl>Jan Medvec</td>
<td class=bl>SHC Cheb</td>
<td class=br>12</td>
<td class=br>4</td>
<td class=br>2</td>
<td class=br>6</td>
<td class=br>38</td>
<td class=bl>&nbsp;:&nbsp;43</td>
</tr><tr><td class=ar>15.</td>
<td class=al>Jaroslav Ouřada</td>
<td class=al>SHC Cheb</td>
<td class=ar>12</td>
<td class=ar>4</td>
<td class=ar>2</td>
<td class=ar>6</td>
<td class=ar>24</td>
<td class=al>&nbsp;:&nbsp;34</td>
</tr><tr><td class=br>16.</td>
<td class=bl>Vladimír Kraus</td>
<td class=bl>Absolut Desperation</td>
<td class=br>11</td>
<td class=br>4</td>
<td class=br>1</td>
<td class=br>6</td>
<td class=br>26</td>
<td class=bl>&nbsp;:&nbsp;33</td>
</tr><tr><td class=ar>17.</td>
<td class=al>Zdeněk Lopaur</td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>12</td>
<td class=ar>3</td>
<td class=ar>4</td>
<td class=ar>5</td>
<td class=ar>28</td>
<td class=al>&nbsp;:&nbsp;34</td>
</tr><tr><td class=br>18.</td>
<td class=bl>Petr Holub</td>
<td class=bl>SHC Cheb</td>
<td class=br>11</td>
<td class=br>4</td>
<td class=br>0</td>
<td class=br>7</td>
<td class=br>16</td>
<td class=bl>&nbsp;:&nbsp;38</td>
</tr><tr><td class=ar>19.</td>
<td class=al>Josef Gruncl</td>
<td class=al>SHC Cheb</td>
<td class=ar>12</td>
<td class=ar>2</td>
<td class=ar>4</td>
<td class=ar>6</td>
<td class=ar>29</td>
<td class=al>&nbsp;:&nbsp;47</td>
</tr><tr><td class=br>20.</td>
<td class=bl>Stanislav Suchý</td>
<td class=bl>Big Band</td>
<td class=br>11</td>
<td class=br>3</td>
<td class=br>1</td>
<td class=br>7</td>
<td class=br>19</td>
<td class=bl>&nbsp;:&nbsp;36</td>
</tr><tr><td class=ar>21.</td>
<td class=al>Tomáš Kahoun st.</td>
<td class=al>BSE United</td>
<td class=ar>12</td>
<td class=ar>4</td>
<td class=ar>0</td>
<td class=ar>8</td>
<td class=ar>21</td>
<td class=al>&nbsp;:&nbsp;38</td>
</tr><tr><td class=br>22.</td>
<td class=bl>Daniel Hrachovec</td>
<td class=bl>SHC Cheb</td>
<td class=br>11</td>
<td class=br>1</td>
<td class=br>2</td>
<td class=br>8</td>
<td class=br>21</td>
<td class=bl>&nbsp;:&nbsp;50</td>
</tr><tr><td class=ar>23.</td>
<td class=al>Hynek Nechutný</td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>12</td>
<td class=ar>3</td>
<td class=ar>1</td>
<td class=ar>8</td>
<td class=ar>19</td>
<td class=al>&nbsp;:&nbsp;34</td>
</tr><tr><td class=br>24.</td>
<td class=bl>Miroslav Mareš st.</td>
<td class=bl>BSE United</td>
<td class=br>11</td>
<td class=br>1</td>
<td class=br>1</td>
<td class=br>9</td>
<td class=br>14</td>
<td class=bl>&nbsp;:&nbsp;45</td>
</tr><tr><td class=ar>25.</td>
<td class=al>Petr Klazar</td>
<td class=al>BSE United</td>
<td class=ar>12</td>
<td class=ar>0</td>
<td class=ar>0</td>
<td class=ar>12</td>
<td class=ar>8</td>
<td class=al>&nbsp;:&nbsp;48</td>
</tr></table></td></tr></table></div></p>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
