<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR družstva</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.stolnihokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="../../pohar.aspx">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>MR družstva 1. červen 2019</span></h2></div></div></div></div><p><div align="center">
<div align=center>
<a href="kriz.aspx">Zápasy ve skupinách (Basic and placement groups)</a><br>
<a href="MR_druzstva_umisteni.aspx ">Zápasy o umístění (Placement matches)</a><br>
</div>



<p class=v>Konečné pořadí turnaje<br>

<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>

<tr><td class=ar>1.</td>
<td class=al>HCS Žabka Praha<br>
Filip Hamáček, Zdeněk Matoušek ml., Jiří Chylík, Daniel Matýsek, Miroslav Černoch, Kryštof Herold, Jakub Matýsek, Zdeněk Matoušek st. </td>
</tr>

<tr><td class=br>2.</td>
<td class=bl>Gladiators Plzeň "A"<br>
Michal Kobrle, Pavel Plešák, Václav Pikl, Bjarne Axelsen, Martin Ženíšek, Miloš Ševr
</td>
</tr>

<tr><td class=ar>3.</td>
<td class=al>THC Stiga-Game Příbram "A"<br>
Leoš Hvižď ml., Jakub Sládek, Jan Sládek, Martin Maděra, Josef Kůrka, Lukáš Vacek, Jakub Saj
</td>
</tr>

<tr><td class=br>4.</td>
<td class=bl>Big Band "A"<br>
Kryštof Lebl, Jan Dryák, Adam Zielinský, Simon Thomas, Antonín Šurýn, Standa Suchý, Alexandr Mačynský
</td>
</tr>


<tr><td class=ar>5.</td>
<td class=al>Absolut Desperation<br>
Stanislav Kraus, David Šmíd, Vladimír Kraus, Zbyněk Pilař, David Brdíček, Michal Zunka
</td>
</tr>

<tr><td class=br>6.</td>
<td class=bl>BSE United "A"<br>
Samuel Hána, Lukáš Paclík, Tomáš Kahoun ml., Lukáš Kahoun, Michal Blažek, Tibor Varga
</td>
</tr>


<tr><td class=ar>7.</td>
<td class=al>THC Třinec<br>
Lukáš Turoň, Petr Turoň, Tomáš Waclawek, David Cibulka, Roman Pavlica
</td>
</tr>

<tr><td class=br>8.</td>
<td class=bl>Stiga HC Benátky<br>
Michal Boštík, Tomáš Bucek, Zdeněk Lopaur, Jiří Malík st., Robert Jež, Jindřich Petr
</td>
</tr>


<tr><td class=ar>9.</td>
<td class=al>SHC Cheb <br>
Miloslav Kubica, Jiří Vácha, Luboš Černý, Jiří Kropáček, Michal Mašika, Václav Macek
</td>
</tr>

</tr><tr><td class=br>10.</td>
<td class=bl>SHC Cheb - Black Horses<br>
Václav Mezera, Michal Holeček, Iva Fochlerová, Petr Holub, Michael Černý, Jiří Macek
</td>
</tr>

<tr><td class=ar>11.</td>
<td class=al>THC Stiga-Game Příbram U17<br>
Tomáš Růžička, Vojtěch Bernát, Pavel Hráský, Anita Grimová, Filip Werner, Tomáš Rybák
</td>
</tr>

<tr><td class=br>12.</td>
<td class=bl>SHC Cheb - Veterans<br>
Daniel Hrachovec, Zbyněk Froněk, Jan Medvec, Josef Gruncl, Jan Klokan, Jaroslav Ouřada
</td>
</tr>

<tr><td class=ar>13.</td>
<td class=al>BSE United Staré Páky<br>
Tomáš Kahoun st., Hana Marešová, Miroslav Mareš st., František Marek, Petr Klazar
</td>
</tr>


<tr><td class=br>14.</td>
<td class=bl>Gladiators Plzeň "B"<br>
Hynek Nechutný, Miroslav Uhlíř, Pavel Kubrt, Jan Kubernát, Matěj Cingroš
</td>
</tr>

<tr><td class=ar>15.</td>
<td class=al>SHC Cheb - Black Orange<br>
Stanislav Srba, Miroslava Horáková, Jan Kubica, Michael Srba, Stanislav Srba ml., Petr Šrámek
</td>
</tr>


<tr><td class=br>16.</td>
<td class=bl>Big Band "B"<br>
Michal Lévy, Vít Perkner, Jonáš Perkner, Kateřina Šurýnová, Radek Hrnčíř, František Kubera
</td>
</tr>

<tr><td class=ar>17.</td>
<td class=al>BSE United Junioři<br>
Matyáš Klazar, Štěpán Krejzlík, Benjamin Hána, Adam Kopřiva, Luboš Kopřiva, Vojtěch Vacke
</td>
</tr>

</table></td></tr></table></div>


</p>





</div></p>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
