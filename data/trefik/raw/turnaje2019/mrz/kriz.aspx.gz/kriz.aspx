<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR ženy</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.stolnihokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="../../pohar.aspx">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../mrz">MR ženy 2. červen 2019</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p><a href="#basic">Základní skupiny (Basic groups)</a><br>
<a href="#final">Výkonnostní skupiny (Final groups)</a><br>
<a name="basic"><p class=vm>Základní skupiny (Basic groups)</p></a>
<p class=v>Group Ž</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Iv Fochlerová</td><td class=ic>CZE</td><td class=kx>*</td>
<td class=kL>1:3 + 2:2</td>
<td class=kW>5:2 + 4:1</td>
<td class=kW>4:0 + 3:0</td>
<td class=kW>5:1 + 3:3</td>
<td class=br>27:12</td><td class=br>+15</td>
<td class=bc>5 - 2 - 1</td>
<td class=br><strong>12</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Ha Marešová</td><td class=ic>CZE</td><td class=kW>3:1 + 2:2</td>
<td class=kx>*</td>
<td class=kT>2:2 + 3:3</td>
<td class=kL>0:1 + 1:0</td>
<td class=kW>3:1 + 3:2</td>
<td class=br>17:12</td><td class=br>+5</td>
<td class=bc>4 - 3 - 1</td>
<td class=br><strong>11</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>An Grimová</td><td class=ic>CZE</td><td class=kL>2:5 + 1:4</td>
<td class=kT>2:2 + 3:3</td>
<td class=kx>*</td>
<td class=kW>7:0 + 0:3</td>
<td class=kW>4:1 + 9:3</td>
<td class=br>28:21</td><td class=br>+7</td>
<td class=bc>3 - 2 - 3</td>
<td class=br><strong>8</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Ka Šurýnová</td><td class=ic>CZE</td><td class=kL>0:4 + 0:3</td>
<td class=kW>1:0 + 0:1</td>
<td class=kL>0:7 + 3:0</td>
<td class=kx>*</td>
<td class=kL>0:5 + 4:2</td>
<td class=br>8:22</td><td class=br>-14</td>
<td class=bc>3 - 0 - 5</td>
<td class=br><strong>6</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Mi Horáková</td><td class=ic>CZE</td><td class=kL>1:5 + 3:3</td>
<td class=kL>1:3 + 2:3</td>
<td class=kL>1:4 + 3:9</td>
<td class=kW>5:0 + 2:4</td>
<td class=kx>*</td>
<td class=br>18:31</td><td class=br>-13</td>
<td class=bc>1 - 1 - 6</td>
<td class=br><strong>3</strong></td><td class=d>5.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Ka Šurýnová</td><td class=bc>5 : 0 + 2 : 4</tr></td>
<tr><td class=brW>Ha Marešová</td><td class=bc>-</td><td class=bl>Iv Fochlerová</td><td class=bc>3 : 1 + 2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 1 + 9 : 3</tr></td>
<tr><td class=brW>Ka Šurýnová</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>1 : 0 + 0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>2 : 2 + 3 : 3</tr></td>
<tr><td class=brW>Iv Fochlerová</td><td class=bc>-</td><td class=bl>Ka Šurýnová</td><td class=bc>4 : 0 + 3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ha Marešová</td><td class=bc>1 : 3 + 2 : 3</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Iv Fochlerová</td><td class=bc>2 : 5 + 1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Iv Fochlerová</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>5 : 1 + 3 : 3</tr></td>
<tr><td class=br>Ka Šurýnová</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>0 : 7 + 3 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<hr><a name="final"><p class=vm>Výkonnostní skupiny (Final groups)</p></a>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
