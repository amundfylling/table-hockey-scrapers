<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open - Plzeň</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.stolnihokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="../../pohar.aspx">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2019">Czech Open - Plzeň </a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group A2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt>Ar Stolyarov</td><td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kL>5:6</td>
<td class=kL>1:5</td>
<td class=kW>5:3</td>
<td class=kW>7:2 K</td>
<td class=kW>6:2</td>
<td class=kT>1:1 K</td>
<td class=kW>6:3</td>
<td class=kW>8:4 K</td>
<td class=kW>5:3</td>
<td class=kW>7:4 K</td>
<td class=kW>5:3</td>
<td class=kW>8:1</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>9:2 K</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>8:3 K</td>
<td class=kW>6:2</td>
<td class=kW>7:2 K</td>
<td class=kW>6:3</td>
<td class=br>132:60</td><td class=br>+72</td>
<td class=bc>19 - 2 - 2</td>
<td class=br><strong>40</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt>Le Hvižď ml.</td><td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kL>4:5</td>
<td class=kW>1:0 K</td>
<td class=kW>4:3</td>
<td class=kW>7:2 K</td>
<td class=kT>4:4</td>
<td class=kW>6:4 K</td>
<td class=kW>5:3</td>
<td class=kW>4:3 K</td>
<td class=kT>1:1</td>
<td class=kW>8:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>3:0 K</td>
<td class=kW>6:1</td>
<td class=kT>4:4</td>
<td class=kW>3:1 K</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>4:2 K</td>
<td class=kW>7:2</td>
<td class=kT>2:2</td>
<td class=br>95:56</td><td class=br>+39</td>
<td class=bc>16 - 4 - 3</td>
<td class=br><strong>36</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt>Dm Petrov</td><td class=kW>6:5</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kL>3:4 K</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>6:4</td>
<td class=kW>5:4 K</td>
<td class=kW>5:0 K</td>
<td class=kL>3:5 K</td>
<td class=kW>5:1</td>
<td class=kW>6:4</td>
<td class=kW>5:2 K</td>
<td class=kL>4:5</td>
<td class=kW>6:3 K</td>
<td class=kW>8:2</td>
<td class=kW>6:0</td>
<td class=kW>7:1</td>
<td class=kW>3:1 K</td>
<td class=br>104:62</td><td class=br>+42</td>
<td class=bc>16 - 2 - 5</td>
<td class=br><strong>34</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt>Mi Shashkov</td><td class=kW>5:1</td>
<td class=kW>5:4</td>
<td class=kW>4:3 K</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kT>3:3 K</td>
<td class=kT>3:3 K</td>
<td class=kW>2:1 K</td>
<td class=kT>2:2</td>
<td class=kW>7:4</td>
<td class=kW>3:1 K</td>
<td class=kW>4:3</td>
<td class=kT>2:2 K</td>
<td class=kW>7:0</td>
<td class=kW>4:2</td>
<td class=kW>7:3</td>
<td class=kW>4:0 K</td>
<td class=br>83:55</td><td class=br>+28</td>
<td class=bc>14 - 5 - 4</td>
<td class=br><strong>33</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>Ji Chylík ml.</td><td class=kL>3:5</td>
<td class=kL>0:1 K</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>1:3 K</td>
<td class=kT>2:2</td>
<td class=kL>2:3 K</td>
<td class=kW>4:1</td>
<td class=kW>7:1 K</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kL>3:7</td>
<td class=kW>4:2 K</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>3:1 K</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1 K</td>
<td class=kW>6:1</td>
<td class=kW>1:0</td>
<td class=br>80:50</td><td class=br>+30</td>
<td class=bc>13 - 4 - 6</td>
<td class=br><strong>30</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>Mi Boštík</td><td class=kL>2:7 K</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kW>2:1 K</td>
<td class=kW>3:1</td>
<td class=kW>6:4 K</td>
<td class=kL>2:3</td>
<td class=kT>4:4 K</td>
<td class=kL>2:9</td>
<td class=kW>6:3</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kT>5:5 K</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>9:2 K</td>
<td class=kW>5:1</td>
<td class=kW>4:0 K</td>
<td class=kW>3:0</td>
<td class=br>91:68</td><td class=br>+23</td>
<td class=bc>13 - 3 - 7</td>
<td class=br><strong>29</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Ja Matýsek</td><td class=kL>2:6</td>
<td class=kL>2:7 K</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1 K</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>7:6 K</td>
<td class=kL>2:3</td>
<td class=kL>2:4 K</td>
<td class=kL>3:5</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kW>6:3</td>
<td class=kW>5:2 K</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kW>2:1 K</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kL>1:5 K</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=br>77:73</td><td class=br>+4</td>
<td class=bc>13 - 1 - 9</td>
<td class=br><strong>27</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>Ho Sládek</td><td class=kT>1:1 K</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2 K</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kT>3:3 K</td>
<td class=kL>0:2</td>
<td class=kT>2:2 K</td>
<td class=kW>6:3</td>
<td class=kW>8:0</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>5:2 K</td>
<td class=kW>2:0</td>
<td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kT>3:3 K</td>
<td class=kW>4:3</td>
<td class=kW>4:1 K</td>
<td class=kL>0:2</td>
<td class=br>66:48</td><td class=br>+18</td>
<td class=bc>10 - 7 - 6</td>
<td class=br><strong>27</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>Da Šmíd</td><td class=kL>3:6</td>
<td class=kL>4:6 K</td>
<td class=kL>2:5</td>
<td class=kW>3:0</td>
<td class=kW>3:2 K</td>
<td class=kL>1:3</td>
<td class=kL>6:7 K</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:1 K</td>
<td class=kT>0:0</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kW>5:1</td>
<td class=kW>3:2 K</td>
<td class=kW>5:4</td>
<td class=kL>2:8</td>
<td class=kW>4:3 K</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kT>3:3 K</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=br>74:70</td><td class=br>+4</td>
<td class=bc>12 - 2 - 9</td>
<td class=br><strong>26</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Da Dvořáček</td><td class=kL>4:8 K</td>
<td class=kL>3:5</td>
<td class=kL>2:7</td>
<td class=kW>5:3</td>
<td class=kL>1:4</td>
<td class=kL>4:6 K</td>
<td class=kW>3:2</td>
<td class=kT>3:3 K</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:1 K</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kL>4:7</td>
<td class=kL>2:5</td>
<td class=kL>1:5 K</td>
<td class=kW>5:0</td>
<td class=kW>4:3</td>
<td class=kW>7:1</td>
<td class=kW>3:1 K</td>
<td class=kW>6:1</td>
<td class=kW>6:4 K</td>
<td class=kW>6:0</td>
<td class=br>83:75</td><td class=br>+8</td>
<td class=bc>12 - 2 - 9</td>
<td class=br><strong>26</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>Pe Borsanyi</td><td class=kL>3:5</td>
<td class=kL>3:4 K</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>1:7 K</td>
<td class=kW>3:2</td>
<td class=kW>4:2 K</td>
<td class=kW>2:0</td>
<td class=kL>1:2 K</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kT>5:5 K</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>5:2 K</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>4:3 K</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=br>67:62</td><td class=br>+5</td>
<td class=bc>12 - 2 - 9</td>
<td class=br><strong>26</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>Pa Plešák</td><td class=kL>4:7 K</td>
<td class=kT>1:1</td>
<td class=kL>4:6</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kT>4:4 K</td>
<td class=kW>5:3</td>
<td class=kT>2:2 K</td>
<td class=kT>0:0</td>
<td class=kL>1:3 K</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kT>3:3 K</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>6:1 K</td>
<td class=kW>4:2</td>
<td class=kW>4:3 K</td>
<td class=kW>7:3</td>
<td class=br>82:69</td><td class=br>+13</td>
<td class=bc>9 - 7 - 7</td>
<td class=br><strong>25</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt>St Kraus</td><td class=kL>3:5</td>
<td class=kL>2:8</td>
<td class=kL>4:5 K</td>
<td class=kT>3:3 K</td>
<td class=kL>2:5</td>
<td class=kW>9:2</td>
<td class=kL>3:5</td>
<td class=kL>3:6</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>4:1 K</td>
<td class=kW>5:4 K</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kL>4:7 K</td>
<td class=kT>5:5</td>
<td class=kL>1:4 K</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>6:1 K</td>
<td class=br>85:82</td><td class=br>+3</td>
<td class=bc>11 - 2 - 10</td>
<td class=br><strong>24</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt>An Bozic</td><td class=kL>1:8</td>
<td class=kL>2:3</td>
<td class=kL>0:5 K</td>
<td class=kT>3:3 K</td>
<td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=kL>0:8</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kL>1:4 K</td>
<td class=kx>*</td>
<td class=kW>4:1 K</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2 K</td>
<td class=kW>4:1</td>
<td class=kW>7:0 K</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kT>1:1 K</td>
<td class=br>59:74</td><td class=br>-15</td>
<td class=bc>7 - 6 - 10</td>
<td class=br><strong>20</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt>Ma Ženíšek</td><td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>5:3 K</td>
<td class=kL>1:2 K</td>
<td class=kW>7:3</td>
<td class=kL>3:5</td>
<td class=kL>3:6</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kW>7:4</td>
<td class=kW>5:1</td>
<td class=kL>2:5</td>
<td class=kL>4:5 K</td>
<td class=kL>1:4 K</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>2:3 K</td>
<td class=kW>3:1</td>
<td class=kL>2:6 K</td>
<td class=kW>5:3</td>
<td class=kW>5:3</td>
<td class=kL>3:5</td>
<td class=kW>4:2 K</td>
<td class=br>73:83</td><td class=br>-10</td>
<td class=bc>9 - 1 - 13</td>
<td class=br><strong>19</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt>To Bucek</td><td class=kL>1:5</td>
<td class=kL>0:3 K</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>2:4 K</td>
<td class=kL>1:4</td>
<td class=kL>2:5 K</td>
<td class=kL>0:1</td>
<td class=kL>2:3 K</td>
<td class=kW>5:2</td>
<td class=kT>5:5 K</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>5:2 K</td>
<td class=kW>4:2</td>
<td class=kL>4:6</td>
<td class=kL>0:1 K</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=br>59:70</td><td class=br>-11</td>
<td class=bc>8 - 2 - 13</td>
<td class=br><strong>18</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ne Skrlep</td><td class=kL>2:9 K</td>
<td class=kL>1:6</td>
<td class=kL>4:6</td>
<td class=kL>4:7</td>
<td class=kL>0:6</td>
<td class=kT>5:5 K</td>
<td class=kL>1:3</td>
<td class=kL>2:5 K</td>
<td class=kL>4:5</td>
<td class=kW>5:1 K</td>
<td class=kL>2:5</td>
<td class=kT>3:3 K</td>
<td class=kL>2:7</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>2:6</td>
<td class=kW>8:0</td>
<td class=kW>3:2 K</td>
<td class=kW>3:0</td>
<td class=kT>3:3 K</td>
<td class=kW>4:2</td>
<td class=br>68:89</td><td class=br>-21</td>
<td class=bc>7 - 4 - 12</td>
<td class=br><strong>18</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Zd Lopaur</td><td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kL>2:5 K</td>
<td class=kL>1:3 K</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kW>4:0</td>
<td class=kL>0:2</td>
<td class=kW>8:2</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kT>4:4</td>
<td class=kW>7:4 K</td>
<td class=kW>2:1 K</td>
<td class=kW>3:2 K</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:3 K</td>
<td class=kL>4:5</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kT>4:4 K</td>
<td class=br>59:76</td><td class=br>-17</td>
<td class=bc>7 - 4 - 12</td>
<td class=br><strong>18</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>My Shalomayev</td><td class=kL>1:3</td>
<td class=kL>1:3 K</td>
<td class=kW>5:4</td>
<td class=kL>3:4</td>
<td class=kL>1:3 K</td>
<td class=kL>1:4</td>
<td class=kL>1:2 K</td>
<td class=kW>5:0</td>
<td class=kL>3:4 K</td>
<td class=kL>3:4</td>
<td class=kL>2:5 K</td>
<td class=kL>2:3</td>
<td class=kT>5:5</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>2:5 K</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kW>5:1 K</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=br>65:67</td><td class=br>-2</td>
<td class=bc>7 - 3 - 13</td>
<td class=br><strong>17</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>To Kahoun ml.</td><td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kL>3:6 K</td>
<td class=kT>2:2 K</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kL>0:3</td>
<td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kW>4:1 K</td>
<td class=kL>0:7 K</td>
<td class=kW>6:2 K</td>
<td class=kL>2:4</td>
<td class=kL>0:8</td>
<td class=kW>3:1 K</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kL>0:2</td>
<td class=kW>6:2</td>
<td class=kT>2:2 K</td>
<td class=br>50:93</td><td class=br>-43</td>
<td class=bc>6 - 2 - 15</td>
<td class=br><strong>14</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>To Jedlička</td><td class=kL>3:8 K</td>
<td class=kL>2:7</td>
<td class=kL>2:8</td>
<td class=kL>0:7</td>
<td class=kL>1:4</td>
<td class=kL>2:9 K</td>
<td class=kL>1:3</td>
<td class=kT>3:3 K</td>
<td class=kL>1:5</td>
<td class=kL>1:3 K</td>
<td class=kW>2:1</td>
<td class=kL>1:6 K</td>
<td class=kL>1:3</td>
<td class=kW>6:2</td>
<td class=kL>3:5</td>
<td class=kW>6:4</td>
<td class=kL>2:3 K</td>
<td class=kW>5:4</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>3:1 K</td>
<td class=kL>1:3</td>
<td class=br>57:97</td><td class=br>-40</td>
<td class=bc>6 - 1 - 16</td>
<td class=br><strong>13</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Mi Blažek</td><td class=kL>2:6</td>
<td class=kL>2:4 K</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>1:5 K</td>
<td class=kL>1:5</td>
<td class=kW>5:1 K</td>
<td class=kL>3:4</td>
<td class=kT>3:3 K</td>
<td class=kL>1:6</td>
<td class=kL>3:4 K</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kW>1:0 K</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>1:5 K</td>
<td class=kW>2:0</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>5:0</td>
<td class=br>44:80</td><td class=br>-36</td>
<td class=bc>5 - 2 - 16</td>
<td class=br><strong>12</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Ja Kubernát</td><td class=kL>2:7 K</td>
<td class=kL>2:7</td>
<td class=kL>1:7</td>
<td class=kL>3:7</td>
<td class=kL>1:6</td>
<td class=kL>0:4 K</td>
<td class=kW>3:2</td>
<td class=kL>1:4 K</td>
<td class=kL>2:6</td>
<td class=kL>4:6 K</td>
<td class=kL>2:3</td>
<td class=kL>3:4 K</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kT>3:3 K</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>1:3 K</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=br>47:94</td><td class=br>-47</td>
<td class=bc>4 - 2 - 17</td>
<td class=br><strong>10</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Mi Mašika</td><td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kL>1:3 K</td>
<td class=kL>0:4 K</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kW>2:0</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>3:6</td>
<td class=kL>3:7</td>
<td class=kL>1:6 K</td>
<td class=kT>1:1 K</td>
<td class=kL>2:4 K</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kT>4:4 K</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kW>3:1</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=br>37:84</td><td class=br>-47</td>
<td class=bc>2 - 6 - 15</td>
<td class=br><strong>10</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ar Stolyarov</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Mi Shashkov</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ne Skrlep</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ja Kubernát</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ja Kubernát</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ar Stolyarov</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Shashkov</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ne Skrlep</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Kubernát</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ar Stolyarov</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Mi Shashkov</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ne Skrlep</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Mi Shashkov</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ne Skrlep</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Ja Kubernát</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Ne Skrlep</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Shashkov</td><td class=bc>-</td><td class=bl>Ja Kubernát</td><td class=bc>7 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Pe Borsanyi</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Mi Shashkov</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ne Skrlep</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Ja Kubernát</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Mi Shashkov</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Ne Skrlep</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ja Kubernát</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Mi Shashkov</td><td class=bc>-</td><td class=bl>Ne Skrlep</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Ja Kubernát</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Pe Borsanyi</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ne Skrlep</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ja Kubernát</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Shashkov</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ne Skrlep</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ja Kubernát</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Shashkov</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Mi Shashkov</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ne Skrlep</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ja Kubernát</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ja Kubernát</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Shashkov</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ne Skrlep</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ar Stolyarov</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Mi Shashkov</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ja Kubernát</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Ne Skrlep</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ne Skrlep</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Ja Kubernát</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ar Stolyarov</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Mi Shashkov</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Ar Stolyarov</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Mi Shashkov</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ne Skrlep</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ja Kubernát</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ar Stolyarov</td><td class=bc>-</td><td class=blW>Mi Shashkov</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ne Skrlep</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ja Kubernát</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>4 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
