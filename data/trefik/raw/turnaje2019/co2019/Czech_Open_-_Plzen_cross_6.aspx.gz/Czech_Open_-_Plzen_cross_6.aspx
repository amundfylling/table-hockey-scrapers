<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open - Plzeň</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.stolnihokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="../../pohar.aspx">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2019">Czech Open - Plzeň </a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 6</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Mi Shashkov</td><td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=br>58:28</td><td class=br>+30</td>
<td class=bc>12 - 3 - 0</td>
<td class=br><strong>27</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Dm Petrov</td><td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>5:4</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kW>11:2</td>
<td class=kW>8:0</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>8:0</td>
<td class=kW>10:2</td>
<td class=br>88:26</td><td class=br>+62</td>
<td class=bc>13 - 0 - 2</td>
<td class=br><strong>26</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>To Kahoun ml.</td><td class=kT>2:2</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>0:7</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>7:2</td>
<td class=br>58:36</td><td class=br>+22</td>
<td class=bc>11 - 2 - 2</td>
<td class=br><strong>24</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>St Kraus</td><td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>4:7</td>
<td class=kW>5:4</td>
<td class=kW>6:1</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kW>8:1</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=kW>9:0</td>
<td class=br>76:36</td><td class=br>+40</td>
<td class=bc>10 - 1 - 4</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>An Bozic</td><td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kW>7:0</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>7:2</td>
<td class=kL>4:5</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>7:3</td>
<td class=br>60:31</td><td class=br>+29</td>
<td class=bc>9 - 2 - 4</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Zd Lopaur</td><td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kW>7:4</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kL>2:5</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=kW>9:1</td>
<td class=br>55:33</td><td class=br>+22</td>
<td class=bc>9 - 1 - 5</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ma Ženíšek</td><td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kL>2:6</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kW>8:0</td>
<td class=kL>2:4</td>
<td class=kW>7:3</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=br>65:41</td><td class=br>+24</td>
<td class=bc>9 - 0 - 6</td>
<td class=br><strong>18</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Mi Mašika</td><td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>8:1</td>
<td class=br>41:33</td><td class=br>+8</td>
<td class=bc>7 - 4 - 4</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Vá Pikl</td><td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>2:7</td>
<td class=kW>3:1</td>
<td class=kL>3:7</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kW>8:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>9:1</td>
<td class=br>55:43</td><td class=br>+12</td>
<td class=bc>8 - 1 - 6</td>
<td class=br><strong>17</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>To Kahoun st.</td><td class=kL>2:6</td>
<td class=kL>2:11</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kW>5:4</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kT>0:0</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=br>44:47</td><td class=br>-3</td>
<td class=bc>7 - 1 - 7</td>
<td class=br><strong>15</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Mi Uhlíř</td><td class=kL>3:5</td>
<td class=kL>0:8</td>
<td class=kL>3:4</td>
<td class=kL>1:8</td>
<td class=kL>2:5</td>
<td class=kW>5:2</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>6:5</td>
<td class=kL>2:5</td>
<td class=kW>9:2</td>
<td class=kW>8:0</td>
<td class=br>51:64</td><td class=br>-13</td>
<td class=bc>5 - 0 - 10</td>
<td class=br><strong>10</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ma Klazar</td><td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=br>27:62</td><td class=br>-35</td>
<td class=bc>4 - 0 - 11</td>
<td class=br><strong>8</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Fr Rasche</td><td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kL>1:8</td>
<td class=kL>2:5</td>
<td class=kL>5:6</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>8:2</td>
<td class=br>40:59</td><td class=br>-19</td>
<td class=bc>4 - 0 - 11</td>
<td class=br><strong>8</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Pe Holub</td><td class=kL>3:5</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>3:7</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kT>0:0</td>
<td class=kW>5:2</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>8:1</td>
<td class=kW>6:0</td>
<td class=br>34:55</td><td class=br>-21</td>
<td class=bc>3 - 1 - 11</td>
<td class=br><strong>7</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Mi Rohla</td><td class=kL>0:4</td>
<td class=kL>0:8</td>
<td class=kL>2:5</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kL>1:7</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>2:9</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>1:8</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=br>16:87</td><td class=br>-71</td>
<td class=bc>0 - 1 - 14</td>
<td class=br><strong>1</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>To Rybák</td><td class=kL>2:5</td>
<td class=kL>2:10</td>
<td class=kL>2:7</td>
<td class=kL>0:9</td>
<td class=kL>3:7</td>
<td class=kL>1:9</td>
<td class=kL>1:5</td>
<td class=kL>1:8</td>
<td class=kL>1:9</td>
<td class=kL>0:6</td>
<td class=kL>0:8</td>
<td class=kL>1:6</td>
<td class=kL>2:8</td>
<td class=kL>0:6</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=br>20:107</td><td class=br>-87</td>
<td class=bc>0 - 1 - 14</td>
<td class=br><strong>1</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Mi Shashkov</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>To Rybák</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Mi Rohla</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=bl>Mi Shashkov</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>To Rybák</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Mi Rohla</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Mi Shashkov</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>To Rybák</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Mi Rohla</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Fr Rasche</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>2 : 11</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>4 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Mi Shashkov</td><td class=bc>-</td><td class=bl>To Rybák</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Mi Rohla</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Fr Rasche</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>To Rybák</td><td class=bc>-</td><td class=bl>Mi Rohla</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Mi Shashkov</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Mi Rohla</td><td class=bc>-</td><td class=blW>Fr Rasche</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>To Rybák</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Mi Shashkov</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Mi Rohla</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>To Rybák</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Mi Shashkov</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Mi Rohla</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>To Rybák</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Mi Shashkov</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Rohla</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>To Rybák</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Mi Shashkov</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Rohla</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>To Rybák</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Mi Shashkov</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Mi Mašika</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Rohla</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>To Rybák</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Mi Shashkov</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Mašika</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Mi Rohla</td><td class=bc>-</td><td class=blW>Mi Shashkov</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>To Rybák</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Mi Shashkov</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Fr Rasche</td><td class=bc>-</td><td class=bl>To Rybák</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Mi Rohla</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Mi Shashkov</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>To Rybák</td><td class=bc>10 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Mi Rohla</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=bl>Mi Shashkov</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>To Rybák</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Mi Mašika</td><td class=bc>-</td><td class=bl>Mi Rohla</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Mi Shashkov</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>To Rybák</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Mi Rohla</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
