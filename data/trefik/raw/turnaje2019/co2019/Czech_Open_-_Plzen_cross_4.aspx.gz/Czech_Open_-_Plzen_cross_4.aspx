<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open - Plzeň</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.stolnihokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="../../pohar.aspx">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2019">Czech Open - Plzeň </a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 4</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Le Hvižď ml.</td><td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>12:1</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=kW>11:0</td>
<td class=kW>4:0</td>
<td class=br>83:16</td><td class=br>+67</td>
<td class=bc>15 - 0 - 0</td>
<td class=br><strong>30</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Da Šmíd</td><td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>6:7</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>8:2</td>
<td class=kW>7:1</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=br>68:32</td><td class=br>+36</td>
<td class=bc>12 - 1 - 2</td>
<td class=br><strong>25</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ji Chylík ml.</td><td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kT>5:5</td>
<td class=kW>2:1</td>
<td class=kW>9:1</td>
<td class=kW>7:4</td>
<td class=kW>7:2</td>
<td class=br>67:30</td><td class=br>+37</td>
<td class=bc>11 - 1 - 3</td>
<td class=br><strong>23</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Pe Borsanyi</td><td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kT>5:5</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=br>53:37</td><td class=br>+16</td>
<td class=bc>9 - 2 - 4</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ja Matýsek</td><td class=kL>2:7</td>
<td class=kW>7:6</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>9:2</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>7:2</td>
<td class=kW>13:1</td>
<td class=kW>6:0</td>
<td class=kW>9:0</td>
<td class=br>73:40</td><td class=br>+33</td>
<td class=bc>10 - 0 - 5</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Mi Blažek</td><td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>5:4</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=br>46:36</td><td class=br>+10</td>
<td class=bc>9 - 1 - 5</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>To Bucek</td><td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kT>5:5</td>
<td class=kL>2:5</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>6:5</td>
<td class=kW>8:1</td>
<td class=kW>6:0</td>
<td class=kW>12:0</td>
<td class=br>66:33</td><td class=br>+33</td>
<td class=bc>9 - 1 - 5</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>My Shalomayev</td><td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>13:0</td>
<td class=kW>8:0</td>
<td class=kW>13:2</td>
<td class=kW>12:2</td>
<td class=br>76:31</td><td class=br>+45</td>
<td class=bc>9 - 0 - 6</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Zd Matoušek st.</td><td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>9:2</td>
<td class=kW>8:1</td>
<td class=br>48:36</td><td class=br>+12</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ra Bidlo</td><td class=kL>1:12</td>
<td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kL>2:9</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kL>1:7</td>
<td class=kW>4:2</td>
<td class=kW>5:4</td>
<td class=kW>5:2</td>
<td class=br>40:72</td><td class=br>-32</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Al Mačynský</td><td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>8:1</td>
<td class=kW>7:1</td>
<td class=kW>8:1</td>
<td class=br>38:39</td><td class=br>-1</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Mi Lévy</td><td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kT>5:5</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kL>4:5</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>7:3</td>
<td class=kW>8:1</td>
<td class=br>42:49</td><td class=br>-7</td>
<td class=bc>4 - 3 - 8</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Wo Abshagen</td><td class=kL>1:4</td>
<td class=kL>2:8</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>3:4</td>
<td class=kL>5:6</td>
<td class=kL>0:13</td>
<td class=kL>2:3</td>
<td class=kW>7:1</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=br>39:63</td><td class=br>-24</td>
<td class=bc>4 - 1 - 10</td>
<td class=br><strong>9</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ra Hrnčíř</td><td class=kL>0:8</td>
<td class=kL>1:7</td>
<td class=kL>1:9</td>
<td class=kL>1:6</td>
<td class=kL>1:13</td>
<td class=kL>0:5</td>
<td class=kL>1:8</td>
<td class=kL>0:8</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:8</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>8:6</td>
<td class=kW>3:2</td>
<td class=br>24:95</td><td class=br>-71</td>
<td class=bc>2 - 0 - 13</td>
<td class=br><strong>4</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Mi Horáková</td><td class=kL>0:11</td>
<td class=kL>1:6</td>
<td class=kL>4:7</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>2:13</td>
<td class=kL>2:9</td>
<td class=kL>4:5</td>
<td class=kL>1:7</td>
<td class=kL>3:7</td>
<td class=kL>3:4</td>
<td class=kL>6:8</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=br>33:101</td><td class=br>-68</td>
<td class=bc>1 - 0 - 14</td>
<td class=br><strong>2</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Ro Prauda</td><td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>2:7</td>
<td class=kL>0:3</td>
<td class=kL>0:9</td>
<td class=kL>0:6</td>
<td class=kL>0:12</td>
<td class=kL>2:12</td>
<td class=kL>1:8</td>
<td class=kL>2:5</td>
<td class=kL>1:8</td>
<td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=br>15:101</td><td class=br>-86</td>
<td class=bc>0 - 0 - 15</td>
<td class=br><strong>0</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Ro Prauda</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Wo Abshagen</td><td class=bc>-</td><td class=bl>Ro Prauda</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Ro Prauda</td><td class=bc>12 : 2</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>6 : 7</tr></td>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>6 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ro Prauda</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ro Prauda</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ra Bidlo</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ro Prauda</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Wo Abshagen</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Pe Borsanyi</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ro Prauda</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>13 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=blW>Pe Borsanyi</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ro Prauda</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 12</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Pe Borsanyi</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Wo Abshagen</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ro Prauda</td><td class=bc>-</td><td class=blW>Ra Bidlo</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>13 : 0</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>11 : 0</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Pe Borsanyi</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ro Prauda</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Ra Bidlo</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ro Prauda</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Pe Borsanyi</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>12 : 1</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Ro Prauda</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ra Bidlo</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Wo Abshagen</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Ro Prauda</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=blW>Ra Bidlo</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ro Prauda</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Ro Prauda</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 13</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Ro Prauda</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
