<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open - Plzeň</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.stolnihokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="../../pohar.aspx">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2019">Czech Open - Plzeň </a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group D</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt>Ka Stařecká</td><td class=kx>*</td>
<td class=kT>1:1 + 2:1</td>
<td class=kL>2:5 + 1:1</td>
<td class=kL>0:3 + 4:3</td>
<td class=kW>3:1 + 3:3</td>
<td class=kW>4:0 + 1:2</td>
<td class=kW>1:0 + 6:1</td>
<td class=kW>5:2 + 3:2</td>
<td class=kW>3:1 + 2:1</td>
<td class=br>41:27</td><td class=br>+14</td>
<td class=bc>10 - 3 - 3</td>
<td class=br><strong>23</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt>To Rybák</td><td class=kT>1:1 + 1:2</td>
<td class=kx>*</td>
<td class=kL>3:6 + 3:8</td>
<td class=kT>1:1 + 2:1</td>
<td class=kW>5:4 + 4:2</td>
<td class=kW>2:1 + 1:0</td>
<td class=kW>2:1 + 5:0</td>
<td class=kW>6:1 + 3:3</td>
<td class=kW>4:3 + 4:3</td>
<td class=br>47:37</td><td class=br>+10</td>
<td class=bc>10 - 3 - 3</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt>Mi Horáková</td><td class=kW>5:2 + 1:1</td>
<td class=kW>6:3 + 8:3</td>
<td class=kx>*</td>
<td class=kT>1:1 + 2:1</td>
<td class=kT>4:4 + 2:6</td>
<td class=kL>1:5 + 0:1</td>
<td class=kW>4:2 + 4:5</td>
<td class=kW>4:2 + 5:3</td>
<td class=kW>1:0 + 5:2</td>
<td class=br>53:41</td><td class=br>+12</td>
<td class=bc>9 - 3 - 4</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt>Ma Cingroš</td><td class=kW>3:0 + 3:4</td>
<td class=kT>1:1 + 1:2</td>
<td class=kT>1:1 + 1:2</td>
<td class=kx>*</td>
<td class=kW>2:1 + 2:4</td>
<td class=kT>1:1 + 1:2</td>
<td class=kW>4:2 + 2:2</td>
<td class=kW>7:3 + 9:1</td>
<td class=kW>5:1 + 4:1</td>
<td class=br>47:28</td><td class=br>+19</td>
<td class=bc>7 - 4 - 5</td>
<td class=br><strong>18</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ja Saj</td><td class=kL>1:3 + 3:3</td>
<td class=kL>4:5 + 2:4</td>
<td class=kT>4:4 + 6:2</td>
<td class=kL>1:2 + 4:2</td>
<td class=kx>*</td>
<td class=kL>0:1 + 1:1</td>
<td class=kW>7:2 + 1:1</td>
<td class=kW>5:1 + 4:1</td>
<td class=kW>3:1 + 1:1</td>
<td class=br>47:34</td><td class=br>+13</td>
<td class=bc>6 - 5 - 5</td>
<td class=br><strong>17</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Ka Šurýnová</td><td class=kL>0:4 + 2:1</td>
<td class=kL>1:2 + 0:1</td>
<td class=kW>5:1 + 1:0</td>
<td class=kT>1:1 + 2:1</td>
<td class=kW>1:0 + 1:1</td>
<td class=kx>*</td>
<td class=kL>2:3 + 2:0</td>
<td class=kT>1:1 + 1:2</td>
<td class=kT>0:0 + 0:4</td>
<td class=br>20:22</td><td class=br>-2</td>
<td class=bc>6 - 4 - 6</td>
<td class=br><strong>16</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Mi Rohla</td><td class=kL>0:1 + 1:6</td>
<td class=kL>1:2 + 0:5</td>
<td class=kL>2:4 + 5:4</td>
<td class=kL>2:4 + 2:2</td>
<td class=kL>2:7 + 1:1</td>
<td class=kW>3:2 + 0:2</td>
<td class=kx>*</td>
<td class=kT>3:3 + 2:0</td>
<td class=kW>3:2 + 3:3</td>
<td class=br>30:48</td><td class=br>-18</td>
<td class=bc>4 - 4 - 8</td>
<td class=br><strong>12</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ro Prauda</td><td class=kL>2:5 + 2:3</td>
<td class=kL>1:6 + 3:3</td>
<td class=kL>2:4 + 3:5</td>
<td class=kL>3:7 + 1:9</td>
<td class=kL>1:5 + 1:4</td>
<td class=kT>1:1 + 2:1</td>
<td class=kT>3:3 + 0:2</td>
<td class=kx>*</td>
<td class=kL>2:3 + 2:0</td>
<td class=br>29:61</td><td class=br>-32</td>
<td class=bc>2 - 3 - 11</td>
<td class=br><strong>7</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Fi Werner</td><td class=kL>1:3 + 1:2</td>
<td class=kL>3:4 + 3:4</td>
<td class=kL>0:1 + 2:5</td>
<td class=kL>1:5 + 1:4</td>
<td class=kL>1:3 + 1:1</td>
<td class=kT>0:0 + 4:0</td>
<td class=kL>2:3 + 3:3</td>
<td class=kW>3:2 + 0:2</td>
<td class=kx>*</td>
<td class=br>26:42</td><td class=br>-16</td>
<td class=bc>2 - 3 - 11</td>
<td class=br><strong>7</strong></td><td class=d>9.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=bl>To Rybák</td><td class=bc>1 : 1 + 2 : 1</tr></td>
<tr><td class=brW>Ma Cingroš</td><td class=bc>-</td><td class=bl>Fi Werner</td><td class=bc>5 : 1 + 4 : 1</tr></td>
<tr><td class=br>Ka Šurýnová</td><td class=bc>-</td><td class=bl>Ro Prauda</td><td class=bc>1 : 1 + 1 : 2</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Mi Rohla</td><td class=bc>4 : 2 + 4 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>To Rybák</td><td class=bc>-</td><td class=bl>Fi Werner</td><td class=bc>4 : 3 + 4 : 3</tr></td>
<tr><td class=brW>Ka Stařecká</td><td class=bc>-</td><td class=bl>Ro Prauda</td><td class=bc>5 : 2 + 3 : 2</tr></td>
<tr><td class=brW>Ma Cingroš</td><td class=bc>-</td><td class=bl>Mi Rohla</td><td class=bc>4 : 2 + 2 : 2</tr></td>
<tr><td class=brW>Ka Šurýnová</td><td class=bc>-</td><td class=bl>Ja Saj</td><td class=bc>1 : 0 + 1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Fi Werner</td><td class=bc>-</td><td class=bl>Ro Prauda</td><td class=bc>3 : 2 + 0 : 2</tr></td>
<tr><td class=brW>To Rybák</td><td class=bc>-</td><td class=bl>Mi Rohla</td><td class=bc>2 : 1 + 5 : 0</tr></td>
<tr><td class=brW>Ka Stařecká</td><td class=bc>-</td><td class=bl>Ja Saj</td><td class=bc>3 : 1 + 3 : 3</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>1 : 1 + 1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ro Prauda</td><td class=bc>-</td><td class=bl>Mi Rohla</td><td class=bc>3 : 3 + 0 : 2</tr></td>
<tr><td class=br>Fi Werner</td><td class=bc>-</td><td class=blW>Ja Saj</td><td class=bc>1 : 3 + 1 : 1</tr></td>
<tr><td class=br>To Rybák</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>3 : 6 + 3 : 8</tr></td>
<tr><td class=brW>Ka Stařecká</td><td class=bc>-</td><td class=bl>Ka Šurýnová</td><td class=bc>4 : 0 + 1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Mi Rohla</td><td class=bc>-</td><td class=blW>Ja Saj</td><td class=bc>2 : 7 + 1 : 1</tr></td>
<tr><td class=br>Ro Prauda</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>2 : 4 + 3 : 5</tr></td>
<tr><td class=br>Fi Werner</td><td class=bc>-</td><td class=bl>Ka Šurýnová</td><td class=bc>0 : 0 + 4 : 0</tr></td>
<tr><td class=br>To Rybák</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>1 : 1 + 2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ja Saj</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 4 + 6 : 2</tr></td>
<tr><td class=brW>Mi Rohla</td><td class=bc>-</td><td class=bl>Ka Šurýnová</td><td class=bc>3 : 2 + 0 : 2</tr></td>
<tr><td class=br>Ro Prauda</td><td class=bc>-</td><td class=blW>Ma Cingroš</td><td class=bc>3 : 7 + 1 : 9</tr></td>
<tr><td class=br>Fi Werner</td><td class=bc>-</td><td class=blW>Ka Stařecká</td><td class=bc>1 : 3 + 1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ka Šurýnová</td><td class=bc>1 : 5 + 0 : 1</tr></td>
<tr><td class=br>Ja Saj</td><td class=bc>-</td><td class=blW>Ma Cingroš</td><td class=bc>1 : 2 + 4 : 2</tr></td>
<tr><td class=br>Mi Rohla</td><td class=bc>-</td><td class=blW>Ka Stařecká</td><td class=bc>0 : 1 + 1 : 6</tr></td>
<tr><td class=br>Ro Prauda</td><td class=bc>-</td><td class=blW>To Rybák</td><td class=bc>1 : 6 + 3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ka Šurýnová</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>1 : 1 + 2 : 1</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>5 : 2 + 1 : 1</tr></td>
<tr><td class=br>Ja Saj</td><td class=bc>-</td><td class=blW>To Rybák</td><td class=bc>4 : 5 + 2 : 4</tr></td>
<tr><td class=brW>Mi Rohla</td><td class=bc>-</td><td class=bl>Fi Werner</td><td class=bc>3 : 2 + 3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ma Cingroš</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>3 : 0 + 3 : 4</tr></td>
<tr><td class=br>Ka Šurýnová</td><td class=bc>-</td><td class=blW>To Rybák</td><td class=bc>1 : 2 + 0 : 1</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Fi Werner</td><td class=bc>1 : 0 + 5 : 2</tr></td>
<tr><td class=brW>Ja Saj</td><td class=bc>-</td><td class=bl>Ro Prauda</td><td class=bc>5 : 1 + 4 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
