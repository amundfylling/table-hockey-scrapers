<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open - Plzeň</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.stolnihokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="../../pohar.aspx">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2019">Czech Open - Plzeň </a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt>Vl Gobyová</td><td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>7:3</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>6:2</td>
<td class=br>72:32</td><td class=br>+40</td>
<td class=bc>14 - 1 - 2</td>
<td class=br><strong>29</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt>Ví Perkner</td><td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>5:1</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>8:1</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=br>69:34</td><td class=br>+35</td>
<td class=bc>12 - 1 - 4</td>
<td class=br><strong>25</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt>Vi Velič</td><td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kW>6:1</td>
<td class=kW>7:3</td>
<td class=kW>7:0</td>
<td class=br>72:44</td><td class=br>+28</td>
<td class=bc>11 - 2 - 4</td>
<td class=br><strong>24</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt>Mi Lévy</td><td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>7:1</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kT>0:0</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=br>67:36</td><td class=br>+31</td>
<td class=bc>10 - 4 - 3</td>
<td class=br><strong>24</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Pa Pohořalý</td><td class=kL>3:5</td>
<td class=kW>5:3</td>
<td class=kL>3:6</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=br>62:42</td><td class=br>+20</td>
<td class=bc>12 - 0 - 5</td>
<td class=br><strong>24</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>An Naszádi</td><td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>1:7</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kW>5:4</td>
<td class=kL>1:2</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>2:0</td>
<td class=br>54:45</td><td class=br>+9</td>
<td class=bc>9 - 3 - 5</td>
<td class=br><strong>21</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Ol Majaniemi</td><td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kW>6:3</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=br>56:46</td><td class=br>+10</td>
<td class=bc>8 - 3 - 6</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ma Klazar</td><td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>0:6</td>
<td class=kL>4:7</td>
<td class=kW>4:1</td>
<td class=kL>3:6</td>
<td class=kW>7:1</td>
<td class=kW>7:4</td>
<td class=kW>6:0</td>
<td class=kW>6:2</td>
<td class=kW>7:2</td>
<td class=br>60:54</td><td class=br>+6</td>
<td class=bc>9 - 1 - 7</td>
<td class=br><strong>19</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Pe Holub</td><td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kW>5:1</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=br>44:42</td><td class=br>+2</td>
<td class=bc>9 - 1 - 7</td>
<td class=br><strong>19</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Al Krejza</td><td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kW>6:0</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>8:2</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=br>59:45</td><td class=br>+14</td>
<td class=bc>8 - 2 - 7</td>
<td class=br><strong>18</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Fr Rasche</td><td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kW>7:4</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=br>55:50</td><td class=br>+5</td>
<td class=bc>7 - 4 - 6</td>
<td class=br><strong>18</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ji Malík</td><td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kW>4:2</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>1:0</td>
<td class=kW>1:0</td>
<td class=br>40:46</td><td class=br>-6</td>
<td class=bc>8 - 2 - 7</td>
<td class=br><strong>18</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>An Grimová</td><td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kW>6:3</td>
<td class=kL>2:4</td>
<td class=kL>2:8</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>6:4</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=br>51:70</td><td class=br>-19</td>
<td class=bc>6 - 1 - 10</td>
<td class=br><strong>13</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Jo Perkner</td><td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=br>31:54</td><td class=br>-23</td>
<td class=bc>5 - 1 - 11</td>
<td class=br><strong>11</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Wo Abshagen</td><td class=kL>3:7</td>
<td class=kL>2:5</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>3:6</td>
<td class=kL>4:7</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>4:6</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>6:1</td>
<td class=br>52:62</td><td class=br>-10</td>
<td class=bc>5 - 1 - 11</td>
<td class=br><strong>11</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Da Kadlec</td><td class=kL>1:3</td>
<td class=kL>1:8</td>
<td class=kL>1:6</td>
<td class=kT>0:0</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=br>19:61</td><td class=br>-42</td>
<td class=bc>2 - 3 - 12</td>
<td class=br><strong>7</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Si Culic</td><td class=kL>3:5</td>
<td class=kL>0:5</td>
<td class=kL>3:7</td>
<td class=kL>2:7</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=br>30:71</td><td class=br>-41</td>
<td class=bc>2 - 1 - 14</td>
<td class=br><strong>5</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Ra Hrnčíř</td><td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kL>0:2</td>
<td class=kL>0:7</td>
<td class=kL>2:6</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=br>14:73</td><td class=br>-59</td>
<td class=bc>0 - 1 - 16</td>
<td class=br><strong>1</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Vi Velič</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>An Naszádi</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ol Majaniemi</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Vi Velič</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Fr Rasche</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ji Malík</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>An Naszádi</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Vi Velič</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ví Perkner</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>An Naszádi</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vi Velič</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ol Majaniemi</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Ví Perkner</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Da Kadlec</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Si Culic</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>An Naszádi</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vi Velič</td><td class=bc>-</td><td class=blW>Wo Abshagen</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ol Majaniemi</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Ji Malík</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Fr Rasche</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>An Naszádi</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Ví Perkner</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Vi Velič</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Wo Abshagen</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ví Perkner</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vi Velič</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Wo Abshagen</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ji Malík</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>An Naszádi</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Vi Velič</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Fr Rasche</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Ol Majaniemi</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Vi Velič</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ji Malík</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Fr Rasche</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Ol Majaniemi</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Pa Pohořalý</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=bl>Vi Velič</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Ol Majaniemi</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Pa Pohořalý</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Vi Velič</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ol Majaniemi</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>Pa Pohořalý</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Vi Velič</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>An Naszádi</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ji Malík</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=blW>Pa Pohořalý</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Vi Velič</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Fr Rasche</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>An Naszádi</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Ol Majaniemi</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Vi Velič</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>An Naszádi</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Fr Rasche</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Si Culic</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Vi Velič</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Wo Abshagen</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Vi Velič</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ji Malík</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Wo Abshagen</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>Vi Velič</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ji Malík</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=blW>Fr Rasche</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Da Kadlec</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ji Malík</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
