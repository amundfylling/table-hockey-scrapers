<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open - Plzeň</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.stolnihokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="../../pohar.aspx">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2019">Czech Open - Plzeň </a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt>Ma Papp</td><td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>6:3</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=br>63:39</td><td class=br>+24</td>
<td class=bc>13 - 2 - 2</td>
<td class=br><strong>28</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt>Zd Matoušek st.</td><td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>5:4</td>
<td class=kW>2:0</td>
<td class=kW>6:4</td>
<td class=kW>4:0</td>
<td class=kW>7:4</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=br>60:38</td><td class=br>+22</td>
<td class=bc>11 - 4 - 2</td>
<td class=br><strong>26</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt>St Srba</td><td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=br>57:34</td><td class=br>+23</td>
<td class=bc>11 - 3 - 3</td>
<td class=br><strong>25</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt>Ra Pommerenke</td><td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kW>4:2</td>
<td class=kW>5:4</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>7:2</td>
<td class=kT>4:4</td>
<td class=br>46:34</td><td class=br>+12</td>
<td class=bc>10 - 3 - 4</td>
<td class=br><strong>23</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Al Mačynský</td><td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=br>43:37</td><td class=br>+6</td>
<td class=bc>9 - 4 - 4</td>
<td class=br><strong>22</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>To Kahoun st.</td><td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kL>3:5</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=br>48:34</td><td class=br>+14</td>
<td class=bc>10 - 1 - 6</td>
<td class=br><strong>21</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Vá Pikl</td><td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kW>8:3</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kW>7:1</td>
<td class=kW>3:2</td>
<td class=br>62:46</td><td class=br>+16</td>
<td class=bc>8 - 3 - 6</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>He Petuch</td><td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kT>5:5</td>
<td class=kW>6:2</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=br>42:44</td><td class=br>-2</td>
<td class=bc>6 - 5 - 6</td>
<td class=br><strong>17</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Hy Nechutný</td><td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>3:0</td>
<td class=br>38:28</td><td class=br>+10</td>
<td class=bc>8 - 1 - 8</td>
<td class=br><strong>17</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Mi Uhlíř</td><td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kT>5:5</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kW>5:3</td>
<td class=kL>5:6</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kW>7:3</td>
<td class=br>58:56</td><td class=br>+2</td>
<td class=bc>6 - 3 - 8</td>
<td class=br><strong>15</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Vo Bernát</td><td class=kT>4:4</td>
<td class=kL>4:5</td>
<td class=kL>0:4</td>
<td class=kL>4:5</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>5:4</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>5:4</td>
<td class=br>52:63</td><td class=br>-11</td>
<td class=bc>6 - 2 - 9</td>
<td class=br><strong>14</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Fr Marek</td><td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kW>6:4</td>
<td class=kW>4:3</td>
<td class=kW>7:2</td>
<td class=br>41:46</td><td class=br>-5</td>
<td class=bc>7 - 0 - 10</td>
<td class=br><strong>14</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Pa Hráský</td><td class=kL>3:6</td>
<td class=kL>4:6</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>1:5</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=br>38:54</td><td class=br>-16</td>
<td class=bc>6 - 2 - 9</td>
<td class=br><strong>14</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Lu Příhoda</td><td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kL>3:8</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kL>4:5</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=br>42:61</td><td class=br>-19</td>
<td class=bc>5 - 2 - 10</td>
<td class=br><strong>12</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Pa Kubrt</td><td class=kL>2:3</td>
<td class=kL>4:7</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kW>6:5</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=br>42:54</td><td class=br>-12</td>
<td class=bc>6 - 0 - 11</td>
<td class=br><strong>12</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Jo Sedláček</td><td class=kL>3:7</td>
<td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>4:6</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>8:0</td>
<td class=kW>4:1</td>
<td class=br>51:58</td><td class=br>-7</td>
<td class=bc>4 - 3 - 10</td>
<td class=br><strong>11</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ra Bidlo</td><td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kW>5:3</td>
<td class=kL>2:7</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>0:8</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=br>36:66</td><td class=br>-30</td>
<td class=bc>3 - 3 - 11</td>
<td class=br><strong>9</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Iv Mašková</td><td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>3:7</td>
<td class=kL>4:5</td>
<td class=kL>2:7</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=br>37:64</td><td class=br>-27</td>
<td class=bc>0 - 7 - 10</td>
<td class=br><strong>7</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>Lu Příhoda</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Lu Příhoda</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Lu Příhoda</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Lu Příhoda</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Ra Bidlo</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Lu Příhoda</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Pa Kubrt</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Lu Příhoda</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Pa Kubrt</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Ma Papp</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Lu Příhoda</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ma Papp</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>4 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Lu Příhoda</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Ma Papp</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Lu Příhoda</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Ma Papp</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Pa Hráský</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Pa Kubrt</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Lu Příhoda</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Lu Příhoda</td><td class=bc>-</td><td class=blW>Ma Papp</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Pa Kubrt</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Lu Příhoda</td><td class=bc>-</td><td class=blW>Pa Hráský</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ma Papp</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Lu Příhoda</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Pa Kubrt</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ra Bidlo</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Lu Příhoda</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Pa Kubrt</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Lu Příhoda</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ra Bidlo</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Lu Příhoda</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Lu Příhoda</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Lu Příhoda</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
