<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open - Plzeň</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.stolnihokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="../../pohar.aspx">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2019">Czech Open - Plzeň </a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Kr Herold</td><td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>1:6</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>54:25</td><td class=br>+29</td>
<td class=bc>12 - 0 - 2</td>
<td class=br><strong>24</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Mi Kobrle</td><td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>6:4</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kL>1:4</td>
<td class=br>54:32</td><td class=br>+22</td>
<td class=bc>10 - 3 - 1</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ma Maděra</td><td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>6:1</td>
<td class=kW>5:4</td>
<td class=kW>5:3</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=br>61:32</td><td class=br>+29</td>
<td class=bc>11 - 0 - 3</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Pa Petr</td><td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>4:6</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kL>3:9</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=br>59:34</td><td class=br>+25</td>
<td class=bc>10 - 1 - 3</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ro Jež</td><td class=kW>6:1</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>8:1</td>
<td class=kW>10:1</td>
<td class=br>57:25</td><td class=br>+32</td>
<td class=bc>10 - 0 - 4</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Vl Kraus</td><td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kW>6:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=br>54:35</td><td class=br>+19</td>
<td class=bc>10 - 0 - 4</td>
<td class=br><strong>20</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Vi Magyari</td><td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=br>35:38</td><td class=br>-3</td>
<td class=bc>7 - 1 - 6</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Si Thomas</td><td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>9:0</td>
<td class=br>41:39</td><td class=br>+2</td>
<td class=bc>6 - 1 - 7</td>
<td class=br><strong>13</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Iv Mašková</td><td class=kL>0:3</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>7:4</td>
<td class=kL>0:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=br>35:38</td><td class=br>-3</td>
<td class=bc>5 - 2 - 7</td>
<td class=br><strong>12</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Hy Nechutný</td><td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>2:7</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=br>29:38</td><td class=br>-9</td>
<td class=bc>5 - 2 - 7</td>
<td class=br><strong>12</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Vo Bernát</td><td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>9:3</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=br>37:40</td><td class=br>-3</td>
<td class=bc>5 - 1 - 8</td>
<td class=br><strong>11</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Vi Velič</td><td class=kL>3:4</td>
<td class=kL>4:6</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>3:6</td>
<td class=kL>3:5</td>
<td class=kL>0:3</td>
<td class=kL>4:7</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=br>41:58</td><td class=br>-17</td>
<td class=bc>3 - 0 - 11</td>
<td class=br><strong>6</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ji Malík</td><td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=br>11:38</td><td class=br>-27</td>
<td class=bc>2 - 1 - 11</td>
<td class=br><strong>5</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Si Culic</td><td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>1:7</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>15:63</td><td class=br>-48</td>
<td class=bc>2 - 0 - 12</td>
<td class=br><strong>4</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ka Stařecká</td><td class=kL>0:5</td>
<td class=kW>4:1</td>
<td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kL>1:10</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>0:9</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>17:65</td><td class=br>-48</td>
<td class=bc>1 - 0 - 13</td>
<td class=br><strong>2</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Vi Velič</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Vi Velič</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Vi Magyari</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Vi Velič</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Vi Magyari</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vi Velič</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Vi Magyari</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vi Velič</td><td class=bc>-</td><td class=blW>Vi Magyari</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Vi Magyari</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Vi Velič</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Ji Malík</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Vi Magyari</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vi Velič</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Vi Magyari</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Vi Velič</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Si Culic</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>3 : 9</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Vi Velič</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Si Culic</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Vi Velič</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Vi Magyari</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Vi Velič</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Vi Velič</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ji Malík</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vi Velič</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Vi Velič</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ka Stařecká</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>2 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
