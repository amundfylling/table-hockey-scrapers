<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open - Plzeň</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.stolnihokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="../../pohar.aspx">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2019">Czech Open - Plzeň </a></span></h2></div></div></div></div><h3 align="right">Basic Groups&nbsp;&nbsp;</h3>
<p><div align="center">
<a href="Czech_Open_-_Plzen_krizF.aspx#final">Final Groups</a><br>
<a href="Czech_Open_-_Plzen_umisteni.aspx">Play-Off</a><br>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Kr Herold</td><td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>1:6</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>54:25</td><td class=br>+29</td>
<td class=bc>12 - 0 - 2</td>
<td class=br><strong>24</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Mi Kobrle</td><td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>6:4</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kL>1:4</td>
<td class=br>54:32</td><td class=br>+22</td>
<td class=bc>10 - 3 - 1</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ma Maděra</td><td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>6:1</td>
<td class=kW>5:4</td>
<td class=kW>5:3</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=br>61:32</td><td class=br>+29</td>
<td class=bc>11 - 0 - 3</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Pa Petr</td><td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>4:6</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kL>3:9</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=br>59:34</td><td class=br>+25</td>
<td class=bc>10 - 1 - 3</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ro Jež</td><td class=kW>6:1</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>8:1</td>
<td class=kW>10:1</td>
<td class=br>57:25</td><td class=br>+32</td>
<td class=bc>10 - 0 - 4</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Vl Kraus</td><td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kW>6:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=br>54:35</td><td class=br>+19</td>
<td class=bc>10 - 0 - 4</td>
<td class=br><strong>20</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Vi Magyari</td><td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=br>35:38</td><td class=br>-3</td>
<td class=bc>7 - 1 - 6</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Si Thomas</td><td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>9:0</td>
<td class=br>41:39</td><td class=br>+2</td>
<td class=bc>6 - 1 - 7</td>
<td class=br><strong>13</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Iv Mašková</td><td class=kL>0:3</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>7:4</td>
<td class=kL>0:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=br>35:38</td><td class=br>-3</td>
<td class=bc>5 - 2 - 7</td>
<td class=br><strong>12</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Hy Nechutný</td><td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>2:7</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=br>29:38</td><td class=br>-9</td>
<td class=bc>5 - 2 - 7</td>
<td class=br><strong>12</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Vo Bernát</td><td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>9:3</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=br>37:40</td><td class=br>-3</td>
<td class=bc>5 - 1 - 8</td>
<td class=br><strong>11</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Vi Velič</td><td class=kL>3:4</td>
<td class=kL>4:6</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>3:6</td>
<td class=kL>3:5</td>
<td class=kL>0:3</td>
<td class=kL>4:7</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=br>41:58</td><td class=br>-17</td>
<td class=bc>3 - 0 - 11</td>
<td class=br><strong>6</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ji Malík</td><td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=br>11:38</td><td class=br>-27</td>
<td class=bc>2 - 1 - 11</td>
<td class=br><strong>5</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Si Culic</td><td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>1:7</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>15:63</td><td class=br>-48</td>
<td class=bc>2 - 0 - 12</td>
<td class=br><strong>4</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ka Stařecká</td><td class=kL>0:5</td>
<td class=kW>4:1</td>
<td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kL>1:10</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>0:9</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>17:65</td><td class=br>-48</td>
<td class=bc>1 - 0 - 13</td>
<td class=br><strong>2</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Vi Velič</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Vi Velič</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Vi Magyari</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Vi Velič</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Vi Magyari</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vi Velič</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Vi Magyari</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vi Velič</td><td class=bc>-</td><td class=blW>Vi Magyari</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Vi Magyari</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Vi Velič</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Ji Malík</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Vi Magyari</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vi Velič</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Vi Magyari</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Vi Velič</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Si Culic</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>3 : 9</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Vi Velič</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Si Culic</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Vi Velič</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Vi Magyari</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Vi Velič</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Vi Velič</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ji Malík</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vi Velič</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Vi Velič</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ka Stařecká</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>2 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ar Stolyarov</td><td class=kx>*</td>
<td class=kW>7:2</td>
<td class=kT>1:1</td>
<td class=kW>7:4</td>
<td class=kW>9:2</td>
<td class=kW>8:4</td>
<td class=kW>8:3</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=kW>8:1</td>
<td class=kW>6:4</td>
<td class=kW>7:2</td>
<td class=kW>6:2</td>
<td class=br>91:32</td><td class=br>+59</td>
<td class=bc>13 - 1 - 0</td>
<td class=br><strong>27</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Mi Boštík</td><td class=kL>2:7</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kT>5:5</td>
<td class=kW>6:4</td>
<td class=kW>9:2</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>6:0</td>
<td class=kW>7:3</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=br>63:35</td><td class=br>+28</td>
<td class=bc>10 - 3 - 1</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ho Sládek</td><td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=kW>8:2</td>
<td class=kW>8:1</td>
<td class=br>58:19</td><td class=br>+39</td>
<td class=bc>9 - 4 - 1</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Pa Plešák</td><td class=kL>4:7</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>6:1</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>8:1</td>
<td class=kW>6:4</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=br>56:33</td><td class=br>+23</td>
<td class=bc>9 - 3 - 2</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ne Skrlep</td><td class=kL>2:9</td>
<td class=kT>5:5</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=br>52:38</td><td class=br>+14</td>
<td class=bc>9 - 3 - 2</td>
<td class=br><strong>21</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Da Dvořáček</td><td class=kL>4:8</td>
<td class=kL>4:6</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>6:4</td>
<td class=kW>3:1</td>
<td class=kL>3:6</td>
<td class=kW>7:2</td>
<td class=kW>7:3</td>
<td class=kW>7:3</td>
<td class=kW>9:1</td>
<td class=kW>10:2</td>
<td class=br>70:46</td><td class=br>+24</td>
<td class=bc>9 - 1 - 4</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>To Jedlička</td><td class=kL>3:8</td>
<td class=kL>2:9</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>2:5</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>7:2</td>
<td class=kW>9:1</td>
<td class=br>45:46</td><td class=br>-1</td>
<td class=bc>6 - 2 - 6</td>
<td class=br><strong>14</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ja Kubernát</td><td class=kL>2:7</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>4:6</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>40:40</td><td class=br>0</td>
<td class=bc>5 - 2 - 7</td>
<td class=br><strong>12</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Fr Marek</td><td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=br>26:30</td><td class=br>-4</td>
<td class=bc>5 - 2 - 7</td>
<td class=br><strong>12</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Pa Kubrt</td><td class=kL>2:7</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kW>6:3</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>9:1</td>
<td class=br>34:43</td><td class=br>-9</td>
<td class=bc>4 - 2 - 8</td>
<td class=br><strong>10</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>He Petuch</td><td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>7:0</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kW>6:4</td>
<td class=br>34:57</td><td class=br>-23</td>
<td class=bc>4 - 1 - 9</td>
<td class=br><strong>9</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Pa Pohořalý</td><td class=kL>1:8</td>
<td class=kL>3:7</td>
<td class=kL>2:6</td>
<td class=kL>1:8</td>
<td class=kL>3:4</td>
<td class=kL>3:7</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>0:7</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>3:7</td>
<td class=kW>5:2</td>
<td class=br>32:66</td><td class=br>-34</td>
<td class=bc>3 - 2 - 9</td>
<td class=br><strong>8</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Vl Gobyová</td><td class=kL>4:6</td>
<td class=kT>2:2</td>
<td class=kL>0:6</td>
<td class=kL>4:6</td>
<td class=kL>1:3</td>
<td class=kL>3:7</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=br>39:50</td><td class=br>-11</td>
<td class=bc>3 - 2 - 9</td>
<td class=br><strong>8</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Al Krejza</td><td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kL>2:8</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>1:9</td>
<td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>7:3</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=br>26:65</td><td class=br>-39</td>
<td class=bc>2 - 0 - 12</td>
<td class=br><strong>4</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ma Cingroš</td><td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>1:8</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>2:10</td>
<td class=kL>1:9</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:9</td>
<td class=kL>4:6</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=br>19:85</td><td class=br>-66</td>
<td class=bc>0 - 0 - 14</td>
<td class=br><strong>0</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Ne Skrlep</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Pa Pohořalý</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Kubernát</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ar Stolyarov</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Ne Skrlep</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Pa Pohořalý</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Pa Kubrt</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ne Skrlep</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ar Stolyarov</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>Ja Kubernát</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ne Skrlep</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ar Stolyarov</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Pa Kubrt</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Ja Kubernát</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Ne Skrlep</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ar Stolyarov</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ja Kubernát</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ne Skrlep</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ja Kubernát</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ar Stolyarov</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Ja Kubernát</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ne Skrlep</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ar Stolyarov</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>6 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Ja Kubernát</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ne Skrlep</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ar Stolyarov</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Pa Kubrt</td><td class=bc>-</td><td class=bl>Ja Kubernát</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Ne Skrlep</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ja Kubernát</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ne Skrlep</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>2 : 9</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Ja Kubernát</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pa Kubrt</td><td class=bc>-</td><td class=bl>Da Dvořáček</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Ja Kubernát</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Ne Skrlep</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Da Dvořáček</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ja Kubernát</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ne Skrlep</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Da Dvořáček</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>10 : 2</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Ja Kubernát</td><td class=bc>-</td><td class=bl>Ne Skrlep</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Da Dvořáček</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>4 : 8</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Ne Skrlep</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ja Kubernát</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>1 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 3</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ro Nuttunen</td><td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kL>1:4</td>
<td class=kW>5:4</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=kW>9:1</td>
<td class=br>62:13</td><td class=br>+49</td>
<td class=bc>12 - 1 - 1</td>
<td class=br><strong>25</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ja Dryák</td><td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kT>5:5</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=kW>5:3</td>
<td class=kW>9:2</td>
<td class=kW>6:3</td>
<td class=kW>7:0</td>
<td class=br>66:27</td><td class=br>+39</td>
<td class=bc>10 - 3 - 1</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Mi Borgh</td><td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>8:1</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=br>55:26</td><td class=br>+29</td>
<td class=bc>10 - 1 - 3</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Mi Černoch</td><td class=kL>4:5</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kL>0:3</td>
<td class=kW>1:0</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>7:0</td>
<td class=kW>7:1</td>
<td class=kW>8:1</td>
<td class=br>51:21</td><td class=br>+30</td>
<td class=bc>10 - 0 - 4</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ki Storchak</td><td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kT>0:0</td>
<td class=kW>7:0</td>
<td class=br>38:23</td><td class=br>+15</td>
<td class=bc>7 - 4 - 3</td>
<td class=br><strong>18</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ge Regula</td><td class=kL>1:6</td>
<td class=kT>5:5</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=br>47:40</td><td class=br>+7</td>
<td class=bc>8 - 2 - 4</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>An Šurýn</td><td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=br>40:28</td><td class=br>+12</td>
<td class=bc>6 - 3 - 5</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ti Varga</td><td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>2:5</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=br>35:28</td><td class=br>+7</td>
<td class=bc>6 - 3 - 5</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Pa Hráský</td><td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>2:0</td>
<td class=kW>6:0</td>
<td class=br>33:33</td><td class=br>0</td>
<td class=bc>6 - 2 - 6</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ra Pommerenke</td><td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=br>37:43</td><td class=br>-6</td>
<td class=bc>5 - 2 - 7</td>
<td class=br><strong>12</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>St Srba</td><td class=kL>2:6</td>
<td class=kL>2:7</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=br>34:41</td><td class=br>-7</td>
<td class=bc>5 - 1 - 8</td>
<td class=br><strong>11</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ol Majaniemi</td><td class=kL>0:6</td>
<td class=kL>3:5</td>
<td class=kL>1:8</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=br>36:51</td><td class=br>-15</td>
<td class=bc>4 - 2 - 8</td>
<td class=br><strong>10</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ví Perkner</td><td class=kL>0:4</td>
<td class=kL>2:9</td>
<td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=br>29:65</td><td class=br>-36</td>
<td class=bc>2 - 1 - 11</td>
<td class=br><strong>5</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Da Kadlec</td><td class=kL>0:7</td>
<td class=kL>3:6</td>
<td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kT>0:0</td>
<td class=kL>0:6</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=br>16:68</td><td class=br>-52</td>
<td class=bc>1 - 1 - 12</td>
<td class=br><strong>3</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ka Šurýnová</td><td class=kL>1:9</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>1:8</td>
<td class=kL>0:7</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=br>5:77</td><td class=br>-72</td>
<td class=bc>0 - 0 - 14</td>
<td class=br><strong>0</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=blW>Ti Varga</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ka Šurýnová</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>Ki Storchak</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>Ge Regula</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ti Varga</td><td class=bc>-</td><td class=bl>Ka Šurýnová</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ki Storchak</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Ge Regula</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ol Majaniemi</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ka Šurýnová</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ti Varga</td><td class=bc>-</td><td class=bl>Ki Storchak</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Ro Nuttunen</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Ki Storchak</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ka Šurýnová</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ti Varga</td><td class=bc>-</td><td class=blW>Ge Regula</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ja Dryák</td><td class=bc>-</td><td class=bl>Ro Nuttunen</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ki Storchak</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ka Šurýnová</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ti Varga</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>Ro Nuttunen</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Ge Regula</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ki Storchak</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ka Šurýnová</td><td class=bc>-</td><td class=blW>Ro Nuttunen</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Ti Varga</td><td class=bc>-</td><td class=blW>Ol Majaniemi</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ki Storchak</td><td class=bc>-</td><td class=blW>Ro Nuttunen</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka Šurýnová</td><td class=bc>-</td><td class=blW>Da Kadlec</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ti Varga</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Ro Nuttunen</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ki Storchak</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ka Šurýnová</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Ti Varga</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Ro Nuttunen</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Pa Hráský</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ki Storchak</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ka Šurýnová</td><td class=bc>-</td><td class=blW>Mi Borgh</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Pa Hráský</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ki Storchak</td><td class=bc>-</td><td class=blW>Mi Borgh</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ol Majaniemi</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Mi Borgh</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Ti Varga</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ki Storchak</td><td class=bc>-</td><td class=bl>Ka Šurýnová</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Pa Hráský</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Mi Borgh</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>Ka Šurýnová</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>Mi Borgh</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>Ka Šurýnová</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=bl>Ki Storchak</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Mi Borgh</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Ti Varga</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ol Majaniemi</td><td class=bc>-</td><td class=bl>Ka Šurýnová</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Ki Storchak</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Mi Borgh</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Ti Varga</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>Ka Šurýnová</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>Ki Storchak</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Ge Regula</td><td class=bc>2 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 4</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Le Hvižď ml.</td><td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>12:1</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=kW>11:0</td>
<td class=kW>4:0</td>
<td class=br>83:16</td><td class=br>+67</td>
<td class=bc>15 - 0 - 0</td>
<td class=br><strong>30</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Da Šmíd</td><td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>6:7</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>8:2</td>
<td class=kW>7:1</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=br>68:32</td><td class=br>+36</td>
<td class=bc>12 - 1 - 2</td>
<td class=br><strong>25</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ji Chylík ml.</td><td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kT>5:5</td>
<td class=kW>2:1</td>
<td class=kW>9:1</td>
<td class=kW>7:4</td>
<td class=kW>7:2</td>
<td class=br>67:30</td><td class=br>+37</td>
<td class=bc>11 - 1 - 3</td>
<td class=br><strong>23</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Pe Borsanyi</td><td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kT>5:5</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=br>53:37</td><td class=br>+16</td>
<td class=bc>9 - 2 - 4</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ja Matýsek</td><td class=kL>2:7</td>
<td class=kW>7:6</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>9:2</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>7:2</td>
<td class=kW>13:1</td>
<td class=kW>6:0</td>
<td class=kW>9:0</td>
<td class=br>73:40</td><td class=br>+33</td>
<td class=bc>10 - 0 - 5</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Mi Blažek</td><td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>5:4</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=br>46:36</td><td class=br>+10</td>
<td class=bc>9 - 1 - 5</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>To Bucek</td><td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kT>5:5</td>
<td class=kL>2:5</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>6:5</td>
<td class=kW>8:1</td>
<td class=kW>6:0</td>
<td class=kW>12:0</td>
<td class=br>66:33</td><td class=br>+33</td>
<td class=bc>9 - 1 - 5</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>My Shalomayev</td><td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>13:0</td>
<td class=kW>8:0</td>
<td class=kW>13:2</td>
<td class=kW>12:2</td>
<td class=br>76:31</td><td class=br>+45</td>
<td class=bc>9 - 0 - 6</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Zd Matoušek st.</td><td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>9:2</td>
<td class=kW>8:1</td>
<td class=br>48:36</td><td class=br>+12</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ra Bidlo</td><td class=kL>1:12</td>
<td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kL>2:9</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kL>1:7</td>
<td class=kW>4:2</td>
<td class=kW>5:4</td>
<td class=kW>5:2</td>
<td class=br>40:72</td><td class=br>-32</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Al Mačynský</td><td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>8:1</td>
<td class=kW>7:1</td>
<td class=kW>8:1</td>
<td class=br>38:39</td><td class=br>-1</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Mi Lévy</td><td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kT>5:5</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kL>4:5</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>7:3</td>
<td class=kW>8:1</td>
<td class=br>42:49</td><td class=br>-7</td>
<td class=bc>4 - 3 - 8</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Wo Abshagen</td><td class=kL>1:4</td>
<td class=kL>2:8</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>3:4</td>
<td class=kL>5:6</td>
<td class=kL>0:13</td>
<td class=kL>2:3</td>
<td class=kW>7:1</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=br>39:63</td><td class=br>-24</td>
<td class=bc>4 - 1 - 10</td>
<td class=br><strong>9</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ra Hrnčíř</td><td class=kL>0:8</td>
<td class=kL>1:7</td>
<td class=kL>1:9</td>
<td class=kL>1:6</td>
<td class=kL>1:13</td>
<td class=kL>0:5</td>
<td class=kL>1:8</td>
<td class=kL>0:8</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:8</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>8:6</td>
<td class=kW>3:2</td>
<td class=br>24:95</td><td class=br>-71</td>
<td class=bc>2 - 0 - 13</td>
<td class=br><strong>4</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Mi Horáková</td><td class=kL>0:11</td>
<td class=kL>1:6</td>
<td class=kL>4:7</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>2:13</td>
<td class=kL>2:9</td>
<td class=kL>4:5</td>
<td class=kL>1:7</td>
<td class=kL>3:7</td>
<td class=kL>3:4</td>
<td class=kL>6:8</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=br>33:101</td><td class=br>-68</td>
<td class=bc>1 - 0 - 14</td>
<td class=br><strong>2</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Ro Prauda</td><td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>2:7</td>
<td class=kL>0:3</td>
<td class=kL>0:9</td>
<td class=kL>0:6</td>
<td class=kL>0:12</td>
<td class=kL>2:12</td>
<td class=kL>1:8</td>
<td class=kL>2:5</td>
<td class=kL>1:8</td>
<td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=br>15:101</td><td class=br>-86</td>
<td class=bc>0 - 0 - 15</td>
<td class=br><strong>0</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Ro Prauda</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Wo Abshagen</td><td class=bc>-</td><td class=bl>Ro Prauda</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Ro Prauda</td><td class=bc>12 : 2</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>6 : 7</tr></td>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>6 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ro Prauda</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ro Prauda</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ra Bidlo</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ro Prauda</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Wo Abshagen</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Pe Borsanyi</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ro Prauda</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>13 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=blW>Pe Borsanyi</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ro Prauda</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 12</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Pe Borsanyi</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Wo Abshagen</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ro Prauda</td><td class=bc>-</td><td class=blW>Ra Bidlo</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>13 : 0</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>11 : 0</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Pe Borsanyi</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ro Prauda</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Ra Bidlo</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ro Prauda</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Pe Borsanyi</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>12 : 1</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Ro Prauda</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ra Bidlo</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Wo Abshagen</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Ro Prauda</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=blW>Ra Bidlo</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ro Prauda</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Ro Prauda</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 13</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Ro Prauda</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 5</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Zd Matoušek ml.</td><td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>11:1</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>11:2</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=kW>9:0</td>
<td class=br>85:14</td><td class=br>+71</td>
<td class=bc>14 - 1 - 0</td>
<td class=br><strong>29</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Da Matýsek</td><td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kW>6:5</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=br>50:28</td><td class=br>+22</td>
<td class=bc>12 - 2 - 1</td>
<td class=br><strong>26</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Va Dietze</td><td class=kL>1:7</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>8:4</td>
<td class=kW>5:3</td>
<td class=kW>7:0</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>9:2</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>12:2</td>
<td class=br>74:35</td><td class=br>+39</td>
<td class=bc>11 - 1 - 3</td>
<td class=br><strong>23</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>To Waclawek</td><td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>9:2</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>8:0</td>
<td class=kW>6:1</td>
<td class=br>68:37</td><td class=br>+31</td>
<td class=bc>9 - 3 - 3</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Kr Lebl</td><td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>1:0</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>7:3</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=br>44:23</td><td class=br>+21</td>
<td class=bc>10 - 1 - 4</td>
<td class=br><strong>21</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Be Rjavec</td><td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>7:4</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=br>52:36</td><td class=br>+16</td>
<td class=bc>10 - 0 - 5</td>
<td class=br><strong>20</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ji Kropáček</td><td class=kL>1:11</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>10:3</td>
<td class=kW>6:0</td>
<td class=br>42:39</td><td class=br>+3</td>
<td class=bc>7 - 4 - 4</td>
<td class=br><strong>18</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ji Vácha</td><td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>4:8</td>
<td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>10:2</td>
<td class=kW>6:1</td>
<td class=kW>9:0</td>
<td class=kW>8:3</td>
<td class=br>64:41</td><td class=br>+23</td>
<td class=bc>8 - 1 - 6</td>
<td class=br><strong>17</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ma Papp</td><td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>4:7</td>
<td class=kW>7:3</td>
<td class=kW>5:0</td>
<td class=kW>7:4</td>
<td class=kW>5:1</td>
<td class=kW>9:2</td>
<td class=kW>5:0</td>
<td class=br>56:40</td><td class=br>+16</td>
<td class=bc>7 - 1 - 7</td>
<td class=br><strong>15</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Lu Příhoda</td><td class=kT>3:3</td>
<td class=kL>5:6</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kW>7:4</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>0:4</td>
<td class=kT>8:8</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=br>51:54</td><td class=br>-3</td>
<td class=bc>5 - 2 - 8</td>
<td class=br><strong>12</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Jo Sedláček</td><td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>2:9</td>
<td class=kL>2:3</td>
<td class=kL>4:7</td>
<td class=kW>3:1</td>
<td class=kL>2:6</td>
<td class=kL>3:7</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=br>40:54</td><td class=br>-14</td>
<td class=bc>6 - 0 - 9</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Jo Perkner</td><td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>8:2</td>
<td class=kW>5:0</td>
<td class=br>32:46</td><td class=br>-14</td>
<td class=bc>3 - 3 - 9</td>
<td class=br><strong>9</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>An Grimová</td><td class=kL>2:11</td>
<td class=kL>1:2</td>
<td class=kL>2:9</td>
<td class=kL>1:6</td>
<td class=kL>3:7</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>2:10</td>
<td class=kL>4:7</td>
<td class=kT>8:8</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=br>41:79</td><td class=br>-38</td>
<td class=bc>3 - 2 - 10</td>
<td class=br><strong>8</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>An Naszádi</td><td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kW>9:0</td>
<td class=br>38:55</td><td class=br>-17</td>
<td class=bc>2 - 3 - 10</td>
<td class=br><strong>7</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ja Saj</td><td class=kL>0:7</td>
<td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>3:7</td>
<td class=kL>3:10</td>
<td class=kL>0:9</td>
<td class=kL>2:9</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>2:8</td>
<td class=kL>2:5</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=br>23:100</td><td class=br>-77</td>
<td class=bc>1 - 0 - 14</td>
<td class=br><strong>2</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Fi Werner</td><td class=kL>0:9</td>
<td class=kL>0:4</td>
<td class=kL>2:12</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kL>3:8</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kL>0:9</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=br>15:94</td><td class=br>-79</td>
<td class=bc>0 - 0 - 15</td>
<td class=br><strong>0</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Fi Werner</td><td class=bc>12 : 2</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ja Saj</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Lu Příhoda</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Fi Werner</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>Ja Saj</td><td class=bc>10 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Lu Příhoda</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Ma Papp</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Fi Werner</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Ja Saj</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>Lu Příhoda</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Ja Saj</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Fi Werner</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Lu Příhoda</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Ja Saj</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Lu Příhoda</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Fi Werner</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ja Saj</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Lu Příhoda</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Fi Werner</td><td class=bc>-</td><td class=blW>An Naszádi</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 11</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Lu Příhoda</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ja Saj</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Ma Papp</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Fi Werner</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ji Kropáček</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Lu Příhoda</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=blW>Ma Papp</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Saj</td><td class=bc>-</td><td class=blW>An Naszádi</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Fi Werner</td><td class=bc>-</td><td class=blW>Ji Kropáček</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>9 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Lu Příhoda</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ja Saj</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>10 : 2</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Fi Werner</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Lu Příhoda</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=blW>Ji Kropáček</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ja Saj</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Fi Werner</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Lu Příhoda</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>8 : 8</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ja Saj</td><td class=bc>-</td><td class=bl>Fi Werner</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Lu Příhoda</td><td class=bc>-</td><td class=bl>Fi Werner</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ja Saj</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>11 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Fi Werner</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Lu Příhoda</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Ja Saj</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Fi Werner</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Lu Příhoda</td><td class=bc>-</td><td class=bl>Ja Saj</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Fi Werner</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Ja Saj</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Lu Příhoda</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Fi Werner</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ja Saj</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>Lu Příhoda</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 6</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Mi Shashkov</td><td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=br>58:28</td><td class=br>+30</td>
<td class=bc>12 - 3 - 0</td>
<td class=br><strong>27</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Dm Petrov</td><td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>5:4</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kW>11:2</td>
<td class=kW>8:0</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>8:0</td>
<td class=kW>10:2</td>
<td class=br>88:26</td><td class=br>+62</td>
<td class=bc>13 - 0 - 2</td>
<td class=br><strong>26</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>To Kahoun ml.</td><td class=kT>2:2</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>0:7</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>7:2</td>
<td class=br>58:36</td><td class=br>+22</td>
<td class=bc>11 - 2 - 2</td>
<td class=br><strong>24</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>St Kraus</td><td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>4:7</td>
<td class=kW>5:4</td>
<td class=kW>6:1</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kW>8:1</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=kW>9:0</td>
<td class=br>76:36</td><td class=br>+40</td>
<td class=bc>10 - 1 - 4</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>An Bozic</td><td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kW>7:0</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>7:2</td>
<td class=kL>4:5</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>7:3</td>
<td class=br>60:31</td><td class=br>+29</td>
<td class=bc>9 - 2 - 4</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Zd Lopaur</td><td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kW>7:4</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kL>2:5</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=kW>9:1</td>
<td class=br>55:33</td><td class=br>+22</td>
<td class=bc>9 - 1 - 5</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ma Ženíšek</td><td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kL>2:6</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kW>8:0</td>
<td class=kL>2:4</td>
<td class=kW>7:3</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=br>65:41</td><td class=br>+24</td>
<td class=bc>9 - 0 - 6</td>
<td class=br><strong>18</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Mi Mašika</td><td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>8:1</td>
<td class=br>41:33</td><td class=br>+8</td>
<td class=bc>7 - 4 - 4</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Vá Pikl</td><td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>2:7</td>
<td class=kW>3:1</td>
<td class=kL>3:7</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kW>8:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>9:1</td>
<td class=br>55:43</td><td class=br>+12</td>
<td class=bc>8 - 1 - 6</td>
<td class=br><strong>17</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>To Kahoun st.</td><td class=kL>2:6</td>
<td class=kL>2:11</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kW>5:4</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kT>0:0</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=br>44:47</td><td class=br>-3</td>
<td class=bc>7 - 1 - 7</td>
<td class=br><strong>15</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Mi Uhlíř</td><td class=kL>3:5</td>
<td class=kL>0:8</td>
<td class=kL>3:4</td>
<td class=kL>1:8</td>
<td class=kL>2:5</td>
<td class=kW>5:2</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>6:5</td>
<td class=kL>2:5</td>
<td class=kW>9:2</td>
<td class=kW>8:0</td>
<td class=br>51:64</td><td class=br>-13</td>
<td class=bc>5 - 0 - 10</td>
<td class=br><strong>10</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ma Klazar</td><td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=br>27:62</td><td class=br>-35</td>
<td class=bc>4 - 0 - 11</td>
<td class=br><strong>8</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Fr Rasche</td><td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kL>1:8</td>
<td class=kL>2:5</td>
<td class=kL>5:6</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>8:2</td>
<td class=br>40:59</td><td class=br>-19</td>
<td class=bc>4 - 0 - 11</td>
<td class=br><strong>8</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Pe Holub</td><td class=kL>3:5</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>3:7</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kT>0:0</td>
<td class=kW>5:2</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>8:1</td>
<td class=kW>6:0</td>
<td class=br>34:55</td><td class=br>-21</td>
<td class=bc>3 - 1 - 11</td>
<td class=br><strong>7</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Mi Rohla</td><td class=kL>0:4</td>
<td class=kL>0:8</td>
<td class=kL>2:5</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kL>1:7</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>2:9</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>1:8</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=br>16:87</td><td class=br>-71</td>
<td class=bc>0 - 1 - 14</td>
<td class=br><strong>1</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>To Rybák</td><td class=kL>2:5</td>
<td class=kL>2:10</td>
<td class=kL>2:7</td>
<td class=kL>0:9</td>
<td class=kL>3:7</td>
<td class=kL>1:9</td>
<td class=kL>1:5</td>
<td class=kL>1:8</td>
<td class=kL>1:9</td>
<td class=kL>0:6</td>
<td class=kL>0:8</td>
<td class=kL>1:6</td>
<td class=kL>2:8</td>
<td class=kL>0:6</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=br>20:107</td><td class=br>-87</td>
<td class=bc>0 - 1 - 14</td>
<td class=br><strong>1</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Mi Shashkov</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>To Rybák</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Mi Rohla</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=bl>Mi Shashkov</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>To Rybák</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Mi Rohla</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Mi Shashkov</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>To Rybák</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Mi Rohla</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Fr Rasche</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>2 : 11</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>4 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Mi Shashkov</td><td class=bc>-</td><td class=bl>To Rybák</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Mi Rohla</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Fr Rasche</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>To Rybák</td><td class=bc>-</td><td class=bl>Mi Rohla</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Mi Shashkov</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Mi Rohla</td><td class=bc>-</td><td class=blW>Fr Rasche</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>To Rybák</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Mi Shashkov</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Mi Rohla</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>To Rybák</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Mi Shashkov</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Mi Rohla</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>To Rybák</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Mi Shashkov</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Rohla</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>To Rybák</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Mi Shashkov</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Rohla</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>To Rybák</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Mi Shashkov</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Mi Mašika</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Rohla</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>To Rybák</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Mi Shashkov</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Mašika</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Mi Rohla</td><td class=bc>-</td><td class=blW>Mi Shashkov</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>To Rybák</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Mi Shashkov</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Fr Rasche</td><td class=bc>-</td><td class=bl>To Rybák</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Mi Rohla</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Mi Shashkov</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>To Rybák</td><td class=bc>10 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Mi Rohla</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=bl>Mi Shashkov</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>To Rybák</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Mi Mašika</td><td class=bc>-</td><td class=bl>Mi Rohla</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Mi Shashkov</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>To Rybák</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Mi Rohla</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</table></div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
