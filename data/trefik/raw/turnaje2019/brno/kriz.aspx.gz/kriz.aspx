<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Brno</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.stolnihokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="../../pohar.aspx">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../brno">Brno 2. únor 2019</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p><a href="#basic">Základní skupiny (Basic groups)</a><br>
<a href="#final">Výkonnostní skupiny (Final groups)</a><br>
<a name="basic"><p class=vm>Základní skupiny (Basic groups)</p></a>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Vá Pikl</td><td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:5</td>
<td class=kW>1:0</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=br>63:26</td><td class=br>+37</td>
<td class=bc>13 - 1 - 2</td>
<td class=br><strong>27</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Mi Zunka</td><td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>8:2</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kL>5:6</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>5:4</td>
<td class=kW>9:5</td>
<td class=kW>8:1</td>
<td class=kW>9:2</td>
<td class=br>82:37</td><td class=br>+45</td>
<td class=bc>12 - 2 - 2</td>
<td class=br><strong>26</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Le Hvižď ml.</td><td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>7:1</td>
<td class=kW>6:4</td>
<td class=kW>3:1</td>
<td class=kW>9:3</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=kW>8:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=br>77:29</td><td class=br>+48</td>
<td class=bc>12 - 2 - 2</td>
<td class=br><strong>26</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Kr Lebl</td><td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>8:3</td>
<td class=kW>7:2</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=br>62:25</td><td class=br>+37</td>
<td class=bc>12 - 2 - 2</td>
<td class=br><strong>26</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Kr Herold</td><td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>8:0</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=br>68:37</td><td class=br>+31</td>
<td class=bc>11 - 4 - 1</td>
<td class=br><strong>26</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>To Jedlička</td><td class=kL>1:2</td>
<td class=kL>2:8</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kW>6:4</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kT>5:5</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kL>4:5</td>
<td class=kW>5:2</td>
<td class=kW>8:2</td>
<td class=kW>6:1</td>
<td class=br>64:46</td><td class=br>+18</td>
<td class=bc>9 - 3 - 4</td>
<td class=br><strong>21</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>An Šurýn</td><td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=br>45:47</td><td class=br>-2</td>
<td class=bc>8 - 3 - 5</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Mi Blažek</td><td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>4:6</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=br>39:42</td><td class=br>-3</td>
<td class=bc>7 - 2 - 7</td>
<td class=br><strong>16</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Lu Varga</td><td class=kL>3:5</td>
<td class=kW>6:5</td>
<td class=kL>4:6</td>
<td class=kL>3:8</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>7:3</td>
<td class=br>49:55</td><td class=br>-6</td>
<td class=bc>7 - 0 - 9</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Mi Uhlíř</td><td class=kL>0:7</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kW>5:4</td>
<td class=kW>7:2</td>
<td class=kL>2:3</td>
<td class=kW>6:0</td>
<td class=br>48:57</td><td class=br>-9</td>
<td class=bc>6 - 1 - 9</td>
<td class=br><strong>13</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ja Strmiska</td><td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>3:9</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kT>5:5</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=br>41:55</td><td class=br>-14</td>
<td class=bc>5 - 3 - 8</td>
<td class=br><strong>13</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ra Nevrlík</td><td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>9:1</td>
<td class=kW>7:2</td>
<td class=br>48:50</td><td class=br>-2</td>
<td class=bc>4 - 4 - 8</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ma Vépy</td><td class=kL>3:6</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kW>3:0</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>4:5</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=br>38:53</td><td class=br>-15</td>
<td class=bc>4 - 2 - 10</td>
<td class=br><strong>10</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Vo Bernát</td><td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kL>1:8</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kW>5:4</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=br>50:58</td><td class=br>-8</td>
<td class=bc>4 - 2 - 10</td>
<td class=br><strong>10</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ji Junek</td><td class=kL>1:4</td>
<td class=kL>5:9</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>0:8</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>7:1</td>
<td class=br>39:67</td><td class=br>-28</td>
<td class=bc>3 - 1 - 12</td>
<td class=br><strong>7</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>An Grimová</td><td class=kL>0:5</td>
<td class=kL>1:8</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>2:8</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>1:9</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=br>18:76</td><td class=br>-58</td>
<td class=bc>2 - 0 - 14</td>
<td class=br><strong>4</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Al Pala</td><td class=kL>0:8</td>
<td class=kL>2:9</td>
<td class=kL>0:8</td>
<td class=kL>2:7</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kL>3:7</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kL>3:4</td>
<td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=br>20:91</td><td class=br>-71</td>
<td class=bc>1 - 0 - 15</td>
<td class=br><strong>2</strong></td><td class=d>17.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ma Vépy</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ra Nevrlík</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Ji Junek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>Lu Varga</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ja Strmiska</td><td class=bc>-</td><td class=bl>Al Pala</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Mi Zunka</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Vépy</td><td class=bc>-</td><td class=blW>Ji Junek</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ra Nevrlík</td><td class=bc>-</td><td class=blW>Lu Varga</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Al Pala</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Zunka</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ja Strmiska</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ji Junek</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Lu Varga</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ma Vépy</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ra Nevrlík</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Al Pala</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Mi Zunka</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ji Junek</td><td class=bc>-</td><td class=blW>Lu Varga</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Vépy</td><td class=bc>-</td><td class=bl>Al Pala</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ra Nevrlík</td><td class=bc>-</td><td class=blW>Mi Zunka</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ja Strmiska</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Lu Varga</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ji Junek</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Al Pala</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Mi Zunka</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ma Vépy</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ra Nevrlík</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ja Strmiska</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Lu Varga</td><td class=bc>-</td><td class=bl>Al Pala</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ji Junek</td><td class=bc>-</td><td class=blW>Mi Zunka</td><td class=bc>5 : 9</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ma Vépy</td><td class=bc>-</td><td class=bl>Ja Strmiska</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Nevrlík</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Al Pala</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Mi Zunka</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Lu Varga</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ji Junek</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ja Strmiska</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Vépy</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ra Nevrlík</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Al Pala</td><td class=bc>-</td><td class=blW>Mi Zunka</td><td class=bc>2 : 9</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Lu Varga</td><td class=bc>-</td><td class=bl>Ja Strmiska</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ji Junek</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Ma Vépy</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Mi Zunka</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Al Pala</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Ja Strmiska</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Lu Varga</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ji Junek</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Ra Nevrlík</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Mi Zunka</td><td class=bc>-</td><td class=bl>Ja Strmiska</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Al Pala</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Lu Varga</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ji Junek</td><td class=bc>-</td><td class=bl>Ra Nevrlík</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Vépy</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ja Strmiska</td><td class=bc>9 : 3</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Zunka</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Al Pala</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Ra Nevrlík</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Lu Varga</td><td class=bc>-</td><td class=blW>Ma Vépy</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ji Junek</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ja Strmiska</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Mi Zunka</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Al Pala</td><td class=bc>-</td><td class=blW>Ra Nevrlík</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ma Vépy</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Lu Varga</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>3 : 8</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ja Strmiska</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Ra Nevrlík</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Mi Zunka</td><td class=bc>-</td><td class=bl>Ma Vépy</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Al Pala</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Ji Junek</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ja Strmiska</td><td class=bc>-</td><td class=bl>Ra Nevrlík</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ma Vépy</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Mi Zunka</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Al Pala</td><td class=bc>-</td><td class=blW>Ji Junek</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Lu Varga</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Ra Nevrlík</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Ma Vépy</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ja Strmiska</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Ji Junek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Zunka</td><td class=bc>-</td><td class=blW>Lu Varga</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Al Pala</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ra Nevrlík</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>Ma Vépy</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ja Strmiska</td><td class=bc>-</td><td class=bl>Ji Junek</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Lu Varga</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Mi Zunka</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ra Nevrlík</td><td class=bc>-</td><td class=bl>Ma Vépy</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ji Junek</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Lu Varga</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ja Strmiska</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Al Pala</td><td class=bc>7 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Zd Matoušek ml.</td><td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>7:6</td>
<td class=kW>8:0</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>7:3</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>9:0</td>
<td class=kW>4:1</td>
<td class=br>83:18</td><td class=br>+65</td>
<td class=bc>16 - 0 - 0</td>
<td class=br><strong>32</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Sa Hána</td><td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>5:4</td>
<td class=kW>7:4</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>9:0</td>
<td class=br>76:32</td><td class=br>+44</td>
<td class=bc>14 - 0 - 2</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Da Šmíd</td><td class=kL>6:7</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>9:0</td>
<td class=kW>8:1</td>
<td class=kW>3:0</td>
<td class=br>74:22</td><td class=br>+52</td>
<td class=bc>13 - 1 - 2</td>
<td class=br><strong>27</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ja Matýsek</td><td class=kL>0:8</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=kW>8:2</td>
<td class=kW>7:2</td>
<td class=kW>10:1</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=br>67:34</td><td class=br>+33</td>
<td class=bc>11 - 3 - 2</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Zb Pilař</td><td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>6:4</td>
<td class=kT>4:4</td>
<td class=kW>8:1</td>
<td class=kW>8:1</td>
<td class=kW>5:0</td>
<td class=br>62:35</td><td class=br>+27</td>
<td class=bc>10 - 2 - 4</td>
<td class=br><strong>22</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ma Martinec</td><td class=kL>0:5</td>
<td class=kL>4:7</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=kW>9:3</td>
<td class=kW>6:5</td>
<td class=kW>8:0</td>
<td class=br>62:39</td><td class=br>+23</td>
<td class=bc>10 - 0 - 6</td>
<td class=br><strong>20</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>To Kahoun st.</td><td class=kL>3:7</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=br>46:41</td><td class=br>+5</td>
<td class=bc>9 - 1 - 6</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Ad Zielinský</td><td class=kL>0:5</td>
<td class=kL>3:6</td>
<td class=kL>0:5</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>8:3</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=br>46:38</td><td class=br>+8</td>
<td class=bc>9 - 1 - 6</td>
<td class=br><strong>19</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Hy Nechutný</td><td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=br>41:30</td><td class=br>+11</td>
<td class=bc>8 - 0 - 8</td>
<td class=br><strong>16</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Pa Hráský</td><td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=br>30:38</td><td class=br>-8</td>
<td class=bc>7 - 0 - 9</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Pa Kocsis</td><td class=kL>0:5</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kW>4:1</td>
<td class=kL>0:4</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=br>33:53</td><td class=br>-20</td>
<td class=bc>5 - 2 - 9</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Iv Mašková</td><td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kL>0:2</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=br>33:44</td><td class=br>-11</td>
<td class=bc>5 - 1 - 10</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ma Klazar</td><td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>2:8</td>
<td class=kL>4:6</td>
<td class=kL>2:7</td>
<td class=kL>0:2</td>
<td class=kL>3:8</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kW>8:2</td>
<td class=br>36:61</td><td class=br>-25</td>
<td class=bc>4 - 2 - 10</td>
<td class=br><strong>10</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Cs Kocsis</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>2:7</td>
<td class=kT>4:4</td>
<td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>10:4</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=br>37:66</td><td class=br>-29</td>
<td class=bc>3 - 3 - 10</td>
<td class=br><strong>9</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>To Olšák</td><td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>0:9</td>
<td class=kL>1:10</td>
<td class=kL>1:8</td>
<td class=kL>3:9</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>4:10</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=br>27:89</td><td class=br>-62</td>
<td class=bc>1 - 3 - 12</td>
<td class=br><strong>5</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Ka Stařecká</td><td class=kL>0:9</td>
<td class=kL>2:6</td>
<td class=kL>1:8</td>
<td class=kL>2:3</td>
<td class=kL>1:8</td>
<td class=kL>5:6</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=br>25:70</td><td class=br>-45</td>
<td class=bc>1 - 1 - 14</td>
<td class=br><strong>3</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>To Pětník</td><td class=kL>1:4</td>
<td class=kL>0:9</td>
<td class=kL>0:3</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kL>1:7</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>2:8</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=br>10:78</td><td class=br>-68</td>
<td class=bc>0 - 0 - 16</td>
<td class=br><strong>0</strong></td><td class=d>17.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>To Pětník</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pa Kocsis</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Zb Pilař</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Cs Kocsis</td><td class=bc>-</td><td class=blW>Ma Martinec</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Sa Hána</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>To Pětník</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pa Kocsis</td><td class=bc>-</td><td class=blW>Zb Pilař</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ma Martinec</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Cs Kocsis</td><td class=bc>-</td><td class=blW>Sa Hána</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>To Olšák</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Pětník</td><td class=bc>-</td><td class=blW>Zb Pilař</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ma Martinec</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Pa Kocsis</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>To Olšák</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Cs Kocsis</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Ma Martinec</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>To Pětník</td><td class=bc>-</td><td class=blW>Ka Stařecká</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Sa Hána</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pa Kocsis</td><td class=bc>-</td><td class=bl>To Olšák</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Zb Pilař</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Ma Martinec</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Sa Hána</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Pětník</td><td class=bc>-</td><td class=blW>To Olšák</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Pa Kocsis</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Cs Kocsis</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Zb Pilař</td><td class=bc>-</td><td class=bl>Ma Martinec</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Sa Hána</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>To Olšák</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>To Pětník</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Cs Kocsis</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Pa Kocsis</td><td class=bc>-</td><td class=blW>Pa Hráský</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ma Martinec</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>Sa Hána</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>To Olšák</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=bl>Cs Kocsis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Pětník</td><td class=bc>-</td><td class=blW>Pa Hráský</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Sa Hána</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ma Martinec</td><td class=bc>-</td><td class=bl>To Olšák</td><td class=bc>9 : 3</tr></td>
<tr><td class=brW>Zb Pilař</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=bl>Cs Kocsis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>To Pětník</td><td class=bc>-</td><td class=blW>Pa Kocsis</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>To Olšák</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ma Martinec</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=bl>Cs Kocsis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Pa Kocsis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>To Olšák</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Cs Kocsis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ma Martinec</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Pa Kocsis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>To Pětník</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>To Olšák</td><td class=bc>-</td><td class=blW>Cs Kocsis</td><td class=bc>4 : 10</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Ma Martinec</td><td class=bc>-</td><td class=bl>Pa Kocsis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>To Pětník</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Cs Kocsis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Pa Hráský</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Olšák</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>Pa Kocsis</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Martinec</td><td class=bc>-</td><td class=bl>To Pětník</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Zb Pilař</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Cs Kocsis</td><td class=bc>-</td><td class=blW>Pa Hráský</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Pa Kocsis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>To Olšák</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 10</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>To Pětník</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ma Martinec</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Cs Kocsis</td><td class=bc>-</td><td class=blW>Pa Kocsis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>To Pětník</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>To Olšák</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Pa Kocsis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Cs Kocsis</td><td class=bc>-</td><td class=bl>To Pětník</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>To Olšák</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Zb Pilař</td><td class=bc>1 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Pa Kocsis</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>To Pětník</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Cs Kocsis</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>To Olšák</td><td class=bc>-</td><td class=blW>Zb Pilař</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>Ma Martinec</td><td class=bc>7 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>To Pětník</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Pa Kocsis</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>7 : 6</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Cs Kocsis</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=blW>Zb Pilař</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ma Martinec</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>To Olšák</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>3 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 3</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>ml Chylík</td><td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=kW>8:0</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=br>73:25</td><td class=br>+48</td>
<td class=bc>13 - 2 - 1</td>
<td class=br><strong>28</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ma Maděra</td><td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=kW>9:0</td>
<td class=br>72:20</td><td class=br>+52</td>
<td class=bc>13 - 0 - 3</td>
<td class=br><strong>26</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ma Ženíšek</td><td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=br>68:29</td><td class=br>+39</td>
<td class=bc>11 - 3 - 2</td>
<td class=br><strong>25</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Mi Boštík</td><td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kW>6:1</td>
<td class=kL>2:4</td>
<td class=kW>6:0</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=br>55:26</td><td class=br>+29</td>
<td class=bc>10 - 4 - 2</td>
<td class=br><strong>24</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Mi Ševr</td><td class=kW>3:2</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>8:0</td>
<td class=br>53:35</td><td class=br>+18</td>
<td class=bc>10 - 4 - 2</td>
<td class=br><strong>24</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>To Bucek</td><td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kW>4:2</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=kW>7:2</td>
<td class=br>63:38</td><td class=br>+25</td>
<td class=bc>12 - 0 - 4</td>
<td class=br><strong>24</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Al Lorand st.</td><td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>8:0</td>
<td class=kW>5:1</td>
<td class=br>49:32</td><td class=br>+17</td>
<td class=bc>9 - 2 - 5</td>
<td class=br><strong>20</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>I  Vépy</td><td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=br>51:39</td><td class=br>+12</td>
<td class=bc>8 - 3 - 5</td>
<td class=br><strong>19</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>To Růžička</td><td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>6:2</td>
<td class=kW>8:4</td>
<td class=kW>5:1</td>
<td class=kW>12:0</td>
<td class=br>61:40</td><td class=br>+21</td>
<td class=bc>9 - 0 - 7</td>
<td class=br><strong>18</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Al Mačynský</td><td class=kL>1:2</td>
<td class=kL>4:5</td>
<td class=kL>0:4</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=br>36:35</td><td class=br>+1</td>
<td class=bc>6 - 2 - 8</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Mi Franek</td><td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=kW>3:2</td>
<td class=br>38:47</td><td class=br>-9</td>
<td class=bc>5 - 3 - 8</td>
<td class=br><strong>13</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ví Perkner</td><td class=kL>0:8</td>
<td class=kL>0:7</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kT>4:4</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kW>10:0</td>
<td class=br>34:54</td><td class=br>-20</td>
<td class=bc>4 - 3 - 9</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Mi Lévy</td><td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>0:1</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kL>2:7</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>11:1</td>
<td class=br>36:53</td><td class=br>-17</td>
<td class=bc>5 - 1 - 10</td>
<td class=br><strong>11</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Jo Perkner</td><td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=br>24:54</td><td class=br>-30</td>
<td class=bc>1 - 4 - 11</td>
<td class=br><strong>6</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Št Krejzlík</td><td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kL>4:8</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=br>23:62</td><td class=br>-39</td>
<td class=bc>2 - 2 - 12</td>
<td class=br><strong>6</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Ra Hrnčíř</td><td class=kL>2:5</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>0:8</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=br>21:78</td><td class=br>-57</td>
<td class=bc>1 - 0 - 15</td>
<td class=br><strong>2</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Ja Kutaj</td><td class=kL>1:6</td>
<td class=kL>0:9</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>0:8</td>
<td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>0:12</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>0:10</td>
<td class=kL>1:11</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=br>14:104</td><td class=br>-90</td>
<td class=bc>0 - 1 - 15</td>
<td class=br><strong>1</strong></td><td class=d>17.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>I  Vépy</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ja Kutaj</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Št Krejzlík</td><td class=bc>-</td><td class=blW>Mi Franek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>I  Vépy</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Mi Franek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ja Kutaj</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Št Krejzlík</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Mi Franek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ja Kutaj</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Št Krejzlík</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>I  Vépy</td><td class=bc>-</td><td class=bl>Mi Franek</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ja Kutaj</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Št Krejzlík</td><td class=bc>-</td><td class=blW>Al Lorand st.</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>Mi Franek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Al Lorand st.</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ja Kutaj</td><td class=bc>-</td><td class=blW>Ví Perkner</td><td class=bc>0 : 10</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Mi Franek</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Ví Perkner</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>Št Krejzlík</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Franek</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Št Krejzlík</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Ja Kutaj</td><td class=bc>11 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Mi Franek</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Al Lorand st.</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>I  Vépy</td><td class=bc>-</td><td class=bl>Št Krejzlík</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ja Kutaj</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Mi Franek</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>Št Krejzlík</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Ja Kutaj</td><td class=bc>12 : 0</tr></td>
<tr><td class=brW>I  Vépy</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Št Krejzlík</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Mi Franek</td><td class=bc>-</td><td class=bl>Ja Kutaj</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Al Lorand st.</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Št Krejzlík</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ja Kutaj</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Franek</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Št Krejzlík</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Ja Kutaj</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Franek</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>I  Vépy</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>Št Krejzlík</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>Ja Kutaj</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>I  Vépy</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Franek</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Št Krejzlík</td><td class=bc>-</td><td class=bl>Ja Kutaj</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>I  Vépy</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ja Kutaj</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Št Krejzlík</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>I  Vépy</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Franek</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Kutaj</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Št Krejzlík</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>I  Vépy</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Mi Franek</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ja Kutaj</td><td class=bc>-</td><td class=blW>I  Vépy</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Št Krejzlík</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>4 : 8</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=bl>Mi Franek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 4</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Mi Kobrle</td><td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kW>7:1</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>8:0</td>
<td class=kW>6:3</td>
<td class=kW>8:2</td>
<td class=kW>8:2</td>
<td class=kW>7:0</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=br>84:28</td><td class=br>+56</td>
<td class=bc>14 - 0 - 2</td>
<td class=br><strong>28</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Da Matýsek</td><td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=br>52:17</td><td class=br>+35</td>
<td class=bc>13 - 2 - 1</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Pa Plešák</td><td class=kL>2:4</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>8:2</td>
<td class=kW>9:0</td>
<td class=kW>7:2</td>
<td class=kW>8:1</td>
<td class=kW>10:2</td>
<td class=kW>8:2</td>
<td class=br>80:35</td><td class=br>+45</td>
<td class=bc>11 - 3 - 2</td>
<td class=br><strong>25</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>To Waclawek</td><td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>3:6</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>6:3</td>
<td class=kW>8:1</td>
<td class=kW>7:1</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=br>68:29</td><td class=br>+39</td>
<td class=bc>12 - 1 - 3</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>To Pokovič</td><td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kL>0:6</td>
<td class=kW>7:2</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kW>7:0</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=br>71:33</td><td class=br>+38</td>
<td class=bc>11 - 2 - 3</td>
<td class=br><strong>24</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Fr Marek</td><td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>8:1</td>
<td class=br>53:37</td><td class=br>+16</td>
<td class=bc>10 - 1 - 5</td>
<td class=br><strong>21</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Mi Černoch</td><td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>8:0</td>
<td class=kW>4:0</td>
<td class=kW>8:1</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>57:26</td><td class=br>+31</td>
<td class=bc>10 - 1 - 5</td>
<td class=br><strong>21</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Ro Jež</td><td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>6:0</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kW>9:0</td>
<td class=kW>6:3</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=br>53:34</td><td class=br>+19</td>
<td class=bc>8 - 2 - 6</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>To Halama</td><td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>6:3</td>
<td class=kW>6:0</td>
<td class=kW>7:0</td>
<td class=kW>7:0</td>
<td class=kW>7:1</td>
<td class=kL>3:4</td>
<td class=br>59:41</td><td class=br>+18</td>
<td class=bc>7 - 2 - 7</td>
<td class=br><strong>16</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>To Kahoun ml.</td><td class=kL>0:8</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>7:2</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=br>46:44</td><td class=br>+2</td>
<td class=bc>8 - 0 - 8</td>
<td class=br><strong>16</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ri Bartošek</td><td class=kL>3:6</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kL>3:6</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>2:7</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>7:0</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=br>48:50</td><td class=br>-2</td>
<td class=bc>6 - 2 - 8</td>
<td class=br><strong>14</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Pe Fuchs</td><td class=kL>2:8</td>
<td class=kL>0:4</td>
<td class=kL>2:8</td>
<td class=kL>1:8</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>0:8</td>
<td class=kW>4:3</td>
<td class=kL>3:6</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kW>11:0</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=br>42:70</td><td class=br>-28</td>
<td class=bc>5 - 2 - 9</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ma Švik</td><td class=kL>2:8</td>
<td class=kL>0:3</td>
<td class=kL>0:9</td>
<td class=kL>1:7</td>
<td class=kL>3:6</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=br>22:64</td><td class=br>-42</td>
<td class=bc>3 - 2 - 11</td>
<td class=br><strong>8</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Mi Ptáček</td><td class=kL>0:7</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kL>2:6</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>1:8</td>
<td class=kL>0:9</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kL>0:11</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=br>23:84</td><td class=br>-61</td>
<td class=bc>3 - 2 - 11</td>
<td class=br><strong>8</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Já Novožil</td><td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:8</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=br>26:80</td><td class=br>-54</td>
<td class=bc>2 - 0 - 14</td>
<td class=br><strong>4</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Ka Šurýnová</td><td class=kL>2:7</td>
<td class=kL>0:3</td>
<td class=kL>2:10</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>0:1</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>13:75</td><td class=br>-62</td>
<td class=bc>1 - 0 - 15</td>
<td class=br><strong>2</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Pe Klazar</td><td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>2:8</td>
<td class=kL>0:4</td>
<td class=kL>1:7</td>
<td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>23:73</td><td class=br>-50</td>
<td class=bc>1 - 0 - 15</td>
<td class=br><strong>2</strong></td><td class=d>17.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ma Švik</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ri Bartošek</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Já Novožil</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Mi Ptáček</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ka Šurýnová</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>To Pokovič</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Švik</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ri Bartošek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Já Novožil</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Mi Ptáček</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ka Šurýnová</td><td class=bc>-</td><td class=blW>To Pokovič</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Švik</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ri Bartošek</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Já Novožil</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>To Pokovič</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Mi Ptáček</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ka Šurýnová</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Švik</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ri Bartošek</td><td class=bc>-</td><td class=blW>To Pokovič</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Já Novožil</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Ptáček</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>To Pokovič</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ma Švik</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ri Bartošek</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Já Novožil</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ka Šurýnová</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>To Pokovič</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ma Švik</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Ri Bartošek</td><td class=bc>-</td><td class=bl>Ka Šurýnová</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Já Novožil</td><td class=bc>-</td><td class=blW>Mi Ptáček</td><td class=bc>4 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>To Pokovič</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Ka Šurýnová</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ma Švik</td><td class=bc>-</td><td class=bl>Mi Ptáček</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ri Bartošek</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>To Pokovič</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ka Šurýnová</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Mi Ptáček</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ma Švik</td><td class=bc>-</td><td class=bl>Já Novožil</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>To Pokovič</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Ka Šurýnová</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Ptáček</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Já Novožil</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Ri Bartošek</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>To Pokovič</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ka Šurýnová</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Mi Ptáček</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Já Novožil</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ri Bartošek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Ma Švik</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Ka Šurýnová</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>To Pokovič</td><td class=bc>-</td><td class=bl>Mi Ptáček</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Já Novožil</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Ri Bartošek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Švik</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ka Šurýnová</td><td class=bc>10 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Mi Ptáček</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>To Pokovič</td><td class=bc>-</td><td class=bl>Já Novožil</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ri Bartošek</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ma Švik</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ka Šurýnová</td><td class=bc>-</td><td class=blW>Mi Ptáček</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Já Novožil</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>Ri Bartošek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>To Pokovič</td><td class=bc>-</td><td class=bl>Ma Švik</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Mi Ptáček</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ka Šurýnová</td><td class=bc>-</td><td class=blW>Já Novožil</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ri Bartošek</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ma Švik</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>To Pokovič</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Já Novožil</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Ptáček</td><td class=bc>-</td><td class=bl>Ri Bartošek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ka Šurýnová</td><td class=bc>-</td><td class=blW>Ma Švik</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>To Pokovič</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Já Novožil</td><td class=bc>-</td><td class=blW>Ri Bartošek</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ma Švik</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Ptáček</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ka Šurýnová</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>To Pokovič</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ri Bartošek</td><td class=bc>-</td><td class=bl>Ma Švik</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Já Novožil</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Ptáček</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>Ka Šurýnová</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>4 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<hr><a name="final"><p class=vm>Výkonnostní skupiny (Final groups)</p></a>
<p class=v>Group A</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt>Zd Matoušek ml.</td><td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>7:6 K</td>
<td class=kW>4:0 K</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>8:0 K</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>5:0 K</td>
<td class=kW>6:1</td>
<td class=kW>3:2 K</td>
<td class=kW>6:3</td>
<td class=br>90:34</td><td class=br>+56</td>
<td class=bc>18 - 5 - 0</td>
<td class=br><strong>41</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt>Le Hvižď ml.</td><td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kL>1:4 K</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kT>1:1 K</td>
<td class=kT>3:3</td>
<td class=kW>6:2 K</td>
<td class=kT>0:0</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>5:1 K</td>
<td class=kL>2:3 K</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=br>81:38</td><td class=br>+43</td>
<td class=bc>14 - 6 - 3</td>
<td class=br><strong>34</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt>Kr Lebl</td><td class=kL>0:4</td>
<td class=kW>4:1 K</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>2:5 K</td>
<td class=kW>2:1</td>
<td class=kT>5:5 K</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kL>0:1 K</td>
<td class=kT>1:1 K</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=br>67:46</td><td class=br>+21</td>
<td class=bc>13 - 5 - 5</td>
<td class=br><strong>31</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt>Pa Plešák</td><td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>2:4 K</td>
<td class=kL>0:1</td>
<td class=kW>4:3</td>
<td class=kL>0:6 K</td>
<td class=kT>3:3 K</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>7:5</td>
<td class=kW>6:0</td>
<td class=kT>2:2 K</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2 K</td>
<td class=br>76:58</td><td class=br>+18</td>
<td class=bc>14 - 3 - 6</td>
<td class=br><strong>31</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>Mi Kobrle</td><td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>4:2 K</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>3:1 K</td>
<td class=kL>2:5 K</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kL>0:2</td>
<td class=kW>7:6</td>
<td class=kL>1:2</td>
<td class=kL>2:3 K</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>9:2</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>7:1 K</td>
<td class=br>84:57</td><td class=br>+27</td>
<td class=bc>13 - 4 - 6</td>
<td class=br><strong>30</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>ml Chylík</td><td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>3:3 K</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kT>6:6</td>
<td class=kW>4:2 K</td>
<td class=kL>0:3</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3 K</td>
<td class=kT>4:4 K</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>6:2 K</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=br>69:52</td><td class=br>+17</td>
<td class=bc>12 - 5 - 6</td>
<td class=br><strong>29</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Mi Boštík</td><td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kT>3:3 K</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>6:5</td>
<td class=kW>4:2</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kW>4:0 K</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kT>2:2 K</td>
<td class=kW>5:3 K</td>
<td class=kW>5:3</td>
<td class=kT>4:4</td>
<td class=kL>5:7</td>
<td class=kW>6:1 K</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=br>84:67</td><td class=br>+17</td>
<td class=bc>11 - 6 - 6</td>
<td class=br><strong>28</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>Da Matýsek</td><td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kW>6:0 K</td>
<td class=kL>1:3 K</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1 K</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>1:0 K</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=kW>5:0 K</td>
<td class=br>55:38</td><td class=br>+17</td>
<td class=bc>11 - 5 - 7</td>
<td class=br><strong>27</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>To Pokovič</td><td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kT>4:4</td>
<td class=kT>3:3 K</td>
<td class=kW>5:2 K</td>
<td class=kT>3:3</td>
<td class=kL>5:6</td>
<td class=kL>1:2 K</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kT>5:5</td>
<td class=kL>1:3</td>
<td class=kW>6:3 K</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>8:6</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>4:3 K</td>
<td class=br>87:74</td><td class=br>+13</td>
<td class=bc>10 - 6 - 7</td>
<td class=br><strong>26</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Da Šmíd</td><td class=kL>6:7 K</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>3:2 K</td>
<td class=kT>4:4</td>
<td class=kL>3:6</td>
<td class=kW>4:2</td>
<td class=kT>2:2 K</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kL>2:3 K</td>
<td class=kW>4:0</td>
<td class=kW>3:1 K</td>
<td class=kW>5:2</td>
<td class=br>73:61</td><td class=br>+12</td>
<td class=bc>11 - 4 - 8</td>
<td class=br><strong>26</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>Sa Hána</td><td class=kL>0:4 K</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kL>3:6</td>
<td class=kW>6:3</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>2:3 K</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>4:2 K</td>
<td class=kW>8:4</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kW>2:0</td>
<td class=kW>7:4 K</td>
<td class=kW>4:0</td>
<td class=kW>5:4 K</td>
<td class=kT>2:2</td>
<td class=br>73:81</td><td class=br>-8</td>
<td class=bc>11 - 2 - 10</td>
<td class=br><strong>24</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>Mi Zunka</td><td class=kT>1:1</td>
<td class=kT>1:1 K</td>
<td class=kW>5:2 K</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kT>6:6</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kT>3:3 K</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kL>1:3 K</td>
<td class=kW>8:2 K</td>
<td class=kT>5:5</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=br>76:66</td><td class=br>+10</td>
<td class=bc>7 - 10 - 6</td>
<td class=br><strong>24</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt>Ma Maděra</td><td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kW>2:0</td>
<td class=kL>2:4 K</td>
<td class=kL>0:4 K</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kW>5:0 K</td>
<td class=kL>2:3 K</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kW>5:0 K</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=br>60:52</td><td class=br>+8</td>
<td class=bc>10 - 3 - 10</td>
<td class=br><strong>23</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt>Kr Herold</td><td class=kL>2:5</td>
<td class=kL>2:6 K</td>
<td class=kT>5:5 K</td>
<td class=kL>5:7</td>
<td class=kL>6:7</td>
<td class=kW>3:0</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kT>5:5</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kT>3:3 K</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kW>5:2 K</td>
<td class=kT>3:3 K</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>6:0</td>
<td class=br>74:72</td><td class=br>+2</td>
<td class=bc>8 - 6 - 9</td>
<td class=br><strong>22</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt>Ja Matýsek</td><td class=kL>0:8 K</td>
<td class=kT>0:0</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kW>2:1</td>
<td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2 K</td>
<td class=kL>2:4 K</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0 K</td>
<td class=kL>4:5</td>
<td class=kT>3:3 K</td>
<td class=kW>2:0</td>
<td class=br>44:59</td><td class=br>-15</td>
<td class=bc>8 - 6 - 9</td>
<td class=br><strong>22</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt>To Waclawek</td><td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2 K</td>
<td class=kW>3:2 K</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kL>0:1 K</td>
<td class=kL>3:6 K</td>
<td class=kL>2:3</td>
<td class=kL>4:8</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1 K</td>
<td class=br>55:70</td><td class=br>-15</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Mi Ševr</td><td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kW>3:2 K</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>0:5 K</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>2:5 K</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kW>3:2 K</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=br>51:69</td><td class=br>-18</td>
<td class=bc>6 - 7 - 10</td>
<td class=br><strong>19</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Ma Ženíšek</td><td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kT>4:4 K</td>
<td class=kL>3:5 K</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kL>4:5</td>
<td class=kW>3:2 K</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kW>5:2 K</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kW>6:3</td>
<td class=kL>2:4 K</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=br>59:75</td><td class=br>-16</td>
<td class=bc>6 - 4 - 13</td>
<td class=br><strong>16</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Vá Pikl</td><td class=kT>2:2</td>
<td class=kL>1:5 K</td>
<td class=kW>1:0 K</td>
<td class=kL>3:4</td>
<td class=kL>1:7</td>
<td class=kL>0:1</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>6:8</td>
<td class=kL>1:4</td>
<td class=kW>6:1</td>
<td class=kW>3:1 K</td>
<td class=kW>2:0</td>
<td class=kL>2:5 K</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kW>2:1 K</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=br>51:69</td><td class=br>-18</td>
<td class=bc>6 - 3 - 14</td>
<td class=br><strong>15</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>To Jedlička</td><td class=kL>1:3</td>
<td class=kW>3:2 K</td>
<td class=kT>1:1 K</td>
<td class=kL>2:5</td>
<td class=kL>2:9</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>2:8 K</td>
<td class=kW>4:1</td>
<td class=kT>3:3 K</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2 K</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=br>52:79</td><td class=br>-27</td>
<td class=bc>3 - 9 - 11</td>
<td class=br><strong>15</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Ma Martinec</td><td class=kL>0:5 K</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kW>7:5</td>
<td class=kW>3:0</td>
<td class=kL>2:6</td>
<td class=kW>3:2 K</td>
<td class=kL>4:7 K</td>
<td class=kT>5:5</td>
<td class=kL>2:5</td>
<td class=kW>4:2</td>
<td class=kL>0:3 K</td>
<td class=kW>4:1</td>
<td class=kL>0:4</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>2:3 K</td>
<td class=kL>3:5</td>
<td class=br>51:87</td><td class=br>-36</td>
<td class=bc>5 - 4 - 14</td>
<td class=br><strong>14</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>To Bucek</td><td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>2:6 K</td>
<td class=kL>1:6 K</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>0:5 K</td>
<td class=kL>1:4</td>
<td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kL>2:3 K</td>
<td class=kW>4:2 K</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>1:5</td>
<td class=br>43:81</td><td class=br>-38</td>
<td class=bc>5 - 4 - 14</td>
<td class=br><strong>14</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Zb Pilař</td><td class=kL>2:3 K</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kL>1:3 K</td>
<td class=kL>4:5 K</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kL>3:5</td>
<td class=kT>3:3 K</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>3:2 K</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>45:74</td><td class=br>-29</td>
<td class=bc>3 - 5 - 15</td>
<td class=br><strong>11</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Fr Marek</td><td class=kL>3:6</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>2:5 K</td>
<td class=kL>1:7 K</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:5 K</td>
<td class=kL>3:4 K</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kL>1:4 K</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>44:85</td><td class=br>-41</td>
<td class=bc>3 - 3 - 17</td>
<td class=br><strong>9</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Ma Martinec</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Zunka</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>To Pokovič</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Sa Hána</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Zb Pilař</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>To Pokovič</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Zunka</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Ma Martinec</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Zunka</td><td class=bc>-</td><td class=bl>Zd Matoušek ml.</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ma Martinec</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>To Pokovič</td><td class=bc>6 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Sa Hána</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Zd Matoušek ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Zunka</td><td class=bc>-</td><td class=bl>Ma Martinec</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>To Pokovič</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Sa Hána</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=bl>Ma Martinec</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=bl>To Pokovič</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mi Zunka</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Mi Zunka</td><td class=bc>-</td><td class=blW>Sa Hána</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Zd Matoušek ml.</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Martinec</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>To Pokovič</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>To Pokovič</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Mi Zunka</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ma Martinec</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>To Pokovič</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mi Zunka</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ma Martinec</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>To Pokovič</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Zunka</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=blW>To Pokovič</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Zunka</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>6 : 6</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>To Pokovič</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Zb Pilař</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Mi Zunka</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=blW>To Pokovič</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Zunka</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Mi Zunka</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>To Pokovič</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Mi Zunka</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>7 : 5</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>To Pokovič</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>8 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Pokovič</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ma Martinec</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>7 : 5</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>7 : 6</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Mi Zunka</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Pokovič</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Zunka</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>To Pokovič</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Zunka</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>To Pokovič</td><td class=bc>-</td><td class=blW>Mi Zunka</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Mi Černoch</td><td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>3:0 K</td>
<td class=kT>3:3</td>
<td class=kW>5:2 K</td>
<td class=kW>3:1 K</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kL>2:4 K</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=br>52:20</td><td class=br>+32</td>
<td class=bc>13 - 5 - 1</td>
<td class=br><strong>31</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Al Lorand st.</td><td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>3:3 K</td>
<td class=kL>2:5</td>
<td class=kW>6:3</td>
<td class=kW>3:0 K</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>2:1 K</td>
<td class=kW>3:0</td>
<td class=kT>3:3 K</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=br>57:37</td><td class=br>+20</td>
<td class=bc>12 - 3 - 4</td>
<td class=br><strong>27</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>I  Vépy</td><td class=kL>1:2</td>
<td class=kT>3:3 K</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>1:2 K</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>2:1 K</td>
<td class=kW>6:0</td>
<td class=kW>3:0 K</td>
<td class=kW>5:2</td>
<td class=kL>1:7</td>
<td class=kW>4:0</td>
<td class=kW>8:4</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=br>56:34</td><td class=br>+22</td>
<td class=bc>11 - 4 - 4</td>
<td class=br><strong>26</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Ad Zielinský</td><td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>5:4</td>
<td class=kW>4:1</td>
<td class=kL>2:3 K</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2 K</td>
<td class=kW>2:1 K</td>
<td class=kL>1:2</td>
<td class=kW>4:0 K</td>
<td class=br>50:34</td><td class=br>+16</td>
<td class=bc>11 - 4 - 4</td>
<td class=br><strong>26</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ro Jež</td><td class=kL>0:3 K</td>
<td class=kL>3:6</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:1 K</td>
<td class=kW>3:1 K</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>4:3</td>
<td class=kT>1:1 K</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>5:0 K</td>
<td class=br>53:39</td><td class=br>+14</td>
<td class=bc>12 - 1 - 6</td>
<td class=br><strong>25</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>To Růžička</td><td class=kT>3:3</td>
<td class=kL>0:3 K</td>
<td class=kW>2:1 K</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kW>1:0 K</td>
<td class=kL>4:5</td>
<td class=kW>5:0 K</td>
<td class=kW>3:1</td>
<td class=kW>8:1</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>57:37</td><td class=br>+20</td>
<td class=bc>11 - 3 - 5</td>
<td class=br><strong>25</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>To Kahoun ml.</td><td class=kL>2:5 K</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>1:3 K</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kW>7:2 K</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>8:2</td>
<td class=kT>2:2</td>
<td class=kL>3:4 K</td>
<td class=kL>1:3</td>
<td class=kW>6:5</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>5:0 K</td>
<td class=br>62:40</td><td class=br>+22</td>
<td class=bc>10 - 4 - 5</td>
<td class=br><strong>24</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ri Bartošek</td><td class=kL>1:3 K</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3 K</td>
<td class=kT>3:3</td>
<td class=kL>2:7 K</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>7:1</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1 K</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>7:3</td>
<td class=br>57:44</td><td class=br>+13</td>
<td class=bc>9 - 2 - 8</td>
<td class=br><strong>20</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Al Mačynský</td><td class=kT>1:1</td>
<td class=kL>1:2 K</td>
<td class=kL>1:2 K</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>0:1 K</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:2 K</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kW>8:3</td>
<td class=kW>4:1</td>
<td class=br>46:38</td><td class=br>+8</td>
<td class=bc>7 - 4 - 8</td>
<td class=br><strong>18</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Mi Uhlíř</td><td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kW>4:2</td>
<td class=kL>0:3</td>
<td class=kW>5:4</td>
<td class=kL>0:2</td>
<td class=kL>1:7</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>5:2 K</td>
<td class=kL>1:4</td>
<td class=kL>1:3 K</td>
<td class=kT>4:4</td>
<td class=kL>1:2 K</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kW>4:2 K</td>
<td class=kW>5:0</td>
<td class=br>50:57</td><td class=br>-7</td>
<td class=bc>7 - 4 - 8</td>
<td class=br><strong>18</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Mi Franek</td><td class=kL>0:4</td>
<td class=kT>3:3 K</td>
<td class=kL>0:3 K</td>
<td class=kL>4:5</td>
<td class=kW>5:2</td>
<td class=kL>0:5 K</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kL>2:3 K</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>7:6</td>
<td class=kW>1:0</td>
<td class=br>44:51</td><td class=br>-7</td>
<td class=bc>7 - 4 - 8</td>
<td class=br><strong>18</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Lu Varga</td><td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kL>2:5 K</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>1:0 K</td>
<td class=kW>4:2</td>
<td class=kL>4:5 K</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>5:2 K</td>
<td class=kL>3:4</td>
<td class=br>51:52</td><td class=br>-1</td>
<td class=bc>8 - 1 - 10</td>
<td class=br><strong>17</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>To Kahoun st.</td><td class=kL>0:2</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kW>3:2 K</td>
<td class=kL>0:5</td>
<td class=kL>1:8</td>
<td class=kL>2:8</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:3</td>
<td class=kW>6:4</td>
<td class=kW>2:1 K</td>
<td class=kL>2:3 K</td>
<td class=kL>2:8</td>
<td class=kL>1:4 K</td>
<td class=br>51:65</td><td class=br>-14</td>
<td class=bc>8 - 1 - 10</td>
<td class=br><strong>17</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Mi Blažek</td><td class=kL>0:5</td>
<td class=kW>4:3</td>
<td class=kL>0:4</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>3:1 K</td>
<td class=kL>2:4</td>
<td class=kL>0:1 K</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2 K</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>4:3 K</td>
<td class=kT>2:2</td>
<td class=br>39:47</td><td class=br>-8</td>
<td class=bc>6 - 5 - 8</td>
<td class=br><strong>17</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>To Halama</td><td class=kW>4:2 K</td>
<td class=kL>1:5</td>
<td class=kL>4:8</td>
<td class=kL>2:4</td>
<td class=kT>1:1 K</td>
<td class=kL>0:4</td>
<td class=kW>4:3 K</td>
<td class=kL>1:2 K</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kL>4:6</td>
<td class=kW>5:4</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=br>58:64</td><td class=br>-6</td>
<td class=bc>7 - 3 - 9</td>
<td class=br><strong>17</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>An Šurýn</td><td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kW>2:1 K</td>
<td class=kW>3:2</td>
<td class=kW>5:4 K</td>
<td class=kL>4:6</td>
<td class=kT>2:2 K</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>1:4 K</td>
<td class=kW>5:3</td>
<td class=br>35:54</td><td class=br>-19</td>
<td class=bc>6 - 2 - 11</td>
<td class=br><strong>14</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Pa Hráský</td><td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3 K</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>5:6</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2 K</td>
<td class=kL>1:3</td>
<td class=kW>6:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>1:4 K</td>
<td class=kW>6:4</td>
<td class=kW>3:2 K</td>
<td class=br>43:57</td><td class=br>-14</td>
<td class=bc>5 - 3 - 11</td>
<td class=br><strong>13</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Hy Nechutný</td><td class=kL>0:1</td>
<td class=kL>0:1</td>
<td class=kL>0:4</td>
<td class=kL>1:2 K</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kW>3:2 K</td>
<td class=kT>1:1</td>
<td class=kL>4:5</td>
<td class=kW>1:0</td>
<td class=kW>4:1 K</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>0:2 K</td>
<td class=br>28:48</td><td class=br>-20</td>
<td class=bc>4 - 2 - 13</td>
<td class=br><strong>10</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Ja Strmiska</td><td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>3:8</td>
<td class=kL>2:4 K</td>
<td class=kL>6:7</td>
<td class=kL>2:5 K</td>
<td class=kW>8:2</td>
<td class=kL>3:4 K</td>
<td class=kL>1:6</td>
<td class=kW>4:1 K</td>
<td class=kL>4:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=br>52:81</td><td class=br>-29</td>
<td class=bc>3 - 3 - 13</td>
<td class=br><strong>9</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Pa Kocsis</td><td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>0:4 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5</td>
<td class=kL>0:5 K</td>
<td class=kL>3:7</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>0:1</td>
<td class=kW>4:3</td>
<td class=kW>4:1 K</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>2:3 K</td>
<td class=kW>2:0 K</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=br>27:69</td><td class=br>-42</td>
<td class=bc>3 - 2 - 14</td>
<td class=br><strong>8</strong></td><td class=d>20.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Lu Varga</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ja Strmiska</td><td class=bc>-</td><td class=bl>Pa Kocsis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Franek</td><td class=bc>-</td><td class=bl>Ri Bartošek</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ja Strmiska</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Lu Varga</td><td class=bc>-</td><td class=blW>Pa Kocsis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Mi Franek</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=bl>Ri Bartošek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ja Strmiska</td><td class=bc>-</td><td class=blW>Pa Hráský</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Pa Kocsis</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Lu Varga</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Franek</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>Ri Bartošek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ja Strmiska</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Pa Kocsis</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Lu Varga</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=bl>Ri Bartošek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Franek</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>I  Vépy</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>8 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=bl>Pa Kocsis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Lu Varga</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ja Strmiska</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>I  Vépy</td><td class=bc>-</td><td class=bl>Ri Bartošek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Mi Franek</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=bl>I  Vépy</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ri Bartošek</td><td class=bc>-</td><td class=bl>Ja Strmiska</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Lu Varga</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Ja Strmiska</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Mi Franek</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Al Lorand st.</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=bl>I  Vépy</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pa Kocsis</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Pa Kocsis</td><td class=bc>-</td><td class=blW>Al Lorand st.</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>I  Vépy</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ri Bartošek</td><td class=bc>-</td><td class=bl>Lu Varga</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Mi Franek</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pa Kocsis</td><td class=bc>-</td><td class=blW>Mi Franek</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ja Strmiska</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ri Bartošek</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Lu Varga</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pa Kocsis</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Mi Franek</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>I  Vépy</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Lu Varga</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ri Bartošek</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Ja Strmiska</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pa Kocsis</td><td class=bc>-</td><td class=blW>I  Vépy</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Mi Franek</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Al Lorand st.</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Lu Varga</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ri Bartošek</td><td class=bc>-</td><td class=bl>Pa Kocsis</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Ja Strmiska</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Lu Varga</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>I  Vépy</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ri Bartošek</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Franek</td><td class=bc>-</td><td class=bl>Ja Strmiska</td><td class=bc>7 : 6</tr></td>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>I  Vépy</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=bl>Lu Varga</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Mi Franek</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Ja Strmiska</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ri Bartošek</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Pa Kocsis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>8 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Lu Varga</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Mi Franek</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>Ja Strmiska</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>I  Vépy</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ri Bartošek</td><td class=bc>-</td><td class=blW>Pa Hráský</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Pa Kocsis</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>Ja Strmiska</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Mi Franek</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>I  Vépy</td><td class=bc>-</td><td class=bl>Lu Varga</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Pa Kocsis</td><td class=bc>5 : 0 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Pa Hráský</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Ri Bartošek</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>I  Vépy</td><td class=bc>-</td><td class=bl>Ja Strmiska</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Franek</td><td class=bc>-</td><td class=blW>Lu Varga</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Pa Kocsis</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ri Bartošek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>3 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Ví Perkner</td><td class=kx>*</td>
<td class=kL>2:6 + 5:0</td>
<td class=kL>2:5 + 2:2</td>
<td class=kL>2:4 + 1:4</td>
<td class=kW>2:1 + 5:4</td>
<td class=kW>5:3 + 6:0</td>
<td class=kW>4:2 + 3:1</td>
<td class=kT>3:3 + 2:2</td>
<td class=kL>1:2 + 5:2</td>
<td class=kW>4:1 + 1:0</td>
<td class=kW>6:1 + 5:0</td>
<td class=kW>5:0 K + 5:0 K</td>
<td class=br>76:43</td><td class=br>+33</td>
<td class=bc>14 - 3 - 5</td>
<td class=br><strong>31</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Cs Kocsis</td><td class=kW>6:2 + 0:5</td>
<td class=kx>*</td>
<td class=kW>4:2 + 2:2</td>
<td class=kT>3:3 + 3:4</td>
<td class=kW>4:3 + 1:5</td>
<td class=kW>4:3 + 3:5</td>
<td class=kW>3:2 + 4:5</td>
<td class=kL>4:5 + 8:2</td>
<td class=kW>5:2 + 8:2</td>
<td class=kW>6:1 + 5:2</td>
<td class=kW>6:2 + 7:1</td>
<td class=kW>5:0 K + 5:0 K</td>
<td class=br>96:58</td><td class=br>+38</td>
<td class=bc>14 - 2 - 6</td>
<td class=br><strong>30</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Iv Mašková</td><td class=kW>5:2 + 2:2</td>
<td class=kL>2:4 + 2:2</td>
<td class=kx>*</td>
<td class=kL>3:4 + 2:0</td>
<td class=kW>4:2 + 3:2</td>
<td class=kW>2:1 + 3:4</td>
<td class=kW>4:1 + 0:3</td>
<td class=kW>6:0 + 3:2</td>
<td class=kW>6:2 + 8:8</td>
<td class=kL>0:3 + 2:3</td>
<td class=kW>3:1 + 3:1</td>
<td class=kW>5:0 K + 5:0 K</td>
<td class=br>73:47</td><td class=br>+26</td>
<td class=bc>13 - 3 - 6</td>
<td class=br><strong>29</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Pe Fuchs</td><td class=kW>4:2 + 4:1</td>
<td class=kT>3:3 + 4:3</td>
<td class=kW>4:3 + 0:2</td>
<td class=kx>*</td>
<td class=kL>2:5 + 2:5</td>
<td class=kL>1:4 + 3:1</td>
<td class=kW>4:0 + 2:3</td>
<td class=kT>2:2 + 2:2</td>
<td class=kL>1:5 + 4:2</td>
<td class=kW>1:0 + 3:0</td>
<td class=kW>3:2 + 6:0</td>
<td class=kW>5:0 K + 5:0 K</td>
<td class=br>65:45</td><td class=br>+20</td>
<td class=bc>13 - 3 - 6</td>
<td class=br><strong>29</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ra Nevrlík</td><td class=kL>1:2 + 4:5</td>
<td class=kL>3:4 + 5:1</td>
<td class=kL>2:4 + 2:3</td>
<td class=kW>5:2 + 5:2</td>
<td class=kx>*</td>
<td class=kW>3:2 + 3:3</td>
<td class=kW>4:3 + 3:5</td>
<td class=kW>8:4 + 3:3</td>
<td class=kW>6:3 + 10:1</td>
<td class=kW>4:2 + 1:2</td>
<td class=kW>3:0 + 4:0</td>
<td class=kW>5:0 K + 5:0 K</td>
<td class=br>89:51</td><td class=br>+38</td>
<td class=bc>13 - 2 - 7</td>
<td class=br><strong>28</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Vo Bernát</td><td class=kL>3:5 + 0:6</td>
<td class=kL>3:4 + 5:3</td>
<td class=kL>1:2 + 4:3</td>
<td class=kW>4:1 + 1:3</td>
<td class=kL>2:3 + 3:3</td>
<td class=kx>*</td>
<td class=kT>2:2 + 3:3</td>
<td class=kW>3:2 + 5:3</td>
<td class=kL>1:7 + 3:3</td>
<td class=kW>3:1 + 4:0</td>
<td class=kW>6:1 + 10:1</td>
<td class=kW>5:0 K + 5:0 K</td>
<td class=br>76:56</td><td class=br>+20</td>
<td class=bc>11 - 4 - 7</td>
<td class=br><strong>26</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Mi Lévy</td><td class=kL>2:4 + 1:3</td>
<td class=kL>2:3 + 5:4</td>
<td class=kL>1:4 + 3:0</td>
<td class=kL>0:4 + 3:2</td>
<td class=kL>3:4 + 5:3</td>
<td class=kT>2:2 + 3:3</td>
<td class=kx>*</td>
<td class=kT>2:2 + 3:3</td>
<td class=kT>0:0 + 3:0</td>
<td class=kT>2:2 + 5:0</td>
<td class=kW>5:3 + 5:0</td>
<td class=kW>5:0 K + 5:0 K</td>
<td class=br>65:46</td><td class=br>+19</td>
<td class=bc>10 - 6 - 6</td>
<td class=br><strong>26</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ma Klazar</td><td class=kT>3:3 + 2:2</td>
<td class=kW>5:4 + 2:8</td>
<td class=kL>0:6 + 2:3</td>
<td class=kT>2:2 + 2:2</td>
<td class=kL>4:8 + 3:3</td>
<td class=kL>2:3 + 3:5</td>
<td class=kT>2:2 + 3:3</td>
<td class=kx>*</td>
<td class=kW>4:1 + 2:0</td>
<td class=kL>3:4 + 1:1</td>
<td class=kW>7:0 + 4:1</td>
<td class=kW>5:0 K + 5:0 K</td>
<td class=br>66:61</td><td class=br>+5</td>
<td class=bc>7 - 8 - 7</td>
<td class=br><strong>22</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Ma Švik</td><td class=kW>2:1 + 2:5</td>
<td class=kL>2:5 + 2:8</td>
<td class=kL>2:6 + 8:8</td>
<td class=kW>5:1 + 2:4</td>
<td class=kL>3:6 + 1:10</td>
<td class=kW>7:1 + 3:3</td>
<td class=kT>0:0 + 0:3</td>
<td class=kL>1:4 + 0:2</td>
<td class=kx>*</td>
<td class=kW>2:1 + 5:2</td>
<td class=kW>7:0 + 2:1</td>
<td class=kW>5:0 K + 5:0 K</td>
<td class=br>66:71</td><td class=br>-5</td>
<td class=bc>9 - 3 - 10</td>
<td class=br><strong>21</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Jo Perkner</td><td class=kL>1:4 + 0:1</td>
<td class=kL>1:6 + 2:5</td>
<td class=kW>3:0 + 3:2</td>
<td class=kL>0:1 + 0:3</td>
<td class=kL>2:4 + 2:1</td>
<td class=kL>1:3 + 0:4</td>
<td class=kT>2:2 + 0:5</td>
<td class=kW>4:3 + 1:1</td>
<td class=kL>1:2 + 2:5</td>
<td class=kx>*</td>
<td class=kW>3:1 + 1:2</td>
<td class=kW>5:0 K + 5:0 K</td>
<td class=br>39:55</td><td class=br>-16</td>
<td class=bc>7 - 2 - 13</td>
<td class=br><strong>16</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Mi Ptáček</td><td class=kL>1:6 + 0:5</td>
<td class=kL>2:6 + 1:7</td>
<td class=kL>1:3 + 1:3</td>
<td class=kL>2:3 + 0:6</td>
<td class=kL>0:3 + 0:4</td>
<td class=kL>1:6 + 1:10</td>
<td class=kL>3:5 + 0:5</td>
<td class=kL>0:7 + 1:4</td>
<td class=kL>0:7 + 1:2</td>
<td class=kL>1:3 + 2:1</td>
<td class=kx>*</td>
<td class=kW>5:0 K + 5:0 K</td>
<td class=br>28:96</td><td class=br>-68</td>
<td class=bc>3 - 0 - 19</td>
<td class=br><strong>6</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ma Vépy</td><td class=kL>0:5 K + 0:5 K</td>
<td class=kL>0:5 K + 0:5 K</td>
<td class=kL>0:5 K + 0:5 K</td>
<td class=kL>0:5 K + 0:5 K</td>
<td class=kL>0:5 K + 0:5 K</td>
<td class=kL>0:5 K + 0:5 K</td>
<td class=kL>0:5 K + 0:5 K</td>
<td class=kL>0:5 K + 0:5 K</td>
<td class=kL>0:5 K + 0:5 K</td>
<td class=kL>0:5 K + 0:5 K</td>
<td class=kL>0:5 K + 0:5 K</td>
<td class=kx>*</td>
<td class=br>0:110</td><td class=br>-110</td>
<td class=bc>0 - 0 - 22</td>
<td class=br><strong>0</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ra Nevrlík</td><td class=bc>-</td><td class=bl>Mi Ptáček</td><td class=bc>3 : 0 + 4 : 0</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>0 : 3 + 2 : 3</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Cs Kocsis</td><td class=bc>2 : 6 + 5 : 0</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>1 : 4 + 3 : 1</tr></td>
<tr><td class=br>Ma Vépy</td><td class=bc>-</td><td class=blW>Ma Švik</td><td class=bc>0 : 5 K + 0 : 5 K</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>2 : 2 + 3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Mi Ptáček</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>1 : 3 + 2 : 1</tr></td>
<tr><td class=br>Ra Nevrlík</td><td class=bc>-</td><td class=blW>Cs Kocsis</td><td class=bc>3 : 4 + 5 : 1</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>2 : 1 + 3 : 4</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Ma Švik</td><td class=bc>1 : 2 + 5 : 2</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>4 : 0 + 2 : 3</tr></td>
<tr><td class=br>Ma Vépy</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>0 : 5 K + 0 : 5 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Cs Kocsis</td><td class=bc>1 : 6 + 2 : 5</tr></td>
<tr><td class=br>Mi Ptáček</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>1 : 6 + 1 : 10</tr></td>
<tr><td class=brW>Ra Nevrlík</td><td class=bc>-</td><td class=bl>Ma Švik</td><td class=bc>6 : 3 + 10 : 1</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>4 : 1 + 0 : 3</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 3 + 2 : 2</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ma Vépy</td><td class=bc>5 : 0 K + 5 : 0 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Cs Kocsis</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>4 : 3 + 3 : 5</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ma Švik</td><td class=bc>1 : 2 + 2 : 5</tr></td>
<tr><td class=br>Mi Ptáček</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>3 : 5 + 0 : 5</tr></td>
<tr><td class=brW>Ra Nevrlík</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>8 : 4 + 3 : 3</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Ma Vépy</td><td class=bc>5 : 0 K + 5 : 0 K</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 4 + 1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Ma Švik</td><td class=bc>1 : 7 + 3 : 3</tr></td>
<tr><td class=brW>Cs Kocsis</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>3 : 2 + 4 : 5</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>4 : 3 + 1 : 1</tr></td>
<tr><td class=brW>Mi Ptáček</td><td class=bc>-</td><td class=bl>Ma Vépy</td><td class=bc>5 : 0 K + 5 : 0 K</tr></td>
<tr><td class=brW>Ra Nevrlík</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 2 + 5 : 2</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>5 : 2 + 2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ma Švik</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>0 : 0 + 0 : 3</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 2 + 5 : 3</tr></td>
<tr><td class=brW>Cs Kocsis</td><td class=bc>-</td><td class=bl>Ma Vépy</td><td class=bc>5 : 0 K + 5 : 0 K</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>0 : 1 + 0 : 3</tr></td>
<tr><td class=br>Mi Ptáček</td><td class=bc>-</td><td class=blW>Ví Perkner</td><td class=bc>1 : 6 + 0 : 5</tr></td>
<tr><td class=br>Ra Nevrlík</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>2 : 4 + 2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Ma Vépy</td><td class=bc>5 : 0 K + 5 : 0 K</tr></td>
<tr><td class=brW>Ma Švik</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 1 + 2 : 4</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Ví Perkner</td><td class=bc>3 : 5 + 0 : 6</tr></td>
<tr><td class=brW>Cs Kocsis</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>4 : 2 + 2 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ra Nevrlík</td><td class=bc>2 : 4 + 2 : 1</tr></td>
<tr><td class=br>Mi Ptáček</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>2 : 2 + 2 : 2</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Ví Perkner</td><td class=bc>2 : 4 + 1 : 3</tr></td>
<tr><td class=br>Ma Švik</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>2 : 6 + 8 : 8</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Ra Nevrlík</td><td class=bc>2 : 3 + 3 : 3</tr></td>
<tr><td class=brW>Cs Kocsis</td><td class=bc>-</td><td class=bl>Mi Ptáček</td><td class=bc>6 : 2 + 7 : 1</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ma Vépy</td><td class=bc>-</td><td class=blW>Ví Perkner</td><td class=bc>0 : 5 K + 0 : 5 K</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>0 : 6 + 2 : 3</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Ra Nevrlík</td><td class=bc>3 : 4 + 5 : 3</tr></td>
<tr><td class=brW>Ma Švik</td><td class=bc>-</td><td class=bl>Mi Ptáček</td><td class=bc>7 : 0 + 2 : 1</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 1 + 4 : 0</tr></td>
<tr><td class=br>Cs Kocsis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>4 : 3 + 0 : 2</tr></td>
<tr><td class=br>Ma Vépy</td><td class=bc>-</td><td class=blW>Ra Nevrlík</td><td class=bc>0 : 5 K + 0 : 5 K</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Mi Ptáček</td><td class=bc>7 : 0 + 4 : 1</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 2 + 5 : 0</tr></td>
<tr><td class=br>Ma Švik</td><td class=bc>-</td><td class=blW>Cs Kocsis</td><td class=bc>2 : 5 + 2 : 8</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>Ra Nevrlík</td><td class=bc>2 : 1 + 5 : 4</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Mi Ptáček</td><td class=bc>3 : 2 + 6 : 0</tr></td>
<tr><td class=br>Ma Vépy</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>0 : 5 K + 0 : 5 K</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Cs Kocsis</td><td class=bc>5 : 4 + 2 : 8</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>2 : 2 + 3 : 3</tr></td>
<tr><td class=br>Ma Švik</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Mi Ptáček</td><td class=bc>3 : 1 + 3 : 1</tr></td>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 1 + 1 : 0</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>Cs Kocsis</td><td class=bc>3 : 3 + 4 : 3</tr></td>
<tr><td class=br>Ma Vépy</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>0 : 5 K + 0 : 5 K</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ma Švik</td><td class=bc>4 : 1 + 2 : 0</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group D</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Ji Junek</td><td class=kx>*</td>
<td class=kW>6:1 + 1:2</td>
<td class=kW>3:1 + 0:5</td>
<td class=kW>2:1 + 3:0</td>
<td class=kW>3:1 + 3:1</td>
<td class=kW>3:2 + 2:0</td>
<td class=kT>3:3 + 3:2</td>
<td class=kW>5:3 + 7:2</td>
<td class=kW>6:1 + 5:2</td>
<td class=kW>2:1 + 1:8</td>
<td class=kW>4:1 + 9:0</td>
<td class=kW>7:0 + 6:1</td>
<td class=br>84:38</td><td class=br>+46</td>
<td class=bc>18 - 1 - 3</td>
<td class=br><strong>37</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>An Grimová</td><td class=kL>1:6 + 2:1</td>
<td class=kx>*</td>
<td class=kL>0:2 + 3:0</td>
<td class=kW>3:1 + 3:1</td>
<td class=kW>6:1 + 2:1</td>
<td class=kT>5:5 + 3:5</td>
<td class=kW>6:2 + 2:2</td>
<td class=kW>4:3 + 3:1</td>
<td class=kW>5:0 + 5:5</td>
<td class=kW>1:0 + 3:2</td>
<td class=kW>9:4 + 5:1</td>
<td class=kW>8:0 + 7:3</td>
<td class=br>86:46</td><td class=br>+40</td>
<td class=bc>16 - 3 - 3</td>
<td class=br><strong>35</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Pe Klazar</td><td class=kL>1:3 + 5:0</td>
<td class=kW>2:0 + 0:3</td>
<td class=kx>*</td>
<td class=kL>2:8 + 4:2</td>
<td class=kW>6:0 + 3:3</td>
<td class=kL>1:2 + 2:2</td>
<td class=kW>2:1 + 4:2</td>
<td class=kW>5:4 + 4:1</td>
<td class=kL>1:4 + 0:3</td>
<td class=kT>1:1 + 5:0</td>
<td class=kW>9:2 + 6:3</td>
<td class=kW>4:2 + 2:2</td>
<td class=br>69:48</td><td class=br>+21</td>
<td class=bc>12 - 4 - 6</td>
<td class=br><strong>28</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Št Krejzlík</td><td class=kL>1:2 + 0:3</td>
<td class=kL>1:3 + 1:3</td>
<td class=kW>8:2 + 2:4</td>
<td class=kx>*</td>
<td class=kW>3:0 + 2:2</td>
<td class=kT>1:1 + 5:2</td>
<td class=kW>2:0 + 2:1</td>
<td class=kT>3:3 + 3:0</td>
<td class=kL>0:5 + 4:2</td>
<td class=kW>3:0 + 0:0</td>
<td class=kL>2:3 + 6:2</td>
<td class=kW>7:0 + 8:1</td>
<td class=br>64:39</td><td class=br>+25</td>
<td class=bc>11 - 4 - 7</td>
<td class=br><strong>26</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ka Stařecká</td><td class=kL>1:3 + 1:3</td>
<td class=kL>1:6 + 1:2</td>
<td class=kL>0:6 + 3:3</td>
<td class=kL>0:3 + 2:2</td>
<td class=kx>*</td>
<td class=kL>3:4 + 2:1</td>
<td class=kW>4:3 + 3:5</td>
<td class=kW>3:1 + 5:3</td>
<td class=kW>3:2 + 2:6</td>
<td class=kW>3:2 K + 5:0 K</td>
<td class=kW>4:3 + 3:1</td>
<td class=kW>3:0 + 2:1</td>
<td class=br>54:60</td><td class=br>-6</td>
<td class=bc>11 - 2 - 9</td>
<td class=br><strong>24</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Al Pala</td><td class=kL>2:3 + 0:2</td>
<td class=kT>5:5 + 5:3</td>
<td class=kW>2:1 + 2:2</td>
<td class=kT>1:1 + 2:5</td>
<td class=kW>4:3 + 1:2</td>
<td class=kx>*</td>
<td class=kL>2:3 + 1:4</td>
<td class=kT>2:2 + 2:5</td>
<td class=kW>3:1 + 1:6</td>
<td class=kW>3:1 + 1:2</td>
<td class=kW>3:0 + 3:0</td>
<td class=kW>5:2 + 2:0</td>
<td class=br>52:53</td><td class=br>-1</td>
<td class=bc>9 - 4 - 9</td>
<td class=br><strong>22</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Ra Hrnčíř</td><td class=kT>3:3 + 2:3</td>
<td class=kL>2:6 + 2:2</td>
<td class=kL>1:2 + 2:4</td>
<td class=kL>0:2 + 1:2</td>
<td class=kL>3:4 + 5:3</td>
<td class=kW>3:2 + 4:1</td>
<td class=kx>*</td>
<td class=kW>4:1 + 2:2</td>
<td class=kW>4:2 + 5:4</td>
<td class=kT>1:1 + 1:5</td>
<td class=kL>2:3 + 5:3</td>
<td class=kT>1:1 + 3:2</td>
<td class=br>56:58</td><td class=br>-2</td>
<td class=bc>8 - 5 - 9</td>
<td class=br><strong>21</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>To Olšák</td><td class=kL>3:5 + 2:7</td>
<td class=kL>3:4 + 1:3</td>
<td class=kL>4:5 + 1:4</td>
<td class=kT>3:3 + 0:3</td>
<td class=kL>1:3 + 3:5</td>
<td class=kT>2:2 + 5:2</td>
<td class=kL>1:4 + 2:2</td>
<td class=kx>*</td>
<td class=kT>2:2 + 3:2</td>
<td class=kW>3:2 + 3:3</td>
<td class=kT>3:3 + 5:0</td>
<td class=kW>4:2 + 7:0</td>
<td class=br>61:66</td><td class=br>-5</td>
<td class=bc>6 - 6 - 10</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Já Novožil</td><td class=kL>1:6 + 2:5</td>
<td class=kL>0:5 + 5:5</td>
<td class=kW>4:1 + 3:0</td>
<td class=kW>5:0 + 2:4</td>
<td class=kL>2:3 + 6:2</td>
<td class=kL>1:3 + 6:1</td>
<td class=kL>2:4 + 4:5</td>
<td class=kT>2:2 + 2:3</td>
<td class=kx>*</td>
<td class=kT>0:0 + 4:0</td>
<td class=kL>1:2 + 3:1</td>
<td class=kL>2:4 + 3:4</td>
<td class=br>60:60</td><td class=br>0</td>
<td class=bc>7 - 3 - 12</td>
<td class=br><strong>17</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ka Šurýnová</td><td class=kL>1:2 + 8:1</td>
<td class=kL>0:1 + 2:3</td>
<td class=kT>1:1 + 0:5</td>
<td class=kL>0:3 + 0:0</td>
<td class=kL>2:3 K + 0:5 K</td>
<td class=kL>1:3 + 2:1</td>
<td class=kT>1:1 + 5:1</td>
<td class=kL>2:3 + 3:3</td>
<td class=kT>0:0 + 0:4</td>
<td class=kx>*</td>
<td class=kW>3:2 + 3:3</td>
<td class=kL>2:4 + 4:1</td>
<td class=br>40:50</td><td class=br>-10</td>
<td class=bc>5 - 6 - 11</td>
<td class=br><strong>16</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Ja Kutaj</td><td class=kL>1:4 + 0:9</td>
<td class=kL>4:9 + 1:5</td>
<td class=kL>2:9 + 3:6</td>
<td class=kW>3:2 + 2:6</td>
<td class=kL>3:4 + 1:3</td>
<td class=kL>0:3 + 0:3</td>
<td class=kW>3:2 + 3:5</td>
<td class=kT>3:3 + 0:5</td>
<td class=kW>2:1 + 1:3</td>
<td class=kL>2:3 + 3:3</td>
<td class=kx>*</td>
<td class=kW>6:3 + 8:0</td>
<td class=br>51:91</td><td class=br>-40</td>
<td class=bc>5 - 2 - 15</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>To Pětník</td><td class=kL>0:7 + 1:6</td>
<td class=kL>0:8 + 3:7</td>
<td class=kL>2:4 + 2:2</td>
<td class=kL>0:7 + 1:8</td>
<td class=kL>0:3 + 1:2</td>
<td class=kL>2:5 + 0:2</td>
<td class=kT>1:1 + 2:3</td>
<td class=kL>2:4 + 0:7</td>
<td class=kW>4:2 + 4:3</td>
<td class=kW>4:2 + 1:4</td>
<td class=kL>3:6 + 0:8</td>
<td class=kx>*</td>
<td class=br>33:101</td><td class=br>-68</td>
<td class=bc>3 - 2 - 17</td>
<td class=br><strong>8</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ji Junek</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>3 : 1 + 0 : 5</tr></td>
<tr><td class=br>To Olšák</td><td class=bc>-</td><td class=bl>Ja Kutaj</td><td class=bc>3 : 3 + 5 : 0</tr></td>
<tr><td class=brW>Št Krejzlík</td><td class=bc>-</td><td class=bl>To Pětník</td><td class=bc>7 : 0 + 8 : 1</tr></td>
<tr><td class=br>Já Novožil</td><td class=bc>-</td><td class=blW>Al Pala</td><td class=bc>1 : 3 + 6 : 1</tr></td>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Ka Šurýnová</td><td class=bc>1 : 0 + 3 : 2</tr></td>
<tr><td class=brW>Ka Stařecká</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>4 : 3 + 3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>Ja Kutaj</td><td class=bc>9 : 2 + 6 : 3</tr></td>
<tr><td class=brW>Ji Junek</td><td class=bc>-</td><td class=bl>To Pětník</td><td class=bc>7 : 0 + 6 : 1</tr></td>
<tr><td class=br>To Olšák</td><td class=bc>-</td><td class=bl>Al Pala</td><td class=bc>2 : 2 + 5 : 2</tr></td>
<tr><td class=brW>Št Krejzlík</td><td class=bc>-</td><td class=bl>Ka Šurýnová</td><td class=bc>3 : 0 + 0 : 0</tr></td>
<tr><td class=br>Já Novožil</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>2 : 4 + 4 : 5</tr></td>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>6 : 1 + 2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ja Kutaj</td><td class=bc>-</td><td class=bl>To Pětník</td><td class=bc>6 : 3 + 8 : 0</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Al Pala</td><td class=bc>1 : 2 + 2 : 2</tr></td>
<tr><td class=brW>Ji Junek</td><td class=bc>-</td><td class=bl>Ka Šurýnová</td><td class=bc>2 : 1 + 1 : 8</tr></td>
<tr><td class=br>To Olšák</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>1 : 4 + 2 : 2</tr></td>
<tr><td class=brW>Št Krejzlík</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>3 : 0 + 2 : 2</tr></td>
<tr><td class=br>Já Novožil</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>0 : 5 + 5 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>To Pětník</td><td class=bc>-</td><td class=blW>Al Pala</td><td class=bc>2 : 5 + 0 : 2</tr></td>
<tr><td class=br>Ja Kutaj</td><td class=bc>-</td><td class=blW>Ka Šurýnová</td><td class=bc>2 : 3 + 3 : 3</tr></td>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>2 : 1 + 4 : 2</tr></td>
<tr><td class=brW>Ji Junek</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>3 : 1 + 3 : 1</tr></td>
<tr><td class=br>To Olšák</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>3 : 4 + 1 : 3</tr></td>
<tr><td class=br>Št Krejzlík</td><td class=bc>-</td><td class=blW>Já Novožil</td><td class=bc>0 : 5 + 4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Al Pala</td><td class=bc>-</td><td class=bl>Ka Šurýnová</td><td class=bc>3 : 1 + 1 : 2</tr></td>
<tr><td class=br>To Pětník</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>1 : 1 + 2 : 3</tr></td>
<tr><td class=br>Ja Kutaj</td><td class=bc>-</td><td class=blW>Ka Stařecká</td><td class=bc>3 : 4 + 1 : 3</tr></td>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>2 : 0 + 0 : 3</tr></td>
<tr><td class=brW>Ji Junek</td><td class=bc>-</td><td class=bl>Já Novožil</td><td class=bc>6 : 1 + 5 : 2</tr></td>
<tr><td class=br>To Olšák</td><td class=bc>-</td><td class=bl>Št Krejzlík</td><td class=bc>3 : 3 + 0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ka Šurýnová</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>1 : 1 + 5 : 1</tr></td>
<tr><td class=brW>Al Pala</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>4 : 3 + 1 : 2</tr></td>
<tr><td class=br>To Pětník</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>0 : 8 + 3 : 7</tr></td>
<tr><td class=brW>Ja Kutaj</td><td class=bc>-</td><td class=bl>Já Novožil</td><td class=bc>2 : 1 + 1 : 3</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Št Krejzlík</td><td class=bc>2 : 8 + 4 : 2</tr></td>
<tr><td class=brW>Ji Junek</td><td class=bc>-</td><td class=bl>To Olšák</td><td class=bc>5 : 3 + 7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>2 : 6 + 2 : 2</tr></td>
<tr><td class=br>Ka Šurýnová</td><td class=bc>-</td><td class=bl>Já Novožil</td><td class=bc>0 : 0 + 0 : 4</tr></td>
<tr><td class=br>Al Pala</td><td class=bc>-</td><td class=bl>Št Krejzlík</td><td class=bc>1 : 1 + 2 : 5</tr></td>
<tr><td class=br>To Pětník</td><td class=bc>-</td><td class=blW>To Olšák</td><td class=bc>2 : 4 + 0 : 7</tr></td>
<tr><td class=br>Ja Kutaj</td><td class=bc>-</td><td class=blW>Ji Junek</td><td class=bc>1 : 4 + 0 : 9</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ka Stařecká</td><td class=bc>-</td><td class=bl>Já Novožil</td><td class=bc>3 : 2 + 2 : 6</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Št Krejzlík</td><td class=bc>0 : 2 + 1 : 2</tr></td>
<tr><td class=br>Ka Šurýnová</td><td class=bc>-</td><td class=blW>To Olšák</td><td class=bc>2 : 3 + 3 : 3</tr></td>
<tr><td class=br>Al Pala</td><td class=bc>-</td><td class=blW>Ji Junek</td><td class=bc>2 : 3 + 0 : 2</tr></td>
<tr><td class=br>To Pětník</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>2 : 4 + 2 : 2</tr></td>
<tr><td class=br>Ja Kutaj</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Št Krejzlík</td><td class=bc>3 : 1 + 3 : 1</tr></td>
<tr><td class=brW>Ka Stařecká</td><td class=bc>-</td><td class=bl>To Olšák</td><td class=bc>3 : 1 + 5 : 3</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Ji Junek</td><td class=bc>3 : 3 + 2 : 3</tr></td>
<tr><td class=br>Ka Šurýnová</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>1 : 1 + 0 : 5</tr></td>
<tr><td class=brW>Al Pala</td><td class=bc>-</td><td class=bl>Ja Kutaj</td><td class=bc>3 : 0 + 3 : 0</tr></td>
<tr><td class=br>To Pětník</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Já Novožil</td><td class=bc>-</td><td class=bl>To Olšák</td><td class=bc>2 : 2 + 2 : 3</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ji Junek</td><td class=bc>1 : 6 + 2 : 1</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>0 : 6 + 3 : 3</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ja Kutaj</td><td class=bc>2 : 3 + 5 : 3</tr></td>
<tr><td class=br>Ka Šurýnová</td><td class=bc>-</td><td class=blW>To Pětník</td><td class=bc>2 : 4 + 4 : 1</tr></td>
<tr><td class=br>Al Pala</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Št Krejzlík</td><td class=bc>-</td><td class=blW>Ji Junek</td><td class=bc>1 : 2 + 0 : 3</tr></td>
<tr><td class=brW>Já Novožil</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 1 + 3 : 0</tr></td>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Ja Kutaj</td><td class=bc>9 : 4 + 5 : 1</tr></td>
<tr><td class=brW>Ka Stařecká</td><td class=bc>-</td><td class=bl>To Pětník</td><td class=bc>3 : 0 + 2 : 1</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Al Pala</td><td class=bc>3 : 2 + 4 : 1</tr></td>
<tr><td class=br>Ka Šurýnová</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>To Olšák</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>4 : 5 + 1 : 4</tr></td>
<tr><td class=br>Št Krejzlík</td><td class=bc>-</td><td class=blW>Ja Kutaj</td><td class=bc>2 : 3 + 6 : 2</tr></td>
<tr><td class=br>Já Novožil</td><td class=bc>-</td><td class=blW>To Pětník</td><td class=bc>2 : 4 + 3 : 4</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=bl>Al Pala</td><td class=bc>5 : 5 + 3 : 5</tr></td>
<tr><td class=brW>Ka Stařecká</td><td class=bc>-</td><td class=bl>Ka Šurýnová</td><td class=bc>3 : 2 K + 5 : 0 K</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
