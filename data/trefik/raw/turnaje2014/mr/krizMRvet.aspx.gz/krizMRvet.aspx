<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN">
<html lang="cz">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<title>MR, Jihlava</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
</head>
<body class="neop">
<a name="Zac"><p class=l>MR veteránů, Jihlava, 1. června 2014</p></a>
<div align=center><p><a href="index.aspx">Back</a></p></div>
<p class=vm>Basic groups</p>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=2 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=ir>1</td><td class=kt>P.Turoň</td><td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kW>7:3</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=br>73:26</td><td class=br>+47</td>
<td class=bc>14 - 3 - 1</td>
<td class=br>31</td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=ir>2</td><td class=kt>P.Plešák</td><td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>7:2</td>
<td class=kW>6:4</td>
<td class=kW>7:0</td>
<td class=kW>11:2</td>
<td class=kW>6:4</td>
<td class=kW>2:0</td>
<td class=kW>7:1</td>
<td class=br>92:36</td><td class=br>+56</td>
<td class=bc>13 - 4 - 1</td>
<td class=br>30</td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=ir>3</td><td class=kt>D.Matýsek</td><td class=kL>0:2</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kW>6:3</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=br>54:27</td><td class=br>+27</td>
<td class=bc>14 - 1 - 3</td>
<td class=br>29</td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=ir>4</td><td class=kt>A.Fiala</td><td class=kL>3:7</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>1:7</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kW>8:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=kW>6:4</td>
<td class=kW>6:0</td>
<td class=kW>7:4</td>
<td class=kW>1:0</td>
<td class=kW>7:1</td>
<td class=br>74:44</td><td class=br>+30</td>
<td class=bc>12 - 2 - 4</td>
<td class=br>26</td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=ir>5</td><td class=kt>Z.Matoušek st.</td><td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kW>7:1</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kT>0:0</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=br>53:41</td><td class=br>+12</td>
<td class=bc>11 - 3 - 4</td>
<td class=br>25</td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=ir>6</td><td class=kt>A.Šrajer</td><td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>5:2</td>
<td class=kT>0:0</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kW>7:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=br>61:37</td><td class=br>+24</td>
<td class=bc>10 - 4 - 4</td>
<td class=br>24</td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=ir>7</td><td class=kt>R.Jež</td><td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kL>0:1</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>8:2</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=br>47:29</td><td class=br>+18</td>
<td class=bc>11 - 2 - 5</td>
<td class=br>24</td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=ir>8</td><td class=kt>V.Pikl</td><td class=kL>3:6</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>4:6</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=br>64:38</td><td class=br>+26</td>
<td class=bc>11 - 2 - 5</td>
<td class=br>24</td><td class=d>8.</td>
</tr><tr><td class=ir>J</td><td class=ir>9</td><td class=kt>D.Cibulka</td><td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kL>1:8</td>
<td class=kT>4:4</td>
<td class=kT>0:0</td>
<td class=kL>1:3</td>
<td class=kW>6:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=br>58:42</td><td class=br>+16</td>
<td class=bc>9 - 5 - 4</td>
<td class=br>23</td><td class=d>9.</td>
</tr><tr><td class=ir>J</td><td class=ir>10</td><td class=kt>T.Kahoun st.</td><td class=kL>4:5</td>
<td class=kL>1:7</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=br>46:53</td><td class=br>-7</td>
<td class=bc>8 - 2 - 8</td>
<td class=br>18</td><td class=d>10.</td>
</tr><tr><td class=ir>J</td><td class=ir>11</td><td class=kt>M.Ševr</td><td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>8:1</td>
<td class=kL>4:6</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=br>50:49</td><td class=br>+1</td>
<td class=bc>9 - 0 - 9</td>
<td class=br>18</td><td class=d>11.</td>
</tr><tr><td class=ir>J</td><td class=ir>12</td><td class=kt>F.Marek</td><td class=kW>2:1</td>
<td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>2:7</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=br>41:56</td><td class=br>-15</td>
<td class=bc>7 - 1 - 10</td>
<td class=br>15</td><td class=d>12.</td>
</tr><tr><td class=ir>J</td><td class=ir>13</td><td class=kt>Z.Lopaur</td><td class=kL>0:5</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>2:8</td>
<td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>7:2</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=kW>6:4</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=br>46:65</td><td class=br>-19</td>
<td class=bc>5 - 1 - 12</td>
<td class=br>11</td><td class=d>13.</td>
</tr><tr><td class=ir>J</td><td class=ir>14</td><td class=kt>S.Suchý</td><td class=kL>0:2</td>
<td class=kL>4:6</td>
<td class=kT>1:1</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kW>1:0</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=br>30:61</td><td class=br>-31</td>
<td class=bc>2 - 5 - 11</td>
<td class=br>9</td><td class=d>14.</td>
</tr><tr><td class=ir>J</td><td class=ir>15</td><td class=kt>J.Malík</td><td class=kL>1:6</td>
<td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kL>4:6</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:8</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=br>30:73</td><td class=br>-43</td>
<td class=bc>3 - 2 - 13</td>
<td class=br>8</td><td class=d>15.</td>
</tr><tr><td class=ir>J</td><td class=ir>16</td><td class=kt>J.Petr</td><td class=kL>0:7</td>
<td class=kL>2:11</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>6:4</td>
<td class=kL>3:4</td>
<td class=kL>0:8</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=br>32:77</td><td class=br>-45</td>
<td class=bc>3 - 2 - 13</td>
<td class=br>8</td><td class=d>16.</td>
</tr><tr><td class=ir>J</td><td class=ir>17</td><td class=kt>T.Halama</td><td class=kL>2:5</td>
<td class=kL>4:6</td>
<td class=kL>1:2</td>
<td class=kL>4:7</td>
<td class=kT>0:0</td>
<td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>4:6</td>
<td class=kW>4:1</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=br>48:67</td><td class=br>-19</td>
<td class=bc>3 - 2 - 13</td>
<td class=br>8</td><td class=d>17.</td>
</tr><tr><td class=ir>J</td><td class=ir>18</td><td class=kt>A.Šurýn</td><td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>0:5 K</td>
<td class=br>18:50</td><td class=br>-32</td>
<td class=bc>1 - 4 - 13</td>
<td class=br>6</td><td class=d>18.</td>
</tr><tr><td class=ir>J</td><td class=ir>19</td><td class=kt>P.Sládek</td><td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kL>0:2</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>0:2</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kW>5:0 K</td>
<td class=kx>*</td>
<td class=br>26:72</td><td class=br>-46</td>
<td class=bc>1 - 3 - 14</td>
<td class=br>5</td><td class=d>19.</td>
</tr></table></td></tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>P.Turoň</td><td class=bc>-</td><td class=bl>J.Malík</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>P.Plešák</td><td class=bc>-</td><td class=bl>J.Petr</td><td class=bc>11 : 2</tr></td>
<tr><td class=brW>V.Pikl</td><td class=bc>-</td><td class=bl>T.Kahoun st.</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>D.Matýsek</td><td class=bc>-</td><td class=bl>T.Halama</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>R.Jež</td><td class=bc>-</td><td class=bl>P.Sládek</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>M.Ševr</td><td class=bc>-</td><td class=bl>F.Marek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>A.Šrajer</td><td class=bc>-</td><td class=bl>Z.Matoušek st.</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>D.Cibulka</td><td class=bc>-</td><td class=blW>A.Fiala</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>A.Šurýn</td><td class=bc>-</td><td class=bl>S.Suchý</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>J.Malík</td><td class=bc>-</td><td class=bl>J.Petr</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>P.Turoň</td><td class=bc>-</td><td class=bl>T.Kahoun st.</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>P.Plešák</td><td class=bc>-</td><td class=bl>T.Halama</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>V.Pikl</td><td class=bc>-</td><td class=bl>P.Sládek</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>D.Matýsek</td><td class=bc>-</td><td class=bl>F.Marek</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>R.Jež</td><td class=bc>-</td><td class=bl>Z.Matoušek st.</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>M.Ševr</td><td class=bc>-</td><td class=blW>A.Fiala</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>A.Šrajer</td><td class=bc>-</td><td class=bl>S.Suchý</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>D.Cibulka</td><td class=bc>-</td><td class=bl>Z.Lopaur</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>J.Petr</td><td class=bc>-</td><td class=blW>T.Kahoun st.</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>J.Malík</td><td class=bc>-</td><td class=bl>T.Halama</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>P.Turoň</td><td class=bc>-</td><td class=bl>P.Sládek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>P.Plešák</td><td class=bc>-</td><td class=bl>F.Marek</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>V.Pikl</td><td class=bc>-</td><td class=blW>Z.Matoušek st.</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>D.Matýsek</td><td class=bc>-</td><td class=bl>A.Fiala</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>R.Jež</td><td class=bc>-</td><td class=bl>S.Suchý</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>M.Ševr</td><td class=bc>-</td><td class=bl>Z.Lopaur</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>A.Šrajer</td><td class=bc>-</td><td class=bl>A.Šurýn</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>T.Kahoun st.</td><td class=bc>-</td><td class=bl>T.Halama</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>J.Petr</td><td class=bc>-</td><td class=bl>P.Sládek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>J.Malík</td><td class=bc>-</td><td class=blW>F.Marek</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>P.Turoň</td><td class=bc>-</td><td class=bl>Z.Matoušek st.</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>P.Plešák</td><td class=bc>-</td><td class=bl>A.Fiala</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>V.Pikl</td><td class=bc>-</td><td class=bl>S.Suchý</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>D.Matýsek</td><td class=bc>-</td><td class=bl>Z.Lopaur</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>R.Jež</td><td class=bc>-</td><td class=bl>A.Šurýn</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>M.Ševr</td><td class=bc>-</td><td class=bl>D.Cibulka</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>T.Halama</td><td class=bc>-</td><td class=bl>P.Sládek</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>T.Kahoun st.</td><td class=bc>-</td><td class=blW>F.Marek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>J.Petr</td><td class=bc>-</td><td class=blW>Z.Matoušek st.</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>J.Malík</td><td class=bc>-</td><td class=blW>A.Fiala</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>P.Turoň</td><td class=bc>-</td><td class=bl>S.Suchý</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>P.Plešák</td><td class=bc>-</td><td class=bl>Z.Lopaur</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>V.Pikl</td><td class=bc>-</td><td class=bl>A.Šurýn</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>D.Matýsek</td><td class=bc>-</td><td class=bl>D.Cibulka</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>R.Jež</td><td class=bc>-</td><td class=blW>A.Šrajer</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>P.Sládek</td><td class=bc>-</td><td class=bl>F.Marek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>T.Halama</td><td class=bc>-</td><td class=bl>Z.Matoušek st.</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>T.Kahoun st.</td><td class=bc>-</td><td class=blW>A.Fiala</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>J.Petr</td><td class=bc>-</td><td class=bl>S.Suchý</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>J.Malík</td><td class=bc>-</td><td class=blW>Z.Lopaur</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>P.Turoň</td><td class=bc>-</td><td class=bl>A.Šurýn</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>P.Plešák</td><td class=bc>-</td><td class=bl>D.Cibulka</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>V.Pikl</td><td class=bc>-</td><td class=blW>A.Šrajer</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>D.Matýsek</td><td class=bc>-</td><td class=bl>M.Ševr</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>F.Marek</td><td class=bc>-</td><td class=blW>Z.Matoušek st.</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>P.Sládek</td><td class=bc>-</td><td class=blW>A.Fiala</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>T.Halama</td><td class=bc>-</td><td class=bl>S.Suchý</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>T.Kahoun st.</td><td class=bc>-</td><td class=bl>Z.Lopaur</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>J.Petr</td><td class=bc>-</td><td class=bl>A.Šurýn</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>J.Malík</td><td class=bc>-</td><td class=blW>D.Cibulka</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>P.Turoň</td><td class=bc>-</td><td class=bl>A.Šrajer</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>P.Plešák</td><td class=bc>-</td><td class=bl>M.Ševr</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>V.Pikl</td><td class=bc>-</td><td class=blW>R.Jež</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Z.Matoušek st.</td><td class=bc>-</td><td class=bl>A.Fiala</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>F.Marek</td><td class=bc>-</td><td class=bl>S.Suchý</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>P.Sládek</td><td class=bc>-</td><td class=bl>Z.Lopaur</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>T.Halama</td><td class=bc>-</td><td class=bl>A.Šurýn</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>T.Kahoun st.</td><td class=bc>-</td><td class=bl>D.Cibulka</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>J.Petr</td><td class=bc>-</td><td class=blW>A.Šrajer</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>J.Malík</td><td class=bc>-</td><td class=blW>M.Ševr</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>P.Turoň</td><td class=bc>-</td><td class=bl>R.Jež</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>P.Plešák</td><td class=bc>-</td><td class=bl>D.Matýsek</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>A.Fiala</td><td class=bc>-</td><td class=bl>S.Suchý</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Z.Matoušek st.</td><td class=bc>-</td><td class=bl>Z.Lopaur</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>F.Marek</td><td class=bc>-</td><td class=bl>A.Šurýn</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>P.Sládek</td><td class=bc>-</td><td class=blW>D.Cibulka</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>T.Halama</td><td class=bc>-</td><td class=blW>A.Šrajer</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>T.Kahoun st.</td><td class=bc>-</td><td class=bl>M.Ševr</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>J.Petr</td><td class=bc>-</td><td class=blW>R.Jež</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>J.Malík</td><td class=bc>-</td><td class=blW>D.Matýsek</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>P.Turoň</td><td class=bc>-</td><td class=bl>V.Pikl</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>S.Suchý</td><td class=bc>-</td><td class=blW>Z.Lopaur</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>A.Fiala</td><td class=bc>-</td><td class=bl>A.Šurýn</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Z.Matoušek st.</td><td class=bc>-</td><td class=bl>D.Cibulka</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>F.Marek</td><td class=bc>-</td><td class=blW>A.Šrajer</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>P.Sládek</td><td class=bc>-</td><td class=blW>M.Ševr</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>T.Halama</td><td class=bc>-</td><td class=blW>R.Jež</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>T.Kahoun st.</td><td class=bc>-</td><td class=blW>D.Matýsek</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>J.Petr</td><td class=bc>-</td><td class=blW>V.Pikl</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>J.Malík</td><td class=bc>-</td><td class=blW>P.Plešák</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Z.Lopaur</td><td class=bc>-</td><td class=blW>A.Šurýn</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>S.Suchý</td><td class=bc>-</td><td class=blW>D.Cibulka</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>A.Fiala</td><td class=bc>-</td><td class=bl>A.Šrajer</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Z.Matoušek st.</td><td class=bc>-</td><td class=bl>M.Ševr</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>F.Marek</td><td class=bc>-</td><td class=blW>R.Jež</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>P.Sládek</td><td class=bc>-</td><td class=blW>D.Matýsek</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>T.Halama</td><td class=bc>-</td><td class=blW>V.Pikl</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>T.Kahoun st.</td><td class=bc>-</td><td class=blW>P.Plešák</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>J.Petr</td><td class=bc>-</td><td class=blW>P.Turoň</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>A.Šurýn</td><td class=bc>-</td><td class=blW>D.Cibulka</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Z.Lopaur</td><td class=bc>-</td><td class=blW>A.Šrajer</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>S.Suchý</td><td class=bc>-</td><td class=blW>M.Ševr</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>A.Fiala</td><td class=bc>-</td><td class=bl>R.Jež</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Z.Matoušek st.</td><td class=bc>-</td><td class=blW>D.Matýsek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>F.Marek</td><td class=bc>-</td><td class=blW>V.Pikl</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>P.Sládek</td><td class=bc>-</td><td class=blW>P.Plešák</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>T.Halama</td><td class=bc>-</td><td class=blW>P.Turoň</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>T.Kahoun st.</td><td class=bc>-</td><td class=bl>J.Malík</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>D.Cibulka</td><td class=bc>-</td><td class=bl>A.Šrajer</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>A.Šurýn</td><td class=bc>-</td><td class=blW>M.Ševr</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Z.Lopaur</td><td class=bc>-</td><td class=blW>R.Jež</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>S.Suchý</td><td class=bc>-</td><td class=bl>D.Matýsek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>A.Fiala</td><td class=bc>-</td><td class=bl>V.Pikl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Z.Matoušek st.</td><td class=bc>-</td><td class=bl>P.Plešák</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>F.Marek</td><td class=bc>-</td><td class=bl>P.Turoň</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>P.Sládek</td><td class=bc>-</td><td class=bl>J.Malík</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>T.Halama</td><td class=bc>-</td><td class=blW>J.Petr</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>A.Šrajer</td><td class=bc>-</td><td class=blW>M.Ševr</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>D.Cibulka</td><td class=bc>-</td><td class=blW>R.Jež</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>A.Šurýn</td><td class=bc>-</td><td class=blW>D.Matýsek</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Z.Lopaur</td><td class=bc>-</td><td class=blW>V.Pikl</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>S.Suchý</td><td class=bc>-</td><td class=blW>P.Plešák</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>A.Fiala</td><td class=bc>-</td><td class=blW>P.Turoň</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Z.Matoušek st.</td><td class=bc>-</td><td class=bl>J.Malík</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>F.Marek</td><td class=bc>-</td><td class=bl>J.Petr</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>P.Sládek</td><td class=bc>-</td><td class=blW>T.Kahoun st.</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>M.Ševr</td><td class=bc>-</td><td class=blW>R.Jež</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>A.Šrajer</td><td class=bc>-</td><td class=blW>D.Matýsek</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>D.Cibulka</td><td class=bc>-</td><td class=bl>V.Pikl</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>A.Šurýn</td><td class=bc>-</td><td class=blW>P.Plešák</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Z.Lopaur</td><td class=bc>-</td><td class=blW>P.Turoň</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>S.Suchý</td><td class=bc>-</td><td class=blW>J.Malík</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>A.Fiala</td><td class=bc>-</td><td class=bl>J.Petr</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Z.Matoušek st.</td><td class=bc>-</td><td class=bl>T.Kahoun st.</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>F.Marek</td><td class=bc>-</td><td class=bl>T.Halama</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>R.Jež</td><td class=bc>-</td><td class=blW>D.Matýsek</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>M.Ševr</td><td class=bc>-</td><td class=blW>V.Pikl</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>A.Šrajer</td><td class=bc>-</td><td class=bl>P.Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>D.Cibulka</td><td class=bc>-</td><td class=bl>P.Turoň</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>A.Šurýn</td><td class=bc>-</td><td class=bl>J.Malík</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Z.Lopaur</td><td class=bc>-</td><td class=bl>J.Petr</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>S.Suchý</td><td class=bc>-</td><td class=bl>T.Kahoun st.</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>A.Fiala</td><td class=bc>-</td><td class=bl>T.Halama</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Z.Matoušek st.</td><td class=bc>-</td><td class=bl>P.Sládek</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>D.Matýsek</td><td class=bc>-</td><td class=blW>V.Pikl</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>R.Jež</td><td class=bc>-</td><td class=blW>P.Plešák</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>M.Ševr</td><td class=bc>-</td><td class=blW>P.Turoň</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>A.Šrajer</td><td class=bc>-</td><td class=bl>J.Malík</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>D.Cibulka</td><td class=bc>-</td><td class=bl>J.Petr</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>A.Šurýn</td><td class=bc>-</td><td class=blW>T.Kahoun st.</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Z.Lopaur</td><td class=bc>-</td><td class=bl>T.Halama</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>S.Suchý</td><td class=bc>-</td><td class=bl>P.Sládek</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>A.Fiala</td><td class=bc>-</td><td class=bl>F.Marek</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>V.Pikl</td><td class=bc>-</td><td class=bl>P.Plešák</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>D.Matýsek</td><td class=bc>-</td><td class=blW>P.Turoň</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>R.Jež</td><td class=bc>-</td><td class=bl>J.Malík</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>M.Ševr</td><td class=bc>-</td><td class=blW>J.Petr</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>A.Šrajer</td><td class=bc>-</td><td class=blW>T.Kahoun st.</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>D.Cibulka</td><td class=bc>-</td><td class=bl>T.Halama</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>A.Šurýn</td><td class=bc>-</td><td class=blW>P.Sládek</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Z.Lopaur</td><td class=bc>-</td><td class=bl>F.Marek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>S.Suchý</td><td class=bc>-</td><td class=blW>Z.Matoušek st.</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>P.Plešák</td><td class=bc>-</td><td class=bl>P.Turoň</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>V.Pikl</td><td class=bc>-</td><td class=bl>J.Malík</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>D.Matýsek</td><td class=bc>-</td><td class=bl>J.Petr</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>R.Jež</td><td class=bc>-</td><td class=blW>T.Kahoun st.</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>M.Ševr</td><td class=bc>-</td><td class=bl>T.Halama</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>A.Šrajer</td><td class=bc>-</td><td class=bl>P.Sládek</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>D.Cibulka</td><td class=bc>-</td><td class=bl>F.Marek</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>A.Šurýn</td><td class=bc>-</td><td class=blW>Z.Matoušek st.</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Z.Lopaur</td><td class=bc>-</td><td class=blW>A.Fiala</td><td class=bc>1 : 7</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>


<p class=v>Play-off<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><th colspan=11><font size="+1"><strong>Finále</strong></font></th></tr>
<tr><td class=br>Pikl Václav&nbsp;&nbsp;</td>
<td class=bl><b>- Plešák Pavel</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;1 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:8&nbsp;&nbsp;</td>
<td class=bl>1:3&nbsp;&nbsp;</td>
<td class=bl>4:2&nbsp;&nbsp;</td>
<td class=bl>0:5&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>Semifinále</strong></font></th></tr>
<tr><td class=ar><b>Pikl Václav</b>&nbsp;&nbsp;</td>
<td class=al>- Matoušek st. Zdeněk&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 1&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:2 P&nbsp;&nbsp;</td>
<td class=al>2:4&nbsp;&nbsp;</td>
<td class=al>4:1&nbsp;&nbsp;</td>
<td class=al>4:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><b>Plešák Pavel</b>&nbsp;&nbsp;</td>
<td class=bl>- Šrajer Antonín&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:3 P&nbsp;&nbsp;</td>
<td class=bl>5:1&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>O 3.místo</strong></font></th></tr>
<tr><td class=ar><b>Šrajer Antonín</b>&nbsp;&nbsp;</td>
<td class=al>- Matoušek st. Zdeněk&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:2 P&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>5:0&nbsp;&nbsp;</td>
<td class=al>1:2&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>Čtvrtfinále</strong></font></th></tr>
<tr><td class=br>Turoň Petr&nbsp;&nbsp;</td>
<td class=bl><b>- Pikl Václav</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:3&nbsp;&nbsp;</td>
<td class=bl>1:2 P&nbsp;&nbsp;</td>
<td class=bl>1:3&nbsp;&nbsp;</td>
<td class=bl>7:1&nbsp;&nbsp;</td>
<td class=bl>1:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Plešák Pavel</b>&nbsp;&nbsp;</td>
<td class=al>- Jež Robert&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>6:0&nbsp;&nbsp;</td>
<td class=al>6:1&nbsp;&nbsp;</td>
<td class=al>8:3&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br>Matýsek Daniel&nbsp;&nbsp;</td>
<td class=bl><b>- Šrajer Antonín</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>5:1&nbsp;&nbsp;</td>
<td class=bl>1:4&nbsp;&nbsp;</td>
<td class=bl>2:6&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>1:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar>Fiala Aleš&nbsp;&nbsp;</td>
<td class=al><b>- Matoušek st. Zdeněk</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;1 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:5&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>3:1&nbsp;&nbsp;</td>
<td class=al>2:5&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr></table></td></tr></table></div></p>


<p class=v>Konečné pořadí turnaje<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>Z</th>
<th>+</th>
<th>=</th>
<th>-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>B</th>
<th></th>
<th>&nbsp;</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al>Plešák Pavel</td>
<td class=al>APP Gladiators Plzeň</td>
<td class=ar>28</td>
<td class=ar>22</td>
<td class=ar>4</td>
<td class=ar>2</td>
<td class=ar>142</td>
<td class=al>: 53</td>
<td class=ar>48</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>2.</td>
<td class=bl>Pikl Václav</td>
<td class=bl>THC Stiga Elites</td>
<td class=br>31</td>
<td class=br>18</td>
<td class=br>2</td>
<td class=br>11</td>
<td class=br>96</td>
<td class=bl>: 79</td>
<td class=br>38</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>3.</td>
<td class=al>Šrajer Antonín</td>
<td class=al>THC Stiga Elites</td>
<td class=ar>31</td>
<td class=ar>16</td>
<td class=ar>4</td>
<td class=ar>11</td>
<td class=ar>96</td>
<td class=al>: 70</td>
<td class=ar>36</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>4.</td>
<td class=bl>Matoušek st. Zdeněk</td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>31</td>
<td class=br>17</td>
<td class=br>3</td>
<td class=br>11</td>
<td class=br>85</td>
<td class=bl>: 78</td>
<td class=br>37</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>5.</td>
<td class=al>Matýsek Daniel</td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>23</td>
<td class=ar>16</td>
<td class=ar>1</td>
<td class=ar>6</td>
<td class=ar>66</td>
<td class=al>: 42</td>
<td class=ar>33</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>6.</td>
<td class=bl>Turoň Petr</td>
<td class=bl>THC Třinec</td>
<td class=br>23</td>
<td class=br>16</td>
<td class=br>3</td>
<td class=br>4</td>
<td class=br>87</td>
<td class=bl>: 38</td>
<td class=br>35</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>7.</td>
<td class=al>Fiala Aleš</td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>22</td>
<td class=ar>13</td>
<td class=ar>2</td>
<td class=ar>7</td>
<td class=ar>84</td>
<td class=al>: 58</td>
<td class=ar>28</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>8.</td>
<td class=bl>Jež Robert</td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>21</td>
<td class=br>11</td>
<td class=br>2</td>
<td class=br>8</td>
<td class=br>51</td>
<td class=bl>: 49</td>
<td class=br>24</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>9.</td>
<td class=al>Cibulka David</td>
<td class=al>THC Třinec</td>
<td class=ar>18</td>
<td class=ar>9</td>
<td class=ar>5</td>
<td class=ar>4</td>
<td class=ar>58</td>
<td class=al>: 42</td>
<td class=ar>23</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>10.</td>
<td class=bl>Kahoun st. Tomáš</td>
<td class=bl>Pelhřimov</td>
<td class=br>18</td>
<td class=br>8</td>
<td class=br>2</td>
<td class=br>8</td>
<td class=br>46</td>
<td class=bl>: 53</td>
<td class=br>18</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>11.</td>
<td class=al>Ševr Miloš</td>
<td class=al>THC Stiga Elites</td>
<td class=ar>18</td>
<td class=ar>9</td>
<td class=ar>0</td>
<td class=ar>9</td>
<td class=ar>50</td>
<td class=al>: 49</td>
<td class=ar>18</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>12.</td>
<td class=bl>Marek František</td>
<td class=bl>BSE České Budějovice</td>
<td class=br>18</td>
<td class=br>7</td>
<td class=br>1</td>
<td class=br>10</td>
<td class=br>41</td>
<td class=bl>: 56</td>
<td class=br>15</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>13.</td>
<td class=al>Lopaur Zdeněk</td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>18</td>
<td class=ar>5</td>
<td class=ar>1</td>
<td class=ar>12</td>
<td class=ar>46</td>
<td class=al>: 65</td>
<td class=ar>11</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>14.</td>
<td class=bl>Suchý Stanislav</td>
<td class=bl>Big Band</td>
<td class=br>18</td>
<td class=br>2</td>
<td class=br>5</td>
<td class=br>11</td>
<td class=br>30</td>
<td class=bl>: 61</td>
<td class=br>9</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>15.</td>
<td class=al>Malík Jiří</td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>18</td>
<td class=ar>3</td>
<td class=ar>2</td>
<td class=ar>13</td>
<td class=ar>30</td>
<td class=al>: 73</td>
<td class=ar>8</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>16.</td>
<td class=bl>Petr Jindřich</td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>18</td>
<td class=br>3</td>
<td class=br>2</td>
<td class=br>13</td>
<td class=br>32</td>
<td class=bl>: 77</td>
<td class=br>8</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>17.</td>
<td class=al>Halama Tomáš</td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>18</td>
<td class=ar>3</td>
<td class=ar>2</td>
<td class=ar>13</td>
<td class=ar>48</td>
<td class=al>: 67</td>
<td class=ar>8</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>18.</td>
<td class=bl>Šurýn Antonín</td>
<td class=bl>Big Band</td>
<td class=br>17</td>
<td class=br>1</td>
<td class=br>4</td>
<td class=br>12</td>
<td class=br>18</td>
<td class=bl>: 45</td>
<td class=br>6</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>19.</td>
<td class=al>Sládek Petr</td>
<td class=al>THC Stiga Elites</td>
<td class=ar>17</td>
<td class=ar>0</td>
<td class=ar>3</td>
<td class=ar>14</td>
<td class=ar>21</td>
<td class=al>: 72</td>
<td class=ar>3</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr></table></td></tr></table></div></p>


</body></html>