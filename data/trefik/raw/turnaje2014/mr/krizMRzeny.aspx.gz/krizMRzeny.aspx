<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN">
<html lang="cz">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<title>MR, Jihlava</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
</head>
<body class="neop">
<a name="Zac"><p class=l>MR ženy, Jihlava, 1. června 2014</p></a>
<div align=center><p><a href="index.aspx">Back</a></p></div>
<p class=vm>Skupina</p>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=2 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=ir>1</td><td class=kt>A.Jackowská</td><td class=kx>*</td>
<td class=kW>2:1 + 6:3 + 2:5</td>
<td class=kW>4:2 + 3:3 + 3:1</td>
<td class=br>20:15</td><td class=br>+5</td>
<td class=bc>4 - 1 - 1</td>
<td class=br>9</td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=ir>2</td><td class=kt>I.Mašková</td><td class=kL>1:2 + 3:6 + 5:2</td>
<td class=kx>*</td>
<td class=kT>2:2 + 2:3 + 9:3</td>
<td class=br>22:18</td><td class=br>+4</td>
<td class=bc>2 - 1 - 3</td>
<td class=br>5</td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=ir>3</td><td class=kt>B.Petrová</td><td class=kL>2:4 + 3:3 + 1:3</td>
<td class=kT>2:2 + 3:2 + 3:9</td>
<td class=kx>*</td>
<td class=br>14:23</td><td class=br>-9</td>
<td class=bc>1 - 2 - 3</td>
<td class=br>4</td><td class=d>3.</td>
</tr></table></td></tr></table></div></p>

<hr>
<p class=vm>Playoff</p>
<p class=v>Semifinále</p>
<p align=center>
I. Mašková - B. Petrová 5:4, 5:2, 2:3P, 3:2</p>
<p class=v>Finále</p>
<p align=center>
A. Jackowská - I. Mašková 2:3P, 3:2, 1:0, 6:0
</p>



<p class=v>Konečné pořadí turnaje<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>Z</th>
<th>+</th>
<th>=</th>
<th>-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>B</th>
<th></th>
<th>&nbsp;</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al>Jackowská Aneta</td>
<td class=al>BSE České Budějovice</td>
<td class=ar>10</td>
<td class=ar>7</td>
<td class=ar>1</td>
<td class=ar>2</td>
<td class=ar>32</td>
<td class=al>: 20</td>
<td class=ar>15</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>2.</td>
<td class=bl>Mašková Iva</td>
<td class=bl>SHC Cheb</td>
<td class=br>14</td>
<td class=br>6</td>
<td class=br>1</td>
<td class=br>7</td>
<td class=br>42</td>
<td class=bl>: 41</td>
<td class=br>13</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>3.</td>
<td class=al>Petrová Barbora</td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>10</td>
<td class=ar>2</td>
<td class=ar>2</td>
<td class=ar>6</td>
<td class=ar>25</td>
<td class=al>: 38</td>
<td class=ar>6</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr></table></td></tr></table></div></p>



</body></html>