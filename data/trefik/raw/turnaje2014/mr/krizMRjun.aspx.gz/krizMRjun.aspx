<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN">
<html lang="cz">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<title>MR, Jihlava</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
</head>
<body class="neop">
<a name="Zac"><p class=l>MR juniorů, Jihlava, 1. června 2014</p></a>
<div align=center><p><a href="index.aspx">Back</a></p></div>
<p class=vm>Basic groups</p>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=2 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=ir>1</td><td class=kt>m.Chylík</td><td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=br>39:13</td><td class=br>+26</td>
<td class=bc>8 - 0 - 1</td>
<td class=br>16</td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=ir>2</td><td class=kt>H.Sládek</td><td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>11:0</td>
<td class=br>38:10</td><td class=br>+28</td>
<td class=bc>8 - 0 - 1</td>
<td class=br>16</td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=ir>3</td><td class=kt>M.Kobrle</td><td class=kW>5:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>5:4</td>
<td class=kW>6:2</td>
<td class=br>25:21</td><td class=br>+4</td>
<td class=bc>5 - 2 - 2</td>
<td class=br>12</td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=ir>4</td><td class=kt>J.Malý</td><td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=br>19:20</td><td class=br>-1</td>
<td class=bc>5 - 1 - 3</td>
<td class=br>11</td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=ir>5</td><td class=kt>T.Kahoun ml.</td><td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=br>15:18</td><td class=br>-3</td>
<td class=bc>4 - 1 - 4</td>
<td class=br>9</td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=ir>6</td><td class=kt>L.Kahoun</td><td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=br>22:21</td><td class=br>+1</td>
<td class=bc>3 - 2 - 4</td>
<td class=br>8</td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=ir>7</td><td class=kt>M.Matějka</td><td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=br>20:22</td><td class=br>-2</td>
<td class=bc>3 - 0 - 6</td>
<td class=br>6</td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=ir>8</td><td class=kt>J.Přibil</td><td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=br>12:19</td><td class=br>-7</td>
<td class=bc>2 - 2 - 5</td>
<td class=br>6</td><td class=d>8.</td>
</tr><tr><td class=ir>J</td><td class=ir>9</td><td class=kt>T.Dvořák</td><td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=br>22:33</td><td class=br>-11</td>
<td class=bc>2 - 1 - 6</td>
<td class=br>5</td><td class=d>9.</td>
</tr><tr><td class=ir>J</td><td class=ir>10</td><td class=kt>L.Florián</td><td class=kL>1:7</td>
<td class=kL>0:11</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>1:7</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=br>10:45</td><td class=br>-35</td>
<td class=bc>0 - 1 - 8</td>
<td class=br>1</td><td class=d>10.</td>
</tr></table></td></tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>H.Sládek</td><td class=bc>-</td><td class=bl>L.Florián</td><td class=bc>11 : 0</tr></td>
<tr><td class=brW>m.Chylík</td><td class=bc>-</td><td class=bl>J.Přibil</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>J.Malý</td><td class=bc>-</td><td class=bl>T.Dvořák</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>M.Kobrle</td><td class=bc>-</td><td class=bl>L.Kahoun</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>M.Matějka</td><td class=bc>-</td><td class=blW>T.Kahoun ml.</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>L.Florián</td><td class=bc>-</td><td class=blW>J.Přibil</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>H.Sládek</td><td class=bc>-</td><td class=bl>T.Dvořák</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>m.Chylík</td><td class=bc>-</td><td class=bl>L.Kahoun</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>J.Malý</td><td class=bc>-</td><td class=blW>T.Kahoun ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>M.Kobrle</td><td class=bc>-</td><td class=bl>M.Matějka</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>J.Přibil</td><td class=bc>-</td><td class=blW>T.Dvořák</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>L.Florián</td><td class=bc>-</td><td class=blW>L.Kahoun</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>H.Sládek</td><td class=bc>-</td><td class=bl>T.Kahoun ml.</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>m.Chylík</td><td class=bc>-</td><td class=bl>M.Matějka</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>J.Malý</td><td class=bc>-</td><td class=bl>M.Kobrle</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>T.Dvořák</td><td class=bc>-</td><td class=blW>L.Kahoun</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>J.Přibil</td><td class=bc>-</td><td class=bl>T.Kahoun ml.</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>L.Florián</td><td class=bc>-</td><td class=blW>M.Matějka</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>H.Sládek</td><td class=bc>-</td><td class=bl>M.Kobrle</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>m.Chylík</td><td class=bc>-</td><td class=bl>J.Malý</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>L.Kahoun</td><td class=bc>-</td><td class=bl>T.Kahoun ml.</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>T.Dvořák</td><td class=bc>-</td><td class=bl>M.Matějka</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>J.Přibil</td><td class=bc>-</td><td class=bl>M.Kobrle</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>L.Florián</td><td class=bc>-</td><td class=blW>J.Malý</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>H.Sládek</td><td class=bc>-</td><td class=blW>m.Chylík</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>T.Kahoun ml.</td><td class=bc>-</td><td class=bl>M.Kobrle</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>L.Kahoun</td><td class=bc>-</td><td class=bl>J.Malý</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>T.Dvořák</td><td class=bc>-</td><td class=blW>m.Chylík</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>J.Přibil</td><td class=bc>-</td><td class=blW>H.Sládek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>L.Florián</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>M.Matějka</td><td class=bc>-</td><td class=blW>J.Malý</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>T.Kahoun ml.</td><td class=bc>-</td><td class=blW>m.Chylík</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>L.Kahoun</td><td class=bc>-</td><td class=blW>H.Sládek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>T.Dvořák</td><td class=bc>-</td><td class=bl>L.Florián</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>J.Přibil</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>M.Kobrle</td><td class=bc>-</td><td class=bl>m.Chylík</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>M.Matějka</td><td class=bc>-</td><td class=blW>H.Sládek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>T.Kahoun ml.</td><td class=bc>-</td><td class=bl>L.Florián</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>L.Kahoun</td><td class=bc>-</td><td class=bl>J.Přibil</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>T.Dvořák</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>J.Malý</td><td class=bc>-</td><td class=blW>H.Sládek</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>M.Kobrle</td><td class=bc>-</td><td class=bl>L.Florián</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>M.Matějka</td><td class=bc>-</td><td class=bl>J.Přibil</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>T.Kahoun ml.</td><td class=bc>-</td><td class=bl>T.Dvořák</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>L.Kahoun</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>m.Chylík</td><td class=bc>-</td><td class=bl>L.Florián</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>J.Malý</td><td class=bc>-</td><td class=bl>J.Přibil</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>M.Kobrle</td><td class=bc>-</td><td class=bl>T.Dvořák</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>M.Matějka</td><td class=bc>-</td><td class=bl>L.Kahoun</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>T.Kahoun ml.</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>


<p class=v>Play-off<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><th colspan=11><font size="+1"><strong>Finále</strong></font></th></tr>
<tr><td class=br><b>Chylík ml. Jiří</b>&nbsp;&nbsp;</td>
<td class=bl>- Sládek Honza&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 1&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:1&nbsp;&nbsp;</td>
<td class=bl>0:4&nbsp;&nbsp;</td>
<td class=bl>3:0&nbsp;&nbsp;</td>
<td class=bl>4:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>Semifinále</strong></font></th></tr>
<tr><td class=ar><b>Chylík ml. Jiří</b>&nbsp;&nbsp;</td>
<td class=al>- Malý Josef&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 1&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>0:4&nbsp;&nbsp;</td>
<td class=al>5:0&nbsp;&nbsp;</td>
<td class=al>4:2&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><b>Sládek Honza</b>&nbsp;&nbsp;</td>
<td class=bl>- Kobrle Michal&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:2&nbsp;&nbsp;</td>
<td class=bl>5:2&nbsp;&nbsp;</td>
<td class=bl>7:3&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>O 3.místo</strong></font></th></tr>
<tr><td class=ar>Kobrle Michal&nbsp;&nbsp;</td>
<td class=al><b>- Malý Josef</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;2 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:0&nbsp;&nbsp;</td>
<td class=al>2:6&nbsp;&nbsp;</td>
<td class=al>5:0&nbsp;&nbsp;</td>
<td class=al>3:4 P&nbsp;&nbsp;</td>
<td class=al>0:3&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>Čtvrtfinále</strong></font></th></tr>
<tr><td class=br><b>Chylík ml. Jiří</b>&nbsp;&nbsp;</td>
<td class=bl>- Přibil Jiří&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>1:0&nbsp;&nbsp;</td>
<td class=bl>5:0&nbsp;&nbsp;</td>
<td class=bl>2:0&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Sládek Honza</b>&nbsp;&nbsp;</td>
<td class=al>- Matějka Marek&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>5:0&nbsp;&nbsp;</td>
<td class=al>6:2&nbsp;&nbsp;</td>
<td class=al>2:0&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><b>Kobrle Michal</b>&nbsp;&nbsp;</td>
<td class=bl>- Kahoun Lukáš&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>5:1&nbsp;&nbsp;</td>
<td class=bl>7:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Malý Josef</b>&nbsp;&nbsp;</td>
<td class=al>- Kahoun ml. Tomáš&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>6:0&nbsp;&nbsp;</td>
<td class=al>7:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr></table></td></tr></table></div></p>
<p>&nbsp;</p>


<p class=v>Konečné pořadí turnaje<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>Z</th>
<th>+</th>
<th>=</th>
<th>-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>B</th>
<th></th>
<th>&nbsp;</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al>Chylík ml. Jiří</td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>20</td>
<td class=ar>17</td>
<td class=ar>0</td>
<td class=ar>3</td>
<td class=ar>70</td>
<td class=al>: 28</td>
<td class=ar>34</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>2.</td>
<td class=bl>Sládek Honza</td>
<td class=bl>THC Stiga Elites</td>
<td class=br>19</td>
<td class=br>15</td>
<td class=br>0</td>
<td class=br>4</td>
<td class=br>74</td>
<td class=bl>: 30</td>
<td class=br>30</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>3.</td>
<td class=al>Malý Josef</td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>21</td>
<td class=ar>12</td>
<td class=ar>1</td>
<td class=ar>8</td>
<td class=ar>56</td>
<td class=al>: 48</td>
<td class=ar>25</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>4.</td>
<td class=bl>Kobrle Michal</td>
<td class=bl>THC Stiga Elites</td>
<td class=br>20</td>
<td class=br>10</td>
<td class=br>2</td>
<td class=br>8</td>
<td class=br>60</td>
<td class=bl>: 55</td>
<td class=br>22</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>5.</td>
<td class=al>Kahoun ml. Tomáš</td>
<td class=al>Pelhřimov</td>
<td class=ar>12</td>
<td class=ar>4</td>
<td class=ar>1</td>
<td class=ar>7</td>
<td class=ar>18</td>
<td class=al>: 34</td>
<td class=ar>9</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>6.</td>
<td class=bl>Kahoun Lukáš</td>
<td class=bl>Pelhřimov</td>
<td class=br>12</td>
<td class=br>3</td>
<td class=br>2</td>
<td class=br>7</td>
<td class=br>27</td>
<td class=bl>: 36</td>
<td class=br>8</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>7.</td>
<td class=al>Matějka Marek</td>
<td class=al>BSE České Budějovice</td>
<td class=ar>12</td>
<td class=ar>3</td>
<td class=ar>0</td>
<td class=ar>9</td>
<td class=ar>22</td>
<td class=al>: 35</td>
<td class=ar>6</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>8.</td>
<td class=bl>Přibil Jiří</td>
<td class=bl>BSE České Budějovice</td>
<td class=br>12</td>
<td class=br>2</td>
<td class=br>2</td>
<td class=br>8</td>
<td class=br>12</td>
<td class=bl>: 27</td>
<td class=br>6</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>9.</td>
<td class=al>Dvořák Tomáš</td>
<td class=al>Big Band</td>
<td class=ar>9</td>
<td class=ar>2</td>
<td class=ar>1</td>
<td class=ar>6</td>
<td class=ar>22</td>
<td class=al>: 33</td>
<td class=ar>5</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>10.</td>
<td class=bl>Florián Libor</td>
<td class=bl>Pelhřimov</td>
<td class=br>9</td>
<td class=br>0</td>
<td class=br>1</td>
<td class=br>8</td>
<td class=br>10</td>
<td class=bl>: 45</td>
<td class=br>1</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr></table></td></tr></table></div></p>

<div align=center><p>Created by <b>Trefik</b>, table hockey edition. Copyright 2003-2014 Vladimír Kraus<br><a href="http://www.trefik.cz">www.trefik.cz</a></p>

</body></html>