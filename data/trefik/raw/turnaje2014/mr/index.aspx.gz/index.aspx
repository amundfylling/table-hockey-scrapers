<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN">
<html lang="cz">

<head>
<meta http-equiv="Content-Type"
content="text/html; charset=windows-1250">
<title>Mistrovství republiky ve stolním hokeji Stiga 2014</title>
<link rel="StyleSheet" href="../../css.css" type="text/css">
</head>

<body class="neop">


<table width="100%" border="0" cellspacing="0" cellpadding="0">


<tr><td valign="top">

<br>
<table border="0" align="center" width="80%" cellspacing="0" cellpadding="2"><tr><td>
<p class="v">Mistrovství republiky ve stolním hokeji Stiga 2014</p>
<br>

<p align="center"><a href="krizMRJ.aspx"><font face="Arial">Turnaj
jednotlivců</font></a><font face="Arial"> - vítěz: <strong>Lukáš Turoň</strong>, 2.místo: <strong>Zdeněk Matoušek ml.</strong>,
3.místo: <strong>Patrik Petr</strong>.</p>

<p align="center"><font face="Arial"><a href="druzstva.htm"><font face="Arial">Turnaj družstev</font></a> - vítěz: <strong>THC Stiga Elites</strong>, 2.místo: <strong>HCS Žabka Praha</strong>, 3.místo <strong>THC Třinec</strong>.</font></p>

<p align="center"><a href="krizMRzeny.aspx"><font face="Arial">Turnaj žen</font></a><font
face="Arial"> - vítězka: <strong>Aneta Jackowská</strong>, 2.místo:
<strong>Iva Mašková</strong>, 3.místo: <strong>Barbora Petrová</strong>.</font></p>

<p align="center"><a href="krizMRjun.aspx"><font face="Arial">Turnaj
juniorů</font></a><font face="Arial"> - vítěz: <strong>Jiří Chylík</strong>, 2.místo: <strong>Jan Sládek</strong>, 3.místo:
<strong>Josef Malý</strong>.</font></p>

<p align="center"><a href="krizMRvet.aspx"><font face="Arial">Turnaj
veteránů</font></a><font face="Arial"> - vítěz: <strong>Pavel Plešák</strong>, 2.místo: <strong>Václav Pikl</strong>, 3.místo: <strong>Antonín Šrajer</strong>.</font></p>

<br><br>


</td></tr></table>



</td></tr>

</table>



</body>
</html>