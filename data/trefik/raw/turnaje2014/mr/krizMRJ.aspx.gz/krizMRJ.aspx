<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN">
<html lang="cz">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1250">
<title>MR, Jihlava</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
</head>
<body class="neop">
<a name="Zac"><p class=l>MR jednotlivů, Jihlava, 1. června 2014</p></a>
<div align=center><p><a href="index.aspx">Back</a></p></div>
<p class=vm>Basic groups</p>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=2 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=ir>1</td><td class=kt>J.Dryák</td><td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kL>5:6</td>
<td class=kW>6:0</td>
<td class=kW>5:2</td>
<td class=kW>8:2</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>8:1</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=kW>7:1</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=br>114:34</td><td class=br>+80</td>
<td class=bc>21 - 0 - 2</td>
<td class=br>42</td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=ir>2</td><td class=kt>P.Petr</td><td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>8:2</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=br>96:27</td><td class=br>+69</td>
<td class=bc>18 - 3 - 2</td>
<td class=br>39</td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=ir>3</td><td class=kt>M.Hvižď</td><td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kL>4:6</td>
<td class=kW>2:1</td>
<td class=kW>9:0</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>9:4</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>9:1</td>
<td class=br>91:38</td><td class=br>+53</td>
<td class=bc>17 - 3 - 3</td>
<td class=br>37</td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=ir>4</td><td class=kt>K.Lebl</td><td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>1:6</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>9:0</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=kW>8:2</td>
<td class=br>90:39</td><td class=br>+51</td>
<td class=bc>18 - 1 - 4</td>
<td class=br>37</td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=ir>5</td><td class=kt>P.Turoň</td><td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=br>80:32</td><td class=br>+48</td>
<td class=bc>15 - 4 - 4</td>
<td class=br>34</td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=ir>6</td><td class=kt>D.Matýsek</td><td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=br>73:36</td><td class=br>+37</td>
<td class=bc>15 - 2 - 6</td>
<td class=br>32</td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=ir>7</td><td class=kt>m.Chylík</td><td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=br>56:46</td><td class=br>+10</td>
<td class=bc>14 - 3 - 6</td>
<td class=br>31</td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=ir>8</td><td class=kt>R.Jež</td><td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=br>66:47</td><td class=br>+19</td>
<td class=bc>14 - 2 - 7</td>
<td class=br>30</td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>9</td><td class=kt>V.Pikl</td><td class=kW>6:5</td>
<td class=kL>2:7</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>8:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kL>2:5</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=kW>9:0</td>
<td class=br>81:59</td><td class=br>+22</td>
<td class=bc>11 - 7 - 5</td>
<td class=br>29</td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>10</td><td class=kt>M.Kobrle</td><td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kW>6:4</td>
<td class=kL>0:9</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>3:6</td>
<td class=kL>1:6</td>
<td class=kW>5:4</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>6:4</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=br>76:81</td><td class=br>-5</td>
<td class=bc>13 - 2 - 8</td>
<td class=br>28</td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>11</td><td class=kt>Z.Matoušek st.</td><td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>2:8</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=br>52:51</td><td class=br>+1</td>
<td class=bc>12 - 2 - 9</td>
<td class=br>26</td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>12</td><td class=kt>M.Boštík</td><td class=kL>2:8</td>
<td class=kL>0:4</td>
<td class=kL>0:9</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kW>4:0</td>
<td class=kL>3:5</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>7:3</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=br>78:69</td><td class=br>+9</td>
<td class=bc>12 - 2 - 9</td>
<td class=br>26</td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>13</td><td class=kt>D.Cibulka</td><td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>3:6</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>7:4</td>
<td class=br>79:60</td><td class=br>+19</td>
<td class=bc>10 - 5 - 8</td>
<td class=br>25</td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>14</td><td class=kt>M.Černoch</td><td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=br>49:49</td><td class=br>0</td>
<td class=bc>12 - 1 - 10</td>
<td class=br>25</td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>15</td><td class=kt>H.Sládek</td><td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>4:9</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=br>70:67</td><td class=br>+3</td>
<td class=bc>10 - 5 - 8</td>
<td class=br>25</td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>16</td><td class=kt>Z.Lopaur</td><td class=kL>1:6</td>
<td class=kL>2:8</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>6:5</td>
<td class=kW>2:1</td>
<td class=kW>7:2</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=br>59:79</td><td class=br>-20</td>
<td class=bc>9 - 1 - 13</td>
<td class=br>19</td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>17</td><td class=kt>T.Halama</td><td class=kL>1:8</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kW>5:4</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=br>46:71</td><td class=br>-25</td>
<td class=bc>8 - 1 - 14</td>
<td class=br>17</td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>18</td><td class=kt>M.Matějka</td><td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kL>3:7</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=br>41:85</td><td class=br>-44</td>
<td class=bc>5 - 2 - 16</td>
<td class=br>12</td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>19</td><td class=kt>P.Pohořalý</td><td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kL>5:6</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=br>46:82</td><td class=br>-36</td>
<td class=bc>4 - 3 - 16</td>
<td class=br>11</td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>20</td><td class=kt>J.Malý</td><td class=kL>4:5</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kL>4:6</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=br>43:78</td><td class=br>-35</td>
<td class=bc>5 - 0 - 18</td>
<td class=br>10</td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>21</td><td class=kt>J.Petr</td><td class=kL>1:7</td>
<td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=br>36:97</td><td class=br>-61</td>
<td class=bc>2 - 2 - 19</td>
<td class=br>6</td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>22</td><td class=kt>J.Přibil</td><td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kL>0:8</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=br>24:89</td><td class=br>-65</td>
<td class=bc>2 - 1 - 20</td>
<td class=br>5</td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>23</td><td class=kt>L.Kobrle</td><td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kL>0:6</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=br>30:89</td><td class=br>-59</td>
<td class=bc>2 - 1 - 20</td>
<td class=br>5</td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>24</td><td class=kt>P.Sládek</td><td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:9</td>
<td class=kL>2:8</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>0:9</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>4:7</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=br>32:103</td><td class=br>-71</td>
<td class=bc>0 - 1 - 22</td>
<td class=br>1</td><td class=d>24.</td>
</tr></table></td></tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>M.Hvižď</td><td class=bc>-</td><td class=bl>J.Přibil</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>J.Dryák</td><td class=bc>-</td><td class=bl>P.Sládek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>P.Petr</td><td class=bc>-</td><td class=bl>L.Kobrle</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>K.Lebl</td><td class=bc>-</td><td class=bl>M.Matějka</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>P.Turoň</td><td class=bc>-</td><td class=bl>J.Petr</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>V.Pikl</td><td class=bc>-</td><td class=bl>M.Kobrle</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>D.Matýsek</td><td class=bc>-</td><td class=bl>T.Halama</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>M.Boštík</td><td class=bc>-</td><td class=bl>J.Malý</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>M.Černoch</td><td class=bc>-</td><td class=bl>P.Pohořalý</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>H.Sládek</td><td class=bc>-</td><td class=bl>Z.Matoušek st.</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>m.Chylík</td><td class=bc>-</td><td class=bl>Z.Lopaur</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>R.Jež</td><td class=bc>-</td><td class=bl>D.Cibulka</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>J.Přibil</td><td class=bc>-</td><td class=bl>P.Sládek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>M.Hvižď</td><td class=bc>-</td><td class=bl>L.Kobrle</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>J.Dryák</td><td class=bc>-</td><td class=bl>M.Matějka</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>P.Petr</td><td class=bc>-</td><td class=bl>J.Petr</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>K.Lebl</td><td class=bc>-</td><td class=bl>M.Kobrle</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>P.Turoň</td><td class=bc>-</td><td class=bl>T.Halama</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>V.Pikl</td><td class=bc>-</td><td class=blW>J.Malý</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>D.Matýsek</td><td class=bc>-</td><td class=bl>P.Pohořalý</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>M.Boštík</td><td class=bc>-</td><td class=blW>Z.Matoušek st.</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>M.Černoch</td><td class=bc>-</td><td class=blW>Z.Lopaur</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>H.Sládek</td><td class=bc>-</td><td class=bl>D.Cibulka</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>m.Chylík</td><td class=bc>-</td><td class=bl>R.Jež</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>P.Sládek</td><td class=bc>-</td><td class=blW>L.Kobrle</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>J.Přibil</td><td class=bc>-</td><td class=blW>M.Matějka</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>M.Hvižď</td><td class=bc>-</td><td class=bl>J.Petr</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>J.Dryák</td><td class=bc>-</td><td class=bl>M.Kobrle</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>P.Petr</td><td class=bc>-</td><td class=bl>T.Halama</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>K.Lebl</td><td class=bc>-</td><td class=bl>J.Malý</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>P.Turoň</td><td class=bc>-</td><td class=bl>P.Pohořalý</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>V.Pikl</td><td class=bc>-</td><td class=bl>Z.Matoušek st.</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>D.Matýsek</td><td class=bc>-</td><td class=bl>Z.Lopaur</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>M.Boštík</td><td class=bc>-</td><td class=blW>D.Cibulka</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>M.Černoch</td><td class=bc>-</td><td class=bl>R.Jež</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>H.Sládek</td><td class=bc>-</td><td class=bl>m.Chylík</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>L.Kobrle</td><td class=bc>-</td><td class=blW>M.Matějka</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>P.Sládek</td><td class=bc>-</td><td class=blW>J.Petr</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>J.Přibil</td><td class=bc>-</td><td class=blW>M.Kobrle</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>M.Hvižď</td><td class=bc>-</td><td class=bl>T.Halama</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>J.Dryák</td><td class=bc>-</td><td class=bl>J.Malý</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>P.Petr</td><td class=bc>-</td><td class=bl>P.Pohořalý</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>K.Lebl</td><td class=bc>-</td><td class=bl>Z.Matoušek st.</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>P.Turoň</td><td class=bc>-</td><td class=bl>Z.Lopaur</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>V.Pikl</td><td class=bc>-</td><td class=bl>D.Cibulka</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>D.Matýsek</td><td class=bc>-</td><td class=bl>R.Jež</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>M.Boštík</td><td class=bc>-</td><td class=bl>m.Chylík</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>M.Černoch</td><td class=bc>-</td><td class=bl>H.Sládek</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>M.Matějka</td><td class=bc>-</td><td class=bl>J.Petr</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>L.Kobrle</td><td class=bc>-</td><td class=blW>M.Kobrle</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>P.Sládek</td><td class=bc>-</td><td class=blW>T.Halama</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>J.Přibil</td><td class=bc>-</td><td class=blW>J.Malý</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>M.Hvižď</td><td class=bc>-</td><td class=bl>P.Pohořalý</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>J.Dryák</td><td class=bc>-</td><td class=bl>Z.Matoušek st.</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>P.Petr</td><td class=bc>-</td><td class=bl>Z.Lopaur</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>K.Lebl</td><td class=bc>-</td><td class=bl>D.Cibulka</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>P.Turoň</td><td class=bc>-</td><td class=blW>R.Jež</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>V.Pikl</td><td class=bc>-</td><td class=blW>m.Chylík</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>D.Matýsek</td><td class=bc>-</td><td class=bl>H.Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>M.Boštík</td><td class=bc>-</td><td class=bl>M.Černoch</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>J.Petr</td><td class=bc>-</td><td class=blW>M.Kobrle</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>M.Matějka</td><td class=bc>-</td><td class=blW>T.Halama</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>L.Kobrle</td><td class=bc>-</td><td class=blW>J.Malý</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>P.Sládek</td><td class=bc>-</td><td class=blW>P.Pohořalý</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>J.Přibil</td><td class=bc>-</td><td class=blW>Z.Matoušek st.</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>M.Hvižď</td><td class=bc>-</td><td class=bl>Z.Lopaur</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>J.Dryák</td><td class=bc>-</td><td class=bl>D.Cibulka</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>P.Petr</td><td class=bc>-</td><td class=bl>R.Jež</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>K.Lebl</td><td class=bc>-</td><td class=blW>m.Chylík</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>P.Turoň</td><td class=bc>-</td><td class=bl>H.Sládek</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>V.Pikl</td><td class=bc>-</td><td class=blW>M.Černoch</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>D.Matýsek</td><td class=bc>-</td><td class=blW>M.Boštík</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>M.Kobrle</td><td class=bc>-</td><td class=bl>T.Halama</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>J.Petr</td><td class=bc>-</td><td class=blW>J.Malý</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>M.Matějka</td><td class=bc>-</td><td class=blW>P.Pohořalý</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>L.Kobrle</td><td class=bc>-</td><td class=blW>Z.Matoušek st.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>P.Sládek</td><td class=bc>-</td><td class=blW>Z.Lopaur</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>J.Přibil</td><td class=bc>-</td><td class=blW>D.Cibulka</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>M.Hvižď</td><td class=bc>-</td><td class=bl>R.Jež</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>J.Dryák</td><td class=bc>-</td><td class=bl>m.Chylík</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>P.Petr</td><td class=bc>-</td><td class=bl>H.Sládek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>K.Lebl</td><td class=bc>-</td><td class=bl>M.Černoch</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>P.Turoň</td><td class=bc>-</td><td class=blW>M.Boštík</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>V.Pikl</td><td class=bc>-</td><td class=blW>D.Matýsek</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>T.Halama</td><td class=bc>-</td><td class=bl>J.Malý</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>M.Kobrle</td><td class=bc>-</td><td class=bl>P.Pohořalý</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>J.Petr</td><td class=bc>-</td><td class=blW>Z.Matoušek st.</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>M.Matějka</td><td class=bc>-</td><td class=bl>Z.Lopaur</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>L.Kobrle</td><td class=bc>-</td><td class=blW>D.Cibulka</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>P.Sládek</td><td class=bc>-</td><td class=blW>R.Jež</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>J.Přibil</td><td class=bc>-</td><td class=blW>m.Chylík</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>M.Hvižď</td><td class=bc>-</td><td class=bl>H.Sládek</td><td class=bc>9 : 4</tr></td>
<tr><td class=brW>J.Dryák</td><td class=bc>-</td><td class=bl>M.Černoch</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>P.Petr</td><td class=bc>-</td><td class=bl>M.Boštík</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>K.Lebl</td><td class=bc>-</td><td class=bl>D.Matýsek</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>P.Turoň</td><td class=bc>-</td><td class=blW>V.Pikl</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>J.Malý</td><td class=bc>-</td><td class=blW>P.Pohořalý</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>T.Halama</td><td class=bc>-</td><td class=blW>Z.Matoušek st.</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>M.Kobrle</td><td class=bc>-</td><td class=bl>Z.Lopaur</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>J.Petr</td><td class=bc>-</td><td class=blW>D.Cibulka</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>M.Matějka</td><td class=bc>-</td><td class=blW>R.Jež</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>L.Kobrle</td><td class=bc>-</td><td class=blW>m.Chylík</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>P.Sládek</td><td class=bc>-</td><td class=blW>H.Sládek</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>J.Přibil</td><td class=bc>-</td><td class=blW>M.Černoch</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>M.Hvižď</td><td class=bc>-</td><td class=bl>M.Boštík</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>J.Dryák</td><td class=bc>-</td><td class=bl>D.Matýsek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>P.Petr</td><td class=bc>-</td><td class=bl>V.Pikl</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>K.Lebl</td><td class=bc>-</td><td class=blW>P.Turoň</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>P.Pohořalý</td><td class=bc>-</td><td class=blW>Z.Matoušek st.</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>J.Malý</td><td class=bc>-</td><td class=blW>Z.Lopaur</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>T.Halama</td><td class=bc>-</td><td class=bl>D.Cibulka</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>M.Kobrle</td><td class=bc>-</td><td class=blW>R.Jež</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>J.Petr</td><td class=bc>-</td><td class=blW>m.Chylík</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>M.Matějka</td><td class=bc>-</td><td class=blW>H.Sládek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>L.Kobrle</td><td class=bc>-</td><td class=blW>M.Černoch</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>P.Sládek</td><td class=bc>-</td><td class=blW>M.Boštík</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>J.Přibil</td><td class=bc>-</td><td class=blW>D.Matýsek</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>M.Hvižď</td><td class=bc>-</td><td class=bl>V.Pikl</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>J.Dryák</td><td class=bc>-</td><td class=bl>P.Turoň</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>P.Petr</td><td class=bc>-</td><td class=blW>K.Lebl</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Z.Matoušek st.</td><td class=bc>-</td><td class=bl>Z.Lopaur</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>P.Pohořalý</td><td class=bc>-</td><td class=bl>D.Cibulka</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>J.Malý</td><td class=bc>-</td><td class=blW>R.Jež</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>T.Halama</td><td class=bc>-</td><td class=blW>m.Chylík</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>M.Kobrle</td><td class=bc>-</td><td class=bl>H.Sládek</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>J.Petr</td><td class=bc>-</td><td class=blW>M.Černoch</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>M.Matějka</td><td class=bc>-</td><td class=blW>M.Boštík</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>L.Kobrle</td><td class=bc>-</td><td class=blW>D.Matýsek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>P.Sládek</td><td class=bc>-</td><td class=blW>V.Pikl</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>J.Přibil</td><td class=bc>-</td><td class=blW>P.Turoň</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>M.Hvižď</td><td class=bc>-</td><td class=bl>K.Lebl</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>J.Dryák</td><td class=bc>-</td><td class=blW>P.Petr</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Z.Lopaur</td><td class=bc>-</td><td class=bl>D.Cibulka</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Z.Matoušek st.</td><td class=bc>-</td><td class=blW>R.Jež</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>P.Pohořalý</td><td class=bc>-</td><td class=blW>m.Chylík</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>J.Malý</td><td class=bc>-</td><td class=blW>H.Sládek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>T.Halama</td><td class=bc>-</td><td class=blW>M.Černoch</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>M.Kobrle</td><td class=bc>-</td><td class=bl>M.Boštík</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>J.Petr</td><td class=bc>-</td><td class=blW>D.Matýsek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>M.Matějka</td><td class=bc>-</td><td class=blW>V.Pikl</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>L.Kobrle</td><td class=bc>-</td><td class=blW>P.Turoň</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>P.Sládek</td><td class=bc>-</td><td class=blW>K.Lebl</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>J.Přibil</td><td class=bc>-</td><td class=blW>P.Petr</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>M.Hvižď</td><td class=bc>-</td><td class=blW>J.Dryák</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>D.Cibulka</td><td class=bc>-</td><td class=blW>m.Chylík</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Z.Lopaur</td><td class=bc>-</td><td class=blW>H.Sládek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Z.Matoušek st.</td><td class=bc>-</td><td class=bl>M.Černoch</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>P.Pohořalý</td><td class=bc>-</td><td class=blW>M.Boštík</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>J.Malý</td><td class=bc>-</td><td class=blW>D.Matýsek</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>T.Halama</td><td class=bc>-</td><td class=bl>V.Pikl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>M.Kobrle</td><td class=bc>-</td><td class=bl>P.Turoň</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>J.Petr</td><td class=bc>-</td><td class=blW>K.Lebl</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>M.Matějka</td><td class=bc>-</td><td class=blW>P.Petr</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>L.Kobrle</td><td class=bc>-</td><td class=blW>J.Dryák</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>P.Sládek</td><td class=bc>-</td><td class=blW>M.Hvižď</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>J.Přibil</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>R.Jež</td><td class=bc>-</td><td class=bl>H.Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>D.Cibulka</td><td class=bc>-</td><td class=bl>M.Černoch</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Z.Lopaur</td><td class=bc>-</td><td class=blW>M.Boštík</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Z.Matoušek st.</td><td class=bc>-</td><td class=bl>D.Matýsek</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>P.Pohořalý</td><td class=bc>-</td><td class=blW>V.Pikl</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>J.Malý</td><td class=bc>-</td><td class=blW>P.Turoň</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>T.Halama</td><td class=bc>-</td><td class=blW>K.Lebl</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>M.Kobrle</td><td class=bc>-</td><td class=blW>P.Petr</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>J.Petr</td><td class=bc>-</td><td class=blW>J.Dryák</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>M.Matějka</td><td class=bc>-</td><td class=bl>M.Hvižď</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>L.Kobrle</td><td class=bc>-</td><td class=blW>J.Přibil</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>P.Sládek</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>m.Chylík</td><td class=bc>-</td><td class=blW>M.Černoch</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>R.Jež</td><td class=bc>-</td><td class=bl>M.Boštík</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>D.Cibulka</td><td class=bc>-</td><td class=bl>D.Matýsek</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Z.Lopaur</td><td class=bc>-</td><td class=bl>V.Pikl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Z.Matoušek st.</td><td class=bc>-</td><td class=bl>P.Turoň</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>P.Pohořalý</td><td class=bc>-</td><td class=blW>K.Lebl</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>J.Malý</td><td class=bc>-</td><td class=blW>P.Petr</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>T.Halama</td><td class=bc>-</td><td class=blW>J.Dryák</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>M.Kobrle</td><td class=bc>-</td><td class=bl>M.Hvižď</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>J.Petr</td><td class=bc>-</td><td class=bl>J.Přibil</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>M.Matějka</td><td class=bc>-</td><td class=bl>P.Sládek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>L.Kobrle</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>H.Sládek</td><td class=bc>-</td><td class=bl>M.Boštík</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>m.Chylík</td><td class=bc>-</td><td class=blW>D.Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>R.Jež</td><td class=bc>-</td><td class=blW>V.Pikl</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>D.Cibulka</td><td class=bc>-</td><td class=blW>P.Turoň</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Z.Lopaur</td><td class=bc>-</td><td class=blW>K.Lebl</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Z.Matoušek st.</td><td class=bc>-</td><td class=blW>P.Petr</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>P.Pohořalý</td><td class=bc>-</td><td class=blW>J.Dryák</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>J.Malý</td><td class=bc>-</td><td class=blW>M.Hvižď</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>T.Halama</td><td class=bc>-</td><td class=bl>J.Přibil</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>M.Kobrle</td><td class=bc>-</td><td class=bl>P.Sládek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>J.Petr</td><td class=bc>-</td><td class=blW>L.Kobrle</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>M.Matějka</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>M.Černoch</td><td class=bc>-</td><td class=blW>D.Matýsek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>H.Sládek</td><td class=bc>-</td><td class=blW>V.Pikl</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>m.Chylík</td><td class=bc>-</td><td class=blW>P.Turoň</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>R.Jež</td><td class=bc>-</td><td class=blW>K.Lebl</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>D.Cibulka</td><td class=bc>-</td><td class=bl>P.Petr</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Z.Lopaur</td><td class=bc>-</td><td class=blW>J.Dryák</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Z.Matoušek st.</td><td class=bc>-</td><td class=blW>M.Hvižď</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>P.Pohořalý</td><td class=bc>-</td><td class=bl>J.Přibil</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>J.Malý</td><td class=bc>-</td><td class=bl>P.Sládek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>T.Halama</td><td class=bc>-</td><td class=bl>L.Kobrle</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>M.Kobrle</td><td class=bc>-</td><td class=bl>M.Matějka</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>J.Petr</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>M.Boštík</td><td class=bc>-</td><td class=bl>V.Pikl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>M.Černoch</td><td class=bc>-</td><td class=blW>P.Turoň</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>H.Sládek</td><td class=bc>-</td><td class=blW>K.Lebl</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>m.Chylík</td><td class=bc>-</td><td class=blW>P.Petr</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>R.Jež</td><td class=bc>-</td><td class=blW>J.Dryák</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>D.Cibulka</td><td class=bc>-</td><td class=blW>M.Hvižď</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Z.Lopaur</td><td class=bc>-</td><td class=bl>J.Přibil</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Z.Matoušek st.</td><td class=bc>-</td><td class=bl>P.Sládek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>P.Pohořalý</td><td class=bc>-</td><td class=bl>L.Kobrle</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>J.Malý</td><td class=bc>-</td><td class=blW>M.Matějka</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>T.Halama</td><td class=bc>-</td><td class=bl>J.Petr</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>M.Kobrle</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>D.Matýsek</td><td class=bc>-</td><td class=blW>P.Turoň</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>M.Boštík</td><td class=bc>-</td><td class=blW>K.Lebl</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>M.Černoch</td><td class=bc>-</td><td class=blW>P.Petr</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>H.Sládek</td><td class=bc>-</td><td class=blW>J.Dryák</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>m.Chylík</td><td class=bc>-</td><td class=blW>M.Hvižď</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>R.Jež</td><td class=bc>-</td><td class=bl>J.Přibil</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>D.Cibulka</td><td class=bc>-</td><td class=bl>P.Sládek</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Z.Lopaur</td><td class=bc>-</td><td class=bl>L.Kobrle</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Z.Matoušek st.</td><td class=bc>-</td><td class=bl>M.Matějka</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>P.Pohořalý</td><td class=bc>-</td><td class=bl>J.Petr</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>J.Malý</td><td class=bc>-</td><td class=blW>M.Kobrle</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>T.Halama</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>V.Pikl</td><td class=bc>-</td><td class=bl>K.Lebl</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>D.Matýsek</td><td class=bc>-</td><td class=bl>P.Petr</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>M.Boštík</td><td class=bc>-</td><td class=blW>J.Dryák</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>M.Černoch</td><td class=bc>-</td><td class=blW>M.Hvižď</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>H.Sládek</td><td class=bc>-</td><td class=bl>J.Přibil</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>m.Chylík</td><td class=bc>-</td><td class=bl>P.Sládek</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>R.Jež</td><td class=bc>-</td><td class=bl>L.Kobrle</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>D.Cibulka</td><td class=bc>-</td><td class=bl>M.Matějka</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Z.Lopaur</td><td class=bc>-</td><td class=bl>J.Petr</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Z.Matoušek st.</td><td class=bc>-</td><td class=blW>M.Kobrle</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>P.Pohořalý</td><td class=bc>-</td><td class=blW>T.Halama</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>J.Malý</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>P.Turoň</td><td class=bc>-</td><td class=bl>P.Petr</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>V.Pikl</td><td class=bc>-</td><td class=bl>J.Dryák</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>D.Matýsek</td><td class=bc>-</td><td class=blW>M.Hvižď</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>M.Boštík</td><td class=bc>-</td><td class=bl>J.Přibil</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>M.Černoch</td><td class=bc>-</td><td class=bl>P.Sládek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>H.Sládek</td><td class=bc>-</td><td class=bl>L.Kobrle</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>m.Chylík</td><td class=bc>-</td><td class=bl>M.Matějka</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>R.Jež</td><td class=bc>-</td><td class=bl>J.Petr</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>D.Cibulka</td><td class=bc>-</td><td class=bl>M.Kobrle</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Z.Lopaur</td><td class=bc>-</td><td class=bl>T.Halama</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Z.Matoušek st.</td><td class=bc>-</td><td class=bl>J.Malý</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>P.Pohořalý</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>K.Lebl</td><td class=bc>-</td><td class=blW>J.Dryák</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>P.Turoň</td><td class=bc>-</td><td class=bl>M.Hvižď</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>V.Pikl</td><td class=bc>-</td><td class=bl>J.Přibil</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>D.Matýsek</td><td class=bc>-</td><td class=bl>P.Sládek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>M.Boštík</td><td class=bc>-</td><td class=bl>L.Kobrle</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>M.Černoch</td><td class=bc>-</td><td class=bl>M.Matějka</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>H.Sládek</td><td class=bc>-</td><td class=bl>J.Petr</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>m.Chylík</td><td class=bc>-</td><td class=bl>M.Kobrle</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>R.Jež</td><td class=bc>-</td><td class=bl>T.Halama</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>D.Cibulka</td><td class=bc>-</td><td class=bl>J.Malý</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Z.Lopaur</td><td class=bc>-</td><td class=bl>P.Pohořalý</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Z.Matoušek st.</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>P.Petr</td><td class=bc>-</td><td class=bl>M.Hvižď</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>K.Lebl</td><td class=bc>-</td><td class=bl>J.Přibil</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>P.Turoň</td><td class=bc>-</td><td class=bl>P.Sládek</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>V.Pikl</td><td class=bc>-</td><td class=bl>L.Kobrle</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>D.Matýsek</td><td class=bc>-</td><td class=bl>M.Matějka</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>M.Boštík</td><td class=bc>-</td><td class=bl>J.Petr</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>M.Černoch</td><td class=bc>-</td><td class=bl>M.Kobrle</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>H.Sládek</td><td class=bc>-</td><td class=bl>T.Halama</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>m.Chylík</td><td class=bc>-</td><td class=bl>J.Malý</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>R.Jež</td><td class=bc>-</td><td class=bl>P.Pohořalý</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>D.Cibulka</td><td class=bc>-</td><td class=bl>Z.Matoušek st.</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Z.Lopaur</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=brW>J.Dryák</td><td class=bc>-</td><td class=bl>J.Přibil</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>P.Petr</td><td class=bc>-</td><td class=bl>P.Sládek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>K.Lebl</td><td class=bc>-</td><td class=bl>L.Kobrle</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>P.Turoň</td><td class=bc>-</td><td class=bl>M.Matějka</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>V.Pikl</td><td class=bc>-</td><td class=bl>J.Petr</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>D.Matýsek</td><td class=bc>-</td><td class=bl>M.Kobrle</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>M.Boštík</td><td class=bc>-</td><td class=bl>T.Halama</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>M.Černoch</td><td class=bc>-</td><td class=bl>J.Malý</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>H.Sládek</td><td class=bc>-</td><td class=bl>P.Pohořalý</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>m.Chylík</td><td class=bc>-</td><td class=bl>Z.Matoušek st.</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>R.Jež</td><td class=bc>-</td><td class=bl>Z.Lopaur</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>D.Cibulka</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=2 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=ir>1</td><td class=kt>Z.Matoušek ml.</td><td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>6:3</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>9:6</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=kW>11:1</td>
<td class=kW>9:1</td>
<td class=kW>6:1</td>
<td class=br>104:34</td><td class=br>+70</td>
<td class=bc>20 - 2 - 1</td>
<td class=br>42</td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=ir>2</td><td class=kt>L.Turoň</td><td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>8:2</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>6:3</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>8:0</td>
<td class=kW>4:0</td>
<td class=kW>8:3</td>
<td class=kW>2:1</td>
<td class=br>109:28</td><td class=br>+81</td>
<td class=bc>20 - 2 - 1</td>
<td class=br>42</td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=ir>3</td><td class=kt>L.Hvižď ml.</td><td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>4:6</td>
<td class=kT>5:5</td>
<td class=kL>0:4</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kW>8:2</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>8:0</td>
<td class=kW>6:0</td>
<td class=kW>8:0</td>
<td class=kW>6:2</td>
<td class=br>100:35</td><td class=br>+65</td>
<td class=bc>19 - 1 - 3</td>
<td class=br>39</td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=ir>4</td><td class=kt>F.Hamáček</td><td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>6:4</td>
<td class=kL>3:4</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=kW>8:2</td>
<td class=kW>5:1</td>
<td class=br>91:36</td><td class=br>+55</td>
<td class=bc>19 - 0 - 4</td>
<td class=br>38</td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=ir>5</td><td class=kt>P.Plešák</td><td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>6:4</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kL>4:6</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>5:4</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>8:1</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>8:2</td>
<td class=br>95:46</td><td class=br>+49</td>
<td class=bc>14 - 7 - 2</td>
<td class=br>35</td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=ir>6</td><td class=kt>D.Šmíd</td><td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kT>5:5</td>
<td class=kL>1:4</td>
<td class=kW>6:4</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>8:1</td>
<td class=kW>4:0</td>
<td class=br>83:50</td><td class=br>+33</td>
<td class=bc>15 - 3 - 5</td>
<td class=br>33</td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=ir>7</td><td class=kt>M.Ženíšek</td><td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kW>4:0</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>8:3</td>
<td class=kW>7:1</td>
<td class=br>83:53</td><td class=br>+30</td>
<td class=bc>14 - 2 - 7</td>
<td class=br>30</td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=ir>8</td><td class=kt>D.Krása</td><td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>4:6</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>8:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=br>71:44</td><td class=br>+27</td>
<td class=bc>12 - 5 - 6</td>
<td class=br>29</td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>9</td><td class=kt>D.Brdíček</td><td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kL>4:5</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>7:3</td>
<td class=kW>9:3</td>
<td class=kW>5:0</td>
<td class=br>77:60</td><td class=br>+17</td>
<td class=bc>13 - 3 - 7</td>
<td class=br>29</td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>10</td><td class=kt>A.Zielinský</td><td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=br>59:36</td><td class=br>+23</td>
<td class=bc>12 - 4 - 7</td>
<td class=br>28</td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>11</td><td class=kt>K.Herold</td><td class=kL>3:4</td>
<td class=kL>2:8</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kL>4:5</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=br>73:64</td><td class=br>+9</td>
<td class=bc>11 - 3 - 9</td>
<td class=br>25</td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>12</td><td class=kt>T.Waclawek</td><td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kW>7:2</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=br>65:56</td><td class=br>+9</td>
<td class=bc>11 - 3 - 9</td>
<td class=br>25</td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>13</td><td class=kt>J.Vácha</td><td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kL>0:1</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kW>5:4</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>6:3</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>7:3</td>
<td class=kW>7:1</td>
<td class=kW>8:0</td>
<td class=br>73:60</td><td class=br>+13</td>
<td class=bc>11 - 2 - 10</td>
<td class=br>24</td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>14</td><td class=kt>A.Jackowská</td><td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=br>52:56</td><td class=br>-4</td>
<td class=bc>9 - 4 - 10</td>
<td class=br>22</td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>15</td><td class=kt>A.Šurýn</td><td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>5:5</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kL>4:5</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=br>57:64</td><td class=br>-7</td>
<td class=bc>7 - 6 - 10</td>
<td class=br>20</td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>16</td><td class=kt>I.Mašková</td><td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kL>4:5</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kW>6:2</td>
<td class=br>48:85</td><td class=br>-37</td>
<td class=bc>7 - 1 - 15</td>
<td class=br>15</td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>17</td><td class=kt>F.Marek</td><td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kT>5:5</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>7:3</td>
<td class=kL>1:2</td>
<td class=kT>0:0</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=br>50:77</td><td class=br>-27</td>
<td class=bc>6 - 2 - 15</td>
<td class=br>14</td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>18</td><td class=kt>T.Dvořák</td><td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>2:8</td>
<td class=kL>1:7</td>
<td class=kL>1:8</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>2:7</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>0:1</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=br>30:88</td><td class=br>-58</td>
<td class=bc>4 - 4 - 15</td>
<td class=br>12</td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>19</td><td class=kt>M.Kouba</td><td class=kL>6:9</td>
<td class=kL>0:6</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>3:7</td>
<td class=kL>2:8</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>1:6</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=br>56:98</td><td class=br>-42</td>
<td class=bc>6 - 0 - 17</td>
<td class=br>12</td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>20</td><td class=kt>H.Nechutný</td><td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=br>39:62</td><td class=br>-23</td>
<td class=bc>5 - 1 - 17</td>
<td class=br>11</td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>21</td><td class=kt>T.Kahoun ml.</td><td class=kL>0:8</td>
<td class=kL>0:8</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>2:7</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kT>0:0</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=br>25:100</td><td class=br>-75</td>
<td class=bc>2 - 5 - 16</td>
<td class=br>9</td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>22</td><td class=kt>T.Kahoun st.</td><td class=kL>1:11</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>0:8</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>3:7</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>3:7</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>6:1</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=br>39:89</td><td class=br>-50</td>
<td class=bc>3 - 2 - 18</td>
<td class=br>8</td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>23</td><td class=kt>B.Petrová</td><td class=kL>1:9</td>
<td class=kL>3:8</td>
<td class=kL>0:8</td>
<td class=kL>2:8</td>
<td class=kL>0:5</td>
<td class=kL>1:8</td>
<td class=kL>3:8</td>
<td class=kL>2:5</td>
<td class=kL>3:9</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=br>39:123</td><td class=br>-84</td>
<td class=bc>2 - 1 - 20</td>
<td class=br>5</td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>24</td><td class=kt>J.Malík</td><td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>2:8</td>
<td class=kL>0:4</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>0:8</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=br>26:100</td><td class=br>-74</td>
<td class=bc>2 - 1 - 20</td>
<td class=br>5</td><td class=d>24.</td>
</tr></table></td></tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>L.Turoň</td><td class=bc>-</td><td class=bl>T.Dvořák</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Z.Matoušek ml.</td><td class=bc>-</td><td class=bl>B.Petrová</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>L.Hvižď ml.</td><td class=bc>-</td><td class=bl>J.Malík</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>F.Hamáček</td><td class=bc>-</td><td class=bl>T.Kahoun ml.</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>P.Plešák</td><td class=bc>-</td><td class=bl>T.Kahoun st.</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>D.Šmíd</td><td class=bc>-</td><td class=bl>I.Mašková</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>A.Zielinský</td><td class=bc>-</td><td class=bl>M.Kouba</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>M.Ženíšek</td><td class=bc>-</td><td class=bl>H.Nechutný</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>D.Krása</td><td class=bc>-</td><td class=bl>F.Marek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>D.Brdíček</td><td class=bc>-</td><td class=bl>A.Jackowská</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>T.Waclawek</td><td class=bc>-</td><td class=bl>A.Šurýn</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>K.Herold</td><td class=bc>-</td><td class=blW>J.Vácha</td><td class=bc>4 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>T.Dvořák</td><td class=bc>-</td><td class=bl>B.Petrová</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>L.Turoň</td><td class=bc>-</td><td class=bl>J.Malík</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Z.Matoušek ml.</td><td class=bc>-</td><td class=bl>T.Kahoun ml.</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>L.Hvižď ml.</td><td class=bc>-</td><td class=bl>T.Kahoun st.</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>F.Hamáček</td><td class=bc>-</td><td class=bl>I.Mašková</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>P.Plešák</td><td class=bc>-</td><td class=bl>M.Kouba</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>D.Šmíd</td><td class=bc>-</td><td class=bl>H.Nechutný</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>A.Zielinský</td><td class=bc>-</td><td class=bl>F.Marek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>M.Ženíšek</td><td class=bc>-</td><td class=bl>A.Jackowská</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>D.Krása</td><td class=bc>-</td><td class=bl>A.Šurýn</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>D.Brdíček</td><td class=bc>-</td><td class=blW>J.Vácha</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>T.Waclawek</td><td class=bc>-</td><td class=blW>K.Herold</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>B.Petrová</td><td class=bc>-</td><td class=bl>J.Malík</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>T.Dvořák</td><td class=bc>-</td><td class=bl>T.Kahoun ml.</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>L.Turoň</td><td class=bc>-</td><td class=bl>T.Kahoun st.</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Z.Matoušek ml.</td><td class=bc>-</td><td class=bl>I.Mašková</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>L.Hvižď ml.</td><td class=bc>-</td><td class=bl>M.Kouba</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>F.Hamáček</td><td class=bc>-</td><td class=bl>H.Nechutný</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>P.Plešák</td><td class=bc>-</td><td class=bl>F.Marek</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>D.Šmíd</td><td class=bc>-</td><td class=bl>A.Jackowská</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>A.Zielinský</td><td class=bc>-</td><td class=bl>A.Šurýn</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>M.Ženíšek</td><td class=bc>-</td><td class=bl>J.Vácha</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>D.Krása</td><td class=bc>-</td><td class=blW>K.Herold</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>D.Brdíček</td><td class=bc>-</td><td class=bl>T.Waclawek</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>J.Malík</td><td class=bc>-</td><td class=blW>T.Kahoun ml.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>B.Petrová</td><td class=bc>-</td><td class=blW>T.Kahoun st.</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>T.Dvořák</td><td class=bc>-</td><td class=blW>I.Mašková</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>L.Turoň</td><td class=bc>-</td><td class=bl>M.Kouba</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Z.Matoušek ml.</td><td class=bc>-</td><td class=bl>H.Nechutný</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>L.Hvižď ml.</td><td class=bc>-</td><td class=bl>F.Marek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>F.Hamáček</td><td class=bc>-</td><td class=bl>A.Jackowská</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>P.Plešák</td><td class=bc>-</td><td class=bl>A.Šurýn</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>D.Šmíd</td><td class=bc>-</td><td class=bl>J.Vácha</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>A.Zielinský</td><td class=bc>-</td><td class=bl>K.Herold</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>M.Ženíšek</td><td class=bc>-</td><td class=bl>T.Waclawek</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>D.Krása</td><td class=bc>-</td><td class=bl>D.Brdíček</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>T.Kahoun ml.</td><td class=bc>-</td><td class=bl>T.Kahoun st.</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>J.Malík</td><td class=bc>-</td><td class=blW>I.Mašková</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>B.Petrová</td><td class=bc>-</td><td class=blW>M.Kouba</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>T.Dvořák</td><td class=bc>-</td><td class=blW>H.Nechutný</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>L.Turoň</td><td class=bc>-</td><td class=bl>F.Marek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Z.Matoušek ml.</td><td class=bc>-</td><td class=bl>A.Jackowská</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>L.Hvižď ml.</td><td class=bc>-</td><td class=bl>A.Šurýn</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>F.Hamáček</td><td class=bc>-</td><td class=bl>J.Vácha</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>P.Plešák</td><td class=bc>-</td><td class=bl>K.Herold</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>D.Šmíd</td><td class=bc>-</td><td class=bl>T.Waclawek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>A.Zielinský</td><td class=bc>-</td><td class=bl>D.Brdíček</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>M.Ženíšek</td><td class=bc>-</td><td class=bl>D.Krása</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>T.Kahoun st.</td><td class=bc>-</td><td class=blW>I.Mašková</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>T.Kahoun ml.</td><td class=bc>-</td><td class=blW>M.Kouba</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>J.Malík</td><td class=bc>-</td><td class=blW>H.Nechutný</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>B.Petrová</td><td class=bc>-</td><td class=bl>F.Marek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>T.Dvořák</td><td class=bc>-</td><td class=blW>A.Jackowská</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>L.Turoň</td><td class=bc>-</td><td class=bl>A.Šurýn</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Z.Matoušek ml.</td><td class=bc>-</td><td class=bl>J.Vácha</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>L.Hvižď ml.</td><td class=bc>-</td><td class=bl>K.Herold</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>F.Hamáček</td><td class=bc>-</td><td class=bl>T.Waclawek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>P.Plešák</td><td class=bc>-</td><td class=bl>D.Brdíček</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>D.Šmíd</td><td class=bc>-</td><td class=bl>D.Krása</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>A.Zielinský</td><td class=bc>-</td><td class=blW>M.Ženíšek</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>I.Mašková</td><td class=bc>-</td><td class=blW>M.Kouba</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>T.Kahoun st.</td><td class=bc>-</td><td class=blW>H.Nechutný</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>T.Kahoun ml.</td><td class=bc>-</td><td class=bl>F.Marek</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>J.Malík</td><td class=bc>-</td><td class=blW>A.Jackowská</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>B.Petrová</td><td class=bc>-</td><td class=blW>A.Šurýn</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>T.Dvořák</td><td class=bc>-</td><td class=bl>J.Vácha</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>L.Turoň</td><td class=bc>-</td><td class=bl>K.Herold</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Z.Matoušek ml.</td><td class=bc>-</td><td class=bl>T.Waclawek</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>L.Hvižď ml.</td><td class=bc>-</td><td class=bl>D.Brdíček</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>F.Hamáček</td><td class=bc>-</td><td class=bl>D.Krása</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>P.Plešák</td><td class=bc>-</td><td class=bl>M.Ženíšek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>D.Šmíd</td><td class=bc>-</td><td class=blW>A.Zielinský</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>M.Kouba</td><td class=bc>-</td><td class=bl>H.Nechutný</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>I.Mašková</td><td class=bc>-</td><td class=blW>F.Marek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>T.Kahoun st.</td><td class=bc>-</td><td class=bl>A.Jackowská</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>T.Kahoun ml.</td><td class=bc>-</td><td class=blW>A.Šurýn</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>J.Malík</td><td class=bc>-</td><td class=blW>J.Vácha</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>B.Petrová</td><td class=bc>-</td><td class=blW>K.Herold</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>T.Dvořák</td><td class=bc>-</td><td class=blW>T.Waclawek</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>L.Turoň</td><td class=bc>-</td><td class=bl>D.Brdíček</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Z.Matoušek ml.</td><td class=bc>-</td><td class=bl>D.Krása</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>L.Hvižď ml.</td><td class=bc>-</td><td class=blW>M.Ženíšek</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>F.Hamáček</td><td class=bc>-</td><td class=bl>A.Zielinský</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>P.Plešák</td><td class=bc>-</td><td class=blW>D.Šmíd</td><td class=bc>4 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>H.Nechutný</td><td class=bc>-</td><td class=bl>F.Marek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>M.Kouba</td><td class=bc>-</td><td class=blW>A.Jackowská</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>I.Mašková</td><td class=bc>-</td><td class=blW>A.Šurýn</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>T.Kahoun st.</td><td class=bc>-</td><td class=blW>J.Vácha</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>T.Kahoun ml.</td><td class=bc>-</td><td class=blW>K.Herold</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>J.Malík</td><td class=bc>-</td><td class=blW>T.Waclawek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>B.Petrová</td><td class=bc>-</td><td class=blW>D.Brdíček</td><td class=bc>3 : 9</tr></td>
<tr><td class=br>T.Dvořák</td><td class=bc>-</td><td class=blW>D.Krása</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>L.Turoň</td><td class=bc>-</td><td class=bl>M.Ženíšek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Z.Matoušek ml.</td><td class=bc>-</td><td class=bl>A.Zielinský</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>L.Hvižď ml.</td><td class=bc>-</td><td class=bl>D.Šmíd</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>F.Hamáček</td><td class=bc>-</td><td class=bl>P.Plešák</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>F.Marek</td><td class=bc>-</td><td class=blW>A.Jackowská</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>H.Nechutný</td><td class=bc>-</td><td class=blW>A.Šurýn</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>M.Kouba</td><td class=bc>-</td><td class=blW>J.Vácha</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>I.Mašková</td><td class=bc>-</td><td class=bl>K.Herold</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>T.Kahoun st.</td><td class=bc>-</td><td class=blW>T.Waclawek</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>T.Kahoun ml.</td><td class=bc>-</td><td class=blW>D.Brdíček</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>J.Malík</td><td class=bc>-</td><td class=blW>D.Krása</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>B.Petrová</td><td class=bc>-</td><td class=blW>M.Ženíšek</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>T.Dvořák</td><td class=bc>-</td><td class=blW>A.Zielinský</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>L.Turoň</td><td class=bc>-</td><td class=bl>D.Šmíd</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Z.Matoušek ml.</td><td class=bc>-</td><td class=bl>P.Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>L.Hvižď ml.</td><td class=bc>-</td><td class=bl>F.Hamáček</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>A.Jackowská</td><td class=bc>-</td><td class=blW>A.Šurýn</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>F.Marek</td><td class=bc>-</td><td class=blW>J.Vácha</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>H.Nechutný</td><td class=bc>-</td><td class=blW>K.Herold</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>M.Kouba</td><td class=bc>-</td><td class=blW>T.Waclawek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>I.Mašková</td><td class=bc>-</td><td class=bl>D.Brdíček</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>T.Kahoun st.</td><td class=bc>-</td><td class=blW>D.Krása</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>T.Kahoun ml.</td><td class=bc>-</td><td class=blW>M.Ženíšek</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>J.Malík</td><td class=bc>-</td><td class=blW>A.Zielinský</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>B.Petrová</td><td class=bc>-</td><td class=blW>D.Šmíd</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>T.Dvořák</td><td class=bc>-</td><td class=blW>P.Plešák</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>L.Turoň</td><td class=bc>-</td><td class=bl>F.Hamáček</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Z.Matoušek ml.</td><td class=bc>-</td><td class=blW>L.Hvižď ml.</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>A.Šurýn</td><td class=bc>-</td><td class=blW>J.Vácha</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>A.Jackowská</td><td class=bc>-</td><td class=blW>K.Herold</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>F.Marek</td><td class=bc>-</td><td class=blW>T.Waclawek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>H.Nechutný</td><td class=bc>-</td><td class=blW>D.Brdíček</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>M.Kouba</td><td class=bc>-</td><td class=blW>D.Krása</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>I.Mašková</td><td class=bc>-</td><td class=blW>M.Ženíšek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>T.Kahoun st.</td><td class=bc>-</td><td class=blW>A.Zielinský</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>T.Kahoun ml.</td><td class=bc>-</td><td class=blW>D.Šmíd</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>J.Malík</td><td class=bc>-</td><td class=blW>P.Plešák</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>B.Petrová</td><td class=bc>-</td><td class=blW>F.Hamáček</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>T.Dvořák</td><td class=bc>-</td><td class=blW>L.Hvižď ml.</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>L.Turoň</td><td class=bc>-</td><td class=blW>Z.Matoušek ml.</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>J.Vácha</td><td class=bc>-</td><td class=blW>T.Waclawek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>A.Šurýn</td><td class=bc>-</td><td class=blW>D.Brdíček</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>A.Jackowská</td><td class=bc>-</td><td class=bl>D.Krása</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>F.Marek</td><td class=bc>-</td><td class=bl>M.Ženíšek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>H.Nechutný</td><td class=bc>-</td><td class=blW>A.Zielinský</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>M.Kouba</td><td class=bc>-</td><td class=blW>D.Šmíd</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>I.Mašková</td><td class=bc>-</td><td class=blW>P.Plešák</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>T.Kahoun st.</td><td class=bc>-</td><td class=blW>F.Hamáček</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>T.Kahoun ml.</td><td class=bc>-</td><td class=blW>L.Hvižď ml.</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>J.Malík</td><td class=bc>-</td><td class=blW>Z.Matoušek ml.</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>B.Petrová</td><td class=bc>-</td><td class=blW>L.Turoň</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>T.Dvořák</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>K.Herold</td><td class=bc>-</td><td class=bl>D.Brdíček</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>J.Vácha</td><td class=bc>-</td><td class=bl>D.Krása</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>A.Šurýn</td><td class=bc>-</td><td class=bl>M.Ženíšek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>A.Jackowská</td><td class=bc>-</td><td class=blW>A.Zielinský</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>F.Marek</td><td class=bc>-</td><td class=blW>D.Šmíd</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>H.Nechutný</td><td class=bc>-</td><td class=blW>P.Plešák</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>M.Kouba</td><td class=bc>-</td><td class=blW>F.Hamáček</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>I.Mašková</td><td class=bc>-</td><td class=blW>L.Hvižď ml.</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>T.Kahoun st.</td><td class=bc>-</td><td class=blW>Z.Matoušek ml.</td><td class=bc>1 : 11</tr></td>
<tr><td class=br>T.Kahoun ml.</td><td class=bc>-</td><td class=blW>L.Turoň</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>J.Malík</td><td class=bc>-</td><td class=blW>T.Dvořák</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>B.Petrová</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>T.Waclawek</td><td class=bc>-</td><td class=blW>D.Krása</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>K.Herold</td><td class=bc>-</td><td class=blW>M.Ženíšek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>J.Vácha</td><td class=bc>-</td><td class=blW>A.Zielinský</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>A.Šurýn</td><td class=bc>-</td><td class=bl>D.Šmíd</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>A.Jackowská</td><td class=bc>-</td><td class=blW>P.Plešák</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>F.Marek</td><td class=bc>-</td><td class=blW>F.Hamáček</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>H.Nechutný</td><td class=bc>-</td><td class=blW>L.Hvižď ml.</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>M.Kouba</td><td class=bc>-</td><td class=blW>Z.Matoušek ml.</td><td class=bc>6 : 9</tr></td>
<tr><td class=br>I.Mašková</td><td class=bc>-</td><td class=blW>L.Turoň</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>T.Kahoun st.</td><td class=bc>-</td><td class=blW>T.Dvořák</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>T.Kahoun ml.</td><td class=bc>-</td><td class=bl>B.Petrová</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>J.Malík</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>D.Brdíček</td><td class=bc>-</td><td class=bl>M.Ženíšek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>T.Waclawek</td><td class=bc>-</td><td class=bl>A.Zielinský</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>K.Herold</td><td class=bc>-</td><td class=blW>D.Šmíd</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>J.Vácha</td><td class=bc>-</td><td class=blW>P.Plešák</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>A.Šurýn</td><td class=bc>-</td><td class=blW>F.Hamáček</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>A.Jackowská</td><td class=bc>-</td><td class=blW>L.Hvižď ml.</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>F.Marek</td><td class=bc>-</td><td class=blW>Z.Matoušek ml.</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>H.Nechutný</td><td class=bc>-</td><td class=blW>L.Turoň</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>M.Kouba</td><td class=bc>-</td><td class=blW>T.Dvořák</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>I.Mašková</td><td class=bc>-</td><td class=bl>B.Petrová</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>T.Kahoun st.</td><td class=bc>-</td><td class=blW>J.Malík</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>T.Kahoun ml.</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>D.Krása</td><td class=bc>-</td><td class=bl>A.Zielinský</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>D.Brdíček</td><td class=bc>-</td><td class=bl>D.Šmíd</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>T.Waclawek</td><td class=bc>-</td><td class=bl>P.Plešák</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>K.Herold</td><td class=bc>-</td><td class=blW>F.Hamáček</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>J.Vácha</td><td class=bc>-</td><td class=blW>L.Hvižď ml.</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>A.Šurýn</td><td class=bc>-</td><td class=blW>Z.Matoušek ml.</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>A.Jackowská</td><td class=bc>-</td><td class=blW>L.Turoň</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>F.Marek</td><td class=bc>-</td><td class=bl>T.Dvořák</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>H.Nechutný</td><td class=bc>-</td><td class=bl>B.Petrová</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>M.Kouba</td><td class=bc>-</td><td class=bl>J.Malík</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>I.Mašková</td><td class=bc>-</td><td class=bl>T.Kahoun ml.</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>T.Kahoun st.</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>M.Ženíšek</td><td class=bc>-</td><td class=blW>D.Šmíd</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>D.Krása</td><td class=bc>-</td><td class=bl>P.Plešák</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>D.Brdíček</td><td class=bc>-</td><td class=bl>F.Hamáček</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>T.Waclawek</td><td class=bc>-</td><td class=blW>L.Hvižď ml.</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>K.Herold</td><td class=bc>-</td><td class=blW>Z.Matoušek ml.</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>J.Vácha</td><td class=bc>-</td><td class=blW>L.Turoň</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>A.Šurýn</td><td class=bc>-</td><td class=bl>T.Dvořák</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>A.Jackowská</td><td class=bc>-</td><td class=bl>B.Petrová</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>F.Marek</td><td class=bc>-</td><td class=bl>J.Malík</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>H.Nechutný</td><td class=bc>-</td><td class=bl>T.Kahoun ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>M.Kouba</td><td class=bc>-</td><td class=blW>T.Kahoun st.</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>I.Mašková</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>A.Zielinský</td><td class=bc>-</td><td class=blW>P.Plešák</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>M.Ženíšek</td><td class=bc>-</td><td class=blW>F.Hamáček</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>D.Krása</td><td class=bc>-</td><td class=blW>L.Hvižď ml.</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>D.Brdíček</td><td class=bc>-</td><td class=blW>Z.Matoušek ml.</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>T.Waclawek</td><td class=bc>-</td><td class=bl>L.Turoň</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>K.Herold</td><td class=bc>-</td><td class=bl>T.Dvořák</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>J.Vácha</td><td class=bc>-</td><td class=bl>B.Petrová</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>A.Šurýn</td><td class=bc>-</td><td class=bl>J.Malík</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>A.Jackowská</td><td class=bc>-</td><td class=bl>T.Kahoun ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>F.Marek</td><td class=bc>-</td><td class=bl>T.Kahoun st.</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>H.Nechutný</td><td class=bc>-</td><td class=blW>I.Mašková</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>M.Kouba</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>D.Šmíd</td><td class=bc>-</td><td class=blW>F.Hamáček</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>A.Zielinský</td><td class=bc>-</td><td class=blW>L.Hvižď ml.</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>M.Ženíšek</td><td class=bc>-</td><td class=blW>Z.Matoušek ml.</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>D.Krása</td><td class=bc>-</td><td class=blW>L.Turoň</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>D.Brdíček</td><td class=bc>-</td><td class=bl>T.Dvořák</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>T.Waclawek</td><td class=bc>-</td><td class=bl>B.Petrová</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>K.Herold</td><td class=bc>-</td><td class=blW>J.Malík</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>J.Vácha</td><td class=bc>-</td><td class=bl>T.Kahoun ml.</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>A.Šurýn</td><td class=bc>-</td><td class=blW>T.Kahoun st.</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>A.Jackowská</td><td class=bc>-</td><td class=bl>I.Mašková</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>F.Marek</td><td class=bc>-</td><td class=bl>M.Kouba</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>H.Nechutný</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>P.Plešák</td><td class=bc>-</td><td class=bl>L.Hvižď ml.</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>D.Šmíd</td><td class=bc>-</td><td class=blW>Z.Matoušek ml.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>A.Zielinský</td><td class=bc>-</td><td class=blW>L.Turoň</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>M.Ženíšek</td><td class=bc>-</td><td class=bl>T.Dvořák</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>D.Krása</td><td class=bc>-</td><td class=bl>B.Petrová</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>D.Brdíček</td><td class=bc>-</td><td class=bl>J.Malík</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>T.Waclawek</td><td class=bc>-</td><td class=bl>T.Kahoun ml.</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>K.Herold</td><td class=bc>-</td><td class=bl>T.Kahoun st.</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>J.Vácha</td><td class=bc>-</td><td class=bl>I.Mašková</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>A.Šurýn</td><td class=bc>-</td><td class=blW>M.Kouba</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>A.Jackowská</td><td class=bc>-</td><td class=bl>H.Nechutný</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>F.Marek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>F.Hamáček</td><td class=bc>-</td><td class=blW>Z.Matoušek ml.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>P.Plešák</td><td class=bc>-</td><td class=bl>L.Turoň</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>D.Šmíd</td><td class=bc>-</td><td class=bl>T.Dvořák</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>A.Zielinský</td><td class=bc>-</td><td class=bl>B.Petrová</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>M.Ženíšek</td><td class=bc>-</td><td class=bl>J.Malík</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>D.Krása</td><td class=bc>-</td><td class=bl>T.Kahoun ml.</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>D.Brdíček</td><td class=bc>-</td><td class=bl>T.Kahoun st.</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>T.Waclawek</td><td class=bc>-</td><td class=bl>I.Mašková</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>K.Herold</td><td class=bc>-</td><td class=bl>M.Kouba</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>J.Vácha</td><td class=bc>-</td><td class=bl>H.Nechutný</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>A.Šurýn</td><td class=bc>-</td><td class=bl>F.Marek</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>A.Jackowská</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>L.Hvižď ml.</td><td class=bc>-</td><td class=blW>L.Turoň</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>F.Hamáček</td><td class=bc>-</td><td class=bl>T.Dvořák</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>P.Plešák</td><td class=bc>-</td><td class=bl>B.Petrová</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>D.Šmíd</td><td class=bc>-</td><td class=bl>J.Malík</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>A.Zielinský</td><td class=bc>-</td><td class=bl>T.Kahoun ml.</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>M.Ženíšek</td><td class=bc>-</td><td class=bl>T.Kahoun st.</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>D.Krása</td><td class=bc>-</td><td class=bl>I.Mašková</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>D.Brdíček</td><td class=bc>-</td><td class=bl>M.Kouba</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>T.Waclawek</td><td class=bc>-</td><td class=bl>H.Nechutný</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>K.Herold</td><td class=bc>-</td><td class=bl>F.Marek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>J.Vácha</td><td class=bc>-</td><td class=blW>A.Jackowská</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>A.Šurýn</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=brW>Z.Matoušek ml.</td><td class=bc>-</td><td class=bl>T.Dvořák</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>L.Hvižď ml.</td><td class=bc>-</td><td class=bl>B.Petrová</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>F.Hamáček</td><td class=bc>-</td><td class=bl>J.Malík</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>P.Plešák</td><td class=bc>-</td><td class=bl>T.Kahoun ml.</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>D.Šmíd</td><td class=bc>-</td><td class=bl>T.Kahoun st.</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>A.Zielinský</td><td class=bc>-</td><td class=bl>I.Mašková</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>M.Ženíšek</td><td class=bc>-</td><td class=bl>M.Kouba</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>D.Krása</td><td class=bc>-</td><td class=bl>H.Nechutný</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>D.Brdíček</td><td class=bc>-</td><td class=bl>F.Marek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>T.Waclawek</td><td class=bc>-</td><td class=blW>A.Jackowská</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>K.Herold</td><td class=bc>-</td><td class=bl>A.Šurýn</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>J.Vácha</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>


<p class=v>Group A</br><div align=center>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=2 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=ir>1</td><td class=kt>L.Turoň</td><td class=kx>*</td>
<td class=kL>0:1 K</td>
<td class=kW>4:1 K</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>5:2 K</td>
<td class=kL>2:4</td>
<td class=kT>2:2 K</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>4:3 K</td>
<td class=kW>4:0 K</td>
<td class=kW>5:1</td>
<td class=kW>8:3</td>
<td class=kW>5:0 K</td>
<td class=br>55:24</td><td class=br>+31</td>
<td class=bc>11 - 2 - 2</td>
<td class=br>24</td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=ir>2</td><td class=kt>Z.Matoušek ml.</td><td class=kW>1:0 K</td>
<td class=kx>*</td>
<td class=kL>1:4 K</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>2:1 K</td>
<td class=kW>4:2</td>
<td class=kT>2:2 K</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2 K</td>
<td class=kW>4:3 K</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>5:0 K</td>
<td class=br>46:29</td><td class=br>+17</td>
<td class=bc>11 - 1 - 3</td>
<td class=br>23</td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=ir>3</td><td class=kt>L.Hvižď ml.</td><td class=kL>1:4 K</td>
<td class=kW>4:1 K</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>5:5</td>
<td class=kW>4:0</td>
<td class=kW>3:1 K</td>
<td class=kW>3:0</td>
<td class=kL>4:6 K</td>
<td class=kL>0:4</td>
<td class=kW>9:4</td>
<td class=kW>5:1 K</td>
<td class=kL>0:4 K</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>5:0 K</td>
<td class=br>55:34</td><td class=br>+21</td>
<td class=bc>10 - 1 - 4</td>
<td class=br>21</td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=ir>4</td><td class=kt>J.Dryák</td><td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:1 K</td>
<td class=kL>2:5 K</td>
<td class=kW>2:0</td>
<td class=kW>4:1 K</td>
<td class=kW>4:2</td>
<td class=kW>5:2 K</td>
<td class=kW>4:0 K</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>6:1 K</td>
<td class=kW>2:1 K</td>
<td class=kW>5:0 K</td>
<td class=br>49:28</td><td class=br>+21</td>
<td class=bc>10 - 1 - 4</td>
<td class=br>21</td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=ir>5</td><td class=kt>M.Hvižď</td><td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kT>5:5</td>
<td class=kL>1:3 K</td>
<td class=kx>*</td>
<td class=kT>1:1 K</td>
<td class=kT>3:3</td>
<td class=kT>1:1 K</td>
<td class=kL>4:5</td>
<td class=kW>3:2 K</td>
<td class=kW>3:2 K</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1 K</td>
<td class=kW>5:1 K</td>
<td class=kW>5:0 K</td>
<td class=br>44:32</td><td class=br>+12</td>
<td class=bc>6 - 7 - 2</td>
<td class=br>19</td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=ir>6</td><td class=kt>P.Petr</td><td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kW>5:2 K</td>
<td class=kT>1:1 K</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2 K</td>
<td class=kW>5:3</td>
<td class=kL>2:3 K</td>
<td class=kL>2:3 K</td>
<td class=kT>2:2</td>
<td class=kW>7:3</td>
<td class=kW>3:1 K</td>
<td class=kW>4:0 K</td>
<td class=kW>5:0 K</td>
<td class=br>43:31</td><td class=br>+12</td>
<td class=bc>7 - 3 - 5</td>
<td class=br>17</td><td class=d>6.</td>
</tr><tr><td class=ir>1/4</td><td class=ir>7</td><td class=kt>F.Hamáček</td><td class=kL>2:5 K</td>
<td class=kL>1:2 K</td>
<td class=kL>1:3 K</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>1:0 K</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>6:4 K</td>
<td class=kW>3:0 K</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kW>5:0 K</td>
<td class=br>38:24</td><td class=br>+14</td>
<td class=bc>7 - 3 - 5</td>
<td class=br>17</td><td class=d>7.</td>
</tr><tr><td class=ir>1/4</td><td class=ir>8</td><td class=kt>P.Turoň</td><td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>1:4 K</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2 K</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>6:1 K</td>
<td class=kW>3:1 K</td>
<td class=kW>5:2</td>
<td class=kT>5:5</td>
<td class=kW>5:1 K</td>
<td class=kL>1:2 K</td>
<td class=kW>5:0 K</td>
<td class=br>44:35</td><td class=br>+9</td>
<td class=bc>6 - 4 - 5</td>
<td class=br>16</td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>9</td><td class=kt>P.Plešák</td><td class=kT>2:2 K</td>
<td class=kT>2:2 K</td>
<td class=kW>6:4 K</td>
<td class=kL>2:4</td>
<td class=kW>5:4</td>
<td class=kL>3:5</td>
<td class=kL>0:1 K</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kT>1:1 K</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>5:0 K</td>
<td class=br>40:35</td><td class=br>+5</td>
<td class=bc>4 - 8 - 3</td>
<td class=br>16</td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>10</td><td class=kt>K.Lebl</td><td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kW>4:0</td>
<td class=kL>2:5 K</td>
<td class=kL>2:3 K</td>
<td class=kW>3:2 K</td>
<td class=kT>1:1</td>
<td class=kL>1:6 K</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:0 K</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kL>1:2 K</td>
<td class=kW>4:3 K</td>
<td class=kW>5:0 K</td>
<td class=br>39:34</td><td class=br>+5</td>
<td class=bc>7 - 2 - 6</td>
<td class=br>16</td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>11</td><td class=kt>D.Matýsek</td><td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>4:9</td>
<td class=kL>0:4 K</td>
<td class=kL>2:3 K</td>
<td class=kW>3:2 K</td>
<td class=kT>1:1</td>
<td class=kL>1:3 K</td>
<td class=kT>1:1</td>
<td class=kL>0:3 K</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>5:0</td>
<td class=kW>2:1 K</td>
<td class=kW>4:1 K</td>
<td class=kW>5:0 K</td>
<td class=br>33:37</td><td class=br>-4</td>
<td class=bc>6 - 2 - 7</td>
<td class=br>14</td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>12</td><td class=kt>D.Krása</td><td class=kL>3:4 K</td>
<td class=kL>2:3 K</td>
<td class=kL>1:5 K</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>4:6 K</td>
<td class=kL>2:5</td>
<td class=kT>1:1 K</td>
<td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>2:3 K</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0 K</td>
<td class=br>40:41</td><td class=br>-1</td>
<td class=bc>4 - 4 - 7</td>
<td class=br>12</td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>13</td><td class=kt>M.Ženíšek</td><td class=kL>0:4 K</td>
<td class=kL>3:4 K</td>
<td class=kW>4:0 K</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>3:7</td>
<td class=kL>0:3 K</td>
<td class=kT>5:5</td>
<td class=kT>1:1 K</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kW>3:2 K</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kW>5:0 K</td>
<td class=br>32:47</td><td class=br>-15</td>
<td class=bc>4 - 3 - 8</td>
<td class=br>11</td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>14</td><td class=kt>m.Chylík</td><td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>1:6 K</td>
<td class=kL>1:4 K</td>
<td class=kL>1:3 K</td>
<td class=kL>0:5</td>
<td class=kL>1:5 K</td>
<td class=kT>2:2</td>
<td class=kW>2:1 K</td>
<td class=kL>1:2 K</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:3 K</td>
<td class=kW>5:0 K</td>
<td class=br>24:51</td><td class=br>-27</td>
<td class=bc>3 - 1 - 11</td>
<td class=br>7</td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>15</td><td class=kt>R.Jež</td><td class=kL>3:8</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>1:2 K</td>
<td class=kL>1:5 K</td>
<td class=kL>0:4 K</td>
<td class=kL>0:4</td>
<td class=kW>2:1 K</td>
<td class=kL>3:5</td>
<td class=kL>3:4 K</td>
<td class=kL>1:4 K</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kL>3:4 K</td>
<td class=kx>*</td>
<td class=kW>5:0 K</td>
<td class=br>31:56</td><td class=br>-25</td>
<td class=bc>3 - 0 - 12</td>
<td class=br>6</td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=ir>16</td><td class=kt>D.Šmíd</td><td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kx>*</td>
<td class=br>0:75</td><td class=br>-75</td>
<td class=bc>0 - 0 - 15</td>
<td class=br>0</td><td class=d>16.</td>
</tr></table></td></tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>J.Dryák</td><td class=bc>-</td><td class=blW>Z.Matoušek ml.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>P.Petr</td><td class=bc>-</td><td class=blW>L.Turoň</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>M.Hvižď</td><td class=bc>-</td><td class=bl>L.Hvižď ml.</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>K.Lebl</td><td class=bc>-</td><td class=bl>F.Hamáček</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>P.Turoň</td><td class=bc>-</td><td class=bl>P.Plešák</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>D.Matýsek</td><td class=bc>-</td><td class=bl>D.Šmíd</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>m.Chylík</td><td class=bc>-</td><td class=blW>M.Ženíšek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>R.Jež</td><td class=bc>-</td><td class=blW>D.Krása</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>R.Jež</td><td class=bc>-</td><td class=blW>L.Turoň</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>J.Dryák</td><td class=bc>-</td><td class=blW>L.Hvižď ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>P.Petr</td><td class=bc>-</td><td class=bl>F.Hamáček</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>M.Hvižď</td><td class=bc>-</td><td class=blW>P.Plešák</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>K.Lebl</td><td class=bc>-</td><td class=bl>D.Šmíd</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>P.Turoň</td><td class=bc>-</td><td class=bl>M.Ženíšek</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>D.Matýsek</td><td class=bc>-</td><td class=blW>D.Krása</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>m.Chylík</td><td class=bc>-</td><td class=blW>Z.Matoušek ml.</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>m.Chylík</td><td class=bc>-</td><td class=blW>L.Hvižď ml.</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>R.Jež</td><td class=bc>-</td><td class=blW>F.Hamáček</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>J.Dryák</td><td class=bc>-</td><td class=bl>P.Plešák</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>P.Petr</td><td class=bc>-</td><td class=bl>D.Šmíd</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>M.Hvižď</td><td class=bc>-</td><td class=bl>M.Ženíšek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>K.Lebl</td><td class=bc>-</td><td class=bl>D.Krása</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>P.Turoň</td><td class=bc>-</td><td class=blW>Z.Matoušek ml.</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>D.Matýsek</td><td class=bc>-</td><td class=blW>L.Turoň</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>D.Matýsek</td><td class=bc>-</td><td class=bl>F.Hamáček</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>m.Chylík</td><td class=bc>-</td><td class=bl>P.Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>R.Jež</td><td class=bc>-</td><td class=bl>D.Šmíd</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>J.Dryák</td><td class=bc>-</td><td class=bl>M.Ženíšek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>P.Petr</td><td class=bc>-</td><td class=bl>D.Krása</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>M.Hvižď</td><td class=bc>-</td><td class=bl>Z.Matoušek ml.</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>K.Lebl</td><td class=bc>-</td><td class=blW>L.Turoň</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>P.Turoň</td><td class=bc>-</td><td class=blW>L.Hvižď ml.</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>F.Hamáček</td><td class=bc>-</td><td class=bl>P.Turoň</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>P.Plešák</td><td class=bc>-</td><td class=bl>D.Matýsek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>D.Šmíd</td><td class=bc>-</td><td class=blW>m.Chylík</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>M.Ženíšek</td><td class=bc>-</td><td class=blW>R.Jež</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>D.Krása</td><td class=bc>-</td><td class=bl>J.Dryák</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Z.Matoušek ml.</td><td class=bc>-</td><td class=bl>P.Petr</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>L.Turoň</td><td class=bc>-</td><td class=bl>M.Hvižď</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>L.Hvižď ml.</td><td class=bc>-</td><td class=blW>K.Lebl</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>P.Plešák</td><td class=bc>-</td><td class=bl>K.Lebl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>D.Šmíd</td><td class=bc>-</td><td class=blW>P.Turoň</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>M.Ženíšek</td><td class=bc>-</td><td class=blW>D.Matýsek</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>D.Krása</td><td class=bc>-</td><td class=bl>m.Chylík</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Z.Matoušek ml.</td><td class=bc>-</td><td class=bl>R.Jež</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>L.Turoň</td><td class=bc>-</td><td class=bl>J.Dryák</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>L.Hvižď ml.</td><td class=bc>-</td><td class=bl>P.Petr</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>F.Hamáček</td><td class=bc>-</td><td class=bl>M.Hvižď</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>D.Šmíd</td><td class=bc>-</td><td class=blW>M.Hvižď</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>M.Ženíšek</td><td class=bc>-</td><td class=blW>K.Lebl</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>D.Krása</td><td class=bc>-</td><td class=blW>P.Turoň</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Z.Matoušek ml.</td><td class=bc>-</td><td class=blW>D.Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>L.Turoň</td><td class=bc>-</td><td class=bl>m.Chylík</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>L.Hvižď ml.</td><td class=bc>-</td><td class=bl>R.Jež</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>F.Hamáček</td><td class=bc>-</td><td class=blW>J.Dryák</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>P.Plešák</td><td class=bc>-</td><td class=blW>P.Petr</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>M.Ženíšek</td><td class=bc>-</td><td class=blW>P.Petr</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>D.Krása</td><td class=bc>-</td><td class=bl>M.Hvižď</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Z.Matoušek ml.</td><td class=bc>-</td><td class=bl>K.Lebl</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>L.Turoň</td><td class=bc>-</td><td class=blW>P.Turoň</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>L.Hvižď ml.</td><td class=bc>-</td><td class=bl>D.Matýsek</td><td class=bc>9 : 4</tr></td>
<tr><td class=brW>F.Hamáček</td><td class=bc>-</td><td class=bl>m.Chylík</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>P.Plešák</td><td class=bc>-</td><td class=bl>R.Jež</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>D.Šmíd</td><td class=bc>-</td><td class=blW>J.Dryák</td><td class=bc>0 : 5 K</tr></td>
</table></td></tr></table></td></tr></table>



<p class=v>Play-off<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><th colspan=11><font size="+1"><strong>Finále</strong></font></th></tr>
<tr><td class=br><b>Turoň Lukáš</b>&nbsp;&nbsp;</td>
<td class=bl>- Matoušek ml. Zdeněk&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 2&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:1&nbsp;&nbsp;</td>
<td class=bl>3:4 P&nbsp;&nbsp;</td>
<td class=bl>6:3&nbsp;&nbsp;</td>
<td class=bl>3:1&nbsp;&nbsp;</td>
<td class=bl>2:3&nbsp;&nbsp;</td>
<td class=bl>2:1 P&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>Semifinále</strong></font></th></tr>
<tr><td class=ar><b>Turoň Lukáš</b>&nbsp;&nbsp;</td>
<td class=al>- Hvižď Michal&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>5:0&nbsp;&nbsp;</td>
<td class=al>4:3&nbsp;&nbsp;</td>
<td class=al>4:5 P&nbsp;&nbsp;</td>
<td class=al>4:1&nbsp;&nbsp;</td>
<td class=al>0:1&nbsp;&nbsp;</td>
<td class=al>3:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><b>Matoušek ml. Zdeněk</b>&nbsp;&nbsp;</td>
<td class=bl>- Petr Patrik&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 2&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>5:1&nbsp;&nbsp;</td>
<td class=bl>7:2&nbsp;&nbsp;</td>
<td class=bl>3:4 P&nbsp;&nbsp;</td>
<td class=bl>3:4 P&nbsp;&nbsp;</td>
<td class=bl>4:2&nbsp;&nbsp;</td>
<td class=bl>6:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>O 3.místo</strong></font></th></tr>
<tr><td class=ar><b>Petr Patrik</b>&nbsp;&nbsp;</td>
<td class=al>- Hvižď Michal&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;1 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>5:0 K&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11><font size="+1"><strong>Čtvrtfinále</strong></font></th></tr>
<tr><td class=br><b>Turoň Lukáš</b>&nbsp;&nbsp;</td>
<td class=bl>- Turoň Petr&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;1 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>5:0 K&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar>Dryák Jan&nbsp;&nbsp;</td>
<td class=al><b>- Hvižď Michal</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;1 : 4&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:5&nbsp;&nbsp;</td>
<td class=al>3:2 P&nbsp;&nbsp;</td>
<td class=al>0:2&nbsp;&nbsp;</td>
<td class=al>1:3&nbsp;&nbsp;</td>
<td class=al>1:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br>Hvižď ml. Leoš&nbsp;&nbsp;</td>
<td class=bl><b>- Petr Patrik</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;0 : 4&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>0:7&nbsp;&nbsp;</td>
<td class=bl>0:6&nbsp;&nbsp;</td>
<td class=bl>2:5&nbsp;&nbsp;</td>
<td class=bl>1:4&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Matoušek ml. Zdeněk</b>&nbsp;&nbsp;</td>
<td class=al>- Hamáček Filip&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 1&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:0&nbsp;&nbsp;</td>
<td class=al>4:1&nbsp;&nbsp;</td>
<td class=al>4:1&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr></table></td></tr></table>

<p class=v>Konečné pořadí turnaje<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>Z</th>
<th>+</th>
<th>=</th>
<th>-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th>B</th>
<th></th>
<th>&nbsp;</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al>Turoň Lukáš</td>
<td class=al>THC Třinec</td>
<td class=ar>43</td>
<td class=ar>34</td>
<td class=ar>3</td>
<td class=ar>6</td>
<td class=ar>178</td>
<td class=al>: 67</td>
<td class=ar>71</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>2.</td>
<td class=bl>Matoušek ml. Zdeněk</td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>48</td>
<td class=br>36</td>
<td class=br>2</td>
<td class=br>10</td>
<td class=br>188</td>
<td class=bl>: 90</td>
<td class=br>74</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>3.</td>
<td class=al>Petr Patrik</td>
<td class=al>THC Stiga Elites</td>
<td class=ar>40</td>
<td class=ar>27</td>
<td class=ar>4</td>
<td class=ar>9</td>
<td class=ar>151</td>
<td class=al>: 77</td>
<td class=ar>58</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>4.</td>
<td class=bl>Hvižď Michal</td>
<td class=bl>THC Stiga Elites</td>
<td class=br>41</td>
<td class=br>24</td>
<td class=br>8</td>
<td class=br>9</td>
<td class=br>137</td>
<td class=bl>: 86</td>
<td class=br>56</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>5.</td>
<td class=al>Hvižď ml. Leoš</td>
<td class=al>THC Stiga-Game Příbram</td>
<td class=ar>35</td>
<td class=ar>25</td>
<td class=ar>2</td>
<td class=ar>8</td>
<td class=ar>136</td>
<td class=al>: 74</td>
<td class=ar>52</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>6.</td>
<td class=bl>Dryák Jan</td>
<td class=bl>Big Band</td>
<td class=br>35</td>
<td class=br>25</td>
<td class=br>1</td>
<td class=br>9</td>
<td class=br>139</td>
<td class=bl>: 65</td>
<td class=br>51</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>7.</td>
<td class=al>Hamáček Filip</td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>36</td>
<td class=ar>23</td>
<td class=ar>3</td>
<td class=ar>10</td>
<td class=ar>117</td>
<td class=al>: 61</td>
<td class=ar>49</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>8.</td>
<td class=bl>Turoň Petr</td>
<td class=bl>THC Třinec</td>
<td class=br>30</td>
<td class=br>17</td>
<td class=br>6</td>
<td class=br>7</td>
<td class=br>100</td>
<td class=bl>: 55</td>
<td class=br>40</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>9.</td>
<td class=al>Plešák Pavel</td>
<td class=al>APP Gladiators Plzeň</td>
<td class=ar>31</td>
<td class=ar>16</td>
<td class=ar>11</td>
<td class=ar>4</td>
<td class=ar>118</td>
<td class=al>: 70</td>
<td class=ar>43</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>10.</td>
<td class=bl>Lebl Kryštof</td>
<td class=bl>Big Band</td>
<td class=br>30</td>
<td class=br>21</td>
<td class=br>3</td>
<td class=br>6</td>
<td class=br>108</td>
<td class=bl>: 52</td>
<td class=br>45</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>11.</td>
<td class=al>Matýsek Daniel</td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>30</td>
<td class=ar>17</td>
<td class=ar>4</td>
<td class=ar>9</td>
<td class=ar>89</td>
<td class=al>: 56</td>
<td class=ar>38</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>12.</td>
<td class=bl>Krása Dušan</td>
<td class=bl>Big Band</td>
<td class=br>31</td>
<td class=br>15</td>
<td class=br>8</td>
<td class=br>8</td>
<td class=br>93</td>
<td class=bl>: 63</td>
<td class=br>38</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>13.</td>
<td class=al>Ženíšek Martin</td>
<td class=al>APP Gladiators Plzeň</td>
<td class=ar>31</td>
<td class=ar>15</td>
<td class=ar>4</td>
<td class=ar>12</td>
<td class=ar>99</td>
<td class=al>: 86</td>
<td class=ar>34</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>14.</td>
<td class=bl>Chylík ml. Jiří</td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>30</td>
<td class=br>14</td>
<td class=br>4</td>
<td class=br>12</td>
<td class=br>64</td>
<td class=bl>: 73</td>
<td class=br>32</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>15.</td>
<td class=al>Jež Robert</td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>30</td>
<td class=ar>15</td>
<td class=ar>2</td>
<td class=ar>13</td>
<td class=ar>81</td>
<td class=al>: 79</td>
<td class=ar>32</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>16.</td>
<td class=bl>Šmíd David</td>
<td class=bl>THC Stiga Svitavy 93</td>
<td class=br>23</td>
<td class=br>15</td>
<td class=br>3</td>
<td class=br>5</td>
<td class=br>83</td>
<td class=bl>: 50</td>
<td class=br>33</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>17.</td>
<td class=al>Pikl Václav</td>
<td class=al>THC Stiga Elites</td>
<td class=ar>23</td>
<td class=ar>11</td>
<td class=ar>7</td>
<td class=ar>5</td>
<td class=ar>81</td>
<td class=al>: 59</td>
<td class=ar>29</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>18.</td>
<td class=bl>Brdíček David</td>
<td class=bl>THC Stiga Svitavy 93</td>
<td class=br>23</td>
<td class=br>13</td>
<td class=br>3</td>
<td class=br>7</td>
<td class=br>77</td>
<td class=bl>: 60</td>
<td class=br>29</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>19.</td>
<td class=al>Zielinský Adam</td>
<td class=al>Big Band</td>
<td class=ar>23</td>
<td class=ar>12</td>
<td class=ar>4</td>
<td class=ar>7</td>
<td class=ar>59</td>
<td class=al>: 36</td>
<td class=ar>28</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>20.</td>
<td class=bl>Kobrle Michal</td>
<td class=bl>THC Stiga Elites</td>
<td class=br>23</td>
<td class=br>13</td>
<td class=br>2</td>
<td class=br>8</td>
<td class=br>76</td>
<td class=bl>: 81</td>
<td class=br>28</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>21.</td>
<td class=al>Matoušek st. Zdeněk</td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>23</td>
<td class=ar>12</td>
<td class=ar>2</td>
<td class=ar>9</td>
<td class=ar>52</td>
<td class=al>: 51</td>
<td class=ar>26</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>22.</td>
<td class=bl>Herold Kryštof</td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>23</td>
<td class=br>11</td>
<td class=br>3</td>
<td class=br>9</td>
<td class=br>73</td>
<td class=bl>: 64</td>
<td class=br>25</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>23.</td>
<td class=al>Boštík Michal</td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>23</td>
<td class=ar>12</td>
<td class=ar>2</td>
<td class=ar>9</td>
<td class=ar>78</td>
<td class=al>: 69</td>
<td class=ar>26</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>24.</td>
<td class=bl>Waclawek Tomáš</td>
<td class=bl>THC Třinec</td>
<td class=br>23</td>
<td class=br>11</td>
<td class=br>3</td>
<td class=br>9</td>
<td class=br>65</td>
<td class=bl>: 56</td>
<td class=br>25</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>25.</td>
<td class=al>Cibulka David</td>
<td class=al>THC Třinec</td>
<td class=ar>23</td>
<td class=ar>10</td>
<td class=ar>5</td>
<td class=ar>8</td>
<td class=ar>79</td>
<td class=al>: 60</td>
<td class=ar>25</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>26.</td>
<td class=bl>Vácha Jiří</td>
<td class=bl>SHC Cheb</td>
<td class=br>23</td>
<td class=br>11</td>
<td class=br>2</td>
<td class=br>10</td>
<td class=br>73</td>
<td class=bl>: 60</td>
<td class=br>24</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>27.</td>
<td class=al>Černoch Miroslav</td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>23</td>
<td class=ar>12</td>
<td class=ar>1</td>
<td class=ar>10</td>
<td class=ar>49</td>
<td class=al>: 49</td>
<td class=ar>25</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>28.</td>
<td class=bl>Jackowská Aneta</td>
<td class=bl>BSE České Budějovice</td>
<td class=br>23</td>
<td class=br>9</td>
<td class=br>4</td>
<td class=br>10</td>
<td class=br>52</td>
<td class=bl>: 56</td>
<td class=br>22</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>29.</td>
<td class=al>Sládek Honza</td>
<td class=al>THC Stiga Elites</td>
<td class=ar>23</td>
<td class=ar>10</td>
<td class=ar>5</td>
<td class=ar>8</td>
<td class=ar>70</td>
<td class=al>: 67</td>
<td class=ar>25</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>30.</td>
<td class=bl>Šurýn Antonín</td>
<td class=bl>Big Band</td>
<td class=br>23</td>
<td class=br>7</td>
<td class=br>6</td>
<td class=br>10</td>
<td class=br>57</td>
<td class=bl>: 64</td>
<td class=br>20</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>31.</td>
<td class=al>Lopaur Zdeněk</td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>23</td>
<td class=ar>9</td>
<td class=ar>1</td>
<td class=ar>13</td>
<td class=ar>59</td>
<td class=al>: 79</td>
<td class=ar>19</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>32.</td>
<td class=bl>Mašková Iva</td>
<td class=bl>SHC Cheb</td>
<td class=br>23</td>
<td class=br>7</td>
<td class=br>1</td>
<td class=br>15</td>
<td class=br>48</td>
<td class=bl>: 85</td>
<td class=br>15</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>33.</td>
<td class=al>Halama Tomáš</td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>23</td>
<td class=ar>8</td>
<td class=ar>1</td>
<td class=ar>14</td>
<td class=ar>46</td>
<td class=al>: 71</td>
<td class=ar>17</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>34.</td>
<td class=bl>Marek František</td>
<td class=bl>BSE České Budějovice</td>
<td class=br>23</td>
<td class=br>6</td>
<td class=br>2</td>
<td class=br>15</td>
<td class=br>50</td>
<td class=bl>: 77</td>
<td class=br>14</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>35.</td>
<td class=al>Matějka Marek</td>
<td class=al>BSE České Budějovice</td>
<td class=ar>23</td>
<td class=ar>5</td>
<td class=ar>2</td>
<td class=ar>16</td>
<td class=ar>41</td>
<td class=al>: 85</td>
<td class=ar>12</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>36.</td>
<td class=bl>Dvořák Tomáš</td>
<td class=bl>Big Band</td>
<td class=br>23</td>
<td class=br>4</td>
<td class=br>4</td>
<td class=br>15</td>
<td class=br>30</td>
<td class=bl>: 88</td>
<td class=br>12</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>37.</td>
<td class=al>Kouba Martin</td>
<td class=al>BSE České Budějovice</td>
<td class=ar>23</td>
<td class=ar>6</td>
<td class=ar>0</td>
<td class=ar>17</td>
<td class=ar>56</td>
<td class=al>: 98</td>
<td class=ar>12</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>38.</td>
<td class=bl>Pohořalý Pavel</td>
<td class=bl>THC Teplýšovice</td>
<td class=br>23</td>
<td class=br>4</td>
<td class=br>3</td>
<td class=br>16</td>
<td class=br>46</td>
<td class=bl>: 82</td>
<td class=br>11</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>39.</td>
<td class=al>Nechutný Hynek</td>
<td class=al>APP Gladiators Plzeň</td>
<td class=ar>23</td>
<td class=ar>5</td>
<td class=ar>1</td>
<td class=ar>17</td>
<td class=ar>39</td>
<td class=al>: 62</td>
<td class=ar>11</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>40.</td>
<td class=bl>Malý Josef</td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>23</td>
<td class=br>5</td>
<td class=br>0</td>
<td class=br>18</td>
<td class=br>43</td>
<td class=bl>: 78</td>
<td class=br>10</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>41.</td>
<td class=al>Kahoun ml. Tomáš</td>
<td class=al>Pelhřimov</td>
<td class=ar>23</td>
<td class=ar>2</td>
<td class=ar>5</td>
<td class=ar>16</td>
<td class=ar>25</td>
<td class=al>: 100</td>
<td class=ar>9</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>42.</td>
<td class=bl>Petr Jindřich</td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>23</td>
<td class=br>2</td>
<td class=br>2</td>
<td class=br>19</td>
<td class=br>36</td>
<td class=bl>: 97</td>
<td class=br>6</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>43.</td>
<td class=al>Kahoun st. Tomáš</td>
<td class=al>Pelhřimov</td>
<td class=ar>23</td>
<td class=ar>3</td>
<td class=ar>2</td>
<td class=ar>18</td>
<td class=ar>39</td>
<td class=al>: 89</td>
<td class=ar>8</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>44.</td>
<td class=bl>Přibil Jiří</td>
<td class=bl>BSE České Budějovice</td>
<td class=br>23</td>
<td class=br>2</td>
<td class=br>1</td>
<td class=br>20</td>
<td class=br>24</td>
<td class=bl>: 89</td>
<td class=br>5</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>45.</td>
<td class=al>Kobrle Lukáš</td>
<td class=al>THC Stiga Elites</td>
<td class=ar>23</td>
<td class=ar>2</td>
<td class=ar>1</td>
<td class=ar>20</td>
<td class=ar>30</td>
<td class=al>: 89</td>
<td class=ar>5</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>46.</td>
<td class=bl>Petrová Barbora</td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>23</td>
<td class=br>2</td>
<td class=br>1</td>
<td class=br>20</td>
<td class=br>39</td>
<td class=bl>: 123</td>
<td class=br>5</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>47.</td>
<td class=al>Malík Jiří</td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>23</td>
<td class=ar>2</td>
<td class=ar>1</td>
<td class=ar>20</td>
<td class=ar>26</td>
<td class=al>: 100</td>
<td class=ar>5</td>
<td class=art></td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>48.</td>
<td class=bl>Sládek Petr</td>
<td class=bl>THC Stiga Elites</td>
<td class=br>23</td>
<td class=br>0</td>
<td class=br>1</td>
<td class=br>22</td>
<td class=br>32</td>
<td class=bl>: 103</td>
<td class=br>1</td>
<td class=brt></td>
<td class=br>&nbsp;</td>
</tr></table></td></tr></table></div></p>


</body>
</html>