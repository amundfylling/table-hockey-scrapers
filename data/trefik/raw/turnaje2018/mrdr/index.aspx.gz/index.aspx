<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR družstva</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.stolnihokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="../../pohar.aspx">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>MR družstva 2. červen 2018</span></h2></div></div></div></div><p><div align="center">
<div align=center>
<a href="kriz.aspx">Zápasy ve skupinách (Basic and placement groups)</a><br>
<a href="MR_druzstva_umisteni.aspx ">Zápasy o umístění (Placement matches)</a><br>
</div>



<p class=v>Konečné pořadí turnaje<br>

<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>

<tr><td class=ar>1.</td>
<td class=al>HCS Žabka Praha<br>
Filip Hamáček, Zdeněk Matoušek ml., Jiří Chylík, Daniel Matýsek, Miroslav Černoch, Kryštof Herold, Jakub Matýsek, Zdeněk Matoušek st. </td>
</tr>

<tr><td class=br>2.</td>
<td class=bl>THC Stiga-Game Příbram "A"<br>
Leoš Hvižď ml., Michal Hvižď, Jakub Sládek, Jan Sládek, Martin Maděra, David Dvořáček, Josef Kůrka, Tomáš Jedlička
</td>
</tr>

<tr><td class=ar>3.</td>
<td class=al>Absolut Desperation<br>
Stanislav Kraus, David Šmíd, Vladimír Kraus, Zbyněk Pilař, David Brdíček, Michal Zunka, Radim Nevrlík
</td>
</tr>

<tr><td class=br>4.</td>
<td class=bl>Big Band Senior<br>
Kryštof Lebl, Jan Dryák, Adam Zielinský, Antonín Šurýn, Standa Suchý
</td>
</tr>

<tr><td class=ar>5.</td>
<td class=al>THC Třinec<br>
Lukáš Turoň, Petr Turoň, Tomáš Waclawek, Jiří Cibulka, David Cibulka, Roman Pavlica
</td>
</tr>

<tr><td class=br>6.</td>
<td class=bl>APP Gladiators Plzeň "A"<br>
Pavel Plešák, Václav Pikl, Martin Ženíšek, Miloš Ševr, Hynek Nechutný
</td>
</tr>

<tr><td class=ar>7.</td>
<td class=al>BSE United "A"<br>
Samuel Hána, Lukáš Paclík, František Marek, Tomáš Kahoun ml., Tomáš Kahoun st.
</td>
</tr>

<tr><td class=br>8.</td>
<td class=bl>SHC Cheb <br>
Miloslav Kubica, Jiří Vácha, Luboš Černý, Zbyněk Froněk, Daniel Hrachovec, Václav Macek
</td>
</tr>

<tr><td class=ar>9.</td>
<td class=al>Stiga HC Benátky<br>
Michal Boštík, Tomáš Bucek, Zdeněk Lopaur, Josef Sedláček, Radek Bidlo, Jindřich Petr
</td>
</tr>

<tr><td class=br>10.</td>
<td class=bl>APP Gladiators Plzeň "B"<br>
Miroslav Uhlíř, Pavel Kubrt, Jan Kubernát, Markéta Jindrová, Matěj Cingroš
</td>
</tr>

</tr><tr><td class=ar>11.</td>
<td class=al>SHC Cheb - Black Horses<br>
Václav Mezera, Michal Holeček, Iva Mašková, Jan Medvec, Josef Gruncl, Stanislav Srba
</td>
</tr>

<tr><td class=br>12.</td>
<td class=bl>THC Teplýšovice<br>
Pavel Pohořalý, Vlasta Gobyová, Vojtěch Goby, Tomáš Kratochvíl, Pavel Goby
</td>
</tr>

<tr><td class=ar>13.</td>
<td class=al>THC Stiga-Game Příbram "B"<br>
Tomáš Růžička, Vojtěch Bernát, Pavel Hráský, Karel Krejčík, Anita Grimová, Jan Peleščák, Petr Vlach
</td>
</tr>

<tr><td class=br>14.</td>
<td class=bl>SHC Cheb - Oranžová torpéda<br>
Jiří Kropáček, Petr Holub, Miroslava Horáková, Jaroslav Ouřada, Michal Mašika, Jiří Macek
</td>
</tr>

<tr><td class=ar>15.</td>
<td class=al>Big Band Junior<br>
Alexandr Mačynský, Petr Fuchs, Vít Perkner, Jonáš Perkner, Lukáš Vaněk
</td>
</tr>

<tr><td class=br>16.</td>
<td class=bl>BSE United "B"<br>
Lukáš Kahoun, Hana Marešová, Matyáš Klazar, Petr Klazar, Jana Kahounová
</td>
</tr>

<tr><td class=ar>17.</td>
<td class=al>SHC Cheb - White Jets<br>
Jan Kubica, Jan Černák, Roman Hejda, Pavel Zeman, Michal Ouřada
</td>
</tr>
</table></td></tr></table></div>


</p>


</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
