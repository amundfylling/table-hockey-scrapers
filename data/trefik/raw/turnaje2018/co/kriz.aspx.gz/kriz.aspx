<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open - Praha</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.stolnihokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="../../pohar.aspx">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co">Czech Open - Praha 21. duben 2018</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p><a href="#basic">Základní skupiny (Basic groups)</a><br>
<a href="#final">Výkonnostní skupiny (Final groups)</a><br>
<a name="basic"><p class=vm>Základní skupiny (Basic groups)</p></a>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Pa Petr</td><td class=kx>*</td>
<td class=kW>8:2</td>
<td class=kL>3:4</td>
<td class=kW>7:3</td>
<td class=kW>5:2</td>
<td class=kW>5:4</td>
<td class=kW>10:2</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kT>4:4</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>8:1</td>
<td class=kW>6:1</td>
<td class=kW>8:2</td>
<td class=kW>8:0</td>
<td class=br>91:36</td><td class=br>+55</td>
<td class=bc>13 - 2 - 1</td>
<td class=br><strong>28</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>St Kraus</td><td class=kL>2:8</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>3:6</td>
<td class=kW>9:4</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>8:1</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>8:2</td>
<td class=kW>9:2</td>
<td class=br>88:36</td><td class=br>+52</td>
<td class=bc>13 - 1 - 2</td>
<td class=br><strong>27</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Jo Kůrka</td><td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>5:3</td>
<td class=kL>0:7</td>
<td class=kW>2:0</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>9:1</td>
<td class=kW>7:1</td>
<td class=kW>8:1</td>
<td class=kW>9:2</td>
<td class=br>71:34</td><td class=br>+37</td>
<td class=bc>13 - 1 - 2</td>
<td class=br><strong>27</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ja Matýsek</td><td class=kL>3:7</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kW>7:1</td>
<td class=kL>2:5</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=br>66:40</td><td class=br>+26</td>
<td class=bc>11 - 3 - 2</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ka Hudec</td><td class=kL>2:5</td>
<td class=kL>4:9</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kL>2:5</td>
<td class=kW>6:0</td>
<td class=kW>9:1</td>
<td class=kW>9:1</td>
<td class=kW>8:2</td>
<td class=kW>8:0</td>
<td class=br>76:37</td><td class=br>+39</td>
<td class=bc>11 - 1 - 4</td>
<td class=br><strong>23</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Vá Pikl</td><td class=kL>4:5</td>
<td class=kL>1:5</td>
<td class=kW>7:0</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=kW>12:0</td>
<td class=kW>10:2</td>
<td class=kW>8:1</td>
<td class=br>62:22</td><td class=br>+40</td>
<td class=bc>9 - 1 - 6</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>To Kahoun st.</td><td class=kL>2:10</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=br>46:42</td><td class=br>+4</td>
<td class=bc>8 - 2 - 6</td>
<td class=br><strong>18</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Be Rjavec</td><td class=kT>4:4</td>
<td class=kL>2:6</td>
<td class=kL>3:5</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>13:1</td>
<td class=br>56:38</td><td class=br>+18</td>
<td class=bc>7 - 4 - 5</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Mi Mitro ml.</td><td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kL>3:6</td>
<td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>8:1</td>
<td class=kW>5:1</td>
<td class=br>52:39</td><td class=br>+13</td>
<td class=bc>7 - 2 - 7</td>
<td class=br><strong>16</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Si Thomas</td><td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kW>7:3</td>
<td class=kW>7:0</td>
<td class=kW>8:0</td>
<td class=kW>9:2</td>
<td class=br>50:34</td><td class=br>+16</td>
<td class=bc>7 - 2 - 7</td>
<td class=br><strong>16</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Zd Matoušek st.</td><td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kT>0:0</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=br>37:35</td><td class=br>+2</td>
<td class=bc>6 - 4 - 6</td>
<td class=br><strong>16</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Cs Kocsis</td><td class=kL>1:5</td>
<td class=kL>1:8</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>10:1</td>
<td class=kW>7:4</td>
<td class=kW>7:1</td>
<td class=kW>9:4</td>
<td class=kW>5:3</td>
<td class=br>56:60</td><td class=br>-4</td>
<td class=bc>7 - 0 - 9</td>
<td class=br><strong>14</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ma Pikat</td><td class=kL>3:4</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kT>0:0</td>
<td class=kL>1:10</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=br>18:54</td><td class=br>-36</td>
<td class=bc>3 - 3 - 10</td>
<td class=br><strong>9</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ví Perkner</td><td class=kL>1:8</td>
<td class=kL>1:6</td>
<td class=kL>1:9</td>
<td class=kL>2:5</td>
<td class=kL>1:9</td>
<td class=kL>0:1</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>3:7</td>
<td class=kL>1:5</td>
<td class=kL>4:7</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>8:2</td>
<td class=kW>4:0</td>
<td class=br>35:72</td><td class=br>-37</td>
<td class=bc>3 - 1 - 12</td>
<td class=br><strong>7</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ja Kubica</td><td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kL>1:9</td>
<td class=kL>0:12</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=br>20:89</td><td class=br>-69</td>
<td class=bc>2 - 1 - 13</td>
<td class=br><strong>5</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Mi Horáková</td><td class=kL>2:8</td>
<td class=kL>2:8</td>
<td class=kL>1:8</td>
<td class=kL>2:6</td>
<td class=kL>2:8</td>
<td class=kL>2:10</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>1:8</td>
<td class=kL>0:8</td>
<td class=kL>0:3</td>
<td class=kL>4:9</td>
<td class=kT>2:2</td>
<td class=kL>2:8</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=br>30:102</td><td class=br>-72</td>
<td class=bc>1 - 2 - 13</td>
<td class=br><strong>4</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Pe Klazar</td><td class=kL>0:8</td>
<td class=kL>2:9</td>
<td class=kL>2:9</td>
<td class=kL>2:6</td>
<td class=kL>0:8</td>
<td class=kL>1:8</td>
<td class=kL>0:3</td>
<td class=kL>1:13</td>
<td class=kL>1:5</td>
<td class=kL>2:9</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=br>17:101</td><td class=br>-84</td>
<td class=bc>0 - 0 - 16</td>
<td class=br><strong>0</strong></td><td class=d>17.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ma Pikat</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Cs Kocsis</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ja Kubica</td><td class=bc>-</td><td class=blW>Mi Mitro ml.</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Jo Kůrka</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 10</tr></td>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 10</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ví Perkner</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Cs Kocsis</td><td class=bc>-</td><td class=bl>Mi Mitro ml.</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ja Kubica</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=bl>Mi Mitro ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Cs Kocsis</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Mi Mitro ml.</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Jo Kůrka</td><td class=bc>2 : 9</tr></td>
<tr><td class=brW>Cs Kocsis</td><td class=bc>-</td><td class=bl>Ja Kubica</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=bl>Mi Mitro ml.</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>Jo Kůrka</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Ja Kubica</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>2 : 9</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ma Pikat</td><td class=bc>-</td><td class=bl>Mi Mitro ml.</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Jo Kůrka</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=bl>Ja Kubica</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>4 : 9</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Cs Kocsis</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Mi Mitro ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Ja Kubica</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Cs Kocsis</td><td class=bc>4 : 9</tr></td>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>8 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Jo Kůrka</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>Ja Kubica</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Cs Kocsis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Mitro ml.</td><td class=bc>-</td><td class=blW>Jo Kůrka</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>Ja Kubica</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>Cs Kocsis</td><td class=bc>1 : 10</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Jo Kůrka</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ja Kubica</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Mitro ml.</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Cs Kocsis</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>Ja Kubica</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Cs Kocsis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ja Kubica</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>Cs Kocsis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Mitro ml.</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Cs Kocsis</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ja Kubica</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Cs Kocsis</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ja Kubica</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Mi Mitro ml.</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Ma Pikat</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Cs Kocsis</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ja Kubica</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mi Mitro ml.</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Cs Kocsis</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ja Kubica</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 12</tr></td>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>1 : 13</tr></td>
<tr><td class=br>Cs Kocsis</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ja Kubica</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Mi Mitro ml.</td><td class=bc>0 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Pe Turoň</td><td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kW>9:2</td>
<td class=kW>2:0</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>6:0</td>
<td class=br>62:22</td><td class=br>+40</td>
<td class=bc>14 - 1 - 1</td>
<td class=br><strong>29</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Le Hvižď ml.</td><td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>4:5</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>2:0</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>8:1</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=kW>9:2</td>
<td class=br>74:27</td><td class=br>+47</td>
<td class=bc>12 - 2 - 2</td>
<td class=br><strong>26</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ma Maděra</td><td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=kW>8:1</td>
<td class=kW>5:4</td>
<td class=kL>4:6</td>
<td class=kW>4:2</td>
<td class=kW>8:2</td>
<td class=kW>8:2</td>
<td class=kW>9:2</td>
<td class=br>73:34</td><td class=br>+39</td>
<td class=bc>12 - 1 - 3</td>
<td class=br><strong>25</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>My Shalomayev</td><td class=kW>3:1</td>
<td class=kW>5:4</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>9:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>8:2</td>
<td class=kW>6:1</td>
<td class=br>66:31</td><td class=br>+35</td>
<td class=bc>12 - 1 - 3</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Da Matýsek</td><td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=br>43:21</td><td class=br>+22</td>
<td class=bc>11 - 1 - 4</td>
<td class=br><strong>23</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Vl Kraus</td><td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kT>1:1</td>
<td class=kW>9:3</td>
<td class=kW>6:1</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>9:1</td>
<td class=kW>8:0</td>
<td class=br>59:37</td><td class=br>+22</td>
<td class=bc>9 - 1 - 6</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>To Jedlička</td><td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>7:3</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kL>0:5</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=br>41:36</td><td class=br>+5</td>
<td class=bc>8 - 3 - 5</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Fe Šuma</td><td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=br>44:44</td><td class=br>0</td>
<td class=bc>8 - 0 - 8</td>
<td class=br><strong>16</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ji Cibulka</td><td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kL>1:7</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kL>3:7</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=br>41:40</td><td class=br>+1</td>
<td class=bc>6 - 3 - 7</td>
<td class=br><strong>15</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ha Marešová</td><td class=kL>0:1</td>
<td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kW>3:0</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=br>21:34</td><td class=br>-13</td>
<td class=bc>6 - 3 - 7</td>
<td class=br><strong>15</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Pe Fuchs</td><td class=kL>2:9</td>
<td class=kL>1:6</td>
<td class=kL>1:8</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>3:9</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=br>39:62</td><td class=br>-23</td>
<td class=bc>6 - 1 - 9</td>
<td class=br><strong>13</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Pa Pohořalý</td><td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kL>4:5</td>
<td class=kL>3:9</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kW>5:0</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=br>45:47</td><td class=br>-2</td>
<td class=bc>6 - 1 - 9</td>
<td class=br><strong>13</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Al Lorand st.</td><td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kW>6:4</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kW>2:0</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=br>38:49</td><td class=br>-11</td>
<td class=bc>5 - 2 - 9</td>
<td class=br><strong>12</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Jo Perkner</td><td class=kL>2:5</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=br>28:51</td><td class=br>-23</td>
<td class=bc>5 - 1 - 10</td>
<td class=br><strong>11</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Vl Lux</td><td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kL>2:8</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=br>25:56</td><td class=br>-31</td>
<td class=bc>2 - 1 - 13</td>
<td class=br><strong>5</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Jo Sedláček</td><td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kL>2:8</td>
<td class=kL>2:8</td>
<td class=kL>2:4</td>
<td class=kL>1:9</td>
<td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=br>30:76</td><td class=br>-46</td>
<td class=bc>2 - 1 - 13</td>
<td class=br><strong>5</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Ja Peleščák</td><td class=kL>0:6</td>
<td class=kL>2:9</td>
<td class=kL>2:9</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>0:8</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=br>21:83</td><td class=br>-62</td>
<td class=bc>0 - 1 - 15</td>
<td class=br><strong>1</strong></td><td class=d>17.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ji Cibulka</td><td class=bc>-</td><td class=bl>Pe Turoň</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Fe Šuma</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Vl Lux</td><td class=bc>-</td><td class=bl>Ja Peleščák</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Fe Šuma</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ji Cibulka</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ja Peleščák</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Vl Lux</td><td class=bc>-</td><td class=blW>Ha Marešová</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Fe Šuma</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ji Cibulka</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ja Peleščák</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>6 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Fe Šuma</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ji Cibulka</td><td class=bc>-</td><td class=bl>Ja Peleščák</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Vl Lux</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Pa Pohořalý</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Fe Šuma</td><td class=bc>-</td><td class=bl>Ja Peleščák</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ji Cibulka</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Vl Lux</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Ja Peleščák</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Fe Šuma</td><td class=bc>-</td><td class=blW>Ha Marešová</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ji Cibulka</td><td class=bc>-</td><td class=bl>Vl Lux</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Ja Peleščák</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Ha Marešová</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Fe Šuma</td><td class=bc>-</td><td class=bl>Vl Lux</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ji Cibulka</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ja Peleščák</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=bl>Vl Lux</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Fe Šuma</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ji Cibulka</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ja Peleščák</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 9</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Vl Lux</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Fe Šuma</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>9 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Vl Lux</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ja Peleščák</td><td class=bc>-</td><td class=blW>Al Lorand st.</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Fe Šuma</td><td class=bc>-</td><td class=bl>Ji Cibulka</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Vl Lux</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ja Peleščák</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Ji Cibulka</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Pe Turoň</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Vl Lux</td><td class=bc>-</td><td class=blW>Al Lorand st.</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Peleščák</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Ji Cibulka</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Fe Šuma</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Vl Lux</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ha Marešová</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ji Cibulka</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Peleščák</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Fe Šuma</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>3 : 9</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vl Lux</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ji Cibulka</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Fe Šuma</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ja Peleščák</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>9 : 3</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Ji Cibulka</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vl Lux</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Fe Šuma</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ja Peleščák</td><td class=bc>-</td><td class=blW>Pa Pohořalý</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>Ji Cibulka</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Fe Šuma</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vl Lux</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Ha Marešová</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ji Cibulka</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>Fe Šuma</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vl Lux</td><td class=bc>-</td><td class=blW>Pa Pohořalý</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ha Marešová</td><td class=bc>-</td><td class=bl>Ja Peleščák</td><td class=bc>2 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 3</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Mi Hvižď</td><td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>6:2</td>
<td class=kW>6:4</td>
<td class=kW>8:4</td>
<td class=kT>0:0</td>
<td class=kW>9:0</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>9:0</td>
<td class=br>83:20</td><td class=br>+63</td>
<td class=bc>14 - 2 - 0</td>
<td class=br><strong>30</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Em Larsson</td><td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=kW>8:1</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>8:1</td>
<td class=br>70:24</td><td class=br>+46</td>
<td class=bc>13 - 1 - 2</td>
<td class=br><strong>27</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ro Jež</td><td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=br>50:34</td><td class=br>+16</td>
<td class=bc>11 - 1 - 4</td>
<td class=br><strong>23</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Pa Plešák</td><td class=kL>4:6</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kT>5:5</td>
<td class=kL>4:5</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=br>70:33</td><td class=br>+37</td>
<td class=bc>10 - 3 - 3</td>
<td class=br><strong>23</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ge Regula</td><td class=kL>4:8</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>5:4</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=br>72:47</td><td class=br>+25</td>
<td class=bc>11 - 1 - 4</td>
<td class=br><strong>23</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Mi Ševr</td><td class=kT>0:0</td>
<td class=kL>0:5</td>
<td class=kW>6:2</td>
<td class=kT>5:5</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=kW>7:1</td>
<td class=br>60:43</td><td class=br>+17</td>
<td class=bc>9 - 3 - 4</td>
<td class=br><strong>21</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>To Hudec</td><td class=kL>0:9</td>
<td class=kL>0:1</td>
<td class=kW>4:1</td>
<td class=kW>5:4</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=br>50:44</td><td class=br>+6</td>
<td class=bc>9 - 1 - 6</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>To Halama</td><td class=kL>0:4</td>
<td class=kL>1:8</td>
<td class=kL>1:2</td>
<td class=kL>3:7</td>
<td class=kL>2:4</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=br>45:45</td><td class=br>0</td>
<td class=bc>8 - 2 - 6</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>To Růžička</td><td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>6:0</td>
<td class=kW>5:2</td>
<td class=br>42:41</td><td class=br>+1</td>
<td class=bc>8 - 0 - 8</td>
<td class=br><strong>16</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Al Mačynský</td><td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>0:2</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=br>34:37</td><td class=br>-3</td>
<td class=bc>5 - 5 - 6</td>
<td class=br><strong>15</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Zd Lopaur</td><td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=br>32:51</td><td class=br>-19</td>
<td class=bc>5 - 1 - 10</td>
<td class=br><strong>11</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Pe Holub</td><td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=br>25:53</td><td class=br>-28</td>
<td class=bc>4 - 2 - 10</td>
<td class=br><strong>10</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Jo Malý</td><td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=br>26:45</td><td class=br>-19</td>
<td class=bc>4 - 2 - 10</td>
<td class=br><strong>10</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Mi Franek</td><td class=kL>4:5</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kW>3:0</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=br>38:49</td><td class=br>-11</td>
<td class=bc>5 - 0 - 11</td>
<td class=br><strong>10</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Hy Nechutný</td><td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=br>24:42</td><td class=br>-18</td>
<td class=bc>2 - 6 - 8</td>
<td class=br><strong>10</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Mi Zeman</td><td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>0:7</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>24:72</td><td class=br>-48</td>
<td class=bc>2 - 1 - 13</td>
<td class=br><strong>5</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>On Bednář</td><td class=kL>0:9</td>
<td class=kL>1:8</td>
<td class=kL>0:7</td>
<td class=kL>0:8</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>11:76</td><td class=br>-65</td>
<td class=bc>0 - 1 - 15</td>
<td class=br><strong>1</strong></td><td class=d>17.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Franek</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Ge Regula</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>On Bednář</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>On Bednář</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Franek</td><td class=bc>-</td><td class=blW>Ge Regula</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>On Bednář</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Mi Franek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>To Hudec</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ge Regula</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Ge Regula</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>On Bednář</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Franek</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>On Bednář</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Mi Franek</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>On Bednář</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Mi Franek</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Franek</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>On Bednář</td><td class=bc>-</td><td class=blW>To Hudec</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>To Hudec</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>On Bednář</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Mi Franek</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>To Hudec</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Mi Franek</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>On Bednář</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Franek</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>On Bednář</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Mi Franek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>On Bednář</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Ge Regula</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Mi Franek</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>On Bednář</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Mi Franek</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>On Bednář</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>To Hudec</td><td class=bc>-</td><td class=blW>Mi Franek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>On Bednář</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Ge Regula</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Mi Franek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>On Bednář</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>To Hudec</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Mi Franek</td><td class=bc>-</td><td class=bl>On Bednář</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>8 : 4</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>1 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 4</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ho Sládek</td><td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>9:1</td>
<td class=kW>7:0</td>
<td class=br>69:17</td><td class=br>+52</td>
<td class=bc>14 - 0 - 2</td>
<td class=br><strong>28</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Mi Boštík</td><td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kW>6:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>8:0</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=br>70:36</td><td class=br>+34</td>
<td class=bc>12 - 3 - 1</td>
<td class=br><strong>27</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ku Sládek</td><td class=kL>0:2</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kL>4:5</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>8:2</td>
<td class=kW>10:0</td>
<td class=kW>8:1</td>
<td class=kW>9:1</td>
<td class=kW>8:0</td>
<td class=br>80:20</td><td class=br>+60</td>
<td class=bc>13 - 0 - 3</td>
<td class=br><strong>26</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>ml Chylík</td><td class=kW>4:0</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>3:6</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>8:1</td>
<td class=br>58:31</td><td class=br>+27</td>
<td class=bc>12 - 1 - 3</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Dm Petrov</td><td class=kL>2:3</td>
<td class=kL>4:6</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kW>7:1</td>
<td class=kT>2:2</td>
<td class=kW>8:1</td>
<td class=kW>7:2</td>
<td class=kW>7:0</td>
<td class=br>69:34</td><td class=br>+35</td>
<td class=bc>11 - 1 - 4</td>
<td class=br><strong>23</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Mi Kubica</td><td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kW>6:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>9:2</td>
<td class=kW>4:2</td>
<td class=kW>9:2</td>
<td class=br>60:34</td><td class=br>+26</td>
<td class=bc>10 - 1 - 5</td>
<td class=br><strong>21</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Fr Marek</td><td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>6:3</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=br>57:39</td><td class=br>+18</td>
<td class=bc>9 - 2 - 5</td>
<td class=br><strong>20</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>An Naszádi</td><td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>8:1</td>
<td class=br>54:42</td><td class=br>+12</td>
<td class=bc>9 - 0 - 7</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ev Solovev</td><td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kW>5:4</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>7:0</td>
<td class=kW>6:3</td>
<td class=kW>14:0</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=br>60:48</td><td class=br>+12</td>
<td class=bc>8 - 1 - 7</td>
<td class=br><strong>17</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ma Martinec</td><td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kW>5:3</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kT>4:4</td>
<td class=kW>4:0</td>
<td class=kW>9:0</td>
<td class=kW>6:0</td>
<td class=kW>7:4</td>
<td class=kW>6:5</td>
<td class=br>62:51</td><td class=br>+11</td>
<td class=bc>7 - 1 - 8</td>
<td class=br><strong>15</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ma Bengtsson</td><td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=br>45:42</td><td class=br>+3</td>
<td class=bc>5 - 4 - 7</td>
<td class=br><strong>14</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Iv Mašková</td><td class=kL>0:8</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>3:6</td>
<td class=kL>0:7</td>
<td class=kL>3:4</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kW>4:0</td>
<td class=br>41:53</td><td class=br>-12</td>
<td class=bc>5 - 3 - 8</td>
<td class=br><strong>13</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Pa Hráský</td><td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>2:8</td>
<td class=kL>3:6</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>8:2</td>
<td class=br>27:69</td><td class=br>-42</td>
<td class=bc>3 - 2 - 11</td>
<td class=br><strong>8</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ra Bidlo</td><td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>0:10</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kL>0:9</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=br>24:70</td><td class=br>-46</td>
<td class=bc>1 - 4 - 11</td>
<td class=br><strong>6</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>An Lux</td><td class=kL>1:5</td>
<td class=kL>0:8</td>
<td class=kL>1:8</td>
<td class=kL>0:3</td>
<td class=kL>1:8</td>
<td class=kL>2:9</td>
<td class=kL>3:6</td>
<td class=kL>3:4</td>
<td class=kL>0:14</td>
<td class=kL>0:6</td>
<td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=br>24:90</td><td class=br>-66</td>
<td class=bc>2 - 1 - 13</td>
<td class=br><strong>5</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>La Kulhánek</td><td class=kL>1:9</td>
<td class=kL>3:4</td>
<td class=kL>1:9</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>4:7</td>
<td class=kL>1:6</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=br>30:80</td><td class=br>-50</td>
<td class=bc>1 - 2 - 13</td>
<td class=br><strong>4</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Ma Cingroš</td><td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kL>0:8</td>
<td class=kL>1:8</td>
<td class=kL>0:7</td>
<td class=kL>2:9</td>
<td class=kL>1:5</td>
<td class=kL>1:8</td>
<td class=kT>1:1</td>
<td class=kL>5:6</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>2:8</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=br>18:92</td><td class=br>-74</td>
<td class=bc>0 - 2 - 14</td>
<td class=br><strong>2</strong></td><td class=d>17.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ma Bengtsson</td><td class=bc>-</td><td class=blW>Ev Solovev</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>An Naszádi</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Ma Martinec</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>La Kulhánek</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ev Solovev</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ma Bengtsson</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Ma Martinec</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>An Lux</td><td class=bc>9 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ev Solovev</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Bengtsson</td><td class=bc>-</td><td class=blW>An Naszádi</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ma Martinec</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>An Lux</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>La Kulhánek</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ev Solovev</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Bengtsson</td><td class=bc>-</td><td class=blW>Ma Martinec</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>An Lux</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>La Kulhánek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ma Martinec</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ev Solovev</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ma Bengtsson</td><td class=bc>-</td><td class=bl>An Lux</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ra Bidlo</td><td class=bc>-</td><td class=bl>La Kulhánek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>1 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Ma Martinec</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>An Lux</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ev Solovev</td><td class=bc>-</td><td class=bl>La Kulhánek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Bengtsson</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=bl>Ma Martinec</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>An Lux</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>La Kulhánek</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ev Solovev</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Bengtsson</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>An Lux</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>An Naszádi</td><td class=bc>-</td><td class=bl>La Kulhánek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ev Solovev</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Bengtsson</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>An Lux</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ma Martinec</td><td class=bc>-</td><td class=bl>La Kulhánek</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>An Naszádi</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ev Solovev</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>An Lux</td><td class=bc>-</td><td class=bl>La Kulhánek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>An Naszádi</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ma Bengtsson</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>La Kulhánek</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Lux</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ma Martinec</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>An Naszádi</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Ma Bengtsson</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ev Solovev</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>La Kulhánek</td><td class=bc>-</td><td class=blW>Pa Hráský</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>An Lux</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ma Martinec</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Ma Bengtsson</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>An Naszádi</td><td class=bc>-</td><td class=bl>Ev Solovev</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>La Kulhánek</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>An Lux</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>Ma Bengtsson</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=blW>Ev Solovev</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>La Kulhánek</td><td class=bc>-</td><td class=blW>Ma Bengtsson</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>An Lux</td><td class=bc>-</td><td class=blW>Ev Solovev</td><td class=bc>0 : 14</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=bl>Ma Bengtsson</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Ev Solovev</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>La Kulhánek</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>An Lux</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=blW>An Naszádi</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Ma Bengtsson</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Ev Solovev</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>La Kulhánek</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>An Lux</td><td class=bc>-</td><td class=blW>An Naszádi</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=bl>Ma Bengtsson</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ev Solovev</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>La Kulhánek</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>An Lux</td><td class=bc>-</td><td class=blW>Ma Martinec</td><td class=bc>0 : 6</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 5</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Mi Kobrle</td><td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kW>8:2</td>
<td class=kW>2:0</td>
<td class=kW>6:0</td>
<td class=kW>6:3</td>
<td class=kW>7:1</td>
<td class=kW>8:2</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kW>8:2</td>
<td class=kW>8:0</td>
<td class=kW>8:2</td>
<td class=kW>7:0</td>
<td class=br>95:25</td><td class=br>+70</td>
<td class=bc>15 - 0 - 1</td>
<td class=br><strong>30</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Zd Matoušek ml.</td><td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>8:1</td>
<td class=kW>6:3</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>8:4</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>8:4</td>
<td class=kW>8:1</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=kW>11:0</td>
<td class=br>91:24</td><td class=br>+67</td>
<td class=bc>15 - 0 - 1</td>
<td class=br><strong>30</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Sa Hána</td><td class=kW>4:3</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kT>0:0</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=kW>7:2</td>
<td class=kW>7:3</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kT>4:4</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>7:3</td>
<td class=kW>6:0</td>
<td class=br>68:37</td><td class=br>+31</td>
<td class=bc>11 - 4 - 1</td>
<td class=br><strong>26</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Kr Herold</td><td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=br>63:28</td><td class=br>+35</td>
<td class=bc>12 - 0 - 4</td>
<td class=br><strong>24</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Da Mitro</td><td class=kL>2:8</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>8:4</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>8:1</td>
<td class=kW>11:1</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=br>73:42</td><td class=br>+31</td>
<td class=bc>11 - 1 - 4</td>
<td class=br><strong>23</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>To Kahoun ml.</td><td class=kL>0:2</td>
<td class=kL>1:8</td>
<td class=kT>0:0</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>7:0</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=kW>6:2</td>
<td class=br>51:40</td><td class=br>+11</td>
<td class=bc>8 - 4 - 4</td>
<td class=br><strong>20</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ma Ženíšek</td><td class=kL>0:6</td>
<td class=kL>3:6</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>8:2</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=br>53:44</td><td class=br>+9</td>
<td class=bc>8 - 2 - 6</td>
<td class=br><strong>18</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ad Zielinský</td><td class=kL>3:6</td>
<td class=kL>0:4</td>
<td class=kL>4:5</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=br>53:44</td><td class=br>+9</td>
<td class=bc>8 - 2 - 6</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Da Cibulka</td><td class=kL>1:7</td>
<td class=kL>0:1</td>
<td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>1:5</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=kW>8:3</td>
<td class=kW>6:3</td>
<td class=kW>8:2</td>
<td class=br>52:41</td><td class=br>+11</td>
<td class=bc>7 - 2 - 7</td>
<td class=br><strong>16</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Mi Uhlíř</td><td class=kL>2:8</td>
<td class=kL>4:8</td>
<td class=kL>3:7</td>
<td class=kL>2:7</td>
<td class=kL>1:6</td>
<td class=kT>4:4</td>
<td class=kW>5:4</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=kL>1:4</td>
<td class=kW>9:0</td>
<td class=br>57:62</td><td class=br>-5</td>
<td class=bc>6 - 2 - 8</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Lu Varga</td><td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kL>4:8</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kW>5:1</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kW>7:0</td>
<td class=kW>8:0</td>
<td class=br>52:56</td><td class=br>-4</td>
<td class=bc>5 - 3 - 8</td>
<td class=br><strong>13</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Št Ivan</td><td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=br>41:51</td><td class=br>-10</td>
<td class=bc>5 - 1 - 10</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Vl Gobyová</td><td class=kL>3:5</td>
<td class=kL>4:8</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kL>0:5</td>
<td class=kL>0:7</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kW>6:2</td>
<td class=br>43:66</td><td class=br>-23</td>
<td class=bc>5 - 1 - 10</td>
<td class=br><strong>11</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Wo Abshagen</td><td class=kL>2:8</td>
<td class=kL>1:8</td>
<td class=kT>4:4</td>
<td class=kL>0:4</td>
<td class=kL>1:8</td>
<td class=kL>2:3</td>
<td class=kL>2:8</td>
<td class=kL>3:5</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kW>5:3</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>9:0</td>
<td class=br>39:76</td><td class=br>-37</td>
<td class=bc>3 - 2 - 11</td>
<td class=br><strong>8</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Lu Vaněk</td><td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>1:11</td>
<td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kL>3:8</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>5:3</td>
<td class=br>28:83</td><td class=br>-55</td>
<td class=bc>2 - 1 - 13</td>
<td class=br><strong>5</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>An Grimová</td><td class=kL>2:8</td>
<td class=kL>2:6</td>
<td class=kL>3:7</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kW>4:1</td>
<td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kT>1:1</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>29:79</td><td class=br>-50</td>
<td class=bc>2 - 1 - 13</td>
<td class=br><strong>5</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Ni Kupka</td><td class=kL>0:7</td>
<td class=kL>0:11</td>
<td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>2:8</td>
<td class=kL>0:9</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>0:9</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>15:105</td><td class=br>-90</td>
<td class=bc>0 - 0 - 16</td>
<td class=br><strong>0</strong></td><td class=d>17.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Lu Varga</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Lu Vaněk</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Št Ivan</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ni Kupka</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Wo Abshagen</td><td class=bc>-</td><td class=bl>Lu Varga</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ni Kupka</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Št Ivan</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Lu Varga</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>4 : 8</tr></td>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Ni Kupka</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Lu Varga</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Ni Kupka</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>Št Ivan</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Lu Varga</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>4 : 8</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ni Kupka</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Št Ivan</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Lu Varga</td><td class=bc>-</td><td class=bl>Ni Kupka</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=blW>Št Ivan</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Ni Kupka</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Lu Varga</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Št Ivan</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ni Kupka</td><td class=bc>11 : 0</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Št Ivan</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Lu Varga</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=blW>Sa Hána</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ni Kupka</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Št Ivan</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Sa Hána</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Lu Varga</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ni Kupka</td><td class=bc>-</td><td class=blW>Št Ivan</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Sa Hána</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Lu Varga</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Št Ivan</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ni Kupka</td><td class=bc>-</td><td class=blW>Sa Hána</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Wo Abshagen</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Lu Varga</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Št Ivan</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ni Kupka</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Sa Hána</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Št Ivan</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ni Kupka</td><td class=bc>-</td><td class=blW>Wo Abshagen</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Lu Varga</td><td class=bc>5 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Št Ivan</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ni Kupka</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Lu Varga</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>11 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Št Ivan</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Lu Varga</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ni Kupka</td><td class=bc>-</td><td class=blW>Lu Vaněk</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>8 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Št Ivan</td><td class=bc>-</td><td class=blW>Lu Varga</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ni Kupka</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=bl>Lu Varga</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Št Ivan</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Zd Matoušek ml.</td><td class=bc>4 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 6</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Mi Černoch</td><td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>8:1</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>7:0</td>
<td class=br>59:20</td><td class=br>+39</td>
<td class=bc>13 - 2 - 2</td>
<td class=br><strong>28</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Fi Hamáček</td><td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>64:22</td><td class=br>+42</td>
<td class=bc>13 - 2 - 2</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>An Šurýn</td><td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>12:3</td>
<td class=kW>5:2</td>
<td class=kW>6:3</td>
<td class=kW>4:0</td>
<td class=br>65:36</td><td class=br>+29</td>
<td class=bc>12 - 3 - 2</td>
<td class=br><strong>27</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Im Blaško</td><td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=kW>9:1</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kW>10:0</td>
<td class=kW>6:0</td>
<td class=kW>8:0</td>
<td class=br>77:21</td><td class=br>+56</td>
<td class=bc>13 - 1 - 3</td>
<td class=br><strong>27</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Kr Lebl</td><td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kT>3:3</td>
<td class=kW>6:4</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=br>58:32</td><td class=br>+26</td>
<td class=bc>12 - 1 - 4</td>
<td class=br><strong>25</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Lu Kobrle</td><td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>9:1</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=br>60:39</td><td class=br>+21</td>
<td class=bc>11 - 2 - 4</td>
<td class=br><strong>24</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>To Waclawek</td><td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kW>3:2</td>
<td class=kW>11:1</td>
<td class=kW>7:0</td>
<td class=kW>8:0</td>
<td class=kW>11:1</td>
<td class=br>86:40</td><td class=br>+46</td>
<td class=bc>11 - 2 - 4</td>
<td class=br><strong>24</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Mi Borgh</td><td class=kW>6:2</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kW>6:3</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>66:32</td><td class=br>+34</td>
<td class=bc>12 - 0 - 5</td>
<td class=br><strong>24</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ji Vácha</td><td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=br>55:39</td><td class=br>+16</td>
<td class=bc>10 - 2 - 5</td>
<td class=br><strong>22</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>To Bucek</td><td class=kL>0:2</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=kW>8:1</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=br>59:37</td><td class=br>+22</td>
<td class=bc>8 - 2 - 7</td>
<td class=br><strong>18</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>He Petuch</td><td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>4:6</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=br>43:55</td><td class=br>-12</td>
<td class=bc>5 - 2 - 10</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Vo Bernát</td><td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kL>1:7</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>7:0</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=br>49:65</td><td class=br>-16</td>
<td class=bc>4 - 3 - 10</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Mi Mareš st.</td><td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>1:9</td>
<td class=kL>1:6</td>
<td class=kL>1:9</td>
<td class=kL>1:7</td>
<td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=br>30:72</td><td class=br>-42</td>
<td class=bc>4 - 3 - 10</td>
<td class=br><strong>11</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ji Malík</td><td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=br>26:49</td><td class=br>-23</td>
<td class=bc>5 - 0 - 12</td>
<td class=br><strong>10</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ma Peško</td><td class=kL>1:8</td>
<td class=kL>1:4</td>
<td class=kL>3:12</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kL>1:11</td>
<td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kL>0:7</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=br>34:89</td><td class=br>-55</td>
<td class=bc>3 - 0 - 14</td>
<td class=br><strong>6</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Lu Toms</td><td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>0:10</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>0:7</td>
<td class=kL>3:6</td>
<td class=kL>1:6</td>
<td class=kL>1:8</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=br>24:71</td><td class=br>-47</td>
<td class=bc>2 - 2 - 13</td>
<td class=br><strong>6</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Ma Klazar</td><td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kL>3:6</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>0:8</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=br>14:72</td><td class=br>-58</td>
<td class=bc>1 - 1 - 15</td>
<td class=br><strong>3</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>E</td><td class=d>18.</td><td class=kt>Da Votrubec</td><td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:8</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>1:11</td>
<td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=br>9:87</td><td class=br>-78</td>
<td class=bc>0 - 0 - 17</td>
<td class=br><strong>0</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Da Votrubec</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Lu Toms</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Fi Hamáček</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ma Peško</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Lu Kobrle</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Da Votrubec</td><td class=bc>11 : 1</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Lu Toms</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ma Peško</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ji Malík</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Lu Kobrle</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Da Votrubec</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Lu Toms</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>Ma Peško</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Lu Kobrle</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Lu Toms</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Da Votrubec</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Ma Peško</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Lu Kobrle</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Lu Toms</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Da Votrubec</td><td class=bc>-</td><td class=blW>Ma Peško</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=blW>Lu Kobrle</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Fi Hamáček</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Lu Toms</td><td class=bc>-</td><td class=blW>Ma Peško</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Da Votrubec</td><td class=bc>-</td><td class=blW>Ji Malík</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Lu Kobrle</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Ma Peško</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Lu Toms</td><td class=bc>-</td><td class=blW>Ji Malík</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Da Votrubec</td><td class=bc>-</td><td class=blW>Lu Kobrle</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ma Peško</td><td class=bc>-</td><td class=blW>Mi Mareš st.</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Ji Malík</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Lu Toms</td><td class=bc>-</td><td class=blW>Lu Kobrle</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Da Votrubec</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Mi Borgh</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Mi Mareš st.</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Peško</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Lu Kobrle</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Lu Toms</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Votrubec</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Mi Borgh</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Lu Kobrle</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Peško</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Lu Toms</td><td class=bc>-</td><td class=blW>Mi Borgh</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Da Votrubec</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ma Peško</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Mi Borgh</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Lu Toms</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Da Votrubec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Lu Kobrle</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>Mi Borgh</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ma Peško</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Lu Toms</td><td class=bc>-</td><td class=bl>Da Votrubec</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Lu Kobrle</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Borgh</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Peško</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 11</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Da Votrubec</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Lu Toms</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Mi Borgh</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Lu Kobrle</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Mareš st.</td><td class=bc>-</td><td class=bl>Da Votrubec</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Peško</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Lu Toms</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Mi Borgh</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Fi Hamáček</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Lu Kobrle</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Da Votrubec</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=bl>Lu Toms</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Peško</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>3 : 12</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Da Votrubec</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Lu Kobrle</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Lu Toms</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Mareš st.</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ma Peško</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Da Votrubec</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Fi Hamáček</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Lu Toms</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Lu Kobrle</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Ji Malík</td><td class=bc>-</td><td class=bl>Ma Peško</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>Da Votrubec</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Lu Toms</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Lu Kobrle</td><td class=bc>-</td><td class=bl>Ma Peško</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<hr><a name="final"><p class=vm>Výkonnostní skupiny (Final groups)</p></a>
<p class=v>Group A1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt>Zd Matoušek ml.</td><td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kL>1:4 K</td>
<td class=kW>4:2</td>
<td class=kW>5:1 K</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1 K</td>
<td class=kL>3:4</td>
<td class=kW>5:0 K</td>
<td class=kW>4:0 K</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>6:4</td>
<td class=kW>6:3 K</td>
<td class=kW>5:0</td>
<td class=kW>8:1 K</td>
<td class=kW>5:1</td>
<td class=kW>7:3</td>
<td class=kW>4:1</td>
<td class=kW>9:1</td>
<td class=br>109:37</td><td class=br>+72</td>
<td class=bc>20 - 0 - 3</td>
<td class=br><strong>40</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt>Pa Petr</td><td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>8:2 K</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kT>4:4 K</td>
<td class=kW>7:3</td>
<td class=kW>3:0</td>
<td class=kW>7:3 K</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>5:4 K</td>
<td class=kW>5:3</td>
<td class=kW>8:4</td>
<td class=kL>3:4 K</td>
<td class=kW>12:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2 K</td>
<td class=kW>3:1</td>
<td class=kW>10:2 K</td>
<td class=br>114:46</td><td class=br>+68</td>
<td class=bc>18 - 3 - 2</td>
<td class=br><strong>39</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt>Mi Hvižď</td><td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kT>4:4</td>
<td class=kW>6:3 K</td>
<td class=kW>6:4 K</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>5:2</td>
<td class=kW>6:2 K</td>
<td class=kW>8:4 K</td>
<td class=kW>6:2</td>
<td class=kW>9:0 K</td>
<td class=kW>6:3</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kT>0:0 K</td>
<td class=kW>5:1</td>
<td class=kW>4:0 K</td>
<td class=kW>9:0</td>
<td class=br>108:39</td><td class=br>+69</td>
<td class=bc>17 - 4 - 2</td>
<td class=br><strong>38</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt>Mi Kobrle</td><td class=kW>4:1 K</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>8:2 K</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>5:2 K</td>
<td class=kL>3:7</td>
<td class=kL>3:4 K</td>
<td class=kW>6:3 K</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>9:0</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>6:0 K</td>
<td class=kT>4:4</td>
<td class=kW>2:0 K</td>
<td class=kL>3:6</td>
<td class=kW>5:4</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=br>99:56</td><td class=br>+43</td>
<td class=bc>15 - 5 - 3</td>
<td class=br><strong>35</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>St Kraus</td><td class=kL>2:4</td>
<td class=kL>2:8 K</td>
<td class=kL>2:6</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>6:2 K</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kL>3:6 K</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>5:1 K</td>
<td class=kW>5:1</td>
<td class=kW>8:3</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>9:4 K</td>
<td class=kW>9:2</td>
<td class=kW>6:2 K</td>
<td class=br>99:68</td><td class=br>+31</td>
<td class=bc>13 - 4 - 6</td>
<td class=br><strong>30</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>Da Mitro</td><td class=kL>1:5 K</td>
<td class=kL>1:7</td>
<td class=kT>4:4</td>
<td class=kL>2:8 K</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kL>0:5 K</td>
<td class=kL>1:6</td>
<td class=kL>3:4 K</td>
<td class=kW>2:1 K</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>4:3 K</td>
<td class=kL>2:3</td>
<td class=kW>4:3 K</td>
<td class=kW>6:2</td>
<td class=kW>2:0</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=br>67:75</td><td class=br>-8</td>
<td class=bc>13 - 1 - 9</td>
<td class=br><strong>27</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Em Larsson</td><td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>3:6 K</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>3:3 K</td>
<td class=kL>0:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>3:1 K</td>
<td class=kW>5:2 K</td>
<td class=kL>3:5</td>
<td class=kW>1:0 K</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0 K</td>
<td class=kW>4:2</td>
<td class=kW>8:1 K</td>
<td class=kW>7:1</td>
<td class=br>81:59</td><td class=br>+22</td>
<td class=bc>13 - 1 - 9</td>
<td class=br><strong>27</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>Pa Plešák</td><td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>4:6 K</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kT>3:3 K</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>0:1 K</td>
<td class=kW>6:1 K</td>
<td class=kL>2:3</td>
<td class=kL>4:5 K</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kT>5:5 K</td>
<td class=kW>5:2</td>
<td class=kW>7:3 K</td>
<td class=kW>8:2</td>
<td class=br>80:58</td><td class=br>+22</td>
<td class=bc>10 - 6 - 7</td>
<td class=br><strong>26</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>Kr Herold</td><td class=kL>1:4 K</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>2:5 K</td>
<td class=kT>3:3</td>
<td class=kW>5:0 K</td>
<td class=kW>1:0</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>0:2 K</td>
<td class=kW>4:3 K</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>4:2 K</td>
<td class=kL>1:3</td>
<td class=kW>2:0 K</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=br>55:61</td><td class=br>-6</td>
<td class=bc>11 - 3 - 9</td>
<td class=br><strong>25</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Be Rjavec</td><td class=kW>4:3</td>
<td class=kT>4:4 K</td>
<td class=kW>2:1</td>
<td class=kW>7:3</td>
<td class=kL>2:6 K</td>
<td class=kW>6:1</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kL>1:7 K</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>3:1 K</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kL>3:5 K</td>
<td class=kW>4:1</td>
<td class=kT>0:0</td>
<td class=kL>1:2 K</td>
<td class=kW>5:0</td>
<td class=kL>1:2 K</td>
<td class=br>66:58</td><td class=br>+8</td>
<td class=bc>11 - 3 - 9</td>
<td class=br><strong>25</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>Sa Hána</td><td class=kL>0:5 K</td>
<td class=kL>3:7</td>
<td class=kL>0:4</td>
<td class=kW>4:3 K</td>
<td class=kL>0:4</td>
<td class=kW>4:3 K</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>2:0 K</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>5:4 K</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>4:0 K</td>
<td class=kL>3:10</td>
<td class=kT>0:0 K</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=br>63:68</td><td class=br>-5</td>
<td class=bc>11 - 2 - 10</td>
<td class=br><strong>24</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>Ad Zielinský</td><td class=kL>0:4 K</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kL>3:6 K</td>
<td class=kW>3:2</td>
<td class=kL>1:2 K</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kL>3:4 K</td>
<td class=kW>2:1</td>
<td class=kL>4:5 K</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3 K</td>
<td class=kW>3:1</td>
<td class=kL>3:5 K</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=br>52:60</td><td class=br>-8</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt>Ja Matýsek</td><td class=kL>1:5</td>
<td class=kL>3:7 K</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kW>6:3 K</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kW>7:1 K</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>1:0 K</td>
<td class=kL>3:5</td>
<td class=kL>3:6</td>
<td class=kW>4:1 K</td>
<td class=kW>1:0</td>
<td class=kL>1:7</td>
<td class=kT>2:2 K</td>
<td class=kW>3:1</td>
<td class=kW>4:3 K</td>
<td class=br>56:67</td><td class=br>-11</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt>Ro Jež</td><td class=kL>0:7</td>
<td class=kL>2:5</td>
<td class=kL>2:6 K</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kL>1:3 K</td>
<td class=kW>1:0 K</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:3 K</td>
<td class=kW>5:2</td>
<td class=kL>1:4 K</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>2:6 K</td>
<td class=kT>1:1</td>
<td class=kW>2:1 K</td>
<td class=kW>7:1</td>
<td class=br>55:72</td><td class=br>-17</td>
<td class=bc>9 - 2 - 12</td>
<td class=br><strong>20</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt>Ge Regula</td><td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>4:8 K</td>
<td class=kL>0:9</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kL>2:5 K</td>
<td class=kL>1:6 K</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kL>3:4 K</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>3:3 K</td>
<td class=kL>1:5</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>6:3 K</td>
<td class=kW>2:1</td>
<td class=kW>4:2 K</td>
<td class=kW>5:2</td>
<td class=br>65:79</td><td class=br>-14</td>
<td class=bc>9 - 2 - 12</td>
<td class=br><strong>20</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt>Vá Pikl</td><td class=kL>1:3</td>
<td class=kL>4:5 K</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>1:5 K</td>
<td class=kL>0:3</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>1:3 K</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kL>0:1 K</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>7:0 K</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=kL>0:2 K</td>
<td class=kW>7:1</td>
<td class=kL>1:2 K</td>
<td class=br>62:56</td><td class=br>+6</td>
<td class=bc>9 - 2 - 12</td>
<td class=br><strong>20</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>To Hudec</td><td class=kL>4:6</td>
<td class=kL>3:5</td>
<td class=kL>0:9 K</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>0:1 K</td>
<td class=kW>5:4 K</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>4:1 K</td>
<td class=kT>3:3 K</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>0:5</td>
<td class=kW>7:0</td>
<td class=kW>2:1</td>
<td class=kW>4:2 K</td>
<td class=kT>3:3</td>
<td class=kL>2:3 K</td>
<td class=kW>7:3</td>
<td class=br>60:76</td><td class=br>-16</td>
<td class=bc>8 - 3 - 12</td>
<td class=br><strong>19</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Ma Ženíšek</td><td class=kL>3:6 K</td>
<td class=kL>4:8</td>
<td class=kL>3:6</td>
<td class=kL>0:6 K</td>
<td class=kL>3:8</td>
<td class=kL>3:4 K</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>2:4 K</td>
<td class=kL>1:3</td>
<td class=kL>0:4 K</td>
<td class=kT>3:3 K</td>
<td class=kW>6:3</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kL>0:5</td>
<td class=kW>5:0</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kT>2:2 K</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kL>2:4</td>
<td class=br>67:79</td><td class=br>-12</td>
<td class=bc>7 - 3 - 13</td>
<td class=br><strong>17</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Jo Kůrka</td><td class=kL>0:5</td>
<td class=kW>4:3 K</td>
<td class=kL>0:3</td>
<td class=kT>4:4</td>
<td class=kT>2:2 K</td>
<td class=kW>3:2</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kW>3:1</td>
<td class=kW>5:3 K</td>
<td class=kW>10:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4 K</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>0:7 K</td>
<td class=kL>0:7</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kW>5:3 K</td>
<td class=kL>1:6</td>
<td class=kW>2:0 K</td>
<td class=br>52:90</td><td class=br>-38</td>
<td class=bc>7 - 3 - 13</td>
<td class=br><strong>17</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>To Kahoun ml.</td><td class=kL>1:8 K</td>
<td class=kL>0:12</td>
<td class=kL>1:7</td>
<td class=kL>0:2 K</td>
<td class=kT>1:1</td>
<td class=kL>3:4 K</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>0:2 K</td>
<td class=kL>1:4</td>
<td class=kT>0:0 K</td>
<td class=kW>5:3 K</td>
<td class=kL>0:1</td>
<td class=kW>4:1</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kT>2:2 K</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=br>36:74</td><td class=br>-38</td>
<td class=bc>5 - 5 - 13</td>
<td class=br><strong>15</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Mi Ševr</td><td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kT>0:0 K</td>
<td class=kW>6:3</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kL>0:5 K</td>
<td class=kT>5:5 K</td>
<td class=kL>3:4</td>
<td class=kT>0:0</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>6:2 K</td>
<td class=kL>3:6 K</td>
<td class=kL>0:4</td>
<td class=kL>2:4 K</td>
<td class=kL>1:6</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kL>3:6 K</td>
<td class=kW>4:2</td>
<td class=br>60:81</td><td class=br>-21</td>
<td class=bc>6 - 3 - 14</td>
<td class=br><strong>15</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Ka Hudec</td><td class=kL>3:7</td>
<td class=kL>2:5 K</td>
<td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kL>4:9 K</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kW>2:1 K</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>2:0 K</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>3:5 K</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>5:2 K</td>
<td class=br>52:79</td><td class=br>-27</td>
<td class=bc>5 - 3 - 15</td>
<td class=br><strong>13</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>To Halama</td><td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>0:4 K</td>
<td class=kL>0:6</td>
<td class=kL>2:9</td>
<td class=kL>3:5</td>
<td class=kL>1:8 K</td>
<td class=kL>3:7 K</td>
<td class=kW>5:1</td>
<td class=kL>0:5</td>
<td class=kL>2:6</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>1:2 K</td>
<td class=kL>2:4 K</td>
<td class=kL>1:7</td>
<td class=kW>3:2 K</td>
<td class=kL>1:6</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kW>6:3 K</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=br>41:92</td><td class=br>-51</td>
<td class=bc>5 - 1 - 17</td>
<td class=br><strong>11</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>To Kahoun st.</td><td class=kL>1:9</td>
<td class=kL>2:10 K</td>
<td class=kL>0:9</td>
<td class=kL>2:4</td>
<td class=kL>2:6 K</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kL>2:8</td>
<td class=kT>3:3</td>
<td class=kW>2:1 K</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>3:4 K</td>
<td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kW>2:1 K</td>
<td class=kL>3:7</td>
<td class=kW>4:2</td>
<td class=kL>0:2 K</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>2:5 K</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=br>39:108</td><td class=br>-69</td>
<td class=bc>3 - 1 - 19</td>
<td class=br><strong>7</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Jo Kůrka</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>4 : 8</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Jo Kůrka</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>To Hudec</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>12 : 0</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Jo Kůrka</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Em Larsson</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Hvižď</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>To Hudec</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>3 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>To Hudec</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=bl>Mi Hvižď</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=blW>Ge Regula</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Em Larsson</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Em Larsson</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Sa Hána</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>To Hudec</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=blW>Ge Regula</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Jo Kůrka</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jo Kůrka</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Em Larsson</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Jo Kůrka</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Sa Hána</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Ge Regula</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>Sa Hána</td><td class=bc>10 : 3</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>7 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group A2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt>Le Hvižď ml.</td><td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kL>1:5 K</td>
<td class=kT>1:1 K</td>
<td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kL>4:5 K</td>
<td class=kL>4:5</td>
<td class=kW>3:1 K</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kW>6:2 K</td>
<td class=kT>2:2 K</td>
<td class=kW>4:2</td>
<td class=kW>6:1 K</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>82:48</td><td class=br>+34</td>
<td class=bc>15 - 3 - 5</td>
<td class=br><strong>33</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt>Fi Hamáček</td><td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kT>2:2 K</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>3:2 K</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kL>0:1 K</td>
<td class=kW>5:4</td>
<td class=kW>4:1 K</td>
<td class=kT>3:3</td>
<td class=kW>5:0 K</td>
<td class=kT>1:1</td>
<td class=kW>7:1</td>
<td class=kW>5:2 K</td>
<td class=kT>2:2</td>
<td class=kW>7:3</td>
<td class=kW>4:2 K</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=kW>7:1</td>
<td class=br>81:47</td><td class=br>+34</td>
<td class=bc>14 - 5 - 4</td>
<td class=br><strong>33</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt>ml Chylík</td><td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:0 K</td>
<td class=kW>3:2 K</td>
<td class=kW>4:2 K</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kL>1:4 K</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>3:6 K</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>4:2 K</td>
<td class=kL>2:4 K</td>
<td class=br>73:52</td><td class=br>+21</td>
<td class=bc>13 - 5 - 5</td>
<td class=br><strong>31</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt>Im Blaško</td><td class=kW>4:0</td>
<td class=kT>2:2 K</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kW>3:2 K</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kL>1:3 K</td>
<td class=kT>3:3</td>
<td class=kL>1:3 K</td>
<td class=kW>6:4</td>
<td class=kW>5:4 K</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kL>3:4 K</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>3:1 K</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=br>72:54</td><td class=br>+18</td>
<td class=bc>14 - 2 - 7</td>
<td class=br><strong>30</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>Ho Sládek</td><td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>0:4 K</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>2:0 K</td>
<td class=kW>3:2 K</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kT>5:5</td>
<td class=kT>2:2</td>
<td class=kL>2:3 K</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>2:0 K</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>2:1 K</td>
<td class=kW>4:2 K</td>
<td class=br>56:45</td><td class=br>+11</td>
<td class=bc>13 - 3 - 7</td>
<td class=br><strong>29</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>Ku Sládek</td><td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>2:3 K</td>
<td class=kW>4:2</td>
<td class=kL>0:2 K</td>
<td class=kx>*</td>
<td class=kW>3:1 K</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kL>0:1</td>
<td class=kW>4:1 K</td>
<td class=kW>4:1</td>
<td class=kW>7:4</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kW>5:1 K</td>
<td class=kW>4:2</td>
<td class=kW>9:5</td>
<td class=kW>7:3</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>5:0 K</td>
<td class=kW>4:1 K</td>
<td class=br>79:49</td><td class=br>+30</td>
<td class=bc>13 - 3 - 7</td>
<td class=br><strong>29</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Dm Petrov</td><td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>2:4 K</td>
<td class=kW>4:0</td>
<td class=kL>2:3 K</td>
<td class=kL>1:3 K</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>4:6 K</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1 K</td>
<td class=kW>6:1</td>
<td class=kL>3:4</td>
<td class=kW>9:3</td>
<td class=kL>2:6</td>
<td class=kW>6:1</td>
<td class=kW>5:0 K</td>
<td class=kW>3:2 K</td>
<td class=br>79:60</td><td class=br>+19</td>
<td class=bc>13 - 2 - 8</td>
<td class=br><strong>28</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>Kr Lebl</td><td class=kL>0:3</td>
<td class=kL>2:3 K</td>
<td class=kL>1:3</td>
<td class=kL>2:3 K</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>1:0 K</td>
<td class=kW>3:2</td>
<td class=kL>1:3 K</td>
<td class=kW>3:1</td>
<td class=kL>1:5 K</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kW>2:0 K</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>3:1 K</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>57:44</td><td class=br>+13</td>
<td class=bc>13 - 2 - 8</td>
<td class=br><strong>28</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>Pe Turoň</td><td class=kW>5:1 K</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>4:5</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:2 K</td>
<td class=kW>4:1</td>
<td class=kL>0:4</td>
<td class=kW>4:0</td>
<td class=kL>1:3 K</td>
<td class=kW>5:1</td>
<td class=kW>4:0 K</td>
<td class=kW>5:1</td>
<td class=kL>0:3</td>
<td class=kW>4:1 K</td>
<td class=kW>3:1 K</td>
<td class=kW>5:4</td>
<td class=kW>5:2 K</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=br>71:50</td><td class=br>+21</td>
<td class=bc>14 - 0 - 9</td>
<td class=br><strong>28</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Ma Maděra</td><td class=kT>1:1 K</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kW>4:0</td>
<td class=kT>5:5</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>2:3 K</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kW>5:4 K</td>
<td class=kT>3:3</td>
<td class=kW>2:1 K</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kL>1:3 K</td>
<td class=kW>3:0 K</td>
<td class=kW>7:2</td>
<td class=kW>4:1 K</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=br>67:51</td><td class=br>+16</td>
<td class=bc>11 - 6 - 6</td>
<td class=br><strong>28</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>Mi Černoch</td><td class=kW>5:1</td>
<td class=kW>1:0 K</td>
<td class=kL>2:3</td>
<td class=kW>3:1 K</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kL>0:1 K</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>1:1 K</td>
<td class=kL>0:1</td>
<td class=kW>3:2 K</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>4:1 K</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>2:6 K</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>8:1</td>
<td class=br>56:42</td><td class=br>+14</td>
<td class=bc>9 - 8 - 6</td>
<td class=br><strong>26</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>Mi Boštík</td><td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kW>4:1 K</td>
<td class=kT>3:3</td>
<td class=kW>3:2 K</td>
<td class=kL>1:4 K</td>
<td class=kW>6:4 K</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2 K</td>
<td class=kL>2:7</td>
<td class=kW>2:1</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kT>3:3 K</td>
<td class=kW>4:3 K</td>
<td class=br>70:66</td><td class=br>+4</td>
<td class=bc>10 - 6 - 7</td>
<td class=br><strong>26</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt>An Šurýn</td><td class=kL>1:4</td>
<td class=kL>1:4 K</td>
<td class=kT>2:2</td>
<td class=kW>3:1 K</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kW>3:1 K</td>
<td class=kL>0:4</td>
<td class=kW>5:1</td>
<td class=kT>1:1 K</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>3:3 K</td>
<td class=kT>0:0</td>
<td class=kL>2:3</td>
<td class=kT>2:2 K</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>4:3 K</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=br>53:51</td><td class=br>+2</td>
<td class=bc>10 - 5 - 8</td>
<td class=br><strong>25</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt>My Shalomayev</td><td class=kW>5:4 K</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kL>4:6</td>
<td class=kL>0:2</td>
<td class=kL>4:7</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kW>3:1 K</td>
<td class=kL>4:5 K</td>
<td class=kW>1:0</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kL>0:1 K</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=kW>4:2 K</td>
<td class=kL>1:2 K</td>
<td class=kW>5:1</td>
<td class=kW>4:0 K</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=br>68:58</td><td class=br>+10</td>
<td class=bc>11 - 2 - 10</td>
<td class=br><strong>24</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt>To Waclawek</td><td class=kW>5:4</td>
<td class=kL>0:5 K</td>
<td class=kT>3:3</td>
<td class=kL>4:5 K</td>
<td class=kL>0:5</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kW>5:1 K</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>2:3 K</td>
<td class=kL>3:4</td>
<td class=kT>3:3 K</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>5:3 K</td>
<td class=kL>2:4</td>
<td class=kW>6:3</td>
<td class=kL>2:4 K</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=br>78:70</td><td class=br>+8</td>
<td class=bc>9 - 5 - 9</td>
<td class=br><strong>23</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt>Da Matýsek</td><td class=kL>1:3 K</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>0:4 K</td>
<td class=kL>1:2 K</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kT>0:0</td>
<td class=kW>1:0 K</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>6:1 K</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1</td>
<td class=kW>2:0 K</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=br>47:44</td><td class=br>+3</td>
<td class=bc>8 - 7 - 8</td>
<td class=br><strong>23</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Mi Kubica</td><td class=kT>3:3</td>
<td class=kL>1:7</td>
<td class=kW>6:3 K</td>
<td class=kL>1:6</td>
<td class=kL>0:2 K</td>
<td class=kL>1:5 K</td>
<td class=kL>1:3 K</td>
<td class=kW>2:0</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2 K</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>3:0 K</td>
<td class=kW>4:3 K</td>
<td class=br>53:63</td><td class=br>-10</td>
<td class=bc>10 - 2 - 11</td>
<td class=br><strong>22</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Lu Kobrle</td><td class=kL>2:6</td>
<td class=kL>2:5 K</td>
<td class=kT>3:3</td>
<td class=kW>4:3 K</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>0:2 K</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kL>1:4 K</td>
<td class=kW>7:2</td>
<td class=kT>2:2 K</td>
<td class=kL>0:7</td>
<td class=kL>3:5 K</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kW>4:1 K</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=br>57:67</td><td class=br>-10</td>
<td class=bc>8 - 3 - 12</td>
<td class=br><strong>19</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Vl Kraus</td><td class=kL>2:6 K</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>5:9</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4 K</td>
<td class=kW>3:1 K</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>2:4 K</td>
<td class=kW>4:2</td>
<td class=kL>1:6 K</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>2:1 K</td>
<td class=kT>1:1</td>
<td class=kW>6:2 K</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=br>50:66</td><td class=br>-16</td>
<td class=bc>8 - 3 - 12</td>
<td class=br><strong>19</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>To Jedlička</td><td class=kT>2:2 K</td>
<td class=kL>3:7</td>
<td class=kT>3:3</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kL>3:7</td>
<td class=kL>3:9</td>
<td class=kL>1:6</td>
<td class=kL>1:3 K</td>
<td class=kL>0:3 K</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kL>0:5</td>
<td class=kW>2:1 K</td>
<td class=kL>3:6</td>
<td class=kT>2:2 K</td>
<td class=kL>2:7</td>
<td class=kW>4:3</td>
<td class=kL>1:2 K</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:1 K</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=br>54:87</td><td class=br>-33</td>
<td class=bc>6 - 6 - 11</td>
<td class=br><strong>18</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Mi Borgh</td><td class=kL>2:4</td>
<td class=kL>2:4 K</td>
<td class=kL>2:3</td>
<td class=kL>1:3 K</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kL>1:3 K</td>
<td class=kL>4:5</td>
<td class=kL>2:7</td>
<td class=kW>6:2 K</td>
<td class=kL>3:4</td>
<td class=kL>3:4 K</td>
<td class=kL>1:5</td>
<td class=kW>4:2 K</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>1:4 K</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=br>58:76</td><td class=br>-18</td>
<td class=bc>4 - 5 - 14</td>
<td class=br><strong>13</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Fe Šuma</td><td class=kL>1:6 K</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>2:5 K</td>
<td class=kL>1:4 K</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>0:4 K</td>
<td class=kL>0:5</td>
<td class=kL>0:2 K</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>2:6 K</td>
<td class=kL>1:3 K</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=br>35:90</td><td class=br>-55</td>
<td class=bc>1 - 4 - 18</td>
<td class=br><strong>6</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Fr Marek</td><td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>2:4 K</td>
<td class=kL>2:6</td>
<td class=kL>1:2 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kT>3:3 K</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kL>0:3 K</td>
<td class=kL>0:6</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>7:3 K</td>
<td class=br>29:82</td><td class=br>-53</td>
<td class=bc>2 - 2 - 19</td>
<td class=br><strong>6</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>An Naszádi</td><td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kW>4:2 K</td>
<td class=kL>0:6</td>
<td class=kL>2:4 K</td>
<td class=kL>1:4 K</td>
<td class=kL>2:3 K</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>1:8</td>
<td class=kL>3:4 K</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kL>3:4 K</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>3:7 K</td>
<td class=kx>*</td>
<td class=br>35:98</td><td class=br>-63</td>
<td class=bc>1 - 3 - 19</td>
<td class=br><strong>5</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Mi Borgh</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Lu Kobrle</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Fe Šuma</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Fe Šuma</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Lu Kobrle</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>9 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Fe Šuma</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pe Turoň</td><td class=bc>-</td><td class=blW>Lu Kobrle</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Mi Borgh</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Pe Turoň</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Lu Kobrle</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fi Hamáček</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Fe Šuma</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Lu Kobrle</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Fe Šuma</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fi Hamáček</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Fe Šuma</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Lu Kobrle</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Fi Hamáček</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Fe Šuma</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lu Kobrle</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Fi Hamáček</td><td class=bc>-</td><td class=bl>Fe Šuma</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Pe Turoň</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Lu Kobrle</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Pe Turoň</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Mi Borgh</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>Lu Kobrle</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Fe Šuma</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Lu Kobrle</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Fe Šuma</td><td class=bc>-</td><td class=bl>Mi Borgh</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Fi Hamáček</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Pe Turoň</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Lu Kobrle</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>Mi Borgh</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Fe Šuma</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Fe Šuma</td><td class=bc>-</td><td class=blW>Lu Kobrle</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Pe Turoň</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Mi Borgh</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Lu Kobrle</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Pe Turoň</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Fe Šuma</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>9 : 5</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Fe Šuma</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Lu Kobrle</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Fi Hamáček</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Lu Kobrle</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>Mi Borgh</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Pe Turoň</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Fe Šuma</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Lu Kobrle</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=bl>Fi Hamáček</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Fe Šuma</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>7 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Ma Bengtsson</td><td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kL>3:5</td>
<td class=kW>10:2</td>
<td class=br>56:29</td><td class=br>+27</td>
<td class=bc>12 - 2 - 3</td>
<td class=br><strong>26</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Ev Solovev</td><td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>9:3</td>
<td class=br>47:28</td><td class=br>+19</td>
<td class=bc>11 - 3 - 3</td>
<td class=br><strong>25</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Ji Vácha</td><td class=kT>0:0</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kL>6:7</td>
<td class=kW>7:4</td>
<td class=kW>3:2</td>
<td class=kW>8:4</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>6:3</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>6:3</td>
<td class=kW>7:4</td>
<td class=kW>7:3</td>
<td class=br>70:48</td><td class=br>+22</td>
<td class=bc>11 - 2 - 4</td>
<td class=br><strong>24</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Si Thomas</td><td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kL>0:5</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kT>4:4</td>
<td class=kW>5:0</td>
<td class=br>56:31</td><td class=br>+25</td>
<td class=bc>10 - 2 - 5</td>
<td class=br><strong>22</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ma Martinec</td><td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kW>7:6</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>10:3</td>
<td class=kW>11:0</td>
<td class=br>75:43</td><td class=br>+32</td>
<td class=bc>9 - 3 - 5</td>
<td class=br><strong>21</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>To Bucek</td><td class=kW>5:2</td>
<td class=kL>1:4</td>
<td class=kL>4:7</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=br>50:39</td><td class=br>+11</td>
<td class=bc>8 - 4 - 5</td>
<td class=br><strong>20</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Lu Varga</td><td class=kL>1:7</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kL>3:6</td>
<td class=kT>4:4</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kT>0:0</td>
<td class=kW>5:3</td>
<td class=kW>6:3</td>
<td class=kW>7:1</td>
<td class=br>51:48</td><td class=br>+3</td>
<td class=bc>8 - 4 - 5</td>
<td class=br><strong>20</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>He Petuch</td><td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>4:8</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>7:1</td>
<td class=br>42:44</td><td class=br>-2</td>
<td class=bc>9 - 1 - 7</td>
<td class=br><strong>19</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Da Cibulka</td><td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=br>45:39</td><td class=br>+6</td>
<td class=bc>7 - 4 - 6</td>
<td class=br><strong>18</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Zd Matoušek st.</td><td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kT>0:0</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>6:2</td>
<td class=kW>2:0</td>
<td class=br>45:44</td><td class=br>+1</td>
<td class=bc>8 - 2 - 7</td>
<td class=br><strong>18</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Zd Lopaur</td><td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kW>5:4</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=br>48:49</td><td class=br>-1</td>
<td class=bc>7 - 2 - 8</td>
<td class=br><strong>16</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Mi Mitro ml.</td><td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=br>41:38</td><td class=br>+3</td>
<td class=bc>6 - 4 - 7</td>
<td class=br><strong>16</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ji Cibulka</td><td class=kT>0:0</td>
<td class=kL>1:2</td>
<td class=kL>3:6</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kW>3:0</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=br>35:40</td><td class=br>-5</td>
<td class=bc>6 - 2 - 9</td>
<td class=br><strong>14</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Ha Marešová</td><td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=br>31:35</td><td class=br>-4</td>
<td class=bc>5 - 3 - 9</td>
<td class=br><strong>13</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Al Mačynský</td><td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kT>0:0</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=br>29:46</td><td class=br>-17</td>
<td class=bc>5 - 2 - 10</td>
<td class=br><strong>12</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>To Růžička</td><td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=br>34:58</td><td class=br>-24</td>
<td class=bc>4 - 2 - 11</td>
<td class=br><strong>10</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Mi Uhlíř</td><td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kL>4:7</td>
<td class=kT>4:4</td>
<td class=kL>3:10</td>
<td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kL>3:6</td>
<td class=br>50:73</td><td class=br>-23</td>
<td class=bc>3 - 3 - 11</td>
<td class=br><strong>9</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Pe Fuchs</td><td class=kL>2:10</td>
<td class=kL>3:9</td>
<td class=kL>3:7</td>
<td class=kL>0:5</td>
<td class=kL>0:11</td>
<td class=kL>1:7</td>
<td class=kL>1:7</td>
<td class=kL>1:7</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>6:3</td>
<td class=kx>*</td>
<td class=br>25:98</td><td class=br>-73</td>
<td class=bc>1 - 1 - 15</td>
<td class=br><strong>3</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ji Cibulka</td><td class=bc>-</td><td class=blW>Lu Varga</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Ma Bengtsson</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ev Solovev</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ha Marešová</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Ma Martinec</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Lu Varga</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Mitro ml.</td><td class=bc>-</td><td class=blW>Ma Bengtsson</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ji Cibulka</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ev Solovev</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Ma Martinec</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Lu Varga</td><td class=bc>-</td><td class=blW>Ma Bengtsson</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ji Cibulka</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ev Solovev</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>Ma Martinec</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ma Bengtsson</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Lu Varga</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ji Cibulka</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Ma Martinec</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ev Solovev</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ma Bengtsson</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Lu Varga</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Mitro ml.</td><td class=bc>-</td><td class=blW>Ma Martinec</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ji Cibulka</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ev Solovev</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Bengtsson</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Lu Varga</td><td class=bc>-</td><td class=bl>Ma Martinec</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ji Cibulka</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ev Solovev</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ma Martinec</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ma Bengtsson</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Lu Varga</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Mitro ml.</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ji Cibulka</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Ev Solovev</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Ma Martinec</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ha Marešová</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Bengtsson</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Lu Varga</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Mi Mitro ml.</td><td class=bc>-</td><td class=blW>Ev Solovev</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ji Cibulka</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Ma Martinec</td><td class=bc>3 : 10</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Bengtsson</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Lu Varga</td><td class=bc>-</td><td class=bl>Ev Solovev</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Mitro ml.</td><td class=bc>-</td><td class=bl>Ji Cibulka</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ev Solovev</td><td class=bc>3 : 9</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Bengtsson</td><td class=bc>-</td><td class=bl>Ji Cibulka</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Lu Varga</td><td class=bc>-</td><td class=bl>Mi Mitro ml.</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Martinec</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>7 : 6</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ev Solovev</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ji Cibulka</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Mi Mitro ml.</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ma Bengtsson</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Lu Varga</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ha Marešová</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=blW>Ev Solovev</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ji Cibulka</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Mi Mitro ml.</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Lu Varga</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ma Bengtsson</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=bl>Ev Solovev</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=blW>Ji Cibulka</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Mi Mitro ml.</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Lu Varga</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ma Bengtsson</td><td class=bc>2 : 10</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Ev Solovev</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ha Marešová</td><td class=bc>-</td><td class=bl>Ji Cibulka</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=bl>Mi Mitro ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ma Martinec</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Lu Varga</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ma Bengtsson</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Ji Cibulka</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Mi Mitro ml.</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=bl>Lu Varga</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Ma Martinec</td><td class=bc>-</td><td class=bl>Ma Bengtsson</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Ev Solovev</td><td class=bc>-</td><td class=bl>Ji Cibulka</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>Mi Mitro ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>8 : 4</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Lu Varga</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=blW>Ma Bengtsson</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ma Martinec</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>11 : 0</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Mi Mitro ml.</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ev Solovev</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Lu Varga</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=bl>Ma Bengtsson</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ha Marešová</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ji Cibulka</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Lu Varga</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ev Solovev</td><td class=bc>-</td><td class=blW>Ma Bengtsson</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Al Lorand st.</td><td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=br>53:26</td><td class=br>+27</td>
<td class=bc>13 - 4 - 0</td>
<td class=br><strong>30</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Pa Pohořalý</td><td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kT>1:1</td>
<td class=br>52:35</td><td class=br>+17</td>
<td class=bc>10 - 4 - 3</td>
<td class=br><strong>24</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Št Ivan</td><td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>5:4</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=br>58:39</td><td class=br>+19</td>
<td class=bc>10 - 3 - 4</td>
<td class=br><strong>23</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Jo Malý</td><td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=br>53:37</td><td class=br>+16</td>
<td class=bc>10 - 3 - 4</td>
<td class=br><strong>23</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Mi Franek</td><td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>4:5</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>2:1</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=br>57:38</td><td class=br>+19</td>
<td class=bc>10 - 2 - 5</td>
<td class=br><strong>22</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Vl Gobyová</td><td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>2:0</td>
<td class=kW>6:3</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=br>48:36</td><td class=br>+12</td>
<td class=bc>9 - 3 - 5</td>
<td class=br><strong>21</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Iv Mašková</td><td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>9:4</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=br>53:44</td><td class=br>+9</td>
<td class=bc>7 - 5 - 5</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Cs Kocsis</td><td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kL>4:9</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>7:2</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=br>58:54</td><td class=br>+4</td>
<td class=bc>9 - 0 - 8</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Ma Pikat</td><td class=kL>0:1</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=br>30:31</td><td class=br>-1</td>
<td class=bc>7 - 3 - 7</td>
<td class=br><strong>17</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ji Malík</td><td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=br>40:47</td><td class=br>-7</td>
<td class=bc>7 - 2 - 8</td>
<td class=br><strong>16</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Vo Bernát</td><td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=br>41:50</td><td class=br>-9</td>
<td class=bc>6 - 4 - 7</td>
<td class=br><strong>16</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Pe Holub</td><td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>2:7</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=br>28:36</td><td class=br>-8</td>
<td class=bc>6 - 4 - 7</td>
<td class=br><strong>16</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Wo Abshagen</td><td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kL>2:5</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=br>52:42</td><td class=br>+10</td>
<td class=bc>7 - 1 - 9</td>
<td class=br><strong>15</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Ra Bidlo</td><td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kL>3:6</td>
<td class=kW>5:3</td>
<td class=kL>2:7</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kW>5:4</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=br>41:62</td><td class=br>-21</td>
<td class=bc>5 - 2 - 10</td>
<td class=br><strong>12</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Ví Perkner</td><td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=br>36:52</td><td class=br>-16</td>
<td class=bc>4 - 2 - 11</td>
<td class=br><strong>10</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Mi Mareš st.</td><td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kW>3:1</td>
<td class=br>28:47</td><td class=br>-19</td>
<td class=bc>3 - 4 - 10</td>
<td class=br><strong>10</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Pa Hráský</td><td class=kT>3:3</td>
<td class=kL>2:7</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>24:47</td><td class=br>-23</td>
<td class=bc>3 - 3 - 11</td>
<td class=br><strong>9</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Jo Perkner</td><td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>24:53</td><td class=br>-29</td>
<td class=bc>1 - 3 - 13</td>
<td class=br><strong>5</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Cs Kocsis</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Mi Franek</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Št Ivan</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Ví Perkner</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Wo Abshagen</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Cs Kocsis</td><td class=bc>-</td><td class=blW>Ra Bidlo</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Mi Franek</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Št Ivan</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ma Pikat</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Wo Abshagen</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Mi Franek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Cs Kocsis</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Mi Mareš st.</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Št Ivan</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>Al Lorand st.</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Mi Franek</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Wo Abshagen</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ji Malík</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Cs Kocsis</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Št Ivan</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Mi Franek</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ra Bidlo</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=blW>Mi Mareš st.</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Cs Kocsis</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Al Lorand st.</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Št Ivan</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ví Perkner</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Mi Franek</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ra Bidlo</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=blW>Pa Hráský</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Cs Kocsis</td><td class=bc>-</td><td class=blW>Al Lorand st.</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Ma Pikat</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=bl>Št Ivan</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Mi Franek</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ra Bidlo</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ji Malík</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Cs Kocsis</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Št Ivan</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Franek</td><td class=bc>-</td><td class=blW>Al Lorand st.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Ma Pikat</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ji Malík</td><td class=bc>-</td><td class=bl>Št Ivan</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Cs Kocsis</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>4 : 9</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Al Lorand st.</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Franek</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Št Ivan</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Wo Abshagen</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ji Malík</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Cs Kocsis</td><td class=bc>-</td><td class=blW>Pa Pohořalý</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Ma Pikat</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>Št Ivan</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Mi Franek</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Pa Pohořalý</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Wo Abshagen</td><td class=bc>-</td><td class=bl>Cs Kocsis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Št Ivan</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Franek</td><td class=bc>-</td><td class=blW>Cs Kocsis</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Ji Malík</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Wo Abshagen</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=bl>Št Ivan</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>Pa Pohořalý</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Cs Kocsis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ji Malík</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Franek</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>Št Ivan</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Pa Pohořalý</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Cs Kocsis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Wo Abshagen</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Franek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Cs Kocsis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Ji Malík</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Mi Franek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Št Ivan</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>Cs Kocsis</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Ra Bidlo</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=bl>Mi Franek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Mareš st.</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Št Ivan</td><td class=bc>-</td><td class=bl>Cs Kocsis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Pikat</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Mi Franek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Cs Kocsis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Št Ivan</td><td class=bc>-</td><td class=bl>Wo Abshagen</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ma Pikat</td><td class=bc>-</td><td class=bl>Mi Franek</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Wo Abshagen</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Št Ivan</td><td class=bc>-</td><td class=bl>Mi Franek</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ma Pikat</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group D</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Hy Nechutný</td><td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>7:3</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0 K</td>
<td class=br>82:14</td><td class=br>+68</td>
<td class=bc>18 - 0 - 0</td>
<td class=br><strong>36</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Ma Peško</td><td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>4:7</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>10:5</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0 K</td>
<td class=br>59:28</td><td class=br>+31</td>
<td class=bc>15 - 1 - 2</td>
<td class=br><strong>31</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Jo Sedláček</td><td class=kL>2:3</td>
<td class=kW>7:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kW>11:1</td>
<td class=kW>2:1</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>6:4</td>
<td class=kW>6:0</td>
<td class=kW>5:0 K</td>
<td class=br>87:34</td><td class=br>+53</td>
<td class=bc>15 - 0 - 3</td>
<td class=br><strong>30</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Lu Toms</td><td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>5:3</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>11:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>5:0 K</td>
<td class=br>56:29</td><td class=br>+27</td>
<td class=bc>12 - 1 - 5</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ma Klazar</td><td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kW>1:0</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=kW>5:0 K</td>
<td class=br>48:33</td><td class=br>+15</td>
<td class=bc>11 - 1 - 6</td>
<td class=br><strong>23</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>An Grimová</td><td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kL>5:6</td>
<td class=kW>6:1</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=kW>5:0 K</td>
<td class=br>62:40</td><td class=br>+22</td>
<td class=bc>10 - 2 - 6</td>
<td class=br><strong>22</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Vl Lux</td><td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>1:11</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kT>4:4</td>
<td class=kL>0:1</td>
<td class=kW>7:1</td>
<td class=kW>7:5</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>5:0 K</td>
<td class=br>58:48</td><td class=br>+10</td>
<td class=bc>9 - 3 - 6</td>
<td class=br><strong>21</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ja Kubica</td><td class=kL>0:7</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>0:6</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kL>0:5</td>
<td class=kW>3:0</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>5:0 K</td>
<td class=br>39:39</td><td class=br>0</td>
<td class=bc>9 - 1 - 8</td>
<td class=br><strong>19</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>La Kulhánek</td><td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kW>4:2</td>
<td class=kL>3:5</td>
<td class=kT>4:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>5:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>5:0 K</td>
<td class=br>56:51</td><td class=br>+5</td>
<td class=bc>9 - 1 - 8</td>
<td class=br><strong>19</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ja Peleščák</td><td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>5:0 K</td>
<td class=br>51:51</td><td class=br>0</td>
<td class=bc>8 - 2 - 8</td>
<td class=br><strong>18</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>On Bednář</td><td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>4:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0 K</td>
<td class=br>43:44</td><td class=br>-1</td>
<td class=bc>8 - 2 - 8</td>
<td class=br><strong>18</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Mi Horáková</td><td class=kL>3:7</td>
<td class=kL>5:10</td>
<td class=kL>2:5</td>
<td class=kL>2:11</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kL>5:7</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>7:1</td>
<td class=kW>7:1</td>
<td class=kW>5:0 K</td>
<td class=br>65:68</td><td class=br>-3</td>
<td class=bc>7 - 2 - 9</td>
<td class=br><strong>16</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Pe Klazar</td><td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>6:5</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kW>5:0 K</td>
<td class=br>44:54</td><td class=br>-10</td>
<td class=bc>7 - 1 - 10</td>
<td class=br><strong>15</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Mi Zeman</td><td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kL>0:6</td>
<td class=kT>4:4</td>
<td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kW>9:2</td>
<td class=kW>5:0 K</td>
<td class=br>43:57</td><td class=br>-14</td>
<td class=bc>5 - 3 - 10</td>
<td class=br><strong>13</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>An Lux</td><td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kT>1:1</td>
<td class=kW>5:0 K</td>
<td class=br>37:48</td><td class=br>-11</td>
<td class=bc>5 - 3 - 10</td>
<td class=br><strong>13</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Lu Vaněk</td><td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kL>0:4</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>4:5</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kW>5:0 K</td>
<td class=br>28:44</td><td class=br>-16</td>
<td class=bc>4 - 2 - 12</td>
<td class=br><strong>10</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ma Cingroš</td><td class=kL>0:7</td>
<td class=kL>0:2</td>
<td class=kL>4:6</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>5:0 K</td>
<td class=br>37:69</td><td class=br>-32</td>
<td class=bc>4 - 1 - 13</td>
<td class=br><strong>9</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Da Votrubec</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kL>2:9</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>5:0 K</td>
<td class=br>21:75</td><td class=br>-54</td>
<td class=bc>1 - 2 - 15</td>
<td class=br><strong>4</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Ni Kupka</td><td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kx>*</td>
<td class=br>0:90</td><td class=br>-90</td>
<td class=bc>0 - 0 - 18</td>
<td class=br><strong>0</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ja Kubica</td><td class=bc>-</td><td class=bl>Da Votrubec</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Vl Lux</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ni Kupka</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>An Lux</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>On Bednář</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ma Peško</td><td class=bc>-</td><td class=bl>Ja Peleščák</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Lu Toms</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Da Votrubec</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ja Kubica</td><td class=bc>-</td><td class=bl>Ni Kupka</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Vl Lux</td><td class=bc>-</td><td class=blW>Ma Cingroš</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>On Bednář</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>An Lux</td><td class=bc>-</td><td class=blW>Ja Peleščák</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Lu Vaněk</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Peško</td><td class=bc>-</td><td class=bl>Lu Toms</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>La Kulhánek</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ni Kupka</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Da Votrubec</td><td class=bc>-</td><td class=blW>Ma Cingroš</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ja Kubica</td><td class=bc>-</td><td class=bl>On Bednář</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vl Lux</td><td class=bc>-</td><td class=blW>Ja Peleščák</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>An Lux</td><td class=bc>-</td><td class=blW>Lu Toms</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Peško</td><td class=bc>-</td><td class=bl>La Kulhánek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ni Kupka</td><td class=bc>-</td><td class=blW>Ma Cingroš</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>On Bednář</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Votrubec</td><td class=bc>-</td><td class=blW>Ja Peleščák</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ja Kubica</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Vl Lux</td><td class=bc>-</td><td class=bl>Lu Toms</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>An Lux</td><td class=bc>-</td><td class=blW>La Kulhánek</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Ma Peško</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Lu Vaněk</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>On Bednář</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ni Kupka</td><td class=bc>-</td><td class=blW>Ja Peleščák</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Votrubec</td><td class=bc>-</td><td class=blW>Lu Toms</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Kubica</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Vl Lux</td><td class=bc>-</td><td class=bl>La Kulhánek</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Lu Vaněk</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Lux</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>On Bednář</td><td class=bc>-</td><td class=blW>Ja Peleščák</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ni Kupka</td><td class=bc>-</td><td class=blW>Lu Toms</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Votrubec</td><td class=bc>-</td><td class=blW>La Kulhánek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Peško</td><td class=bc>-</td><td class=bl>An Lux</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vl Lux</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>1 : 11</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Ja Kubica</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ja Peleščák</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>On Bednář</td><td class=bc>-</td><td class=blW>Lu Toms</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ni Kupka</td><td class=bc>-</td><td class=blW>La Kulhánek</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Da Votrubec</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ja Kubica</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vl Lux</td><td class=bc>-</td><td class=blW>Ma Peško</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=bl>Lu Toms</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ja Peleščák</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>On Bednář</td><td class=bc>-</td><td class=blW>La Kulhánek</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>An Lux</td><td class=bc>-</td><td class=bl>Vl Lux</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ni Kupka</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Da Votrubec</td><td class=bc>-</td><td class=blW>Ma Peško</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ja Kubica</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Lu Toms</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>La Kulhánek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ja Kubica</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>On Bednář</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ni Kupka</td><td class=bc>-</td><td class=blW>Ma Peško</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Da Votrubec</td><td class=bc>-</td><td class=bl>An Lux</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=bl>Ja Peleščák</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>La Kulhánek</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Vl Lux</td><td class=bc>-</td><td class=bl>Da Votrubec</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ja Peleščák</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>On Bednář</td><td class=bc>-</td><td class=bl>Ma Peško</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ma Cingroš</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ni Kupka</td><td class=bc>-</td><td class=blW>An Lux</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Lu Toms</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ja Kubica</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Lu Toms</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>11 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ma Peško</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ja Peleščák</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>On Bednář</td><td class=bc>-</td><td class=bl>An Lux</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ni Kupka</td><td class=bc>-</td><td class=blW>Vl Lux</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>La Kulhánek</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ni Kupka</td><td class=bc>-</td><td class=blW>Da Votrubec</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>La Kulhánek</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ma Peško</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Lu Toms</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>An Lux</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ja Peleščák</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>On Bednář</td><td class=bc>-</td><td class=blW>Vl Lux</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Ja Kubica</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>La Kulhánek</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>An Lux</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Lu Toms</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Vl Lux</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ja Peleščák</td><td class=bc>-</td><td class=blW>Ja Kubica</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>On Bednář</td><td class=bc>-</td><td class=bl>Da Votrubec</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ma Peško</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ma Peško</td><td class=bc>5 : 10</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>On Bednář</td><td class=bc>-</td><td class=bl>Ni Kupka</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>La Kulhánek</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=bl>Vl Lux</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Lu Toms</td><td class=bc>-</td><td class=bl>Ja Kubica</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>Da Votrubec</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ja Peleščák</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>An Lux</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ma Peško</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=bl>An Lux</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ja Peleščák</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>La Kulhánek</td><td class=bc>-</td><td class=blW>Ja Kubica</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Da Votrubec</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Lu Toms</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>Ni Kupka</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Vl Lux</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=bl>An Lux</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Peško</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Vl Lux</td><td class=bc>5 : 7</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Ja Kubica</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>On Bednář</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>La Kulhánek</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Ni Kupka</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Lu Toms</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Da Votrubec</td><td class=bc>9 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>An Lux</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Vl Lux</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ma Peško</td><td class=bc>-</td><td class=bl>Ja Kubica</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Da Votrubec</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Lu Toms</td><td class=bc>-</td><td class=bl>Ja Peleščák</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>La Kulhánek</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>On Bednář</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Ni Kupka</td><td class=bc>5 : 0 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Vl Lux</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Lux</td><td class=bc>-</td><td class=blW>Ja Kubica</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=bl>Da Votrubec</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Peško</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Ni Kupka</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>La Kulhánek</td><td class=bc>-</td><td class=bl>Ja Peleščák</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>On Bednář</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Vl Lux</td><td class=bc>-</td><td class=bl>Ja Kubica</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Da Votrubec</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>An Lux</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Lu Vaněk</td><td class=bc>-</td><td class=bl>Ni Kupka</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Ma Peško</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>On Bednář</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Ja Peleščák</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>La Kulhánek</td><td class=bc>-</td><td class=blW>Lu Toms</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
