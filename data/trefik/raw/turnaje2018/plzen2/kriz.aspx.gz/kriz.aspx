<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Plzeň</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.stolnihokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="../../pohar.aspx">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../plzen2">Plzeň 24. únor 2018</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p><a href="#basic">Základní skupiny (Basic groups)</a><br>
<a href="#final">Výkonnostní skupiny (Final groups)</a><br>
<a name="basic"><p class=vm>Základní skupiny (Basic groups)</p></a>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Mi Hvižď</td><td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>7:2</td>
<td class=kW>6:3</td>
<td class=kW>9:0</td>
<td class=kW>6:2</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=kW>9:2</td>
<td class=kW>6:2</td>
<td class=kW>9:0</td>
<td class=br>98:22</td><td class=br>+76</td>
<td class=bc>16 - 1 - 0</td>
<td class=br><strong>33</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Kr Lebl</td><td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>7:3</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>9:2</td>
<td class=kT>3:3</td>
<td class=kW>7:3</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>6:0</td>
<td class=kW>7:0</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=br>78:26</td><td class=br>+52</td>
<td class=bc>13 - 3 - 1</td>
<td class=br><strong>29</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Da Matýsek</td><td class=kL>1:6</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>6:3</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=br>54:34</td><td class=br>+20</td>
<td class=bc>12 - 2 - 3</td>
<td class=br><strong>26</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ad Zielinský</td><td class=kL>0:6</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>2:5</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>8:3</td>
<td class=kW>5:2</td>
<td class=kW>9:5</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kW>1:0</td>
<td class=kW>6:2</td>
<td class=br>62:41</td><td class=br>+21</td>
<td class=bc>12 - 2 - 3</td>
<td class=br><strong>26</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Pa Plešák</td><td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>12:3</td>
<td class=kW>7:3</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>12:1</td>
<td class=kW>7:4</td>
<td class=kW>10:2</td>
<td class=br>90:37</td><td class=br>+53</td>
<td class=bc>11 - 4 - 2</td>
<td class=br><strong>26</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Mi Kubica</td><td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>6:4</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>8:3</td>
<td class=kW>11:2</td>
<td class=kW>9:3</td>
<td class=br>88:42</td><td class=br>+46</td>
<td class=bc>12 - 1 - 4</td>
<td class=br><strong>25</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>To Jedlička</td><td class=kL>3:5</td>
<td class=kL>3:7</td>
<td class=kW>4:3</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kW>6:1</td>
<td class=kW>8:3</td>
<td class=kW>6:0</td>
<td class=kW>7:0</td>
<td class=br>63:48</td><td class=br>+15</td>
<td class=bc>8 - 3 - 6</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>An Šurýn</td><td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kL>0:5</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>9:1</td>
<td class=br>52:44</td><td class=br>+8</td>
<td class=bc>8 - 2 - 7</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Hy Nechutný</td><td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>3:8</td>
<td class=kW>3:2</td>
<td class=kL>0:6</td>
<td class=kW>1:0</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=br>36:42</td><td class=br>-6</td>
<td class=bc>8 - 2 - 7</td>
<td class=br><strong>18</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ro Jež</td><td class=kL>2:7</td>
<td class=kL>2:9</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kL>0:4</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>8:2</td>
<td class=kW>8:1</td>
<td class=kW>8:2</td>
<td class=br>59:55</td><td class=br>+4</td>
<td class=bc>8 - 1 - 8</td>
<td class=br><strong>17</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Iv Mašková</td><td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kL>5:9</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>6:5</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kW>7:3</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=br>47:58</td><td class=br>-11</td>
<td class=bc>6 - 3 - 8</td>
<td class=br><strong>15</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>Mi Uhlíř</td><td class=kL>0:9</td>
<td class=kL>3:7</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>3:12</td>
<td class=kL>4:6</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>5:6</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=br>48:76</td><td class=br>-28</td>
<td class=bc>6 - 1 - 10</td>
<td class=br><strong>13</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Al Mačynský</td><td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kL>3:7</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kL>0:1</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=br>48:52</td><td class=br>-4</td>
<td class=bc>6 - 1 - 10</td>
<td class=br><strong>13</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>B</td><td class=d>14.</td><td class=kt>Fr Marek</td><td class=kL>1:7</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=br>41:52</td><td class=br>-11</td>
<td class=bc>6 - 1 - 10</td>
<td class=br><strong>13</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>Pa Hráský</td><td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kL>3:7</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=br>32:71</td><td class=br>-39</td>
<td class=bc>3 - 1 - 13</td>
<td class=br><strong>7</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>C</td><td class=d>16.</td><td class=kt>Ma Klazar</td><td class=kL>2:9</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kL>1:12</td>
<td class=kL>3:8</td>
<td class=kL>3:8</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>2:8</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=br>31:91</td><td class=br>-60</td>
<td class=bc>2 - 1 - 14</td>
<td class=br><strong>5</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>C</td><td class=d>17.</td><td class=kt>An Lux</td><td class=kL>2:6</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>0:1</td>
<td class=kL>4:7</td>
<td class=kL>2:11</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>1:8</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kL>1:7</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=br>25:84</td><td class=br>-59</td>
<td class=bc>1 - 0 - 16</td>
<td class=br><strong>2</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>C</td><td class=d>18.</td><td class=kt>Pe Klazar</td><td class=kL>0:9</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kL>2:10</td>
<td class=kL>3:9</td>
<td class=kL>0:7</td>
<td class=kL>1:9</td>
<td class=kL>0:4</td>
<td class=kL>2:8</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=br>19:96</td><td class=br>-77</td>
<td class=bc>0 - 1 - 16</td>
<td class=br><strong>1</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>An Lux</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>2 : 11</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>An Lux</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>An Lux</td><td class=bc>-</td><td class=blW>Pa Hráský</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>9 : 3</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>An Lux</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>An Lux</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>3 : 12</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Pa Hráský</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>An Lux</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 12</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>An Lux</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>An Lux</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>An Lux</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>An Lux</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>An Lux</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>An Lux</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>An Lux</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>An Lux</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>An Lux</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>An Lux</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>An Lux</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>10 : 2</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>5 : 9</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Zd Matoušek ml.</td><td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kW>6:3</td>
<td class=kW>7:2</td>
<td class=kW>8:2</td>
<td class=kW>8:2</td>
<td class=kW>4:2</td>
<td class=kW>9:0</td>
<td class=br>84:26</td><td class=br>+58</td>
<td class=bc>15 - 2 - 0</td>
<td class=br><strong>32</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ho Sládek</td><td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>6:0</td>
<td class=kT>1:1</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=kW>8:2</td>
<td class=kW>5:3</td>
<td class=kW>7:2</td>
<td class=br>70:35</td><td class=br>+35</td>
<td class=bc>12 - 4 - 1</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>ml Chylík</td><td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>2:0</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=br>64:28</td><td class=br>+36</td>
<td class=bc>11 - 4 - 2</td>
<td class=br><strong>26</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Mi Ševr</td><td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>9:3</td>
<td class=kW>9:2</td>
<td class=kW>9:0</td>
<td class=br>70:31</td><td class=br>+39</td>
<td class=bc>9 - 6 - 2</td>
<td class=br><strong>24</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Vá Pikl</td><td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kW>6:4</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>8:1</td>
<td class=kW>6:0</td>
<td class=kW>8:1</td>
<td class=kW>6:1</td>
<td class=kW>10:0</td>
<td class=br>71:30</td><td class=br>+41</td>
<td class=bc>12 - 0 - 5</td>
<td class=br><strong>24</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ma Maděra</td><td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>11:0</td>
<td class=kL>1:2</td>
<td class=kW>6:1</td>
<td class=kW>6:3</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kW>8:2</td>
<td class=kW>5:2</td>
<td class=br>75:33</td><td class=br>+42</td>
<td class=bc>10 - 3 - 4</td>
<td class=br><strong>23</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>To Kahoun ml.</td><td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kL>3:7</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>8:0</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>8:3</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=br>60:45</td><td class=br>+15</td>
<td class=bc>9 - 3 - 5</td>
<td class=br><strong>21</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ma Ženíšek</td><td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kL>0:1</td>
<td class=kW>6:1</td>
<td class=kW>1:0</td>
<td class=kW>6:1</td>
<td class=kW>10:1</td>
<td class=kW>6:4</td>
<td class=kW>7:0</td>
<td class=kW>9:1</td>
<td class=br>65:35</td><td class=br>+30</td>
<td class=bc>9 - 2 - 6</td>
<td class=br><strong>20</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ji Vácha</td><td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>7:4</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>8:3</td>
<td class=kW>4:1</td>
<td class=br>61:47</td><td class=br>+14</td>
<td class=bc>9 - 2 - 6</td>
<td class=br><strong>20</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ja Matýsek</td><td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kL>2:6</td>
<td class=kL>4:6</td>
<td class=kT>2:2</td>
<td class=kW>7:3</td>
<td class=kW>4:2</td>
<td class=kL>4:7</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=br>61:53</td><td class=br>+8</td>
<td class=bc>8 - 2 - 7</td>
<td class=br><strong>18</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Da Hrachovec</td><td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>0:11</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kW>10:2</td>
<td class=kW>6:1</td>
<td class=br>50:60</td><td class=br>-10</td>
<td class=bc>7 - 0 - 10</td>
<td class=br><strong>14</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>To Kahoun st.</td><td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=br>35:58</td><td class=br>-23</td>
<td class=bc>5 - 2 - 10</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Jo Gruncl</td><td class=kL>3:6</td>
<td class=kT>1:1</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>0:8</td>
<td class=kL>0:1</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kW>9:2</td>
<td class=kW>3:1</td>
<td class=br>38:60</td><td class=br>-22</td>
<td class=bc>5 - 2 - 10</td>
<td class=br><strong>12</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>B</td><td class=d>14.</td><td class=kt>Vo Bernát</td><td class=kL>2:7</td>
<td class=kL>2:7</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>1:8</td>
<td class=kL>3:6</td>
<td class=kW>3:1</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=br>47:64</td><td class=br>-17</td>
<td class=bc>6 - 0 - 11</td>
<td class=br><strong>12</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>Mi Lévy</td><td class=kL>2:8</td>
<td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kT>1:1</td>
<td class=kL>0:6</td>
<td class=kL>2:7</td>
<td class=kL>3:4</td>
<td class=kL>1:10</td>
<td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kL>2:7</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=br>37:83</td><td class=br>-46</td>
<td class=bc>5 - 1 - 11</td>
<td class=br><strong>11</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>C</td><td class=d>16.</td><td class=kt>Ma Straka</td><td class=kL>2:8</td>
<td class=kL>2:8</td>
<td class=kL>0:4</td>
<td class=kL>3:9</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kL>3:8</td>
<td class=kL>4:6</td>
<td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=br>41:92</td><td class=br>-51</td>
<td class=bc>2 - 1 - 14</td>
<td class=br><strong>5</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>C</td><td class=d>17.</td><td class=kt>An Grimová</td><td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>2:7</td>
<td class=kL>2:9</td>
<td class=kL>1:6</td>
<td class=kL>2:8</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>3:8</td>
<td class=kL>0:2</td>
<td class=kL>2:10</td>
<td class=kW>4:3</td>
<td class=kL>2:9</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=br>28:97</td><td class=br>-69</td>
<td class=bc>1 - 1 - 15</td>
<td class=br><strong>3</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>C</td><td class=d>18.</td><td class=kt>Lu Vaněk</td><td class=kL>0:9</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kL>0:9</td>
<td class=kL>0:10</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>1:9</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=br>17:97</td><td class=br>-80</td>
<td class=bc>0 - 1 - 16</td>
<td class=br><strong>1</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ma Straka</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ma Straka</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Jo Gruncl</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Straka</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Straka</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Straka</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>3 : 9</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ma Straka</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 11</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ma Straka</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ma Straka</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Straka</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Jo Gruncl</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Straka</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Zd Matoušek ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ma Straka</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Jo Gruncl</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Zd Matoušek ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ma Straka</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Jo Gruncl</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>2 : 10</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ma Straka</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ma Straka</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Jo Gruncl</td><td class=bc>-</td><td class=bl>Ma Straka</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Ma Straka</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Ma Straka</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Ma Straka</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 3</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Le Hvižď ml.</td><td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:4</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kW>4:2</td>
<td class=kW>10:2</td>
<td class=kW>4:0</td>
<td class=kW>11:2</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=kW>9:0</td>
<td class=br>97:27</td><td class=br>+70</td>
<td class=bc>16 - 1 - 0</td>
<td class=br><strong>33</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Mi Kobrle</td><td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>10:4</td>
<td class=kW>5:3</td>
<td class=kT>5:5</td>
<td class=kW>7:2</td>
<td class=kW>7:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kW>7:2</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=br>94:30</td><td class=br>+64</td>
<td class=bc>14 - 2 - 1</td>
<td class=br><strong>30</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>St Kraus</td><td class=kL>4:5</td>
<td class=kL>4:10</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>8:1</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kL>2:4</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>9:1</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=kW>6:2</td>
<td class=kW>8:1</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=br>97:35</td><td class=br>+62</td>
<td class=bc>14 - 0 - 3</td>
<td class=br><strong>28</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Da Šmíd</td><td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>8:2</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=br>64:30</td><td class=br>+34</td>
<td class=bc>11 - 3 - 3</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Mi Boštík</td><td class=kT>3:3</td>
<td class=kT>5:5</td>
<td class=kL>1:8</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>8:1</td>
<td class=kW>5:0</td>
<td class=kW>5:4</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=br>67:35</td><td class=br>+32</td>
<td class=bc>10 - 5 - 2</td>
<td class=br><strong>25</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Kr Herold</td><td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kL>1:7</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>9:2</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>8:1</td>
<td class=br>61:48</td><td class=br>+13</td>
<td class=bc>9 - 4 - 4</td>
<td class=br><strong>22</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Zd Matoušek st.</td><td class=kL>2:5</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=br>48:36</td><td class=br>+12</td>
<td class=bc>10 - 1 - 6</td>
<td class=br><strong>21</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Vl Kraus</td><td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>8:2</td>
<td class=kW>7:0</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>9:1</td>
<td class=br>64:45</td><td class=br>+19</td>
<td class=bc>7 - 5 - 5</td>
<td class=br><strong>19</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>To Bucek</td><td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>9:3</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>12:0</td>
<td class=kW>5:1</td>
<td class=kW>10:1</td>
<td class=br>72:50</td><td class=br>+22</td>
<td class=bc>8 - 2 - 7</td>
<td class=br><strong>18</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Zb Pilař</td><td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=kW>6:3</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>56:44</td><td class=br>+12</td>
<td class=bc>8 - 1 - 8</td>
<td class=br><strong>17</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Mi Holeček</td><td class=kL>1:7</td>
<td class=kL>0:6</td>
<td class=kL>1:9</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=br>41:48</td><td class=br>-7</td>
<td class=bc>7 - 3 - 7</td>
<td class=br><strong>17</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>Zd Lopaur</td><td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>0:5</td>
<td class=kW>2:0</td>
<td class=kW>5:4</td>
<td class=kW>7:1</td>
<td class=kW>2:0</td>
<td class=br>40:50</td><td class=br>-10</td>
<td class=bc>6 - 2 - 9</td>
<td class=br><strong>14</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Ja Medvec</td><td class=kL>2:10</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>2:8</td>
<td class=kL>3:9</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=kW>7:1</td>
<td class=br>45:75</td><td class=br>-30</td>
<td class=bc>5 - 1 - 11</td>
<td class=br><strong>11</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>B</td><td class=d>14.</td><td class=kt>To Růžička</td><td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>1:8</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kW>5:0</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kL>4:6</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=br>35:74</td><td class=br>-39</td>
<td class=bc>4 - 2 - 11</td>
<td class=br><strong>10</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>Ra Bidlo</td><td class=kL>2:11</td>
<td class=kL>2:7</td>
<td class=kL>1:8</td>
<td class=kL>2:8</td>
<td class=kL>0:5</td>
<td class=kL>2:9</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kW>6:4</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=br>37:82</td><td class=br>-45</td>
<td class=bc>3 - 1 - 13</td>
<td class=br><strong>7</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>C</td><td class=d>16.</td><td class=kt>Pe Fuchs</td><td class=kL>2:7</td>
<td class=kL>1:7</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>4:5</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>0:12</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kL>4:5</td>
<td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>9:0</td>
<td class=br>39:75</td><td class=br>-36</td>
<td class=bc>3 - 0 - 14</td>
<td class=br><strong>6</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>C</td><td class=d>17.</td><td class=kt>Jo Perkner</td><td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=br>13:83</td><td class=br>-70</td>
<td class=bc>1 - 1 - 15</td>
<td class=br><strong>3</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>C</td><td class=d>18.</td><td class=kt>Ma Cingroš</td><td class=kL>0:9</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>0:8</td>
<td class=kL>1:8</td>
<td class=kL>1:5</td>
<td class=kL>1:9</td>
<td class=kL>1:10</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>0:9</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=br>10:113</td><td class=br>-103</td>
<td class=bc>0 - 0 - 17</td>
<td class=br><strong>0</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Zb Pilař</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>10 : 2</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Mi Holeček</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ja Medvec</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 12</tr></td>
<tr><td class=br>Mi Holeček</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Ja Medvec</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Mi Holeček</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Zb Pilař</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ra Bidlo</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Mi Holeček</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Zb Pilař</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Mi Holeček</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Zb Pilař</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Mi Holeček</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Zb Pilař</td><td class=bc>-</td><td class=bl>Mi Holeček</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Mi Holeček</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ra Bidlo</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Mi Holeček</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Ja Medvec</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ra Bidlo</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>6 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Mi Holeček</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Zb Pilař</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Mi Holeček</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Mi Holeček</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Mi Holeček</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mi Holeček</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Ja Medvec</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>11 : 2</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Zb Pilař</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Mi Holeček</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>9 : 3</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ra Bidlo</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Mi Holeček</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>10 : 4</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Zb Pilař</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Ja Medvec</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Mi Holeček</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<hr><a name="final"><p class=vm>Výkonnostní skupiny (Final groups)</p></a>
<p class=v>Group A</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt>Mi Hvižď</td><td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kW>4:0 K</td>
<td class=kW>6:4</td>
<td class=kW>3:2</td>
<td class=kT>3:3 K</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1 K</td>
<td class=kW>4:2 K</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>6:0 K</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>5:3 K</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>9:3</td>
<td class=kW>3:0 K</td>
<td class=br>96:42</td><td class=br>+54</td>
<td class=bc>19 - 4 - 0</td>
<td class=br><strong>42</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt>Zd Matoušek ml.</td><td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kL>3:6</td>
<td class=kW>6:3 K</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2 K</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>4:3 K</td>
<td class=kW>3:0</td>
<td class=kW>3:0 K</td>
<td class=kW>2:1 K</td>
<td class=kT>2:2 K</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>4:2 K</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=br>88:41</td><td class=br>+47</td>
<td class=bc>19 - 3 - 1</td>
<td class=br><strong>41</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt>Le Hvižď ml.</td><td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>5:4 K</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1 K</td>
<td class=kT>3:3 K</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kW>5:2 K</td>
<td class=kW>5:3 K</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kW>7:0</td>
<td class=kW>5:2 K</td>
<td class=kW>9:1</td>
<td class=kW>5:0 K</td>
<td class=kW>3:1</td>
<td class=br>102:45</td><td class=br>+57</td>
<td class=bc>18 - 3 - 2</td>
<td class=br><strong>39</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt>Kr Lebl</td><td class=kL>0:4 K</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2 K</td>
<td class=kW>4:3</td>
<td class=kW>7:3</td>
<td class=kW>1:0 K</td>
<td class=kW>5:1 K</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kT>3:3 K</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>7:3 K</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>3:0 K</td>
<td class=br>74:43</td><td class=br>+31</td>
<td class=bc>16 - 3 - 4</td>
<td class=br><strong>35</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>St Kraus</td><td class=kL>4:6</td>
<td class=kW>6:3</td>
<td class=kL>4:5 K</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kL>4:10 K</td>
<td class=kW>8:1 K</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>7:1 K</td>
<td class=kW>6:3 K</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>8:2</td>
<td class=kT>2:2</td>
<td class=kW>8:1</td>
<td class=kW>4:0 K</td>
<td class=kW>9:1</td>
<td class=kL>2:4 K</td>
<td class=kW>5:0</td>
<td class=br>106:58</td><td class=br>+48</td>
<td class=bc>14 - 4 - 5</td>
<td class=br><strong>32</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>Ho Sládek</td><td class=kL>2:3</td>
<td class=kL>3:6 K</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kW>8:1</td>
<td class=kT>1:1 K</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kT>3:3 K</td>
<td class=kW>3:0</td>
<td class=kW>3:2 K</td>
<td class=kT>3:3 K</td>
<td class=kW>4:3 K</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>4:3 K</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=br>66:53</td><td class=br>+13</td>
<td class=bc>11 - 5 - 7</td>
<td class=br><strong>27</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Pa Plešák</td><td class=kT>3:3 K</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kT>2:2 K</td>
<td class=kL>3:6</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kT>3:3 K</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kT>5:5</td>
<td class=kL>3:4 K</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>4:2 K</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>4:1 K</td>
<td class=br>78:66</td><td class=br>+12</td>
<td class=bc>9 - 9 - 5</td>
<td class=br><strong>27</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>Mi Kobrle</td><td class=kT>2:2</td>
<td class=kL>1:7</td>
<td class=kL>1:3 K</td>
<td class=kL>3:4</td>
<td class=kW>10:4 K</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>5:5 K</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kW>7:2 K</td>
<td class=kW>5:3 K</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>7:1 K</td>
<td class=kW>6:1</td>
<td class=kT>3:3 K</td>
<td class=kW>4:0</td>
<td class=br>85:57</td><td class=br>+28</td>
<td class=bc>10 - 7 - 6</td>
<td class=br><strong>27</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>Mi Boštík</td><td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kT>3:3 K</td>
<td class=kL>3:7</td>
<td class=kL>1:8 K</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kT>5:5 K</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kW>4:1 K</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kW>10:5</td>
<td class=kL>0:1 K</td>
<td class=kW>6:1</td>
<td class=kT>3:3 K</td>
<td class=kW>4:0</td>
<td class=br>68:63</td><td class=br>+5</td>
<td class=bc>7 - 8 - 8</td>
<td class=br><strong>22</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Da Matýsek</td><td class=kL>1:6 K</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kL>0:1 K</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3 K</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>3:0 K</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>0:6</td>
<td class=kT>3:3</td>
<td class=kW>2:1 K</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>3:4 K</td>
<td class=kW>4:0</td>
<td class=kL>2:7</td>
<td class=kW>2:0</td>
<td class=kT>3:3 K</td>
<td class=br>48:61</td><td class=br>-13</td>
<td class=bc>9 - 4 - 10</td>
<td class=br><strong>22</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>Mi Kubica</td><td class=kL>2:4 K</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:5 K</td>
<td class=kT>2:2</td>
<td class=kL>1:8</td>
<td class=kT>2:2 K</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kL>0:3 K</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>5:2 K</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kL>4:5 K</td>
<td class=kW>4:1</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kW>7:2 K</td>
<td class=br>58:64</td><td class=br>-6</td>
<td class=bc>9 - 4 - 10</td>
<td class=br><strong>22</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>ml Chylík</td><td class=kL>3:6</td>
<td class=kL>2:5 K</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kT>1:1 K</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>1:0 K</td>
<td class=kW>2:1</td>
<td class=kL>2:3 K</td>
<td class=kT>3:3 K</td>
<td class=kW>4:1 K</td>
<td class=kL>4:8</td>
<td class=kL>1:2</td>
<td class=kT>2:2 K</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=br>49:56</td><td class=br>-7</td>
<td class=bc>7 - 7 - 9</td>
<td class=br><strong>21</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt>Kr Herold</td><td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>2:5 K</td>
<td class=kL>0:4</td>
<td class=kL>1:7 K</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>2:7 K</td>
<td class=kL>1:4 K</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kW>5:0</td>
<td class=kW>4:1 K</td>
<td class=kW>6:4</td>
<td class=kW>3:1 K</td>
<td class=kT>3:3</td>
<td class=br>52:69</td><td class=br>-17</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt>Da Šmíd</td><td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>3:5 K</td>
<td class=kL>1:2</td>
<td class=kL>3:6 K</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>3:5 K</td>
<td class=kT>1:1 K</td>
<td class=kW>6:0</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kW>2:1 K</td>
<td class=kW>3:2</td>
<td class=kW>3:2 K</td>
<td class=kW>6:0</td>
<td class=br>57:63</td><td class=br>-6</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt>Ma Maděra</td><td class=kL>1:2</td>
<td class=kL>3:4 K</td>
<td class=kT>4:4</td>
<td class=kL>0:4</td>
<td class=kL>3:6</td>
<td class=kT>3:3 K</td>
<td class=kT>5:5</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>0:1 K</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kW>5:2 K</td>
<td class=kT>3:3 K</td>
<td class=kW>4:1 K</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kL>2:3 K</td>
<td class=kW>6:4</td>
<td class=kW>4:1</td>
<td class=br>64:69</td><td class=br>-5</td>
<td class=bc>7 - 6 - 10</td>
<td class=br><strong>20</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt>Ad Zielinský</td><td class=kL>0:6 K</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kT>3:3 K</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kW>4:3 K</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>1:2 K</td>
<td class=kL>2:5 K</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>2:0 K</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>2:0 K</td>
<td class=br>49:53</td><td class=br>-4</td>
<td class=bc>7 - 5 - 11</td>
<td class=br><strong>19</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Vá Pikl</td><td class=kL>2:3</td>
<td class=kL>0:3 K</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>2:3 K</td>
<td class=kW>4:1</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kW>3:2 K</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>2:5 K</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>1:3 K</td>
<td class=kL>2:3 K</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1 K</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=br>49:65</td><td class=br>-16</td>
<td class=bc>8 - 3 - 12</td>
<td class=br><strong>19</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Mi Ševr</td><td class=kL>3:6</td>
<td class=kL>1:2 K</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>2:8</td>
<td class=kT>3:3 K</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kT>3:3 K</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kT>3:3 K</td>
<td class=kT>1:1</td>
<td class=kW>3:1 K</td>
<td class=kx>*</td>
<td class=kT>1:1 K</td>
<td class=kW>5:3</td>
<td class=kW>5:3</td>
<td class=kT>3:3 K</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=br>55:73</td><td class=br>-18</td>
<td class=bc>4 - 10 - 9</td>
<td class=br><strong>18</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Ma Ženíšek</td><td class=kL>2:3</td>
<td class=kT>2:2 K</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>3:4 K</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>1:4 K</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>1:4 K</td>
<td class=kW>2:1</td>
<td class=kW>3:2 K</td>
<td class=kT>1:1 K</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>3:4</td>
<td class=kL>3:4 K</td>
<td class=kL>2:5</td>
<td class=kW>4:0</td>
<td class=br>54:61</td><td class=br>-7</td>
<td class=bc>6 - 4 - 13</td>
<td class=br><strong>16</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>To Jedlička</td><td class=kL>3:5 K</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kL>3:7 K</td>
<td class=kL>1:8</td>
<td class=kL>3:4</td>
<td class=kL>2:4 K</td>
<td class=kL>2:6</td>
<td class=kL>5:10</td>
<td class=kW>4:3 K</td>
<td class=kW>5:4 K</td>
<td class=kW>8:4</td>
<td class=kL>0:5</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kL>0:2 K</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>4:3 K</td>
<td class=br>67:100</td><td class=br>-33</td>
<td class=bc>8 - 0 - 15</td>
<td class=br><strong>16</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Zd Matoušek st.</td><td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>2:5 K</td>
<td class=kW>2:1</td>
<td class=kL>0:4 K</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>1:7 K</td>
<td class=kW>1:0 K</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>1:4 K</td>
<td class=kL>1:2 K</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:2 K</td>
<td class=kW>4:1</td>
<td class=br>44:76</td><td class=br>-32</td>
<td class=bc>6 - 2 - 15</td>
<td class=br><strong>14</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>To Kahoun ml.</td><td class=kL>2:5</td>
<td class=kL>2:4 K</td>
<td class=kL>1:9</td>
<td class=kL>1:4</td>
<td class=kL>1:9</td>
<td class=kL>3:4 K</td>
<td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kW>7:2</td>
<td class=kW>2:0</td>
<td class=kT>2:2 K</td>
<td class=kL>4:6</td>
<td class=kL>2:3</td>
<td class=kW>3:2 K</td>
<td class=kT>1:1</td>
<td class=kL>1:4 K</td>
<td class=kT>3:3 K</td>
<td class=kW>4:3 K</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>0:2</td>
<td class=br>50:86</td><td class=br>-36</td>
<td class=bc>5 - 4 - 14</td>
<td class=br><strong>14</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Vl Kraus</td><td class=kL>3:9</td>
<td class=kL>3:5</td>
<td class=kL>0:5 K</td>
<td class=kL>2:5</td>
<td class=kW>4:2 K</td>
<td class=kW>4:2</td>
<td class=kL>1:6</td>
<td class=kT>3:3 K</td>
<td class=kT>3:3 K</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>1:3 K</td>
<td class=kL>2:3 K</td>
<td class=kL>4:6</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kL>1:6</td>
<td class=kL>2:5 K</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>51:88</td><td class=br>-37</td>
<td class=bc>4 - 4 - 15</td>
<td class=br><strong>12</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>An Šurýn</td><td class=kL>0:3 K</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>0:3 K</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>1:4 K</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kT>3:3 K</td>
<td class=kL>2:7 K</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>0:2 K</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>3:4 K</td>
<td class=kL>1:4</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>22:80</td><td class=br>-58</td>
<td class=bc>1 - 3 - 19</td>
<td class=br><strong>5</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>9 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>5 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Ad Zielinský</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>5 : 10</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>St Kraus</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>To Jedlička</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Mi Hvižď</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>St Kraus</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ad Zielinský</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>To Jedlička</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>8 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Hvižď</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>St Kraus</td><td class=bc>-</td><td class=bl>Ad Zielinský</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>To Jedlička</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>St Kraus</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ad Zielinský</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>To Jedlička</td><td class=bc>4 : 8</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Ro Jež</td><td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>6:3</td>
<td class=kW>5:0</td>
<td class=kL>3:5</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>8:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=br>69:33</td><td class=br>+36</td>
<td class=bc>12 - 2 - 3</td>
<td class=br><strong>26</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Ji Vácha</td><td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>3:6</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kL>4:6</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kW>10:1</td>
<td class=br>70:47</td><td class=br>+23</td>
<td class=bc>11 - 3 - 3</td>
<td class=br><strong>25</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Zb Pilař</td><td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kW>6:3</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=br>61:48</td><td class=br>+13</td>
<td class=bc>10 - 2 - 5</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>To Kahoun st.</td><td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=br>50:39</td><td class=br>+11</td>
<td class=bc>9 - 3 - 5</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>To Bucek</td><td class=kL>0:5</td>
<td class=kW>6:3</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kW>6:2</td>
<td class=kL>2:4</td>
<td class=kW>7:1</td>
<td class=kL>2:6</td>
<td class=kW>4:1</td>
<td class=kW>6:5</td>
<td class=kW>5:4</td>
<td class=kL>5:6</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=br>65:55</td><td class=br>+10</td>
<td class=bc>10 - 0 - 7</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Ja Matýsek</td><td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kL>3:6</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kL>0:7</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kW>9:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=br>55:47</td><td class=br>+8</td>
<td class=bc>9 - 2 - 6</td>
<td class=br><strong>20</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Hy Nechutný</td><td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>2:0</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kW>6:3</td>
<td class=br>44:42</td><td class=br>+2</td>
<td class=bc>8 - 2 - 7</td>
<td class=br><strong>18</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Mi Holeček</td><td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kT>0:0</td>
<td class=kT>0:0</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=br>42:41</td><td class=br>+1</td>
<td class=bc>6 - 6 - 5</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Fr Marek</td><td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kT>5:5</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=br>51:50</td><td class=br>+1</td>
<td class=bc>6 - 5 - 6</td>
<td class=br><strong>17</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Vo Bernát</td><td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>0:6</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=br>53:57</td><td class=br>-4</td>
<td class=bc>6 - 5 - 6</td>
<td class=br><strong>17</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Ja Medvec</td><td class=kL>3:8</td>
<td class=kW>5:3</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kT>0:0</td>
<td class=kT>5:5</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>6:5</td>
<td class=kW>5:4</td>
<td class=kW>5:4</td>
<td class=kL>1:3</td>
<td class=kL>4:6</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=br>53:65</td><td class=br>-12</td>
<td class=bc>6 - 4 - 7</td>
<td class=br><strong>16</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Da Hrachovec</td><td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kL>5:6</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=br>44:43</td><td class=br>+1</td>
<td class=bc>6 - 4 - 7</td>
<td class=br><strong>16</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Zd Lopaur</td><td class=kL>1:2</td>
<td class=kL>4:5</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kW>7:0</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=br>53:45</td><td class=br>+8</td>
<td class=bc>5 - 5 - 7</td>
<td class=br><strong>15</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>To Růžička</td><td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kL>5:6</td>
<td class=kW>4:2</td>
<td class=kL>1:7</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>6:6</td>
<td class=kW>5:2</td>
<td class=kW>1:0</td>
<td class=br>49:63</td><td class=br>-14</td>
<td class=bc>5 - 4 - 8</td>
<td class=br><strong>14</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Al Mačynský</td><td class=kL>2:7</td>
<td class=kW>6:4</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>4:5</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=br>39:52</td><td class=br>-13</td>
<td class=bc>4 - 3 - 10</td>
<td class=br><strong>11</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Mi Uhlíř</td><td class=kL>0:4</td>
<td class=kL>3:6</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kW>6:5</td>
<td class=kL>2:9</td>
<td class=kW>6:2</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kW>6:4</td>
<td class=kL>3:4</td>
<td class=kL>2:7</td>
<td class=kT>6:6</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=br>54:76</td><td class=br>-22</td>
<td class=bc>4 - 3 - 10</td>
<td class=br><strong>11</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Iv Mašková</td><td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=br>35:55</td><td class=br>-20</td>
<td class=bc>4 - 2 - 11</td>
<td class=br><strong>10</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Jo Gruncl</td><td class=kW>4:1</td>
<td class=kL>1:10</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=br>31:60</td><td class=br>-29</td>
<td class=bc>4 - 1 - 12</td>
<td class=br><strong>9</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Zb Pilař</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Mi Holeček</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Ja Medvec</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=bl>Mi Holeček</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Ja Medvec</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=bl>Mi Holeček</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Mi Holeček</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Zb Pilař</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ja Medvec</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Mi Holeček</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Zb Pilař</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ja Medvec</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=bl>Mi Holeček</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Mi Holeček</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Zb Pilař</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Mi Holeček</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ja Medvec</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Zb Pilař</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Mi Holeček</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Jo Gruncl</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Zb Pilař</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Jo Gruncl</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Mi Holeček</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Zb Pilař</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Zb Pilař</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Holeček</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Holeček</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Holeček</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>6 : 6</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mi Holeček</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Jo Gruncl</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Holeček</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Jo Gruncl</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Zb Pilař</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Ja Medvec</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Holeček</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Zb Pilař</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Holeček</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Ra Bidlo</td><td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>8:2</td>
<td class=kW>5:2</td>
<td class=kL>2:5</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=br>45:20</td><td class=br>+25</td>
<td class=bc>9 - 1 - 1</td>
<td class=br><strong>19</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Pe Fuchs</td><td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kW>10:0</td>
<td class=br>48:16</td><td class=br>+32</td>
<td class=bc>9 - 1 - 1</td>
<td class=br><strong>19</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Pa Hráský</td><td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>8:0</td>
<td class=kW>6:1</td>
<td class=br>42:19</td><td class=br>+23</td>
<td class=bc>8 - 1 - 2</td>
<td class=br><strong>17</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Mi Lévy</td><td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>0:5</td>
<td class=kW>9:2</td>
<td class=kW>5:2</td>
<td class=kW>8:2</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=br>45:26</td><td class=br>+19</td>
<td class=bc>7 - 1 - 3</td>
<td class=br><strong>15</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ma Straka</td><td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>8:1</td>
<td class=kW>4:0</td>
<td class=kW>8:2</td>
<td class=br>42:30</td><td class=br>+12</td>
<td class=bc>6 - 1 - 4</td>
<td class=br><strong>13</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>An Grimová</td><td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kL>0:3</td>
<td class=kW>1:0</td>
<td class=br>20:21</td><td class=br>-1</td>
<td class=bc>4 - 2 - 5</td>
<td class=br><strong>10</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Ma Klazar</td><td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>2:9</td>
<td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=br>26:34</td><td class=br>-8</td>
<td class=bc>4 - 1 - 6</td>
<td class=br><strong>9</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Jo Perkner</td><td class=kL>2:8</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=br>22:36</td><td class=br>-14</td>
<td class=bc>4 - 0 - 7</td>
<td class=br><strong>8</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Pe Klazar</td><td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>2:8</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>9:1</td>
<td class=kT>2:2</td>
<td class=br>25:35</td><td class=br>-10</td>
<td class=bc>2 - 3 - 6</td>
<td class=br><strong>7</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>An Lux</td><td class=kW>5:2</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=br>23:32</td><td class=br>-9</td>
<td class=bc>3 - 1 - 7</td>
<td class=br><strong>7</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Lu Vaněk</td><td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>0:8</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kL>1:9</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=br>18:40</td><td class=br>-22</td>
<td class=bc>3 - 1 - 7</td>
<td class=br><strong>7</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ma Cingroš</td><td class=kL>1:6</td>
<td class=kL>0:10</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>2:8</td>
<td class=kL>0:1</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=br>9:56</td><td class=br>-47</td>
<td class=bc>0 - 1 - 10</td>
<td class=br><strong>1</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ra Bidlo</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Straka</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>An Lux</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Lu Vaněk</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ra Bidlo</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>An Lux</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ma Straka</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>An Lux</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ra Bidlo</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ma Straka</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Lu Vaněk</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>An Lux</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Ma Straka</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ra Bidlo</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>An Lux</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Ma Straka</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Lévy</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>An Lux</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ma Straka</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Ra Bidlo</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>An Lux</td><td class=bc>-</td><td class=blW>Ma Straka</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ra Bidlo</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Pa Hráský</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>An Lux</td><td class=bc>-</td><td class=bl>Ra Bidlo</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Pa Hráský</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ma Straka</td><td class=bc>-</td><td class=blW>Ra Bidlo</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Mi Lévy</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>An Lux</td><td class=bc>-</td><td class=blW>Pa Hráský</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Lu Vaněk</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Mi Lévy</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Ma Straka</td><td class=bc>-</td><td class=blW>Pa Hráský</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>An Lux</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ra Bidlo</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ma Straka</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>An Lux</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Mi Lévy</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ra Bidlo</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ma Straka</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>An Lux</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
