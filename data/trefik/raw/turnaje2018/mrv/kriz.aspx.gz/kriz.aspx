<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR veteráni</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.stolnihokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="../../pohar.aspx">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../mrv">MR veteráni 3. červen 2018</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p><a href="#basic">Základní skupiny (Basic groups)</a><br>
<a href="#final">Výkonnostní skupiny (Final groups)</a><br>
<a name="basic"><p class=vm>Základní skupiny (Basic groups)</p></a>
<p class=v>Group V1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Ja Dryák</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=kW>8:1</td>
<td class=br>54:12</td><td class=br>+42</td>
<td class=bc>10 - 2 - 0</td>
<td class=br><strong>22</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Ka Krejčík</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=br>34:24</td><td class=br>+10</td>
<td class=bc>7 - 4 - 1</td>
<td class=br><strong>18</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Da Matýsek</td><td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>8:2</td>
<td class=br>38:22</td><td class=br>+16</td>
<td class=bc>9 - 0 - 3</td>
<td class=br><strong>18</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>To Bucek</td><td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>7:3</td>
<td class=kL>2:5</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>9:1</td>
<td class=br>48:25</td><td class=br>+23</td>
<td class=bc>7 - 3 - 2</td>
<td class=br><strong>17</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Vá Pikl</td><td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>1:0</td>
<td class=kW>8:0</td>
<td class=br>38:20</td><td class=br>+18</td>
<td class=bc>7 - 1 - 4</td>
<td class=br><strong>15</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Da Cibulka</td><td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>3:7</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kL>4:5</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=br>38:33</td><td class=br>+5</td>
<td class=bc>7 - 0 - 5</td>
<td class=br><strong>14</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>St Suchý</td><td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kW>5:0</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>8:2</td>
<td class=br>33:27</td><td class=br>+6</td>
<td class=bc>5 - 3 - 4</td>
<td class=br><strong>13</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Zd Lopaur</td><td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=br>28:36</td><td class=br>-8</td>
<td class=bc>3 - 4 - 5</td>
<td class=br><strong>10</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Zd Matoušek st.</td><td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=br>24:33</td><td class=br>-9</td>
<td class=bc>4 - 1 - 7</td>
<td class=br><strong>9</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Da Hrachovec</td><td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kW>5:4</td>
<td class=kW>1:0</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kW>7:2</td>
<td class=br>25:40</td><td class=br>-15</td>
<td class=bc>4 - 0 - 8</td>
<td class=br><strong>8</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>To Kahoun st.</td><td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kL>0:1</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>6:0</td>
<td class=br>20:28</td><td class=br>-8</td>
<td class=bc>3 - 1 - 8</td>
<td class=br><strong>7</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ja Ouřada</td><td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=br>19:35</td><td class=br>-16</td>
<td class=bc>2 - 1 - 9</td>
<td class=br><strong>5</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Pe Klazar</td><td class=kL>1:8</td>
<td class=kL>1:5</td>
<td class=kL>2:8</td>
<td class=kL>1:9</td>
<td class=kL>0:8</td>
<td class=kL>2:5</td>
<td class=kL>2:8</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=br>12:76</td><td class=br>-64</td>
<td class=bc>0 - 0 - 12</td>
<td class=br><strong>0</strong></td><td class=d>13.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>St Suchý</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>St Suchý</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Ka Krejčík</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>St Suchý</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ja Dryák</td><td class=bc>-</td><td class=bl>Ka Krejčík</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>St Suchý</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Ka Krejčík</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ka Krejčík</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>St Suchý</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>4 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ka Krejčík</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ja Ouřada</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>St Suchý</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ka Krejčík</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>St Suchý</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ka Krejčík</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ka Krejčík</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>St Suchý</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Ka Krejčík</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=blW>St Suchý</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Ka Krejčík</td><td class=bc>-</td><td class=bl>St Suchý</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=bl>St Suchý</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Ka Krejčík</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>St Suchý</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Ja Ouřada</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Ka Krejčík</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>2 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group V2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Da Šmíd</td><td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>4:3</td>
<td class=kW>7:0</td>
<td class=kW>7:4</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=br>57:21</td><td class=br>+36</td>
<td class=bc>12 - 1 - 0</td>
<td class=br><strong>25</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Pa Plešák</td><td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kT>4:4</td>
<td class=kW>13:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>8:1</td>
<td class=kW>8:1</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>11:1</td>
<td class=kW>4:0</td>
<td class=br>78:18</td><td class=br>+60</td>
<td class=bc>10 - 3 - 0</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Lu Černý</td><td class=kL>1:3</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kW>6:4</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=br>53:25</td><td class=br>+28</td>
<td class=bc>10 - 1 - 2</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Vl Kraus</td><td class=kL>1:6</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=br>43:27</td><td class=br>+16</td>
<td class=bc>8 - 3 - 2</td>
<td class=br><strong>19</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Jo Kůrka</td><td class=kL>3:5</td>
<td class=kL>1:13</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>6:3</td>
<td class=br>50:44</td><td class=br>+6</td>
<td class=bc>9 - 1 - 3</td>
<td class=br><strong>19</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Fr Marek</td><td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>4:6</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>6:5</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kL>0:5</td>
<td class=br>38:42</td><td class=br>-4</td>
<td class=bc>7 - 0 - 6</td>
<td class=br><strong>14</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Zb Pilař</td><td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>5:6</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=br>38:33</td><td class=br>+5</td>
<td class=bc>6 - 1 - 6</td>
<td class=br><strong>13</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>St Srba</td><td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=br>23:27</td><td class=br>-4</td>
<td class=bc>5 - 2 - 6</td>
<td class=br><strong>12</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Ja Medvec</td><td class=kL>1:6</td>
<td class=kL>1:8</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kT>0:0</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=br>21:40</td><td class=br>-19</td>
<td class=bc>2 - 4 - 7</td>
<td class=br><strong>8</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Jo Sedláček</td><td class=kL>3:4</td>
<td class=kL>1:8</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=br>24:51</td><td class=br>-27</td>
<td class=bc>3 - 2 - 8</td>
<td class=br><strong>8</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Pe Holub</td><td class=kL>0:7</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=br>24:49</td><td class=br>-25</td>
<td class=bc>2 - 2 - 9</td>
<td class=br><strong>6</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Jo Gruncl</td><td class=kL>4:7</td>
<td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kT>0:0</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=br>24:47</td><td class=br>-23</td>
<td class=bc>2 - 1 - 10</td>
<td class=br><strong>5</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ji Petr</td><td class=kL>1:4</td>
<td class=kL>1:11</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>3:6</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=br>26:52</td><td class=br>-26</td>
<td class=bc>2 - 1 - 10</td>
<td class=br><strong>5</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Pe Vlach</td><td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>3:6</td>
<td class=kW>5:0</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=br>25:48</td><td class=br>-23</td>
<td class=bc>2 - 0 - 11</td>
<td class=br><strong>4</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Lu Černý</td><td class=bc>-</td><td class=bl>Pe Vlach</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Jo Kůrka</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 13</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Ji Petr</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Pe Vlach</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Lu Černý</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>Ji Petr</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pe Vlach</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Lu Černý</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Zb Pilař</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=bl>Ji Petr</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pe Vlach</td><td class=bc>-</td><td class=blW>Zb Pilař</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Lu Černý</td><td class=bc>-</td><td class=bl>Ji Petr</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ji Petr</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pe Vlach</td><td class=bc>-</td><td class=blW>Ja Medvec</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Lu Černý</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Jo Kůrka</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Zb Pilař</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Ji Petr</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pe Vlach</td><td class=bc>-</td><td class=blW>Jo Kůrka</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Lu Černý</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Jo Gruncl</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Zb Pilař</td><td class=bc>-</td><td class=bl>Ji Petr</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Jo Kůrka</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Pe Vlach</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Lu Černý</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ji Petr</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>Jo Kůrka</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Lu Černý</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pe Vlach</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ji Petr</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Zb Pilař</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Lu Černý</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Pe Vlach</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ja Medvec</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ji Petr</td><td class=bc>-</td><td class=blW>Jo Gruncl</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>Lu Černý</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Pe Vlach</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Lu Černý</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ji Petr</td><td class=bc>-</td><td class=bl>Pe Vlach</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>Lu Černý</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Pe Vlach</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ji Petr</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Zb Pilař</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Lu Černý</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Pe Vlach</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Jo Kůrka</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ji Petr</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 11</tr></td>
<tr><td class=br>Zb Pilař</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Pe Vlach</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Zb Pilař</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ji Petr</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<hr><a name="final"><p class=vm>Výkonnostní skupiny (Final groups)</p></a>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
