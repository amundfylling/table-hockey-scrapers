<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR junioři + ženy</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.stolnihokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="../../pohar.aspx">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../mrjz">MR junioři + ženy 3. červen 2018</a></span></h2></div></div></div></div><p><div align="center">
<div align=center>

<p class=v>Group JW</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Ho Sládek</td><td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>9:2</td>
<td class=kW>8:1</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>8:1</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>8:5</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=br>95:29</td><td class=br>+66</td>
<td class=bc>16 - 1 - 0</td>
<td class=br><strong>33</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Ja Matýsek</td><td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kW>5:4</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>7:5</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>7:3</td>
<td class=br>78:38</td><td class=br>+40</td>
<td class=bc>15 - 1 - 1</td>
<td class=br><strong>31</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>To Růžička</td><td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kW>9:0</td>
<td class=br>56:25</td><td class=br>+31</td>
<td class=bc>11 - 2 - 4</td>
<td class=br><strong>24</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Al Mačynský</td><td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>9:0</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=br>62:31</td><td class=br>+31</td>
<td class=bc>11 - 2 - 4</td>
<td class=br><strong>24</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Pa Hráský</td><td class=kL>2:9</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>8:0</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=br>46:41</td><td class=br>+5</td>
<td class=bc>11 - 1 - 5</td>
<td class=br><strong>23</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Iv Mašková</td><td class=kL>1:8</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=br>56:43</td><td class=br>+13</td>
<td class=bc>10 - 2 - 5</td>
<td class=br><strong>22</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Vl Gobyová</td><td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>7:3</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=kW>5:0</td>
<td class=br>57:40</td><td class=br>+17</td>
<td class=bc>9 - 2 - 6</td>
<td class=br><strong>20</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ma Jindrová</td><td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kW>6:1</td>
<td class=kW>2:0</td>
<td class=br>48:35</td><td class=br>+13</td>
<td class=bc>8 - 4 - 5</td>
<td class=br><strong>20</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Ha Marešová</td><td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=br>41:37</td><td class=br>+4</td>
<td class=bc>8 - 3 - 6</td>
<td class=br><strong>19</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ví Perkner</td><td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>0:9</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kL>0:2</td>
<td class=br>33:44</td><td class=br>-11</td>
<td class=bc>7 - 2 - 8</td>
<td class=br><strong>16</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Mi Horáková</td><td class=kL>1:8</td>
<td class=kL>5:7</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>8:1</td>
<td class=kW>2:1</td>
<td class=br>46:58</td><td class=br>-12</td>
<td class=bc>6 - 2 - 9</td>
<td class=br><strong>14</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>An Grimová</td><td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kW>6:2</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=br>36:55</td><td class=br>-19</td>
<td class=bc>6 - 2 - 9</td>
<td class=br><strong>14</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ma Klazar</td><td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=br>38:52</td><td class=br>-14</td>
<td class=bc>5 - 3 - 9</td>
<td class=br><strong>13</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Vo Bernát</td><td class=kL>5:8</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>3:7</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kL>0:1</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=br>51:57</td><td class=br>-6</td>
<td class=bc>6 - 0 - 11</td>
<td class=br><strong>12</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Ja Peleščák</td><td class=kL>2:6</td>
<td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>0:8</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=br>35:68</td><td class=br>-33</td>
<td class=bc>3 - 2 - 12</td>
<td class=br><strong>8</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Jo Perkner</td><td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=br>15:39</td><td class=br>-24</td>
<td class=bc>3 - 1 - 13</td>
<td class=br><strong>7</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ma Cingroš</td><td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kL>2:7</td>
<td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>19:75</td><td class=br>-56</td>
<td class=bc>1 - 1 - 15</td>
<td class=br><strong>3</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Lu Vaněk</td><td class=kL>1:5</td>
<td class=kL>3:7</td>
<td class=kL>0:9</td>
<td class=kL>1:6</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>17:62</td><td class=br>-45</td>
<td class=bc>1 - 1 - 15</td>
<td class=br><strong>3</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ví Perkner</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>Ja Peleščák</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ma Jindrová</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Ví Perkner</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Ja Peleščák</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>5 : 7</tr></td>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Jindrová</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lu Vaněk</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Ja Peleščák</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ma Jindrová</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Ja Peleščák</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Ha Marešová</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>Ma Jindrová</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Ja Peleščák</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ma Jindrová</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Pa Hráský</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Ja Peleščák</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Ma Jindrová</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Pa Hráský</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ja Peleščák</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Ma Jindrová</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Pa Hráský</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ja Peleščák</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Al Mačynský</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Ma Jindrová</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Cingroš</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Ha Marešová</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Al Mačynský</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ja Peleščák</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ma Jindrová</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ha Marešová</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Ma Jindrová</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ja Peleščák</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>8 : 5</tr></td>
<tr><td class=br>Lu Vaněk</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=bl>Ma Jindrová</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ha Marešová</td><td class=bc>-</td><td class=bl>Pa Hráský</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ja Peleščák</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Pa Hráský</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ha Marešová</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ja Peleščák</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ma Jindrová</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ha Marešová</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ja Peleščák</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Pa Hráský</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ma Jindrová</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ha Marešová</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ja Peleščák</td><td class=bc>-</td><td class=blW>Ví Perkner</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ma Jindrová</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ja Peleščák</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Ma Cingroš</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ma Jindrová</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Ha Marešová</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>Ja Peleščák</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Jindrová</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Al Mačynský</td><td class=bc>-</td><td class=bl>Ja Peleščák</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Iv Mašková</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Ma Cingroš</td><td class=bc>-</td><td class=bl>Lu Vaněk</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ví Perkner</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pa Hráský</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ma Jindrová</td><td class=bc>-</td><td class=bl>Ja Peleščák</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Al Mačynský</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
