<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR junioři</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.stolnihokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="../../pohar.aspx">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../mrj">MR junioři 5. září 2021</a></span></h2></div></div></div></div><p><div align="center">
<div align=center>
<p class=v>Group J</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Ja Matýsek</td><td class=ic>CZE</td><td class=kx>*</td>
<td class=kW>3:0 + 1:0</td>
<td class=kW>8:0 + 4:3</td>
<td class=kW>5:2 + 4:1</td>
<td class=kT>1:1 + 3:2</td>
<td class=kW>3:1 + 4:2</td>
<td class=kW>5:4 + 5:4</td>
<td class=kW>5:2 + 6:3</td>
<td class=kW>6:4 + 4:2</td>
<td class=kW>7:2 + 5:0</td>
<td class=br>79:33</td><td class=br>+46</td>
<td class=bc>17 - 1 - 0</td>
<td class=br><strong>35</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Ad Kopřiva</td><td class=ic>CZE</td><td class=kL>0:3 + 0:1</td>
<td class=kx>*</td>
<td class=kW>4:1 + 3:5</td>
<td class=kW>4:0 + 5:1</td>
<td class=kW>5:1 + 2:3</td>
<td class=kW>6:3 + 3:2</td>
<td class=kW>6:3 + 5:5</td>
<td class=kW>6:1 + 7:3</td>
<td class=kW>7:0 + 5:0</td>
<td class=kW>8:1 + 6:0</td>
<td class=br>82:33</td><td class=br>+49</td>
<td class=bc>13 - 1 - 4</td>
<td class=br><strong>27</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Vo Bernát</td><td class=ic>CZE</td><td class=kL>0:8 + 3:4</td>
<td class=kL>1:4 + 5:3</td>
<td class=kx>*</td>
<td class=kW>3:2 + 2:1</td>
<td class=kL>1:3 + 2:1</td>
<td class=kW>4:0 + 3:1</td>
<td class=kW>5:1 + 5:3</td>
<td class=kW>6:1 + 4:1</td>
<td class=kT>3:3 + 6:3</td>
<td class=kW>7:1 + 8:0</td>
<td class=br>68:40</td><td class=br>+28</td>
<td class=bc>13 - 1 - 4</td>
<td class=br><strong>27</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Ma Klazar</td><td class=ic>CZE</td><td class=kL>2:5 + 1:4</td>
<td class=kL>0:4 + 1:5</td>
<td class=kL>2:3 + 1:2</td>
<td class=kx>*</td>
<td class=kW>1:0 + 3:0</td>
<td class=kL>1:4 + 2:0</td>
<td class=kW>5:2 + 5:2</td>
<td class=kW>3:0 + 9:1</td>
<td class=kW>3:0 K + 5:0 K</td>
<td class=kW>5:1 + 7:0</td>
<td class=br>56:33</td><td class=br>+23</td>
<td class=bc>11 - 0 - 7</td>
<td class=br><strong>22</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Jo Perkner</td><td class=ic>CZE</td><td class=kT>1:1 + 2:3</td>
<td class=kL>1:5 + 3:2</td>
<td class=kW>3:1 + 1:2</td>
<td class=kL>0:1 + 0:3</td>
<td class=kx>*</td>
<td class=kL>0:2 + 2:2</td>
<td class=kW>3:1 + 2:5</td>
<td class=kW>1:0 + 4:4</td>
<td class=kW>3:1 + 2:0</td>
<td class=kW>3:2 + 2:2</td>
<td class=br>33:37</td><td class=br>-4</td>
<td class=bc>7 - 4 - 7</td>
<td class=br><strong>18</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Ví Perkner</td><td class=ic>CZE</td><td class=kL>1:3 + 2:4</td>
<td class=kL>3:6 + 2:3</td>
<td class=kL>0:4 + 1:3</td>
<td class=kW>4:1 + 0:2</td>
<td class=kW>2:0 + 2:2</td>
<td class=kx>*</td>
<td class=kL>3:5 + 5:3</td>
<td class=kT>3:3 + 5:2</td>
<td class=kW>2:1 + 6:1</td>
<td class=kW>6:1 + 2:2</td>
<td class=br>49:46</td><td class=br>+3</td>
<td class=bc>7 - 3 - 8</td>
<td class=br><strong>17</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>An Grimová</td><td class=ic>CZE</td><td class=kL>4:5 + 4:5</td>
<td class=kL>3:6 + 5:5</td>
<td class=kL>1:5 + 3:5</td>
<td class=kL>2:5 + 2:5</td>
<td class=kL>1:3 + 5:2</td>
<td class=kW>5:3 + 3:5</td>
<td class=kx>*</td>
<td class=kW>4:1 + 4:4</td>
<td class=kW>4:2 + 5:0</td>
<td class=kW>5:1 + 6:0</td>
<td class=br>66:62</td><td class=br>+4</td>
<td class=bc>7 - 2 - 9</td>
<td class=br><strong>16</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Vo Kraus</td><td class=ic>CZE</td><td class=kL>2:5 + 3:6</td>
<td class=kL>1:6 + 3:7</td>
<td class=kL>1:6 + 1:4</td>
<td class=kL>0:3 + 1:9</td>
<td class=kL>0:1 + 4:4</td>
<td class=kT>3:3 + 2:5</td>
<td class=kL>1:4 + 4:4</td>
<td class=kx>*</td>
<td class=kL>1:3 + 7:3</td>
<td class=kT>2:2 + 2:1</td>
<td class=br>38:76</td><td class=br>-38</td>
<td class=bc>2 - 4 - 12</td>
<td class=br><strong>8</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>On Čech</td><td class=ic>&nbsp;</td><td class=kL>4:6 + 2:4</td>
<td class=kL>0:7 + 0:5</td>
<td class=kT>3:3 + 3:6</td>
<td class=kL>0:3 K + 0:5 K</td>
<td class=kL>1:3 + 0:2</td>
<td class=kL>1:2 + 1:6</td>
<td class=kL>2:4 + 0:5</td>
<td class=kW>3:1 + 3:7</td>
<td class=kx>*</td>
<td class=kT>0:0 + 2:2</td>
<td class=br>25:71</td><td class=br>-46</td>
<td class=bc>1 - 3 - 14</td>
<td class=br><strong>5</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Vo Vacke</td><td class=ic>CZE</td><td class=kL>2:7 + 0:5</td>
<td class=kL>1:8 + 0:6</td>
<td class=kL>1:7 + 0:8</td>
<td class=kL>1:5 + 0:7</td>
<td class=kL>2:3 + 2:2</td>
<td class=kL>1:6 + 2:2</td>
<td class=kL>1:5 + 0:6</td>
<td class=kT>2:2 + 1:2</td>
<td class=kT>0:0 + 2:2</td>
<td class=kx>*</td>
<td class=br>18:83</td><td class=br>-65</td>
<td class=bc>0 - 5 - 13</td>
<td class=br><strong>5</strong></td><td class=d>10.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>7 : 1 + 8 : 0</tr></td>
<tr><td class=br>On Čech</td><td class=bc>-</td><td class=blW>Ví Perkner</td><td class=bc>1 : 2 + 1 : 6</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>1 : 3 + 5 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 5 + 1 : 4</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>6 : 1 + 7 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Ví Perkner</td><td class=bc>1 : 6 + 2 : 2</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>1 : 3 + 2 : 1</tr></td>
<tr><td class=br>On Čech</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>4 : 6 + 2 : 4</tr></td>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>4 : 1 + 4 : 4</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 4 + 1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 0 + 2 : 2</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 7 + 0 : 5</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>6 : 1 + 4 : 1</tr></td>
<tr><td class=br>On Čech</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 7 + 0 : 5</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 5 + 2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>1 : 1 + 2 : 3</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>3 : 3 + 5 : 2</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>1 : 8 + 0 : 6</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 2 + 2 : 1</tr></td>
<tr><td class=br>On Čech</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>2 : 4 + 0 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>5 : 2 + 6 : 3</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>1 : 5 + 3 : 2</tr></td>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>4 : 1 + 0 : 2</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>1 : 5 + 0 : 6</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=bl>On Čech</td><td class=bc>3 : 3 + 6 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>0 : 3 + 1 : 9</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>5 : 4 + 5 : 4</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>On Čech</td><td class=bc>3 : 1 + 2 : 0</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>0 : 4 + 1 : 3</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>6 : 3 + 5 : 5</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>On Čech</td><td class=bc>1 : 3 + 7 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>8 : 0 + 4 : 3</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>3 : 2 + 2 : 2</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>On Čech</td><td class=bc>3 : 0 K + 5 : 0 K</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>4 : 1 + 3 : 5</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>2 : 2 + 2 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>3 : 1 + 4 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Vo Bernát</td><td class=bc>1 : 5 + 3 : 5</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>5 : 1 + 7 : 0</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>6 : 3 + 3 : 2</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>0 : 1 + 4 : 4</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>On Čech</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>0 : 0 + 2 : 2</tr></td>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>5 : 3 + 3 : 5</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>1 : 0 + 3 : 0</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 3 + 0 : 1</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
