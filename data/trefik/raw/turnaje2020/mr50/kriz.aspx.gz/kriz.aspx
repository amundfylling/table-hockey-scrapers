<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR 55+</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.stolnihokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="../../pohar.aspx">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../mr50">MR 55+ 5. září 2021</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p><a href="#basic">Základní skupiny (Basic groups)</a><br>
<a href="#final">Výkonnostní skupiny (Final groups)</a><br>
<a name="basic"><p class=vm>Základní skupiny (Basic groups)</p></a>
<p class=v>Group 50+</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Pa Plešák</td><td class=ic>CZE</td><td class=kx>*</td>
<td class=kL>2:4 + 4:0</td>
<td class=kW>4:3 + 4:0</td>
<td class=kW>6:1 + 6:1</td>
<td class=kW>3:1 + 7:2</td>
<td class=kW>3:0 + 2:1</td>
<td class=br>41:13</td><td class=br>+28</td>
<td class=bc>9 - 0 - 1</td>
<td class=br><strong>18</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Vá Pikl</td><td class=ic>CZE</td><td class=kW>4:2 + 0:4</td>
<td class=kx>*</td>
<td class=kW>7:1 + 1:0</td>
<td class=kW>8:1 + 4:2</td>
<td class=kW>2:0 + 7:2</td>
<td class=kW>8:0 + 8:3</td>
<td class=br>49:15</td><td class=br>+34</td>
<td class=bc>9 - 0 - 1</td>
<td class=br><strong>18</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Fr Marek</td><td class=ic>CZE</td><td class=kL>3:4 + 0:4</td>
<td class=kL>1:7 + 0:1</td>
<td class=kx>*</td>
<td class=kW>6:3 + 1:4</td>
<td class=kL>2:4 + 5:1</td>
<td class=kW>4:2 + 2:0</td>
<td class=br>24:30</td><td class=br>-6</td>
<td class=bc>4 - 0 - 6</td>
<td class=br><strong>8</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Jo Gruncl</td><td class=ic>CZE</td><td class=kL>1:6 + 1:6</td>
<td class=kL>1:8 + 2:4</td>
<td class=kL>3:6 + 4:1</td>
<td class=kx>*</td>
<td class=kL>2:4 + 5:3</td>
<td class=kT>1:1 + 5:0</td>
<td class=br>25:39</td><td class=br>-14</td>
<td class=bc>3 - 1 - 6</td>
<td class=br><strong>7</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Mi Mareš st.</td><td class=ic>CZE</td><td class=kL>1:3 + 2:7</td>
<td class=kL>0:2 + 2:7</td>
<td class=kW>4:2 + 1:5</td>
<td class=kW>4:2 + 3:5</td>
<td class=kx>*</td>
<td class=kL>1:2 + 2:2</td>
<td class=br>20:37</td><td class=br>-17</td>
<td class=bc>2 - 1 - 7</td>
<td class=br><strong>5</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Ra Hrnčíř</td><td class=ic>CZE</td><td class=kL>0:3 + 1:2</td>
<td class=kL>0:8 + 3:8</td>
<td class=kL>2:4 + 0:2</td>
<td class=kT>1:1 + 0:5</td>
<td class=kW>2:1 + 2:2</td>
<td class=kx>*</td>
<td class=br>11:36</td><td class=br>-25</td>
<td class=bc>1 - 2 - 7</td>
<td class=br><strong>4</strong></td><td class=d>6.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 6 + 1 : 6</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 8 + 3 : 8</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Mi Mareš st.</td><td class=bc>2 : 4 + 5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>1 : 1 + 5 : 0</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>7 : 1 + 1 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>3 : 1 + 7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 3 + 1 : 2</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>6 : 3 + 1 : 4</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 2 + 2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>2 : 4 + 0 : 2</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Mi Mareš st.</td><td class=bc>2 : 4 + 5 : 3</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 4 + 4 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>3 : 4 + 0 : 4</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>1 : 2 + 2 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>8 : 1 + 4 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
