<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR družstva</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.stolnihokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="../../pohar.aspx">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>MR družstva 4. září 2021</span></h2></div></div></div></div><p><div align="center">
<div align=center>
<a href="kriz.aspx">Zápasy ve skupinách (Basic and placement groups)</a><br>
<a href="MR_druzstva_umisteni.aspx ">Zápasy o umístění (Placement matches)</a><br>
<a href="MR_druzstva_players.aspx">Bilance hráčů</a><br>
<a href="utokturnaje.aspx">Tabulka útočníků (Best forwards)</a><br>
<a href="obranaturnaje.aspx">Tabulka obránců (Best defenders)</a><br>
</div>
<table border=0 cellpadding=2 cellspacing=0 class="rnk">
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">Z</th>
<th align="center">+</th>
<th align="center">=</th>
<th align="center">-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al>THC Stiga-Game Příbram</td>
<td class=al>&nbsp;</td>
<td class=ar>18</td>
<td class=ar>9</td>
<td class=ar>9</td>
<td class=ar>0</td>
<td class=ar>139</td>
<td class=al>&nbsp;:&nbsp;31</td>
</tr><tr><td class=br>2.</td>
<td class=bl>Žabka Praha</td>
<td class=bl>&nbsp;</td>
<td class=br>18</td>
<td class=br>8</td>
<td class=br>9</td>
<td class=br>1</td>
<td class=br>136</td>
<td class=bl>&nbsp;:&nbsp;39</td>
</tr><tr><td class=ar>3.</td>
<td class=al>Big Band "A"</td>
<td class=al>&nbsp;</td>
<td class=ar>18</td>
<td class=ar>7</td>
<td class=ar>9</td>
<td class=ar>2</td>
<td class=ar>112</td>
<td class=al>&nbsp;:&nbsp;51</td>
</tr><tr><td class=br>4.</td>
<td class=bl>Stiga HC Benátky</td>
<td class=bl>&nbsp;</td>
<td class=br>18</td>
<td class=br>5</td>
<td class=br>10</td>
<td class=br>3</td>
<td class=br>104</td>
<td class=bl>&nbsp;:&nbsp;68</td>
</tr><tr><td class=ar>5.</td>
<td class=al>SHC Cheb "A"</td>
<td class=al>&nbsp;</td>
<td class=ar>18</td>
<td class=ar>6</td>
<td class=ar>10</td>
<td class=ar>2</td>
<td class=ar>102</td>
<td class=al>&nbsp;:&nbsp;75</td>
</tr><tr><td class=br>6.</td>
<td class=bl>THC Třinec</td>
<td class=bl>&nbsp;</td>
<td class=br>18</td>
<td class=br>4</td>
<td class=br>10</td>
<td class=br>4</td>
<td class=br>108</td>
<td class=bl>&nbsp;:&nbsp;74</td>
</tr><tr><td class=ar>7.</td>
<td class=al>Gladiators Plzeň</td>
<td class=al>&nbsp;</td>
<td class=ar>18</td>
<td class=ar>4</td>
<td class=ar>9</td>
<td class=ar>5</td>
<td class=ar>89</td>
<td class=al>&nbsp;:&nbsp;86</td>
</tr><tr><td class=br>8.</td>
<td class=bl>BSE United "A"</td>
<td class=bl>&nbsp;</td>
<td class=br>18</td>
<td class=br>3</td>
<td class=br>10</td>
<td class=br>5</td>
<td class=br>97</td>
<td class=bl>&nbsp;:&nbsp;70</td>
</tr><tr><td class=ar>9.</td>
<td class=al>SHC Cheb "B"</td>
<td class=al>&nbsp;</td>
<td class=ar>14</td>
<td class=ar>3</td>
<td class=ar>7</td>
<td class=ar>4</td>
<td class=ar>59</td>
<td class=al>&nbsp;:&nbsp;83</td>
</tr><tr><td class=br>10.</td>
<td class=bl>BSE United "B"</td>
<td class=bl>&nbsp;</td>
<td class=br>14</td>
<td class=br>2</td>
<td class=br>7</td>
<td class=br>5</td>
<td class=br>65</td>
<td class=bl>&nbsp;:&nbsp;74</td>
</tr><tr><td class=ar>11.</td>
<td class=al>Big Band "B"</td>
<td class=al>&nbsp;</td>
<td class=ar>14</td>
<td class=ar>2</td>
<td class=ar>7</td>
<td class=ar>5</td>
<td class=ar>50</td>
<td class=al>&nbsp;:&nbsp;83</td>
</tr><tr><td class=br>12.</td>
<td class=bl>Javorové listy Teplýšovice</td>
<td class=bl>&nbsp;</td>
<td class=br>14</td>
<td class=br>1</td>
<td class=br>7</td>
<td class=br>6</td>
<td class=br>33</td>
<td class=bl>&nbsp;:&nbsp;116</td>
</tr><tr><td class=ar>13.</td>
<td class=al>BSE United "C"</td>
<td class=al>&nbsp;</td>
<td class=ar>14</td>
<td class=ar>1</td>
<td class=ar>7</td>
<td class=ar>6</td>
<td class=ar>17</td>
<td class=al>&nbsp;:&nbsp;126</td>
</tr><tr><td class=br>14.</td>
<td class=bl>BSE United "ZŠ Želiv"</td>
<td class=bl>&nbsp;</td>
<td class=br>14</td>
<td class=br>0</td>
<td class=br>7</td>
<td class=br>7</td>
<td class=br>9</td>
<td class=bl>&nbsp;:&nbsp;144</td>
</tr></table></td></tr></table></div></p>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
