<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Třinec</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../trinec">Třinec 19. březen 2022</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p><a href="#basic">Základní skupiny (Basic groups)</a><br>
<a href="#final">Výkonnostní skupiny (Final groups)</a><br>
<a name="basic"><p class=vm>Základní skupiny (Basic groups)</p></a>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>25</td>
<td class=ic>26</td>
<td class=ic>27</td>
<td class=ic>28</td>
<td class=ic>29</td>
<td class=ic>30</td>
<td class=ic>31</td>
<td class=ic>32</td>
<td class=ic>33</td>
<td class=ic>34</td>
<td class=ic>35</td>
<td class=ic>36</td>
<td class=ic>37</td>
<td class=ic>38</td>
<td class=ic>39</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Mi Kobrle</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kL>5:8</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>9:3</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>7:5</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kT>4:4</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>6:3</td>
<td class=kW>10:1</td>
<td class=kW>5:3</td>
<td class=kW>7:1</td>
<td class=kW>5:3</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=kW>8:1</td>
<td class=kW>9:0</td>
<td class=kW>8:1</td>
<td class=kW>15:0</td>
<td class=kW>7:1</td>
<td class=kW>8:0</td>
<td class=br>210:67</td><td class=br>+143</td>
<td class=bc>31 - 6 - 1</td>
<td class=br><strong>68</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Pa Petr</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>4:8</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kW>7:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>5:3</td>
<td class=kW>8:3</td>
<td class=kW>6:3</td>
<td class=kW>7:2</td>
<td class=kW>7:2</td>
<td class=kW>3:0</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>9:3</td>
<td class=kW>7:2</td>
<td class=kW>7:3</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>10:2</td>
<td class=kW>6:0</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=kW>12:0</td>
<td class=br>197:69</td><td class=br>+128</td>
<td class=bc>32 - 2 - 4</td>
<td class=br><strong>66</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Ho Sládek</td><td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kW>9:1</td>
<td class=kW>8:0</td>
<td class=kW>5:1</td>
<td class=br>134:61</td><td class=br>+73</td>
<td class=bc>29 - 6 - 3</td>
<td class=br><strong>64</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Ji Chylík ml.</td><td class=kW>8:5</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>7:1</td>
<td class=kL>2:6</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=kW>1:0</td>
<td class=kT>0:0</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kL>0:2</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kW>8:3</td>
<td class=kW>6:0</td>
<td class=kW>7:0</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=br>164:53</td><td class=br>+111</td>
<td class=bc>29 - 4 - 5</td>
<td class=br><strong>62</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=d>5.</td><td class=kt>Ma Maděra</td><td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>5:1</td>
<td class=kL>0:5</td>
<td class=kT>0:0</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kL>0:1</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>6:3</td>
<td class=kW>6:0</td>
<td class=kW>8:3</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>8:0</td>
<td class=kW>11:1</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>8:1</td>
<td class=kW>8:1</td>
<td class=br>168:62</td><td class=br>+106</td>
<td class=bc>28 - 6 - 4</td>
<td class=br><strong>62</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=d>6.</td><td class=kt>Lu Turoň</td><td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>7:3</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=kW>8:1</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=br>144:57</td><td class=br>+87</td>
<td class=bc>27 - 6 - 5</td>
<td class=br><strong>60</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/4</td><td class=d>7.</td><td class=kt>Pe Turoň</td><td class=kL>0:3</td>
<td class=kW>8:4</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=kW>4:0</td>
<td class=kW>6:5</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kT>5:5</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>7:3</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>11:1</td>
<td class=kW>6:0</td>
<td class=kW>8:0</td>
<td class=kW>5:0</td>
<td class=kW>8:2</td>
<td class=kW>4:1</td>
<td class=br>158:84</td><td class=br>+74</td>
<td class=bc>26 - 5 - 7</td>
<td class=br><strong>57</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/4</td><td class=d>8.</td><td class=kt>Pa Plešák</td><td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>3:6</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kL>3:6</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>8:6</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kW>7:1</td>
<td class=kT>4:4</td>
<td class=kW>7:3</td>
<td class=kW>5:0</td>
<td class=kW>9:1</td>
<td class=kW>4:0</td>
<td class=kW>11:0</td>
<td class=br>168:84</td><td class=br>+84</td>
<td class=bc>26 - 4 - 8</td>
<td class=br><strong>56</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Mi Černoch</td><td class=kL>3:5</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kT>0:0</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kL>3:4</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>11:0</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>8:2</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>7:0</td>
<td class=kW>8:1</td>
<td class=kW>12:0</td>
<td class=br>137:57</td><td class=br>+80</td>
<td class=bc>24 - 6 - 8</td>
<td class=br><strong>54</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Lu Kahoun</td><td class=kL>3:9</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>6:3</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kL>4:6</td>
<td class=kL>4:5</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kT>0:0</td>
<td class=kL>4:6</td>
<td class=kW>10:3</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=br>134:103</td><td class=br>+31</td>
<td class=bc>23 - 4 - 11</td>
<td class=br><strong>50</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Vá Pikl</td><td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>0:0</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>6:3</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kW>1:0</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>9:0</td>
<td class=kW>10:0</td>
<td class=kW>9:0</td>
<td class=br>132:71</td><td class=br>+61</td>
<td class=bc>21 - 7 - 10</td>
<td class=br><strong>49</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Kr Lebl</td><td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>5:5</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>2:8</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=br>121:80</td><td class=br>+41</td>
<td class=bc>20 - 8 - 10</td>
<td class=br><strong>48</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>To Bucek</td><td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>0:6</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kL>2:5</td>
<td class=kW>5:3</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>6:5</td>
<td class=kW>6:0</td>
<td class=kW>6:4</td>
<td class=kW>8:1</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=br>114:98</td><td class=br>+16</td>
<td class=bc>21 - 2 - 15</td>
<td class=br><strong>44</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Ma Ženíšek</td><td class=kL>2:5</td>
<td class=kL>3:8</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kW>3:0</td>
<td class=kW>6:3</td>
<td class=kW>2:0</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>6:3</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kW>6:1</td>
<td class=kW>6:4</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=br>129:101</td><td class=br>+28</td>
<td class=bc>21 - 2 - 15</td>
<td class=br><strong>44</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Kr Herold</td><td class=kL>3:4</td>
<td class=kL>3:6</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>1:7</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=br>105:83</td><td class=br>+22</td>
<td class=bc>19 - 5 - 14</td>
<td class=br><strong>43</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>To Waclawek</td><td class=kL>5:7</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kW>6:4</td>
<td class=kL>3:6</td>
<td class=kT>5:5</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=kW>6:2</td>
<td class=kW>11:0</td>
<td class=kW>6:0</td>
<td class=br>141:105</td><td class=br>+36</td>
<td class=bc>20 - 3 - 15</td>
<td class=br><strong>43</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ja Cienciala</td><td class=kL>3:6</td>
<td class=kL>2:7</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>0:4</td>
<td class=kW>1:0</td>
<td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kW>4:3</td>
<td class=kW>5:4</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kW>8:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>4:6</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>7:1</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kW>6:5</td>
<td class=kW>8:1</td>
<td class=kW>7:0</td>
<td class=br>130:106</td><td class=br>+24</td>
<td class=bc>19 - 4 - 15</td>
<td class=br><strong>42</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Mi Blažek</td><td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kW>6:3</td>
<td class=kL>0:4</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>6:3</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=br>107:92</td><td class=br>+15</td>
<td class=bc>19 - 4 - 15</td>
<td class=br><strong>42</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Al Krejza</td><td class=kL>0:4</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kL>0:8</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>8:2</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>6:4</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=br>99:99</td><td class=br>0</td>
<td class=bc>19 - 3 - 16</td>
<td class=br><strong>41</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Mi Ševr</td><td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>7:4</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>9:0</td>
<td class=br>109:99</td><td class=br>+10</td>
<td class=bc>18 - 4 - 16</td>
<td class=br><strong>40</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Zd Lopaur</td><td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>2:7</td>
<td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kW>3:2</td>
<td class=kL>0:11</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>3:6</td>
<td class=kW>3:0</td>
<td class=kW>6:5</td>
<td class=kT>1:1</td>
<td class=kW>7:5</td>
<td class=kW>6:4</td>
<td class=kL>1:8</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kL>5:6</td>
<td class=kW>6:0</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>9:0</td>
<td class=kT>3:3</td>
<td class=kW>9:0</td>
<td class=kW>9:0</td>
<td class=br>133:125</td><td class=br>+8</td>
<td class=bc>18 - 4 - 16</td>
<td class=br><strong>40</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Ad Kopřiva</td><td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kL>3:6</td>
<td class=kL>3:7</td>
<td class=kW>4:1</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>6:4</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>9:0</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=br>111:102</td><td class=br>+9</td>
<td class=bc>17 - 5 - 16</td>
<td class=br><strong>39</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Ji Cibulka</td><td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>5:6</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>2:8</td>
<td class=kW>6:0</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kT>4:4</td>
<td class=kW>6:2</td>
<td class=br>109:98</td><td class=br>+11</td>
<td class=bc>17 - 5 - 16</td>
<td class=br><strong>39</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Ro Jež</td><td class=kL>0:5</td>
<td class=kL>0:7</td>
<td class=kT>4:4</td>
<td class=kT>0:0</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kL>0:3</td>
<td class=kL>4:6</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>0:4</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>2:0</td>
<td class=br>93:95</td><td class=br>-2</td>
<td class=bc>15 - 8 - 15</td>
<td class=br><strong>38</strong></td><td class=d>24.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>25.</td><td class=kt>Da Cibulka</td><td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>6:8</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>5:6</td>
<td class=kT>3:3</td>
<td class=kW>8:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>7:1</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kT>5:5</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>8:1</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=br>118:110</td><td class=br>+8</td>
<td class=bc>13 - 9 - 16</td>
<td class=br><strong>35</strong></td><td class=d>25.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>26.</td><td class=kt>Jo Malý</td><td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>3:6</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kT>0:0</td>
<td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kW>4:0</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>9:0</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kW>2:0</td>
<td class=br>88:110</td><td class=br>-22</td>
<td class=bc>13 - 4 - 21</td>
<td class=br><strong>30</strong></td><td class=d>26.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>27.</td><td class=kt>Ma Klazar</td><td class=kL>3:6</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kL>0:6</td>
<td class=kL>3:7</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kW>6:4</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>3:6</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kL>5:7</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>8:1</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=br>110:131</td><td class=br>-21</td>
<td class=bc>13 - 4 - 21</td>
<td class=br><strong>30</strong></td><td class=d>27.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>28.</td><td class=kt>Ro Pavlica</td><td class=kL>1:10</td>
<td class=kL>3:9</td>
<td class=kL>2:7</td>
<td class=kT>3:3</td>
<td class=kL>3:8</td>
<td class=kL>0:3</td>
<td class=kT>5:5</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>3:10</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kL>4:7</td>
<td class=kL>4:6</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kW>7:2</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=br>104:141</td><td class=br>-37</td>
<td class=bc>11 - 6 - 21</td>
<td class=br><strong>28</strong></td><td class=d>28.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>29.</td><td class=kt>To Kahoun ml.</td><td class=kL>3:5</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>8:1</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kT>1:1</td>
<td class=kW>7:4</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=br>95:116</td><td class=br>-21</td>
<td class=bc>12 - 4 - 22</td>
<td class=br><strong>28</strong></td><td class=d>29.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>30.</td><td class=kt>Ma Košňar</td><td class=kL>1:7</td>
<td class=kL>3:7</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kW>6:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>5:5</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=br>90:138</td><td class=br>-48</td>
<td class=bc>11 - 4 - 23</td>
<td class=br><strong>26</strong></td><td class=d>30.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>31.</td><td class=kt>Hy Nechutný</td><td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kL>0:1</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>3:7</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=br>76:104</td><td class=br>-28</td>
<td class=bc>9 - 8 - 21</td>
<td class=br><strong>26</strong></td><td class=d>31.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>32.</td><td class=kt>To Halama</td><td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>3:4</td>
<td class=kL>0:6</td>
<td class=kL>2:6</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>6:5</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>1:8</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>9:1</td>
<td class=br>82:140</td><td class=br>-58</td>
<td class=bc>10 - 3 - 25</td>
<td class=br><strong>23</strong></td><td class=d>32.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>33.</td><td class=kt>Jo Perkner</td><td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kL>0:1</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>0:7</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>8:2</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=br>66:128</td><td class=br>-62</td>
<td class=bc>11 - 0 - 27</td>
<td class=br><strong>22</strong></td><td class=d>33.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>34.</td><td class=kt>Er Bernhauser</td><td class=kL>1:8</td>
<td class=kL>2:10</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kL>0:7</td>
<td class=kL>1:11</td>
<td class=kT>4:4</td>
<td class=kL>2:8</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>2:7</td>
<td class=kL>5:6</td>
<td class=kL>4:6</td>
<td class=kL>1:3</td>
<td class=kL>1:7</td>
<td class=kL>1:7</td>
<td class=kT>4:4</td>
<td class=kL>4:6</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>7:4</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=br>81:189</td><td class=br>-108</td>
<td class=bc>6 - 2 - 30</td>
<td class=br><strong>14</strong></td><td class=d>34.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>35.</td><td class=kt>Ra Hrnčíř</td><td class=kL>0:9</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>3:8</td>
<td class=kL>1:11</td>
<td class=kL>1:8</td>
<td class=kL>0:6</td>
<td class=kL>3:7</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:7</td>
<td class=kL>0:9</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=br>54:191</td><td class=br>-137</td>
<td class=bc>3 - 4 - 31</td>
<td class=br><strong>10</strong></td><td class=d>35.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>36.</td><td class=kt>An Grimová</td><td class=kL>1:8</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>0:6</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>4:6</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>0:8</td>
<td class=kL>2:7</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kL>0:9</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:8</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>2:8</td>
<td class=kL>4:7</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=br>64:181</td><td class=br>-117</td>
<td class=bc>3 - 3 - 32</td>
<td class=br><strong>9</strong></td><td class=d>36.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>37.</td><td class=kt>Da Hejnoch</td><td class=kL>0:15</td>
<td class=kL>0:5</td>
<td class=kL>1:9</td>
<td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kL>1:9</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>0:9</td>
<td class=kL>0:4</td>
<td class=kL>1:8</td>
<td class=kL>0:3</td>
<td class=kL>0:7</td>
<td class=kL>2:6</td>
<td class=kL>5:6</td>
<td class=kL>3:6</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>0:9</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>1:7</td>
<td class=kL>4:7</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=br>54:207</td><td class=br>-153</td>
<td class=bc>2 - 3 - 33</td>
<td class=br><strong>7</strong></td><td class=d>37.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>38.</td><td class=kt>Mi Krejza</td><td class=kL>1:7</td>
<td class=kL>1:7</td>
<td class=kL>0:8</td>
<td class=kL>1:6</td>
<td class=kL>1:8</td>
<td class=kL>0:3</td>
<td class=kL>2:8</td>
<td class=kL>0:4</td>
<td class=kL>1:8</td>
<td class=kL>1:2</td>
<td class=kL>0:10</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:11</td>
<td class=kL>1:8</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kL>0:9</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>28:203</td><td class=br>-175</td>
<td class=bc>1 - 1 - 36</td>
<td class=br><strong>3</strong></td><td class=d>38.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>39.</td><td class=kt>An Nowaková</td><td class=kL>0:8</td>
<td class=kL>0:12</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:11</td>
<td class=kL>0:12</td>
<td class=kL>1:6</td>
<td class=kL>0:9</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>0:9</td>
<td class=kL>0:9</td>
<td class=kL>0:7</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>1:9</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>21:238</td><td class=br>-217</td>
<td class=bc>0 - 0 - 38</td>
<td class=br><strong>0</strong></td><td class=d>39.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>An Nowaková</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ro Pavlica</td><td class=bc>-</td><td class=bl>Ji Cibulka</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ja Cienciala</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>An Nowaková</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pe Turoň</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Ji Cibulka</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ro Pavlica</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Lu Turoň</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ja Cienciala</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Hejnoch</td><td class=bc>-</td><td class=bl>An Nowaková</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ji Cibulka</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ro Pavlica</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Lu Turoň</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>An Nowaková</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pe Turoň</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ji Cibulka</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>11 : 0</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Pavlica</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Ja Cienciala</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>An Nowaková</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Ji Cibulka</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Pavlica</td><td class=bc>-</td><td class=blW>Ja Cienciala</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Nowaková</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>1 : 11</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=bl>Ji Cibulka</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pe Turoň</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>5 : 7</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>Ja Cienciala</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ro Pavlica</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>An Nowaková</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 12</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ji Cibulka</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ja Cienciala</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Lu Turoň</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>An Nowaková</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 12</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Ji Cibulka</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ja Cienciala</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=bl>Lu Turoň</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Er Bernhauser</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>Ro Pavlica</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>An Nowaková</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ji Cibulka</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Ja Cienciala</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ro Pavlica</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ji Cibulka</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>An Nowaková</td><td class=bc>-</td><td class=blW>Mi Krejza</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Ja Cienciala</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>11 : 1</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ro Pavlica</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>1 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ji Cibulka</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>An Nowaková</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ja Cienciala</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pe Turoň</td><td class=bc>-</td><td class=bl>Ro Pavlica</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ji Cibulka</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>An Nowaková</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Ja Cienciala</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Er Bernhauser</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Ro Pavlica</td><td class=bc>10 : 3</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>9 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Ji Cibulka</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>An Nowaková</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ja Cienciala</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Lu Turoň</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Er Bernhauser</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Ro Pavlica</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ji Cibulka</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>8 : 5</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Ja Cienciala</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>An Nowaková</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Ro Pavlica</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ji Cibulka</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ja Cienciala</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>An Nowaková</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ro Pavlica</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ji Cibulka</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ja Cienciala</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ro Pavlica</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>An Nowaková</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Pe Turoň</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ji Cibulka</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ja Cienciala</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>10 : 2</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ro Pavlica</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>An Nowaková</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ji Cibulka</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ja Cienciala</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ro Pavlica</td><td class=bc>9 : 3</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>An Nowaková</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Ja Cienciala</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ji Cibulka</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ro Pavlica</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>5 : 7</tr></td>
<tr><td class=br>An Nowaková</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ja Cienciala</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Lu Turoň</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Er Bernhauser</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ji Cibulka</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ro Pavlica</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Nowaková</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Da Hejnoch</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ja Cienciala</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Ro Pavlica</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ji Cibulka</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>An Nowaková</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ja Cienciala</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ro Pavlica</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ji Cibulka</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>11 : 0</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>4 : 8</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>An Nowaková</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>9 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=brW>Ja Cienciala</td><td class=bc>-</td><td class=bl>Lu Turoň</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ro Pavlica</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ji Cibulka</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Pe Turoň</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>An Nowaková</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 11</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ja Cienciala</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ro Pavlica</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Ji Cibulka</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Pe Turoň</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Ro Pavlica</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ja Cienciala</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Ji Cibulka</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>An Nowaková</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>26</td></tr>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ro Pavlica</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ja Cienciala</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ji Cibulka</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>An Nowaková</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>27</td></tr>
<tr><td class=br>Ro Pavlica</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ja Cienciala</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Pe Turoň</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ji Cibulka</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>An Nowaková</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>28</td></tr>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Pavlica</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ja Cienciala</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>9 : 3</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Da Hejnoch</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ji Cibulka</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>An Nowaková</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>29</td></tr>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ro Pavlica</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Lu Turoň</td><td class=bc>-</td><td class=bl>Pe Turoň</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ja Cienciala</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Ji Cibulka</td><td class=bc>-</td><td class=bl>An Nowaková</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>30</td></tr>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ro Pavlica</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Pe Turoň</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ja Cienciala</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>15 : 0</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>An Nowaková</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ji Cibulka</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>31</td></tr>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ro Pavlica</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Ja Cienciala</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>An Nowaková</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ji Cibulka</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>8 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>32</td></tr>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Pe Turoň</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ro Pavlica</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ja Cienciala</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>An Nowaková</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ji Cibulka</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>33</td></tr>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ro Pavlica</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Lu Turoň</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ja Cienciala</td><td class=bc>-</td><td class=bl>An Nowaková</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ji Cibulka</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>34</td></tr>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ro Pavlica</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Er Bernhauser</td><td class=bc>-</td><td class=bl>An Nowaková</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ja Cienciala</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>35</td></tr>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>6 : 8</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ro Pavlica</td><td class=bc>-</td><td class=bl>An Nowaková</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ja Cienciala</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ji Cibulka</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>36</td></tr>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>An Nowaková</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Pavlica</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Lu Turoň</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Cienciala</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ji Cibulka</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>37</td></tr>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pe Turoň</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>An Nowaková</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ro Pavlica</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ja Cienciala</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ji Cibulka</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>38</td></tr>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>An Nowaková</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ro Pavlica</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Lu Turoň</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ja Cienciala</td><td class=bc>-</td><td class=bl>Ji Cibulka</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>39</td></tr>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Da Hejnoch</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>An Nowaková</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ro Pavlica</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Er Bernhauser</td><td class=bc>-</td><td class=bl>Ji Cibulka</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ja Cienciala</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>4 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<hr><a name="final"><p class=vm>Výkonnostní skupiny (Final groups)</p></a>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
