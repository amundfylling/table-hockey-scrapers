<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Třinec</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../trinec2">Třinec 9. duben 2022</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p><a href="#basic">Základní skupiny (Basic groups)</a><br>
<a href="#final">Výkonnostní skupiny (Final groups)</a><br>
<a name="basic"><p class=vm>Základní skupiny (Basic groups)</p></a>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>25</td>
<td class=ic>26</td>
<td class=ic>27</td>
<td class=ic>28</td>
<td class=ic>29</td>
<td class=ic>30</td>
<td class=ic>31</td>
<td class=ic>32</td>
<td class=ic>33</td>
<td class=ic>34</td>
<td class=ic>35</td>
<td class=ic>36</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Lu Turoň</td><td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kW>8:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kW>8:1</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>6:4</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>7:0</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>8:2</td>
<td class=kW>8:2</td>
<td class=kW>8:1</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kW>9:1</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>8:2</td>
<td class=kW>5:0</td>
<td class=br>171:57</td><td class=br>+114</td>
<td class=bc>29 - 3 - 3</td>
<td class=br><strong>61</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Mi Kobrle</td><td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>7:4</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kT>4:4</td>
<td class=kW>7:3</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>8:2</td>
<td class=kW>8:1</td>
<td class=kW>6:1</td>
<td class=kW>8:2</td>
<td class=kW>9:1</td>
<td class=kW>7:0</td>
<td class=kW>9:1</td>
<td class=kW>7:0</td>
<td class=kW>9:2</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>9:2</td>
<td class=kW>7:1</td>
<td class=kW>9:1</td>
<td class=kW>8:2</td>
<td class=br>199:63</td><td class=br>+136</td>
<td class=bc>27 - 6 - 2</td>
<td class=br><strong>60</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Ji Chylík ml.</td><td class=kL>1:2</td>
<td class=kL>4:7</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>6:3</td>
<td class=kL>3:5</td>
<td class=kW>3:0</td>
<td class=kW>6:4</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>7:3</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>9:2</td>
<td class=kW>4:0</td>
<td class=br>147:61</td><td class=br>+86</td>
<td class=bc>28 - 4 - 3</td>
<td class=br><strong>60</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>To Waclawek</td><td class=kL>3:8</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kL>0:3</td>
<td class=kW>5:4</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>9:1</td>
<td class=br>136:67</td><td class=br>+69</td>
<td class=bc>27 - 2 - 6</td>
<td class=br><strong>56</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=d>5.</td><td class=kt>Ja Matýsek</td><td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kW>7:3</td>
<td class=kW>7:1</td>
<td class=kL>3:4</td>
<td class=kT>5:5</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>8:2</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=br>161:79</td><td class=br>+82</td>
<td class=bc>26 - 4 - 5</td>
<td class=br><strong>56</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=d>6.</td><td class=kt>Pe Turoň</td><td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:4</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>6:3</td>
<td class=kW>5:4</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>8:1</td>
<td class=kW>8:4</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>8:2</td>
<td class=kW>5:1</td>
<td class=kW>7:5</td>
<td class=kT>2:2</td>
<td class=kW>10:0</td>
<td class=kW>7:0</td>
<td class=kW>10:1</td>
<td class=kW>7:0</td>
<td class=br>166:70</td><td class=br>+96</td>
<td class=bc>24 - 7 - 4</td>
<td class=br><strong>55</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/4</td><td class=d>7.</td><td class=kt>Mi Černoch</td><td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>10:0</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kW>6:0</td>
<td class=kW>6:2</td>
<td class=kW>5:0 K</td>
<td class=kW>2:0</td>
<td class=kW>10:2</td>
<td class=kW>8:1</td>
<td class=kW>7:0</td>
<td class=br>118:43</td><td class=br>+75</td>
<td class=bc>24 - 6 - 5</td>
<td class=br><strong>54</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/4</td><td class=d>8.</td><td class=kt>Kr Lebl</td><td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kT>0:0</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>6:3</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kT>5:5</td>
<td class=kL>1:2</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kW>6:4</td>
<td class=kL>4:5</td>
<td class=kW>7:0</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=kW>7:2</td>
<td class=kT>2:2</td>
<td class=kW>9:1</td>
<td class=kW>5:0</td>
<td class=kW>7:2</td>
<td class=kW>3:0</td>
<td class=br>126:73</td><td class=br>+53</td>
<td class=bc>22 - 6 - 7</td>
<td class=br><strong>50</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Kr Herold</td><td class=kW>5:0</td>
<td class=kL>0:5</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>9:1</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>7:2</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=kW>3:0</td>
<td class=br>118:62</td><td class=br>+56</td>
<td class=bc>21 - 7 - 7</td>
<td class=br><strong>49</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ma Ženíšek</td><td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kL>4:6</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kL>3:9</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=br>121:78</td><td class=br>+43</td>
<td class=bc>22 - 4 - 9</td>
<td class=br><strong>48</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Da Matýsek</td><td class=kL>1:8</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kW>5:2</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kW>7:2</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=br>113:64</td><td class=br>+49</td>
<td class=bc>21 - 6 - 8</td>
<td class=br><strong>48</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>To Bucek</td><td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>9:3</td>
<td class=kW>8:2</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=kW>8:0</td>
<td class=br>115:75</td><td class=br>+40</td>
<td class=bc>22 - 4 - 9</td>
<td class=br><strong>48</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Mi Ševr</td><td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kW>6:2</td>
<td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kL>3:6</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>8:0</td>
<td class=kW>5:4</td>
<td class=kW>6:5</td>
<td class=kW>8:1</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>9:0</td>
<td class=br>141:80</td><td class=br>+61</td>
<td class=bc>22 - 4 - 9</td>
<td class=br><strong>48</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Ad Kopřiva</td><td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>6:4</td>
<td class=kL>0:4</td>
<td class=kW>5:1</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>8:3</td>
<td class=kT>4:4</td>
<td class=kW>6:0</td>
<td class=kW>3:0</td>
<td class=kW>7:2</td>
<td class=kW>5:0 K</td>
<td class=kW>7:3</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>8:1</td>
<td class=kW>9:2</td>
<td class=br>135:85</td><td class=br>+50</td>
<td class=bc>20 - 7 - 8</td>
<td class=br><strong>47</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Vá Pikl</td><td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>7:2</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>6:4</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>5:0 K</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>9:0</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=kW>11:0</td>
<td class=br>127:76</td><td class=br>+51</td>
<td class=bc>21 - 1 - 13</td>
<td class=br><strong>43</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Lu Kahoun</td><td class=kL>4:6</td>
<td class=kT>4:4</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>3:7</td>
<td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>2:7</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kT>4:4</td>
<td class=kW>8:3</td>
<td class=kW>8:3</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kW>8:0</td>
<td class=kW>5:0 K</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=br>114:84</td><td class=br>+30</td>
<td class=bc>16 - 9 - 10</td>
<td class=br><strong>41</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Da Cibulka</td><td class=kW>3:2</td>
<td class=kL>3:7</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kL>1:7</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kW>6:3</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>8:2</td>
<td class=kL>3:4</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>8:3</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=kW>5:0 K</td>
<td class=kW>11:2</td>
<td class=kW>8:0</td>
<td class=kW>8:1</td>
<td class=kW>8:1</td>
<td class=br>140:92</td><td class=br>+48</td>
<td class=bc>19 - 3 - 13</td>
<td class=br><strong>41</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Ma Klazar</td><td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kL>3:6</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kW>5:3</td>
<td class=kL>3:6</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>2:8</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kL>0:6</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>5:4</td>
<td class=kW>7:3</td>
<td class=kW>9:0</td>
<td class=br>108:110</td><td class=br>-2</td>
<td class=bc>17 - 4 - 14</td>
<td class=br><strong>38</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Ma Martinec</td><td class=kL>0:7</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kW>2:1</td>
<td class=kT>5:5</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>10:1</td>
<td class=kW>9:4</td>
<td class=kW>9:3</td>
<td class=br>109:107</td><td class=br>+2</td>
<td class=bc>17 - 2 - 16</td>
<td class=br><strong>36</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Fr Marek</td><td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kW>5:3</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kW>7:3</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>94:86</td><td class=br>+8</td>
<td class=bc>14 - 7 - 14</td>
<td class=br><strong>35</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>To Kahoun ml.</td><td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kT>5:5</td>
<td class=kL>1:6</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>6:3</td>
<td class=kW>5:0 K</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=br>98:86</td><td class=br>+12</td>
<td class=bc>15 - 5 - 15</td>
<td class=br><strong>35</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Ro Jež</td><td class=kL>1:3</td>
<td class=kL>2:8</td>
<td class=kL>4:6</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>6:0</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>7:0</td>
<td class=kW>6:0</td>
<td class=br>105:90</td><td class=br>+15</td>
<td class=bc>16 - 3 - 16</td>
<td class=br><strong>35</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Pe Fuchs</td><td class=kL>2:4</td>
<td class=kL>1:8</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>1:7</td>
<td class=kL>0:3</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kL>3:5</td>
<td class=kW>4:2</td>
<td class=kW>10:3</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>6:3</td>
<td class=kL>1:3</td>
<td class=kW>10:1</td>
<td class=kW>3:2</td>
<td class=br>89:111</td><td class=br>-22</td>
<td class=bc>13 - 2 - 20</td>
<td class=br><strong>28</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Al Krejza</td><td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kW>3:0</td>
<td class=kL>1:4</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>0:8</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kL>3:8</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kL>2:7</td>
<td class=kL>6:7</td>
<td class=kW>4:3</td>
<td class=kW>5:0 K</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kT>1:1</td>
<td class=br>83:118</td><td class=br>-35</td>
<td class=bc>10 - 6 - 19</td>
<td class=br><strong>26</strong></td><td class=d>24.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>25.</td><td class=kt>Ja Čepička</td><td class=kL>2:8</td>
<td class=kL>2:8</td>
<td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kL>2:8</td>
<td class=kL>4:8</td>
<td class=kL>0:4</td>
<td class=kL>4:6</td>
<td class=kL>1:9</td>
<td class=kW>9:3</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kL>3:8</td>
<td class=kL>4:6</td>
<td class=kL>3:8</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kT>4:4</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>8:5</td>
<td class=kW>4:1</td>
<td class=br>116:156</td><td class=br>-40</td>
<td class=bc>11 - 3 - 21</td>
<td class=br><strong>25</strong></td><td class=d>25.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>26.</td><td class=kt>Mi Uhlíř</td><td class=kL>2:8</td>
<td class=kL>1:9</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kL>5:6</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kL>3:8</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>2:7</td>
<td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>8:1</td>
<td class=kT>2:2</td>
<td class=kW>8:4</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>6:3</td>
<td class=kW>9:1</td>
<td class=kW>10:2</td>
<td class=kW>8:0</td>
<td class=br>128:142</td><td class=br>-14</td>
<td class=bc>10 - 3 - 22</td>
<td class=br><strong>23</strong></td><td class=d>26.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>27.</td><td class=kt>Ma Košňar</td><td class=kL>1:8</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>0:10</td>
<td class=kL>0:7</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>1:8</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kL>1:8</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kW>5:0 K</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=br>63:137</td><td class=br>-74</td>
<td class=bc>9 - 2 - 24</td>
<td class=br><strong>20</strong></td><td class=d>27.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>28.</td><td class=kt>To Halama</td><td class=kL>0:4</td>
<td class=kL>1:9</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>2:7</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>5:0 K</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kT>1:1</td>
<td class=br>62:120</td><td class=br>-58</td>
<td class=bc>6 - 6 - 23</td>
<td class=br><strong>18</strong></td><td class=d>28.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>29.</td><td class=kt>An Grimová</td><td class=kL>2:6</td>
<td class=kL>0:7</td>
<td class=kL>3:7</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>2:8</td>
<td class=kL>0:2</td>
<td class=kL>0:6</td>
<td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>3:9</td>
<td class=kL>0:6</td>
<td class=kL>2:7</td>
<td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kL>0:7</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kL>2:5</td>
<td class=kL>3:10</td>
<td class=kW>7:2</td>
<td class=kL>3:5</td>
<td class=kL>4:8</td>
<td class=kL>0:1</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=br>80:165</td><td class=br>-85</td>
<td class=bc>6 - 2 - 27</td>
<td class=br><strong>14</strong></td><td class=d>29.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>30.</td><td class=kt>St Cieslar</td><td class=kL>1:9</td>
<td class=kL>2:9</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>2:8</td>
<td class=kL>2:6</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>3:5</td>
<td class=kL>1:7</td>
<td class=kL>3:7</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>0:5 K</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kW>7:6</td>
<td class=kT>4:4</td>
<td class=kL>1:5</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kL>0:5 K</td>
<td class=kW>4:3</td>
<td class=kW>6:0</td>
<td class=br>63:159</td><td class=br>-96</td>
<td class=bc>5 - 3 - 27</td>
<td class=br><strong>13</strong></td><td class=d>30.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>31.</td><td class=kt>Er Bernhauser</td><td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>5:7</td>
<td class=kL>2:6</td>
<td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>3:7</td>
<td class=kL>1:7</td>
<td class=kL>0:8</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>3:7</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:0 K</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=br>72:153</td><td class=br>-81</td>
<td class=bc>5 - 2 - 28</td>
<td class=br><strong>12</strong></td><td class=d>31.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>32.</td><td class=kt>Jo Malý</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>0:5 K</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kL>0:5 K</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kL>2:5</td>
<td class=kW>3:0</td>
<td class=br>35:122</td><td class=br>-87</td>
<td class=bc>3 - 5 - 27</td>
<td class=br><strong>11</strong></td><td class=d>32.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>33.</td><td class=kt>Vo Vacke</td><td class=kL>0:4</td>
<td class=kL>2:9</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>0:7</td>
<td class=kL>0:10</td>
<td class=kL>0:2</td>
<td class=kL>1:9</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>0:9</td>
<td class=kL>0:3</td>
<td class=kL>2:11</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=br>47:177</td><td class=br>-130</td>
<td class=bc>3 - 2 - 30</td>
<td class=br><strong>8</strong></td><td class=d>33.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>34.</td><td class=kt>Pe Klazar</td><td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>0:7</td>
<td class=kL>2:10</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>0:8</td>
<td class=kL>4:5</td>
<td class=kL>1:10</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>2:6</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>1:9</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kW>5:0 K</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kW>3:1</td>
<td class=br>48:173</td><td class=br>-125</td>
<td class=bc>4 - 0 - 31</td>
<td class=br><strong>8</strong></td><td class=d>34.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>35.</td><td class=kt>Br Sabo</td><td class=kL>2:8</td>
<td class=kL>1:9</td>
<td class=kL>2:9</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kL>1:10</td>
<td class=kL>1:8</td>
<td class=kL>2:7</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>0:6</td>
<td class=kL>1:8</td>
<td class=kL>0:8</td>
<td class=kL>1:4</td>
<td class=kL>1:8</td>
<td class=kL>3:7</td>
<td class=kL>4:9</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>1:10</td>
<td class=kL>2:6</td>
<td class=kL>5:8</td>
<td class=kL>2:10</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=br>60:220</td><td class=br>-160</td>
<td class=bc>3 - 1 - 31</td>
<td class=br><strong>7</strong></td><td class=d>35.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>36.</td><td class=kt>Mi Krejza</td><td class=kL>0:5</td>
<td class=kL>2:8</td>
<td class=kL>0:4</td>
<td class=kL>1:9</td>
<td class=kL>2:5</td>
<td class=kL>0:7</td>
<td class=kL>0:7</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>0:6</td>
<td class=kL>0:8</td>
<td class=kL>0:9</td>
<td class=kL>2:9</td>
<td class=kL>0:11</td>
<td class=kL>0:4</td>
<td class=kL>1:8</td>
<td class=kL>0:9</td>
<td class=kL>3:9</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>0:8</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kT>4:4</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=br>24:191</td><td class=br>-167</td>
<td class=bc>0 - 3 - 32</td>
<td class=br><strong>3</strong></td><td class=d>36.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pe Turoň</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Br Sabo</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>St Cieslar</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pe Turoň</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ma Martinec</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>St Cieslar</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Lu Turoň</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pe Turoň</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Er Bernhauser</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>St Cieslar</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Er Bernhauser</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Martinec</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>St Cieslar</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ja Čepička</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>10 : 2</tr></td>
<tr><td class=br>Pe Turoň</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>St Cieslar</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pe Turoň</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>St Cieslar</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Martinec</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>9 : 4</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>St Cieslar</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Pe Turoň</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ma Martinec</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Lu Turoň</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>St Cieslar</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Er Bernhauser</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ma Martinec</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>St Cieslar</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ja Čepička</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>8 : 5</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Ma Martinec</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>St Cieslar</td><td class=bc>6 : 7</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Jo Malý</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ma Martinec</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>St Cieslar</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Br Sabo</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Vo Vacke</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Ma Martinec</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ja Čepička</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>9 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>7 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>St Cieslar</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Ma Martinec</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Lu Turoň</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ja Čepička</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Pe Turoň</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>St Cieslar</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>11 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ma Martinec</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>St Cieslar</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Ma Martinec</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=bl>Pe Turoň</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Lu Turoň</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>8 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>St Cieslar</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>9 : 3</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Martinec</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Ja Čepička</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>6 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>St Cieslar</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ma Martinec</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Pe Turoň</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>St Cieslar</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ma Martinec</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Jo Malý</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>St Cieslar</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>8 : 4</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Martinec</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Lu Turoň</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Vo Vacke</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Ma Martinec</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>St Cieslar</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ma Martinec</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Pe Turoň</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Ja Čepička</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>St Cieslar</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ma Martinec</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>St Cieslar</td><td class=bc>-</td><td class=blW>Ma Martinec</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ma Martinec</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>St Cieslar</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ja Čepička</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Ma Martinec</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>3 : 10</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>St Cieslar</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>Er Bernhauser</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>St Cieslar</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>26</td></tr>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ja Čepička</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>St Cieslar</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>11 : 0</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>27</td></tr>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Ja Čepička</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>St Cieslar</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>28</td></tr>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Martinec</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Br Sabo</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>St Cieslar</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>29</td></tr>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Vo Vacke</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>St Cieslar</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>30</td></tr>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Martinec</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>9 : 3</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>St Cieslar</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>31</td></tr>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Pe Turoň</td><td class=bc>-</td><td class=bl>Lu Turoň</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Er Bernhauser</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>St Cieslar</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>32</td></tr>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Martinec</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>St Cieslar</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>33</td></tr>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Jo Malý</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Ja Čepička</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>St Cieslar</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>34</td></tr>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Mi Krejza</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>St Cieslar</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>35</td></tr>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Martinec</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>St Cieslar</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>36</td></tr>
<tr><td class=br>Mi Krejza</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Jo Malý</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ja Čepička</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Martinec</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>2 : 10</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>St Cieslar</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<hr><a name="final"><p class=vm>Výkonnostní skupiny (Final groups)</p></a>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
