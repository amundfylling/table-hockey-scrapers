<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR veteráni</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../mrv">MR veteráni 29. květen 2022</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p><a href="#basic">Základní skupiny (Basic groups)</a><br>
<a href="#final">Výkonnostní skupiny (Final groups)</a><br>
<a name="basic"><p class=vm>Základní skupiny (Basic groups)</p></a>
<p class=v>Group V1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Ja Dryák</td><td class=ic>CZE</td><td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=kW>7:1</td>
<td class=kW>6:5</td>
<td class=kW>9:1</td>
<td class=br>69:19</td><td class=br>+50</td>
<td class=bc>14 - 0 - 0</td>
<td class=br><strong>28</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Pa Plešák</td><td class=ic>CZE</td><td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>7:4</td>
<td class=kW>9:2</td>
<td class=kW>8:0</td>
<td class=kW>9:1</td>
<td class=br>70:23</td><td class=br>+47</td>
<td class=bc>11 - 2 - 1</td>
<td class=br><strong>24</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Da Matýsek</td><td class=ic>CZE</td><td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>8:2</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>8:0</td>
<td class=br>48:19</td><td class=br>+29</td>
<td class=bc>10 - 2 - 2</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>To Bucek</td><td class=ic>CZE</td><td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>8:3</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kL>1:4</td>
<td class=kW>10:2</td>
<td class=br>47:27</td><td class=br>+20</td>
<td class=bc>9 - 3 - 2</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>St Srba</td><td class=ic>CZE</td><td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>8:0</td>
<td class=br>46:19</td><td class=br>+27</td>
<td class=bc>9 - 2 - 3</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Da Cibulka</td><td class=ic>CZE</td><td class=kL>3:4</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>8:1</td>
<td class=br>40:28</td><td class=br>+12</td>
<td class=bc>8 - 1 - 5</td>
<td class=br><strong>17</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Al Krejza</td><td class=ic>CZE</td><td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kT>0:0</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kW>10:0</td>
<td class=br>40:29</td><td class=br>+11</td>
<td class=bc>7 - 2 - 5</td>
<td class=br><strong>16</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Vá Pikl</td><td class=ic>CZE</td><td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>10:0</td>
<td class=kW>2:1</td>
<td class=kW>10:0</td>
<td class=br>46:26</td><td class=br>+20</td>
<td class=bc>6 - 2 - 6</td>
<td class=br><strong>14</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Pa Kubrt</td><td class=ic>CZE</td><td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>2:8</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kT>5:5</td>
<td class=kL>2:4</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=br>36:42</td><td class=br>-6</td>
<td class=bc>4 - 2 - 8</td>
<td class=br><strong>10</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ro Jež</td><td class=ic>CZE</td><td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=br>21:35</td><td class=br>-14</td>
<td class=bc>4 - 1 - 9</td>
<td class=br><strong>9</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Da Hrachovec</td><td class=ic>CZE</td><td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>3:8</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>10:3</td>
<td class=br>38:55</td><td class=br>-17</td>
<td class=bc>3 - 3 - 8</td>
<td class=br><strong>9</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Mi Mašika</td><td class=ic>CZE</td><td class=kL>0:6</td>
<td class=kL>4:7</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kT>5:5</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kW>7:1</td>
<td class=br>34:52</td><td class=br>-18</td>
<td class=bc>3 - 1 - 10</td>
<td class=br><strong>7</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Pe Klazar</td><td class=ic>CZE</td><td class=kL>1:7</td>
<td class=kL>2:9</td>
<td class=kL>0:3</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>0:10</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>7:0</td>
<td class=br>27:64</td><td class=br>-37</td>
<td class=bc>3 - 1 - 10</td>
<td class=br><strong>7</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Jo Gruncl</td><td class=ic>CZE</td><td class=kL>5:6</td>
<td class=kL>0:8</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=br>29:55</td><td class=br>-26</td>
<td class=bc>3 - 0 - 11</td>
<td class=br><strong>6</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Vl Fiedler</td><td class=ic>&nbsp;</td><td class=kL>1:9</td>
<td class=kL>1:9</td>
<td class=kL>0:8</td>
<td class=kL>2:10</td>
<td class=kL>0:8</td>
<td class=kL>1:8</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>3:10</td>
<td class=kL>1:7</td>
<td class=kL>0:7</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=br>13:111</td><td class=br>-98</td>
<td class=bc>0 - 0 - 14</td>
<td class=br><strong>0</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vl Fiedler</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Jo Gruncl</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Vl Fiedler</td><td class=bc>-</td><td class=blW>Pa Kubrt</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Vl Fiedler</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Vl Fiedler</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>3 : 10</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Pa Kubrt</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>6 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Jo Gruncl</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Vl Fiedler</td><td class=bc>8 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Mi Mašika</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Vl Fiedler</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Pa Kubrt</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Vl Fiedler</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pa Kubrt</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Mi Mašika</td><td class=bc>-</td><td class=bl>Vl Fiedler</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Vl Fiedler</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Vl Fiedler</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Jo Gruncl</td><td class=bc>-</td><td class=bl>Vl Fiedler</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Vl Fiedler</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Vl Fiedler</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 10</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vl Fiedler</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>4 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group V2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Da Šmíd</td><td class=ic>CZE</td><td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>8:1</td>
<td class=kW>7:0</td>
<td class=br>52:15</td><td class=br>+37</td>
<td class=bc>11 - 1 - 1</td>
<td class=br><strong>23</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Ma Ženíšek</td><td class=ic>CZE</td><td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=br>52:26</td><td class=br>+26</td>
<td class=bc>10 - 2 - 1</td>
<td class=br><strong>22</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Mi Černoch</td><td class=ic>CZE</td><td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>7:0</td>
<td class=br>44:16</td><td class=br>+28</td>
<td class=bc>8 - 3 - 2</td>
<td class=br><strong>19</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Pe Turoň</td><td class=ic>CZE</td><td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>8:1</td>
<td class=kW>7:0</td>
<td class=br>51:31</td><td class=br>+20</td>
<td class=bc>8 - 1 - 4</td>
<td class=br><strong>17</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Vl Kraus</td><td class=ic>CZE</td><td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>7:1</td>
<td class=kW>8:1</td>
<td class=kL>2:3</td>
<td class=kW>6:0</td>
<td class=kW>8:2</td>
<td class=kW>2:0</td>
<td class=br>50:24</td><td class=br>+26</td>
<td class=bc>7 - 3 - 3</td>
<td class=br><strong>17</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>An Šurýn</td><td class=ic>CZE</td><td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=br>31:18</td><td class=br>+13</td>
<td class=bc>7 - 3 - 3</td>
<td class=br><strong>17</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>To Kahoun st.</td><td class=ic>CZE</td><td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kW>6:3</td>
<td class=kW>6:2</td>
<td class=br>27:34</td><td class=br>-7</td>
<td class=bc>6 - 1 - 6</td>
<td class=br><strong>13</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Zd Lopaur</td><td class=ic>CZE</td><td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=br>36:41</td><td class=br>-5</td>
<td class=bc>5 - 2 - 6</td>
<td class=br><strong>12</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Pe Holub</td><td class=ic>CZE</td><td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>0:3</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=br>27:36</td><td class=br>-9</td>
<td class=bc>5 - 2 - 6</td>
<td class=br><strong>12</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ja Medvec</td><td class=ic>CZE</td><td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kW>5:3</td>
<td class=kL>1:8</td>
<td class=kL>0:3</td>
<td class=kW>6:0</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>4:5</td>
<td class=kW>10:1</td>
<td class=kW>7:1</td>
<td class=br>46:41</td><td class=br>+5</td>
<td class=bc>5 - 1 - 7</td>
<td class=br><strong>11</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Hy Nechutný</td><td class=ic>CZE</td><td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=br>21:35</td><td class=br>-14</td>
<td class=bc>3 - 2 - 8</td>
<td class=br><strong>8</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Fr Marek</td><td class=ic>CZE</td><td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kW>5:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=br>26:44</td><td class=br>-18</td>
<td class=bc>4 - 0 - 9</td>
<td class=br><strong>8</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ra Hrnčíř</td><td class=ic>CZE</td><td class=kL>1:8</td>
<td class=kL>2:6</td>
<td class=kL>0:6</td>
<td class=kL>1:8</td>
<td class=kL>2:8</td>
<td class=kL>0:3</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kL>3:7</td>
<td class=kL>1:10</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=br>21:74</td><td class=br>-53</td>
<td class=bc>1 - 1 - 11</td>
<td class=br><strong>3</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Mi Horáková</td><td class=ic>CZE</td><td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>0:7</td>
<td class=kL>0:7</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=br>15:64</td><td class=br>-49</td>
<td class=bc>0 - 0 - 13</td>
<td class=br><strong>0</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Pe Turoň</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ja Medvec</td><td class=bc>1 : 10</tr></td>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ja Medvec</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ja Medvec</td><td class=bc>-</td><td class=bl>To Kahoun st.</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pe Turoň</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>To Kahoun st.</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ja Medvec</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pe Turoň</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>Pe Turoň</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>To Kahoun st.</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ja Medvec</td><td class=bc>-</td><td class=bl>Pe Turoň</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Pe Turoň</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>To Kahoun st.</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<hr><a name="final"><p class=vm>Výkonnostní skupiny (Final groups)</p></a>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
