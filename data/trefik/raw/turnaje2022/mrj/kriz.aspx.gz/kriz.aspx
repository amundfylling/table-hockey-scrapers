<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR junioři</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../mrj">MR junioři 29. květen 2022</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p><a href="#basic">Základní skupiny (Basic groups)</a><br>
<a href="#final">Výkonnostní skupiny (Final groups)</a><br>
<a name="basic"><p class=vm>Základní skupiny (Basic groups)</p></a>
<p class=v>Group J</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Ma Klazar</td><td class=ic>CZE</td><td class=kx>*</td>
<td class=kW>3:2 + 2:3</td>
<td class=kW>2:0 + 1:4</td>
<td class=kW>7:1 + 7:1</td>
<td class=kW>4:0 + 7:1</td>
<td class=kW>5:1 + 10:3</td>
<td class=kW>5:0 + 7:0</td>
<td class=kW>9:1 + 9:2</td>
<td class=kW>7:2 + 7:1</td>
<td class=br>92:22</td><td class=br>+70</td>
<td class=bc>14 - 0 - 2</td>
<td class=br><strong>28</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Ja Matýsek</td><td class=ic>CZE</td><td class=kL>2:3 + 3:2</td>
<td class=kx>*</td>
<td class=kW>4:3 + 1:4</td>
<td class=kW>4:1 + 5:2</td>
<td class=kW>6:4 + 6:2</td>
<td class=kW>6:0 + 4:1</td>
<td class=kW>3:1 + 5:1</td>
<td class=kW>6:1 + 10:0</td>
<td class=kW>4:2 + 5:0</td>
<td class=br>74:27</td><td class=br>+47</td>
<td class=bc>14 - 0 - 2</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Ad Kopřiva</td><td class=ic>CZE</td><td class=kL>0:2 + 4:1</td>
<td class=kL>3:4 + 4:1</td>
<td class=kx>*</td>
<td class=kW>4:1 + 5:1</td>
<td class=kW>7:2 + 6:2</td>
<td class=kW>5:1 + 3:2</td>
<td class=kW>4:0 + 1:4</td>
<td class=kW>9:2 + 9:1</td>
<td class=kW>2:1 + 8:3</td>
<td class=br>74:28</td><td class=br>+46</td>
<td class=bc>13 - 0 - 3</td>
<td class=br><strong>26</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>On Pulec</td><td class=ic>CZE</td><td class=kL>1:7 + 1:7</td>
<td class=kL>1:4 + 2:5</td>
<td class=kL>1:4 + 1:5</td>
<td class=kx>*</td>
<td class=kL>1:2 + 2:0</td>
<td class=kT>1:1 + 4:3</td>
<td class=kW>4:2 + 4:1</td>
<td class=kW>3:0 + 4:2</td>
<td class=kW>5:2 + 1:1</td>
<td class=br>36:46</td><td class=br>-10</td>
<td class=bc>7 - 2 - 7</td>
<td class=br><strong>16</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Vo Kraus</td><td class=ic>CZE</td><td class=kL>0:4 + 1:7</td>
<td class=kL>4:6 + 2:6</td>
<td class=kL>2:7 + 2:6</td>
<td class=kW>2:1 + 0:2</td>
<td class=kx>*</td>
<td class=kL>0:3 + 5:2</td>
<td class=kT>2:2 + 4:2</td>
<td class=kW>5:4 + 4:2</td>
<td class=kW>4:3 + 4:0</td>
<td class=br>41:57</td><td class=br>-16</td>
<td class=bc>7 - 1 - 8</td>
<td class=br><strong>15</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Vo Vacke</td><td class=ic>CZE</td><td class=kL>1:5 + 3:10</td>
<td class=kL>0:6 + 1:4</td>
<td class=kL>1:5 + 2:3</td>
<td class=kT>1:1 + 3:4</td>
<td class=kW>3:0 + 2:5</td>
<td class=kx>*</td>
<td class=kW>6:3 + 2:2</td>
<td class=kW>7:2 + 2:1</td>
<td class=kL>1:2 + 2:0</td>
<td class=br>37:53</td><td class=br>-16</td>
<td class=bc>5 - 2 - 9</td>
<td class=br><strong>12</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>An Ouřada</td><td class=ic>CZE</td><td class=kL>0:5 + 0:7</td>
<td class=kL>1:3 + 1:5</td>
<td class=kL>0:4 + 4:1</td>
<td class=kL>2:4 + 1:4</td>
<td class=kT>2:2 + 2:4</td>
<td class=kL>3:6 + 2:2</td>
<td class=kx>*</td>
<td class=kT>5:5 + 6:2</td>
<td class=kW>7:2 + 5:1</td>
<td class=br>41:57</td><td class=br>-16</td>
<td class=bc>4 - 3 - 9</td>
<td class=br><strong>11</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ka Brodacký</td><td class=ic>CZE</td><td class=kL>1:9 + 2:9</td>
<td class=kL>1:6 + 0:10</td>
<td class=kL>2:9 + 1:9</td>
<td class=kL>0:3 + 2:4</td>
<td class=kL>4:5 + 2:4</td>
<td class=kL>2:7 + 1:2</td>
<td class=kT>5:5 + 2:6</td>
<td class=kx>*</td>
<td class=kW>3:1 + 4:4</td>
<td class=br>32:93</td><td class=br>-61</td>
<td class=bc>1 - 2 - 13</td>
<td class=br><strong>4</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Lu Holub</td><td class=ic>CZE</td><td class=kL>2:7 + 1:7</td>
<td class=kL>2:4 + 0:5</td>
<td class=kL>1:2 + 3:8</td>
<td class=kL>2:5 + 1:1</td>
<td class=kL>3:4 + 0:4</td>
<td class=kW>2:1 + 0:2</td>
<td class=kL>2:7 + 1:5</td>
<td class=kL>1:3 + 4:4</td>
<td class=kx>*</td>
<td class=br>25:69</td><td class=br>-44</td>
<td class=bc>1 - 2 - 13</td>
<td class=br><strong>4</strong></td><td class=d>9.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ka Brodacký</td><td class=bc>-</td><td class=blW>Vo Vacke</td><td class=bc>2 : 7 + 1 : 2</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>On Pulec</td><td class=bc>2 : 5 + 1 : 1</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>5 : 0 + 7 : 0</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>3 : 4 + 4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=bl>On Pulec</td><td class=bc>1 : 1 + 3 : 4</tr></td>
<tr><td class=br>Ka Brodacký</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>5 : 5 + 2 : 6</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 4 + 0 : 5</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>4 : 0 + 7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>On Pulec</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>4 : 2 + 4 : 1</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 6 + 1 : 4</tr></td>
<tr><td class=br>Ka Brodacký</td><td class=bc>-</td><td class=blW>Vo Kraus</td><td class=bc>4 : 5 + 2 : 4</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>1 : 2 + 3 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 3 + 1 : 5</tr></td>
<tr><td class=br>On Pulec</td><td class=bc>-</td><td class=blW>Vo Kraus</td><td class=bc>1 : 2 + 2 : 0</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>1 : 5 + 2 : 3</tr></td>
<tr><td class=br>Ka Brodacký</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 9 + 2 : 9</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>6 : 4 + 6 : 2</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 4 + 4 : 1</tr></td>
<tr><td class=br>On Pulec</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 7 + 1 : 7</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Lu Holub</td><td class=bc>1 : 2 + 2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 7 + 2 : 6</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 3 + 3 : 2</tr></td>
<tr><td class=brW>An Ouřada</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>7 : 2 + 5 : 1</tr></td>
<tr><td class=brW>On Pulec</td><td class=bc>-</td><td class=bl>Ka Brodacký</td><td class=bc>3 : 0 + 4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>0 : 2 + 4 : 1</tr></td>
<tr><td class=brW>Vo Kraus</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>4 : 3 + 4 : 0</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ka Brodacký</td><td class=bc>6 : 1 + 10 : 0</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Vo Vacke</td><td class=bc>3 : 6 + 2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>7 : 2 + 7 : 1</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ka Brodacký</td><td class=bc>9 : 2 + 9 : 1</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Vo Vacke</td><td class=bc>0 : 3 + 5 : 2</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>On Pulec</td><td class=bc>4 : 1 + 5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Ka Brodacký</td><td class=bc>1 : 3 + 4 : 4</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>5 : 1 + 10 : 3</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>On Pulec</td><td class=bc>4 : 1 + 5 : 1</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>2 : 2 + 4 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<hr><a name="final"><p class=vm>Výkonnostní skupiny (Final groups)</p></a>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
