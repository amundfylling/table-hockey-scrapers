<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2022">Czech Open </a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1927&x=374">Vojta Kraus</a></td><td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>7:2</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=br>49:21</td><td class=br>+28</td>
<td class=bc>11 - 1 - 0</td>
<td class=br><strong>23</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1940&x=374">Ma Košňar</a></td><td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>8:1</td>
<td class=kW>4:2</td>
<td class=kW>8:0</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>10:0</td>
<td class=br>57:17</td><td class=br>+40</td>
<td class=bc>10 - 1 - 1</td>
<td class=br><strong>21</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1430&x=374">Da Kadlec</a></td><td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>7:0</td>
<td class=br>38:24</td><td class=br>+14</td>
<td class=bc>8 - 1 - 3</td>
<td class=br><strong>17</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1968&x=374">Mi Touš</a></td><td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>6:4</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=br>44:31</td><td class=br>+13</td>
<td class=bc>6 - 2 - 4</td>
<td class=br><strong>14</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1973&x=374">Br Sabo</a></td><td class=kL>3:4</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>7:0</td>
<td class=br>35:26</td><td class=br>+9</td>
<td class=bc>6 - 2 - 4</td>
<td class=br><strong>14</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1984&x=374">Ka Brodacký</a></td><td class=kL>3:4</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kW>7:2</td>
<td class=kL>2:7</td>
<td class=kW>6:4</td>
<td class=kW>3:2</td>
<td class=br>40:42</td><td class=br>-2</td>
<td class=bc>6 - 1 - 5</td>
<td class=br><strong>13</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1869&x=374">Pe Klazar</a></td><td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=br>28:28</td><td class=br>0</td>
<td class=bc>5 - 2 - 5</td>
<td class=br><strong>12</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1881&x=374">Fi Werner</a></td><td class=kL>2:3</td>
<td class=kL>0:8</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=br>24:26</td><td class=br>-2</td>
<td class=bc>5 - 2 - 5</td>
<td class=br><strong>12</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1947&x=374">Lu Holub</a></td><td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kW>4:2</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>8:0</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=br>34:36</td><td class=br>-2</td>
<td class=bc>5 - 0 - 7</td>
<td class=br><strong>10</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1626&x=374">Mi Horáková</a></td><td class=kL>2:7</td>
<td class=kL>0:1</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>2:7</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kL>0:8</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=br>29:45</td><td class=br>-16</td>
<td class=bc>4 - 0 - 8</td>
<td class=br><strong>8</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1923&x=374">Vo Vacke</a></td><td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>4:6</td>
<td class=kL>2:3</td>
<td class=kW>7:2</td>
<td class=kW>3:0</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>6:0</td>
<td class=br>30:27</td><td class=br>+3</td>
<td class=bc>4 - 0 - 8</td>
<td class=br><strong>8</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1076&x=374">Mi Zeman</a></td><td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>4:6</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=br>20:44</td><td class=br>-24</td>
<td class=bc>2 - 0 - 10</td>
<td class=br><strong>4</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1982&x=374">Ja Čermák</a></td><td class=kL>0:6</td>
<td class=kL>0:10</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=br>9:70</td><td class=br>-61</td>
<td class=bc>0 - 0 - 12</td>
<td class=br><strong>0</strong></td><td class=d>13.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Ja Čermák</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Vojta Kraus</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ka Brodacký</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>Da Kadlec</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Fi Werner</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ja Čermák</td><td class=bc>-</td><td class=blW>Vo Vacke</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Ka Brodacký</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Vojta Kraus</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=bl>Fi Werner</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Mi Touš</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Vo Vacke</td><td class=bc>-</td><td class=bl>Ka Brodacký</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ja Čermák</td><td class=bc>-</td><td class=blW>Da Kadlec</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Vojta Kraus</td><td class=bc>-</td><td class=bl>Fi Werner</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Br Sabo</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ka Brodacký</td><td class=bc>-</td><td class=blW>Da Kadlec</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Vo Vacke</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ja Čermák</td><td class=bc>-</td><td class=blW>Fi Werner</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Mi Touš</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vojta Kraus</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ka Brodacký</td><td class=bc>-</td><td class=bl>Fi Werner</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>Vojta Kraus</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ja Čermák</td><td class=bc>-</td><td class=blW>Lu Holub</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>Fi Werner</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ka Brodacký</td><td class=bc>-</td><td class=blW>Lu Holub</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Mi Touš</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ja Čermák</td><td class=bc>-</td><td class=blW>Br Sabo</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Da Kadlec</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Vojta Kraus</td><td class=bc>-</td><td class=bl>Ja Čermák</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Mi Touš</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ka Brodacký</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Fi Werner</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Fi Werner</td><td class=bc>-</td><td class=blW>Mi Touš</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Br Sabo</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Da Kadlec</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ka Brodacký</td><td class=bc>-</td><td class=blW>Vojta Kraus</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Lu Holub</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Lu Holub</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ka Brodacký</td><td class=bc>-</td><td class=bl>Ja Čermák</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Fi Werner</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Br Sabo</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Lu Holub</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Da Kadlec</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Fi Werner</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>Ja Čermák</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Vojta Kraus</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Br Sabo</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Vojta Kraus</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ka Brodacký</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Fi Werner</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Ja Čermák</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Vojta Kraus</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Mi Touš</td><td class=bc>-</td><td class=bl>Ja Čermák</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Vo Vacke</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Fi Werner</td><td class=bc>-</td><td class=blW>Da Kadlec</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ka Brodacký</td><td class=bc>4 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Vojta Kraus</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Ja Čermák</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Br Sabo</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Ka Brodacký</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Da Kadlec</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>1 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
