<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2022">Czech Open </a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group A2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=57&x=374">Zd Matoušek ml.</a></td><td class=kx>*</td>
<td class=kT>3:3 K</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kW>5:0</td>
<td class=kW>6:5</td>
<td class=kW>3:1 K</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>4:1 K</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=kT>3:3</td>
<td class=kW>8:0</td>
<td class=kW>5:1 K</td>
<td class=kW>4:2</td>
<td class=kW>4:2 K</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=br>95:41</td><td class=br>+54</td>
<td class=bc>18 - 2 - 3</td>
<td class=br><strong>38</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=559&x=374">Bj Axelsen</a></td><td class=kT>3:3 K</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kT>5:5</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=kL>0:5</td>
<td class=kW>5:3 K</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>6:4 K</td>
<td class=kT>2:2</td>
<td class=kW>6:5</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>3:2 K</td>
<td class=kW>3:1</td>
<td class=kW>3:1 K</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=br>83:53</td><td class=br>+30</td>
<td class=bc>14 - 7 - 2</td>
<td class=br><strong>35</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=567&x=374">Kr Lebl</a></td><td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1 K</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>4:1 K</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2</td>
<td class=kW>4:0 K</td>
<td class=kW>4:1 K</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=br>77:44</td><td class=br>+33</td>
<td class=bc>14 - 5 - 4</td>
<td class=br><strong>33</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1503&x=374">Ve Huotelin</a></td><td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>3:3 K</td>
<td class=kL>1:2 K</td>
<td class=kW>7:5</td>
<td class=kL>3:6 K</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kT>3:3 K</td>
<td class=kW>7:5</td>
<td class=kW>6:0</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>6:0</td>
<td class=kW>7:1</td>
<td class=kW>7:0 K</td>
<td class=br>94:60</td><td class=br>+34</td>
<td class=bc>13 - 6 - 4</td>
<td class=br><strong>32</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1174&x=374">Ma Maděra</a></td><td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kT>3:3 K</td>
<td class=kx>*</td>
<td class=kL>1:3 K</td>
<td class=kW>6:2</td>
<td class=kW>4:3 K</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>5:3 K</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>6:3</td>
<td class=kT>2:2 K</td>
<td class=br>76:49</td><td class=br>+27</td>
<td class=bc>14 - 4 - 5</td>
<td class=br><strong>32</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=842&x=374">Ma Lisý</a></td><td class=kW>5:1</td>
<td class=kT>5:5</td>
<td class=kL>1:5</td>
<td class=kW>2:1 K</td>
<td class=kW>3:1 K</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>0:5 K</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3 K</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kT>0:0</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>7:0</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kT>2:2 K</td>
<td class=br>67:50</td><td class=br>+17</td>
<td class=bc>12 - 6 - 5</td>
<td class=br><strong>30</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=961&x=374">Mi Boštík</a></td><td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>5:7</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>4:1 K</td>
<td class=kL>3:7</td>
<td class=kL>0:2 K</td>
<td class=kL>0:3</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>4:1 K</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1 K</td>
<td class=kW>5:2</td>
<td class=kW>3:1 K</td>
<td class=kW>6:1</td>
<td class=br>76:60</td><td class=br>+16</td>
<td class=bc>12 - 4 - 7</td>
<td class=br><strong>28</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1644&x=374">To Růžička</a></td><td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kW>5:4</td>
<td class=kW>6:3 K</td>
<td class=kL>3:4 K</td>
<td class=kW>5:0 K</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kL>1:8</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>0:2 K</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>5:0 K</td>
<td class=br>67:57</td><td class=br>+10</td>
<td class=bc>12 - 3 - 8</td>
<td class=br><strong>27</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1845&x=374">My Shalomayev</a></td><td class=kL>5:6</td>
<td class=kW>5:0</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>1:4 K</td>
<td class=kW>8:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:7 K</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kW>6:3</td>
<td class=kL>3:4</td>
<td class=kW>3:0 K</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>4:1 K</td>
<td class=kW>4:2</td>
<td class=kL>0:4 K</td>
<td class=kW>2:1</td>
<td class=br>81:66</td><td class=br>+15</td>
<td class=bc>12 - 2 - 9</td>
<td class=br><strong>26</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1976&x=374">Jo Astrom</a></td><td class=kL>1:3 K</td>
<td class=kL>3:5 K</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kW>7:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kW>4:2</td>
<td class=kW>4:2 K</td>
<td class=kW>10:1</td>
<td class=kW>1:0</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>3:2 K</td>
<td class=kW>4:2</td>
<td class=kW>4:1 K</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=br>72:58</td><td class=br>+14</td>
<td class=bc>10 - 6 - 7</td>
<td class=br><strong>26</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=386&x=374">Ku Sládek</a></td><td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>2:0 K</td>
<td class=kT>1:1</td>
<td class=kW>7:1 K</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kL>1:4 K</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>4:1 K</td>
<td class=kT>1:1</td>
<td class=kT>2:2 K</td>
<td class=kW>5:3</td>
<td class=br>61:49</td><td class=br>+12</td>
<td class=bc>9 - 7 - 7</td>
<td class=br><strong>25</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1033&x=374">Si Thomas</a></td><td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>1:4 K</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kW>5:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kW>4:1 K</td>
<td class=kL>2:5 K</td>
<td class=kW>3:2</td>
<td class=kL>2:3 K</td>
<td class=kW>4:2 K</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=br>58:60</td><td class=br>-2</td>
<td class=bc>12 - 0 - 11</td>
<td class=br><strong>24</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=248&x=374">Ma Ženíšek</a></td><td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3 K</td>
<td class=kL>3:5 K</td>
<td class=kL>3:4 K</td>
<td class=kL>1:5</td>
<td class=kW>2:0 K</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kW>1:0</td>
<td class=kW>6:3</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kW>4:2 K</td>
<td class=br>64:61</td><td class=br>+3</td>
<td class=bc>10 - 3 - 10</td>
<td class=br><strong>23</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=893&x=374">Ne Škrlep</a></td><td class=kL>1:4 K</td>
<td class=kL>4:6 K</td>
<td class=kW>4:3</td>
<td class=kL>5:7</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kL>2:4 K</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>3:4 K</td>
<td class=kL>1:5</td>
<td class=kW>2:0 K</td>
<td class=kW>3:1</td>
<td class=kW>5:4</td>
<td class=br>67:73</td><td class=br>-6</td>
<td class=bc>10 - 3 - 10</td>
<td class=br><strong>23</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1974&x=374">Ja Obadič</a></td><td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>1:4 K</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kL>3:6</td>
<td class=kL>1:10</td>
<td class=kW>3:2</td>
<td class=kL>1:4 K</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>7:4 K</td>
<td class=kT>3:3</td>
<td class=kL>1:5 K</td>
<td class=kL>1:4 K</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=br>53:79</td><td class=br>-26</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=176&x=374">Zd Lopaur</a></td><td class=kL>2:3</td>
<td class=kL>5:6</td>
<td class=kT>2:2 K</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kW>5:2 K</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>4:7 K</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2 K</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=br>57:64</td><td class=br>-7</td>
<td class=bc>8 - 5 - 10</td>
<td class=br><strong>21</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=841&x=374">Ma Ležík</a></td><td class=kL>0:7</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>1:4 K</td>
<td class=kL>2:3</td>
<td class=kL>0:3 K</td>
<td class=kT>4:4</td>
<td class=kW>4:1 K</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kW>3:0 K</td>
<td class=kW>6:2</td>
<td class=kT>5:5 K</td>
<td class=kW>3:2</td>
<td class=br>62:69</td><td class=br>-7</td>
<td class=bc>6 - 8 - 9</td>
<td class=br><strong>20</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=53&x=374">Vá Pikl</a></td><td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>0:4 K</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kT>0:0</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kW>3:2 K</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kW>5:1 K</td>
<td class=kT>1:1 K</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kL>0:2 K</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=br>51:59</td><td class=br>-8</td>
<td class=bc>6 - 7 - 10</td>
<td class=br><strong>19</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1912&x=374">Al Krejza</a></td><td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>1:4 K</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>2:4 K</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kW>4:1 K</td>
<td class=kT>2:2 K</td>
<td class=kW>4:2</td>
<td class=kW>2:0 K</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=br>42:65</td><td class=br>-23</td>
<td class=bc>5 - 8 - 10</td>
<td class=br><strong>18</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1709&x=374">Mi Blažek</a></td><td class=kL>1:5 K</td>
<td class=kL>2:3 K</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>1:7</td>
<td class=kL>2:3 K</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kW>4:3 K</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=br>43:68</td><td class=br>-25</td>
<td class=bc>4 - 8 - 11</td>
<td class=br><strong>16</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=261&x=374">Da Cibulka</a></td><td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kL>1:4 K</td>
<td class=kL>2:4</td>
<td class=kL>1:4 K</td>
<td class=kL>2:4</td>
<td class=kL>1:4 K</td>
<td class=kW>3:2</td>
<td class=kL>0:5</td>
<td class=kW>5:1</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>0:3 K</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:1 K</td>
<td class=kT>3:3</td>
<td class=br>49:75</td><td class=br>-26</td>
<td class=bc>6 - 3 - 14</td>
<td class=br><strong>15</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1488&x=374">Ra Pommerenke</a></td><td class=kL>2:4 K</td>
<td class=kL>1:3 K</td>
<td class=kL>3:4</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>1:4 K</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kW>5:3</td>
<td class=kL>0:2 K</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=br>38:79</td><td class=br>-41</td>
<td class=bc>3 - 3 - 17</td>
<td class=br><strong>9</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=26&x=374">Mi Ševr</a></td><td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>1:7</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kL>1:3 K</td>
<td class=kL>1:5</td>
<td class=kW>4:0 K</td>
<td class=kT>3:3</td>
<td class=kT>2:2 K</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kT>5:5 K</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>1:5 K</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>41:79</td><td class=br>-38</td>
<td class=bc>2 - 4 - 17</td>
<td class=br><strong>8</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=818&x=374">Ro Jež</a></td><td class=kL>2:7</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>0:7 K</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2 K</td>
<td class=kL>1:6</td>
<td class=kL>0:5 K</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kL>0:1</td>
<td class=kL>2:4 K</td>
<td class=kL>4:5</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>30:86</td><td class=br>-56</td>
<td class=bc>0 - 3 - 20</td>
<td class=br><strong>3</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>7 : 5</tr></td>
<tr><td class=br>Ma Lisý</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ja Obadič</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>7 : 4 K</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Lisý</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 0 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 2 K</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 4 K</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Zd Matoušek ml.</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Lisý</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>2 : 2 K</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>2 : 0 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>2 : 4 K</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>1 : 1 K</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 4 K</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>2 : 2 K</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>3 : 6 K</tr></td>
<tr><td class=brW>Ma Lisý</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 3 K</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 3 K</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 4 K</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 3 K</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>Ma Lisý</td><td class=bc>1 : 2 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 4 K</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Ma Lisý</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>3 : 3 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Ma Lisý</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>0 : 2 K</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ja Obadič</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ma Lisý</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>3 : 0 K</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>3 : 4 K</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>1 : 3 K</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Zd Matoušek ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=bl>Ma Lisý</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>5 : 7</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>1 : 5 K</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>3 : 0 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>2 : 3 K</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>2 : 4 K</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 4 K</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Ma Lisý</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>4 : 1 K</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>1 : 4 K</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 0 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>5 : 3 K</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 5 K</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Ma Lisý</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 1 K</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 2 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 3 K</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Ma Lisý</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ja Obadič</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>0 : 2 K</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=bl>Ma Lisý</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 4 K</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=blW>Ma Lisý</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>4 : 1 K</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Ma Lisý</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>0 : 7 K</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>5 : 1 K</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 5 K</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>3 : 3 K</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>3 : 4 K</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Ja Obadič</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>2 : 2 K</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>0 : 2 K</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ma Lisý</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>3 : 1 K</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Ja Obadič</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>4 : 1 K</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ma Lisý</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ma Lisý</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ja Obadič</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 4 K</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Lisý</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Ja Obadič</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>2 : 2 K</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 5 K</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 4 K</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ma Lisý</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>4 : 1 K</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>6 : 4 K</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 7 K</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 4 K</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Ja Obadič</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ma Lisý</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>4 : 1 K</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>3 : 2 K</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 3 K</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ma Lisý</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>3 : 3 K</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Ja Obadič</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ma Lisý</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
