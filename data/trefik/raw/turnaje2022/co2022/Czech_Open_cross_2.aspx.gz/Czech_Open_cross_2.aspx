<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2022">Czech Open </a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1174&x=374">Ma Maděra</a></td><td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kW>8:2</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>8:4</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kW>10:1</td>
<td class=kW>7:2</td>
<td class=br>86:33</td><td class=br>+53</td>
<td class=bc>14 - 2 - 2</td>
<td class=br><strong>30</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=409&x=374">Pa Petr</a></td><td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>2:7</td>
<td class=kW>6:3</td>
<td class=kW>6:1</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>9:2</td>
<td class=kW>9:2</td>
<td class=kW>4:0</td>
<td class=kW>9:1</td>
<td class=kW>12:1</td>
<td class=kW>11:0</td>
<td class=kW>12:1</td>
<td class=br>111:35</td><td class=br>+76</td>
<td class=bc>14 - 1 - 3</td>
<td class=br><strong>29</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1503&x=374">Ve Huotelin</a></td><td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kW>7:0</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kW>11:1</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kW>7:3</td>
<td class=kW>6:0</td>
<td class=kW>9:1</td>
<td class=br>90:38</td><td class=br>+52</td>
<td class=bc>11 - 4 - 3</td>
<td class=br><strong>26</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1975&x=374">Gu Hermansson</a></td><td class=kL>2:8</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kL>2:5</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>8:3</td>
<td class=kW>8:1</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=br>76:43</td><td class=br>+33</td>
<td class=bc>12 - 2 - 4</td>
<td class=br><strong>26</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=842&x=374">Ma Lisý</a></td><td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>9:0</td>
<td class=kW>8:1</td>
<td class=br>61:32</td><td class=br>+29</td>
<td class=bc>11 - 3 - 4</td>
<td class=br><strong>25</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=40&x=374">Da Matýsek</a></td><td class=kL>0:3</td>
<td class=kL>3:6</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kL>4:8</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>9:2</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>9:2</td>
<td class=br>67:42</td><td class=br>+25</td>
<td class=bc>12 - 1 - 5</td>
<td class=br><strong>25</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=248&x=374">Ma Ženíšek</a></td><td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kW>6:4</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>8:2</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>9:3</td>
<td class=br>79:47</td><td class=br>+32</td>
<td class=bc>11 - 2 - 5</td>
<td class=br><strong>24</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1118&x=374">Lu Kahoun</a></td><td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>7:3</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=br>55:42</td><td class=br>+13</td>
<td class=bc>10 - 4 - 4</td>
<td class=br><strong>24</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1644&x=374">To Růžička</a></td><td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kW>6:3</td>
<td class=kL>2:5</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kL>3:5</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>9:1</td>
<td class=br>67:40</td><td class=br>+27</td>
<td class=bc>10 - 2 - 6</td>
<td class=br><strong>22</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1977&x=374">Ti Dion</a></td><td class=kL>4:8</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kW>8:4</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=br>61:45</td><td class=br>+16</td>
<td class=bc>8 - 5 - 5</td>
<td class=br><strong>21</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>A</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=818&x=374">Ro Jež</a></td><td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kL>2:4</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>9:0</td>
<td class=br>54:49</td><td class=br>+5</td>
<td class=bc>8 - 3 - 7</td>
<td class=br><strong>19</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>A</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=201&x=374">To Bucek</a></td><td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>4:6</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=kW>4:3</td>
<td class=kW>7:0</td>
<td class=kW>10:0</td>
<td class=br>67:48</td><td class=br>+19</td>
<td class=bc>8 - 2 - 8</td>
<td class=br><strong>18</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1599&x=374">Mi Uhlíř</a></td><td class=kL>1:3</td>
<td class=kL>2:9</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kL>3:7</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kW>7:3</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>8:0</td>
<td class=br>66:71</td><td class=br>-5</td>
<td class=bc>6 - 3 - 9</td>
<td class=br><strong>15</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>B</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1645&x=374">An Grimová</a></td><td class=kL>0:3</td>
<td class=kL>2:9</td>
<td class=kL>1:11</td>
<td class=kL>3:8</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>0:6</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=br>45:79</td><td class=br>-34</td>
<td class=bc>5 - 2 - 11</td>
<td class=br><strong>12</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>B</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=999&x=374">To Halama</a></td><td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>1:7</td>
<td class=kL>1:8</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>0:7</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kL>2:7</td>
<td class=kL>3:7</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>9:0</td>
<td class=kW>9:2</td>
<td class=br>45:78</td><td class=br>-33</td>
<td class=bc>4 - 2 - 12</td>
<td class=br><strong>10</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>B</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1941&x=374">Ja Kopecký</a></td><td class=kL>2:5</td>
<td class=kL>1:9</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>2:9</td>
<td class=kL>2:8</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=br>27:76</td><td class=br>-49</td>
<td class=bc>4 - 2 - 12</td>
<td class=br><strong>10</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>C</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1927&x=374">Vojta Kraus</a></td><td class=kL>0:7</td>
<td class=kL>1:12</td>
<td class=kL>3:7</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=br>26:87</td><td class=br>-61</td>
<td class=bc>2 - 0 - 16</td>
<td class=br><strong>4</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>C</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1947&x=374">Lu Holub</a></td><td class=kL>1:10</td>
<td class=kL>0:11</td>
<td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kL>0:9</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>3:6</td>
<td class=kL>0:9</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=br>19:108</td><td class=br>-89</td>
<td class=bc>1 - 0 - 17</td>
<td class=br><strong>2</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>C</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1430&x=374">Da Kadlec</a></td><td class=kL>2:7</td>
<td class=kL>1:12</td>
<td class=kL>1:9</td>
<td class=kL>0:3</td>
<td class=kL>1:8</td>
<td class=kL>2:9</td>
<td class=kL>3:9</td>
<td class=kL>1:5</td>
<td class=kL>1:9</td>
<td class=kL>0:4</td>
<td class=kL>0:9</td>
<td class=kL>0:10</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>2:9</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=br>20:129</td><td class=br>-109</td>
<td class=bc>0 - 0 - 18</td>
<td class=br><strong>0</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>Ma Lisý</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Ja Kopecký</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ma Lisý</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Vojta Kraus</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>4 : 8</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ma Lisý</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>9 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ma Lisý</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ja Kopecký</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Ma Lisý</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Ma Lisý</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>1 : 11</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>9 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Ma Lisý</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>3 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ma Lisý</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>12 : 1</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Ja Kopecký</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Lisý</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Vojta Kraus</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Lisý</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Ma Lisý</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ja Kopecký</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ma Lisý</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>4 : 8</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Lu Holub</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Lisý</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>9 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>2 : 9</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Lisý</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Lisý</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>3 : 9</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 12</tr></td>
<tr><td class=br>Ma Lisý</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Ma Lisý</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Ma Lisý</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>4 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
