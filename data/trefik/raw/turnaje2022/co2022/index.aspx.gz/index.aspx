<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Czech Open, 23. duben 2022</span></h2></div></div></div></div><p><div align="center">
<div align=center>
<a href="Czech_Open_list.aspx">Live index</a><br>
<a href="kriz.aspx">Zápasy ve skupinách (Basic and placement groups)</a><br>
<a href="Czech_Open_playoff.aspx ">Zápasy o umístění (Placement matches)</a><br>
<a href="utokturnaje.aspx">Tabulka útočníků (Best forwards)</a><br>
<a href="obranaturnaje.aspx">Tabulka obránců (Best defenders)</a><br>
<a href="kluby.aspx">Soutěž klubů</a><br>
</div>
<p class=v>Konečné pořadí turnaje (Final table)<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0 class="rnk">
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">M</th>
<th align="center">+</th>
<th align="center">=</th>
<th align="center">-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">Pts</th>
<th align="center">CZ pts</th>
<th>&nbsp;</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1649&x=374">Miglinieks Raivis</a></td>
<td class=al>* Latvia</td>
<td class=ar>64</td>
<td class=ar>51</td>
<td class=ar>1</td>
<td class=ar>12</td>
<td class=ar>288</td>
<td class=al>&nbsp;:&nbsp;129</td>
<td class=ar>103</td>
<td class=art>180</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>2.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=409&x=374">Petr Patrik</a></td>
<td class=bl>THC Stiga Elites</td>
<td class=br>62</td>
<td class=br>45</td>
<td class=br>4</td>
<td class=br>13</td>
<td class=br>282</td>
<td class=bl>&nbsp;:&nbsp;139</td>
<td class=br>94</td>
<td class=brt>172</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>3.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=57&x=374">Matoušek ml. Zdeněk</a></td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>57</td>
<td class=ar>48</td>
<td class=ar>2</td>
<td class=ar>7</td>
<td class=ar>271</td>
<td class=al>&nbsp;:&nbsp;102</td>
<td class=ar>98</td>
<td class=art>166</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>4.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1251&x=374">Sládek Honza</a></td>
<td class=bl>THC Stiga Elites</td>
<td class=br>60</td>
<td class=br>34</td>
<td class=br>7</td>
<td class=br>19</td>
<td class=br>174</td>
<td class=bl>&nbsp;:&nbsp;128</td>
<td class=br>75</td>
<td class=brt>161</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>5.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1477&x=374">Kobrle Michal</a></td>
<td class=al>THC Stiga Elites</td>
<td class=ar>50</td>
<td class=ar>36</td>
<td class=ar>6</td>
<td class=ar>8</td>
<td class=ar>227</td>
<td class=al>&nbsp;:&nbsp;103</td>
<td class=ar>78</td>
<td class=art>157</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>6.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=567&x=374">Lebl Kryštof</a></td>
<td class=bl>Big Band</td>
<td class=br>52</td>
<td class=br>33</td>
<td class=br>9</td>
<td class=br>10</td>
<td class=br>175</td>
<td class=bl>&nbsp;:&nbsp;99</td>
<td class=br>75</td>
<td class=brt>154</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>7.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1503&x=374">Huotelin Vesa</a></td>
<td class=al>* Finland</td>
<td class=ar>54</td>
<td class=ar>34</td>
<td class=ar>8</td>
<td class=ar>12</td>
<td class=ar>228</td>
<td class=al>&nbsp;:&nbsp;138</td>
<td class=ar>76</td>
<td class=art>152</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>8.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1174&x=374">Maděra Martin</a></td>
<td class=bl>THC Stiga-Game Příbram</td>
<td class=br>50</td>
<td class=br>34</td>
<td class=br>4</td>
<td class=br>12</td>
<td class=br>194</td>
<td class=bl>&nbsp;:&nbsp;107</td>
<td class=br>72</td>
<td class=brt>151</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>9.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=559&x=374">Axelsen Bjarne</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>45</td>
<td class=ar>27</td>
<td class=ar>8</td>
<td class=ar>10</td>
<td class=ar>161</td>
<td class=al>&nbsp;:&nbsp;99</td>
<td class=ar>62</td>
<td class=art>148</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>10.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=993&x=374">Chylík ml. Jiří</a></td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>47</td>
<td class=br>30</td>
<td class=br>8</td>
<td class=br>9</td>
<td class=br>162</td>
<td class=bl>&nbsp;:&nbsp;94</td>
<td class=br>68</td>
<td class=brt>147</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>11.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1975&x=374">Hermansson Gustaf</a></td>
<td class=al>* Sweden</td>
<td class=ar>49</td>
<td class=ar>28</td>
<td class=ar>5</td>
<td class=ar>16</td>
<td class=ar>171</td>
<td class=al>&nbsp;:&nbsp;132</td>
<td class=ar>61</td>
<td class=art>146</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>12.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1&x=374">Plešák Pavel</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>47</td>
<td class=br>26</td>
<td class=br>8</td>
<td class=br>13</td>
<td class=br>190</td>
<td class=bl>&nbsp;:&nbsp;120</td>
<td class=br>60</td>
<td class=brt>145</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>13.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=842&x=374">Lisý Marek</a></td>
<td class=al>Hradec Králové</td>
<td class=ar>47</td>
<td class=ar>24</td>
<td class=ar>8</td>
<td class=ar>15</td>
<td class=ar>146</td>
<td class=al>&nbsp;:&nbsp;102</td>
<td class=ar>56</td>
<td class=art>144</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>14.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1650&x=374">Dietze Valentin</a></td>
<td class=bl>* Germany</td>
<td class=br>46</td>
<td class=br>26</td>
<td class=br>5</td>
<td class=br>15</td>
<td class=br>161</td>
<td class=bl>&nbsp;:&nbsp;116</td>
<td class=br>57</td>
<td class=brt>143</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>15.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=448&x=374">Waclawek Tomáš</a></td>
<td class=al>THC Třinec</td>
<td class=ar>44</td>
<td class=ar>24</td>
<td class=ar>1</td>
<td class=ar>19</td>
<td class=ar>152</td>
<td class=al>&nbsp;:&nbsp;131</td>
<td class=ar>49</td>
<td class=art>142</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>16.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1815&x=374">Božič Anže</a></td>
<td class=bl>* Slovenia</td>
<td class=br>47</td>
<td class=br>28</td>
<td class=br>3</td>
<td class=br>16</td>
<td class=br>155</td>
<td class=bl>&nbsp;:&nbsp;108</td>
<td class=br>59</td>
<td class=brt>141</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>17.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=961&x=374">Boštík Michal</a></td>
<td class=al>THC Stiga Elites</td>
<td class=ar>40</td>
<td class=ar>22</td>
<td class=ar>6</td>
<td class=ar>12</td>
<td class=ar>149</td>
<td class=al>&nbsp;:&nbsp;96</td>
<td class=ar>50</td>
<td class=art>139</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>18.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1644&x=374">Růžička Tomáš</a></td>
<td class=bl>THC Stiga-Game Příbram</td>
<td class=br>40</td>
<td class=br>19</td>
<td class=br>5</td>
<td class=br>16</td>
<td class=br>123</td>
<td class=bl>&nbsp;:&nbsp;105</td>
<td class=br>43</td>
<td class=brt>138</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>19.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1845&x=374">Shalomayev Mykhaylo</a></td>
<td class=al>* Ukraine</td>
<td class=ar>42</td>
<td class=ar>22</td>
<td class=ar>3</td>
<td class=ar>17</td>
<td class=ar>138</td>
<td class=al>&nbsp;:&nbsp;118</td>
<td class=ar>47</td>
<td class=art>137</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>20.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1976&x=374">Astrom Joakim</a></td>
<td class=bl>* Sweden</td>
<td class=br>41</td>
<td class=br>21</td>
<td class=br>8</td>
<td class=br>12</td>
<td class=br>142</td>
<td class=bl>&nbsp;:&nbsp;96</td>
<td class=br>50</td>
<td class=brt>136</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>21.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=386&x=374">Sládek Kuba</a></td>
<td class=al>THC Stiga-Game Příbram</td>
<td class=ar>42</td>
<td class=ar>19</td>
<td class=ar>9</td>
<td class=ar>14</td>
<td class=ar>114</td>
<td class=al>&nbsp;:&nbsp;92</td>
<td class=ar>47</td>
<td class=art>135</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>22.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=886&x=374">Rjavec Bernard</a></td>
<td class=bl>* Slovenia</td>
<td class=br>44</td>
<td class=br>22</td>
<td class=br>6</td>
<td class=br>16</td>
<td class=br>121</td>
<td class=bl>&nbsp;:&nbsp;98</td>
<td class=br>50</td>
<td class=brt>134</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>23.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1033&x=374">Thomas Simon</a></td>
<td class=al>Big Band</td>
<td class=ar>44</td>
<td class=ar>24</td>
<td class=ar>2</td>
<td class=ar>18</td>
<td class=ar>131</td>
<td class=al>&nbsp;:&nbsp;103</td>
<td class=ar>50</td>
<td class=art>133</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>24.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=18&x=374">Šurýn Antonín</a></td>
<td class=bl>Big Band</td>
<td class=br>40</td>
<td class=br>15</td>
<td class=br>9</td>
<td class=br>16</td>
<td class=br>75</td>
<td class=bl>&nbsp;:&nbsp;88</td>
<td class=br>39</td>
<td class=brt>132</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>25.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=248&x=374">Ženíšek Martin</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>40</td>
<td class=ar>19</td>
<td class=ar>4</td>
<td class=ar>17</td>
<td class=ar>137</td>
<td class=al>&nbsp;:&nbsp;112</td>
<td class=ar>42</td>
<td class=art>131</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>26.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=40&x=374">Matýsek Daniel</a></td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>41</td>
<td class=br>21</td>
<td class=br>3</td>
<td class=br>17</td>
<td class=br>128</td>
<td class=bl>&nbsp;:&nbsp;114</td>
<td class=br>45</td>
<td class=brt>129</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>27.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=893&x=374">Škrlep Nejc</a></td>
<td class=al>* Slovenia</td>
<td class=ar>40</td>
<td class=ar>19</td>
<td class=ar>4</td>
<td class=ar>17</td>
<td class=ar>134</td>
<td class=al>&nbsp;:&nbsp;123</td>
<td class=ar>42</td>
<td class=art>127</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>28.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=310&x=374">Černoch Miroslav</a></td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>40</td>
<td class=br>19</td>
<td class=br>6</td>
<td class=br>15</td>
<td class=br>113</td>
<td class=bl>&nbsp;:&nbsp;81</td>
<td class=br>44</td>
<td class=brt>126</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>29.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=4&x=374">Kraus Vladimír</a></td>
<td class=al>Rokycany</td>
<td class=ar>41</td>
<td class=ar>17</td>
<td class=ar>5</td>
<td class=ar>19</td>
<td class=ar>128</td>
<td class=al>&nbsp;:&nbsp;116</td>
<td class=ar>39</td>
<td class=art>125</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>30.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1974&x=374">Obadič Jakob Zalokar</a></td>
<td class=bl>* Slovenia</td>
<td class=br>41</td>
<td class=br>16</td>
<td class=br>5</td>
<td class=br>20</td>
<td class=br>117</td>
<td class=bl>&nbsp;:&nbsp;140</td>
<td class=br>37</td>
<td class=brt>124</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>31.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=176&x=374">Lopaur Zdeněk</a></td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>41</td>
<td class=ar>15</td>
<td class=ar>6</td>
<td class=ar>20</td>
<td class=ar>123</td>
<td class=al>&nbsp;:&nbsp;123</td>
<td class=ar>36</td>
<td class=art>123</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>32.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1977&x=374">Dion Till</a></td>
<td class=bl>* Germany</td>
<td class=br>40</td>
<td class=br>13</td>
<td class=br>10</td>
<td class=br>17</td>
<td class=br>114</td>
<td class=bl>&nbsp;:&nbsp;119</td>
<td class=br>36</td>
<td class=brt>122</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>33.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=841&x=374">Ležík Matěj</a></td>
<td class=al>Hradec Králové</td>
<td class=ar>36</td>
<td class=ar>12</td>
<td class=ar>11</td>
<td class=ar>13</td>
<td class=ar>110</td>
<td class=al>&nbsp;:&nbsp;106</td>
<td class=ar>35</td>
<td class=art>120</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>34.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1118&x=374">Kahoun Lukáš</a></td>
<td class=bl>BSE United</td>
<td class=br>36</td>
<td class=br>16</td>
<td class=br>7</td>
<td class=br>13</td>
<td class=br>95</td>
<td class=bl>&nbsp;:&nbsp;104</td>
<td class=br>39</td>
<td class=brt>119</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>35.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=53&x=374">Pikl Václav</a></td>
<td class=al>THC Stiga Elites</td>
<td class=ar>37</td>
<td class=ar>15</td>
<td class=ar>9</td>
<td class=ar>13</td>
<td class=ar>114</td>
<td class=al>&nbsp;:&nbsp;81</td>
<td class=ar>39</td>
<td class=art>118</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>36.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1065&x=374">Herold Kryštof</a></td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>36</td>
<td class=br>15</td>
<td class=br>5</td>
<td class=br>16</td>
<td class=br>100</td>
<td class=bl>&nbsp;:&nbsp;90</td>
<td class=br>35</td>
<td class=brt>117</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>37.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1912&x=374">Krejza Aleš</a></td>
<td class=al>THC Třinec</td>
<td class=ar>37</td>
<td class=ar>13</td>
<td class=ar>10</td>
<td class=ar>14</td>
<td class=ar>90</td>
<td class=al>&nbsp;:&nbsp;86</td>
<td class=ar>36</td>
<td class=art>116</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>38.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1876&x=374">Kopřiva Adam</a></td>
<td class=bl>BSE United</td>
<td class=br>36</td>
<td class=br>13</td>
<td class=br>5</td>
<td class=br>18</td>
<td class=br>92</td>
<td class=bl>&nbsp;:&nbsp;121</td>
<td class=br>31</td>
<td class=brt>115</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>39.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1709&x=374">Blažek Michal</a></td>
<td class=al>BSE United</td>
<td class=ar>36</td>
<td class=ar>12</td>
<td class=ar>12</td>
<td class=ar>12</td>
<td class=ar>82</td>
<td class=al>&nbsp;:&nbsp;87</td>
<td class=ar>36</td>
<td class=art>114</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>40.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1117&x=374">Kahoun ml. Tomáš</a></td>
<td class=bl>BSE United</td>
<td class=br>37</td>
<td class=br>14</td>
<td class=br>3</td>
<td class=br>20</td>
<td class=br>87</td>
<td class=bl>&nbsp;:&nbsp;101</td>
<td class=br>31</td>
<td class=brt>113</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>41.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=261&x=374">Cibulka David</a></td>
<td class=al>THC Třinec</td>
<td class=ar>36</td>
<td class=ar>14</td>
<td class=ar>4</td>
<td class=ar>18</td>
<td class=ar>91</td>
<td class=al>&nbsp;:&nbsp;99</td>
<td class=ar>32</td>
<td class=art>112</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>42.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1978&x=374">Verbytskyy Mykola</a></td>
<td class=bl>* Ukraine</td>
<td class=br>36</td>
<td class=br>11</td>
<td class=br>3</td>
<td class=br>22</td>
<td class=br>62</td>
<td class=bl>&nbsp;:&nbsp;98</td>
<td class=br>25</td>
<td class=brt>111</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>43.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=201&x=374">Bucek Tomáš</a></td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>36</td>
<td class=ar>12</td>
<td class=ar>5</td>
<td class=ar>19</td>
<td class=ar>106</td>
<td class=al>&nbsp;:&nbsp;106</td>
<td class=ar>29</td>
<td class=art>110</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>44.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1488&x=374">Pommerenke Ralph</a></td>
<td class=bl>* Germany</td>
<td class=br>36</td>
<td class=br>11</td>
<td class=br>5</td>
<td class=br>20</td>
<td class=br>82</td>
<td class=bl>&nbsp;:&nbsp;109</td>
<td class=br>27</td>
<td class=brt>109</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>45.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=108&x=374">Hejda Roman</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>37</td>
<td class=ar>10</td>
<td class=ar>8</td>
<td class=ar>19</td>
<td class=ar>93</td>
<td class=al>&nbsp;:&nbsp;115</td>
<td class=ar>28</td>
<td class=art>108</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>46.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=26&x=374">Ševr Miloš</a></td>
<td class=bl>THC Stiga Elites</td>
<td class=br>36</td>
<td class=br>11</td>
<td class=br>5</td>
<td class=br>20</td>
<td class=br>88</td>
<td class=bl>&nbsp;:&nbsp;106</td>
<td class=br>27</td>
<td class=brt>106</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>47.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=70&x=374">Srba Stanislav</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>36</td>
<td class=ar>11</td>
<td class=ar>5</td>
<td class=ar>20</td>
<td class=ar>64</td>
<td class=al>&nbsp;:&nbsp;115</td>
<td class=ar>27</td>
<td class=art>104</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>48.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=818&x=374">Jež Robert</a></td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>36</td>
<td class=br>8</td>
<td class=br>4</td>
<td class=br>24</td>
<td class=br>78</td>
<td class=bl>&nbsp;:&nbsp;115</td>
<td class=br>20</td>
<td class=brt>103</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>49.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1599&x=374">Uhlíř Miroslav</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>41</td>
<td class=ar>21</td>
<td class=ar>6</td>
<td class=ar>14</td>
<td class=ar>156</td>
<td class=al>&nbsp;:&nbsp;130</td>
<td class=ar>48</td>
<td class=art>102</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>50.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1630&x=374">Holub Petr</a></td>
<td class=bl>SHC Cheb</td>
<td class=br>39</td>
<td class=br>15</td>
<td class=br>8</td>
<td class=br>16</td>
<td class=br>92</td>
<td class=bl>&nbsp;:&nbsp;105</td>
<td class=br>38</td>
<td class=brt>101</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>51.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1966&x=374">Čepička Jan</a></td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>36</td>
<td class=ar>14</td>
<td class=ar>1</td>
<td class=ar>21</td>
<td class=ar>91</td>
<td class=al>&nbsp;:&nbsp;129</td>
<td class=ar>29</td>
<td class=art>100</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>52.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=999&x=374">Halama Tomáš</a></td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>38</td>
<td class=br>14</td>
<td class=br>4</td>
<td class=br>20</td>
<td class=br>96</td>
<td class=bl>&nbsp;:&nbsp;122</td>
<td class=br>32</td>
<td class=brt>99</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>53.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1058&x=374">Marek František</a></td>
<td class=al>BSE United</td>
<td class=ar>33</td>
<td class=ar>12</td>
<td class=ar>4</td>
<td class=ar>17</td>
<td class=ar>86</td>
<td class=al>&nbsp;:&nbsp;100</td>
<td class=ar>28</td>
<td class=art>98</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>54.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1657&x=374">Perkner Jonáš</a></td>
<td class=bl>Big Band</td>
<td class=br>34</td>
<td class=br>15</td>
<td class=br>3</td>
<td class=br>16</td>
<td class=br>76</td>
<td class=bl>&nbsp;:&nbsp;94</td>
<td class=br>33</td>
<td class=brt>97</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>55.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1318&x=374">Sedláček Josef</a></td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>34</td>
<td class=ar>13</td>
<td class=ar>6</td>
<td class=ar>15</td>
<td class=ar>95</td>
<td class=al>&nbsp;:&nbsp;101</td>
<td class=ar>32</td>
<td class=art>96</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>56.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1979&x=374">Bohinc Gal</a></td>
<td class=bl>* Slovenia</td>
<td class=br>34</td>
<td class=br>12</td>
<td class=br>9</td>
<td class=br>13</td>
<td class=br>71</td>
<td class=bl>&nbsp;:&nbsp;76</td>
<td class=br>33</td>
<td class=brt>95</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>57.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1872&x=374">Fuchs Petr</a></td>
<td class=al>Big Band</td>
<td class=ar>33</td>
<td class=ar>10</td>
<td class=ar>5</td>
<td class=ar>18</td>
<td class=ar>65</td>
<td class=al>&nbsp;:&nbsp;105</td>
<td class=ar>25</td>
<td class=art>94</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>58.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=204&x=374">Nechutný Hynek</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>34</td>
<td class=br>13</td>
<td class=br>6</td>
<td class=br>15</td>
<td class=br>82</td>
<td class=bl>&nbsp;:&nbsp;84</td>
<td class=br>32</td>
<td class=brt>93</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>59.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1983&x=374">Božič Aljaž</a></td>
<td class=al>* Slovenia</td>
<td class=ar>33</td>
<td class=ar>12</td>
<td class=ar>2</td>
<td class=ar>19</td>
<td class=ar>78</td>
<td class=al>&nbsp;:&nbsp;97</td>
<td class=ar>26</td>
<td class=art>92</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>60.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1405&x=374">Kubrt Pavel</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>33</td>
<td class=br>8</td>
<td class=br>7</td>
<td class=br>18</td>
<td class=br>79</td>
<td class=bl>&nbsp;:&nbsp;107</td>
<td class=br>23</td>
<td class=brt>91</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>61.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1980&x=374">Zalite Janis</a></td>
<td class=al>* Latvia</td>
<td class=ar>33</td>
<td class=ar>11</td>
<td class=ar>5</td>
<td class=ar>17</td>
<td class=ar>87</td>
<td class=al>&nbsp;:&nbsp;103</td>
<td class=ar>27</td>
<td class=art>90</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>62.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1941&x=374">Kopecký Jaroslav</a></td>
<td class=bl>SHC Cheb</td>
<td class=br>33</td>
<td class=br>7</td>
<td class=br>5</td>
<td class=br>21</td>
<td class=br>54</td>
<td class=bl>&nbsp;:&nbsp;124</td>
<td class=br>19</td>
<td class=brt>89</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>63.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1645&x=374">Grimová Anita</a></td>
<td class=al>Příbram</td>
<td class=ar>33</td>
<td class=ar>8</td>
<td class=ar>5</td>
<td class=ar>20</td>
<td class=ar>81</td>
<td class=al>&nbsp;:&nbsp;132</td>
<td class=ar>21</td>
<td class=art>88</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>64.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1981&x=374">Kvasnikova Polina</a></td>
<td class=bl>* Ukraine</td>
<td class=br>33</td>
<td class=br>8</td>
<td class=br>2</td>
<td class=br>23</td>
<td class=br>59</td>
<td class=bl>&nbsp;:&nbsp;119</td>
<td class=br>18</td>
<td class=brt>87</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>65.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1940&x=374">Košňar Martin</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>37</td>
<td class=ar>19</td>
<td class=ar>4</td>
<td class=ar>14</td>
<td class=ar>107</td>
<td class=al>&nbsp;:&nbsp;87</td>
<td class=ar>42</td>
<td class=art>86</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>66.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1968&x=374">Touš Michal</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>39</td>
<td class=br>12</td>
<td class=br>2</td>
<td class=br>25</td>
<td class=br>109</td>
<td class=bl>&nbsp;:&nbsp;148</td>
<td class=br>26</td>
<td class=brt>85</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>67.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1927&x=374">Kraus Vojtěch</a></td>
<td class=al>Rokycany</td>
<td class=ar>35</td>
<td class=ar>15</td>
<td class=ar>1</td>
<td class=ar>19</td>
<td class=ar>93</td>
<td class=al>&nbsp;:&nbsp;127</td>
<td class=ar>31</td>
<td class=art>84</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>68.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1430&x=374">Kadlec Daniel</a></td>
<td class=bl>Big Band</td>
<td class=br>33</td>
<td class=br>8</td>
<td class=br>1</td>
<td class=br>24</td>
<td class=br>60</td>
<td class=bl>&nbsp;:&nbsp;164</td>
<td class=br>17</td>
<td class=brt>83</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>69.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1973&x=374">Sabo Branislav</a></td>
<td class=al>*THC Predators (SVK)</td>
<td class=ar>31</td>
<td class=ar>10</td>
<td class=ar>3</td>
<td class=ar>18</td>
<td class=ar>68</td>
<td class=al>&nbsp;:&nbsp;103</td>
<td class=ar>23</td>
<td class=art>82</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>70.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1984&x=374">Brodacký Karel</a></td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>30</td>
<td class=br>6</td>
<td class=br>1</td>
<td class=br>23</td>
<td class=br>67</td>
<td class=bl>&nbsp;:&nbsp;195</td>
<td class=br>13</td>
<td class=brt>81</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>71.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1869&x=374">Klazar Petr</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>30</td>
<td class=ar>5</td>
<td class=ar>3</td>
<td class=ar>22</td>
<td class=ar>50</td>
<td class=al>&nbsp;:&nbsp;119</td>
<td class=ar>13</td>
<td class=art>80</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>72.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1881&x=374">Werner Filip</a></td>
<td class=bl>THC Stiga-Game Příbram</td>
<td class=br>31</td>
<td class=br>7</td>
<td class=br>5</td>
<td class=br>19</td>
<td class=br>42</td>
<td class=bl>&nbsp;:&nbsp;127</td>
<td class=br>19</td>
<td class=brt>79</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>73.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1947&x=374">Holub Lukáš</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>30</td>
<td class=ar>6</td>
<td class=ar>0</td>
<td class=ar>24</td>
<td class=ar>53</td>
<td class=al>&nbsp;:&nbsp;144</td>
<td class=ar>12</td>
<td class=art>78</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>74.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1626&x=374">Horáková Miroslava</a></td>
<td class=bl>SHC Cheb</td>
<td class=br>30</td>
<td class=br>7</td>
<td class=br>1</td>
<td class=br>22</td>
<td class=br>72</td>
<td class=bl>&nbsp;:&nbsp;152</td>
<td class=br>15</td>
<td class=brt>77</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>75.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1923&x=374">Vacke Vojtěch</a></td>
<td class=al>BSE United</td>
<td class=ar>31</td>
<td class=ar>5</td>
<td class=ar>1</td>
<td class=ar>25</td>
<td class=ar>64</td>
<td class=al>&nbsp;:&nbsp;141</td>
<td class=ar>11</td>
<td class=art>76</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>76.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1076&x=374">Zeman Milan</a></td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>30</td>
<td class=br>3</td>
<td class=br>1</td>
<td class=br>26</td>
<td class=br>39</td>
<td class=bl>&nbsp;:&nbsp;127</td>
<td class=br>7</td>
<td class=brt>75</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>77.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1982&x=374">Čermák Jan</a></td>
<td class=al>Praha</td>
<td class=ar>31</td>
<td class=ar>0</td>
<td class=ar>0</td>
<td class=ar>31</td>
<td class=ar>20</td>
<td class=al>&nbsp;:&nbsp;178</td>
<td class=ar>0</td>
<td class=art>74</td>
<td class=ar>&nbsp;</td>
</tr></table></td></tr></table></div></p>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
