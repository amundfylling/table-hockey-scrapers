<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2022">Czech Open </a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 3</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=57&x=374">Zd Matoušek ml.</a></td><td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=kW>4:2</td>
<td class=kW>9:0</td>
<td class=kW>8:2</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>8:2</td>
<td class=kW>9:2</td>
<td class=kW>10:1</td>
<td class=kW>15:0</td>
<td class=br>111:24</td><td class=br>+87</td>
<td class=bc>17 - 1 - 0</td>
<td class=br><strong>35</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=310&x=374">Mi Černoch</a></td><td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kW>9:1</td>
<td class=kW>6:1</td>
<td class=kW>10:1</td>
<td class=br>73:25</td><td class=br>+48</td>
<td class=bc>13 - 2 - 3</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1976&x=374">Jo Astrom</a></td><td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>10:2</td>
<td class=kW>8:3</td>
<td class=kW>7:1</td>
<td class=kW>11:0</td>
<td class=br>80:34</td><td class=br>+46</td>
<td class=bc>13 - 2 - 3</td>
<td class=br><strong>28</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1&x=374">Pa Plešák</a></td><td class=kL>3:5</td>
<td class=kW>2:0</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>10:2</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kW>7:3</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>9:0</td>
<td class=kW>10:4</td>
<td class=kW>4:0</td>
<td class=kW>14:0</td>
<td class=br>95:39</td><td class=br>+56</td>
<td class=bc>11 - 5 - 2</td>
<td class=br><strong>27</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=559&x=374">Bj Axelsen</a></td><td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kW>5:3</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>6:4</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>9:3</td>
<td class=kW>4:1</td>
<td class=kW>11:0</td>
<td class=br>77:43</td><td class=br>+34</td>
<td class=bc>12 - 2 - 4</td>
<td class=br><strong>26</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1251&x=374">Ho Sládek</a></td><td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kL>4:5</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>15:5</td>
<td class=br>67:36</td><td class=br>+31</td>
<td class=bc>10 - 5 - 3</td>
<td class=br><strong>25</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1709&x=374">Mi Blažek</a></td><td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=br>50:35</td><td class=br>+15</td>
<td class=bc>9 - 5 - 4</td>
<td class=br><strong>23</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1065&x=374">Kr Herold</a></td><td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>9:2</td>
<td class=br>56:42</td><td class=br>+14</td>
<td class=bc>9 - 3 - 6</td>
<td class=br><strong>21</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=893&x=374">Ne Škrlep</a></td><td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>4:6</td>
<td class=kW>5:4</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=kW>5:4</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>6:3</td>
<td class=kL>4:5</td>
<td class=kW>8:0</td>
<td class=kW>5:1</td>
<td class=br>68:46</td><td class=br>+22</td>
<td class=bc>10 - 1 - 7</td>
<td class=br><strong>21</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1876&x=374">Ad Kopřiva</a></td><td class=kL>0:8</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>2:10</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>8:2</td>
<td class=kW>5:1</td>
<td class=kW>8:2</td>
<td class=br>55:62</td><td class=br>-7</td>
<td class=bc>10 - 0 - 8</td>
<td class=br><strong>20</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>A</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1488&x=374">Ra Pommerenke</a></td><td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>10:1</td>
<td class=br>50:45</td><td class=br>+5</td>
<td class=bc>8 - 3 - 7</td>
<td class=br><strong>19</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>A</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1978&x=374">My Verbytskyy</a></td><td class=kL>0:9</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>7:4</td>
<td class=br>39:47</td><td class=br>-8</td>
<td class=bc>6 - 2 - 10</td>
<td class=br><strong>14</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1630&x=374">Pe Holub</a></td><td class=kL>2:8</td>
<td class=kL>1:7</td>
<td class=kL>0:3</td>
<td class=kL>3:7</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kL>4:5</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=br>47:61</td><td class=br>-14</td>
<td class=bc>4 - 4 - 10</td>
<td class=br><strong>12</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>B</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1983&x=374">Al Božič</a></td><td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kL>1:4</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=br>45:62</td><td class=br>-17</td>
<td class=bc>6 - 0 - 12</td>
<td class=br><strong>12</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>B</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1058&x=374">Fr Marek</a></td><td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kW>5:1</td>
<td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>10:1</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=br>41:57</td><td class=br>-16</td>
<td class=bc>5 - 2 - 11</td>
<td class=br><strong>12</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>B</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1966&x=374">Ja Čepička</a></td><td class=kL>2:8</td>
<td class=kL>0:7</td>
<td class=kL>2:10</td>
<td class=kL>0:9</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=br>38:80</td><td class=br>-42</td>
<td class=bc>4 - 1 - 13</td>
<td class=br><strong>9</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>C</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1626&x=374">Mi Horáková</a></td><td class=kL>2:9</td>
<td class=kL>1:9</td>
<td class=kL>3:8</td>
<td class=kL>4:10</td>
<td class=kL>3:9</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kW>5:4</td>
<td class=kL>2:8</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kW>4:1</td>
<td class=kL>1:10</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:5</td>
<td class=br>43:107</td><td class=br>-64</td>
<td class=bc>3 - 1 - 14</td>
<td class=br><strong>7</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>C</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1076&x=374">Mi Zeman</a></td><td class=kL>1:10</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=br>19:83</td><td class=br>-64</td>
<td class=bc>1 - 1 - 16</td>
<td class=br><strong>3</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>C</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1984&x=374">Ka Brodacký</a></td><td class=kL>0:15</td>
<td class=kL>1:10</td>
<td class=kL>0:11</td>
<td class=kL>0:14</td>
<td class=kL>0:11</td>
<td class=kL>5:15</td>
<td class=kL>1:3</td>
<td class=kL>2:9</td>
<td class=kL>1:5</td>
<td class=kL>2:8</td>
<td class=kL>1:10</td>
<td class=kL>4:7</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>5:6</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=br>27:153</td><td class=br>-126</td>
<td class=bc>0 - 0 - 18</td>
<td class=br><strong>0</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al Božič</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ka Brodacký</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Božič</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ka Brodacký</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 15</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Al Božič</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ka Brodacký</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Ja Čepička</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Al Božič</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ka Brodacký</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Ka Brodacký</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 10</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>9 : 3</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Božič</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Al Božič</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Ka Brodacký</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>10 : 2</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Al Božič</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Ka Brodacký</td><td class=bc>11 : 0</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ja Čepička</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Ka Brodacký</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Al Božič</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Ka Brodacký</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Al Božič</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ka Brodacký</td><td class=bc>14 : 0</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Al Božič</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Ka Brodacký</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Al Božič</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Ja Čepička</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Ka Brodacký</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Al Božič</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ka Brodacký</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Al Božič</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 10</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ja Čepička</td><td class=bc>-</td><td class=bl>Ka Brodacký</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Al Božič</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ka Brodacký</td><td class=bc>-</td><td class=blW>Al Božič</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Al Božič</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ka Brodacký</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>2 : 10</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Božič</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>4 : 10</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Ka Brodacký</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Al Božič</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ka Brodacký</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>5 : 15</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
