<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2022">Czech Open </a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1599&x=374">Mi Uhlíř</a></td><td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>4:5</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=kW>6:1</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>5:6</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=br>65:40</td><td class=br>+25</td>
<td class=bc>9 - 3 - 3</td>
<td class=br><strong>21</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1630&x=374">Pe Holub</a></td><td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=br>30:28</td><td class=br>+2</td>
<td class=bc>8 - 4 - 3</td>
<td class=br><strong>20</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1966&x=374">Ja Čepička</a></td><td class=kW>5:4</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>7:4</td>
<td class=kL>4:7</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=br>48:38</td><td class=br>+10</td>
<td class=bc>10 - 0 - 5</td>
<td class=br><strong>20</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=999&x=374">To Halama</a></td><td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=br>36:30</td><td class=br>+6</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1058&x=374">Fr Marek</a></td><td class=kL>3:6</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kW>4:0</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=br>45:43</td><td class=br>+2</td>
<td class=bc>7 - 2 - 6</td>
<td class=br><strong>16</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1657&x=374">Jo Perkner</a></td><td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=br>34:39</td><td class=br>-5</td>
<td class=bc>7 - 2 - 6</td>
<td class=br><strong>16</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1318&x=374">Jo Sedláček</a></td><td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kL>4:8</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=br>47:40</td><td class=br>+7</td>
<td class=bc>7 - 2 - 6</td>
<td class=br><strong>16</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1979&x=374">Ga Bohinc</a></td><td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>8:0</td>
<td class=br>41:30</td><td class=br>+11</td>
<td class=bc>6 - 3 - 6</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1872&x=374">Pe Fuchs</a></td><td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kL>0:3</td>
<td class=kW>7:3</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=br>39:42</td><td class=br>-3</td>
<td class=bc>6 - 3 - 6</td>
<td class=br><strong>15</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=204&x=374">Hy Nechutný</a></td><td class=kL>2:7</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kL>1:6</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=br>41:40</td><td class=br>+1</td>
<td class=bc>6 - 3 - 6</td>
<td class=br><strong>15</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1983&x=374">Al Božič</a></td><td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kW>3:0</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=br>33:35</td><td class=br>-2</td>
<td class=bc>6 - 2 - 7</td>
<td class=br><strong>14</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1405&x=374">Pa Kubrt</a></td><td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>4:7</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>3:7</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>4:5</td>
<td class=kL>3:4</td>
<td class=br>47:46</td><td class=br>+1</td>
<td class=bc>5 - 4 - 6</td>
<td class=br><strong>14</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1980&x=374">Ja Zalite</a></td><td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kW>7:4</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kW>8:4</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=br>49:43</td><td class=br>+6</td>
<td class=bc>5 - 4 - 6</td>
<td class=br><strong>14</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1941&x=374">Ja Kopecký</a></td><td class=kW>6:5</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>0:5</td>
<td class=br>27:48</td><td class=br>-21</td>
<td class=bc>3 - 3 - 9</td>
<td class=br><strong>9</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1645&x=374">An Grimová</a></td><td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=br>36:53</td><td class=br>-17</td>
<td class=bc>3 - 3 - 9</td>
<td class=br><strong>9</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1981&x=374">Po Kvasnikova</a></td><td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>0:8</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kW>5:0</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=br>29:52</td><td class=br>-23</td>
<td class=bc>4 - 0 - 11</td>
<td class=br><strong>8</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ja Zalite</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Ja Čepička</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Pa Kubrt</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Al Božič</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>4 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ja Zalite</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Al Božič</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ja Čepička</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ja Zalite</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ga Bohinc</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=bl>Al Božič</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Pa Kubrt</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ja Zalite</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ga Bohinc</td><td class=bc>-</td><td class=bl>Al Božič</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Pa Kubrt</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ja Čepička</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ja Zalite</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Al Božič</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ga Bohinc</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>8 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pa Kubrt</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ja Čepička</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Al Božič</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ja Zalite</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Al Božič</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ja Čepička</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ja Zalite</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Al Božič</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Po Kvasnikova</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ja Čepička</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ja Zalite</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Al Božič</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ja Kopecký</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>Ja Zalite</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Po Kvasnikova</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=bl>Ja Zalite</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Al Božič</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ja Zalite</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>Ja Čepička</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Al Božič</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ja Zalite</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ja Čepička</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Al Božič</td><td class=bc>-</td><td class=bl>Ja Zalite</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ja Čepička</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Pa Kubrt</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Ja Zalite</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Al Božič</td><td class=bc>-</td><td class=blW>Ja Čepička</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ja Kopecký</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Ja Zalite</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ja Kopecký</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Al Božič</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ga Bohinc</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Al Božič</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
