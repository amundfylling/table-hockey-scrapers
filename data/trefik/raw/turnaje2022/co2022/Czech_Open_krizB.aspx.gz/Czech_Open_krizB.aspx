<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2022">Czech Open </a></span></h2></div></div></div></div><h3 align="right">Basic Groups&nbsp;&nbsp;</h3>
<p><div align="center">
<a href="Czech_Open_krizF.aspx#final">Final Groups</a><br>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1649&x=374">Ra Miglinieks</a></td><td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>9:1</td>
<td class=kW>9:2</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>9:1</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>8:1</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>11:2</td>
<td class=kW>11:2</td>
<td class=br>113:25</td><td class=br>+88</td>
<td class=bc>18 - 0 - 0</td>
<td class=br><strong>36</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=961&x=374">Mi Boštík</a></td><td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>7:1</td>
<td class=kW>6:2</td>
<td class=br>80:22</td><td class=br>+58</td>
<td class=bc>14 - 2 - 2</td>
<td class=br><strong>30</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1650&x=374">Va Dietze</a></td><td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=kW>7:4</td>
<td class=kW>6:1</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>7:3</td>
<td class=kW>3:0</td>
<td class=br>71:40</td><td class=br>+31</td>
<td class=bc>11 - 3 - 4</td>
<td class=br><strong>25</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=386&x=374">Ku Sládek</a></td><td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>7:1</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=br>53:32</td><td class=br>+21</td>
<td class=bc>11 - 3 - 4</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1815&x=374">An Božič</a></td><td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=br>53:33</td><td class=br>+20</td>
<td class=bc>11 - 2 - 5</td>
<td class=br><strong>24</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=26&x=374">Mi Ševr</a></td><td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kT>5:5</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kW>6:3</td>
<td class=kW>9:0</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=br>60:42</td><td class=br>+18</td>
<td class=bc>10 - 3 - 5</td>
<td class=br><strong>23</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=18&x=374">An Šurýn</a></td><td class=kL>1:9</td>
<td class=kL>0:4</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=br>36:33</td><td class=br>+3</td>
<td class=bc>10 - 3 - 5</td>
<td class=br><strong>23</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1845&x=374">My Shalomayev</a></td><td class=kL>2:9</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>7:0</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=br>53:46</td><td class=br>+7</td>
<td class=bc>10 - 1 - 7</td>
<td class=br><strong>21</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=448&x=374">To Waclawek</a></td><td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kW>6:2</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>9:3</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kW>8:1</td>
<td class=kW>9:1</td>
<td class=kW>5:1</td>
<td class=br>64:48</td><td class=br>+16</td>
<td class=bc>10 - 0 - 8</td>
<td class=br><strong>20</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=841&x=374">Ma Ležík</a></td><td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>4:7</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kT>5:5</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>7:3</td>
<td class=kW>6:2</td>
<td class=br>61:50</td><td class=br>+11</td>
<td class=bc>8 - 4 - 6</td>
<td class=br><strong>20</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>A</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=70&x=374">St Srba</a></td><td class=kL>1:9</td>
<td class=kL>0:8</td>
<td class=kL>1:6</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kL>3:9</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kT>0:0</td>
<td class=br>37:44</td><td class=br>-7</td>
<td class=bc>8 - 4 - 6</td>
<td class=br><strong>20</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>A</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=261&x=374">Da Cibulka</a></td><td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>7:0</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kT>1:1</td>
<td class=kW>6:5</td>
<td class=kW>4:2</td>
<td class=br>50:40</td><td class=br>+10</td>
<td class=bc>9 - 1 - 8</td>
<td class=br><strong>19</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1980&x=374">Ja Zalite</a></td><td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>0:7</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=br>38:60</td><td class=br>-22</td>
<td class=bc>6 - 1 - 11</td>
<td class=br><strong>13</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>B</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1981&x=374">Po Kvasnikova</a></td><td class=kL>1:8</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kL>0:9</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=br>30:67</td><td class=br>-37</td>
<td class=bc>4 - 2 - 12</td>
<td class=br><strong>10</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>B</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1872&x=374">Pe Fuchs</a></td><td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=br>26:63</td><td class=br>-37</td>
<td class=bc>4 - 2 - 12</td>
<td class=br><strong>10</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>B</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1405&x=374">Pa Kubrt</a></td><td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>0:6</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=br>32:61</td><td class=br>-29</td>
<td class=bc>3 - 3 - 12</td>
<td class=br><strong>9</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>C</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1940&x=374">Ma Košňar</a></td><td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>0:7</td>
<td class=kL>1:8</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=br>29:62</td><td class=br>-33</td>
<td class=bc>3 - 3 - 12</td>
<td class=br><strong>9</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>C</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1968&x=374">Mi Touš</a></td><td class=kL>2:11</td>
<td class=kL>1:7</td>
<td class=kL>3:7</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>1:9</td>
<td class=kL>3:7</td>
<td class=kL>1:3</td>
<td class=kL>5:6</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>7:0</td>
<td class=br>40:89</td><td class=br>-49</td>
<td class=bc>2 - 0 - 16</td>
<td class=br><strong>4</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>C</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1869&x=374">Pe Klazar</a></td><td class=kL>2:11</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kT>0:0</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kx>*</td>
<td class=br>22:91</td><td class=br>-69</td>
<td class=bc>0 - 1 - 17</td>
<td class=br><strong>1</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ja Zalite</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ja Zalite</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Ja Zalite</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ja Zalite</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Po Kvasnikova</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Pa Kubrt</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ja Zalite</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ja Zalite</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ja Zalite</td><td class=bc>-</td><td class=blW>Pa Kubrt</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Pa Kubrt</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ja Zalite</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Ma Ležík</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Touš</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Zalite</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ma Ležík</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ja Zalite</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>11 : 2</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Ja Zalite</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ja Zalite</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ma Ležík</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ja Zalite</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>3 : 9</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Po Kvasnikova</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ja Zalite</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Ja Zalite</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>11 : 2</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Ja Zalite</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ja Zalite</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Ja Zalite</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Mi Touš</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ma Ležík</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>0 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1174&x=374">Ma Maděra</a></td><td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kW>8:2</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>8:4</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kW>10:1</td>
<td class=kW>7:2</td>
<td class=br>86:33</td><td class=br>+53</td>
<td class=bc>14 - 2 - 2</td>
<td class=br><strong>30</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=409&x=374">Pa Petr</a></td><td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>2:7</td>
<td class=kW>6:3</td>
<td class=kW>6:1</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>9:2</td>
<td class=kW>9:2</td>
<td class=kW>4:0</td>
<td class=kW>9:1</td>
<td class=kW>12:1</td>
<td class=kW>11:0</td>
<td class=kW>12:1</td>
<td class=br>111:35</td><td class=br>+76</td>
<td class=bc>14 - 1 - 3</td>
<td class=br><strong>29</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1503&x=374">Ve Huotelin</a></td><td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kW>7:0</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kW>11:1</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kW>7:3</td>
<td class=kW>6:0</td>
<td class=kW>9:1</td>
<td class=br>90:38</td><td class=br>+52</td>
<td class=bc>11 - 4 - 3</td>
<td class=br><strong>26</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1975&x=374">Gu Hermansson</a></td><td class=kL>2:8</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kL>2:5</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>8:3</td>
<td class=kW>8:1</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=br>76:43</td><td class=br>+33</td>
<td class=bc>12 - 2 - 4</td>
<td class=br><strong>26</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=842&x=374">Ma Lisý</a></td><td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>9:0</td>
<td class=kW>8:1</td>
<td class=br>61:32</td><td class=br>+29</td>
<td class=bc>11 - 3 - 4</td>
<td class=br><strong>25</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=40&x=374">Da Matýsek</a></td><td class=kL>0:3</td>
<td class=kL>3:6</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kL>4:8</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>9:2</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>9:2</td>
<td class=br>67:42</td><td class=br>+25</td>
<td class=bc>12 - 1 - 5</td>
<td class=br><strong>25</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=248&x=374">Ma Ženíšek</a></td><td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kW>6:4</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>8:2</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>9:3</td>
<td class=br>79:47</td><td class=br>+32</td>
<td class=bc>11 - 2 - 5</td>
<td class=br><strong>24</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1118&x=374">Lu Kahoun</a></td><td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>7:3</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=br>55:42</td><td class=br>+13</td>
<td class=bc>10 - 4 - 4</td>
<td class=br><strong>24</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1644&x=374">To Růžička</a></td><td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kW>6:3</td>
<td class=kL>2:5</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kL>3:5</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>9:1</td>
<td class=br>67:40</td><td class=br>+27</td>
<td class=bc>10 - 2 - 6</td>
<td class=br><strong>22</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1977&x=374">Ti Dion</a></td><td class=kL>4:8</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kW>8:4</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=br>61:45</td><td class=br>+16</td>
<td class=bc>8 - 5 - 5</td>
<td class=br><strong>21</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>A</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=818&x=374">Ro Jež</a></td><td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kL>2:4</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>9:0</td>
<td class=br>54:49</td><td class=br>+5</td>
<td class=bc>8 - 3 - 7</td>
<td class=br><strong>19</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>A</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=201&x=374">To Bucek</a></td><td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>4:6</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=kW>4:3</td>
<td class=kW>7:0</td>
<td class=kW>10:0</td>
<td class=br>67:48</td><td class=br>+19</td>
<td class=bc>8 - 2 - 8</td>
<td class=br><strong>18</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1599&x=374">Mi Uhlíř</a></td><td class=kL>1:3</td>
<td class=kL>2:9</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kL>3:7</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kW>7:3</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>8:0</td>
<td class=br>66:71</td><td class=br>-5</td>
<td class=bc>6 - 3 - 9</td>
<td class=br><strong>15</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>B</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1645&x=374">An Grimová</a></td><td class=kL>0:3</td>
<td class=kL>2:9</td>
<td class=kL>1:11</td>
<td class=kL>3:8</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>0:6</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=br>45:79</td><td class=br>-34</td>
<td class=bc>5 - 2 - 11</td>
<td class=br><strong>12</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>B</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=999&x=374">To Halama</a></td><td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>1:7</td>
<td class=kL>1:8</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>0:7</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kL>2:7</td>
<td class=kL>3:7</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>9:0</td>
<td class=kW>9:2</td>
<td class=br>45:78</td><td class=br>-33</td>
<td class=bc>4 - 2 - 12</td>
<td class=br><strong>10</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>B</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1941&x=374">Ja Kopecký</a></td><td class=kL>2:5</td>
<td class=kL>1:9</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>2:9</td>
<td class=kL>2:8</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=br>27:76</td><td class=br>-49</td>
<td class=bc>4 - 2 - 12</td>
<td class=br><strong>10</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>C</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1927&x=374">Vojta Kraus</a></td><td class=kL>0:7</td>
<td class=kL>1:12</td>
<td class=kL>3:7</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=br>26:87</td><td class=br>-61</td>
<td class=bc>2 - 0 - 16</td>
<td class=br><strong>4</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>C</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1947&x=374">Lu Holub</a></td><td class=kL>1:10</td>
<td class=kL>0:11</td>
<td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kL>0:9</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>3:6</td>
<td class=kL>0:9</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=br>19:108</td><td class=br>-89</td>
<td class=bc>1 - 0 - 17</td>
<td class=br><strong>2</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>C</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1430&x=374">Da Kadlec</a></td><td class=kL>2:7</td>
<td class=kL>1:12</td>
<td class=kL>1:9</td>
<td class=kL>0:3</td>
<td class=kL>1:8</td>
<td class=kL>2:9</td>
<td class=kL>3:9</td>
<td class=kL>1:5</td>
<td class=kL>1:9</td>
<td class=kL>0:4</td>
<td class=kL>0:9</td>
<td class=kL>0:10</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>2:9</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=br>20:129</td><td class=br>-109</td>
<td class=bc>0 - 0 - 18</td>
<td class=br><strong>0</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>Ma Lisý</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Ja Kopecký</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ma Lisý</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Vojta Kraus</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>4 : 8</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ma Lisý</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>9 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ma Lisý</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ja Kopecký</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Ma Lisý</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>An Grimová</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Ma Lisý</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>1 : 11</tr></td>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>9 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Ma Lisý</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>3 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ma Lisý</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>12 : 1</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Ja Kopecký</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Lisý</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Vojta Kraus</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Lisý</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>To Růžička</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Ma Lisý</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ja Kopecký</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ma Lisý</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>4 : 8</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>To Růžička</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Lu Holub</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Lisý</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>9 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>To Halama</td><td class=bc>2 : 9</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Lisý</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Lisý</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>To Halama</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>An Grimová</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>3 : 9</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 12</tr></td>
<tr><td class=br>Ma Lisý</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>To Halama</td><td class=bc>-</td><td class=bl>An Grimová</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>To Růžička</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Ma Lisý</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Grimová</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>To Halama</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>To Růžička</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Ma Lisý</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>4 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 3</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=57&x=374">Zd Matoušek ml.</a></td><td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=kW>4:2</td>
<td class=kW>9:0</td>
<td class=kW>8:2</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>8:2</td>
<td class=kW>9:2</td>
<td class=kW>10:1</td>
<td class=kW>15:0</td>
<td class=br>111:24</td><td class=br>+87</td>
<td class=bc>17 - 1 - 0</td>
<td class=br><strong>35</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=310&x=374">Mi Černoch</a></td><td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kW>9:1</td>
<td class=kW>6:1</td>
<td class=kW>10:1</td>
<td class=br>73:25</td><td class=br>+48</td>
<td class=bc>13 - 2 - 3</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1976&x=374">Jo Astrom</a></td><td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>10:2</td>
<td class=kW>8:3</td>
<td class=kW>7:1</td>
<td class=kW>11:0</td>
<td class=br>80:34</td><td class=br>+46</td>
<td class=bc>13 - 2 - 3</td>
<td class=br><strong>28</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1&x=374">Pa Plešák</a></td><td class=kL>3:5</td>
<td class=kW>2:0</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>10:2</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kW>7:3</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>9:0</td>
<td class=kW>10:4</td>
<td class=kW>4:0</td>
<td class=kW>14:0</td>
<td class=br>95:39</td><td class=br>+56</td>
<td class=bc>11 - 5 - 2</td>
<td class=br><strong>27</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=559&x=374">Bj Axelsen</a></td><td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kW>5:3</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>6:4</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>9:3</td>
<td class=kW>4:1</td>
<td class=kW>11:0</td>
<td class=br>77:43</td><td class=br>+34</td>
<td class=bc>12 - 2 - 4</td>
<td class=br><strong>26</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1251&x=374">Ho Sládek</a></td><td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kL>4:5</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>15:5</td>
<td class=br>67:36</td><td class=br>+31</td>
<td class=bc>10 - 5 - 3</td>
<td class=br><strong>25</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1709&x=374">Mi Blažek</a></td><td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=br>50:35</td><td class=br>+15</td>
<td class=bc>9 - 5 - 4</td>
<td class=br><strong>23</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1065&x=374">Kr Herold</a></td><td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>9:2</td>
<td class=br>56:42</td><td class=br>+14</td>
<td class=bc>9 - 3 - 6</td>
<td class=br><strong>21</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=893&x=374">Ne Škrlep</a></td><td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>4:6</td>
<td class=kW>5:4</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=kW>5:4</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>6:3</td>
<td class=kL>4:5</td>
<td class=kW>8:0</td>
<td class=kW>5:1</td>
<td class=br>68:46</td><td class=br>+22</td>
<td class=bc>10 - 1 - 7</td>
<td class=br><strong>21</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1876&x=374">Ad Kopřiva</a></td><td class=kL>0:8</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>2:10</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>8:2</td>
<td class=kW>5:1</td>
<td class=kW>8:2</td>
<td class=br>55:62</td><td class=br>-7</td>
<td class=bc>10 - 0 - 8</td>
<td class=br><strong>20</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>A</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1488&x=374">Ra Pommerenke</a></td><td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>10:1</td>
<td class=br>50:45</td><td class=br>+5</td>
<td class=bc>8 - 3 - 7</td>
<td class=br><strong>19</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>A</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1978&x=374">My Verbytskyy</a></td><td class=kL>0:9</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>7:4</td>
<td class=br>39:47</td><td class=br>-8</td>
<td class=bc>6 - 2 - 10</td>
<td class=br><strong>14</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1630&x=374">Pe Holub</a></td><td class=kL>2:8</td>
<td class=kL>1:7</td>
<td class=kL>0:3</td>
<td class=kL>3:7</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kL>4:5</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=br>47:61</td><td class=br>-14</td>
<td class=bc>4 - 4 - 10</td>
<td class=br><strong>12</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>B</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1983&x=374">Al Božič</a></td><td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kL>1:4</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=br>45:62</td><td class=br>-17</td>
<td class=bc>6 - 0 - 12</td>
<td class=br><strong>12</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>B</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1058&x=374">Fr Marek</a></td><td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kW>5:1</td>
<td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>10:1</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=br>41:57</td><td class=br>-16</td>
<td class=bc>5 - 2 - 11</td>
<td class=br><strong>12</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>B</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1966&x=374">Ja Čepička</a></td><td class=kL>2:8</td>
<td class=kL>0:7</td>
<td class=kL>2:10</td>
<td class=kL>0:9</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=br>38:80</td><td class=br>-42</td>
<td class=bc>4 - 1 - 13</td>
<td class=br><strong>9</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>C</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1626&x=374">Mi Horáková</a></td><td class=kL>2:9</td>
<td class=kL>1:9</td>
<td class=kL>3:8</td>
<td class=kL>4:10</td>
<td class=kL>3:9</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kW>5:4</td>
<td class=kL>2:8</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kW>4:1</td>
<td class=kL>1:10</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:5</td>
<td class=br>43:107</td><td class=br>-64</td>
<td class=bc>3 - 1 - 14</td>
<td class=br><strong>7</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>C</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1076&x=374">Mi Zeman</a></td><td class=kL>1:10</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=br>19:83</td><td class=br>-64</td>
<td class=bc>1 - 1 - 16</td>
<td class=br><strong>3</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>C</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1984&x=374">Ka Brodacký</a></td><td class=kL>0:15</td>
<td class=kL>1:10</td>
<td class=kL>0:11</td>
<td class=kL>0:14</td>
<td class=kL>0:11</td>
<td class=kL>5:15</td>
<td class=kL>1:3</td>
<td class=kL>2:9</td>
<td class=kL>1:5</td>
<td class=kL>2:8</td>
<td class=kL>1:10</td>
<td class=kL>4:7</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>5:6</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=br>27:153</td><td class=br>-126</td>
<td class=bc>0 - 0 - 18</td>
<td class=br><strong>0</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al Božič</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ka Brodacký</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Božič</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ka Brodacký</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 15</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Al Božič</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ka Brodacký</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Ja Čepička</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Al Božič</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ka Brodacký</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Ka Brodacký</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 10</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>9 : 3</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Božič</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Al Božič</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mi Blažek</td><td class=bc>-</td><td class=bl>Ka Brodacký</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Jo Astrom</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>10 : 2</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Al Božič</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Ka Brodacký</td><td class=bc>11 : 0</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ja Čepička</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Ka Brodacký</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Jo Astrom</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Al Božič</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Ka Brodacký</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Al Božič</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ka Brodacký</td><td class=bc>14 : 0</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Al Božič</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Ka Brodacký</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Al Božič</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Ja Čepička</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Ka Brodacký</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Al Božič</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ja Čepička</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ka Brodacký</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Al Božič</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 10</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ja Čepička</td><td class=bc>-</td><td class=bl>Ka Brodacký</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Al Božič</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Blažek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ka Brodacký</td><td class=bc>-</td><td class=blW>Al Božič</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Al Božič</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ka Brodacký</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>2 : 10</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Mi Blažek</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Božič</td><td class=bc>-</td><td class=blW>Jo Astrom</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>4 : 10</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Ka Brodacký</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Jo Astrom</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Al Božič</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ka Brodacký</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>5 : 15</tr></td>
<tr><td class=br>Ja Čepička</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Mi Blažek</td><td class=bc>1 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 4</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1477&x=374">Mi Kobrle</a></td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>7:1</td>
<td class=kW>7:1</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kW>7:3</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>8:3</td>
<td class=kW>8:2</td>
<td class=kW>9:1</td>
<td class=kW>11:2</td>
<td class=kW>7:0</td>
<td class=br>110:29</td><td class=br>+81</td>
<td class=bc>17 - 2 - 0</td>
<td class=br><strong>36</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=567&x=374">Kr Lebl</a></td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>9:1</td>
<td class=kW>5:0</td>
<td class=br>65:19</td><td class=br>+46</td>
<td class=bc>13 - 5 - 1</td>
<td class=br><strong>31</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=993&x=374">Ji Chylík ml.</a></td><td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kW>7:1</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=kW>7:3</td>
<td class=kW>4:2</td>
<td class=br>67:29</td><td class=br>+38</td>
<td class=bc>13 - 3 - 3</td>
<td class=br><strong>29</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=53&x=374">Vá Pikl</a></td><td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kL>3:5</td>
<td class=kW>10:1</td>
<td class=kW>8:1</td>
<td class=kW>7:0</td>
<td class=kW>8:0</td>
<td class=br>72:32</td><td class=br>+40</td>
<td class=bc>11 - 3 - 5</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=886&x=374">Be Rjavec</a></td><td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>8:1</td>
<td class=kW>4:0</td>
<td class=br>62:32</td><td class=br>+30</td>
<td class=bc>12 - 1 - 6</td>
<td class=br><strong>25</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1033&x=374">Si Thomas</a></td><td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kW>5:3</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kW>9:0</td>
<td class=kW>6:2</td>
<td class=kW>8:0</td>
<td class=br>71:39</td><td class=br>+32</td>
<td class=bc>11 - 2 - 6</td>
<td class=br><strong>24</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=4&x=374">Vl Kraus</a></td><td class=kL>1:7</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kL>6:7</td>
<td class=kL>1:2</td>
<td class=kW>7:2</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>8:0</td>
<td class=kW>8:4</td>
<td class=kW>6:0</td>
<td class=br>69:46</td><td class=br>+23</td>
<td class=bc>10 - 3 - 6</td>
<td class=br><strong>23</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1912&x=374">Al Krejza</a></td><td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>10:1</td>
<td class=kW>4:0</td>
<td class=br>59:32</td><td class=br>+27</td>
<td class=bc>10 - 3 - 6</td>
<td class=br><strong>23</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=108&x=374">Ro Hejda</a></td><td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=br>52:49</td><td class=br>+3</td>
<td class=bc>7 - 6 - 6</td>
<td class=br><strong>20</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=176&x=374">Zd Lopaur</a></td><td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kL>4:7</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>8:0</td>
<td class=kW>7:2</td>
<td class=kW>8:1</td>
<td class=br>70:53</td><td class=br>+17</td>
<td class=bc>8 - 4 - 7</td>
<td class=br><strong>20</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>A</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1117&x=374">To Kahoun ml.</a></td><td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>7:2</td>
<td class=br>54:45</td><td class=br>+9</td>
<td class=bc>9 - 1 - 9</td>
<td class=br><strong>19</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>A</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1974&x=374">Ja Obadič</a></td><td class=kL>3:7</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kW>7:6</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>7:4</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kW>5:2</td>
<td class=kW>9:0</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=br>67:64</td><td class=br>+3</td>
<td class=bc>8 - 2 - 9</td>
<td class=br><strong>18</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1979&x=374">Ga Bohinc</a></td><td class=kL>0:6</td>
<td class=kT>1:1</td>
<td class=kL>1:7</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=br>30:46</td><td class=br>-16</td>
<td class=bc>6 - 6 - 7</td>
<td class=br><strong>18</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>B</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=204&x=374">Hy Nechutný</a></td><td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kW>3:0</td>
<td class=kL>2:7</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=br>41:44</td><td class=br>-3</td>
<td class=bc>7 - 3 - 9</td>
<td class=br><strong>17</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>B</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1657&x=374">Jo Perkner</a></td><td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kW>2:0</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>8:2</td>
<td class=br>42:55</td><td class=br>-13</td>
<td class=bc>8 - 1 - 10</td>
<td class=br><strong>17</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>B</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1318&x=374">Jo Sedláček</a></td><td class=kL>3:8</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kL>0:1</td>
<td class=kL>1:7</td>
<td class=kW>3:2</td>
<td class=kL>1:7</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=br>48:61</td><td class=br>-13</td>
<td class=bc>6 - 4 - 9</td>
<td class=br><strong>16</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>C</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1973&x=374">Br Sabo</a></td><td class=kL>2:8</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>1:10</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=br>33:77</td><td class=br>-44</td>
<td class=bc>4 - 1 - 14</td>
<td class=br><strong>9</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>C</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1881&x=374">Fi Werner</a></td><td class=kL>1:9</td>
<td class=kL>2:7</td>
<td class=kL>0:8</td>
<td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kL>0:9</td>
<td class=kL>0:8</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>0:8</td>
<td class=kL>0:6</td>
<td class=kL>0:9</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=br>18:101</td><td class=br>-83</td>
<td class=bc>2 - 3 - 14</td>
<td class=br><strong>7</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>C</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1923&x=374">Vo Vacke</a></td><td class=kL>2:11</td>
<td class=kL>1:9</td>
<td class=kL>3:7</td>
<td class=kL>0:7</td>
<td class=kL>1:8</td>
<td class=kL>2:6</td>
<td class=kL>4:8</td>
<td class=kL>1:10</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=br>34:114</td><td class=br>-80</td>
<td class=bc>1 - 1 - 17</td>
<td class=br><strong>3</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>C</td><td class=d>20.</td><td class=kt><a href="../../../thstats/overview_co.aspx?idpl=1982&x=374">Ja Čermák</a></td><td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>0:8</td>
<td class=kL>0:4</td>
<td class=kL>0:8</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>1:8</td>
<td class=kL>2:7</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>2:8</td>
<td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=br>11:108</td><td class=br>-97</td>
<td class=bc>0 - 0 - 19</td>
<td class=br><strong>0</strong></td><td class=d>20.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ja Čermák</td><td class=bc>-</td><td class=blW>Fi Werner</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ro Hejda</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ja Obadič</td><td class=bc>-</td><td class=bl>Fi Werner</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Ga Bohinc</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ja Čermák</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Fi Werner</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Čermák</td><td class=bc>-</td><td class=blW>Br Sabo</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Fi Werner</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ja Obadič</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ja Čermák</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Ro Hejda</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Br Sabo</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Fi Werner</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ja Čermák</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ro Hejda</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Fi Werner</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ja Obadič</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ja Čermák</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Fi Werner</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ja Čermák</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Br Sabo</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Fi Werner</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ja Obadič</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>7 : 6</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ja Čermák</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>4 : 8</tr></td>
<tr><td class=br>Fi Werner</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Ja Obadič</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ja Čermák</td><td class=bc>-</td><td class=blW>Ro Hejda</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Fi Werner</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ga Bohinc</td><td class=bc>-</td><td class=bl>Ja Čermák</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Vo Vacke</td><td class=bc>-</td><td class=bl>Ja Čermák</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Fi Werner</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ja Obadič</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>Ro Hejda</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Ja Čermák</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=blW>Ja Obadič</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Fi Werner</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Ja Čermák</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Fi Werner</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Vo Vacke</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ro Hejda</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Ja Čermák</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Br Sabo</td><td class=bc>-</td><td class=bl>Fi Werner</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ja Čermák</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Fi Werner</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ja Čermák</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ja Obadič</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Fi Werner</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ja Čermák</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Fi Werner</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ja Čermák</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Fi Werner</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Ro Hejda</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ja Obadič</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Fi Werner</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>11 : 2</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Ja Čermák</td><td class=bc>-</td><td class=blW>Ja Obadič</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=blW>Fi Werner</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Vo Vacke</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</table></div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
