<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Plzeň</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/pohar13.aspx">U13</a>
&nbsp;<a href="../data/pohar55.aspx">55+</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Plzeň, 1. listopad 2025</span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Základní skupiny (Basic groups)</a><br>
<a href="#final">Výkonnostní skupiny (Final groups)</a><br>
<a name="basic"><p class=vm>Základní skupiny (Basic groups)</p></a>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Mi Hvižď</td><td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kW>9:2</td>
<td class=kW>11:0</td>
<td class=kW>6:0</td>
<td class=kW>7:1</td>
<td class=kW>6:2</td>
<td class=kW>7:0</td>
<td class=kW>15:1</td>
<td class=kW>14:0</td>
<td class=kW>10:2</td>
<td class=br>116:16</td><td class=br>+100</td>
<td class=bc>14 - 1 - 0</td>
<td class=br><strong>29</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ma Klazar</td><td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>10:1</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=br>78:25</td><td class=br>+53</td>
<td class=bc>14 - 0 - 1</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Pe Fuchs</td><td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>11:1</td>
<td class=kW>4:0</td>
<td class=kW>9:1</td>
<td class=kW>7:1</td>
<td class=kW>9:0</td>
<td class=br>76:23</td><td class=br>+53</td>
<td class=bc>11 - 2 - 2</td>
<td class=br><strong>24</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Vl Kraus</td><td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>8:2</td>
<td class=kT>4:4</td>
<td class=kW>4:0</td>
<td class=kW>11:0</td>
<td class=kW>9:0</td>
<td class=br>64:30</td><td class=br>+34</td>
<td class=bc>11 - 1 - 3</td>
<td class=br><strong>23</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Al Krejza</td><td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>9:0</td>
<td class=kW>7:0</td>
<td class=kW>7:0</td>
<td class=br>54:28</td><td class=br>+26</td>
<td class=bc>10 - 0 - 5</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ro Jež</td><td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kL>2:7</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>10:1</td>
<td class=kW>9:0</td>
<td class=br>53:35</td><td class=br>+18</td>
<td class=bc>9 - 0 - 6</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Ja Dryák</td><td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kW>9:0</td>
<td class=kW>9:0</td>
<td class=kW>8:1</td>
<td class=br>70:31</td><td class=br>+39</td>
<td class=bc>9 - 0 - 6</td>
<td class=br><strong>18</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Mi Uhlíř</td><td class=kL>2:9</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=kW>11:0</td>
<td class=br>57:44</td><td class=br>+13</td>
<td class=bc>7 - 2 - 6</td>
<td class=br><strong>16</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Hy Nechutný</td><td class=kL>0:11</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=br>33:38</td><td class=br>-5</td>
<td class=bc>8 - 0 - 7</td>
<td class=br><strong>16</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ja Kopecký</td><td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>8:3</td>
<td class=kW>4:3</td>
<td class=br>37:39</td><td class=br>-2</td>
<td class=bc>7 - 1 - 7</td>
<td class=br><strong>15</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Pa Janouškovec</td><td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>0:7</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=br>27:60</td><td class=br>-33</td>
<td class=bc>3 - 3 - 9</td>
<td class=br><strong>9</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>On Chlebo</td><td class=kL>2:6</td>
<td class=kL>1:10</td>
<td class=kL>1:11</td>
<td class=kL>2:8</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>2:7</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=br>30:67</td><td class=br>-37</td>
<td class=bc>4 - 1 - 10</td>
<td class=br><strong>9</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ra Hrnčíř</td><td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>9:2</td>
<td class=br>37:57</td><td class=br>-20</td>
<td class=bc>3 - 2 - 10</td>
<td class=br><strong>8</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ja Kubica</td><td class=kL>1:15</td>
<td class=kL>1:5</td>
<td class=kL>1:9</td>
<td class=kL>0:4</td>
<td class=kL>0:9</td>
<td class=kL>1:3</td>
<td class=kL>0:9</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=br>11:82</td><td class=br>-71</td>
<td class=bc>0 - 3 - 12</td>
<td class=br><strong>3</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>To Urban</td><td class=kL>0:14</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>0:11</td>
<td class=kL>0:7</td>
<td class=kL>1:10</td>
<td class=kL>0:9</td>
<td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kL>3:8</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=br>21:100</td><td class=br>-79</td>
<td class=bc>1 - 1 - 13</td>
<td class=br><strong>3</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>C</td><td class=d>16.</td><td class=kt>Mi Matuštík</td><td class=kL>2:10</td>
<td class=kL>0:8</td>
<td class=kL>0:9</td>
<td class=kL>0:9</td>
<td class=kL>0:7</td>
<td class=kL>0:9</td>
<td class=kL>1:8</td>
<td class=kL>0:11</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>2:9</td>
<td class=kT>1:1</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=br>14:103</td><td class=br>-89</td>
<td class=bc>0 - 1 - 14</td>
<td class=br><strong>1</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Matuštík Milan</td><td class=bc>-</td><td class=blW>Urban Tomáš</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=blW>Kopecký Jaroslav</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Dryák Jan</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Chlebo Ondřej</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Janouškovec Pavel</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=blW>Kopecký Jaroslav</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Matuštík Milan</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>1 : 15</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Uhlíř Miroslav</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Dryák Jan</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Kopecký Jaroslav</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>0 : 14</tr></td>
<tr><td class=br>Matuštík Milan</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Uhlíř Miroslav</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Dryák Jan</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kopecký Jaroslav</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Matuštík Milan</td><td class=bc>-</td><td class=blW>Chlebo Ondřej</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=blW>Dryák Jan</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kopecký Jaroslav</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Matuštík Milan</td><td class=bc>-</td><td class=blW>Janouškovec Pavel</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Dryák Jan</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Uhlíř Miroslav</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Kopecký Jaroslav</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Matuštík Milan</td><td class=bc>-</td><td class=blW>Dryák Jan</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=blW>Uhlíř Miroslav</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>11 : 1</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kopecký Jaroslav</td><td class=bc>-</td><td class=blW>Dryák Jan</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=blW>Uhlíř Miroslav</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Matuštík Milan</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Dryák Jan</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Uhlíř Miroslav</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kopecký Jaroslav</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>Matuštík Milan</td><td class=bc>-</td><td class=bl>Kubica Jan</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=blW>Dryák Jan</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=bl>Uhlíř Miroslav</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Kubica Jan</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Kopecký Jaroslav</td><td class=bc>-</td><td class=bl>Matuštík Milan</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Dryák Jan</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Uhlíř Miroslav</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Kubica Jan</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Matuštík Milan</td><td class=bc>10 : 2</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Kopecký Jaroslav</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Uhlíř Miroslav</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Chlebo Ondřej</td><td class=bc>-</td><td class=bl>Kubica Jan</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Matuštík Milan</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Kopecký Jaroslav</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Dryák Jan</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=bl>Kubica Jan</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Matuštík Milan</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Chlebo Ondřej</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Kopecký Jaroslav</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Hvižď Michal</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Dryák Jan</td><td class=bc>-</td><td class=bl>Kubica Jan</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Matuštík Milan</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Janouškovec Pavel</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Kopecký Jaroslav</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=bl>Hvižď Michal</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Kubica Jan</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Uhlíř Miroslav</td><td class=bc>-</td><td class=bl>Matuštík Milan</td><td class=bc>11 : 0</tr></td>
<tr><td class=brW>Dryák Jan</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Kopecký Jaroslav</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Matuštík Milan</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=bl>Kopecký Jaroslav</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Dryák Jan</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Kopecký Jaroslav</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Dryák Jan</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Mi Kobrle</td><td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>8:2</td>
<td class=kL>2:4</td>
<td class=kW>8:3</td>
<td class=kW>7:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>7:3</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>9:0</td>
<td class=kW>9:1</td>
<td class=kW>8:0</td>
<td class=kW>8:0</td>
<td class=br>94:22</td><td class=br>+72</td>
<td class=bc>14 - 0 - 1</td>
<td class=br><strong>28</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Kr Lebl</td><td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=kW>10:2</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>8:0</td>
<td class=kW>4:0</td>
<td class=br>63:21</td><td class=br>+42</td>
<td class=bc>11 - 2 - 2</td>
<td class=br><strong>24</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>An Šurýn</td><td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=br>57:24</td><td class=br>+33</td>
<td class=bc>11 - 2 - 2</td>
<td class=br><strong>24</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Mi Touš</td><td class=kL>2:8</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kW>6:4</td>
<td class=kW>5:4</td>
<td class=kL>1:3</td>
<td class=kW>7:3</td>
<td class=kL>5:6</td>
<td class=kW>3:2</td>
<td class=kW>10:0</td>
<td class=kW>9:0</td>
<td class=kW>13:1</td>
<td class=kW>10:0</td>
<td class=br>82:38</td><td class=br>+44</td>
<td class=bc>11 - 0 - 4</td>
<td class=br><strong>22</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ja Janouškovec</td><td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kL>0:6</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>1:7</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kT>0:0</td>
<td class=kW>5:3</td>
<td class=kW>5:0 K</td>
<td class=kT>3:3</td>
<td class=kW>8:0</td>
<td class=kW>4:2</td>
<td class=kW>8:2</td>
<td class=kW>4:2</td>
<td class=br>56:37</td><td class=br>+19</td>
<td class=bc>9 - 3 - 3</td>
<td class=br><strong>21</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>To Lahučký</td><td class=kL>3:8</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>17:2</td>
<td class=kW>13:1</td>
<td class=kW>8:2</td>
<td class=kW>8:0</td>
<td class=br>80:33</td><td class=br>+47</td>
<td class=bc>9 - 2 - 4</td>
<td class=br><strong>20</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Zd Lopaur</td><td class=kL>1:7</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>4:6</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>6:5</td>
<td class=kW>5:0 K</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=kW>8:0</td>
<td class=kW>7:2</td>
<td class=br>54:35</td><td class=br>+19</td>
<td class=bc>8 - 1 - 6</td>
<td class=br><strong>17</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Ku Sládek</td><td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>4:5</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kW>9:1</td>
<td class=kW>7:2</td>
<td class=kW>7:0</td>
<td class=kW>5:0</td>
<td class=br>58:30</td><td class=br>+28</td>
<td class=bc>8 - 1 - 6</td>
<td class=br><strong>17</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>To Bucek</td><td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kW>6:3</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=br>47:34</td><td class=br>+13</td>
<td class=bc>7 - 3 - 5</td>
<td class=br><strong>17</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Fr Rasche</td><td class=kL>3:7</td>
<td class=kL>2:7</td>
<td class=kL>4:5</td>
<td class=kL>3:7</td>
<td class=kL>3:5</td>
<td class=kT>4:4</td>
<td class=kL>5:6</td>
<td class=kL>2:6</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=kW>3:1</td>
<td class=br>56:59</td><td class=br>-3</td>
<td class=bc>6 - 1 - 8</td>
<td class=br><strong>13</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ji Vácha</td><td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>6:5</td>
<td class=kL>0:5 K</td>
<td class=kL>2:6</td>
<td class=kL>0:5 K</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kL>0:5 K</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=kL>0:5 K</td>
<td class=kW>3:1</td>
<td class=br>38:58</td><td class=br>-20</td>
<td class=bc>6 - 0 - 9</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ma Moravec</td><td class=kL>2:6</td>
<td class=kL>2:10</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kW>5:0 K</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=br>35:49</td><td class=br>-14</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Kr Soudek</td><td class=kL>0:9</td>
<td class=kL>0:6</td>
<td class=kL>2:7</td>
<td class=kL>0:10</td>
<td class=kL>0:8</td>
<td class=kL>2:17</td>
<td class=kL>1:3</td>
<td class=kL>1:9</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kW>4:0</td>
<td class=kW>9:1</td>
<td class=br>31:95</td><td class=br>-64</td>
<td class=bc>3 - 0 - 12</td>
<td class=br><strong>6</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Vo Pošík</td><td class=kL>1:9</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>0:9</td>
<td class=kL>2:4</td>
<td class=kL>1:13</td>
<td class=kL>0:7</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kL>0:3</td>
<td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>16:0</td>
<td class=br>33:86</td><td class=br>-53</td>
<td class=bc>2 - 0 - 13</td>
<td class=br><strong>4</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>Da Polaštíková</td><td class=kL>0:8</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>1:13</td>
<td class=kL>2:8</td>
<td class=kL>2:8</td>
<td class=kL>0:8</td>
<td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>0:8</td>
<td class=kW>5:0 K</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=br>12:90</td><td class=br>-78</td>
<td class=bc>2 - 0 - 13</td>
<td class=br><strong>4</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>C</td><td class=d>16.</td><td class=kt>Št Bláha</td><td class=kL>0:8</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>0:10</td>
<td class=kL>2:4</td>
<td class=kL>0:8</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:9</td>
<td class=kL>0:16</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=br>8:93</td><td class=br>-85</td>
<td class=bc>0 - 0 - 15</td>
<td class=br><strong>0</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Bláha Štěpán</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Rasche Frank</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Lahučký Tomáš</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Soudek Kryštof</td><td class=bc>-</td><td class=bl>Polaštíková Daniela</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Bláha Štěpán</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Rasche Frank</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Lahučký Tomáš</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=blW>Polaštíková Daniela</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Soudek Kryštof</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Bláha Štěpán</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Lahučký Tomáš</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pošík Vojtěch</td><td class=bc>-</td><td class=bl>Polaštíková Daniela</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Soudek Kryštof</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>0 : 5 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Bláha Štěpán</td><td class=bc>-</td><td class=blW>Lahučký Tomáš</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Polaštíková Daniela</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Soudek Kryštof</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>5 : 0 K</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>10 : 2</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Lahučký Tomáš</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Polaštíková Daniela</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Bláha Štěpán</td><td class=bc>-</td><td class=blW>Soudek Kryštof</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=bl>Lahučký Tomáš</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Polaštíková Daniela</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Soudek Kryštof</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Bláha Štěpán</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Lahučký Tomáš</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Polaštíková Daniela</td><td class=bc>13 : 1</tr></td>
<tr><td class=brW>Rasche Frank</td><td class=bc>-</td><td class=bl>Soudek Kryštof</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Bláha Štěpán</td><td class=bc>-</td><td class=blW>Pošík Vojtěch</td><td class=bc>0 : 16</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Polaštíková Daniela</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Soudek Kryštof</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Bláha Štěpán</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Polaštíková Daniela</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Bláha Štěpán</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Soudek Kryštof</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Polaštíková Daniela</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>13 : 1</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Rasche Frank</td><td class=bc>-</td><td class=bl>Bláha Štěpán</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Soudek Kryštof</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Polaštíková Daniela</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Bláha Štěpán</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Soudek Kryštof</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Polaštíková Daniela</td><td class=bc>-</td><td class=bl>Bláha Štěpán</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Bláha Štěpán</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Soudek Kryštof</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Polaštíková Daniela</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Rasche Frank</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Bláha Štěpán</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Soudek Kryštof</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Polaštíková Daniela</td><td class=bc>-</td><td class=blW>Rasche Frank</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Bláha Štěpán</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Soudek Kryštof</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Polaštíková Daniela</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Soudek Kryštof</td><td class=bc>-</td><td class=blW>Lahučký Tomáš</td><td class=bc>2 : 17</tr></td>
<tr><td class=br>Polaštíková Daniela</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 3</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Pa Petr</td><td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>11:3</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>6:3</td>
<td class=kW>10:1</td>
<td class=kW>7:2</td>
<td class=kW>10:0</td>
<td class=kW>11:1</td>
<td class=kW>8:1</td>
<td class=br>97:22</td><td class=br>+75</td>
<td class=bc>14 - 1 - 0</td>
<td class=br><strong>29</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Mi Černoch</td><td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>9:2</td>
<td class=kW>8:1</td>
<td class=kW>12:0</td>
<td class=kW>8:1</td>
<td class=br>74:19</td><td class=br>+55</td>
<td class=bc>12 - 1 - 2</td>
<td class=br><strong>25</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>To Růžička</td><td class=kL>3:11</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=kW>8:0</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=br>61:28</td><td class=br>+33</td>
<td class=bc>12 - 0 - 3</td>
<td class=br><strong>24</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ma Ženíšek</td><td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kL>3:6</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>10:1</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kW>6:1</td>
<td class=br>61:29</td><td class=br>+32</td>
<td class=bc>11 - 1 - 3</td>
<td class=br><strong>23</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Kr Herold</td><td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>5:0 K</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>6:4</td>
<td class=kW>4:0</td>
<td class=kW>8:2</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=br>63:28</td><td class=br>+35</td>
<td class=bc>10 - 3 - 2</td>
<td class=br><strong>23</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>On Gruncl</td><td class=kL>0:7</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>8:1</td>
<td class=kW>8:2</td>
<td class=br>54:41</td><td class=br>+13</td>
<td class=bc>9 - 1 - 5</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Ti Dion</td><td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>9:1</td>
<td class=kW>6:0</td>
<td class=kW>8:3</td>
<td class=kW>6:1</td>
<td class=br>57:30</td><td class=br>+27</td>
<td class=bc>9 - 1 - 5</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Ad Kopřiva</td><td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>0:5 K</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>11:4</td>
<td class=kW>7:0</td>
<td class=br>48:41</td><td class=br>+7</td>
<td class=bc>7 - 1 - 7</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Jo Vomáčka</td><td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>8:1</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>9:2</td>
<td class=br>46:35</td><td class=br>+11</td>
<td class=bc>7 - 1 - 7</td>
<td class=br><strong>15</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ti Varga</td><td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=br>45:41</td><td class=br>+4</td>
<td class=bc>7 - 1 - 7</td>
<td class=br><strong>15</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Pe Holub</td><td class=kL>3:6</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>1:10</td>
<td class=kL>4:6</td>
<td class=kW>5:4</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kW>7:3</td>
<td class=br>46:58</td><td class=br>-12</td>
<td class=bc>6 - 0 - 9</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ji Pošík</td><td class=kL>1:10</td>
<td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:8</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>6:5</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=br>23:73</td><td class=br>-50</td>
<td class=bc>3 - 1 - 11</td>
<td class=br><strong>7</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ví Pernica</td><td class=kL>2:7</td>
<td class=kL>2:9</td>
<td class=kL>0:8</td>
<td class=kL>1:6</td>
<td class=kL>2:8</td>
<td class=kL>2:3</td>
<td class=kL>1:9</td>
<td class=kT>4:4</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>2:7</td>
<td class=kL>5:6</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>8:2</td>
<td class=kW>6:4</td>
<td class=br>44:82</td><td class=br>-38</td>
<td class=bc>3 - 1 - 11</td>
<td class=br><strong>7</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Pe Klazar</td><td class=kL>0:10</td>
<td class=kL>1:8</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=br>25:76</td><td class=br>-51</td>
<td class=bc>2 - 0 - 13</td>
<td class=br><strong>4</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>Vá Bláha</td><td class=kL>1:11</td>
<td class=kL>0:12</td>
<td class=kL>1:7</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>1:8</td>
<td class=kL>3:8</td>
<td class=kL>4:11</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kT>4:4</td>
<td class=kL>2:8</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=br>29:100</td><td class=br>-71</td>
<td class=bc>1 - 1 - 13</td>
<td class=br><strong>3</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>C</td><td class=d>16.</td><td class=kt>Ma Pokorný</td><td class=kL>1:8</td>
<td class=kL>1:8</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>2:8</td>
<td class=kL>1:6</td>
<td class=kL>0:7</td>
<td class=kL>2:9</td>
<td class=kL>2:6</td>
<td class=kL>3:7</td>
<td class=kL>2:4</td>
<td class=kL>4:6</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=br>22:92</td><td class=br>-70</td>
<td class=bc>0 - 0 - 15</td>
<td class=br><strong>0</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Bláha Václav</td><td class=bc>11 : 1</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Pokorný Matěj</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Varga Tibor</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Holub Petr</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kopřiva Adam</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Dion Till</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Bláha Václav</td><td class=bc>12 : 0</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Pokorný Matěj</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Varga Tibor</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Holub Petr</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Vomáčka Josef</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Kopřiva Adam</td><td class=bc>-</td><td class=blW>Dion Till</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Bláha Václav</td><td class=bc>-</td><td class=bl>Pokorný Matěj</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Varga Tibor</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Vomáčka Josef</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Dion Till</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Kopřiva Adam</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Pokorný Matěj</td><td class=bc>-</td><td class=blW>Varga Tibor</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Bláha Václav</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Dion Till</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=bl>Kopřiva Adam</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Pošík Jiří</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Varga Tibor</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pokorný Matěj</td><td class=bc>-</td><td class=blW>Holub Petr</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Bláha Václav</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=bl>Dion Till</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Kopřiva Adam</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Holub Petr</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Varga Tibor</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Pokorný Matěj</td><td class=bc>-</td><td class=blW>Vomáčka Josef</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Bláha Václav</td><td class=bc>-</td><td class=blW>Dion Till</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Kopřiva Adam</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Varga Tibor</td><td class=bc>-</td><td class=bl>Dion Till</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pokorný Matěj</td><td class=bc>-</td><td class=blW>Kopřiva Adam</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Bláha Václav</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Petr Patrik</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Dion Till</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Kopřiva Adam</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Varga Tibor</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Pokorný Matěj</td><td class=bc>-</td><td class=blW>Klazar Petr</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Bláha Václav</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Kopřiva Adam</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Holub Petr</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Varga Tibor</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pokorný Matěj</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Bláha Václav</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Dion Till</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Varga Tibor</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pokorný Matěj</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Bláha Václav</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Kopřiva Adam</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Dion Till</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>3 : 11</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Varga Tibor</td><td class=bc>-</td><td class=bl>Bláha Václav</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pokorný Matěj</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Pošík Jiří</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Kopřiva Adam</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Dion Till</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Holub Petr</td><td class=bc>-</td><td class=bl>Bláha Václav</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Pokorný Matěj</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Varga Tibor</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Kopřiva Adam</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Dion Till</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Bláha Václav</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Pokorný Matěj</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Varga Tibor</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Kopřiva Adam</td><td class=bc>-</td><td class=bl>Bláha Václav</td><td class=bc>11 : 4</tr></td>
<tr><td class=brW>Dion Till</td><td class=bc>-</td><td class=bl>Pokorný Matěj</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Varga Tibor</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>2 : 9</tr></td>
<tr><td class=brW>Klazar Petr</td><td class=bc>-</td><td class=bl>Bláha Václav</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Pošík Jiří</td><td class=bc>-</td><td class=bl>Pokorný Matěj</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kopřiva Adam</td><td class=bc>-</td><td class=bl>Varga Tibor</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Dion Till</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Vomáčka Josef</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Bláha Václav</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Pokorný Matěj</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Varga Tibor</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kopřiva Adam</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Dion Till</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 4</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Vo Kraus</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=br>47:19</td><td class=br>+28</td>
<td class=bc>10 - 3 - 1</td>
<td class=br><strong>23</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ma Ležík</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>9:1</td>
<td class=kW>11:0</td>
<td class=kW>7:0</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=kW>3:0</td>
<td class=kW>8:0</td>
<td class=br>68:19</td><td class=br>+49</td>
<td class=bc>9 - 4 - 1</td>
<td class=br><strong>22</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ji Chylík ml.</td><td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kW>6:0</td>
<td class=br>54:25</td><td class=br>+29</td>
<td class=bc>9 - 4 - 1</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Vá Pikl</td><td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>9:1</td>
<td class=kW>5:0</td>
<td class=kW>10:0</td>
<td class=kW>10:0</td>
<td class=br>57:24</td><td class=br>+33</td>
<td class=bc>8 - 3 - 3</td>
<td class=br><strong>19</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Mi Ševr</td><td class=kL>1:5</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kT>4:4</td>
<td class=kL>3:6</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>13:1</td>
<td class=kW>5:1</td>
<td class=kW>5:4</td>
<td class=kW>8:1</td>
<td class=br>64:37</td><td class=br>+27</td>
<td class=bc>8 - 3 - 3</td>
<td class=br><strong>19</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Pa Plešák</td><td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kW>4:1</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>9:0</td>
<td class=kW>8:0</td>
<td class=br>61:32</td><td class=br>+29</td>
<td class=bc>8 - 2 - 4</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Da Matýsek</td><td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kW>9:0</td>
<td class=br>48:21</td><td class=br>+27</td>
<td class=bc>7 - 4 - 3</td>
<td class=br><strong>18</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Mi Kubica</td><td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=kW>8:3</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=br>54:42</td><td class=br>+12</td>
<td class=bc>7 - 2 - 5</td>
<td class=br><strong>16</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Mi Mašika</td><td class=kL>2:6</td>
<td class=kL>1:9</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>9:0</td>
<td class=br>46:38</td><td class=br>+8</td>
<td class=bc>7 - 1 - 6</td>
<td class=br><strong>15</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Mi Moravec</td><td class=kL>1:2</td>
<td class=kL>0:11</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>9:0</td>
<td class=kW>6:0</td>
<td class=br>37:45</td><td class=br>-8</td>
<td class=bc>5 - 2 - 7</td>
<td class=br><strong>12</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Fr Marek</td><td class=kT>1:1</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=br>31:42</td><td class=br>-11</td>
<td class=bc>5 - 1 - 8</td>
<td class=br><strong>11</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Da Kadlec</td><td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kL>1:9</td>
<td class=kL>1:13</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>7:0</td>
<td class=br>32:66</td><td class=br>-34</td>
<td class=bc>3 - 1 - 10</td>
<td class=br><strong>7</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ma Šperňák</td><td class=kL>1:4</td>
<td class=kL>0:8</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>3:8</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>12:1</td>
<td class=kW>11:0</td>
<td class=br>37:59</td><td class=br>-22</td>
<td class=bc>2 - 0 - 12</td>
<td class=br><strong>4</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Vá Bláha</td><td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kL>0:10</td>
<td class=kL>4:5</td>
<td class=kL>0:9</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>0:9</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>1:12</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=br>11:79</td><td class=br>-68</td>
<td class=bc>1 - 1 - 12</td>
<td class=br><strong>3</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>Ka Mendová</td><td class=kL>0:6</td>
<td class=kL>0:8</td>
<td class=kL>0:6</td>
<td class=kL>0:10</td>
<td class=kL>1:8</td>
<td class=kL>0:8</td>
<td class=kL>0:9</td>
<td class=kL>1:7</td>
<td class=kL>0:9</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>0:11</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=br>3:102</td><td class=br>-99</td>
<td class=bc>0 - 1 - 13</td>
<td class=br><strong>1</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Mendová Karolína</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Bláha Václav ml.</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Šperňák Marek</td><td class=bc>-</td><td class=blW>Marek František</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Mendová Karolína</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Bláha Václav ml.</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Marek František</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Šperňák Marek</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Bláha Václav ml.</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mendová Karolína</td><td class=bc>-</td><td class=blW>Marek František</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Šperňák Marek</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Bláha Václav ml.</td><td class=bc>-</td><td class=blW>Marek František</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mendová Karolína</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Šperňák Marek</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Bláha Václav ml.</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Ležík Matěj</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mendová Karolína</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>1 : 13</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Bláha Václav ml.</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ležík Matěj</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mendová Karolína</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kadlec Daniel</td><td class=bc>-</td><td class=bl>Šperňák Marek</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Bláha Václav ml.</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Mendová Karolína</td><td class=bc>-</td><td class=blW>Šperňák Marek</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=blW>Mašika Michal</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Bláha Václav ml.</td><td class=bc>-</td><td class=blW>Šperňák Marek</td><td class=bc>1 : 12</tr></td>
<tr><td class=br>Ležík Matěj</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mendová Karolína</td><td class=bc>-</td><td class=blW>Kadlec Daniel</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Mašika Michal</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Šperňák Marek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Bláha Václav ml.</td><td class=bc>-</td><td class=blW>Kadlec Daniel</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>11 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=blW>Mašika Michal</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Šperňák Marek</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Marek František</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Bláha Václav ml.</td><td class=bc>-</td><td class=bl>Mendová Karolína</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Šperňák Marek</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Mendová Karolína</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Mašika Michal</td><td class=bc>-</td><td class=bl>Šperňák Marek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Mendová Karolína</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=bl>Ležík Matěj</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Bláha Václav ml.</td><td class=bc>9 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Šperňák Marek</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Mašika Michal</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Mendová Karolína</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Bláha Václav ml.</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Šperňák Marek</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Mašika Michal</td><td class=bc>-</td><td class=bl>Mendová Karolína</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Ležík Matěj</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=blW>Bláha Václav ml.</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Mendová Karolína</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Šperňák Marek</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Mašika Michal</td><td class=bc>-</td><td class=bl>Bláha Václav ml.</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>2 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<hr><a name="final"><p class=vm>Výkonnostní skupiny (Final groups)</p></a>
<p class=v>Group A</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt>Mi Kobrle</td><td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kT>5:5</td>
<td class=kT>5:5</td>
<td class=kW>6:4</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2 K</td>
<td class=kW>5:0</td>
<td class=kW>8:2 K</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>8:3 K</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>5:3</td>
<td class=kW>7:2</td>
<td class=kW>4:1 K</td>
<td class=kW>5:1</td>
<td class=kL>2:4 K</td>
<td class=kW>7:2</td>
<td class=br>118:43</td><td class=br>+75</td>
<td class=bc>20 - 2 - 1</td>
<td class=br><strong>42</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt>Ji Chylík ml.</td><td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kT>1:1 K</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>5:2 K</td>
<td class=kW>4:1</td>
<td class=kW>7:3</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>4:0 K</td>
<td class=kW>4:2</td>
<td class=kT>2:2 K</td>
<td class=kT>3:3 K</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=br>89:42</td><td class=br>+47</td>
<td class=bc>18 - 3 - 2</td>
<td class=br><strong>39</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt>Pa Petr</td><td class=kT>5:5</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kT>4:4</td>
<td class=kW>5:2 K</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>4:3 K</td>
<td class=kW>8:3</td>
<td class=kT>2:2 K</td>
<td class=kW>6:2</td>
<td class=kW>5:4</td>
<td class=kW>11:3 K</td>
<td class=kW>6:1</td>
<td class=kW>6:3</td>
<td class=kT>5:5</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>7:4</td>
<td class=kW>7:0 K</td>
<td class=br>118:64</td><td class=br>+54</td>
<td class=bc>16 - 6 - 1</td>
<td class=br><strong>38</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt>Mi Hvižď</td><td class=kT>5:5</td>
<td class=kL>3:5</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>7:1 K</td>
<td class=kT>3:3 K</td>
<td class=kW>5:0</td>
<td class=kW>4:3</td>
<td class=kL>4:5</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>5:1 K</td>
<td class=kW>8:0</td>
<td class=kT>4:4</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>6:5</td>
<td class=kW>4:2 K</td>
<td class=kW>3:0</td>
<td class=kW>7:1 K</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=br>105:52</td><td class=br>+53</td>
<td class=bc>15 - 6 - 2</td>
<td class=br><strong>36</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>Ma Ležík</td><td class=kL>4:6</td>
<td class=kT>1:1 K</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kW>4:3 K</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kT>3:3 K</td>
<td class=kL>3:5</td>
<td class=kT>2:2 K</td>
<td class=kL>3:6 K</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kW>6:0</td>
<td class=kT>3:3</td>
<td class=br>80:58</td><td class=br>+22</td>
<td class=bc>11 - 8 - 4</td>
<td class=br><strong>30</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>Ma Klazar</td><td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>1:7 K</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:2 K</td>
<td class=kT>4:4</td>
<td class=kW>7:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kW>4:2 K</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>5:2 K</td>
<td class=kW>4:0</td>
<td class=kW>4:2 K</td>
<td class=kL>5:7</td>
<td class=kT>2:2</td>
<td class=br>82:66</td><td class=br>+16</td>
<td class=bc>11 - 6 - 6</td>
<td class=br><strong>28</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Pe Fuchs</td><td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kW>5:3</td>
<td class=kT>3:3 K</td>
<td class=kL>0:4</td>
<td class=kL>2:5 K</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kL>2:4 K</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>4:1 K</td>
<td class=kT>2:2</td>
<td class=kW>7:2 K</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=br>67:53</td><td class=br>+14</td>
<td class=bc>11 - 5 - 7</td>
<td class=br><strong>27</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>Kr Lebl</td><td class=kL>2:5 K</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kL>0:1 K</td>
<td class=kL>1:7</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kL>5:6</td>
<td class=kW>2:1 K</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kT>2:2 K</td>
<td class=kW>4:3</td>
<td class=kT>3:3 K</td>
<td class=kW>7:2</td>
<td class=br>69:64</td><td class=br>+5</td>
<td class=bc>11 - 5 - 7</td>
<td class=br><strong>27</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>Kr Herold</td><td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>2:5 K</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>3:7</td>
<td class=kL>1:4</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kT>1:1 K</td>
<td class=kW>3:2</td>
<td class=kL>4:5 K</td>
<td class=kW>5:4</td>
<td class=kW>6:1</td>
<td class=kW>5:1 K</td>
<td class=kT>4:4</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>3:2 K</td>
<td class=br>69:66</td><td class=br>+3</td>
<td class=bc>11 - 3 - 9</td>
<td class=br><strong>25</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Mi Touš</td><td class=kL>2:8 K</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kW>5:4</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>1:0 K</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>3:6</td>
<td class=kW>5:2</td>
<td class=kL>3:4</td>
<td class=kL>2:4 K</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0 K</td>
<td class=kW>5:2</td>
<td class=kW>4:3 K</td>
<td class=kW>4:0</td>
<td class=br>72:73</td><td class=br>-1</td>
<td class=bc>11 - 2 - 10</td>
<td class=br><strong>24</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>Pa Plešák</td><td class=kL>2:6</td>
<td class=kL>2:5 K</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>3:4 K</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kW>4:1 K</td>
<td class=kT>3:3</td>
<td class=kL>1:2 K</td>
<td class=kW>5:4 K</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>7:2</td>
<td class=br>76:66</td><td class=br>+10</td>
<td class=bc>8 - 7 - 8</td>
<td class=br><strong>23</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>Mi Černoch</td><td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>3:4 K</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kT>1:1 K</td>
<td class=kW>6:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kW>5:0 K</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>2:3 K</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>5:2 K</td>
<td class=br>59:63</td><td class=br>-4</td>
<td class=bc>10 - 3 - 10</td>
<td class=br><strong>23</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt>Vl Kraus</td><td class=kL>2:5</td>
<td class=kL>3:7</td>
<td class=kL>3:8</td>
<td class=kL>1:5 K</td>
<td class=kL>3:6</td>
<td class=kL>2:4 K</td>
<td class=kW>4:2 K</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>4:7</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>7:1</td>
<td class=kW>4:3 K</td>
<td class=kW>4:1</td>
<td class=kW>1:0 K</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=br>66:84</td><td class=br>-18</td>
<td class=bc>8 - 4 - 11</td>
<td class=br><strong>20</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt>Ma Ženíšek</td><td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kT>2:2 K</td>
<td class=kL>0:8</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kW>6:5</td>
<td class=kW>5:4 K</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kL>0:5 K</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kL>0:3 K</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>8:2</td>
<td class=kL>3:6 K</td>
<td class=br>61:79</td><td class=br>-18</td>
<td class=bc>7 - 6 - 10</td>
<td class=br><strong>20</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt>To Lahučký</td><td class=kL>3:8 K</td>
<td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2 K</td>
<td class=kL>4:5</td>
<td class=kW>4:2 K</td>
<td class=kL>2:6</td>
<td class=kW>5:2</td>
<td class=kW>7:4</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kL>1:3 K</td>
<td class=kL>1:2</td>
<td class=kW>7:1 K</td>
<td class=kL>4:5</td>
<td class=br>77:75</td><td class=br>+2</td>
<td class=bc>7 - 5 - 11</td>
<td class=br><strong>19</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt>Vá Pikl</td><td class=kL>1:4</td>
<td class=kL>0:4 K</td>
<td class=kL>4:5</td>
<td class=kL>0:3</td>
<td class=kT>3:3 K</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kL>1:4 K</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>3:1 K</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=br>47:62</td><td class=br>-15</td>
<td class=bc>8 - 3 - 12</td>
<td class=br><strong>19</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>To Růžička</td><td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>3:11 K</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>1:5 K</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kW>3:2 K</td>
<td class=kL>2:3</td>
<td class=kW>3:0 K</td>
<td class=kL>2:5</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>6:3</td>
<td class=kW>3:2 K</td>
<td class=br>57:73</td><td class=br>-16</td>
<td class=bc>7 - 5 - 11</td>
<td class=br><strong>19</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Vo Kraus</td><td class=kL>0:5</td>
<td class=kT>2:2 K</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kT>2:2 K</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>2:1 K</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>1:3 K</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>5:1 K</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=br>46:62</td><td class=br>-16</td>
<td class=bc>5 - 9 - 9</td>
<td class=br><strong>19</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Mi Ševr</td><td class=kL>3:5</td>
<td class=kT>3:3 K</td>
<td class=kL>3:6</td>
<td class=kL>5:6</td>
<td class=kW>6:3 K</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kL>4:5 K</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kL>1:5 K</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=br>57:76</td><td class=br>-19</td>
<td class=bc>6 - 4 - 13</td>
<td class=br><strong>16</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Al Krejza</td><td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kT>5:5</td>
<td class=kL>2:4 K</td>
<td class=kL>1:4</td>
<td class=kL>2:5 K</td>
<td class=kL>1:4 K</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kL>3:4 K</td>
<td class=kW>5:3</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:0 K</td>
<td class=kL>0:1</td>
<td class=kW>5:1</td>
<td class=br>53:80</td><td class=br>-27</td>
<td class=bc>4 - 5 - 14</td>
<td class=br><strong>13</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>An Šurýn</td><td class=kL>1:4 K</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kL>1:5</td>
<td class=kL>0:4 K</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kW>3:1 K</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>6:0 K</td>
<td class=kT>2:2</td>
<td class=br>37:67</td><td class=br>-30</td>
<td class=bc>5 - 3 - 15</td>
<td class=br><strong>13</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Ro Jež</td><td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:7 K</td>
<td class=kL>3:6</td>
<td class=kL>2:4 K</td>
<td class=kL>2:7 K</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kL>0:1 K</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>0:3 K</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=br>46:89</td><td class=br>-43</td>
<td class=bc>4 - 3 - 16</td>
<td class=br><strong>11</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Ja Janouškovec</td><td class=kW>4:2 K</td>
<td class=kL>0:2</td>
<td class=kL>4:7</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kW>7:5</td>
<td class=kL>1:5</td>
<td class=kT>3:3 K</td>
<td class=kL>1:5</td>
<td class=kL>3:4 K</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kL>2:8</td>
<td class=kL>1:7 K</td>
<td class=kL>0:2</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kL>0:6 K</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=br>43:91</td><td class=br>-48</td>
<td class=bc>4 - 3 - 16</td>
<td class=br><strong>11</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>On Gruncl</td><td class=kL>2:7</td>
<td class=kL>1:6</td>
<td class=kL>0:7 K</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kL>2:3 K</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kL>2:5 K</td>
<td class=kL>1:3</td>
<td class=kW>6:3 K</td>
<td class=kW>5:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3 K</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=br>46:92</td><td class=br>-46</td>
<td class=bc>2 - 6 - 15</td>
<td class=br><strong>10</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Hvižď Michal</td><td class=bc>-</td><td class=bl>Lahučký Tomáš</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>5 : 7</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Ležík Matěj</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Hvižď Michal</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Ležík Matěj</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=bl>Lahučký Tomáš</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Petr Patrik</td><td class=bc>-</td><td class=bl>Ležík Matěj</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Lahučký Tomáš</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Ležík Matěj</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Hvižď Michal</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Lahučký Tomáš</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Ležík Matěj</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Lahučký Tomáš</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Lahučký Tomáš</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Hvižď Michal</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Ležík Matěj</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Hvižď Michal</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>5 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>5 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Ležík Matěj</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fuchs Petr</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Fuchs Petr</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>8 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>5 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Hvižď Michal</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Fuchs Petr</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ležík Matěj</td><td class=bc>-</td><td class=bl>Hvižď Michal</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=bl>Fuchs Petr</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>2 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>To Bucek</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kL>3:7</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kW>5:2</td>
<td class=kT>5:5</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>5:4</td>
<td class=kW>9:0</td>
<td class=kW>8:2</td>
<td class=kW>5:0 K</td>
<td class=br>78:46</td><td class=br>+32</td>
<td class=bc>12 - 4 - 3</td>
<td class=br><strong>28</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Da Matýsek</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kW>5:2</td>
<td class=kW>8:1</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0 K</td>
<td class=br>65:41</td><td class=br>+24</td>
<td class=bc>12 - 4 - 3</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Ku Sládek</td><td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>6:4</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>5:0 K</td>
<td class=br>73:42</td><td class=br>+31</td>
<td class=bc>12 - 3 - 4</td>
<td class=br><strong>27</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Mi Kubica</td><td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kW>7:1</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>7:2</td>
<td class=kT>2:2</td>
<td class=kW>7:0</td>
<td class=kW>5:0 K</td>
<td class=br>75:38</td><td class=br>+37</td>
<td class=bc>11 - 4 - 4</td>
<td class=br><strong>26</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=d>5.</td><td class=kt>Ja Dryák</td><td class=kW>7:3</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>9:3</td>
<td class=kW>5:1</td>
<td class=kL>3:5</td>
<td class=kW>6:2</td>
<td class=kL>3:5</td>
<td class=kL>5:6</td>
<td class=kW>4:2</td>
<td class=kW>9:0</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kW>9:1</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>5:0 K</td>
<td class=br>95:49</td><td class=br>+46</td>
<td class=bc>12 - 2 - 5</td>
<td class=br><strong>26</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=d>6.</td><td class=kt>Ji Vácha</td><td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kW>6:4</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>8:3</td>
<td class=kW>5:0 K</td>
<td class=br>70:44</td><td class=br>+26</td>
<td class=bc>11 - 4 - 4</td>
<td class=br><strong>26</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/4</td><td class=d>7.</td><td class=kt>Ti Dion</td><td class=kW>4:1</td>
<td class=kL>3:6</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>3:9</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0 K</td>
<td class=br>63:47</td><td class=br>+16</td>
<td class=bc>11 - 3 - 5</td>
<td class=br><strong>25</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/4</td><td class=d>8.</td><td class=kt>Ad Kopřiva</td><td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>5:0 K</td>
<td class=br>58:40</td><td class=br>+18</td>
<td class=bc>10 - 5 - 4</td>
<td class=br><strong>25</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Zd Lopaur</td><td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kW>5:3</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kW>4:0</td>
<td class=kL>4:6</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0 K</td>
<td class=br>61:49</td><td class=br>+12</td>
<td class=bc>10 - 2 - 7</td>
<td class=br><strong>22</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ti Varga</td><td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>2:6</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kL>2:6</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>5:0 K</td>
<td class=br>46:44</td><td class=br>+2</td>
<td class=bc>8 - 6 - 5</td>
<td class=br><strong>22</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Mi Mašika</td><td class=kT>5:5</td>
<td class=kL>3:4</td>
<td class=kL>2:6</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kL>4:6</td>
<td class=kL>2:4</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>5:0 K</td>
<td class=br>67:58</td><td class=br>+9</td>
<td class=bc>8 - 5 - 6</td>
<td class=br><strong>21</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Mi Uhlíř</td><td class=kL>2:5</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kL>1:7</td>
<td class=kW>6:5</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>6:3</td>
<td class=kW>5:0 K</td>
<td class=br>65:60</td><td class=br>+5</td>
<td class=bc>8 - 4 - 7</td>
<td class=br><strong>20</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Fr Marek</td><td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>6:3</td>
<td class=kW>4:3</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kW>5:0 K</td>
<td class=br>51:58</td><td class=br>-7</td>
<td class=bc>6 - 5 - 8</td>
<td class=br><strong>17</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Pe Holub</td><td class=kL>2:6</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>0:9</td>
<td class=kL>4:6</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>6:2</td>
<td class=kL>2:5</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>5:0 K</td>
<td class=br>60:66</td><td class=br>-6</td>
<td class=bc>7 - 2 - 10</td>
<td class=br><strong>16</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Hy Nechutný</td><td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kT>0:0</td>
<td class=kW>5:0 K</td>
<td class=br>35:41</td><td class=br>-6</td>
<td class=bc>7 - 2 - 10</td>
<td class=br><strong>16</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Mi Moravec</td><td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kW>6:4</td>
<td class=kT>2:2</td>
<td class=kL>3:6</td>
<td class=kL>1:6</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>5:0 K</td>
<td class=br>40:65</td><td class=br>-25</td>
<td class=bc>5 - 2 - 12</td>
<td class=br><strong>12</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Fr Rasche</td><td class=kL>4:5</td>
<td class=kL>0:3</td>
<td class=kL>4:6</td>
<td class=kL>2:7</td>
<td class=kL>1:9</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>1:7</td>
<td class=kW>6:4</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0 K</td>
<td class=br>54:81</td><td class=br>-27</td>
<td class=bc>5 - 1 - 13</td>
<td class=br><strong>11</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Ja Kopecký</td><td class=kL>0:9</td>
<td class=kL>2:4</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>0:6</td>
<td class=kW>5:1</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:0 K</td>
<td class=br>33:73</td><td class=br>-40</td>
<td class=bc>3 - 1 - 15</td>
<td class=br><strong>7</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Pa Janouškovec</td><td class=kL>2:8</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kL>3:8</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>0:5</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kT>0:0</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:0 K</td>
<td class=br>29:81</td><td class=br>-52</td>
<td class=bc>1 - 3 - 15</td>
<td class=br><strong>5</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Jo Vomáčka</td><td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kx>*</td>
<td class=br>0:95</td><td class=br>-95</td>
<td class=bc>0 - 0 - 19</td>
<td class=br><strong>0</strong></td><td class=d>20.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Dryák Jan</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Dion Till</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=bl>Varga Tibor</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kopřiva Adam</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Kopecký Jaroslav</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Mašika Michal</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>5 : 0 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Dryák Jan</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Dion Till</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Varga Tibor</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Uhlíř Miroslav</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Kopecký Jaroslav</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Kopřiva Adam</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Dryák Jan</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Varga Tibor</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Dion Till</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Kopecký Jaroslav</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=blW>Mašika Michal</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Kopřiva Adam</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Holub Petr</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=blW>Varga Tibor</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Dryák Jan</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Kopecký Jaroslav</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Dion Till</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Kopřiva Adam</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Varga Tibor</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Holub Petr</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=blW>Kopecký Jaroslav</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Dryák Jan</td><td class=bc>-</td><td class=blW>Mašika Michal</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Dion Till</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Kopřiva Adam</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Varga Tibor</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Rasche Frank</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Kopecký Jaroslav</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Mašika Michal</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Marek František</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Dryák Jan</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Dion Till</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Kopřiva Adam</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Varga Tibor</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Kopecký Jaroslav</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Mašika Michal</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Dryák Jan</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Kopřiva Adam</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Dion Till</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Uhlíř Miroslav</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Rasche Frank</td><td class=bc>-</td><td class=bl>Kopecký Jaroslav</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Varga Tibor</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=blW>Kopřiva Adam</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Dryák Jan</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Uhlíř Miroslav</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Dion Till</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Kopecký Jaroslav</td><td class=bc>-</td><td class=blW>Mašika Michal</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Rasche Frank</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Varga Tibor</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Kopřiva Adam</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=blW>Uhlíř Miroslav</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Dryák Jan</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Dion Till</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Mašika Michal</td><td class=bc>-</td><td class=bl>Vomáčka Josef</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Kopecký Jaroslav</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Varga Tibor</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Kopřiva Adam</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=bl>Uhlíř Miroslav</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=bl>Dion Till</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Dryák Jan</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Mašika Michal</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kopecký Jaroslav</td><td class=bc>-</td><td class=blW>Kopřiva Adam</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Varga Tibor</td><td class=bc>-</td><td class=bl>Uhlíř Miroslav</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Dion Till</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Dryák Jan</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Kopřiva Adam</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Kopecký Jaroslav</td><td class=bc>-</td><td class=blW>Uhlíř Miroslav</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Varga Tibor</td><td class=bc>-</td><td class=bl>Dion Till</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Dryák Jan</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=blW>Marek František</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Kopřiva Adam</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Uhlíř Miroslav</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kopecký Jaroslav</td><td class=bc>-</td><td class=blW>Dion Till</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Rasche Frank</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Varga Tibor</td><td class=bc>-</td><td class=blW>Dryák Jan</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Marek František</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Uhlíř Miroslav</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Dion Till</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kopecký Jaroslav</td><td class=bc>-</td><td class=blW>Dryák Jan</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Marek František</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Varga Tibor</td><td class=bc>-</td><td class=blW>Holub Petr</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Kopřiva Adam</td><td class=bc>-</td><td class=blW>Uhlíř Miroslav</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Dion Till</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Dryák Jan</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kopecký Jaroslav</td><td class=bc>-</td><td class=blW>Holub Petr</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Varga Tibor</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kopřiva Adam</td><td class=bc>-</td><td class=blW>Dion Till</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Dryák Jan</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Holub Petr</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Kopecký Jaroslav</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Varga Tibor</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=blW>Dion Till</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kopřiva Adam</td><td class=bc>-</td><td class=blW>Dryák Jan</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=blW>Marek František</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Holub Petr</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Janouškovec Pavel</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Kopecký Jaroslav</td><td class=bc>-</td><td class=blW>Varga Tibor</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Uhlíř Miroslav</td><td class=bc>-</td><td class=bl>Dryák Jan</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kopřiva Adam</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Varga Tibor</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Rasche Frank</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kopecký Jaroslav</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Dion Till</td><td class=bc>-</td><td class=blW>Dryák Jan</td><td class=bc>3 : 9</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=blW>Holub Petr</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kopřiva Adam</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Varga Tibor</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=blW>Kopecký Jaroslav</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Marek František</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Dion Till</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Uhlíř Miroslav</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kopřiva Adam</td><td class=bc>-</td><td class=bl>Varga Tibor</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Kopecký Jaroslav</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Vomáčka Josef</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Ví Pernica</td><td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>11:2</td>
<td class=kW>7:0</td>
<td class=kW>7:1</td>
<td class=kW>8:0</td>
<td class=kW>8:3</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>9:0</td>
<td class=kW>6:1</td>
<td class=kW>8:0</td>
<td class=kW>10:0</td>
<td class=kW>5:0 K</td>
<td class=br>112:23</td><td class=br>+89</td>
<td class=bc>18 - 0 - 0</td>
<td class=br><strong>36</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Ma Šperňák</td><td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>8:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>11:0</td>
<td class=kW>9:1</td>
<td class=kW>5:0</td>
<td class=kW>12:0</td>
<td class=kW>5:0 K</td>
<td class=br>84:20</td><td class=br>+64</td>
<td class=bc>13 - 4 - 1</td>
<td class=br><strong>30</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Ma Moravec</td><td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0 K</td>
<td class=br>56:30</td><td class=br>+26</td>
<td class=bc>14 - 2 - 2</td>
<td class=br><strong>30</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Da Kadlec</td><td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>5:5</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>6:3</td>
<td class=kW>7:4</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>7:3</td>
<td class=kW>5:1</td>
<td class=kW>7:3</td>
<td class=kW>5:0 K</td>
<td class=br>86:36</td><td class=br>+50</td>
<td class=bc>14 - 1 - 3</td>
<td class=br><strong>29</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=d>5.</td><td class=kt>On Chlebo</td><td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0 K</td>
<td class=br>70:30</td><td class=br>+40</td>
<td class=bc>13 - 2 - 3</td>
<td class=br><strong>28</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=d>6.</td><td class=kt>Ra Hrnčíř</td><td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kT>5:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>7:0</td>
<td class=kW>9:1</td>
<td class=kW>7:2</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=kW>5:0 K</td>
<td class=br>82:31</td><td class=br>+51</td>
<td class=bc>12 - 2 - 4</td>
<td class=br><strong>26</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/4</td><td class=d>7.</td><td class=kt>Pe Klazar</td><td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>6:5</td>
<td class=kL>0:3</td>
<td class=kW>5:2</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>5:4</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>5:0 K</td>
<td class=br>53:45</td><td class=br>+8</td>
<td class=bc>10 - 2 - 6</td>
<td class=br><strong>22</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/4</td><td class=d>8.</td><td class=kt>Kr Soudek</td><td class=kL>2:11</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kL>5:6</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>12:2</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0 K</td>
<td class=br>72:51</td><td class=br>+21</td>
<td class=bc>10 - 2 - 6</td>
<td class=br><strong>22</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Vo Pošík</td><td class=kL>0:7</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kL>0:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>10:0</td>
<td class=kW>5:0 K</td>
<td class=br>50:35</td><td class=br>+15</td>
<td class=bc>10 - 0 - 8</td>
<td class=br><strong>20</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ji Pošík</td><td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kW>4:2</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>5:0 K</td>
<td class=br>46:55</td><td class=br>-9</td>
<td class=bc>8 - 1 - 9</td>
<td class=br><strong>17</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Mi Matuštík</td><td class=kL>0:8</td>
<td class=kL>0:4</td>
<td class=kL>0:1</td>
<td class=kL>3:6</td>
<td class=kL>2:7</td>
<td class=kL>1:9</td>
<td class=kW>5:2</td>
<td class=kL>1:7</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>5:0 K</td>
<td class=br>39:64</td><td class=br>-25</td>
<td class=bc>7 - 1 - 10</td>
<td class=br><strong>15</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Vá Bláha</td><td class=kL>3:8</td>
<td class=kL>2:8</td>
<td class=kL>2:3</td>
<td class=kL>4:7</td>
<td class=kL>2:7</td>
<td class=kL>2:7</td>
<td class=kW>5:0</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kL>0:2</td>
<td class=kW>5:0 K</td>
<td class=br>49:66</td><td class=br>-17</td>
<td class=bc>6 - 1 - 11</td>
<td class=br><strong>13</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ja Kubica</td><td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>6:4</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>5:0 K</td>
<td class=br>47:55</td><td class=br>-8</td>
<td class=bc>6 - 1 - 11</td>
<td class=br><strong>13</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Da Polaštíková</td><td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0 K</td>
<td class=br>31:40</td><td class=br>-9</td>
<td class=bc>5 - 3 - 10</td>
<td class=br><strong>13</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Vá Bláha</td><td class=kL>0:9</td>
<td class=kL>0:11</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>0:5</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>5:0 K</td>
<td class=br>28:68</td><td class=br>-40</td>
<td class=bc>4 - 1 - 13</td>
<td class=br><strong>9</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>To Urban</td><td class=kL>1:6</td>
<td class=kL>1:9</td>
<td class=kL>1:5</td>
<td class=kL>3:7</td>
<td class=kL>2:6</td>
<td class=kL>0:6</td>
<td class=kL>4:5</td>
<td class=kL>2:12</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>4:5</td>
<td class=kL>2:5</td>
<td class=kL>4:6</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>5:0 K</td>
<td class=br>41:84</td><td class=br>-43</td>
<td class=bc>2 - 3 - 13</td>
<td class=br><strong>7</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ka Mendová</td><td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:0 K</td>
<td class=br>23:80</td><td class=br>-57</td>
<td class=bc>3 - 1 - 14</td>
<td class=br><strong>7</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Št Bláha</td><td class=kL>0:10</td>
<td class=kL>0:12</td>
<td class=kL>2:3</td>
<td class=kL>3:7</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>0:10</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:0 K</td>
<td class=br>22:88</td><td class=br>-66</td>
<td class=bc>2 - 1 - 15</td>
<td class=br><strong>5</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Ma Pokorný</td><td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kx>*</td>
<td class=br>0:90</td><td class=br>-90</td>
<td class=bc>0 - 0 - 18</td>
<td class=br><strong>0</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Chlebo Ondřej</td><td class=bc>-</td><td class=bl>Pokorný Matěj</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Bláha Štěpán</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pošík Jiří</td><td class=bc>-</td><td class=bl>Matuštík Milan</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kadlec Daniel</td><td class=bc>-</td><td class=bl>Mendová Karolína</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Bláha Václav</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Soudek Kryštof</td><td class=bc>-</td><td class=bl>Polaštíková Daniela</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Šperňák Marek</td><td class=bc>-</td><td class=bl>Bláha Václav ml.</td><td class=bc>11 : 0</tr></td>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=blW>Klazar Petr</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Pokorný Matěj</td><td class=bc>-</td><td class=blW>Bláha Štěpán</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Chlebo Ondřej</td><td class=bc>-</td><td class=bl>Matuštík Milan</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Mendová Karolína</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Pošík Jiří</td><td class=bc>-</td><td class=bl>Bláha Václav</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kadlec Daniel</td><td class=bc>-</td><td class=bl>Polaštíková Daniela</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Soudek Kryštof</td><td class=bc>-</td><td class=bl>Bláha Václav ml.</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Šperňák Marek</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Bláha Štěpán</td><td class=bc>-</td><td class=blW>Matuštík Milan</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pokorný Matěj</td><td class=bc>-</td><td class=blW>Mendová Karolína</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Chlebo Ondřej</td><td class=bc>-</td><td class=bl>Bláha Václav</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Polaštíková Daniela</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pošík Jiří</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kadlec Daniel</td><td class=bc>-</td><td class=bl>Bláha Václav ml.</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Klazar Petr</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Soudek Kryštof</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Kubica Jan</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Matuštík Milan</td><td class=bc>-</td><td class=bl>Mendová Karolína</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Bláha Štěpán</td><td class=bc>-</td><td class=bl>Bláha Václav</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Pokorný Matěj</td><td class=bc>-</td><td class=blW>Polaštíková Daniela</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Chlebo Ondřej</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Bláha Václav ml.</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Klazar Petr</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kadlec Daniel</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Kubica Jan</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Soudek Kryštof</td><td class=bc>-</td><td class=bl>Šperňák Marek</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Mendová Karolína</td><td class=bc>-</td><td class=blW>Bláha Václav</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Matuštík Milan</td><td class=bc>-</td><td class=bl>Polaštíková Daniela</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Bláha Štěpán</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pokorný Matěj</td><td class=bc>-</td><td class=blW>Bláha Václav ml.</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Chlebo Ondřej</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Kubica Jan</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Šperňák Marek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Bláha Václav</td><td class=bc>-</td><td class=bl>Polaštíková Daniela</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mendová Karolína</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Matuštík Milan</td><td class=bc>-</td><td class=bl>Bláha Václav ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Bláha Štěpán</td><td class=bc>-</td><td class=blW>Klazar Petr</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Pokorný Matěj</td><td class=bc>-</td><td class=blW>Pošík Vojtěch</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Chlebo Ondřej</td><td class=bc>-</td><td class=bl>Kubica Jan</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=bl>Šperňák Marek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Kadlec Daniel</td><td class=bc>-</td><td class=bl>Soudek Kryštof</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Polaštíková Daniela</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Bláha Václav</td><td class=bc>-</td><td class=blW>Bláha Václav ml.</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mendová Karolína</td><td class=bc>-</td><td class=blW>Klazar Petr</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Matuštík Milan</td><td class=bc>-</td><td class=blW>Pošík Vojtěch</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Bláha Štěpán</td><td class=bc>-</td><td class=blW>Kubica Jan</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pokorný Matěj</td><td class=bc>-</td><td class=blW>Šperňák Marek</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Soudek Kryštof</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Urban Tomáš</td><td class=bc>-</td><td class=bl>Bláha Václav ml.</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Polaštíková Daniela</td><td class=bc>-</td><td class=blW>Klazar Petr</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Bláha Václav</td><td class=bc>-</td><td class=blW>Pošík Vojtěch</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mendová Karolína</td><td class=bc>-</td><td class=bl>Kubica Jan</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Matuštík Milan</td><td class=bc>-</td><td class=blW>Šperňák Marek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Bláha Štěpán</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Pokorný Matěj</td><td class=bc>-</td><td class=blW>Soudek Kryštof</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Bláha Václav ml.</td><td class=bc>-</td><td class=blW>Klazar Petr</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=blW>Pošík Vojtěch</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Polaštíková Daniela</td><td class=bc>-</td><td class=blW>Kubica Jan</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Bláha Václav</td><td class=bc>-</td><td class=blW>Šperňák Marek</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Mendová Karolína</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Matuštík Milan</td><td class=bc>-</td><td class=blW>Soudek Kryštof</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Bláha Štěpán</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Pokorný Matěj</td><td class=bc>-</td><td class=blW>Kadlec Daniel</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Chlebo Ondřej</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Pošík Vojtěch</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Bláha Václav ml.</td><td class=bc>-</td><td class=blW>Kubica Jan</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=blW>Šperňák Marek</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Polaštíková Daniela</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Bláha Václav</td><td class=bc>-</td><td class=blW>Soudek Kryštof</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mendová Karolína</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Matuštík Milan</td><td class=bc>-</td><td class=blW>Kadlec Daniel</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Bláha Štěpán</td><td class=bc>-</td><td class=blW>Pošík Jiří</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Pokorný Matěj</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>0 : 5 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Pošík Vojtěch</td><td class=bc>-</td><td class=bl>Kubica Jan</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=bl>Šperňák Marek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Bláha Václav ml.</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=blW>Soudek Kryštof</td><td class=bc>2 : 12</tr></td>
<tr><td class=br>Polaštíková Daniela</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Bláha Václav</td><td class=bc>-</td><td class=blW>Kadlec Daniel</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Mendová Karolína</td><td class=bc>-</td><td class=blW>Pošík Jiří</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Matuštík Milan</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Bláha Štěpán</td><td class=bc>-</td><td class=blW>Chlebo Ondřej</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=blW>Šperňák Marek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Klazar Petr</td><td class=bc>-</td><td class=bl>Soudek Kryštof</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Bláha Václav ml.</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=blW>Kadlec Daniel</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Polaštíková Daniela</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Bláha Václav</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mendová Karolína</td><td class=bc>-</td><td class=blW>Chlebo Ondřej</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Matuštík Milan</td><td class=bc>-</td><td class=bl>Pokorný Matěj</td><td class=bc>5 : 0 K</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Šperňák Marek</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=bl>Soudek Kryštof</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Kadlec Daniel</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Bláha Václav ml.</td><td class=bc>-</td><td class=blW>Pošík Jiří</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Polaštíková Daniela</td><td class=bc>-</td><td class=blW>Chlebo Ondřej</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Bláha Václav</td><td class=bc>-</td><td class=bl>Pokorný Matěj</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Mendová Karolína</td><td class=bc>-</td><td class=bl>Bláha Štěpán</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Soudek Kryštof</td><td class=bc>11 : 2</tr></td>
<tr><td class=brW>Šperňák Marek</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=blW>Kadlec Daniel</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Pošík Vojtěch</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Bláha Václav ml.</td><td class=bc>-</td><td class=blW>Chlebo Ondřej</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Urban Tomáš</td><td class=bc>-</td><td class=bl>Pokorný Matěj</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Polaštíková Daniela</td><td class=bc>-</td><td class=bl>Bláha Štěpán</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Bláha Václav</td><td class=bc>-</td><td class=bl>Matuštík Milan</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Soudek Kryštof</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Šperňák Marek</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Chlebo Ondřej</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Klazar Petr</td><td class=bc>-</td><td class=bl>Pokorný Matěj</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Bláha Václav ml.</td><td class=bc>-</td><td class=bl>Bláha Štěpán</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=blW>Matuštík Milan</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Polaštíková Daniela</td><td class=bc>-</td><td class=bl>Mendová Karolína</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Soudek Kryštof</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Šperňák Marek</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kubica Jan</td><td class=bc>-</td><td class=bl>Pokorný Matěj</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Pošík Vojtěch</td><td class=bc>-</td><td class=bl>Bláha Štěpán</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Matuštík Milan</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Bláha Václav ml.</td><td class=bc>-</td><td class=bl>Mendová Karolína</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=blW>Bláha Václav</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Kadlec Daniel</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Soudek Kryštof</td><td class=bc>-</td><td class=blW>Chlebo Ondřej</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Pokorný Matěj</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Šperňák Marek</td><td class=bc>-</td><td class=bl>Bláha Štěpán</td><td class=bc>12 : 0</tr></td>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=blW>Matuštík Milan</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pošík Vojtěch</td><td class=bc>-</td><td class=bl>Mendová Karolína</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Bláha Václav</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Bláha Václav ml.</td><td class=bc>-</td><td class=blW>Polaštíková Daniela</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Pošík Jiří</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kadlec Daniel</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Pokorný Matěj</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Soudek Kryštof</td><td class=bc>-</td><td class=bl>Bláha Štěpán</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Matuštík Milan</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Šperňák Marek</td><td class=bc>-</td><td class=bl>Mendová Karolína</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=blW>Bláha Václav</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Polaštíková Daniela</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Klazar Petr</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pošík Jiří</td><td class=bc>-</td><td class=bl>Pokorný Matěj</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Kadlec Daniel</td><td class=bc>-</td><td class=bl>Bláha Štěpán</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Matuštík Milan</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Soudek Kryštof</td><td class=bc>-</td><td class=bl>Mendová Karolína</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Bláha Václav</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Šperňák Marek</td><td class=bc>-</td><td class=bl>Polaštíková Daniela</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kubica Jan</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Pošík Vojtěch</td><td class=bc>-</td><td class=bl>Bláha Václav ml.</td><td class=bc>3 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
