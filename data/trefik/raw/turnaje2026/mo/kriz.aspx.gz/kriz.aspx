<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Moravia Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/pohar13.aspx">U13</a>
&nbsp;<a href="../data/pohar55.aspx">55+</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Moravia Open, 4. říjen 2025</span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Základní skupiny (Basic groups)</a><br>
<a href="#final">Výkonnostní skupiny (Final groups)</a><br>
<a name="basic"><p class=vm>Základní skupiny (Basic groups)</p></a>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ra Kalninš</td><td class=kx>*</td>
<td class=kW>7:0</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>10:0</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>8:0</td>
<td class=kW>8:2</td>
<td class=kW>5:1</td>
<td class=kW>8:0</td>
<td class=kW>9:1</td>
<td class=br>70:11</td><td class=br>+59</td>
<td class=bc>10 - 1 - 0</td>
<td class=br><strong>21</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Al Krejza</td><td class=kL>0:7</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>8:1</td>
<td class=kW>7:0</td>
<td class=br>37:19</td><td class=br>+18</td>
<td class=bc>7 - 2 - 2</td>
<td class=br><strong>16</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ku Sládek</td><td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>8:0</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>9:3</td>
<td class=kW>8:0</td>
<td class=kW>7:0</td>
<td class=br>49:17</td><td class=br>+32</td>
<td class=bc>6 - 3 - 2</td>
<td class=br><strong>15</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Pa Plešák</td><td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kL>2:5</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>9:0</td>
<td class=kW>6:1</td>
<td class=br>44:23</td><td class=br>+21</td>
<td class=bc>7 - 1 - 3</td>
<td class=br><strong>15</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Da Dvořáček</td><td class=kL>0:10</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>9:0</td>
<td class=kW>8:0</td>
<td class=kW>11:0</td>
<td class=br>50:35</td><td class=br>+15</td>
<td class=bc>7 - 0 - 4</td>
<td class=br><strong>14</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>To Růžička</td><td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>8:1</td>
<td class=kW>7:0</td>
<td class=br>43:25</td><td class=br>+18</td>
<td class=bc>6 - 2 - 3</td>
<td class=br><strong>14</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Os Tabara</td><td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=br>31:30</td><td class=br>+1</td>
<td class=bc>5 - 3 - 3</td>
<td class=br><strong>13</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Do Zupančič</td><td class=kL>0:8</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>8:1</td>
<td class=kW>7:0</td>
<td class=br>32:26</td><td class=br>+6</td>
<td class=bc>3 - 3 - 5</td>
<td class=br><strong>9</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ja Tomáštík</td><td class=kL>2:8</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>8:2</td>
<td class=kW>6:2</td>
<td class=br>32:36</td><td class=br>-4</td>
<td class=bc>3 - 3 - 5</td>
<td class=br><strong>9</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Vě Stanzelová</td><td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>3:9</td>
<td class=kL>1:6</td>
<td class=kL>0:9</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=br>18:54</td><td class=br>-36</td>
<td class=bc>2 - 0 - 9</td>
<td class=br><strong>4</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>To Šudřích</td><td class=kL>0:8</td>
<td class=kL>1:8</td>
<td class=kL>0:8</td>
<td class=kL>0:9</td>
<td class=kL>0:8</td>
<td class=kL>1:8</td>
<td class=kL>1:3</td>
<td class=kL>1:8</td>
<td class=kL>2:8</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=br>10:74</td><td class=br>-64</td>
<td class=bc>1 - 0 - 10</td>
<td class=br><strong>2</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Vo Pošík</td><td class=kL>1:9</td>
<td class=kL>0:7</td>
<td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kL>0:11</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>2:6</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=br>9:75</td><td class=br>-66</td>
<td class=bc>0 - 0 - 11</td>
<td class=br><strong>0</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Tomáštík Jan</td><td class=bc>-</td><td class=bl>Šudřích Tomáš</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Zupančič Domen</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Stanzelová Věra</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=bl>Kalninš Rainers</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Šudřích Tomáš</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Tomáštík Jan</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Zupančič Domen</td><td class=bc>-</td><td class=blW>Kalninš Rainers</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Stanzelová Věra</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Šudřích Tomáš</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Tomáštík Jan</td><td class=bc>-</td><td class=blW>Kalninš Rainers</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Zupančič Domen</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Stanzelová Věra</td><td class=bc>-</td><td class=blW>Tabara Oskar</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Kalninš Rainers</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Šudřích Tomáš</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Tomáštík Jan</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=blW>Tabara Oskar</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Zupančič Domen</td><td class=bc>-</td><td class=bl>Stanzelová Věra</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Kalninš Rainers</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Šudřích Tomáš</td><td class=bc>-</td><td class=blW>Tabara Oskar</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Tomáštík Jan</td><td class=bc>-</td><td class=bl>Stanzelová Věra</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Zupančič Domen</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Stanzelová Věra</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Šudřích Tomáš</td><td class=bc>-</td><td class=blW>Zupančič Domen</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Tomáštík Jan</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Stanzelová Věra</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Zupančič Domen</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Tomáštík Jan</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Šudřích Tomáš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Stanzelová Věra</td><td class=bc>9 : 3</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Zupančič Domen</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Tomáštík Jan</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Šudřích Tomáš</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=bl>Zupančič Domen</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Tomáštík Jan</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Šudřích Tomáš</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Stanzelová Věra</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=bl>Tomáštík Jan</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Šudřích Tomáš</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Zupančič Domen</td><td class=bc>-</td><td class=bl>Tomáštík Jan</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Stanzelová Věra</td><td class=bc>-</td><td class=bl>Šudřích Tomáš</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Tabara Oskar</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Kalninš Rainers</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Šudřích Tomáš</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Zupančič Domen</td><td class=bc>-</td><td class=blW>Dvořáček David</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Stanzelová Věra</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Tabara Oskar</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Kalninš Rainers</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ra Miglinieks</td><td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>10:2</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>6:5</td>
<td class=kW>7:5</td>
<td class=kW>10:2</td>
<td class=kW>3:0</td>
<td class=kW>7:0</td>
<td class=kW>10:0</td>
<td class=br>70:22</td><td class=br>+48</td>
<td class=bc>11 - 0 - 0</td>
<td class=br><strong>22</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Mi Hvižď</td><td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>7:2</td>
<td class=kW>10:3</td>
<td class=kW>9:2</td>
<td class=kW>9:1</td>
<td class=kW>8:1</td>
<td class=kW>8:1</td>
<td class=kW>9:0</td>
<td class=br>74:18</td><td class=br>+56</td>
<td class=bc>10 - 0 - 1</td>
<td class=br><strong>20</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>To Bucek</td><td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>9:2</td>
<td class=kW>9:0</td>
<td class=kW>7:1</td>
<td class=kW>8:1</td>
<td class=kW>2:1</td>
<td class=kW>8:0</td>
<td class=br>52:18</td><td class=br>+34</td>
<td class=bc>7 - 2 - 2</td>
<td class=br><strong>16</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Mi Boštík</td><td class=kL>2:10</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>7:3</td>
<td class=kW>5:1</td>
<td class=kW>5:4</td>
<td class=kW>6:1</td>
<td class=kW>8:0</td>
<td class=kW>5:0</td>
<td class=br>50:31</td><td class=br>+19</td>
<td class=bc>8 - 0 - 3</td>
<td class=br><strong>16</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ti Varga</td><td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>7:1</td>
<td class=br>44:20</td><td class=br>+24</td>
<td class=bc>7 - 1 - 3</td>
<td class=br><strong>15</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Vl Kraus</td><td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kT>1:1</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>9:0</td>
<td class=br>40:25</td><td class=br>+15</td>
<td class=bc>6 - 1 - 4</td>
<td class=br><strong>13</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Mi Uhlíř</td><td class=kL>5:6</td>
<td class=kL>3:10</td>
<td class=kL>2:9</td>
<td class=kL>3:7</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kW>7:1</td>
<td class=kW>8:1</td>
<td class=kW>10:0</td>
<td class=br>51:47</td><td class=br>+4</td>
<td class=bc>4 - 1 - 6</td>
<td class=br><strong>9</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Li Kondrashevskyi</td><td class=kL>5:7</td>
<td class=kL>2:9</td>
<td class=kL>0:9</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>7:0</td>
<td class=kW>7:2</td>
<td class=kW>8:1</td>
<td class=br>39:50</td><td class=br>-11</td>
<td class=bc>3 - 2 - 6</td>
<td class=br><strong>8</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Pe Klazar</td><td class=kL>2:10</td>
<td class=kL>1:9</td>
<td class=kL>1:7</td>
<td class=kL>4:5</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=br>29:51</td><td class=br>-22</td>
<td class=bc>3 - 1 - 7</td>
<td class=br><strong>7</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Mi Grepl</td><td class=kL>0:3</td>
<td class=kL>1:8</td>
<td class=kL>1:8</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:7</td>
<td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>7:0</td>
<td class=br>16:57</td><td class=br>-41</td>
<td class=bc>1 - 1 - 9</td>
<td class=br><strong>3</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>Ma Grepl</td><td class=kL>0:7</td>
<td class=kL>1:8</td>
<td class=kL>1:2</td>
<td class=kL>0:8</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>1:8</td>
<td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=br>15:60</td><td class=br>-45</td>
<td class=bc>1 - 1 - 9</td>
<td class=br><strong>3</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ja Janků</td><td class=kL>0:10</td>
<td class=kL>0:9</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kL>0:9</td>
<td class=kL>0:10</td>
<td class=kL>1:8</td>
<td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=br>4:85</td><td class=br>-81</td>
<td class=bc>0 - 0 - 11</td>
<td class=br><strong>0</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Hvižď Michal</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Boštík Michal</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Grepl Miroslav</td><td class=bc>-</td><td class=blW>Kondrashevskyi Liubomyr</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Janků Jakub</td><td class=bc>-</td><td class=blW>Grepl Matej</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=blW>Varga Tibor</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Boštík Michal</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Kondrashevskyi Liubomyr</td><td class=bc>7 : 5</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Grepl Matej</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Grepl Miroslav</td><td class=bc>-</td><td class=blW>Varga Tibor</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Janků Jakub</td><td class=bc>-</td><td class=blW>Klazar Petr</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Kondrashevskyi Liubomyr</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Grepl Matej</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Varga Tibor</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Grepl Miroslav</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Janků Jakub</td><td class=bc>-</td><td class=blW>Uhlíř Miroslav</td><td class=bc>0 : 10</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=bl>Grepl Matej</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Varga Tibor</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Uhlíř Miroslav</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Grepl Miroslav</td><td class=bc>-</td><td class=bl>Janků Jakub</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Grepl Matej</td><td class=bc>-</td><td class=blW>Varga Tibor</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Uhlíř Miroslav</td><td class=bc>10 : 3</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Janků Jakub</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Grepl Miroslav</td><td class=bc>8 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Varga Tibor</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Grepl Matej</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=bl>Uhlíř Miroslav</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Janků Jakub</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Grepl Miroslav</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Uhlíř Miroslav</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Varga Tibor</td><td class=bc>-</td><td class=bl>Janků Jakub</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Grepl Matej</td><td class=bc>-</td><td class=bl>Grepl Miroslav</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Boštík Michal</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>2 : 10</tr></td>
<tr><td class=br>Hvižď Michal</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Janků Jakub</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Klazar Petr</td><td class=bc>-</td><td class=bl>Grepl Miroslav</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Varga Tibor</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Grepl Matej</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Boštík Michal</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Uhlíř Miroslav</td><td class=bc>-</td><td class=bl>Grepl Miroslav</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>2 : 10</tr></td>
<tr><td class=br>Varga Tibor</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Grepl Matej</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Janků Jakub</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Varga Tibor</td><td class=bc>-</td><td class=bl>Kondrashevskyi Liubomyr</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Grepl Matej</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Grepl Miroslav</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Janků Jakub</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Kondrashevskyi Liubomyr</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Klazar Petr</td><td class=bc>-</td><td class=bl>Grepl Matej</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Varga Tibor</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Grepl Miroslav</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Janků Jakub</td><td class=bc>-</td><td class=blW>Kondrashevskyi Liubomyr</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Uhlíř Miroslav</td><td class=bc>-</td><td class=bl>Grepl Matej</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Varga Tibor</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 3</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Va Dietze</td><td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>8:0</td>
<td class=kW>8:1</td>
<td class=kW>2:0</td>
<td class=br>53:18</td><td class=br>+35</td>
<td class=bc>10 - 1 - 0</td>
<td class=br><strong>21</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Pa Petr</td><td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kW>6:3</td>
<td class=kW>7:0</td>
<td class=kW>13:3</td>
<td class=kW>6:2</td>
<td class=kW>7:3</td>
<td class=kW>5:0</td>
<td class=kW>11:1</td>
<td class=kW>11:0</td>
<td class=br>81:18</td><td class=br>+63</td>
<td class=bc>10 - 0 - 1</td>
<td class=br><strong>20</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ma Klazar</td><td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>8:4</td>
<td class=kW>9:0</td>
<td class=kW>5:0</td>
<td class=kW>12:1</td>
<td class=kW>9:0</td>
<td class=br>58:22</td><td class=br>+36</td>
<td class=bc>8 - 0 - 3</td>
<td class=br><strong>16</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Mi Černoch</td><td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>8:0</td>
<td class=kW>9:0</td>
<td class=kW>8:0</td>
<td class=kW>10:0</td>
<td class=br>50:14</td><td class=br>+36</td>
<td class=bc>8 - 0 - 3</td>
<td class=br><strong>16</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>An Šurýn</td><td class=kT>3:3</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>8:2</td>
<td class=kW>4:0</td>
<td class=br>38:27</td><td class=br>+11</td>
<td class=bc>6 - 2 - 3</td>
<td class=br><strong>14</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ra Pommerenke</td><td class=kL>2:5</td>
<td class=kL>0:7</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kW>7:0</td>
<td class=br>33:25</td><td class=br>+8</td>
<td class=bc>5 - 3 - 3</td>
<td class=br><strong>13</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ví Pernica</td><td class=kL>2:5</td>
<td class=kL>3:13</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>2:7</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=br>35:41</td><td class=br>-6</td>
<td class=bc>4 - 2 - 5</td>
<td class=br><strong>10</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Fr Rasche</td><td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>4:8</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>6:2</td>
<td class=kW>9:0</td>
<td class=kW>9:1</td>
<td class=br>45:39</td><td class=br>+6</td>
<td class=bc>4 - 0 - 7</td>
<td class=br><strong>8</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Da Pavelka</td><td class=kL>2:5</td>
<td class=kL>3:7</td>
<td class=kL>0:9</td>
<td class=kL>0:8</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=br>31:47</td><td class=br>-16</td>
<td class=bc>3 - 2 - 6</td>
<td class=br><strong>8</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Mi Zeman</td><td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:9</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>13:0</td>
<td class=br>17:47</td><td class=br>-30</td>
<td class=bc>1 - 1 - 9</td>
<td class=br><strong>3</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>Jo Linek</td><td class=kL>1:8</td>
<td class=kL>1:11</td>
<td class=kL>1:12</td>
<td class=kL>0:8</td>
<td class=kL>2:8</td>
<td class=kL>0:6</td>
<td class=kL>2:7</td>
<td class=kL>0:9</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>9:0</td>
<td class=br>18:75</td><td class=br>-57</td>
<td class=bc>1 - 1 - 9</td>
<td class=br><strong>3</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ma Očenášek</td><td class=kL>0:2</td>
<td class=kL>0:11</td>
<td class=kL>0:9</td>
<td class=kL>0:10</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>1:9</td>
<td class=kL>0:7</td>
<td class=kL>0:13</td>
<td class=kL>0:9</td>
<td class=kx>*</td>
<td class=br>1:87</td><td class=br>-86</td>
<td class=bc>0 - 0 - 11</td>
<td class=br><strong>0</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Očenášek Matěj</td><td class=bc>11 : 0</tr></td>
<tr><td class=brW>Dietze Valentin</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Linek Jozef</td><td class=bc>-</td><td class=blW>Pavelka David</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Zeman Milan</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Očenášek Matěj</td><td class=bc>-</td><td class=blW>Pommerenke Ralph</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Dietze Valentin</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pavelka David</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Linek Jozef</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Zeman Milan</td><td class=bc>-</td><td class=blW>Rasche Frank</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Očenášek Matěj</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Dietze Valentin</td><td class=bc>-</td><td class=bl>Linek Jozef</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Rasche Frank</td><td class=bc>-</td><td class=bl>Pavelka David</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Zeman Milan</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Očenášek Matěj</td><td class=bc>-</td><td class=blW>Linek Jozef</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Pavelka David</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Dietze Valentin</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Zeman Milan</td><td class=bc>-</td><td class=blW>Pommerenke Ralph</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Dietze Valentin</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Linek Jozef</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=bl>Pavelka David</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Očenášek Matěj</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Zeman Milan</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Petr Patrik</td><td class=bc>-</td><td class=blW>Dietze Valentin</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Pavelka David</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Očenášek Matěj</td><td class=bc>-</td><td class=blW>Rasche Frank</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Zeman Milan</td><td class=bc>-</td><td class=bl>Linek Jozef</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Linek Jozef</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Očenášek Matěj</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Dietze Valentin</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Zeman Milan</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>0 : 9</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Pavelka David</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Linek Jozef</td><td class=bc>-</td><td class=blW>Rasche Frank</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Očenášek Matěj</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Zeman Milan</td><td class=bc>-</td><td class=blW>Dietze Valentin</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pavelka David</td><td class=bc>-</td><td class=blW>Dietze Valentin</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Linek Jozef</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 11</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Pommerenke Ralph</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Zeman Milan</td><td class=bc>-</td><td class=bl>Očenášek Matěj</td><td class=bc>13 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Dietze Valentin</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>3 : 13</tr></td>
<tr><td class=brW>Pavelka David</td><td class=bc>-</td><td class=bl>Očenášek Matěj</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Linek Jozef</td><td class=bc>-</td><td class=blW>Pommerenke Ralph</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Zeman Milan</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Očenášek Matěj</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pavelka David</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Linek Jozef</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>1 : 12</tr></td>
<tr><td class=br>Zeman Milan</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Dietze Valentin</td><td class=bc>-</td><td class=bl>Očenášek Matěj</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Pommerenke Ralph</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Linek Jozef</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Zeman Milan</td><td class=bc>-</td><td class=blW>Pavelka David</td><td class=bc>1 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 4</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Mi Kobrle</td><td class=kx>*</td>
<td class=kL>0:5</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>8:1</td>
<td class=kW>7:2</td>
<td class=kW>5:3</td>
<td class=kW>14:5</td>
<td class=kW>10:0</td>
<td class=kW>8:0</td>
<td class=kW>9:1</td>
<td class=br>77:20</td><td class=br>+57</td>
<td class=bc>10 - 0 - 1</td>
<td class=br><strong>20</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Vá Pikl</td><td class=kW>5:0</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kT>5:5</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>6:0</td>
<td class=kW>11:0</td>
<td class=br>42:20</td><td class=br>+22</td>
<td class=bc>8 - 1 - 2</td>
<td class=br><strong>17</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ja Obadič</td><td class=kL>1:5</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>7:3</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=br>44:24</td><td class=br>+20</td>
<td class=bc>8 - 0 - 3</td>
<td class=br><strong>16</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>My Shalomayev</td><td class=kL>1:6</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kW>9:0</td>
<td class=kW>7:0</td>
<td class=br>44:16</td><td class=br>+28</td>
<td class=bc>7 - 1 - 3</td>
<td class=br><strong>15</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>To Kahoun ml.</td><td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>6:4</td>
<td class=br>34:26</td><td class=br>+8</td>
<td class=bc>6 - 2 - 3</td>
<td class=br><strong>14</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Mi Moravec</td><td class=kL>1:8</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>9:0</td>
<td class=br>29:27</td><td class=br>+2</td>
<td class=bc>4 - 3 - 4</td>
<td class=br><strong>11</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Iv Fochlerová</td><td class=kL>2:7</td>
<td class=kT>5:5</td>
<td class=kL>3:7</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=br>32:40</td><td class=br>-8</td>
<td class=bc>4 - 2 - 5</td>
<td class=br><strong>10</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Mi Ševr</td><td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kW>9:1</td>
<td class=br>37:35</td><td class=br>+2</td>
<td class=bc>4 - 2 - 5</td>
<td class=br><strong>10</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ji Junek</td><td class=kL>5:14</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kW>8:1</td>
<td class=br>29:37</td><td class=br>-8</td>
<td class=bc>3 - 3 - 5</td>
<td class=br><strong>9</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ja Janouškovec</td><td class=kL>0:10</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>9:1</td>
<td class=br>27:35</td><td class=br>-8</td>
<td class=bc>4 - 0 - 7</td>
<td class=br><strong>8</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>Ja Paclik</td><td class=kL>0:8</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>0:9</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=br>8:50</td><td class=br>-42</td>
<td class=bc>1 - 0 - 10</td>
<td class=br><strong>2</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ja Šrámek</td><td class=kL>1:9</td>
<td class=kL>0:11</td>
<td class=kL>0:8</td>
<td class=kL>0:7</td>
<td class=kL>4:6</td>
<td class=kL>0:9</td>
<td class=kL>1:4</td>
<td class=kL>1:9</td>
<td class=kL>1:8</td>
<td class=kL>1:9</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=br>9:82</td><td class=br>-73</td>
<td class=bc>0 - 0 - 11</td>
<td class=br><strong>0</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Šrámek Jakub</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Obadič Jakob Zalokar</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Paclik Jakub</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Fochlerová Iva</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Junek Jiří</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Šrámek Jakub</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Obadič Jakob Zalokar</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Paclik Jakub</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fochlerová Iva</td><td class=bc>-</td><td class=blW>Junek Jiří</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Šrámek Jakub</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Obadič Jakob Zalokar</td><td class=bc>-</td><td class=bl>Junek Jiří</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Paclik Jakub</td><td class=bc>-</td><td class=blW>Fochlerová Iva</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Junek Jiří</td><td class=bc>14 : 5</tr></td>
<tr><td class=br>Šrámek Jakub</td><td class=bc>-</td><td class=blW>Fochlerová Iva</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Obadič Jakob Zalokar</td><td class=bc>-</td><td class=bl>Paclik Jakub</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Junek Jiří</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=bl>Fochlerová Iva</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Paclik Jakub</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Šrámek Jakub</td><td class=bc>-</td><td class=blW>Obadič Jakob Zalokar</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Junek Jiří</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=bl>Fochlerová Iva</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Paclik Jakub</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=blW>Obadič Jakob Zalokar</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Šrámek Jakub</td><td class=bc>9 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=bl>Fochlerová Iva</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Paclik Jakub</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Obadič Jakob Zalokar</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Šrámek Jakub</td><td class=bc>11 : 0</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Junek Jiří</td><td class=bc>-</td><td class=bl>Paclik Jakub</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Obadič Jakob Zalokar</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Šrámek Jakub</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Fochlerová Iva</td><td class=bc>-</td><td class=blW>Obadič Jakob Zalokar</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Junek Jiří</td><td class=bc>-</td><td class=bl>Šrámek Jakub</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Kahoun ml. Tomáš</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Paclik Jakub</td><td class=bc>-</td><td class=bl>Šrámek Jakub</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Fochlerová Iva</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Junek Jiří</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Obadič Jakob Zalokar</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Paclik Jakub</td><td class=bc>-</td><td class=blW>Kahoun ml. Tomáš</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Fochlerová Iva</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Junek Jiří</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Šrámek Jakub</td><td class=bc>-</td><td class=blW>Kahoun ml. Tomáš</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Obadič Jakob Zalokar</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Paclik Jakub</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Fochlerová Iva</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Junek Jiří</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 5</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Kr Herold</td><td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>9:1</td>
<td class=br>52:13</td><td class=br>+39</td>
<td class=bc>10 - 0 - 1</td>
<td class=br><strong>20</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ji Chylík ml.</td><td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>7:0</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>10:0</td>
<td class=kW>9:0</td>
<td class=kW>9:0</td>
<td class=br>59:6</td><td class=br>+53</td>
<td class=bc>10 - 0 - 1</td>
<td class=br><strong>20</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ne Škrlep</td><td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>8:1</td>
<td class=kW>8:2</td>
<td class=kW>9:7</td>
<td class=kW>7:0</td>
<td class=br>54:24</td><td class=br>+30</td>
<td class=bc>9 - 0 - 2</td>
<td class=br><strong>18</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ma Ležík</td><td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>8:1</td>
<td class=kW>11:1</td>
<td class=kW>7:0</td>
<td class=kW>9:1</td>
<td class=br>58:13</td><td class=br>+45</td>
<td class=bc>8 - 0 - 3</td>
<td class=br><strong>16</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Zd Lopaur</td><td class=kL>2:6</td>
<td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kW>9:1</td>
<td class=kW>9:1</td>
<td class=br>44:31</td><td class=br>+13</td>
<td class=bc>6 - 1 - 4</td>
<td class=br><strong>13</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Al Pala</td><td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>8:2</td>
<td class=kW>7:1</td>
<td class=kW>7:1</td>
<td class=br>37:23</td><td class=br>+14</td>
<td class=bc>5 - 1 - 5</td>
<td class=br><strong>11</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ro Jež</td><td class=kL>1:3</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>7:0</td>
<td class=kW>3:0</td>
<td class=kW>6:3</td>
<td class=kW>8:6</td>
<td class=kW>10:0</td>
<td class=br>37:36</td><td class=br>+1</td>
<td class=bc>5 - 1 - 5</td>
<td class=br><strong>11</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Hy Nechutný</td><td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>2:7</td>
<td class=kL>0:2</td>
<td class=kL>0:7</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=br>19:35</td><td class=br>-16</td>
<td class=bc>4 - 1 - 6</td>
<td class=br><strong>9</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>On Chlebo</td><td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>1:8</td>
<td class=kL>1:8</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=br>22:43</td><td class=br>-21</td>
<td class=bc>3 - 1 - 7</td>
<td class=br><strong>7</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ma Moravec</td><td class=kL>0:5</td>
<td class=kL>0:10</td>
<td class=kL>2:8</td>
<td class=kL>1:11</td>
<td class=kL>0:3</td>
<td class=kL>2:8</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=br>19:60</td><td class=br>-41</td>
<td class=bc>2 - 1 - 8</td>
<td class=br><strong>5</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>Va Linek</td><td class=kL>0:5</td>
<td class=kL>0:9</td>
<td class=kL>7:9</td>
<td class=kL>0:7</td>
<td class=kL>1:9</td>
<td class=kL>1:7</td>
<td class=kL>6:8</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=br>20:67</td><td class=br>-47</td>
<td class=bc>1 - 0 - 10</td>
<td class=br><strong>2</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Fi Šrámek</td><td class=kL>1:9</td>
<td class=kL>0:9</td>
<td class=kL>0:7</td>
<td class=kL>1:9</td>
<td class=kL>1:9</td>
<td class=kL>1:7</td>
<td class=kL>0:10</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=br>8:78</td><td class=br>-70</td>
<td class=bc>0 - 0 - 11</td>
<td class=br><strong>0</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Šrámek Filip</td><td class=bc>-</td><td class=blW>Chlebo Ondřej</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Linek Vaclav</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Škrlep Nejc</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Pala Aleš</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Chlebo Ondřej</td><td class=bc>-</td><td class=bl>Linek Vaclav</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Šrámek Filip</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ležík Matěj</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Škrlep Nejc</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pala Aleš</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Linek Vaclav</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Šrámek Filip</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Škrlep Nejc</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Pala Aleš</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Linek Vaclav</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Šrámek Filip</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Škrlep Nejc</td><td class=bc>-</td><td class=bl>Pala Aleš</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Linek Vaclav</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Šrámek Filip</td><td class=bc>-</td><td class=blW>Pala Aleš</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ležík Matěj</td><td class=bc>-</td><td class=blW>Škrlep Nejc</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Linek Vaclav</td><td class=bc>-</td><td class=blW>Pala Aleš</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=blW>Škrlep Nejc</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Šrámek Filip</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>1 : 9</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Pala Aleš</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Škrlep Nejc</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>1 : 11</tr></td>
<tr><td class=brW>Linek Vaclav</td><td class=bc>-</td><td class=bl>Šrámek Filip</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Pala Aleš</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Škrlep Nejc</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Šrámek Filip</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Chlebo Ondřej</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Linek Vaclav</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Škrlep Nejc</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Ležík Matěj</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Šrámek Filip</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Linek Vaclav</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Pala Aleš</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Šrámek Filip</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Linek Vaclav</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Škrlep Nejc</td><td class=bc>-</td><td class=bl>Šrámek Filip</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Pala Aleš</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Linek Vaclav</td><td class=bc>8 : 6</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Škrlep Nejc</td><td class=bc>-</td><td class=bl>Linek Vaclav</td><td class=bc>9 : 7</tr></td>
<tr><td class=brW>Pala Aleš</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 6</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Kr Lebl</td><td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>8:2</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=br>57:12</td><td class=br>+45</td>
<td class=bc>10 - 1 - 0</td>
<td class=br><strong>21</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Da Matýsek</td><td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>37:10</td><td class=br>+27</td>
<td class=bc>8 - 2 - 1</td>
<td class=br><strong>18</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>An Božič</td><td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>6:4</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kW>6:0</td>
<td class=kW>8:2</td>
<td class=kW>4:2</td>
<td class=kW>8:0</td>
<td class=br>47:23</td><td class=br>+24</td>
<td class=bc>7 - 3 - 1</td>
<td class=br><strong>17</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>On Gruncl</td><td class=kL>1:7</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kL>0:4</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=br>36:25</td><td class=br>+11</td>
<td class=bc>7 - 1 - 3</td>
<td class=br><strong>15</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>To Lahučký</td><td class=kL>4:5</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>12:3</td>
<td class=kT>3:3</td>
<td class=kW>7:0</td>
<td class=kW>14:0</td>
<td class=br>55:22</td><td class=br>+33</td>
<td class=bc>6 - 3 - 2</td>
<td class=br><strong>15</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ma Ženíšek</td><td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>4:6</td>
<td class=kL>3:6</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kW>6:1</td>
<td class=br>38:34</td><td class=br>+4</td>
<td class=bc>6 - 0 - 5</td>
<td class=br><strong>12</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Vo Kraus</td><td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=kW>11:0</td>
<td class=br>39:24</td><td class=br>+15</td>
<td class=bc>5 - 1 - 5</td>
<td class=br><strong>11</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Mi Mašika</td><td class=kL>0:6</td>
<td class=kL>2:6</td>
<td class=kL>3:6</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>13:0</td>
<td class=br>31:32</td><td class=br>-1</td>
<td class=bc>4 - 1 - 6</td>
<td class=br><strong>9</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Da Kadlec</td><td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>3:12</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=br>17:49</td><td class=br>-32</td>
<td class=bc>3 - 0 - 8</td>
<td class=br><strong>6</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ol Tabara</td><td class=kL>2:8</td>
<td class=kL>0:4</td>
<td class=kL>2:8</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>7:0</td>
<td class=kW>3:1</td>
<td class=br>27:40</td><td class=br>-13</td>
<td class=bc>2 - 2 - 7</td>
<td class=br><strong>6</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>Ji Pošík</td><td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>0:7</td>
<td class=kL>4:5</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kL>0:7</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=br>13:55</td><td class=br>-42</td>
<td class=bc>0 - 1 - 10</td>
<td class=br><strong>1</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Zd Slovák</td><td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kL>1:7</td>
<td class=kL>0:14</td>
<td class=kL>1:6</td>
<td class=kL>0:11</td>
<td class=kL>0:13</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=br>6:77</td><td class=br>-71</td>
<td class=bc>0 - 1 - 10</td>
<td class=br><strong>1</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Slovák Zdeněk</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Mašika Michal</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Tabara Oliver</td><td class=bc>-</td><td class=blW>Božič Anže</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Lahučký Tomáš</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Slovák Zdeněk</td><td class=bc>-</td><td class=blW>Kadlec Daniel</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Božič Anže</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Tabara Oliver</td><td class=bc>-</td><td class=bl>Lahučký Tomáš</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Slovák Zdeněk</td><td class=bc>-</td><td class=blW>Božič Anže</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=bl>Lahučký Tomáš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Tabara Oliver</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Božič Anže</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Slovák Zdeněk</td><td class=bc>-</td><td class=blW>Lahučký Tomáš</td><td class=bc>0 : 14</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mašika Michal</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Tabara Oliver</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Božič Anže</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Lahučký Tomáš</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Slovák Zdeněk</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Tabara Oliver</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Lahučký Tomáš</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kadlec Daniel</td><td class=bc>-</td><td class=bl>Tabara Oliver</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Slovák Zdeněk</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Tabara Oliver</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Slovák Zdeněk</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Tabara Oliver</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Božič Anže</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Slovák Zdeněk</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Slovák Zdeněk</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Tabara Oliver</td><td class=bc>-</td><td class=blW>Mašika Michal</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Slovák Zdeněk</td><td class=bc>11 : 0</tr></td>
<tr><td class=brW>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>12 : 3</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Božič Anže</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Tabara Oliver</td><td class=bc>-</td><td class=bl>Slovák Zdeněk</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Kadlec Daniel</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Božič Anže</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Mašika Michal</td><td class=bc>-</td><td class=bl>Slovák Zdeněk</td><td class=bc>13 : 0</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Tabara Oliver</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Božič Anže</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<hr><a name="final"><p class=vm>Výkonnostní skupiny (Final groups)</p></a>
<p class=v>Group A1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt>Ra Kalninš</td><td class=kx>*</td>
<td class=kW>8:6</td>
<td class=kW>4:2</td>
<td class=kW>6:4</td>
<td class=kW>8:2</td>
<td class=kW>4:3 K</td>
<td class=kW>9:4</td>
<td class=kW>10:0</td>
<td class=kW>6:0</td>
<td class=kW>4:1 K</td>
<td class=kW>6:1</td>
<td class=kW>8:2</td>
<td class=kW>5:1 K</td>
<td class=kW>7:0 K</td>
<td class=kW>5:2</td>
<td class=kW>10:0 K</td>
<td class=kW>8:0 K</td>
<td class=kL>3:4</td>
<td class=kT>2:2 K</td>
<td class=kW>8:3</td>
<td class=kW>11:2</td>
<td class=kL>0:5 K</td>
<td class=kW>17:3</td>
<td class=kW>6:2</td>
<td class=br>155:49</td><td class=br>+106</td>
<td class=bc>20 - 1 - 2</td>
<td class=br><strong>41</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt>Pa Petr</td><td class=kL>6:8</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kL>3:5 K</td>
<td class=kW>5:0 K</td>
<td class=kW>6:2</td>
<td class=kW>7:1 K</td>
<td class=kW>6:3 K</td>
<td class=kW>5:1</td>
<td class=kW>8:1</td>
<td class=kW>5:4</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>9:0</td>
<td class=kW>7:0 K</td>
<td class=kW>13:0</td>
<td class=kW>5:0</td>
<td class=kW>13:3 K</td>
<td class=kW>6:2 K</td>
<td class=br>143:41</td><td class=br>+102</td>
<td class=bc>20 - 0 - 3</td>
<td class=br><strong>40</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt>Ji Chylík ml.</td><td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>1:4 K</td>
<td class=kW>3:0 K</td>
<td class=kW>2:0</td>
<td class=kW>2:1 K</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>7:0 K</td>
<td class=kW>8:1</td>
<td class=kL>2:3</td>
<td class=kW>7:0 K</td>
<td class=kW>8:1</td>
<td class=kW>5:1</td>
<td class=kW>3:1 K</td>
<td class=kW>3:0 K</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=br>89:30</td><td class=br>+59</td>
<td class=bc>18 - 1 - 4</td>
<td class=br><strong>37</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt>Kr Herold</td><td class=kL>4:6</td>
<td class=kL>1:6</td>
<td class=kW>4:1 K</td>
<td class=kx>*</td>
<td class=kW>5:1 K</td>
<td class=kL>1:2</td>
<td class=kW>3:2 K</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>3:1 K</td>
<td class=kW>6:2</td>
<td class=kT>4:4</td>
<td class=kW>6:2 K</td>
<td class=kW>6:2</td>
<td class=kW>2:0</td>
<td class=kW>4:2 K</td>
<td class=kL>2:3 K</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=br>77:39</td><td class=br>+38</td>
<td class=bc>16 - 3 - 4</td>
<td class=br><strong>35</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>Ne Škrlep</td><td class=kL>2:8</td>
<td class=kL>1:6</td>
<td class=kL>0:3 K</td>
<td class=kL>1:5 K</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>2:1 K</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>5:0 K</td>
<td class=kW>5:4</td>
<td class=kW>5:2</td>
<td class=kW>6:1 K</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>3:2 K</td>
<td class=kW>5:2 K</td>
<td class=kW>7:2</td>
<td class=kW>9:3</td>
<td class=br>89:62</td><td class=br>+27</td>
<td class=bc>17 - 1 - 5</td>
<td class=br><strong>35</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>Ku Sládek</td><td class=kL>3:4 K</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kT>3:3 K</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>4:1 K</td>
<td class=kT>1:1 K</td>
<td class=kT>4:4</td>
<td class=kL>1:2 K</td>
<td class=kW>3:1 K</td>
<td class=kW>5:1</td>
<td class=kW>8:0 K</td>
<td class=kW>7:2</td>
<td class=kW>10:0</td>
<td class=kW>7:0</td>
<td class=kW>8:0</td>
<td class=kW>7:4</td>
<td class=br>96:43</td><td class=br>+53</td>
<td class=bc>15 - 4 - 4</td>
<td class=br><strong>34</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Ma Ležík</td><td class=kL>4:9</td>
<td class=kL>1:6</td>
<td class=kL>1:2 K</td>
<td class=kL>2:3 K</td>
<td class=kL>1:2 K</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>7:2</td>
<td class=kW>6:2</td>
<td class=kW>6:1 K</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>5:0 K</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>2:1 K</td>
<td class=kW>6:1 K</td>
<td class=kW>8:2</td>
<td class=kW>9:0</td>
<td class=br>98:47</td><td class=br>+51</td>
<td class=bc>16 - 1 - 6</td>
<td class=br><strong>33</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>Va Dietze</td><td class=kL>0:10</td>
<td class=kW>5:3 K</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>4:1 K</td>
<td class=kL>0:4</td>
<td class=kW>4:2 K</td>
<td class=kT>3:3 K</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kL>3:5</td>
<td class=kW>5:2 K</td>
<td class=kW>9:2</td>
<td class=kW>5:0</td>
<td class=kW>5:2 K</td>
<td class=kW>4:2 K</td>
<td class=br>89:61</td><td class=br>+28</td>
<td class=bc>13 - 5 - 5</td>
<td class=br><strong>31</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>Mi Černoch</td><td class=kL>0:6</td>
<td class=kL>0:5 K</td>
<td class=kW>5:1</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>1:4 K</td>
<td class=kx>*</td>
<td class=kL>0:6</td>
<td class=kL>0:1 K</td>
<td class=kW>3:0 K</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=kW>2:0 K</td>
<td class=kW>5:1</td>
<td class=kW>8:2</td>
<td class=kW>4:2 K</td>
<td class=kW>5:2 K</td>
<td class=br>54:53</td><td class=br>+1</td>
<td class=bc>11 - 3 - 9</td>
<td class=br><strong>25</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>To Růžička</td><td class=kL>1:4 K</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kT>3:3 K</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>5:2 K</td>
<td class=kW>2:1 K</td>
<td class=kW>3:0</td>
<td class=kL>2:3 K</td>
<td class=kT>3:3 K</td>
<td class=kT>2:2</td>
<td class=kL>2:3 K</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kW>8:1</td>
<td class=kT>3:3</td>
<td class=br>67:52</td><td class=br>+15</td>
<td class=bc>9 - 6 - 8</td>
<td class=br><strong>24</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>Ma Klazar</td><td class=kL>1:6</td>
<td class=kL>1:7 K</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>2:4 K</td>
<td class=kW>1:0 K</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:1 K</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kL>2:3 K</td>
<td class=kW>8:1</td>
<td class=kW>2:0</td>
<td class=kW>4:2 K</td>
<td class=kW>8:4 K</td>
<td class=br>66:55</td><td class=br>+11</td>
<td class=bc>11 - 2 - 10</td>
<td class=br><strong>24</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>An Šurýn</td><td class=kL>2:8</td>
<td class=kL>3:6 K</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kT>3:3 K</td>
<td class=kL>0:3 K</td>
<td class=kW>2:1</td>
<td class=kL>1:5 K</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kT>1:1 K</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>7:2 K</td>
<td class=kW>3:2 K</td>
<td class=br>51:67</td><td class=br>-16</td>
<td class=bc>10 - 3 - 10</td>
<td class=br><strong>23</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt>Pa Plešák</td><td class=kL>1:5 K</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>1:4 K</td>
<td class=kL>2:7</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kL>2:5 K</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=kL>2:5</td>
<td class=kW>6:4 K</td>
<td class=kW>2:1 K</td>
<td class=kW>4:2</td>
<td class=kW>5:0 K</td>
<td class=kW>4:2</td>
<td class=kW>11:0</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=br>68:74</td><td class=br>-6</td>
<td class=bc>10 - 3 - 10</td>
<td class=br><strong>23</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt>Al Krejza</td><td class=kL>0:7 K</td>
<td class=kL>1:8</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kT>1:1 K</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2 K</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:2 K</td>
<td class=kW>2:1 K</td>
<td class=kL>2:3</td>
<td class=kW>3:2 K</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=br>43:62</td><td class=br>-19</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt>Ro Jež</td><td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kL>0:7 K</td>
<td class=kL>1:3 K</td>
<td class=kL>0:5 K</td>
<td class=kT>4:4</td>
<td class=kL>1:6 K</td>
<td class=kL>0:7</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kT>1:1 K</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kL>0:5 K</td>
<td class=kW>7:0 K</td>
<td class=kW>5:3</td>
<td class=kW>6:3</td>
<td class=br>50:75</td><td class=br>-25</td>
<td class=bc>8 - 2 - 13</td>
<td class=br><strong>18</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt>Da Dvořáček</td><td class=kL>0:10 K</td>
<td class=kL>0:6</td>
<td class=kL>1:8</td>
<td class=kL>2:6</td>
<td class=kL>4:5</td>
<td class=kW>2:1 K</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kW>3:2 K</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>4:6 K</td>
<td class=kL>2:5 K</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>4:3 K</td>
<td class=kT>4:4</td>
<td class=kL>3:6 K</td>
<td class=kW>2:1</td>
<td class=kT>5:5</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=br>55:93</td><td class=br>-38</td>
<td class=bc>6 - 5 - 12</td>
<td class=br><strong>17</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Do Zupančič</td><td class=kL>0:8 K</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3 K</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kT>3:3 K</td>
<td class=kL>0:4</td>
<td class=kW>3:0</td>
<td class=kL>1:2 K</td>
<td class=kL>1:2 K</td>
<td class=kL>2:4</td>
<td class=kL>3:4 K</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kT>2:2 K</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=br>44:72</td><td class=br>-28</td>
<td class=bc>5 - 6 - 12</td>
<td class=br><strong>16</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Zd Lopaur</td><td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kL>0:7 K</td>
<td class=kL>2:6 K</td>
<td class=kL>1:6 K</td>
<td class=kL>1:5</td>
<td class=kL>0:5 K</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kT>1:1 K</td>
<td class=kT>4:4</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kW>6:1 K</td>
<td class=kW>7:2 K</td>
<td class=kW>9:3</td>
<td class=kT>3:3</td>
<td class=br>53:81</td><td class=br>-28</td>
<td class=bc>6 - 4 - 13</td>
<td class=br><strong>16</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Os Tabara</td><td class=kT>2:2 K</td>
<td class=kL>0:9</td>
<td class=kL>1:8</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kL>0:8 K</td>
<td class=kL>1:6</td>
<td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2 K</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>0:5 K</td>
<td class=kL>2:3 K</td>
<td class=kL>0:2</td>
<td class=kW>6:3 K</td>
<td class=kT>2:2 K</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>1:6</td>
<td class=br>43:86</td><td class=br>-43</td>
<td class=bc>6 - 3 - 14</td>
<td class=br><strong>15</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Ra Pommerenke</td><td class=kL>3:8</td>
<td class=kL>0:7 K</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>3:5</td>
<td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kL>2:5 K</td>
<td class=kL>0:2 K</td>
<td class=kT>2:2</td>
<td class=kW>3:2 K</td>
<td class=kT>1:1 K</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>0:5</td>
<td class=kT>3:3 K</td>
<td class=kW>5:2 K</td>
<td class=br>45:81</td><td class=br>-36</td>
<td class=bc>4 - 4 - 15</td>
<td class=br><strong>12</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Al Pala</td><td class=kL>2:11</td>
<td class=kL>0:13</td>
<td class=kL>1:3 K</td>
<td class=kL>2:4 K</td>
<td class=kL>2:3 K</td>
<td class=kL>0:10</td>
<td class=kL>1:2 K</td>
<td class=kL>2:9</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:8</td>
<td class=kL>1:2</td>
<td class=kL>0:11</td>
<td class=kL>2:4</td>
<td class=kW>5:0 K</td>
<td class=kT>5:5</td>
<td class=kW>3:1</td>
<td class=kL>1:6 K</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>2:0 K</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=br>44:111</td><td class=br>-67</td>
<td class=bc>5 - 1 - 17</td>
<td class=br><strong>11</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Hy Nechutný</td><td class=kW>5:0 K</td>
<td class=kL>0:5</td>
<td class=kL>0:3 K</td>
<td class=kW>3:2 K</td>
<td class=kL>2:5 K</td>
<td class=kL>0:7</td>
<td class=kL>1:6 K</td>
<td class=kL>0:5</td>
<td class=kL>2:8</td>
<td class=kL>3:5</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kL>0:7 K</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>2:7 K</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kL>0:2 K</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=br>39:82</td><td class=br>-43</td>
<td class=bc>5 - 1 - 17</td>
<td class=br><strong>11</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Ví Pernica</td><td class=kL>3:17</td>
<td class=kL>3:13 K</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kL>0:8</td>
<td class=kL>2:8</td>
<td class=kL>2:5 K</td>
<td class=kL>2:4 K</td>
<td class=kL>1:8</td>
<td class=kL>2:4 K</td>
<td class=kL>2:7 K</td>
<td class=kL>2:6</td>
<td class=kL>0:1</td>
<td class=kL>3:5</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>3:9</td>
<td class=kL>2:4</td>
<td class=kT>3:3 K</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1 K</td>
<td class=br>45:129</td><td class=br>-84</td>
<td class=bc>2 - 2 - 19</td>
<td class=br><strong>6</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Fr Rasche</td><td class=kL>2:6</td>
<td class=kL>2:6 K</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>3:9</td>
<td class=kL>4:7</td>
<td class=kL>0:9</td>
<td class=kL>2:4 K</td>
<td class=kL>2:5 K</td>
<td class=kT>3:3</td>
<td class=kL>4:8 K</td>
<td class=kL>2:3 K</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kL>2:5 K</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>1:2 K</td>
<td class=kx>*</td>
<td class=br>52:110</td><td class=br>-58</td>
<td class=bc>1 - 2 - 20</td>
<td class=br><strong>4</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Kalninš Rainers</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Pala Aleš</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Dietze Valentin</td><td class=bc>-</td><td class=bl>Ležík Matěj</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Škrlep Nejc</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Tabara Oskar</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Zupančič Domen</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Zupančič Domen</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Pala Aleš</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Dietze Valentin</td><td class=bc>-</td><td class=blW>Škrlep Nejc</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Petr Patrik</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=blW>Rasche Frank</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Zupančič Domen</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Pala Aleš</td><td class=bc>11 : 2</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Dietze Valentin</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Škrlep Nejc</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Kalninš Rainers</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Pala Aleš</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=bl>Dietze Valentin</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ležík Matěj</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Škrlep Nejc</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Tabara Oskar</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=bl>Zupančič Domen</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Škrlep Nejc</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Kalninš Rainers</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Pala Aleš</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Dietze Valentin</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=bl>Zupančič Domen</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Škrlep Nejc</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Zupančič Domen</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Kalninš Rainers</td><td class=bc>3 : 17</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Pala Aleš</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 13</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Dietze Valentin</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Škrlep Nejc</td><td class=bc>-</td><td class=bl>Zupančič Domen</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=blW>Kalninš Rainers</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pala Aleš</td><td class=bc>-</td><td class=blW>Dietze Valentin</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=blW>Zupančič Domen</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Škrlep Nejc</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Kalninš Rainers</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Dietze Valentin</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pala Aleš</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Dietze Valentin</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Kalninš Rainers</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Dvořáček David</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Jež Robert</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Tabara Oskar</td><td class=bc>-</td><td class=bl>Pala Aleš</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Zupančič Domen</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Škrlep Nejc</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Škrlep Nejc</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Dietze Valentin</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Kalninš Rainers</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Pala Aleš</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=blW>Lopaur Zdeněk</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Zupančič Domen</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Škrlep Nejc</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>9 : 3</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Dietze Valentin</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Petr Patrik</td><td class=bc>-</td><td class=blW>Kalninš Rainers</td><td class=bc>6 : 8</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=bl>Pala Aleš</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Zupančič Domen</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Zupančič Domen</td><td class=bc>-</td><td class=blW>Pala Aleš</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Škrlep Nejc</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ležík Matěj</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Dietze Valentin</td><td class=bc>-</td><td class=blW>Kalninš Rainers</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pala Aleš</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Ležík Matěj</td><td class=bc>9 : 4</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Škrlep Nejc</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Dietze Valentin</td><td class=bc>-</td><td class=bl>Zupančič Domen</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Zupančič Domen</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Lopaur Zdeněk</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>9 : 3</tr></td>
<tr><td class=br>Pala Aleš</td><td class=bc>-</td><td class=blW>Pommerenke Ralph</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Jež Robert</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Škrlep Nejc</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Dietze Valentin</td><td class=bc>-</td><td class=blW>Tabara Oskar</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Pommerenke Ralph</td><td class=bc>-</td><td class=bl>Lopaur Zdeněk</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Pala Aleš</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Jež Robert</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=blW>Kalninš Rainers</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ležík Matěj</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Škrlep Nejc</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Dietze Valentin</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Dvořáček David</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Zupančič Domen</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Lopaur Zdeněk</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Pala Aleš</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Jež Robert</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kalninš Rainers</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Ležík Matěj</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Škrlep Nejc</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Dietze Valentin</td><td class=bc>-</td><td class=bl>Dvořáček David</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Zupančič Domen</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>3 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group A2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt>Ra Miglinieks</td><td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>4:3 K</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kW>10:2 K</td>
<td class=kW>7:1</td>
<td class=kW>4:3 K</td>
<td class=kW>4:0</td>
<td class=kW>5:1 K</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>7:4</td>
<td class=kW>4:3</td>
<td class=kW>8:2</td>
<td class=kW>4:1 K</td>
<td class=kW>8:1</td>
<td class=kW>6:5 K</td>
<td class=kW>4:0</td>
<td class=kW>7:5 K</td>
<td class=kW>4:3</td>
<td class=kW>7:3</td>
<td class=kW>7:4</td>
<td class=br>122:53</td><td class=br>+69</td>
<td class=bc>22 - 0 - 1</td>
<td class=br><strong>44</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt>Mi Kobrle</td><td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>5:5</td>
<td class=kT>4:4</td>
<td class=kL>0:5 K</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>5:1 K</td>
<td class=kW>4:1</td>
<td class=kW>6:1 K</td>
<td class=kW>7:3</td>
<td class=kW>8:2</td>
<td class=kW>8:1</td>
<td class=kW>8:1</td>
<td class=kW>7:2</td>
<td class=kW>5:1 K</td>
<td class=kW>6:3</td>
<td class=kW>8:1 K</td>
<td class=kW>7:0</td>
<td class=kW>5:3 K</td>
<td class=kW>5:0</td>
<td class=kW>7:2 K</td>
<td class=br>126:45</td><td class=br>+81</td>
<td class=bc>18 - 3 - 2</td>
<td class=br><strong>39</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt>Kr Lebl</td><td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>6:1 K</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kT>0:0 K</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kW>5:4 K</td>
<td class=kW>4:2 K</td>
<td class=kW>4:1 K</td>
<td class=kW>7:1 K</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>9:4</td>
<td class=kW>3:0</td>
<td class=kW>6:0 K</td>
<td class=kW>5:1</td>
<td class=br>87:40</td><td class=br>+47</td>
<td class=bc>16 - 4 - 3</td>
<td class=br><strong>36</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt>Mi Hvižď</td><td class=kL>3:4 K</td>
<td class=kT>5:5</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>5:2 K</td>
<td class=kT>1:1</td>
<td class=kW>2:0 K</td>
<td class=kL>2:3</td>
<td class=kW>4:2 K</td>
<td class=kT>1:1</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kW>7:2 K</td>
<td class=kW>9:1</td>
<td class=kW>10:3 K</td>
<td class=kW>9:0</td>
<td class=kW>9:2 K</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>9:0</td>
<td class=br>109:47</td><td class=br>+62</td>
<td class=bc>16 - 3 - 4</td>
<td class=br><strong>35</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>An Božič</td><td class=kL>3:5</td>
<td class=kT>4:4</td>
<td class=kL>1:6 K</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>8:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2 K</td>
<td class=kW>3:0</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kT>1:1 K</td>
<td class=kW>6:4 K</td>
<td class=kW>3:1 K</td>
<td class=kT>2:2 K</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kW>8:1</td>
<td class=kW>3:2</td>
<td class=kW>6:3 K</td>
<td class=kW>5:3</td>
<td class=br>84:52</td><td class=br>+32</td>
<td class=bc>14 - 5 - 4</td>
<td class=br><strong>33</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>Vá Pikl</td><td class=kL>0:2</td>
<td class=kW>5:0 K</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kL>1:8</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kL>1:5 K</td>
<td class=kT>2:2</td>
<td class=kL>0:5 K</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2 K</td>
<td class=kW>7:1</td>
<td class=kW>2:1 K</td>
<td class=kW>3:2</td>
<td class=kW>4:0 K</td>
<td class=kW>5:4</td>
<td class=kT>5:5 K</td>
<td class=br>65:52</td><td class=br>+13</td>
<td class=bc>14 - 4 - 5</td>
<td class=br><strong>32</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Mi Boštík</td><td class=kL>2:10 K</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>2:5 K</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:1 K</td>
<td class=kL>1:4</td>
<td class=kL>1:3 K</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>5:3 K</td>
<td class=kW>6:4</td>
<td class=kW>7:3 K</td>
<td class=kW>4:2</td>
<td class=kW>5:1 K</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>8:2</td>
<td class=br>77:66</td><td class=br>+11</td>
<td class=bc>14 - 1 - 8</td>
<td class=br><strong>29</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>Da Matýsek</td><td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kT>0:0 K</td>
<td class=kT>1:1</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>1:2 K</td>
<td class=kW>4:1 K</td>
<td class=kW>4:2 K</td>
<td class=kW>3:0 K</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kW>7:1</td>
<td class=kL>0:2</td>
<td class=kW>7:0</td>
<td class=kW>4:2</td>
<td class=kW>6:2 K</td>
<td class=kW>6:2</td>
<td class=br>64:47</td><td class=br>+17</td>
<td class=bc>10 - 7 - 6</td>
<td class=br><strong>27</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>Ti Varga</td><td class=kL>3:4 K</td>
<td class=kL>0:6</td>
<td class=kT>3:3</td>
<td class=kL>0:2 K</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:4 K</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>2:2 K</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kW>5:1 K</td>
<td class=kW>5:0</td>
<td class=kW>5:2 K</td>
<td class=kW>3:1</td>
<td class=kW>5:2 K</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=br>63:57</td><td class=br>+6</td>
<td class=bc>10 - 6 - 7</td>
<td class=br><strong>26</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Ja Obadič</td><td class=kL>0:4</td>
<td class=kL>1:5 K</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>5:1 K</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>1:4 K</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>2:1 K</td>
<td class=kL>3:6</td>
<td class=kL>2:3 K</td>
<td class=kL>3:4</td>
<td class=kW>5:3 K</td>
<td class=kT>4:4</td>
<td class=kW>7:3 K</td>
<td class=br>68:62</td><td class=br>+6</td>
<td class=bc>10 - 5 - 8</td>
<td class=br><strong>25</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>To Bucek</td><td class=kL>1:5 K</td>
<td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=kL>2:4 K</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>3:1 K</td>
<td class=kT>4:4</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kT>1:1 K</td>
<td class=kW>2:0</td>
<td class=kW>9:2 K</td>
<td class=kW>6:2</td>
<td class=kW>9:0 K</td>
<td class=kL>2:5</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=br>64:47</td><td class=br>+17</td>
<td class=bc>9 - 6 - 8</td>
<td class=br><strong>24</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>My Shalomayev</td><td class=kL>3:5</td>
<td class=kL>1:6 K</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>5:0 K</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>4:1 K</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>1:2 K</td>
<td class=kW>4:1</td>
<td class=kL>2:3 K</td>
<td class=kW>7:2</td>
<td class=kW>3:1 K</td>
<td class=kW>5:1</td>
<td class=kW>4:1 K</td>
<td class=br>64:53</td><td class=br>+11</td>
<td class=bc>10 - 4 - 9</td>
<td class=br><strong>24</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt>To Lahučký</td><td class=kL>1:4</td>
<td class=kL>3:7</td>
<td class=kL>4:5 K</td>
<td class=kL>3:6</td>
<td class=kT>1:1 K</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kW>2:1 K</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>5:2 K</td>
<td class=kW>3:2 K</td>
<td class=kL>2:3 K</td>
<td class=kW>1:0</td>
<td class=kL>1:6</td>
<td class=kW>7:2</td>
<td class=kW>5:4</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kT>2:2 K</td>
<td class=kW>2:0</td>
<td class=br>58:59</td><td class=br>-1</td>
<td class=bc>10 - 3 - 10</td>
<td class=br><strong>23</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt>Ma Ženíšek</td><td class=kL>4:7</td>
<td class=kL>2:8</td>
<td class=kL>2:4 K</td>
<td class=kL>1:4</td>
<td class=kL>4:6 K</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>1:4 K</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>2:5 K</td>
<td class=kx>*</td>
<td class=kW>6:0 K</td>
<td class=kL>3:6 K</td>
<td class=kW>1:0</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kW>2:1 K</td>
<td class=kW>5:1</td>
<td class=br>69:71</td><td class=br>-2</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt>Vo Kraus</td><td class=kL>3:4</td>
<td class=kL>1:8</td>
<td class=kL>1:4 K</td>
<td class=kW>3:1</td>
<td class=kL>1:3 K</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>2:4 K</td>
<td class=kT>4:4</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kL>2:3 K</td>
<td class=kL>0:6 K</td>
<td class=kx>*</td>
<td class=kW>4:0 K</td>
<td class=kW>8:1</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kW>9:3</td>
<td class=kL>2:6</td>
<td class=kW>5:0 K</td>
<td class=kW>2:1</td>
<td class=br>66:71</td><td class=br>-5</td>
<td class=bc>9 - 2 - 12</td>
<td class=br><strong>20</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt>On Gruncl</td><td class=kL>2:8</td>
<td class=kL>1:8</td>
<td class=kL>1:7 K</td>
<td class=kL>3:5</td>
<td class=kT>2:2 K</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>0:3 K</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>3:2 K</td>
<td class=kW>6:3 K</td>
<td class=kL>0:4 K</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>3:6</td>
<td class=kW>7:5</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0 K</td>
<td class=kW>3:1</td>
<td class=br>62:84</td><td class=br>-22</td>
<td class=bc>9 - 2 - 12</td>
<td class=br><strong>20</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Vl Kraus</td><td class=kL>1:4 K</td>
<td class=kL>2:7</td>
<td class=kL>0:3</td>
<td class=kL>2:7 K</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>3:5 K</td>
<td class=kL>0:2</td>
<td class=kL>1:5 K</td>
<td class=kT>1:1</td>
<td class=kT>1:1 K</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kL>0:1</td>
<td class=kL>1:8</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>3:2 K</td>
<td class=kW>2:0</td>
<td class=kW>6:1 K</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=br>45:69</td><td class=br>-24</td>
<td class=bc>6 - 5 - 12</td>
<td class=br><strong>17</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>To Kahoun ml.</td><td class=kL>1:8</td>
<td class=kL>1:5 K</td>
<td class=kL>0:3</td>
<td class=kL>1:9</td>
<td class=kL>2:3</td>
<td class=kL>2:3 K</td>
<td class=kL>4:6</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>1:2 K</td>
<td class=kL>0:2</td>
<td class=kW>2:1 K</td>
<td class=kW>6:1</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kW>3:1 K</td>
<td class=kL>2:4</td>
<td class=kT>4:4 K</td>
<td class=kW>5:0</td>
<td class=kW>5:3 K</td>
<td class=br>55:87</td><td class=br>-32</td>
<td class=bc>6 - 2 - 15</td>
<td class=br><strong>14</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Mi Uhlíř</td><td class=kL>5:6 K</td>
<td class=kL>3:6</td>
<td class=kL>1:6</td>
<td class=kL>3:10 K</td>
<td class=kT>2:2</td>
<td class=kL>1:7</td>
<td class=kL>3:7 K</td>
<td class=kL>1:7</td>
<td class=kL>2:5 K</td>
<td class=kW>6:3</td>
<td class=kL>2:9 K</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kW>6:3</td>
<td class=kL>2:3 K</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>3:3 K</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=br>66:113</td><td class=br>-47</td>
<td class=bc>5 - 3 - 15</td>
<td class=br><strong>13</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Mi Moravec</td><td class=kL>0:4</td>
<td class=kL>1:8 K</td>
<td class=kL>1:2</td>
<td class=kL>0:9</td>
<td class=kL>0:6</td>
<td class=kL>1:2 K</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kW>3:2 K</td>
<td class=kL>2:6</td>
<td class=kW>3:2 K</td>
<td class=kL>4:5</td>
<td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=kL>5:7</td>
<td class=kL>0:2</td>
<td class=kL>1:3 K</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>3:3 K</td>
<td class=kL>2:4</td>
<td class=kT>2:2 K</td>
<td class=br>44:86</td><td class=br>-42</td>
<td class=bc>5 - 2 - 16</td>
<td class=br><strong>12</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Li Kondrashevskyi</td><td class=kL>5:7 K</td>
<td class=kL>0:7</td>
<td class=kL>4:9</td>
<td class=kL>2:9 K</td>
<td class=kL>1:8</td>
<td class=kL>2:3</td>
<td class=kL>1:5 K</td>
<td class=kL>0:7</td>
<td class=kL>2:5 K</td>
<td class=kW>4:3</td>
<td class=kL>0:9 K</td>
<td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>3:9</td>
<td class=kL>2:3</td>
<td class=kL>1:6 K</td>
<td class=kW>4:2</td>
<td class=kT>3:3 K</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=br>52:121</td><td class=br>-69</td>
<td class=bc>5 - 1 - 17</td>
<td class=br><strong>11</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Mi Ševr</td><td class=kL>3:4</td>
<td class=kL>3:5 K</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>0:4 K</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>3:5 K</td>
<td class=kW>5:2</td>
<td class=kL>1:3 K</td>
<td class=kL>2:7</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>4:4 K</td>
<td class=kW>3:1</td>
<td class=kT>3:3 K</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kL>3:6 K</td>
<td class=br>58:83</td><td class=br>-25</td>
<td class=bc>4 - 3 - 16</td>
<td class=br><strong>11</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Mi Mašika</td><td class=kL>3:7</td>
<td class=kL>0:5</td>
<td class=kL>0:6 K</td>
<td class=kL>1:4</td>
<td class=kL>3:6 K</td>
<td class=kL>4:5</td>
<td class=kL>0:3</td>
<td class=kL>2:6 K</td>
<td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kT>2:2 K</td>
<td class=kL>1:2 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:3 K</td>
<td class=kW>4:1</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=br>41:91</td><td class=br>-50</td>
<td class=bc>3 - 3 - 17</td>
<td class=br><strong>9</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Iv Fochlerová</td><td class=kL>4:7</td>
<td class=kL>2:7 K</td>
<td class=kL>1:5</td>
<td class=kL>0:9</td>
<td class=kL>3:5</td>
<td class=kT>5:5 K</td>
<td class=kL>2:8</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>3:7 K</td>
<td class=kT>1:1</td>
<td class=kL>1:4 K</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>3:5 K</td>
<td class=kL>3:5</td>
<td class=kT>2:2 K</td>
<td class=kL>2:4</td>
<td class=kW>6:3 K</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=br>49:102</td><td class=br>-53</td>
<td class=bc>1 - 5 - 17</td>
<td class=br><strong>7</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Hvižď Michal</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Lahučký Tomáš</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Božič Anže</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Obadič Jakob Zalokar</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Varga Tibor</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Fochlerová Iva</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Uhlíř Miroslav</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Lahučký Tomáš</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Božič Anže</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Obadič Jakob Zalokar</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Varga Tibor</td><td class=bc>-</td><td class=bl>Fochlerová Iva</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=blW>Kahoun ml. Tomáš</td><td class=bc>4 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=bl>Fochlerová Iva</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Lahučký Tomáš</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Obadič Jakob Zalokar</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Božič Anže</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Varga Tibor</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Boštík Michal</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Božič Anže</td><td class=bc>-</td><td class=blW>Obadič Jakob Zalokar</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=blW>Varga Tibor</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Fochlerová Iva</td><td class=bc>-</td><td class=blW>Uhlíř Miroslav</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Kondrashevskyi Liubomyr</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Uhlíř Miroslav</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Varga Tibor</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Fochlerová Iva</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Obadič Jakob Zalokar</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Kondrashevskyi Liubomyr</td><td class=bc>9 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Uhlíř Miroslav</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Varga Tibor</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Kondrashevskyi Liubomyr</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Fochlerová Iva</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Obadič Jakob Zalokar</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Varga Tibor</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Kondrashevskyi Liubomyr</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Uhlíř Miroslav</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Fochlerová Iva</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Shalomayev Mykhaylo</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=bl>Obadič Jakob Zalokar</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Obadič Jakob Zalokar</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Varga Tibor</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Kondrashevskyi Liubomyr</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Božič Anže</td><td class=bc>-</td><td class=bl>Uhlíř Miroslav</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Fochlerová Iva</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Boštík Michal</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Obadič Jakob Zalokar</td><td class=bc>-</td><td class=bl>Hvižď Michal</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Varga Tibor</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>1 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=blW>Lahučký Tomáš</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Fochlerová Iva</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Obadič Jakob Zalokar</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Boštík Michal</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Varga Tibor</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=blW>Lahučký Tomáš</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Fochlerová Iva</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Fochlerová Iva</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Hvižď Michal</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Obadič Jakob Zalokar</td><td class=bc>-</td><td class=bl>Boštík Michal</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Varga Tibor</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Lahučký Tomáš</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Uhlíř Miroslav</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>3 : 9</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Fochlerová Iva</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>7 : 5</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Boštík Michal</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Obadič Jakob Zalokar</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Hvižď Michal</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Varga Tibor</td><td class=bc>-</td><td class=bl>Lahučký Tomáš</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Mašika Michal</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Fochlerová Iva</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Kahoun ml. Tomáš</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Hvižď Michal</td><td class=bc>-</td><td class=blW>Božič Anže</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Boštík Michal</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Kondrashevskyi Liubomyr</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Uhlíř Miroslav</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Obadič Jakob Zalokar</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Varga Tibor</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Obadič Jakob Zalokar</td><td class=bc>-</td><td class=bl>Varga Tibor</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=bl>Kondrashevskyi Liubomyr</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Lahučký Tomáš</td><td class=bc>-</td><td class=bl>Fochlerová Iva</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Kahoun ml. Tomáš</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mašika Michal</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Božič Anže</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Hvižď Michal</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Uhlíř Miroslav</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Lahučký Tomáš</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Kahoun ml. Tomáš</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Fochlerová Iva</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Božič Anže</td><td class=bc>-</td><td class=bl>Boštík Michal</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Varga Tibor</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Kondrashevskyi Liubomyr</td><td class=bc>-</td><td class=bl>Obadič Jakob Zalokar</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=blW>Shalomayev Mykhaylo</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Shalomayev Mykhaylo</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Lahučký Tomáš</td><td class=bc>-</td><td class=blW>Kahoun ml. Tomáš</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Fochlerová Iva</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mašika Michal</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Miglinieks Raivis</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Božič Anže</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Boštík Michal</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Varga Tibor</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Kondrashevskyi Liubomyr</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Obadič Jakob Zalokar</td><td class=bc>-</td><td class=blW>Uhlíř Miroslav</td><td class=bc>3 : 6</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt>Ol Tabara</td><td class=kx>*</td>
<td class=kW>6:5</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=br>48:19</td><td class=br>+29</td>
<td class=bc>10 - 1 - 0</td>
<td class=br><strong>21</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt>Da Pavelka</td><td class=kL>5:6</td>
<td class=kx>*</td>
<td class=kW>8:1</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kT>5:5</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>7:1</td>
<td class=kW>6:3</td>
<td class=kW>7:0</td>
<td class=br>59:22</td><td class=br>+37</td>
<td class=bc>9 - 1 - 1</td>
<td class=br><strong>19</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt>Da Kadlec</td><td class=kL>3:4</td>
<td class=kL>1:8</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kL>3:4</td>
<td class=kW>8:4</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kL>4:5</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=br>48:34</td><td class=br>+14</td>
<td class=bc>7 - 0 - 4</td>
<td class=br><strong>14</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt>Ja Janouškovec</td><td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=br>37:25</td><td class=br>+12</td>
<td class=bc>6 - 0 - 5</td>
<td class=br><strong>12</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Mi Grepl</td><td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kL>3:7</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=br>22:34</td><td class=br>-12</td>
<td class=bc>5 - 1 - 5</td>
<td class=br><strong>11</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Ma Moravec</td><td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=br>25:24</td><td class=br>+1</td>
<td class=bc>5 - 1 - 5</td>
<td class=br><strong>11</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Ja Tomáštík</td><td class=kT>3:3</td>
<td class=kT>5:5</td>
<td class=kL>4:8</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=br>30:27</td><td class=br>+3</td>
<td class=bc>4 - 3 - 4</td>
<td class=br><strong>11</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ji Junek</td><td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=br>24:27</td><td class=br>-3</td>
<td class=bc>4 - 2 - 5</td>
<td class=br><strong>10</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Pe Klazar</td><td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kW>7:3</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=br>24:36</td><td class=br>-12</td>
<td class=bc>3 - 2 - 6</td>
<td class=br><strong>8</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Vě Stanzelová</td><td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kW>5:4</td>
<td class=kL>1:7</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=br>16:41</td><td class=br>-25</td>
<td class=bc>2 - 2 - 7</td>
<td class=br><strong>6</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>On Chlebo</td><td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kT>0:0</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=br>13:31</td><td class=br>-18</td>
<td class=bc>2 - 1 - 8</td>
<td class=br><strong>5</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Mi Zeman</td><td class=kL>2:4</td>
<td class=kL>0:7</td>
<td class=kL>2:6</td>
<td class=kL>1:7</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=br>14:40</td><td class=br>-26</td>
<td class=bc>1 - 2 - 8</td>
<td class=br><strong>4</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Tomáštík Jan</td><td class=bc>-</td><td class=bl>Tabara Oliver</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Klazar Petr</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pavelka David</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Stanzelová Věra</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=blW>Grepl Miroslav</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Zeman Milan</td><td class=bc>-</td><td class=bl>Junek Jiří</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Tabara Oliver</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Tomáštík Jan</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kadlec Daniel</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pavelka David</td><td class=bc>-</td><td class=bl>Grepl Miroslav</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Junek Jiří</td><td class=bc>-</td><td class=bl>Stanzelová Věra</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zeman Milan</td><td class=bc>-</td><td class=blW>Klazar Petr</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=bl>Junek Jiří</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Tomáštík Jan</td><td class=bc>-</td><td class=blW>Grepl Miroslav</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=bl>Stanzelová Věra</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Pavelka David</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Zeman Milan</td><td class=bc>-</td><td class=blW>Tabara Oliver</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Junek Jiří</td><td class=bc>-</td><td class=blW>Pavelka David</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Grepl Miroslav</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Tabara Oliver</td><td class=bc>-</td><td class=bl>Stanzelová Věra</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Tomáštík Jan</td><td class=bc>-</td><td class=blW>Kadlec Daniel</td><td class=bc>4 : 8</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Chlebo Ondřej</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Zeman Milan</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Pavelka David</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Stanzelová Věra</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Kadlec Daniel</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Tabara Oliver</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Tomáštík Jan</td><td class=bc>-</td><td class=bl>Junek Jiří</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Zeman Milan</td><td class=bc>-</td><td class=blW>Grepl Miroslav</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Grepl Miroslav</td><td class=bc>-</td><td class=bl>Stanzelová Věra</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Tomáštík Jan</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Junek Jiří</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Tabara Oliver</td><td class=bc>-</td><td class=bl>Pavelka David</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Zeman Milan</td><td class=bc>-</td><td class=blW>Kadlec Daniel</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Stanzelová Věra</td><td class=bc>-</td><td class=blW>Chlebo Ondřej</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Grepl Miroslav</td><td class=bc>-</td><td class=blW>Junek Jiří</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Tabara Oliver</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Tomáštík Jan</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zeman Milan</td><td class=bc>-</td><td class=blW>Pavelka David</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Kadlec Daniel</td><td class=bc>-</td><td class=bl>Junek Jiří</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Stanzelová Věra</td><td class=bc>-</td><td class=blW>Pavelka David</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Grepl Miroslav</td><td class=bc>-</td><td class=blW>Klazar Petr</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Tabara Oliver</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Zeman Milan</td><td class=bc>-</td><td class=blW>Tomáštík Jan</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=blW>Pavelka David</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Kadlec Daniel</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Stanzelová Věra</td><td class=bc>-</td><td class=blW>Tomáštík Jan</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Grepl Miroslav</td><td class=bc>-</td><td class=blW>Tabara Oliver</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Zeman Milan</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Junek Jiří</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=blW>Tomáštík Jan</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kadlec Daniel</td><td class=bc>-</td><td class=blW>Tabara Oliver</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Stanzelová Věra</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Grepl Miroslav</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zeman Milan</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Pavelka David</td><td class=bc>-</td><td class=bl>Tomáštík Jan</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Junek Jiří</td><td class=bc>-</td><td class=blW>Tabara Oliver</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Chlebo Ondřej</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kadlec Daniel</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Grepl Miroslav</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Zeman Milan</td><td class=bc>-</td><td class=blW>Stanzelová Věra</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Tabara Oliver</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Pavelka David</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Junek Jiří</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Stanzelová Věra</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kadlec Daniel</td><td class=bc>-</td><td class=bl>Grepl Miroslav</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Zeman Milan</td><td class=bc>-</td><td class=bl>Chlebo Ondřej</td><td class=bc>2 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt>To Šudřích</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>7:0</td>
<td class=kL>1:2</td>
<td class=kW>9:1</td>
<td class=br>46:20</td><td class=br>+26</td>
<td class=bc>8 - 1 - 2</td>
<td class=br><strong>17</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt>Zd Slovák</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>8:3</td>
<td class=kT>3:3</td>
<td class=kW>6:4</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>7:0</td>
<td class=kW>7:2</td>
<td class=br>45:22</td><td class=br>+23</td>
<td class=bc>6 - 5 - 0</td>
<td class=br><strong>17</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt>Vo Pošík</td><td class=kL>4:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>8:0</td>
<td class=kW>5:0</td>
<td class=br>40:18</td><td class=br>+22</td>
<td class=bc>7 - 2 - 2</td>
<td class=br><strong>16</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt>Ja Paclik</td><td class=kL>1:3</td>
<td class=kL>3:8</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=br>43:22</td><td class=br>+21</td>
<td class=bc>8 - 0 - 3</td>
<td class=br><strong>16</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ma Grepl</td><td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=br>37:18</td><td class=br>+19</td>
<td class=bc>7 - 1 - 3</td>
<td class=br><strong>15</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Jo Linek</td><td class=kW>6:2</td>
<td class=kL>4:6</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>8:1</td>
<td class=kW>6:3</td>
<td class=br>45:34</td><td class=br>+11</td>
<td class=bc>6 - 1 - 4</td>
<td class=br><strong>13</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Ji Pošík</td><td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=br>25:17</td><td class=br>+8</td>
<td class=bc>5 - 2 - 4</td>
<td class=br><strong>12</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ja Šrámek</td><td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=br>18:26</td><td class=br>-8</td>
<td class=bc>4 - 2 - 5</td>
<td class=br><strong>10</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Va Linek</td><td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=br>17:32</td><td class=br>-15</td>
<td class=bc>3 - 1 - 7</td>
<td class=br><strong>7</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Fi Šrámek</td><td class=kL>0:7</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=br>18:34</td><td class=br>-16</td>
<td class=bc>2 - 1 - 8</td>
<td class=br><strong>5</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Ja Janků</td><td class=kW>2:1</td>
<td class=kL>0:7</td>
<td class=kL>0:8</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:8</td>
<td class=kL>0:1</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>6:44</td><td class=br>-38</td>
<td class=bc>2 - 0 - 9</td>
<td class=br><strong>4</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ma Očenášek</td><td class=kL>1:9</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kL>3:6</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>9:62</td><td class=br>-53</td>
<td class=bc>0 - 0 - 11</td>
<td class=br><strong>0</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Šudřích Tomáš</td><td class=bc>-</td><td class=bl>Slovák Zdeněk</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Grepl Matej</td><td class=bc>-</td><td class=bl>Šrámek Filip</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Linek Jozef</td><td class=bc>-</td><td class=bl>Šrámek Jakub</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Paclik Jakub</td><td class=bc>-</td><td class=bl>Očenášek Matěj</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Linek Vaclav</td><td class=bc>-</td><td class=bl>Janků Jakub</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Slovák Zdeněk</td><td class=bc>-</td><td class=bl>Šrámek Filip</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Šudřích Tomáš</td><td class=bc>-</td><td class=bl>Šrámek Jakub</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Grepl Matej</td><td class=bc>-</td><td class=bl>Očenášek Matěj</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Linek Jozef</td><td class=bc>-</td><td class=bl>Janků Jakub</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Paclik Jakub</td><td class=bc>-</td><td class=blW>Pošík Vojtěch</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Linek Vaclav</td><td class=bc>-</td><td class=blW>Pošík Jiří</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Šrámek Filip</td><td class=bc>-</td><td class=blW>Šrámek Jakub</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Slovák Zdeněk</td><td class=bc>-</td><td class=bl>Očenášek Matěj</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Šudřích Tomáš</td><td class=bc>-</td><td class=blW>Janků Jakub</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Grepl Matej</td><td class=bc>-</td><td class=blW>Pošík Vojtěch</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Linek Jozef</td><td class=bc>-</td><td class=blW>Pošík Jiří</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Paclik Jakub</td><td class=bc>-</td><td class=bl>Linek Vaclav</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Šrámek Jakub</td><td class=bc>-</td><td class=bl>Očenášek Matěj</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Šrámek Filip</td><td class=bc>-</td><td class=bl>Janků Jakub</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Slovák Zdeněk</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Šudřích Tomáš</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Grepl Matej</td><td class=bc>-</td><td class=bl>Linek Vaclav</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Linek Jozef</td><td class=bc>-</td><td class=blW>Paclik Jakub</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Očenášek Matěj</td><td class=bc>-</td><td class=blW>Janků Jakub</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Šrámek Jakub</td><td class=bc>-</td><td class=blW>Pošík Vojtěch</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Šrámek Filip</td><td class=bc>-</td><td class=blW>Pošík Jiří</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Slovák Zdeněk</td><td class=bc>-</td><td class=bl>Linek Vaclav</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Šudřích Tomáš</td><td class=bc>-</td><td class=bl>Paclik Jakub</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Grepl Matej</td><td class=bc>-</td><td class=bl>Linek Jozef</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Janků Jakub</td><td class=bc>-</td><td class=blW>Pošík Vojtěch</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Očenášek Matěj</td><td class=bc>-</td><td class=blW>Pošík Jiří</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Šrámek Jakub</td><td class=bc>-</td><td class=bl>Linek Vaclav</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Šrámek Filip</td><td class=bc>-</td><td class=blW>Paclik Jakub</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Slovák Zdeněk</td><td class=bc>-</td><td class=bl>Linek Jozef</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Šudřích Tomáš</td><td class=bc>-</td><td class=bl>Grepl Matej</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Pošík Vojtěch</td><td class=bc>-</td><td class=bl>Linek Vaclav</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Janků Jakub</td><td class=bc>-</td><td class=blW>Paclik Jakub</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Očenášek Matěj</td><td class=bc>-</td><td class=blW>Linek Jozef</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Šrámek Jakub</td><td class=bc>-</td><td class=blW>Grepl Matej</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Šrámek Filip</td><td class=bc>-</td><td class=blW>Šudřích Tomáš</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Slovák Zdeněk</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Paclik Jakub</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=bl>Linek Jozef</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Janků Jakub</td><td class=bc>-</td><td class=blW>Grepl Matej</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Očenášek Matěj</td><td class=bc>-</td><td class=blW>Šudřích Tomáš</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Šrámek Jakub</td><td class=bc>-</td><td class=bl>Slovák Zdeněk</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Šrámek Filip</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Linek Vaclav</td><td class=bc>-</td><td class=blW>Linek Jozef</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Grepl Matej</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Šudřích Tomáš</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Janků Jakub</td><td class=bc>-</td><td class=blW>Slovák Zdeněk</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Očenášek Matěj</td><td class=bc>-</td><td class=blW>Šrámek Filip</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Šrámek Jakub</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Paclik Jakub</td><td class=bc>-</td><td class=bl>Grepl Matej</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Linek Vaclav</td><td class=bc>-</td><td class=blW>Šudřích Tomáš</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=bl>Slovák Zdeněk</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pošík Vojtěch</td><td class=bc>-</td><td class=bl>Šrámek Filip</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Janků Jakub</td><td class=bc>-</td><td class=blW>Šrámek Jakub</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Očenášek Matěj</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Linek Jozef</td><td class=bc>-</td><td class=bl>Šudřích Tomáš</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Paclik Jakub</td><td class=bc>-</td><td class=blW>Slovák Zdeněk</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Linek Vaclav</td><td class=bc>-</td><td class=bl>Šrámek Filip</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Šrámek Jakub</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Pošík Vojtěch</td><td class=bc>-</td><td class=bl>Očenášek Matěj</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Janků Jakub</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Grepl Matej</td><td class=bc>-</td><td class=bl>Slovák Zdeněk</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Linek Jozef</td><td class=bc>-</td><td class=bl>Šrámek Filip</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Paclik Jakub</td><td class=bc>-</td><td class=bl>Šrámek Jakub</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Linek Vaclav</td><td class=bc>-</td><td class=bl>Očenášek Matěj</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Pošík Jiří</td><td class=bc>-</td><td class=bl>Janků Jakub</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
