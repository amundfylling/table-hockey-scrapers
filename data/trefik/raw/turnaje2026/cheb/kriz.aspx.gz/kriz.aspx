<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Cheb</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/pohar13.aspx">U13</a>
&nbsp;<a href="../data/pohar55.aspx">55+</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Cheb, 22. listopad 2025</span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Základní skupiny (Basic groups)</a><br>
<a href="#final">Výkonnostní skupiny (Final groups)</a><br>
<a name="basic"><p class=vm>Základní skupiny (Basic groups)</p></a>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Mi Kobrle</td><td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>6:5</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kW>9:4</td>
<td class=kW>6:0</td>
<td class=kW>6:3</td>
<td class=kW>6:3</td>
<td class=kW>10:3</td>
<td class=kW>10:4</td>
<td class=kW>8:2</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kW>9:0</td>
<td class=br>104:37</td><td class=br>+67</td>
<td class=bc>15 - 1 - 0</td>
<td class=br><strong>31</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>To Bucek</td><td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kL>0:4</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=br>49:30</td><td class=br>+19</td>
<td class=bc>11 - 3 - 2</td>
<td class=br><strong>25</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ma Klazar</td><td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kT>5:5</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>7:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>9:1</td>
<td class=kW>3:1</td>
<td class=kW>9:0</td>
<td class=br>62:31</td><td class=br>+31</td>
<td class=bc>10 - 4 - 2</td>
<td class=br><strong>24</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Mi Kubica</td><td class=kL>5:6</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kL>2:4</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>1:0</td>
<td class=kW>8:2</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=kW>8:1</td>
<td class=br>72:34</td><td class=br>+38</td>
<td class=bc>12 - 0 - 4</td>
<td class=br><strong>24</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Kr Herold</td><td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>6:3</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=br>58:37</td><td class=br>+21</td>
<td class=bc>11 - 1 - 4</td>
<td class=br><strong>23</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ma Ženíšek</td><td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kT>5:5</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>6:5</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>7:0</td>
<td class=kW>4:1</td>
<td class=kW>6:4</td>
<td class=kW>3:0</td>
<td class=br>65:41</td><td class=br>+24</td>
<td class=bc>9 - 5 - 2</td>
<td class=br><strong>23</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Vl Kraus</td><td class=kL>4:9</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=kW>5:4</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=br>64:36</td><td class=br>+28</td>
<td class=bc>11 - 1 - 4</td>
<td class=br><strong>23</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Ra Pommerenke</td><td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kL>0:4</td>
<td class=kL>5:6</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kL>1:5</td>
<td class=kW>6:0</td>
<td class=br>37:41</td><td class=br>-4</td>
<td class=bc>7 - 1 - 8</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Mi Mašika</td><td class=kL>3:6</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kW>9:1</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=kW>4:0</td>
<td class=br>38:45</td><td class=br>-7</td>
<td class=bc>6 - 1 - 9</td>
<td class=br><strong>13</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ro Hejda</td><td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>8:5</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=br>45:49</td><td class=br>-4</td>
<td class=bc>5 - 2 - 9</td>
<td class=br><strong>12</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Pe Holub</td><td class=kL>3:10</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>0:7</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=br>43:54</td><td class=br>-11</td>
<td class=bc>5 - 2 - 9</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ja Medvec</td><td class=kL>4:10</td>
<td class=kL>1:3</td>
<td class=kL>0:7</td>
<td class=kL>2:8</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kL>0:3</td>
<td class=kL>1:9</td>
<td class=kL>5:8</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>8:4</td>
<td class=kL>1:4</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>10:1</td>
<td class=br>52:73</td><td class=br>-21</td>
<td class=bc>5 - 1 - 10</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ol Tabara</td><td class=kL>2:8</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>4:8</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=br>37:53</td><td class=br>-16</td>
<td class=bc>4 - 3 - 9</td>
<td class=br><strong>11</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ja Ouřada</td><td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=br>20:58</td><td class=br>-38</td>
<td class=bc>4 - 1 - 11</td>
<td class=br><strong>9</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ma Musil</td><td class=kL>3:4</td>
<td class=kW>4:0</td>
<td class=kL>1:9</td>
<td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=br>31:51</td><td class=br>-20</td>
<td class=bc>4 - 1 - 11</td>
<td class=br><strong>9</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Pa Janouškovec</td><td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>4:6</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kL>4:5</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=br>31:51</td><td class=br>-20</td>
<td class=bc>3 - 1 - 12</td>
<td class=br><strong>7</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Vo Hampejs</td><td class=kL>0:9</td>
<td class=kL>2:7</td>
<td class=kL>0:9</td>
<td class=kL>1:8</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:7</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>1:10</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=br>7:94</td><td class=br>-87</td>
<td class=bc>0 - 0 - 16</td>
<td class=br><strong>0</strong></td><td class=d>17.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Holub Petr</td><td class=bc>-</td><td class=bl>Hampejs Vojtěch</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Tabara Oliver</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Musil Martin</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ouřada Jaroslav</td><td class=bc>-</td><td class=bl>Medvec Jan</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Mašika Michal</td><td class=bc>-</td><td class=bl>Hejda Roman</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Hampejs Vojtěch</td><td class=bc>-</td><td class=blW>Pommerenke Ralph</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Holub Petr</td><td class=bc>-</td><td class=bl>Tabara Oliver</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Musil Martin</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Medvec Jan</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ouřada Jaroslav</td><td class=bc>-</td><td class=blW>Hejda Roman</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Pommerenke Ralph</td><td class=bc>-</td><td class=bl>Tabara Oliver</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Hampejs Vojtěch</td><td class=bc>-</td><td class=blW>Musil Martin</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Medvec Jan</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Hejda Roman</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>9 : 4</tr></td>
<tr><td class=br>Ouřada Jaroslav</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>6 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Tabara Oliver</td><td class=bc>-</td><td class=bl>Musil Martin</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pommerenke Ralph</td><td class=bc>-</td><td class=bl>Medvec Jan</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Hampejs Vojtěch</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Hejda Roman</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ouřada Jaroslav</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Musil Martin</td><td class=bc>-</td><td class=blW>Medvec Jan</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Tabara Oliver</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pommerenke Ralph</td><td class=bc>-</td><td class=bl>Hejda Roman</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Hampejs Vojtěch</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Medvec Jan</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Musil Martin</td><td class=bc>-</td><td class=bl>Hejda Roman</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Tabara Oliver</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Hampejs Vojtěch</td><td class=bc>-</td><td class=blW>Janouškovec Pavel</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Holub Petr</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Ouřada Jaroslav</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Hejda Roman</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Medvec Jan</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Musil Martin</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Tabara Oliver</td><td class=bc>-</td><td class=blW>Janouškovec Pavel</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=blW>Mašika Michal</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Hampejs Vojtěch</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Holub Petr</td><td class=bc>-</td><td class=bl>Ouřada Jaroslav</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Hejda Roman</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Medvec Jan</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Musil Martin</td><td class=bc>-</td><td class=blW>Mašika Michal</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Tabara Oliver</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pommerenke Ralph</td><td class=bc>-</td><td class=bl>Ouřada Jaroslav</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Hampejs Vojtěch</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Hejda Roman</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Medvec Jan</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Musil Martin</td><td class=bc>-</td><td class=blW>Ouřada Jaroslav</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Tabara Oliver</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hampejs Vojtěch</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Janouškovec Pavel</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Hejda Roman</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Ouřada Jaroslav</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Medvec Jan</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>4 : 10</tr></td>
<tr><td class=brW>Musil Martin</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Tabara Oliver</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=blW>Holub Petr</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Mašika Michal</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Ouřada Jaroslav</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Hejda Roman</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Medvec Jan</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Musil Martin</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Tabara Oliver</td><td class=bc>-</td><td class=bl>Hampejs Vojtěch</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Ouřada Jaroslav</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Hejda Roman</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Medvec Jan</td><td class=bc>-</td><td class=bl>Hampejs Vojtěch</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Musil Martin</td><td class=bc>-</td><td class=blW>Pommerenke Ralph</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Ouřada Jaroslav</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Hejda Roman</td><td class=bc>-</td><td class=bl>Hampejs Vojtěch</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Pommerenke Ralph</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Medvec Jan</td><td class=bc>-</td><td class=bl>Tabara Oliver</td><td class=bc>8 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ouřada Jaroslav</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Hampejs Vojtěch</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Hejda Roman</td><td class=bc>-</td><td class=bl>Tabara Oliver</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Musil Martin</td><td class=bc>9 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ouřada Jaroslav</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mašika Michal</td><td class=bc>-</td><td class=bl>Hampejs Vojtěch</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Janouškovec Pavel</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Tabara Oliver</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Musil Martin</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Hejda Roman</td><td class=bc>-</td><td class=bl>Medvec Jan</td><td class=bc>8 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>10 : 3</tr></td>
<tr><td class=brW>Ouřada Jaroslav</td><td class=bc>-</td><td class=bl>Hampejs Vojtěch</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Tabara Oliver</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Musil Martin</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Medvec Jan</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Hampejs Vojtěch</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ouřada Jaroslav</td><td class=bc>-</td><td class=blW>Tabara Oliver</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Musil Martin</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mašika Michal</td><td class=bc>-</td><td class=bl>Medvec Jan</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Hejda Roman</td><td class=bc>6 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Mi Hvižď</td><td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kW>8:1</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kW>9:0</td>
<td class=kW>13:0</td>
<td class=kW>11:0</td>
<td class=br>91:11</td><td class=br>+80</td>
<td class=bc>15 - 1 - 0</td>
<td class=br><strong>31</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ku Sládek</td><td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>0:1</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>8:4</td>
<td class=kW>4:3</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=br>61:21</td><td class=br>+40</td>
<td class=bc>13 - 2 - 1</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Mi Touš</td><td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>7:0</td>
<td class=kW>4:3</td>
<td class=kW>7:1</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=kW>12:0</td>
<td class=br>80:34</td><td class=br>+46</td>
<td class=bc>13 - 1 - 2</td>
<td class=br><strong>27</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ja Matýsek</td><td class=kL>0:4</td>
<td class=kW>1:0</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=br>58:26</td><td class=br>+32</td>
<td class=bc>11 - 2 - 3</td>
<td class=br><strong>24</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Al Krejza</td><td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>10:1</td>
<td class=kW>7:0</td>
<td class=br>66:26</td><td class=br>+40</td>
<td class=bc>10 - 2 - 4</td>
<td class=br><strong>22</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>On Gruncl</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kW>10:0</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=br>57:36</td><td class=br>+21</td>
<td class=bc>9 - 4 - 3</td>
<td class=br><strong>22</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Da Hrachovec</td><td class=kL>3:5</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kL>0:1</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=br>50:50</td><td class=br>0</td>
<td class=bc>8 - 1 - 7</td>
<td class=br><strong>17</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>An Šurýn</td><td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=br>44:37</td><td class=br>+7</td>
<td class=bc>8 - 1 - 7</td>
<td class=br><strong>17</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Gu Gripp</td><td class=kL>0:6</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>2:6</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kW>8:2</td>
<td class=kW>8:0</td>
<td class=kW>4:1</td>
<td class=kW>10:0</td>
<td class=br>48:41</td><td class=br>+7</td>
<td class=bc>6 - 2 - 8</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Mi Moravec</td><td class=kL>2:3</td>
<td class=kL>4:8</td>
<td class=kL>0:7</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=br>44:46</td><td class=br>-2</td>
<td class=bc>6 - 2 - 8</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>St Srba</td><td class=kL>1:8</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=br>40:47</td><td class=br>-7</td>
<td class=bc>6 - 1 - 9</td>
<td class=br><strong>13</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ví Pernica</td><td class=kL>2:6</td>
<td class=kT>0:0</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>8:3</td>
<td class=kW>5:0</td>
<td class=br>41:48</td><td class=br>-7</td>
<td class=bc>5 - 3 - 8</td>
<td class=br><strong>13</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Jo Gruncl</td><td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>3:7</td>
<td class=kL>0:7</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=br>30:42</td><td class=br>-12</td>
<td class=bc>5 - 3 - 8</td>
<td class=br><strong>13</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ma Moravec</td><td class=kL>0:5</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>2:8</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=br>35:52</td><td class=br>-17</td>
<td class=bc>5 - 1 - 10</td>
<td class=br><strong>11</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Vá Macek ml.</td><td class=kL>0:9</td>
<td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>0:10</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=br>23:81</td><td class=br>-58</td>
<td class=bc>2 - 0 - 14</td>
<td class=br><strong>4</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Mi Matuštík</td><td class=kL>0:13</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>1:10</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>0:3</td>
<td class=kL>3:8</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>15:89</td><td class=br>-74</td>
<td class=bc>1 - 0 - 15</td>
<td class=br><strong>2</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Ma Vích</td><td class=kL>0:11</td>
<td class=kL>2:5</td>
<td class=kL>0:12</td>
<td class=kL>1:7</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>0:7</td>
<td class=kL>0:10</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>6:102</td><td class=br>-96</td>
<td class=bc>0 - 0 - 16</td>
<td class=br><strong>0</strong></td><td class=d>17.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Vích Matyáš</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Hrachovec Daniel</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Macek ml. Václav</td><td class=bc>-</td><td class=blW>Gruncl Josef</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Srba Stanislav</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Matuštík Milan</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Vích Matyáš</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=bl>Gruncl Josef</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Hrachovec Daniel</td><td class=bc>-</td><td class=bl>Srba Stanislav</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Macek ml. Václav</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Matýsek Jakub</td><td class=bc>-</td><td class=blW>Gripp Gunnar</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vích Matyáš</td><td class=bc>-</td><td class=blW>Gruncl Josef</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Srba Stanislav</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Hrachovec Daniel</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Macek ml. Václav</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Gripp Gunnar</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Matuštík Milan</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Gruncl Josef</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Srba Stanislav</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Vích Matyáš</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Hrachovec Daniel</td><td class=bc>-</td><td class=bl>Gripp Gunnar</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Macek ml. Václav</td><td class=bc>-</td><td class=bl>Matuštík Milan</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Gruncl Josef</td><td class=bc>-</td><td class=blW>Srba Stanislav</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Hvižď Michal</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vích Matyáš</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Gripp Gunnar</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Matuštík Milan</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Hrachovec Daniel</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Macek ml. Václav</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Srba Stanislav</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Gruncl Josef</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=bl>Gripp Gunnar</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Vích Matyáš</td><td class=bc>-</td><td class=blW>Matuštík Milan</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Hrachovec Daniel</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Srba Stanislav</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Gruncl Josef</td><td class=bc>-</td><td class=bl>Gripp Gunnar</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Matuštík Milan</td><td class=bc>13 : 0</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vích Matyáš</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>0 : 12</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Macek ml. Václav</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Gripp Gunnar</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Srba Stanislav</td><td class=bc>-</td><td class=bl>Matuštík Milan</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Gruncl Josef</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vích Matyáš</td><td class=bc>-</td><td class=blW>Macek ml. Václav</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=blW>Hrachovec Daniel</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Gripp Gunnar</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Matuštík Milan</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Srba Stanislav</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Gruncl Josef</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Macek ml. Václav</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Hrachovec Daniel</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Vích Matyáš</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Gripp Gunnar</td><td class=bc>-</td><td class=bl>Matuštík Milan</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Srba Stanislav</td><td class=bc>-</td><td class=bl>Macek ml. Václav</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Gruncl Josef</td><td class=bc>-</td><td class=bl>Hrachovec Daniel</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Matuštík Milan</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Gripp Gunnar</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Macek ml. Václav</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Hrachovec Daniel</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Srba Stanislav</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Gruncl Josef</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Vích Matyáš</td><td class=bc>11 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Matýsek Jakub</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Matuštík Milan</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Gripp Gunnar</td><td class=bc>-</td><td class=bl>Macek ml. Václav</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Hrachovec Daniel</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Srba Stanislav</td><td class=bc>-</td><td class=bl>Vích Matyáš</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Gruncl Josef</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Macek ml. Václav</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Matuštík Milan</td><td class=bc>-</td><td class=blW>Hrachovec Daniel</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Gripp Gunnar</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Vích Matyáš</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Srba Stanislav</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>1 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Macek ml. Václav</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Hrachovec Daniel</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Matuštík Milan</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Gripp Gunnar</td><td class=bc>-</td><td class=bl>Vích Matyáš</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Gruncl Josef</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Macek ml. Václav</td><td class=bc>-</td><td class=blW>Hrachovec Daniel</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Vích Matyáš</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Matuštík Milan</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Gripp Gunnar</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=bl>Gruncl Josef</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Srba Stanislav</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Hrachovec Daniel</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Macek ml. Václav</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Vích Matyáš</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Matýsek Jakub</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Matuštík Milan</td><td class=bc>-</td><td class=blW>Gruncl Josef</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Gripp Gunnar</td><td class=bc>-</td><td class=blW>Srba Stanislav</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Hrachovec Daniel</td><td class=bc>-</td><td class=bl>Vích Matyáš</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Macek ml. Václav</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Gruncl Josef</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Srba Stanislav</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Matuštík Milan</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Gripp Gunnar</td><td class=bc>-</td><td class=blW>Gruncl Ondřej</td><td class=bc>1 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 3</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Pa Petr</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>7:3</td>
<td class=kW>9:2</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kW>9:1</td>
<td class=kW>9:0</td>
<td class=kW>10:2</td>
<td class=kW>10:1</td>
<td class=kW>11:0</td>
<td class=kW>9:0</td>
<td class=kW>14:0</td>
<td class=kW>12:0</td>
<td class=br>120:17</td><td class=br>+103</td>
<td class=bc>14 - 1 - 0</td>
<td class=br><strong>29</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Zd Matoušek ml.</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>8:2</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>7:1</td>
<td class=kW>9:0</td>
<td class=kW>13:0</td>
<td class=br>82:9</td><td class=br>+73</td>
<td class=bc>14 - 1 - 0</td>
<td class=br><strong>29</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Da Matýsek</td><td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kW>6:3</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>8:2</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>9:0</td>
<td class=br>64:24</td><td class=br>+40</td>
<td class=bc>12 - 0 - 3</td>
<td class=br><strong>24</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Vo Kraus</td><td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>9:1</td>
<td class=br>58:30</td><td class=br>+28</td>
<td class=bc>10 - 1 - 4</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Fr Marek</td><td class=kL>3:7</td>
<td class=kL>0:7</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kL>0:5</td>
<td class=kL>2:7</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>9:0</td>
<td class=br>56:43</td><td class=br>+13</td>
<td class=bc>10 - 0 - 5</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ja Janouškovec</td><td class=kL>2:9</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kW>10:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=br>57:40</td><td class=br>+17</td>
<td class=bc>9 - 1 - 5</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Mi Ševr</td><td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=kW>16:4</td>
<td class=kW>9:2</td>
<td class=kW>9:0</td>
<td class=kW>13:1</td>
<td class=br>82:38</td><td class=br>+44</td>
<td class=bc>9 - 1 - 5</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Pa Plešák</td><td class=kL>3:6</td>
<td class=kL>0:1</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>9:1</td>
<td class=kW>6:0</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kW>9:0</td>
<td class=kW>9:0</td>
<td class=kW>12:0</td>
<td class=kW>14:1</td>
<td class=br>88:28</td><td class=br>+60</td>
<td class=bc>9 - 1 - 5</td>
<td class=br><strong>19</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Os Tabara</td><td class=kL>1:9</td>
<td class=kL>0:5</td>
<td class=kL>0:1</td>
<td class=kL>0:6</td>
<td class=kW>7:2</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kL>1:9</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>12:1</td>
<td class=br>51:50</td><td class=br>+1</td>
<td class=bc>8 - 1 - 6</td>
<td class=br><strong>17</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Lu Holub</td><td class=kL>0:9</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:7</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=br>32:55</td><td class=br>-23</td>
<td class=bc>6 - 0 - 9</td>
<td class=br><strong>12</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Pe Klazar</td><td class=kL>2:10</td>
<td class=kL>2:8</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>2:7</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=br>38:62</td><td class=br>-24</td>
<td class=bc>4 - 1 - 10</td>
<td class=br><strong>9</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ja Kopecký</td><td class=kL>1:10</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=br>26:55</td><td class=br>-29</td>
<td class=bc>3 - 2 - 10</td>
<td class=br><strong>8</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Mi Horáková</td><td class=kL>0:11</td>
<td class=kL>0:6</td>
<td class=kL>2:8</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>2:10</td>
<td class=kL>4:16</td>
<td class=kL>0:9</td>
<td class=kL>3:4</td>
<td class=kL>2:7</td>
<td class=kL>3:6</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>8:1</td>
<td class=br>34:93</td><td class=br>-59</td>
<td class=bc>3 - 1 - 11</td>
<td class=br><strong>7</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>To Urban</td><td class=kL>0:9</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>2:9</td>
<td class=kL>0:9</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kW>4:1</td>
<td class=br>27:75</td><td class=br>-48</td>
<td class=bc>2 - 1 - 12</td>
<td class=br><strong>5</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ro Hašek</td><td class=kL>0:14</td>
<td class=kL>0:9</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>0:9</td>
<td class=kL>0:12</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=br>15:95</td><td class=br>-80</td>
<td class=bc>1 - 0 - 14</td>
<td class=br><strong>2</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Ro Kubinec</td><td class=kL>0:12</td>
<td class=kL>0:13</td>
<td class=kL>0:9</td>
<td class=kL>1:9</td>
<td class=kL>0:9</td>
<td class=kL>1:7</td>
<td class=kL>1:13</td>
<td class=kL>1:14</td>
<td class=kL>1:12</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>1:8</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=br>8:124</td><td class=br>-116</td>
<td class=bc>0 - 0 - 15</td>
<td class=br><strong>0</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Marek František</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Matoušek ml. Zdeněk</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=blW>Klazar Petr</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Tabara Oskar</td><td class=bc>-</td><td class=bl>Hašek Roman</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Holub Lukáš</td><td class=bc>-</td><td class=bl>Kopecký Jaroslav</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kubinec Roman</td><td class=bc>-</td><td class=blW>Horáková Miroslava</td><td class=bc>1 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Matoušek ml. Zdeněk</td><td class=bc>-</td><td class=bl>Hašek Roman</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=blW>Kopecký Jaroslav</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Holub Lukáš</td><td class=bc>-</td><td class=bl>Horáková Miroslava</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Kubinec Roman</td><td class=bc>12 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Marek František</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Hašek Roman</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Kopecký Jaroslav</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Matoušek ml. Zdeněk</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=bl>Horáková Miroslava</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Tabara Oskar</td><td class=bc>-</td><td class=bl>Kubinec Roman</td><td class=bc>12 : 1</tr></td>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 9</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Hašek Roman</td><td class=bc>12 : 0</tr></td>
<tr><td class=brW>Marek František</td><td class=bc>-</td><td class=bl>Kopecký Jaroslav</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Horáková Miroslava</td><td class=bc>10 : 2</tr></td>
<tr><td class=brW>Matoušek ml. Zdeněk</td><td class=bc>-</td><td class=bl>Kubinec Roman</td><td class=bc>13 : 0</tr></td>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Tabara Oskar</td><td class=bc>-</td><td class=bl>Holub Lukáš</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Klazar Petr</td><td class=bc>-</td><td class=bl>Hašek Roman</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Kopecký Jaroslav</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Marek František</td><td class=bc>-</td><td class=bl>Horáková Miroslava</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Kubinec Roman</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>2 : 9</tr></td>
<tr><td class=brW>Matoušek ml. Zdeněk</td><td class=bc>-</td><td class=bl>Holub Lukáš</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=blW>Tabara Oskar</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Hašek Roman</td><td class=bc>-</td><td class=blW>Kopecký Jaroslav</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Horáková Miroslava</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Kubinec Roman</td><td class=bc>14 : 1</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Holub Lukáš</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Janouškovec Jan</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Matoušek ml. Zdeněk</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Kopecký Jaroslav</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Hašek Roman</td><td class=bc>-</td><td class=blW>Horáková Miroslava</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Klazar Petr</td><td class=bc>-</td><td class=bl>Kubinec Roman</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Holub Lukáš</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=blW>Tabara Oskar</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Matoušek ml. Zdeněk</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Horáková Miroslava</td><td class=bc>16 : 4</tr></td>
<tr><td class=brW>Kopecký Jaroslav</td><td class=bc>-</td><td class=bl>Kubinec Roman</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Hašek Roman</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 14</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Holub Lukáš</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=blW>Matoušek ml. Zdeněk</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Horáková Miroslava</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 11</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Holub Lukáš</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kopecký Jaroslav</td><td class=bc>-</td><td class=blW>Tabara Oskar</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Hašek Roman</td><td class=bc>-</td><td class=blW>Urban Tomáš</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Matoušek ml. Zdeněk</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Kubinec Roman</td><td class=bc>-</td><td class=blW>Holub Lukáš</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Horáková Miroslava</td><td class=bc>-</td><td class=blW>Tabara Oskar</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Kopecký Jaroslav</td><td class=bc>-</td><td class=blW>Matoušek ml. Zdeněk</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Hašek Roman</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Kubinec Roman</td><td class=bc>-</td><td class=blW>Urban Tomáš</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Horáková Miroslava</td><td class=bc>-</td><td class=blW>Matoušek ml. Zdeněk</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kopecký Jaroslav</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Hašek Roman</td><td class=bc>-</td><td class=blW>Marek František</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Holub Lukáš</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Petr Patrik</td><td class=bc>-</td><td class=bl>Matoušek ml. Zdeněk</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kubinec Roman</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Horáková Miroslava</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Marek František</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kopecký Jaroslav</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Hašek Roman</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=blW>Matoušek ml. Zdeněk</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kubinec Roman</td><td class=bc>-</td><td class=blW>Marek František</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Horáková Miroslava</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kopecký Jaroslav</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Hašek Roman</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Marek František</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Kubinec Roman</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Horáková Miroslava</td><td class=bc>-</td><td class=blW>Klazar Petr</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Hašek Roman</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Kopecký Jaroslav</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Matoušek ml. Zdeněk</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=blW>Marek František</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>10 : 2</tr></td>
<tr><td class=br>Kubinec Roman</td><td class=bc>-</td><td class=blW>Hašek Roman</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Horáková Miroslava</td><td class=bc>-</td><td class=bl>Kopecký Jaroslav</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Marek František</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Matoušek ml. Zdeněk</td><td class=bc>-</td><td class=bl>Plešák Pavel</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Tabara Oskar</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Holub Lukáš</td><td class=bc>-</td><td class=bl>Hašek Roman</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Kopecký Jaroslav</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Kubinec Roman</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>1 : 13</tr></td>
<tr><td class=br>Horáková Miroslava</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 4</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Kr Lebl</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>9:5</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>6:3</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>7:0</td>
<td class=kW>9:1</td>
<td class=kW>7:0</td>
<td class=br>82:15</td><td class=br>+67</td>
<td class=bc>14 - 1 - 0</td>
<td class=br><strong>29</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ji Chylík ml.</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kL>3:4</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>8:3</td>
<td class=kW>5:2</td>
<td class=kW>8:0</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=br>64:20</td><td class=br>+44</td>
<td class=bc>13 - 1 - 1</td>
<td class=br><strong>27</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ji Vácha</td><td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>8:0</td>
<td class=kW>7:1</td>
<td class=br>63:31</td><td class=br>+32</td>
<td class=bc>11 - 0 - 4</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Vá Pikl</td><td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kW>7:0</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>8:3</td>
<td class=kW>8:0</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=kW>9:1</td>
<td class=kW>9:0</td>
<td class=br>72:25</td><td class=br>+47</td>
<td class=bc>11 - 0 - 4</td>
<td class=br><strong>22</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Mi Uhlíř</td><td class=kL>5:9</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>8:3</td>
<td class=kW>5:2</td>
<td class=br>68:37</td><td class=br>+31</td>
<td class=bc>11 - 0 - 4</td>
<td class=br><strong>22</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Mi Černoch</td><td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>8:0</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=br>59:24</td><td class=br>+35</td>
<td class=bc>11 - 0 - 4</td>
<td class=br><strong>22</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>To Růžička</td><td class=kL>0:2</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>8:0</td>
<td class=kW>5:1</td>
<td class=kW>7:3</td>
<td class=kW>5:0</td>
<td class=br>57:29</td><td class=br>+28</td>
<td class=bc>10 - 1 - 4</td>
<td class=br><strong>21</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Fr Rasche</td><td class=kL>3:6</td>
<td class=kL>1:6</td>
<td class=kW>6:2</td>
<td class=kL>0:7</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>4:5</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=br>44:44</td><td class=br>0</td>
<td class=bc>7 - 1 - 7</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Vá Macek</td><td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>7:3</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>8:0</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=br>54:43</td><td class=br>+11</td>
<td class=bc>6 - 2 - 7</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Hy Nechutný</td><td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=br>36:39</td><td class=br>-3</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ra Hrnčíř</td><td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>3:8</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kL>3:7</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>2:0</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=br>35:57</td><td class=br>-22</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ji Musil</td><td class=kL>0:6</td>
<td class=kL>3:8</td>
<td class=kL>1:6</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>0:8</td>
<td class=kL>1:7</td>
<td class=kW>5:4</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=br>35:70</td><td class=br>-35</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Vo Pošík</td><td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=br>23:58</td><td class=br>-35</td>
<td class=bc>2 - 2 - 11</td>
<td class=br><strong>6</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ji Pošík</td><td class=kL>0:7</td>
<td class=kL>0:8</td>
<td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>0:8</td>
<td class=kL>0:7</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=br>13:79</td><td class=br>-66</td>
<td class=bc>1 - 2 - 12</td>
<td class=br><strong>4</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ja Kubica</td><td class=kL>1:9</td>
<td class=kL>0:6</td>
<td class=kL>0:8</td>
<td class=kL>1:9</td>
<td class=kL>3:8</td>
<td class=kL>1:6</td>
<td class=kL>3:7</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=br>15:81</td><td class=br>-66</td>
<td class=bc>0 - 2 - 13</td>
<td class=br><strong>2</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Jo Staněk</td><td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>1:7</td>
<td class=kL>0:9</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=br>7:75</td><td class=br>-68</td>
<td class=bc>0 - 1 - 14</td>
<td class=br><strong>1</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Staněk Josef</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Macek Václav</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=blW>Musil Jindřich</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Rasche Frank</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Uhlíř Miroslav</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Staněk Josef</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Musil Jindřich</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Macek Václav</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Rasche Frank</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Uhlíř Miroslav</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Staněk Josef</td><td class=bc>-</td><td class=blW>Musil Jindřich</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Macek Václav</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=blW>Uhlíř Miroslav</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Rasche Frank</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Musil Jindřich</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Staněk Josef</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Uhlíř Miroslav</td><td class=bc>9 : 5</tr></td>
<tr><td class=br>Macek Václav</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=blW>Rasche Frank</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Musil Jindřich</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Staněk Josef</td><td class=bc>-</td><td class=blW>Uhlíř Miroslav</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Macek Václav</td><td class=bc>-</td><td class=bl>Kubica Jan</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Musil Jindřich</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Uhlíř Miroslav</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Staněk Josef</td><td class=bc>-</td><td class=blW>Rasche Frank</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Kubica Jan</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Macek Václav</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Musil Jindřich</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Uhlíř Miroslav</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Kubica Jan</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Staněk Josef</td><td class=bc>-</td><td class=blW>Macek Václav</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Uhlíř Miroslav</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Musil Jindřich</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=blW>Rasche Frank</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Kubica Jan</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Macek Václav</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Staněk Josef</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=bl>Kubica Jan</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Musil Jindřich</td><td class=bc>-</td><td class=blW>Macek Václav</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Staněk Josef</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Uhlíř Miroslav</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Kubica Jan</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Macek Václav</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Musil Jindřich</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Staněk Josef</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Pošík Vojtěch</td><td class=bc>-</td><td class=bl>Kubica Jan</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Uhlíř Miroslav</td><td class=bc>-</td><td class=bl>Macek Václav</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pošík Jiří</td><td class=bc>-</td><td class=bl>Staněk Josef</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Musil Jindřich</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Rasche Frank</td><td class=bc>-</td><td class=bl>Macek Václav</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Staněk Josef</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Musil Jindřich</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Pošík Vojtěch</td><td class=bc>-</td><td class=bl>Staněk Josef</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Uhlíř Miroslav</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Musil Jindřich</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Macek Václav</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=bl>Staněk Josef</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Uhlíř Miroslav</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Musil Jindřich</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Staněk Josef</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Macek Václav</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Uhlíř Miroslav</td><td class=bc>-</td><td class=bl>Musil Jindřich</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Macek Václav</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Musil Jindřich</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Uhlíř Miroslav</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<hr><a name="final"><p class=vm>Výkonnostní skupiny (Final groups)</p></a>
<p class=v>Group A</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt>Zd Matoušek ml.</td><td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kL>1:5</td>
<td class=kW>5:3</td>
<td class=kW>6:4</td>
<td class=kW>4:1</td>
<td class=kW>7:4</td>
<td class=kL>2:8</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>3:2 K</td>
<td class=kW>5:0</td>
<td class=kW>2:0 K</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=kW>8:1</td>
<td class=kW>7:0 K</td>
<td class=kW>4:0 K</td>
<td class=br>96:47</td><td class=br>+49</td>
<td class=bc>19 - 1 - 3</td>
<td class=br><strong>39</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt>Pa Petr</td><td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kL>1:4</td>
<td class=kW>6:3</td>
<td class=kL>4:5</td>
<td class=kT>3:3</td>
<td class=kW>5:1 K</td>
<td class=kW>6:0</td>
<td class=kW>4:1 K</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kW>6:2</td>
<td class=kW>11:0</td>
<td class=kW>9:1</td>
<td class=kW>7:3 K</td>
<td class=kW>9:2 K</td>
<td class=br>114:47</td><td class=br>+67</td>
<td class=bc>16 - 5 - 2</td>
<td class=br><strong>37</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt>Mi Kobrle</td><td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kW>5:2 K</td>
<td class=kT>4:4</td>
<td class=kW>5:1 K</td>
<td class=kW>3:1</td>
<td class=kW>6:5 K</td>
<td class=kW>8:0</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>5:3</td>
<td class=kW>6:2 K</td>
<td class=kT>3:3 K</td>
<td class=kW>9:3</td>
<td class=kW>9:2</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=br>110:50</td><td class=br>+60</td>
<td class=bc>15 - 6 - 2</td>
<td class=br><strong>36</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt>Mi Hvižď</td><td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kW>4:0 K</td>
<td class=kT>1:1 K</td>
<td class=kW>6:2</td>
<td class=kW>4:1 K</td>
<td class=kW>6:5</td>
<td class=kT>5:5</td>
<td class=kT>3:3</td>
<td class=kT>6:6</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>2:1 K</td>
<td class=kW>8:4</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kW>5:0 K</td>
<td class=kW>5:1</td>
<td class=kW>8:4</td>
<td class=br>102:54</td><td class=br>+48</td>
<td class=bc>15 - 6 - 2</td>
<td class=br><strong>36</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>Ji Chylík ml.</td><td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kW>4:0</td>
<td class=kW>5:0 K</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1 K</td>
<td class=kT>3:3</td>
<td class=kW>2:1 K</td>
<td class=kW>7:3</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kW>3:2 K</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=br>81:41</td><td class=br>+40</td>
<td class=bc>15 - 5 - 3</td>
<td class=br><strong>35</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>Kr Lebl</td><td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kW>5:4</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kL>1:8</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kW>3:1 K</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>5:2 K</td>
<td class=kW>4:3</td>
<td class=kW>3:0 K</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>9:5 K</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=br>84:58</td><td class=br>+26</td>
<td class=bc>15 - 4 - 4</td>
<td class=br><strong>34</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Ja Matýsek</td><td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>0:4 K</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>1:0 K</td>
<td class=kW>4:1</td>
<td class=kL>4:5 K</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kW>4:1 K</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kT>2:2 K</td>
<td class=kW>6:1</td>
<td class=kW>8:0</td>
<td class=br>78:49</td><td class=br>+29</td>
<td class=bc>12 - 7 - 4</td>
<td class=br><strong>31</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>Ku Sládek</td><td class=kL>4:6</td>
<td class=kL>0:4</td>
<td class=kW>5:3</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>0:1 K</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:3 K</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>3:9</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2 K</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kW>5:3</td>
<td class=kW>5:0 K</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=br>66:60</td><td class=br>+6</td>
<td class=bc>12 - 3 - 8</td>
<td class=br><strong>27</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>To Bucek</td><td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>2:5 K</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kW>8:1</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>1:1 K</td>
<td class=kL>1:5</td>
<td class=kW>4:2 K</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1 K</td>
<td class=kW>4:3 K</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=br>63:61</td><td class=br>+2</td>
<td class=bc>12 - 3 - 8</td>
<td class=br><strong>27</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Mi Touš</td><td class=kL>4:7</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kL>1:4 K</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kW>5:4 K</td>
<td class=kL>3:5 K</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>9:6</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2 K</td>
<td class=kT>2:2</td>
<td class=kT>5:5</td>
<td class=kL>4:6</td>
<td class=kW>6:2 K</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>87:78</td><td class=br>+9</td>
<td class=bc>10 - 6 - 7</td>
<td class=br><strong>26</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>Ma Klazar</td><td class=kW>8:2</td>
<td class=kL>3:6</td>
<td class=kL>1:5 K</td>
<td class=kL>5:6</td>
<td class=kL>0:4</td>
<td class=kW>4:2</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kT>1:1 K</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1 K</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kL>0:3</td>
<td class=kW>3:2 K</td>
<td class=kT>5:5 K</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=br>74:63</td><td class=br>+11</td>
<td class=bc>10 - 4 - 9</td>
<td class=br><strong>24</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>Mi Černoch</td><td class=kL>0:3</td>
<td class=kW>5:4</td>
<td class=kL>1:3</td>
<td class=kT>5:5</td>
<td class=kL>0:5 K</td>
<td class=kL>1:3 K</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kL>1:4 K</td>
<td class=kT>3:3</td>
<td class=kL>3:5 K</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kW>3:2 K</td>
<td class=kW>8:2</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=br>62:69</td><td class=br>-7</td>
<td class=bc>9 - 5 - 9</td>
<td class=br><strong>23</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt>Mi Kubica</td><td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>5:6 K</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>2:4 K</td>
<td class=kL>2:3</td>
<td class=kL>1:2 K</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>8:1</td>
<td class=kW>3:1</td>
<td class=kW>3:1 K</td>
<td class=kW>5:3 K</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>2:0</td>
<td class=br>74:59</td><td class=br>+15</td>
<td class=bc>10 - 3 - 10</td>
<td class=br><strong>23</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt>Vo Kraus</td><td class=kL>2:3 K</td>
<td class=kL>1:5 K</td>
<td class=kL>0:8</td>
<td class=kT>6:6</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kL>6:9</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:1 K</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>8:1</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>2:3 K</td>
<td class=kW>4:3 K</td>
<td class=br>66:73</td><td class=br>-7</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt>Ji Vácha</td><td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>1:3 K</td>
<td class=kL>2:5 K</td>
<td class=kL>0:5</td>
<td class=kW>9:3</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kW>4:3</td>
<td class=kW>4:1 K</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>2:3 K</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kW>7:3</td>
<td class=kW>4:2 K</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=br>65:81</td><td class=br>-16</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt>Da Matýsek</td><td class=kL>0:2 K</td>
<td class=kL>1:4 K</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3 K</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kL>2:6</td>
<td class=kW>5:3</td>
<td class=kL>2:4</td>
<td class=kW>6:1</td>
<td class=kW>5:2 K</td>
<td class=kW>2:0 K</td>
<td class=br>59:61</td><td class=br>-2</td>
<td class=bc>8 - 5 - 10</td>
<td class=br><strong>21</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Vá Pikl</td><td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>1:2 K</td>
<td class=kL>0:3 K</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kW>5:3 K</td>
<td class=kL>1:8</td>
<td class=kL>0:2</td>
<td class=kW>3:2 K</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kL>2:3 K</td>
<td class=kW>4:0</td>
<td class=kT>0:0</td>
<td class=kW>2:1</td>
<td class=br>49:68</td><td class=br>-19</td>
<td class=bc>7 - 2 - 14</td>
<td class=br><strong>16</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Al Krejza</td><td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kL>3:5</td>
<td class=kL>1:2 K</td>
<td class=kL>3:7</td>
<td class=kT>1:1</td>
<td class=kL>1:4 K</td>
<td class=kL>2:4 K</td>
<td class=kT>2:2</td>
<td class=kL>2:4 K</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kT>2:2 K</td>
<td class=kW>7:3</td>
<td class=kW>5:0</td>
<td class=br>57:67</td><td class=br>-10</td>
<td class=bc>5 - 6 - 12</td>
<td class=br><strong>16</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Kr Herold</td><td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kL>2:6 K</td>
<td class=kL>4:8</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>1:2 K</td>
<td class=kT>2:2</td>
<td class=kL>2:3 K</td>
<td class=kT>3:3</td>
<td class=kL>1:3 K</td>
<td class=kL>1:8</td>
<td class=kL>0:1</td>
<td class=kW>6:2</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>3:3 K</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=br>52:74</td><td class=br>-22</td>
<td class=bc>5 - 5 - 13</td>
<td class=br><strong>15</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Ma Ženíšek</td><td class=kL>2:7</td>
<td class=kL>2:6</td>
<td class=kT>3:3 K</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kW>4:0</td>
<td class=kL>3:4 K</td>
<td class=kT>5:5</td>
<td class=kT>5:5 K</td>
<td class=kL>4:5</td>
<td class=kL>3:5 K</td>
<td class=kL>2:3</td>
<td class=kL>3:7</td>
<td class=kL>3:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kT>3:3 K</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=br>61:93</td><td class=br>-32</td>
<td class=bc>5 - 4 - 14</td>
<td class=br><strong>14</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Mi Uhlíř</td><td class=kL>1:6</td>
<td class=kL>0:11</td>
<td class=kL>3:9</td>
<td class=kL>2:6</td>
<td class=kL>2:3 K</td>
<td class=kL>5:9 K</td>
<td class=kL>0:2</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kW>6:4</td>
<td class=kL>0:1</td>
<td class=kL>2:3 K</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kL>2:4 K</td>
<td class=kW>4:2</td>
<td class=kW>3:2 K</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>7:2</td>
<td class=kW>7:2</td>
<td class=br>64:95</td><td class=br>-31</td>
<td class=bc>6 - 2 - 15</td>
<td class=br><strong>14</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>On Gruncl</td><td class=kL>1:8</td>
<td class=kL>1:9</td>
<td class=kL>2:9</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kT>2:2 K</td>
<td class=kL>0:5 K</td>
<td class=kL>3:5</td>
<td class=kL>2:6 K</td>
<td class=kL>0:4</td>
<td class=kL>2:8</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>4:7</td>
<td class=br>36:112</td><td class=br>-76</td>
<td class=bc>1 - 5 - 17</td>
<td class=br><strong>7</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Fr Marek</td><td class=kL>0:7 K</td>
<td class=kL>3:7 K</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>0:1</td>
<td class=kL>0:6</td>
<td class=kW>3:2 K</td>
<td class=kL>2:6</td>
<td class=kL>2:5 K</td>
<td class=kT>0:0</td>
<td class=kL>3:7</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:2 K</td>
<td class=br>32:103</td><td class=br>-71</td>
<td class=bc>2 - 1 - 20</td>
<td class=br><strong>5</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Ja Janouškovec</td><td class=kL>0:4 K</td>
<td class=kL>2:9 K</td>
<td class=kL>1:6</td>
<td class=kL>4:8</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>0:8</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>3:4 K</td>
<td class=kL>3:6</td>
<td class=kL>0:2 K</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kL>2:7</td>
<td class=kW>7:4</td>
<td class=kL>2:5 K</td>
<td class=kx>*</td>
<td class=br>36:105</td><td class=br>-69</td>
<td class=bc>2 - 0 - 21</td>
<td class=br><strong>4</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Petr Patrik</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Matoušek ml. Zdeněk</td><td class=bc>-</td><td class=bl>Uhlíř Miroslav</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=blW>Touš Michal</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Uhlíř Miroslav</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Matýsek Jakub</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Matoušek ml. Zdeněk</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Hvižď Michal</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Matoušek ml. Zdeněk</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Uhlíř Miroslav</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Matýsek Jakub</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Hvižď Michal</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Matoušek ml. Zdeněk</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Krejza Aleš</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Uhlíř Miroslav</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Sládek Kuba</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kraus Vojtěch</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>4 : 8</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Uhlíř Miroslav</td><td class=bc>11 : 0</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Matoušek ml. Zdeněk</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Sládek Kuba</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Matoušek ml. Zdeněk</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Hvižď Michal</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Matýsek Daniel</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Gruncl Ondřej</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kraus Vojtěch</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Krejza Aleš</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Marek František</td><td class=bc>-</td><td class=blW>Uhlíř Miroslav</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Matýsek Jakub</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Janouškovec Jan</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Touš Michal</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Petr Patrik</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Hvižď Michal</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=bl>Uhlíř Miroslav</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Matoušek ml. Zdeněk</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Uhlíř Miroslav</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Matoušek ml. Zdeněk</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Uhlíř Miroslav</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Klazar Matyáš</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=blW>Matoušek ml. Zdeněk</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Pikl Václav</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Uhlíř Miroslav</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hvižď Michal</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=bl>Chylík ml. Jiří</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Ženíšek Martin</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Bucek Tomáš</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Matoušek ml. Zdeněk</td><td class=bc>8 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Uhlíř Miroslav</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Černoch Miroslav</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Lebl Kryštof</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Hvižď Michal</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Vácha Jiří</td><td class=bc>3 : 9</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Herold Kryštof</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Kobrle Michal</td><td class=bc>-</td><td class=blW>Matoušek ml. Zdeněk</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Uhlíř Miroslav</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Černoch Miroslav</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Lebl Kryštof</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Chylík ml. Jiří</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Vácha Jiří</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Pikl Václav</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Bucek Tomáš</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Klazar Matyáš</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Kubica Miloslav</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Herold Kryštof</td><td class=bc>-</td><td class=blW>Matoušek ml. Zdeněk</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ženíšek Martin</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Kobrle Michal</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>8 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Hvižď Michal</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Matoušek ml. Zdeněk</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=blW>Herold Kryštof</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Matoušek ml. Zdeněk</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Bucek Tomáš</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>3 : 9</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Janouškovec Jan</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Petr Patrik</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Matýsek Jakub</td><td class=bc>-</td><td class=blW>Matoušek ml. Zdeněk</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Klazar Matyáš</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Kraus Vojtěch</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=blW>Kubica Miloslav</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Gruncl Ondřej</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>8 : 4</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Sládek Kuba</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Kobrle Michal</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Touš Michal</td><td class=bc>-</td><td class=blW>Matoušek ml. Zdeněk</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Vácha Jiří</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>9 : 6</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Matýsek Jakub</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Pikl Václav</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Krejza Aleš</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=blW>Ženíšek Martin</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Hvižď Michal</td><td class=bc>-</td><td class=bl>Matoušek ml. Zdeněk</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Lebl Kryštof</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Matýsek Daniel</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Sládek Kuba</td><td class=bc>-</td><td class=bl>Marek František</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Chylík ml. Jiří</td><td class=bc>-</td><td class=bl>Herold Kryštof</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Touš Michal</td><td class=bc>-</td><td class=bl>Janouškovec Jan</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Vácha Jiří</td><td class=bc>-</td><td class=bl>Ženíšek Martin</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Matýsek Jakub</td><td class=bc>-</td><td class=blW>Petr Patrik</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pikl Václav</td><td class=bc>-</td><td class=blW>Kobrle Michal</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Krejza Aleš</td><td class=bc>-</td><td class=blW>Matoušek ml. Zdeněk</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Uhlíř Miroslav</td><td class=bc>-</td><td class=blW>Bucek Tomáš</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Gruncl Ondřej</td><td class=bc>-</td><td class=blW>Matýsek Daniel</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Černoch Miroslav</td><td class=bc>-</td><td class=bl>Klazar Matyáš</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hvižď Michal</td><td class=bc>-</td><td class=bl>Kraus Vojtěch</td><td class=bc>6 : 6</tr></td>
<tr><td class=brW>Lebl Kryštof</td><td class=bc>-</td><td class=bl>Kubica Miloslav</td><td class=bc>3 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Pa Plešák</td><td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>6:3</td>
<td class=kW>8:2</td>
<td class=kW>5:4</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>6:4</td>
<td class=kL>4:7</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=br>82:42</td><td class=br>+40</td>
<td class=bc>15 - 0 - 4</td>
<td class=br><strong>30</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Vl Kraus</td><td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kW>4:1</td>
<td class=kL>5:8</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kW>7:4</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=br>70:45</td><td class=br>+25</td>
<td class=bc>14 - 0 - 5</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Mi Moravec</td><td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kL>2:5</td>
<td class=kW>5:1</td>
<td class=kW>8:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=br>58:34</td><td class=br>+24</td>
<td class=bc>14 - 0 - 5</td>
<td class=br><strong>28</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>An Šurýn</td><td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kT>1:1</td>
<td class=kT>5:5</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=br>56:40</td><td class=br>+16</td>
<td class=bc>10 - 5 - 4</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=d>5.</td><td class=kt>To Růžička</td><td class=kL>1:6</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>6:3</td>
<td class=kL>3:4</td>
<td class=kW>4:0</td>
<td class=br>66:42</td><td class=br>+24</td>
<td class=bc>10 - 4 - 5</td>
<td class=br><strong>24</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=d>6.</td><td class=kt>St Srba</td><td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kL>3:6</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kW>1:0</td>
<td class=kW>5:2</td>
<td class=br>52:40</td><td class=br>+12</td>
<td class=bc>10 - 3 - 6</td>
<td class=br><strong>23</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/4</td><td class=d>7.</td><td class=kt>Pe Holub</td><td class=kL>2:8</td>
<td class=kW>8:5</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>0:0</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=br>54:53</td><td class=br>+1</td>
<td class=bc>9 - 4 - 6</td>
<td class=br><strong>22</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/4</td><td class=d>8.</td><td class=kt>Os Tabara</td><td class=kL>4:5</td>
<td class=kW>4:1</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kW>5:4</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=br>49:44</td><td class=br>+5</td>
<td class=bc>10 - 1 - 8</td>
<td class=br><strong>21</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Ra Pommerenke</td><td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>0:1</td>
<td class=kT>0:0</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>6:5</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=br>46:47</td><td class=br>-1</td>
<td class=bc>9 - 2 - 8</td>
<td class=br><strong>20</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ro Hejda</td><td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kL>2:6</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=br>52:55</td><td class=br>-3</td>
<td class=bc>7 - 5 - 7</td>
<td class=br><strong>19</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Fr Rasche</td><td class=kL>4:6</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kW>6:2</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=br>61:62</td><td class=br>-1</td>
<td class=bc>8 - 3 - 8</td>
<td class=br><strong>19</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Vá Macek</td><td class=kW>7:4</td>
<td class=kL>3:5</td>
<td class=kL>2:8</td>
<td class=kT>1:1</td>
<td class=kL>3:6</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kW>4:0</td>
<td class=kW>8:2</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=br>61:57</td><td class=br>+4</td>
<td class=bc>8 - 2 - 9</td>
<td class=br><strong>18</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Mi Ševr</td><td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>5:5</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=br>50:52</td><td class=br>-2</td>
<td class=bc>7 - 4 - 8</td>
<td class=br><strong>18</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Mi Mašika</td><td class=kL>0:6</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=br>42:50</td><td class=br>-8</td>
<td class=bc>7 - 2 - 10</td>
<td class=br><strong>16</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Gu Gripp</td><td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=br>43:44</td><td class=br>-1</td>
<td class=bc>7 - 2 - 10</td>
<td class=br><strong>16</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Da Hrachovec</td><td class=kL>2:5</td>
<td class=kL>4:7</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=br>42:69</td><td class=br>-27</td>
<td class=bc>5 - 2 - 12</td>
<td class=br><strong>12</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ra Hrnčíř</td><td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>2:8</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=br>34:61</td><td class=br>-27</td>
<td class=bc>5 - 1 - 13</td>
<td class=br><strong>11</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Lu Holub</td><td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>5:6</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=br>43:62</td><td class=br>-19</td>
<td class=bc>4 - 3 - 12</td>
<td class=br><strong>11</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Hy Nechutný</td><td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kL>0:1</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=br>32:54</td><td class=br>-22</td>
<td class=bc>4 - 3 - 12</td>
<td class=br><strong>11</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Pe Klazar</td><td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=br>37:77</td><td class=br>-40</td>
<td class=bc>3 - 2 - 14</td>
<td class=br><strong>8</strong></td><td class=d>20.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Hrachovec Daniel</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Srba Stanislav</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pommerenke Ralph</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Holub Lukáš</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Hejda Roman</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Mašika Michal</td><td class=bc>-</td><td class=bl>Macek Václav</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Gripp Gunnar</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Klazar Petr</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Srba Stanislav</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Hrachovec Daniel</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Holub Lukáš</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Hejda Roman</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Macek Václav</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Rasche Frank</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mašika Michal</td><td class=bc>-</td><td class=bl>Gripp Gunnar</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Srba Stanislav</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Holub Petr</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Hrachovec Daniel</td><td class=bc>-</td><td class=bl>Holub Lukáš</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Hejda Roman</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Pommerenke Ralph</td><td class=bc>-</td><td class=bl>Macek Václav</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Tabara Oskar</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Gripp Gunnar</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Rasche Frank</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Srba Stanislav</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Holub Lukáš</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Hrachovec Daniel</td><td class=bc>-</td><td class=blW>Hejda Roman</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=bl>Macek Václav</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=blW>Tabara Oskar</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pommerenke Ralph</td><td class=bc>-</td><td class=bl>Gripp Gunnar</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>6 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Holub Petr</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Srba Stanislav</td><td class=bc>-</td><td class=blW>Holub Lukáš</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Hejda Roman</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Macek Václav</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Hrachovec Daniel</td><td class=bc>-</td><td class=blW>Tabara Oskar</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Gripp Gunnar</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Holub Lukáš</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Srba Stanislav</td><td class=bc>-</td><td class=bl>Hejda Roman</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Klazar Petr</td><td class=bc>-</td><td class=bl>Macek Václav</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Tabara Oskar</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Gripp Gunnar</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Hrachovec Daniel</td><td class=bc>-</td><td class=blW>Mašika Michal</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Hejda Roman</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Holub Petr</td><td class=bc>-</td><td class=bl>Macek Václav</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Srba Stanislav</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Gripp Gunnar</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Mašika Michal</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Rasche Frank</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Hrachovec Daniel</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Hejda Roman</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Macek Václav</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Holub Petr</td><td class=bc>-</td><td class=bl>Gripp Gunnar</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Srba Stanislav</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Rasche Frank</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Hrachovec Daniel</td><td class=bc>-</td><td class=blW>Pommerenke Ralph</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Hejda Roman</td><td class=bc>-</td><td class=bl>Macek Václav</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=bl>Gripp Gunnar</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Mašika Michal</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=blW>Rasche Frank</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Srba Stanislav</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kraus Vladimír</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Hrachovec Daniel</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Macek Václav</td><td class=bc>-</td><td class=bl>Tabara Oskar</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Hejda Roman</td><td class=bc>-</td><td class=blW>Gripp Gunnar</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Rasche Frank</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Srba Stanislav</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kraus Vladimír</td><td class=bc>-</td><td class=bl>Hrachovec Daniel</td><td class=bc>7 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Tabara Oskar</td><td class=bc>-</td><td class=bl>Mašika Michal</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Macek Václav</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Hejda Roman</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Pommerenke Ralph</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Nechutný Hynek</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Holub Petr</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Srba Stanislav</td><td class=bc>-</td><td class=bl>Hrachovec Daniel</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Hrnčíř Radek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Gripp Gunnar</td><td class=bc>-</td><td class=bl>Rasche Frank</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Macek Václav</td><td class=bc>-</td><td class=bl>Šurýn Antonín</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Hejda Roman</td><td class=bc>-</td><td class=blW>Pommerenke Ralph</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Holub Lukáš</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Hrachovec Daniel</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Holub Petr</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>8 : 5</tr></td>
<tr><td class=brW>Srba Stanislav</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Klazar Petr</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Plešák Pavel</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Gripp Gunnar</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Tabara Oskar</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Macek Václav</td><td class=bc>-</td><td class=blW>Růžička Tomáš</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Hejda Roman</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Hrachovec Daniel</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Srba Stanislav</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Šurýn Antonín</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Mašika Michal</td><td class=bc>-</td><td class=bl>Pommerenke Ralph</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Gripp Gunnar</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Tabara Oskar</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Macek Václav</td><td class=bc>-</td><td class=bl>Hrachovec Daniel</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Hejda Roman</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Holub Lukáš</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=blW>Srba Stanislav</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Holub Petr</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Pommerenke Ralph</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Ševr Miloš</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Gripp Gunnar</td><td class=bc>-</td><td class=bl>Hrachovec Daniel</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Tabara Oskar</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Macek Václav</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Hejda Roman</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Srba Stanislav</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=blW>Holub Petr</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Nechutný Hynek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Růžička Tomáš</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Hrachovec Daniel</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Mašika Michal</td><td class=bc>-</td><td class=bl>Kraus Vladimír</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Gripp Gunnar</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=blW>Klazar Petr</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Macek Václav</td><td class=bc>-</td><td class=bl>Srba Stanislav</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Hejda Roman</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Moravec Michael</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Holub Lukáš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Pommerenke Ralph</td><td class=bc>-</td><td class=bl>Ševr Miloš</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=blW>Hrachovec Daniel</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Plešák Pavel</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Rasche Frank</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Gripp Gunnar</td><td class=bc>-</td><td class=blW>Srba Stanislav</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=blW>Holub Petr</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Macek Václav</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Hejda Roman</td><td class=bc>-</td><td class=bl>Holub Lukáš</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Hrachovec Daniel</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Rasche Frank</td><td class=bc>-</td><td class=bl>Srba Stanislav</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Holub Petr</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Gripp Gunnar</td><td class=bc>-</td><td class=blW>Nechutný Hynek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Tabara Oskar</td><td class=bc>-</td><td class=bl>Holub Lukáš</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Macek Václav</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Hejda Roman</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Ševr Miloš</td><td class=bc>-</td><td class=blW>Kraus Vladimír</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Hrnčíř Radek</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Pommerenke Ralph</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Srba Stanislav</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=bl>Holub Lukáš</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Gripp Gunnar</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Tabara Oskar</td><td class=bc>-</td><td class=bl>Hejda Roman</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Macek Václav</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Hrachovec Daniel</td><td class=bc>-</td><td class=blW>Hrnčíř Radek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ševr Miloš</td><td class=bc>-</td><td class=bl>Klazar Petr</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Růžička Tomáš</td><td class=bc>-</td><td class=bl>Srba Stanislav</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pommerenke Ralph</td><td class=bc>-</td><td class=bl>Holub Petr</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Šurýn Antonín</td><td class=bc>-</td><td class=bl>Nechutný Hynek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Plešák Pavel</td><td class=bc>-</td><td class=bl>Holub Lukáš</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Rasche Frank</td><td class=bc>-</td><td class=blW>Moravec Michael</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mašika Michal</td><td class=bc>-</td><td class=blW>Hejda Roman</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Gripp Gunnar</td><td class=bc>-</td><td class=bl>Macek Václav</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Tabara Oskar</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Ví Pernica</td><td class=kx>*</td>
<td class=kW>5:2 + 0:0</td>
<td class=kW>2:0 + 4:4</td>
<td class=kW>5:1 + 3:6</td>
<td class=kW>3:1 + 5:1</td>
<td class=kL>2:4 + 5:4</td>
<td class=kT>4:4 + 6:2</td>
<td class=kW>5:4 + 5:1</td>
<td class=kW>3:2 + 5:3</td>
<td class=kW>1:0 + 1:1</td>
<td class=kT>4:4 + 6:3</td>
<td class=kW>6:1 + 7:5</td>
<td class=br>87:53</td><td class=br>+34</td>
<td class=bc>15 - 5 - 2</td>
<td class=br><strong>35</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Ja Medvec</td><td class=kL>2:5 + 0:0</td>
<td class=kx>*</td>
<td class=kL>1:2 + 2:2</td>
<td class=kW>4:3 + 0:5</td>
<td class=kW>4:3 + 4:0</td>
<td class=kL>1:3 + 2:1</td>
<td class=kW>4:0 + 3:2</td>
<td class=kW>5:3 + 4:0</td>
<td class=kW>7:2 + 2:0</td>
<td class=kW>3:2 + 6:3</td>
<td class=kW>4:2 + 7:2</td>
<td class=kW>9:2 + 7:3</td>
<td class=br>81:45</td><td class=br>+36</td>
<td class=bc>16 - 2 - 4</td>
<td class=br><strong>34</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Ol Tabara</td><td class=kL>0:2 + 4:4</td>
<td class=kW>2:1 + 2:2</td>
<td class=kx>*</td>
<td class=kW>5:2 + 1:3</td>
<td class=kT>2:2 + 2:1</td>
<td class=kT>0:0 + 6:0</td>
<td class=kW>3:2 + 3:4</td>
<td class=kW>7:3 + 7:0</td>
<td class=kW>2:1 + 6:3</td>
<td class=kW>2:1 + 1:1</td>
<td class=kW>3:1 + 7:1</td>
<td class=kW>3:1 + 4:3</td>
<td class=br>72:38</td><td class=br>+34</td>
<td class=bc>14 - 5 - 3</td>
<td class=br><strong>33</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Ja Ouřada</td><td class=kL>1:5 + 6:3</td>
<td class=kL>3:4 + 5:0</td>
<td class=kL>2:5 + 3:1</td>
<td class=kx>*</td>
<td class=kW>4:2 + 1:2</td>
<td class=kW>3:1 + 6:1</td>
<td class=kT>1:1 + 2:2</td>
<td class=kW>8:0 + 6:3</td>
<td class=kW>5:1 + 2:2</td>
<td class=kW>1:0 + 4:0</td>
<td class=kW>5:1 + 4:2</td>
<td class=kW>5:3 + 5:2</td>
<td class=br>82:41</td><td class=br>+41</td>
<td class=bc>15 - 3 - 4</td>
<td class=br><strong>33</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=d>5.</td><td class=kt>Ja Kopecký</td><td class=kL>1:3 + 1:5</td>
<td class=kL>3:4 + 0:4</td>
<td class=kT>2:2 + 1:2</td>
<td class=kL>2:4 + 2:1</td>
<td class=kx>*</td>
<td class=kW>3:1 + 1:5</td>
<td class=kL>1:2 + 2:1</td>
<td class=kW>3:2 + 5:1</td>
<td class=kW>3:0 + 5:3</td>
<td class=kW>5:1 + 3:2</td>
<td class=kW>3:0 + 3:1</td>
<td class=kW>5:3 + 3:0</td>
<td class=br>57:47</td><td class=br>+10</td>
<td class=bc>13 - 1 - 8</td>
<td class=br><strong>27</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=d>6.</td><td class=kt>Jo Gruncl</td><td class=kW>4:2 + 4:5</td>
<td class=kW>3:1 + 1:2</td>
<td class=kT>0:0 + 0:6</td>
<td class=kL>1:3 + 1:6</td>
<td class=kL>1:3 + 5:1</td>
<td class=kx>*</td>
<td class=kW>5:3 + 1:2</td>
<td class=kW>4:1 + 1:3</td>
<td class=kW>2:1 + 2:1</td>
<td class=kW>4:0 + 3:1</td>
<td class=kW>3:1 + 3:3</td>
<td class=kW>6:2 + 5:3</td>
<td class=br>59:50</td><td class=br>+9</td>
<td class=bc>12 - 2 - 8</td>
<td class=br><strong>26</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/4</td><td class=d>7.</td><td class=kt>Ma Moravec</td><td class=kT>4:4 + 2:6</td>
<td class=kL>0:4 + 2:3</td>
<td class=kL>2:3 + 4:3</td>
<td class=kT>1:1 + 2:2</td>
<td class=kW>2:1 + 1:2</td>
<td class=kL>3:5 + 2:1</td>
<td class=kx>*</td>
<td class=kW>5:2 + 5:2</td>
<td class=kT>2:2 + 2:4</td>
<td class=kW>2:0 + 1:3</td>
<td class=kW>2:0 + 3:2</td>
<td class=kW>4:1 + 4:2</td>
<td class=br>55:53</td><td class=br>+2</td>
<td class=bc>10 - 4 - 8</td>
<td class=br><strong>24</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/4</td><td class=d>8.</td><td class=kt>Ji Pošík</td><td class=kL>4:5 + 1:5</td>
<td class=kL>3:5 + 0:4</td>
<td class=kL>3:7 + 0:7</td>
<td class=kL>0:8 + 3:6</td>
<td class=kL>2:3 + 1:5</td>
<td class=kL>1:4 + 3:1</td>
<td class=kL>2:5 + 2:5</td>
<td class=kx>*</td>
<td class=kW>4:1 + 5:1</td>
<td class=kW>2:0 + 1:2</td>
<td class=kL>2:6 + 8:5</td>
<td class=kW>3:1 + 9:3</td>
<td class=br>59:89</td><td class=br>-30</td>
<td class=bc>7 - 0 - 15</td>
<td class=br><strong>14</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Ji Musil</td><td class=kL>2:3 + 3:5</td>
<td class=kL>2:7 + 0:2</td>
<td class=kL>1:2 + 3:6</td>
<td class=kL>1:5 + 2:2</td>
<td class=kL>0:3 + 3:5</td>
<td class=kL>1:2 + 1:2</td>
<td class=kT>2:2 + 4:2</td>
<td class=kL>1:4 + 1:5</td>
<td class=kx>*</td>
<td class=kW>3:1 + 4:1</td>
<td class=kW>4:2 + 1:6</td>
<td class=kW>3:1 + 5:0</td>
<td class=br>47:68</td><td class=br>-21</td>
<td class=bc>6 - 2 - 14</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Vo Pošík</td><td class=kL>0:1 + 1:1</td>
<td class=kL>2:3 + 3:6</td>
<td class=kL>1:2 + 1:1</td>
<td class=kL>0:1 + 0:4</td>
<td class=kL>1:5 + 2:3</td>
<td class=kL>0:4 + 1:3</td>
<td class=kL>0:2 + 3:1</td>
<td class=kL>0:2 + 2:1</td>
<td class=kL>1:3 + 1:4</td>
<td class=kx>*</td>
<td class=kW>4:2 + 5:1</td>
<td class=kW>3:0 + 7:2</td>
<td class=br>38:52</td><td class=br>-14</td>
<td class=bc>6 - 2 - 14</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Mi Horáková</td><td class=kT>4:4 + 3:6</td>
<td class=kL>2:4 + 2:7</td>
<td class=kL>1:3 + 1:7</td>
<td class=kL>1:5 + 2:4</td>
<td class=kL>0:3 + 1:3</td>
<td class=kL>1:3 + 3:3</td>
<td class=kL>0:2 + 2:3</td>
<td class=kW>6:2 + 5:8</td>
<td class=kL>2:4 + 6:1</td>
<td class=kL>2:4 + 1:5</td>
<td class=kx>*</td>
<td class=kW>7:2 + 6:2</td>
<td class=br>58:85</td><td class=br>-27</td>
<td class=bc>4 - 2 - 16</td>
<td class=br><strong>10</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>To Urban</td><td class=kL>1:6 + 5:7</td>
<td class=kL>2:9 + 3:7</td>
<td class=kL>1:3 + 3:4</td>
<td class=kL>3:5 + 2:5</td>
<td class=kL>3:5 + 0:3</td>
<td class=kL>2:6 + 3:5</td>
<td class=kL>1:4 + 2:4</td>
<td class=kL>1:3 + 3:9</td>
<td class=kL>1:3 + 0:5</td>
<td class=kL>0:3 + 2:7</td>
<td class=kL>2:7 + 2:6</td>
<td class=kx>*</td>
<td class=br>42:116</td><td class=br>-74</td>
<td class=bc>0 - 0 - 22</td>
<td class=br><strong>0</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Medvec Jan</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>5 : 3 + 4 : 0</tr></td>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>6 : 1 + 7 : 5</tr></td>
<tr><td class=br>Kopecký Jaroslav</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>1 : 2 + 2 : 1</tr></td>
<tr><td class=br>Musil Jindřich</td><td class=bc>-</td><td class=blW>Ouřada Jaroslav</td><td class=bc>1 : 5 + 2 : 2</tr></td>
<tr><td class=brW>Tabara Oliver</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>2 : 1 + 1 : 1</tr></td>
<tr><td class=brW>Gruncl Josef</td><td class=bc>-</td><td class=bl>Horáková Miroslava</td><td class=bc>3 : 1 + 3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Pošík Jiří</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>3 : 1 + 9 : 3</tr></td>
<tr><td class=brW>Medvec Jan</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>4 : 0 + 3 : 2</tr></td>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Ouřada Jaroslav</td><td class=bc>5 : 1 + 3 : 6</tr></td>
<tr><td class=brW>Kopecký Jaroslav</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>5 : 1 + 3 : 2</tr></td>
<tr><td class=brW>Musil Jindřich</td><td class=bc>-</td><td class=bl>Horáková Miroslava</td><td class=bc>4 : 2 + 1 : 6</tr></td>
<tr><td class=br>Tabara Oliver</td><td class=bc>-</td><td class=bl>Gruncl Josef</td><td class=bc>0 : 0 + 6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>1 : 4 + 2 : 4</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Ouřada Jaroslav</td><td class=bc>0 : 8 + 3 : 6</tr></td>
<tr><td class=brW>Medvec Jan</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>3 : 2 + 6 : 3</tr></td>
<tr><td class=br>Pernica Vít</td><td class=bc>-</td><td class=bl>Horáková Miroslava</td><td class=bc>4 : 4 + 6 : 3</tr></td>
<tr><td class=brW>Kopecký Jaroslav</td><td class=bc>-</td><td class=bl>Gruncl Josef</td><td class=bc>3 : 1 + 1 : 5</tr></td>
<tr><td class=br>Musil Jindřich</td><td class=bc>-</td><td class=blW>Tabara Oliver</td><td class=bc>1 : 2 + 3 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=bl>Ouřada Jaroslav</td><td class=bc>1 : 1 + 2 : 2</tr></td>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=blW>Pošík Vojtěch</td><td class=bc>0 : 3 + 2 : 7</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Horáková Miroslava</td><td class=bc>2 : 6 + 8 : 5</tr></td>
<tr><td class=br>Medvec Jan</td><td class=bc>-</td><td class=blW>Gruncl Josef</td><td class=bc>1 : 3 + 2 : 1</tr></td>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Tabara Oliver</td><td class=bc>2 : 0 + 4 : 4</tr></td>
<tr><td class=brW>Kopecký Jaroslav</td><td class=bc>-</td><td class=bl>Musil Jindřich</td><td class=bc>3 : 0 + 5 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ouřada Jaroslav</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>1 : 0 + 4 : 0</tr></td>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Horáková Miroslava</td><td class=bc>2 : 0 + 3 : 2</tr></td>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=blW>Gruncl Josef</td><td class=bc>2 : 6 + 3 : 5</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Tabara Oliver</td><td class=bc>3 : 7 + 0 : 7</tr></td>
<tr><td class=brW>Medvec Jan</td><td class=bc>-</td><td class=bl>Musil Jindřich</td><td class=bc>7 : 2 + 2 : 0</tr></td>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Kopecký Jaroslav</td><td class=bc>3 : 1 + 5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Pošík Vojtěch</td><td class=bc>-</td><td class=bl>Horáková Miroslava</td><td class=bc>4 : 2 + 5 : 1</tr></td>
<tr><td class=brW>Ouřada Jaroslav</td><td class=bc>-</td><td class=bl>Gruncl Josef</td><td class=bc>3 : 1 + 6 : 1</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=blW>Tabara Oliver</td><td class=bc>2 : 3 + 4 : 3</tr></td>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=blW>Musil Jindřich</td><td class=bc>1 : 3 + 0 : 5</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=blW>Kopecký Jaroslav</td><td class=bc>2 : 3 + 1 : 5</tr></td>
<tr><td class=br>Medvec Jan</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>2 : 5 + 0 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Horáková Miroslava</td><td class=bc>-</td><td class=blW>Tabara Oliver</td><td class=bc>1 : 3 + 1 : 7</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Musil Jindřich</td><td class=bc>1 : 3 + 1 : 4</tr></td>
<tr><td class=brW>Ouřada Jaroslav</td><td class=bc>-</td><td class=bl>Kopecký Jaroslav</td><td class=bc>4 : 2 + 1 : 2</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>4 : 4+ 2 : 6</tr></td>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=blW>Medvec Jan</td><td class=bc>2 : 9 + 3 : 7</tr></td>
<tr><td class=br>Pošík Jiří</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Gruncl Josef</td><td class=bc>-</td><td class=bl>Musil Jindřich</td><td class=bc>2 : 1 + 2 : 1</tr></td>
<tr><td class=br>Horáková Miroslava</td><td class=bc>-</td><td class=blW>Kopecký Jaroslav</td><td class=bc>0 : 3 + 1 : 3</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>0 : 1 + 1 : 1</tr></td>
<tr><td class=br>Ouřada Jaroslav</td><td class=bc>-</td><td class=blW>Medvec Jan</td><td class=bc>3 : 4 + 5 : 0</tr></td>
<tr><td class=brW>Moravec Martin</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>5 : 2 + 5 : 2</tr></td>
<tr><td class=br>Urban Tomáš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Tabara Oliver</td><td class=bc>-</td><td class=bl>Kopecký Jaroslav</td><td class=bc>2 : 2 + 2 : 1</tr></td>
<tr><td class=brW>Gruncl Josef</td><td class=bc>-</td><td class=bl>Pernica Vít</td><td class=bc>4 : 2 + 4 : 5</tr></td>
<tr><td class=br>Horáková Miroslava</td><td class=bc>-</td><td class=blW>Medvec Jan</td><td class=bc>2 : 4 + 2 : 7</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Pošík Jiří</td><td class=bc>0 : 2 + 2 : 1</tr></td>
<tr><td class=brW>Ouřada Jaroslav</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>5 : 3 + 5 : 2</tr></td>
<tr><td class=br>Moravec Martin</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Musil Jindřich</td><td class=bc>-</td><td class=blW>Pernica Vít</td><td class=bc>2 : 3 + 3 : 5</tr></td>
<tr><td class=brW>Tabara Oliver</td><td class=bc>-</td><td class=bl>Medvec Jan</td><td class=bc>2 : 1 + 2 : 2</tr></td>
<tr><td class=brW>Gruncl Josef</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>4 : 1 + 1 : 3</tr></td>
<tr><td class=brW>Horáková Miroslava</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>7 : 2  + 6 : 2</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=blW>Moravec Martin</td><td class=bc>0 : 2 + 3 : 1</tr></td>
<tr><td class=br>Ouřada Jaroslav</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Kopecký Jaroslav</td><td class=bc>-</td><td class=blW>Medvec Jan</td><td class=bc>3 : 4 + 0 : 4</tr></td>
<tr><td class=br>Musil Jindřich</td><td class=bc>-</td><td class=blW>Pošík Jiří</td><td class=bc>1 : 4 + 1 : 5</tr></td>
<tr><td class=brW>Tabara Oliver</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>3 : 1 + 4 : 3</tr></td>
<tr><td class=brW>Gruncl Josef</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>5 : 3 + 1 : 2</tr></td>
<tr><td class=br>Horáková Miroslava</td><td class=bc>-</td><td class=blW>Ouřada Jaroslav</td><td class=bc>1 : 5 + 2 : 4</tr></td>
<tr><td class=br>Pošík Vojtěch</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Pernica Vít</td><td class=bc>-</td><td class=bl>Pošík Jiří</td><td class=bc>5 : 4 + 5 : 1</tr></td>
<tr><td class=brW>Kopecký Jaroslav</td><td class=bc>-</td><td class=bl>Urban Tomáš</td><td class=bc>5 : 3 + 3 : 0</tr></td>
<tr><td class=br>Musil Jindřich</td><td class=bc>-</td><td class=bl>Moravec Martin</td><td class=bc>2 : 2 + 4 : 2</tr></td>
<tr><td class=brW>Tabara Oliver</td><td class=bc>-</td><td class=bl>Ouřada Jaroslav</td><td class=bc>5 : 2 + 1 : 3</tr></td>
<tr><td class=brW>Gruncl Josef</td><td class=bc>-</td><td class=bl>Pošík Vojtěch</td><td class=bc>4 : 0 + 3 : 1</tr></td>
<tr><td class=br>Horáková Miroslava</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group D</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Ma Musil</td><td class=kx>*</td>
<td class=kT>1:1 + 4:1</td>
<td class=kW>6:1 + 7:1</td>
<td class=kW>5:0 + 8:2</td>
<td class=kW>6:0 + 9:1</td>
<td class=kW>4:1 + 6:1</td>
<td class=kW>4:2 + 8:0</td>
<td class=kW>8:1 + 7:0</td>
<td class=kW>6:0 + 6:0</td>
<td class=kW>7:1 + 8:0</td>
<td class=br>110:13</td><td class=br>+97</td>
<td class=bc>17 - 1 - 0</td>
<td class=br><strong>35</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Pa Janouškovec</td><td class=kT>1:1 + 1:4</td>
<td class=kx>*</td>
<td class=kW>2:1 + 4:1</td>
<td class=kW>4:3 + 4:0</td>
<td class=kW>6:1 + 4:1</td>
<td class=kW>6:1 + 3:1</td>
<td class=kW>1:0 + 3:1</td>
<td class=kW>8:0 + 5:0</td>
<td class=kW>3:0 + 3:0</td>
<td class=kW>6:0 + 4:0</td>
<td class=br>68:15</td><td class=br>+53</td>
<td class=bc>16 - 1 - 1</td>
<td class=br><strong>33</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Vá Macek ml.</td><td class=kL>1:6 + 1:7</td>
<td class=kL>1:2 + 1:4</td>
<td class=kx>*</td>
<td class=kW>2:1 + 1:1</td>
<td class=kW>2:0 + 3:3</td>
<td class=kW>1:0 + 3:2</td>
<td class=kL>0:1 + 3:0</td>
<td class=kW>2:1 + 4:3</td>
<td class=kW>2:1 + 2:0</td>
<td class=kW>3:0 + 2:0</td>
<td class=br>34:32</td><td class=br>+2</td>
<td class=bc>11 - 2 - 5</td>
<td class=br><strong>24</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Ja Kubica</td><td class=kL>0:5 + 2:8</td>
<td class=kL>3:4 + 0:4</td>
<td class=kL>1:2 + 1:1</td>
<td class=kx>*</td>
<td class=kW>3:1 + 2:1</td>
<td class=kW>2:0 + 1:2</td>
<td class=kW>3:1 + 3:0</td>
<td class=kW>4:1 + 2:0</td>
<td class=kW>3:1 + 3:0</td>
<td class=kT>3:3 + 1:0</td>
<td class=br>37:34</td><td class=br>+3</td>
<td class=bc>10 - 2 - 6</td>
<td class=br><strong>22</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=d>5.</td><td class=kt>Mi Matuštík</td><td class=kL>0:6 + 1:9</td>
<td class=kL>1:6 + 1:4</td>
<td class=kL>0:2 + 3:3</td>
<td class=kL>1:3 + 1:2</td>
<td class=kx>*</td>
<td class=kL>2:3 + 3:1</td>
<td class=kW>3:2 + 4:1</td>
<td class=kW>3:1 + 4:1</td>
<td class=kW>6:0 + 2:0</td>
<td class=kW>4:1 + 6:1</td>
<td class=br>45:46</td><td class=br>-1</td>
<td class=bc>9 - 1 - 8</td>
<td class=br><strong>19</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=d>6.</td><td class=kt>Ro Hašek</td><td class=kL>1:4 + 1:6</td>
<td class=kL>1:6 + 1:3</td>
<td class=kL>0:1 + 2:3</td>
<td class=kL>0:2 + 2:1</td>
<td class=kW>3:2 + 1:3</td>
<td class=kx>*</td>
<td class=kW>3:0 + 4:0</td>
<td class=kW>7:1 + 3:1</td>
<td class=kW>3:1 + 3:3</td>
<td class=kW>3:0 + 7:2</td>
<td class=br>45:39</td><td class=br>+6</td>
<td class=bc>9 - 1 - 8</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/4</td><td class=d>7.</td><td class=kt>Vo Hampejs</td><td class=kL>2:4 + 0:8</td>
<td class=kL>0:1 + 1:3</td>
<td class=kW>1:0 + 0:3</td>
<td class=kL>1:3 + 0:3</td>
<td class=kL>2:3 + 1:4</td>
<td class=kL>0:3 + 0:4</td>
<td class=kx>*</td>
<td class=kT>0:0 + 4:1</td>
<td class=kW>4:1 + 1:1</td>
<td class=kL>2:3 + 2:0</td>
<td class=br>21:45</td><td class=br>-24</td>
<td class=bc>4 - 2 - 12</td>
<td class=br><strong>10</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/4</td><td class=d>8.</td><td class=kt>Ro Kubinec</td><td class=kL>1:8 + 0:7</td>
<td class=kL>0:8 + 0:5</td>
<td class=kL>1:2 + 3:4</td>
<td class=kL>1:4 + 0:2</td>
<td class=kL>1:3 + 1:4</td>
<td class=kL>1:7 + 1:3</td>
<td class=kT>0:0 + 1:4</td>
<td class=kx>*</td>
<td class=kL>0:2 + 1:0</td>
<td class=kW>5:2 + 0:0</td>
<td class=br>17:65</td><td class=br>-48</td>
<td class=bc>2 - 2 - 14</td>
<td class=br><strong>6</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Jo Staněk</td><td class=kL>0:6 + 0:6</td>
<td class=kL>0:3 + 0:3</td>
<td class=kL>1:2 + 0:2</td>
<td class=kL>1:3 + 0:3</td>
<td class=kL>0:6 + 0:2</td>
<td class=kL>1:3 + 3:3</td>
<td class=kL>1:4 + 1:1</td>
<td class=kW>2:0 + 0:1</td>
<td class=kx>*</td>
<td class=kL>0:2 + 1:0</td>
<td class=br>11:50</td><td class=br>-39</td>
<td class=bc>2 - 2 - 14</td>
<td class=br><strong>6</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ma Vích</td><td class=kL>1:7 + 0:8</td>
<td class=kL>0:6 + 0:4</td>
<td class=kL>0:3 + 0:2</td>
<td class=kT>3:3 + 0:1</td>
<td class=kL>1:4 + 1:6</td>
<td class=kL>0:3 + 2:7</td>
<td class=kW>3:2 + 0:2</td>
<td class=kL>2:5 + 0:0</td>
<td class=kW>2:0 + 0:1</td>
<td class=kx>*</td>
<td class=br>15:64</td><td class=br>-49</td>
<td class=bc>2 - 2 - 14</td>
<td class=br><strong>6</strong></td><td class=d>10.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Musil Martin</td><td class=bc>-</td><td class=bl>Vích Matyáš</td><td class=bc>7 : 1 + 8 : 0</tr></td>
<tr><td class=br>Macek ml. Václav</td><td class=bc>-</td><td class=blW>Hampejs Vojtěch</td><td class=bc>0 : 1 + 3 : 0</tr></td>
<tr><td class=brW>Hašek Roman</td><td class=bc>-</td><td class=bl>Staněk Josef</td><td class=bc>3 : 1 + 3 : 3</tr></td>
<tr><td class=brW>Kubica Jan</td><td class=bc>-</td><td class=bl>Kubinec Roman</td><td class=bc>4 : 1 + 2 : 0</tr></td>
<tr><td class=brW>Janouškovec Pavel</td><td class=bc>-</td><td class=bl>Matuštík Milan</td><td class=bc>6 : 1 + 4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Vích Matyáš</td><td class=bc>-</td><td class=bl>Hampejs Vojtěch</td><td class=bc>3 : 2 + 0 : 2</tr></td>
<tr><td class=brW>Musil Martin</td><td class=bc>-</td><td class=bl>Staněk Josef</td><td class=bc>6 : 0 + 6 : 0</tr></td>
<tr><td class=brW>Macek ml. Václav</td><td class=bc>-</td><td class=bl>Kubinec Roman</td><td class=bc>2 : 1 + 4 : 3</tr></td>
<tr><td class=brW>Hašek Roman</td><td class=bc>-</td><td class=bl>Matuštík Milan</td><td class=bc>3 : 2 + 1 : 3</tr></td>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=blW>Janouškovec Pavel</td><td class=bc>3 : 4 + 0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Hampejs Vojtěch</td><td class=bc>-</td><td class=bl>Staněk Josef</td><td class=bc>4 : 1 + 1 : 1</tr></td>
<tr><td class=br>Vích Matyáš</td><td class=bc>-</td><td class=blW>Kubinec Roman</td><td class=bc>2 : 5 + 0 : 0</tr></td>
<tr><td class=brW>Musil Martin</td><td class=bc>-</td><td class=bl>Matuštík Milan</td><td class=bc>6 : 0 + 9 : 1</tr></td>
<tr><td class=br>Macek ml. Václav</td><td class=bc>-</td><td class=blW>Janouškovec Pavel</td><td class=bc>1 : 2 + 1 : 4</tr></td>
<tr><td class=br>Hašek Roman</td><td class=bc>-</td><td class=blW>Kubica Jan</td><td class=bc>0 : 2 + 2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Staněk Josef</td><td class=bc>-</td><td class=bl>Kubinec Roman</td><td class=bc>2 : 0 + 0 : 1</tr></td>
<tr><td class=br>Hampejs Vojtěch</td><td class=bc>-</td><td class=blW>Matuštík Milan</td><td class=bc>2 : 3 + 1 : 4</tr></td>
<tr><td class=br>Vích Matyáš</td><td class=bc>-</td><td class=blW>Janouškovec Pavel</td><td class=bc>0 : 6 + 0 : 4</tr></td>
<tr><td class=brW>Musil Martin</td><td class=bc>-</td><td class=bl>Kubica Jan</td><td class=bc>5 : 0 + 8 : 2</tr></td>
<tr><td class=brW>Macek ml. Václav</td><td class=bc>-</td><td class=bl>Hašek Roman</td><td class=bc>1 : 0 + 3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Kubinec Roman</td><td class=bc>-</td><td class=blW>Matuštík Milan</td><td class=bc>1 : 3 + 1 : 4</tr></td>
<tr><td class=br>Staněk Josef</td><td class=bc>-</td><td class=blW>Janouškovec Pavel</td><td class=bc>0 : 3 + 0 : 3</tr></td>
<tr><td class=br>Hampejs Vojtěch</td><td class=bc>-</td><td class=blW>Kubica Jan</td><td class=bc>1 : 3 + 0 : 3</tr></td>
<tr><td class=br>Vích Matyáš</td><td class=bc>-</td><td class=blW>Hašek Roman</td><td class=bc>0 : 3 + 2 : 7</tr></td>
<tr><td class=brW>Musil Martin</td><td class=bc>-</td><td class=bl>Macek ml. Václav</td><td class=bc>6 : 1 + 7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Matuštík Milan</td><td class=bc>-</td><td class=blW>Kubica Jan</td><td class=bc>1 : 3 + 1 : 2</tr></td>
<tr><td class=br>Kubinec Roman</td><td class=bc>-</td><td class=blW>Hašek Roman</td><td class=bc>1 : 7 + 1 : 3</tr></td>
<tr><td class=br>Staněk Josef</td><td class=bc>-</td><td class=blW>Macek ml. Václav</td><td class=bc>1 : 2 + 0 : 2</tr></td>
<tr><td class=br>Hampejs Vojtěch</td><td class=bc>-</td><td class=blW>Musil Martin</td><td class=bc>2 : 4 + 0 : 8</tr></td>
<tr><td class=br>Vích Matyáš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Janouškovec Pavel</td><td class=bc>-</td><td class=bl>Hašek Roman</td><td class=bc>6 : 1 + 3 : 1</tr></td>
<tr><td class=br>Matuštík Milan</td><td class=bc>-</td><td class=blW>Macek ml. Václav</td><td class=bc>0 : 2 + 3 : 3</tr></td>
<tr><td class=br>Kubinec Roman</td><td class=bc>-</td><td class=blW>Musil Martin</td><td class=bc>1 : 8 + 0 : 7</tr></td>
<tr><td class=br>Staněk Josef</td><td class=bc>-</td><td class=blW>Vích Matyáš</td><td class=bc>0 : 2 + 1 : 0</tr></td>
<tr><td class=br>Hampejs Vojtěch</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=blW>Macek ml. Václav</td><td class=bc>1 : 2 + 1 : 1</tr></td>
<tr><td class=br>Janouškovec Pavel</td><td class=bc>-</td><td class=bl>Musil Martin</td><td class=bc>1 : 1 + 1 : 4</tr></td>
<tr><td class=brW>Matuštík Milan</td><td class=bc>-</td><td class=bl>Vích Matyáš</td><td class=bc>4 : 1 + 6 : 1</tr></td>
<tr><td class=br>Kubinec Roman</td><td class=bc>-</td><td class=bl>Hampejs Vojtěch</td><td class=bc>0 : 0+ 1 : 4</tr></td>
<tr><td class=br>Staněk Josef</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Hašek Roman</td><td class=bc>-</td><td class=blW>Musil Martin</td><td class=bc>1 : 4 + 1 : 6</tr></td>
<tr><td class=br>Kubica Jan</td><td class=bc>-</td><td class=bl>Vích Matyáš</td><td class=bc>3 : 3 + 1 : 0</tr></td>
<tr><td class=brW>Janouškovec Pavel</td><td class=bc>-</td><td class=bl>Hampejs Vojtěch</td><td class=bc>1 : 0 + 3 : 1</tr></td>
<tr><td class=brW>Matuštík Milan</td><td class=bc>-</td><td class=bl>Staněk Josef</td><td class=bc>6 : 0 + 2 : 0</tr></td>
<tr><td class=br>Kubinec Roman</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Macek ml. Václav</td><td class=bc>-</td><td class=bl>Vích Matyáš</td><td class=bc>3 : 0 + 2 : 0</tr></td>
<tr><td class=brW>Hašek Roman</td><td class=bc>-</td><td class=bl>Hampejs Vojtěch</td><td class=bc>3 : 0 + 4 : 0</tr></td>
<tr><td class=brW>Kubica Jan</td><td class=bc>-</td><td class=bl>Staněk Josef</td><td class=bc>3 : 1 + 3 : 0</tr></td>
<tr><td class=brW>Janouškovec Pavel</td><td class=bc>-</td><td class=bl>Kubinec Roman</td><td class=bc>8 : 0 + 5 : 0</tr></td>
<tr><td class=br>Matuštík Milan</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
