<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Plzeň</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Plzeň, 13. květen 2023</span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Základní skupiny (Basic groups)</a><br>
<a href="#final">Výkonnostní skupiny (Final groups)</a><br>
<a name="basic"><p class=vm>Základní skupiny (Basic groups)</p></a>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=101&x=-391&p=Mi%20Kubica">Mi Kubica</a></td><td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kL>0:4</td>
<td class=kW>5:4</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>4:3</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>8:0</td>
<td class=kW>2:0</td>
<td class=kW>8:1</td>
<td class=kW>4:0</td>
<td class=br>75:32</td><td class=br>+43</td>
<td class=bc>14 - 1 - 2</td>
<td class=br><strong>29</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=818&x=-391&p=Ro%20Je%C5%BE">Ro Jež</a></td><td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=br>61:32</td><td class=br>+29</td>
<td class=bc>14 - 0 - 3</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=567&x=-391&p=Kr%20Lebl">Kr Lebl</a></td><td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kW>8:1</td>
<td class=kW>4:2</td>
<td class=kL>4:5</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=kW>7:0</td>
<td class=br>73:29</td><td class=br>+44</td>
<td class=bc>13 - 1 - 3</td>
<td class=br><strong>27</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=993&x=-391&p=Ji%20Chyl%C3%ADk%20ml.">Ji Chylík ml.</a></td><td class=kL>4:5</td>
<td class=kW>4:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kW>5:3</td>
<td class=kW>8:0</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>8:5</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>6:3</td>
<td class=br>80:38</td><td class=br>+42</td>
<td class=bc>13 - 1 - 3</td>
<td class=br><strong>27</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1251&x=-391&p=Ho%20Sl%C3%A1dek">Ho Sládek</a></td><td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>7:3</td>
<td class=kW>6:0</td>
<td class=br>62:36</td><td class=br>+26</td>
<td class=bc>11 - 3 - 3</td>
<td class=br><strong>25</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=248&x=-391&p=Ma%20%C5%BDen%C3%AD%C5%A1ek">Ma Ženíšek</a></td><td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kL>4:5</td>
<td class=kL>4:6</td>
<td class=kW>8:2</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>9:1</td>
<td class=br>73:36</td><td class=br>+37</td>
<td class=bc>12 - 1 - 4</td>
<td class=br><strong>25</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=4&x=-391&p=Vl%20Kraus">Vl Kraus</a></td><td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>1:8</td>
<td class=kW>5:4</td>
<td class=kW>4:0</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kW>7:4</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>3:0</td>
<td class=br>54:34</td><td class=br>+20</td>
<td class=bc>10 - 3 - 4</td>
<td class=br><strong>23</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=26&x=-391&p=Mi%20%C5%A0evr">Mi Ševr</a></td><td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>10:1</td>
<td class=kW>1:0</td>
<td class=kW>8:1</td>
<td class=kW>5:0</td>
<td class=br>55:35</td><td class=br>+20</td>
<td class=bc>7 - 4 - 6</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=176&x=-391&p=Zd%20Lopaur">Zd Lopaur</a></td><td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>5:4</td>
<td class=kL>0:8</td>
<td class=kL>1:6</td>
<td class=kW>5:4</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>3:5</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>8:3</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>7:1</td>
<td class=br>57:59</td><td class=br>-2</td>
<td class=bc>8 - 2 - 7</td>
<td class=br><strong>18</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1630&x=-391&p=Pe%20Holub">Pe Holub</a></td><td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kW>6:4</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=br>51:45</td><td class=br>+6</td>
<td class=bc>6 - 5 - 6</td>
<td class=br><strong>17</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1117&x=-391&p=To%20Kahoun%20ml.">To Kahoun ml.</a></td><td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>2:8</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>7:0</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=br>46:51</td><td class=br>-5</td>
<td class=bc>7 - 1 - 9</td>
<td class=br><strong>15</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1968&x=-391&p=Mi%20Tou%C5%A1">Mi Touš</a></td><td class=kL>3:7</td>
<td class=kL>2:7</td>
<td class=kL>1:7</td>
<td class=kL>5:8</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>4:7</td>
<td class=kL>0:2</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>4:7</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=br>51:72</td><td class=br>-21</td>
<td class=bc>6 - 1 - 10</td>
<td class=br><strong>13</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1639&x=-391&p=Ja%20Ou%C5%99ada">Ja Ouřada</a></td><td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kL>0:7</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=br>39:47</td><td class=br>-8</td>
<td class=bc>5 - 3 - 9</td>
<td class=br><strong>13</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>B</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1927&x=-391&p=Vo%20Kraus">Vo Kraus</a></td><td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=br>45:54</td><td class=br>-9</td>
<td class=bc>4 - 4 - 9</td>
<td class=br><strong>12</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1896&x=-391&p=Ra%20Hrn%C4%8D%C3%AD%C5%99">Ra Hrnčíř</a></td><td class=kL>0:8</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>1:10</td>
<td class=kL>3:8</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kW>7:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=br>33:77</td><td class=br>-44</td>
<td class=bc>4 - 0 - 13</td>
<td class=br><strong>8</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>C</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1076&x=-391&p=Mi%20Zeman">Mi Zeman</a></td><td class=kL>0:2</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=br>19:68</td><td class=br>-49</td>
<td class=bc>2 - 0 - 15</td>
<td class=br><strong>4</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>C</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1947&x=-391&p=Lu%20Holub">Lu Holub</a></td><td class=kL>1:8</td>
<td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kL>3:4</td>
<td class=kL>3:7</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kL>1:8</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=br>30:81</td><td class=br>-51</td>
<td class=bc>0 - 3 - 14</td>
<td class=br><strong>3</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>C</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2021&x=-391&p=Kr%20Novotn%C3%BD">Kr Novotný</a></td><td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>3:6</td>
<td class=kL>0:6</td>
<td class=kL>1:9</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=br>10:88</td><td class=br>-78</td>
<td class=bc>0 - 1 - 16</td>
<td class=br><strong>1</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ja Ouřada</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Kr Novotný</td><td class=bc>-</td><td class=blW>Ja Ouřada</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kr Novotný</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Mi Touš</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kr Novotný</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Mi Touš</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kr Novotný</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Vo Kraus</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>8 : 5</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Kr Novotný</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Vo Kraus</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kr Novotný</td><td class=bc>-</td><td class=blW>Vo Kraus</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kr Novotný</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kr Novotný</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ja Ouřada</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Mi Touš</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Touš</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Vo Kraus</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Mi Touš</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Ja Ouřada</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Mi Touš</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=blW>Ja Ouřada</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>0 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1477&x=-391&p=Mi%20Kobrle">Mi Kobrle</a></td><td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>6:5</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>9:4</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>10:1</td>
<td class=kW>6:3</td>
<td class=kW>8:2</td>
<td class=kW>9:2</td>
<td class=kW>8:0</td>
<td class=kW>8:0</td>
<td class=br>106:29</td><td class=br>+77</td>
<td class=bc>16 - 1 - 0</td>
<td class=br><strong>33</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=386&x=-391&p=Ku%20Sl%C3%A1dek">Ku Sládek</a></td><td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=br>65:25</td><td class=br>+40</td>
<td class=bc>14 - 0 - 3</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=310&x=-391&p=Mi%20%C4%8Cernoch">Mi Černoch</a></td><td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>13:0</td>
<td class=kW>7:1</td>
<td class=kW>9:0</td>
<td class=kW>7:1</td>
<td class=kW>8:0</td>
<td class=kW>5:0</td>
<td class=br>82:13</td><td class=br>+69</td>
<td class=bc>13 - 2 - 2</td>
<td class=br><strong>28</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1065&x=-391&p=Kr%20Herold">Kr Herold</a></td><td class=kL>5:6</td>
<td class=kW>3:1</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=br>67:32</td><td class=br>+35</td>
<td class=bc>13 - 1 - 3</td>
<td class=br><strong>27</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=53&x=-391&p=V%C3%A1%20Pikl">Vá Pikl</a></td><td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>9:2</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=kW>7:2</td>
<td class=kW>8:0</td>
<td class=kW>7:0</td>
<td class=br>72:36</td><td class=br>+36</td>
<td class=bc>10 - 3 - 4</td>
<td class=br><strong>23</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1872&x=-391&p=Pe%20Fuchs">Pe Fuchs</a></td><td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>8:0</td>
<td class=kL>2:3</td>
<td class=kW>6:0</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=br>60:32</td><td class=br>+28</td>
<td class=bc>11 - 0 - 6</td>
<td class=br><strong>22</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1940&x=-391&p=Ma%20Ko%C5%A1%C5%88ar">Ma Košňar</a></td><td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>5:4</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=br>51:42</td><td class=br>+9</td>
<td class=bc>9 - 1 - 7</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=89&x=-391&p=Jo%20Gruncl">Jo Gruncl</a></td><td class=kL>4:9</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>6:3</td>
<td class=br>48:55</td><td class=br>-7</td>
<td class=bc>7 - 4 - 6</td>
<td class=br><strong>18</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=18&x=-391&p=An%20%C5%A0ur%C3%BDn">An Šurýn</a></td><td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kT>6:6</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=br>51:42</td><td class=br>+9</td>
<td class=bc>8 - 2 - 7</td>
<td class=br><strong>18</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=70&x=-391&p=St%20Srba">St Srba</a></td><td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>8:0</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=br>48:43</td><td class=br>+5</td>
<td class=bc>8 - 2 - 7</td>
<td class=br><strong>18</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=318&x=-391&p=Ji%20V%C3%A1cha">Ji Vácha</a></td><td class=kL>0:5</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>0:1</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=kW>5:0</td>
<td class=kW>8:1</td>
<td class=kW>6:0</td>
<td class=br>63:43</td><td class=br>+20</td>
<td class=bc>7 - 3 - 7</td>
<td class=br><strong>17</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1058&x=-391&p=Fr%20Marek">Fr Marek</a></td><td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=br>43:47</td><td class=br>-4</td>
<td class=bc>7 - 1 - 9</td>
<td class=br><strong>15</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=10&x=-391&p=Ja%20Medvec">Ja Medvec</a></td><td class=kL>1:10</td>
<td class=kL>0:8</td>
<td class=kL>0:13</td>
<td class=kL>0:6</td>
<td class=kL>2:9</td>
<td class=kL>0:8</td>
<td class=kL>4:5</td>
<td class=kL>1:3</td>
<td class=kT>6:6</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=br>50:86</td><td class=br>-36</td>
<td class=bc>5 - 3 - 9</td>
<td class=br><strong>13</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>B</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=41&x=-391&p=Da%20Hrachovec">Da Hrachovec</a></td><td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=br>41:58</td><td class=br>-17</td>
<td class=bc>6 - 1 - 10</td>
<td class=br><strong>13</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2018&x=-391&p=Ja%20Janou%C5%A1kovec">Ja Janouškovec</a></td><td class=kL>2:8</td>
<td class=kL>1:4</td>
<td class=kL>0:9</td>
<td class=kL>2:6</td>
<td class=kL>0:8</td>
<td class=kL>0:6</td>
<td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>0:8</td>
<td class=kL>0:8</td>
<td class=kL>3:5</td>
<td class=kL>3:6</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=kW>7:0</td>
<td class=br>35:89</td><td class=br>-54</td>
<td class=bc>3 - 0 - 14</td>
<td class=br><strong>6</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>C</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1999&x=-391&p=Fi%20Pano%C5%A1">Fi Panoš</a></td><td class=kL>2:9</td>
<td class=kL>2:6</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>2:7</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>29:77</td><td class=br>-48</td>
<td class=bc>2 - 2 - 13</td>
<td class=br><strong>6</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>C</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2027&x=-391&p=Ve%20Kubrt">Ve Kubrt</a></td><td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>1:8</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=br>14:95</td><td class=br>-81</td>
<td class=bc>1 - 0 - 16</td>
<td class=br><strong>2</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>C</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1950&x=-391&p=Ad%20Sl%C3%A1dek">Ad Sládek</a></td><td class=kL>0:8</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>2:4</td>
<td class=kL>0:7</td>
<td class=kL>3:6</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=br>8:89</td><td class=br>-81</td>
<td class=bc>0 - 0 - 17</td>
<td class=br><strong>0</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ve Kubrt</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ad Sládek</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Jo Gruncl</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ve Kubrt</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ad Sládek</td><td class=bc>-</td><td class=blW>Ja Medvec</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Jo Gruncl</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ve Kubrt</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ad Sládek</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=blW>Jo Gruncl</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>13 : 0</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ve Kubrt</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ad Sládek</td><td class=bc>-</td><td class=blW>Jo Gruncl</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ja Medvec</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ve Kubrt</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ad Sládek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>8 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ve Kubrt</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ad Sládek</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ve Kubrt</td><td class=bc>-</td><td class=blW>Ja Janouškovec</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ad Sládek</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Fi Panoš</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>6 : 6</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ve Kubrt</td><td class=bc>-</td><td class=blW>Fi Panoš</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ad Sládek</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ja Medvec</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Fi Panoš</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ve Kubrt</td><td class=bc>-</td><td class=bl>Ad Sládek</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Jo Gruncl</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Fi Panoš</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ad Sládek</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ve Kubrt</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Fi Panoš</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Ad Sládek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ja Medvec</td><td class=bc>-</td><td class=bl>Ve Kubrt</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Fi Panoš</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ad Sládek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Ve Kubrt</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Fi Panoš</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ad Sládek</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Jo Gruncl</td><td class=bc>-</td><td class=bl>Ve Kubrt</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ja Janouškovec</td><td class=bc>-</td><td class=bl>Fi Panoš</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ad Sládek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ve Kubrt</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ja Medvec</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ja Janouškovec</td><td class=bc>-</td><td class=bl>Ad Sládek</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ve Kubrt</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Jo Gruncl</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Fi Panoš</td><td class=bc>-</td><td class=bl>Ad Sládek</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Ve Kubrt</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Ve Kubrt</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ad Sládek</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>9 : 4</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 3</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=409&x=-391&p=Pa%20Petr">Pa Petr</a></td><td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>6:4</td>
<td class=kW>7:3</td>
<td class=kW>9:2</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>11:4</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kW>8:0</td>
<td class=kW>9:2</td>
<td class=kW>10:0</td>
<td class=kW>14:2</td>
<td class=br>106:29</td><td class=br>+77</td>
<td class=bc>13 - 2 - 1</td>
<td class=br><strong>28</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1&x=-391&p=Pa%20Ple%C5%A1%C3%A1k">Pa Plešák</a></td><td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>6:0</td>
<td class=kW>7:2</td>
<td class=kW>7:1</td>
<td class=kW>10:1</td>
<td class=kW>5:2</td>
<td class=br>63:23</td><td class=br>+40</td>
<td class=bc>11 - 4 - 1</td>
<td class=br><strong>26</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=961&x=-391&p=Mi%20Bo%C5%A1t%C3%ADk">Mi Boštík</a></td><td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kL>1:5</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=kL>4:5</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kW>9:3</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=br>64:33</td><td class=br>+31</td>
<td class=bc>11 - 2 - 3</td>
<td class=br><strong>24</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=64&x=-391&p=Da%20%C5%A0m%C3%ADd">Da Šmíd</a></td><td class=kL>4:6</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>8:1</td>
<td class=kL>0:1</td>
<td class=kW>6:0</td>
<td class=kT>1:1</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=br>61:23</td><td class=br>+38</td>
<td class=bc>10 - 3 - 3</td>
<td class=br><strong>23</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1912&x=-391&p=Al%20Krejza">Al Krejza</a></td><td class=kL>3:7</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kW>10:1</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=br>69:33</td><td class=br>+36</td>
<td class=bc>11 - 1 - 4</td>
<td class=br><strong>23</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1876&x=-391&p=Ad%20Kop%C5%99iva">Ad Kopřiva</a></td><td class=kL>2:9</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=kW>4:3</td>
<td class=kW>8:0</td>
<td class=br>52:44</td><td class=br>+8</td>
<td class=bc>10 - 2 - 4</td>
<td class=br><strong>22</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1406&x=-391&p=Ja%20Mat%C3%BDsek">Ja Matýsek</a></td><td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>7:1</td>
<td class=kW>9:2</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=br>63:32</td><td class=br>+31</td>
<td class=bc>9 - 4 - 3</td>
<td class=br><strong>22</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=201&x=-391&p=To%20Bucek">To Bucek</a></td><td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kL>3:6</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>7:1</td>
<td class=kW>7:3</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>64:39</td><td class=br>+25</td>
<td class=bc>9 - 2 - 5</td>
<td class=br><strong>20</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=32&x=-391&p=Ji%20Krop%C3%A1%C4%8Dek">Ji Kropáček</a></td><td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>1:7</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=br>52:42</td><td class=br>+10</td>
<td class=bc>9 - 1 - 6</td>
<td class=br><strong>19</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1599&x=-391&p=Mi%20Uhl%C3%AD%C5%99">Mi Uhlíř</a></td><td class=kL>4:11</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kL>1:8</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>2:9</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>9:1</td>
<td class=kW>7:4</td>
<td class=kW>6:0</td>
<td class=kW>6:2</td>
<td class=br>61:61</td><td class=br>0</td>
<td class=bc>7 - 3 - 6</td>
<td class=br><strong>17</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=204&x=-391&p=Hy%20Nechutn%C3%BD">Hy Nechutný</a></td><td class=kL>0:7</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=br>29:47</td><td class=br>-18</td>
<td class=bc>6 - 0 - 10</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1405&x=-391&p=Pa%20Kubrt">Pa Kubrt</a></td><td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kL>0:6</td>
<td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>3:7</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>6:3</td>
<td class=kW>7:1</td>
<td class=br>39:61</td><td class=br>-22</td>
<td class=bc>5 - 1 - 10</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1657&x=-391&p=Jo%20Perkner">Jo Perkner</a></td><td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=br>22:50</td><td class=br>-28</td>
<td class=bc>2 - 3 - 11</td>
<td class=br><strong>7</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>B</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2025&x=-391&p=Vo%20Gorej">Vo Gorej</a></td><td class=kL>0:8</td>
<td class=kL>2:7</td>
<td class=kL>3:9</td>
<td class=kL>0:7</td>
<td class=kL>1:10</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>1:9</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=br>22:86</td><td class=br>-64</td>
<td class=bc>2 - 2 - 12</td>
<td class=br><strong>6</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1941&x=-391&p=Ja%20Kopeck%C3%BD">Ja Kopecký</a></td><td class=kL>2:9</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kL>4:7</td>
<td class=kW>2:0</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=br>34:72</td><td class=br>-38</td>
<td class=bc>3 - 0 - 13</td>
<td class=br><strong>6</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>C</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1959&x=-391&p=On%20Chlebo">On Chlebo</a></td><td class=kL>0:10</td>
<td class=kL>1:10</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=br>18:74</td><td class=br>-56</td>
<td class=bc>1 - 2 - 13</td>
<td class=br><strong>4</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>C</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1626&x=-391&p=Mi%20Hor%C3%A1kov%C3%A1">Mi Horáková</a></td><td class=kL>2:14</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>2:7</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=br>19:89</td><td class=br>-70</td>
<td class=bc>1 - 0 - 15</td>
<td class=br><strong>2</strong></td><td class=d>17.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ja Kopecký</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Pa Kubrt</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>On Chlebo</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ji Kropáček</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>Ji Kropáček</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Pa Kubrt</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 10</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>7 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Ja Kopecký</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Pa Kubrt</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 7</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Pa Kubrt</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 14</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 9</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Vo Gorej</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>4 : 11</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Pa Kubrt</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>9 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ja Kopecký</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ji Kropáček</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Vo Gorej</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ji Kropáček</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>1 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<hr><a name="final"><p class=vm>Výkonnostní skupiny (Final groups)</p></a>
<p class=v>Group A</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=409&x=-391&p=Pa%20Petr">Pa Petr</a></td><td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kT>4:4</td>
<td class=kW>6:4 K</td>
<td class=kW>3:2</td>
<td class=kT>3:3 K</td>
<td class=kL>1:2 K</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kT>1:1 K</td>
<td class=kL>0:2</td>
<td class=kW>7:3 K</td>
<td class=kW>2:0</td>
<td class=kW>4:1 K</td>
<td class=kW>9:2 K</td>
<td class=kW>6:4</td>
<td class=kW>7:2</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>9:2</td>
<td class=kW>9:0</td>
<td class=br>101:43</td><td class=br>+58</td>
<td class=bc>17 - 4 - 2</td>
<td class=br><strong>38</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1477&x=-391&p=Mi%20Kobrle">Mi Kobrle</a></td><td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>1:1 K</td>
<td class=kT>1:1</td>
<td class=kW>5:1 K</td>
<td class=kT>3:3</td>
<td class=kW>7:5</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kW>6:5 K</td>
<td class=kW>5:2</td>
<td class=kW>7:2 K</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kW>5:2 K</td>
<td class=kW>9:4 K</td>
<td class=kW>4:2 K</td>
<td class=br>97:53</td><td class=br>+44</td>
<td class=bc>14 - 7 - 2</td>
<td class=br><strong>35</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=567&x=-391&p=Kr%20Lebl">Kr Lebl</a></td><td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>4:0 K</td>
<td class=kW>2:0 K</td>
<td class=kT>4:4 K</td>
<td class=kL>2:5 K</td>
<td class=kW>6:3</td>
<td class=kT>4:4</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kL>2:3 K</td>
<td class=kW>8:1 K</td>
<td class=kW>4:2 K</td>
<td class=kW>2:0</td>
<td class=kW>9:1</td>
<td class=kW>7:3</td>
<td class=br>86:47</td><td class=br>+39</td>
<td class=bc>15 - 3 - 5</td>
<td class=br><strong>33</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=310&x=-391&p=Mi%20%C4%8Cernoch">Mi Černoch</a></td><td class=kT>4:4</td>
<td class=kT>1:1 K</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>0:2 K</td>
<td class=kL>0:5</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1 K</td>
<td class=kL>2:5</td>
<td class=kT>2:2 K</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kL>2:3 K</td>
<td class=kW>4:0 K</td>
<td class=kW>4:1 K</td>
<td class=br>63:43</td><td class=br>+20</td>
<td class=bc>12 - 7 - 4</td>
<td class=br><strong>31</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=64&x=-391&p=Da%20%C5%A0m%C3%ADd">Da Šmíd</a></td><td class=kL>4:6 K</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>3:3 K</td>
<td class=kL>2:3 K</td>
<td class=kW>7:2</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kW>3:1 K</td>
<td class=kT>4:4</td>
<td class=kW>4:2 K</td>
<td class=kT>1:1</td>
<td class=kW>2:1 K</td>
<td class=kT>1:1 K</td>
<td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=br>68:50</td><td class=br>+18</td>
<td class=bc>11 - 6 - 6</td>
<td class=br><strong>28</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=386&x=-391&p=Ku%20Sl%C3%A1dek">Ku Sládek</a></td><td class=kL>2:3</td>
<td class=kL>1:5 K</td>
<td class=kL>0:2</td>
<td class=kW>2:0 K</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kL>1:3 K</td>
<td class=kW>4:1</td>
<td class=kW>4:1 K</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>8:2</td>
<td class=kT>1:1</td>
<td class=kW>2:0 K</td>
<td class=kW>5:2 K</td>
<td class=kW>5:1 K</td>
<td class=br>65:40</td><td class=br>+25</td>
<td class=bc>12 - 3 - 8</td>
<td class=br><strong>27</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1406&x=-391&p=Ja%20Mat%C3%BDsek">Ja Matýsek</a></td><td class=kT>3:3 K</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kT>3:3 K</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=kW>7:4</td>
<td class=kT>0:0</td>
<td class=kW>3:1</td>
<td class=kL>4:7</td>
<td class=kW>5:1 K</td>
<td class=kT>2:2</td>
<td class=kL>0:4 K</td>
<td class=kL>1:2</td>
<td class=kL>1:3 K</td>
<td class=kL>1:3 K</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=br>72:52</td><td class=br>+20</td>
<td class=bc>10 - 7 - 6</td>
<td class=br><strong>27</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1&x=-391&p=Pa%20Ple%C5%A1%C3%A1k">Pa Plešák</a></td><td class=kW>2:1 K</td>
<td class=kL>5:7</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kW>3:2 K</td>
<td class=kL>2:4</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kL>4:6</td>
<td class=kT>2:2 K</td>
<td class=kL>2:3</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2</td>
<td class=kW>4:0 K</td>
<td class=kL>3:4 K</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kL>1:6</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=br>69:61</td><td class=br>+8</td>
<td class=bc>10 - 6 - 7</td>
<td class=br><strong>26</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=101&x=-391&p=Mi%20Kubica">Mi Kubica</a></td><td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kL>0:4 K</td>
<td class=kL>3:4</td>
<td class=kL>2:7</td>
<td class=kW>2:0</td>
<td class=kL>4:7</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kW>5:4 K</td>
<td class=kL>2:3 K</td>
<td class=kT>4:4 K</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kW>7:4</td>
<td class=kW>6:2 K</td>
<td class=kW>6:1 K</td>
<td class=kW>2:1 K</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=br>81:71</td><td class=br>+10</td>
<td class=bc>11 - 4 - 8</td>
<td class=br><strong>26</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=993&x=-391&p=Ji%20Chyl%C3%ADk%20ml.">Ji Chylík ml.</a></td><td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kL>0:2 K</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kT>0:0</td>
<td class=kT>1:1</td>
<td class=kL>4:5 K</td>
<td class=kx>*</td>
<td class=kW>5:0 K</td>
<td class=kW>3:1 K</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kW>4:1 K</td>
<td class=kL>4:5 K</td>
<td class=kW>5:3 K</td>
<td class=kW>7:0</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=br>68:51</td><td class=br>+17</td>
<td class=bc>10 - 5 - 8</td>
<td class=br><strong>25</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1251&x=-391&p=Ho%20Sl%C3%A1dek">Ho Sládek</a></td><td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kT>4:4 K</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kW>3:2 K</td>
<td class=kL>0:5 K</td>
<td class=kx>*</td>
<td class=kW>3:1 K</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kL>2:3 K</td>
<td class=kL>0:4 K</td>
<td class=kT>3:3 K</td>
<td class=kW>6:2</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=br>57:57</td><td class=br>0</td>
<td class=bc>9 - 7 - 7</td>
<td class=br><strong>25</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=248&x=-391&p=Ma%20%C5%BDen%C3%AD%C5%A1ek">Ma Ženíšek</a></td><td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kW>5:2 K</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kW>7:4</td>
<td class=kW>6:4</td>
<td class=kT>4:4 K</td>
<td class=kL>1:3 K</td>
<td class=kL>1:3 K</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1 K</td>
<td class=kW>1:0 K</td>
<td class=kW>4:3 K</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=br>62:65</td><td class=br>-3</td>
<td class=bc>10 - 5 - 8</td>
<td class=br><strong>25</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=961&x=-391&p=Mi%20Bo%C5%A1t%C3%ADk">Mi Boštík</a></td><td class=kT>1:1 K</td>
<td class=kT>2:2</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kL>1:3 K</td>
<td class=kW>3:2</td>
<td class=kL>1:5 K</td>
<td class=kT>2:2 K</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:2 K</td>
<td class=kL>1:3</td>
<td class=kW>6:3 K</td>
<td class=kW>4:1 K</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=br>64:58</td><td class=br>+6</td>
<td class=bc>9 - 7 - 7</td>
<td class=br><strong>25</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1065&x=-391&p=Kr%20Herold">Kr Herold</a></td><td class=kW>2:0</td>
<td class=kL>5:6 K</td>
<td class=kT>4:4</td>
<td class=kL>1:5 K</td>
<td class=kT>4:4</td>
<td class=kW>3:1 K</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kT>1:1 K</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>3:2 K</td>
<td class=kW>5:2 K</td>
<td class=kW>4:2 K</td>
<td class=br>67:66</td><td class=br>+1</td>
<td class=bc>9 - 7 - 7</td>
<td class=br><strong>25</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1912&x=-391&p=Al%20Krejza">Al Krejza</a></td><td class=kL>3:7 K</td>
<td class=kL>2:5</td>
<td class=kL>3:6</td>
<td class=kW>5:2</td>
<td class=kL>2:4 K</td>
<td class=kL>1:4</td>
<td class=kW>4:0 K</td>
<td class=kT>1:1 K</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>2:5 K</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>6:3 K</td>
<td class=kL>2:4 K</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=br>66:68</td><td class=br>-2</td>
<td class=bc>11 - 2 - 10</td>
<td class=br><strong>24</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=53&x=-391&p=V%C3%A1%20Pikl">Vá Pikl</a></td><td class=kL>0:2</td>
<td class=kL>2:7 K</td>
<td class=kL>1:3</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kL>1:4 K</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kT>1:1 K</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kL>1:4 K</td>
<td class=kT>2:2 K</td>
<td class=kW>5:2 K</td>
<td class=br>45:49</td><td class=br>-4</td>
<td class=bc>7 - 8 - 8</td>
<td class=br><strong>22</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=201&x=-391&p=To%20Bucek">To Bucek</a></td><td class=kL>1:4 K</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:2 K</td>
<td class=kL>0:4</td>
<td class=kW>3:1 K</td>
<td class=kL>0:4 K</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>3:6 K</td>
<td class=kW>2:1</td>
<td class=kL>3:6 K</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>7:1 K</td>
<td class=kL>3:5</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=br>57:69</td><td class=br>-12</td>
<td class=bc>10 - 1 - 12</td>
<td class=br><strong>21</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1876&x=-391&p=Ad%20Kop%C5%99iva">Ad Kopřiva</a></td><td class=kL>2:9 K</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kT>1:1 K</td>
<td class=kL>1:4</td>
<td class=kW>3:1 K</td>
<td class=kW>4:3 K</td>
<td class=kL>4:7</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>1:4 K</td>
<td class=kT>3:3</td>
<td class=kW>4:2 K</td>
<td class=kW>2:1</td>
<td class=kL>1:7 K</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>5:6</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>7:3</td>
<td class=br>54:85</td><td class=br>-31</td>
<td class=bc>8 - 2 - 13</td>
<td class=br><strong>18</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=818&x=-391&p=Ro%20Je%C5%BE">Ro Jež</a></td><td class=kL>4:6</td>
<td class=kL>0:6</td>
<td class=kW>3:2 K</td>
<td class=kT>2:2</td>
<td class=kW>6:3</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>2:6 K</td>
<td class=kL>1:4 K</td>
<td class=kW>3:2 K</td>
<td class=kL>1:3 K</td>
<td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1 K</td>
<td class=kW>4:2 K</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=br>56:80</td><td class=br>-24</td>
<td class=bc>8 - 1 - 14</td>
<td class=br><strong>17</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=4&x=-391&p=Vl%20Kraus">Vl Kraus</a></td><td class=kL>2:7</td>
<td class=kW>5:4</td>
<td class=kL>1:8 K</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kL>2:8</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>1:6 K</td>
<td class=kW>5:4 K</td>
<td class=kW>4:0 K</td>
<td class=kL>0:1 K</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>5:4</td>
<td class=kL>2:3</td>
<td class=kL>1:2 K</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=br>59:80</td><td class=br>-21</td>
<td class=bc>7 - 3 - 13</td>
<td class=br><strong>17</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=26&x=-391&p=Mi%20%C5%A0evr">Mi Ševr</a></td><td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>2:4 K</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kW>6:1</td>
<td class=kL>1:2 K</td>
<td class=kL>3:5 K</td>
<td class=kT>3:3 K</td>
<td class=kL>3:4 K</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>6:5</td>
<td class=kL>2:4 K</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>7:2</td>
<td class=kW>2:1</td>
<td class=br>58:70</td><td class=br>-12</td>
<td class=bc>6 - 3 - 14</td>
<td class=br><strong>15</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1872&x=-391&p=Pe%20Fuchs">Pe Fuchs</a></td><td class=kL>1:5</td>
<td class=kL>2:5 K</td>
<td class=kL>0:2</td>
<td class=kW>3:2 K</td>
<td class=kL>1:5</td>
<td class=kL>0:2 K</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>0:7</td>
<td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3 K</td>
<td class=kL>2:4</td>
<td class=kW>4:1 K</td>
<td class=kL>3:5</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>2:4 K</td>
<td class=kW>4:1 K</td>
<td class=br>50:80</td><td class=br>-30</td>
<td class=bc>6 - 1 - 16</td>
<td class=br><strong>13</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=89&x=-391&p=Jo%20Gruncl">Jo Gruncl</a></td><td class=kL>2:9</td>
<td class=kL>4:9 K</td>
<td class=kL>1:9</td>
<td class=kL>0:4 K</td>
<td class=kL>1:5</td>
<td class=kL>2:5 K</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kL>2:5 K</td>
<td class=kL>2:6</td>
<td class=kT>2:2 K</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>2:7</td>
<td class=kW>4:2 K</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=br>41:111</td><td class=br>-70</td>
<td class=bc>2 - 2 - 19</td>
<td class=br><strong>6</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1940&x=-391&p=Ma%20Ko%C5%A1%C5%88ar">Ma Košňar</a></td><td class=kL>0:9</td>
<td class=kL>2:4 K</td>
<td class=kL>3:7</td>
<td class=kL>1:4 K</td>
<td class=kL>1:3</td>
<td class=kL>1:5 K</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>2:4 K</td>
<td class=kL>3:4</td>
<td class=kL>2:5 K</td>
<td class=kT>2:2</td>
<td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>1:4 K</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=br>33:90</td><td class=br>-57</td>
<td class=bc>0 - 3 - 20</td>
<td class=br><strong>3</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Jo Gruncl</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>7 : 5</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>1 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1117&x=-391&p=To%20Kahoun%20ml.">To Kahoun ml.</a></td><td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kT>0:0</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=br>47:17</td><td class=br>+30</td>
<td class=bc>12 - 3 - 2</td>
<td class=br><strong>27</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1599&x=-391&p=Mi%20Uhl%C3%AD%C5%99">Mi Uhlíř</a></td><td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kW>6:4</td>
<td class=kW>3:1</td>
<td class=kW>8:2</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>6:4</td>
<td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>10:7</td>
<td class=kW>5:4</td>
<td class=kW>6:1</td>
<td class=kW>10:0</td>
<td class=br>82:46</td><td class=br>+36</td>
<td class=bc>13 - 0 - 4</td>
<td class=br><strong>26</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=32&x=-391&p=Ji%20Krop%C3%A1%C4%8Dek">Ji Kropáček</a></td><td class=kT>0:0</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>9:3</td>
<td class=kW>6:5</td>
<td class=kW>7:4</td>
<td class=br>59:41</td><td class=br>+18</td>
<td class=bc>11 - 2 - 4</td>
<td class=br><strong>24</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=204&x=-391&p=Hy%20Nechutn%C3%BD">Hy Nechutný</a></td><td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>8:3</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=br>49:31</td><td class=br>+18</td>
<td class=bc>10 - 4 - 3</td>
<td class=br><strong>24</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=176&x=-391&p=Zd%20Lopaur">Zd Lopaur</a></td><td class=kW>4:2</td>
<td class=kL>4:6</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kW>7:2</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kW>9:2</td>
<td class=kW>3:1</td>
<td class=kW>8:0</td>
<td class=br>69:40</td><td class=br>+29</td>
<td class=bc>11 - 1 - 5</td>
<td class=br><strong>23</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=70&x=-391&p=St%20Srba">St Srba</a></td><td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=br>45:36</td><td class=br>+9</td>
<td class=bc>9 - 3 - 5</td>
<td class=br><strong>21</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/4</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=318&x=-391&p=Ji%20V%C3%A1cha">Ji Vácha</a></td><td class=kL>2:5</td>
<td class=kL>2:8</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kW>6:0</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>6:3</td>
<td class=kW>5:4</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=br>57:51</td><td class=br>+6</td>
<td class=bc>9 - 3 - 5</td>
<td class=br><strong>21</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/4</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1058&x=-391&p=Fr%20Marek">Fr Marek</a></td><td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kT>0:0</td>
<td class=kW>6:3</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=br>53:34</td><td class=br>+19</td>
<td class=bc>8 - 3 - 6</td>
<td class=br><strong>19</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1657&x=-391&p=Jo%20Perkner">Jo Perkner</a></td><td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=br>34:34</td><td class=br>0</td>
<td class=bc>8 - 3 - 6</td>
<td class=br><strong>19</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1927&x=-391&p=Vo%20Kraus">Vo Kraus</a></td><td class=kT>1:1</td>
<td class=kL>4:6</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>5:4</td>
<td class=kL>0:2</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=br>43:46</td><td class=br>-3</td>
<td class=bc>7 - 3 - 7</td>
<td class=br><strong>17</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=41&x=-391&p=Da%20Hrachovec">Da Hrachovec</a></td><td class=kL>1:4</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>2:7</td>
<td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kW>5:4</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kW>8:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=br>48:55</td><td class=br>-7</td>
<td class=bc>7 - 2 - 8</td>
<td class=br><strong>16</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1630&x=-391&p=Pe%20Holub">Pe Holub</a></td><td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=br>50:49</td><td class=br>+1</td>
<td class=bc>6 - 3 - 8</td>
<td class=br><strong>15</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=18&x=-391&p=An%20%C5%A0ur%C3%BDn">An Šurýn</a></td><td class=kL>0:1</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kL>4:5</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=br>38:45</td><td class=br>-7</td>
<td class=bc>6 - 3 - 8</td>
<td class=br><strong>15</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1405&x=-391&p=Pa%20Kubrt">Pa Kubrt</a></td><td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kL>3:6</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=br>38:47</td><td class=br>-9</td>
<td class=bc>6 - 2 - 9</td>
<td class=br><strong>14</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=10&x=-391&p=Ja%20Medvec">Ja Medvec</a></td><td class=kL>1:3</td>
<td class=kL>7:10</td>
<td class=kL>2:3</td>
<td class=kL>3:8</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>3:6</td>
<td class=kT>0:0</td>
<td class=kW>3:1</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>50:59</td><td class=br>-9</td>
<td class=bc>6 - 2 - 9</td>
<td class=br><strong>14</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1968&x=-391&p=Mi%20Tou%C5%A1">Mi Touš</a></td><td class=kL>0:4</td>
<td class=kL>4:5</td>
<td class=kL>3:9</td>
<td class=kL>3:5</td>
<td class=kL>2:9</td>
<td class=kL>1:6</td>
<td class=kL>4:5</td>
<td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kL>1:8</td>
<td class=kT>4:4</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>6:5</td>
<td class=kW>7:3</td>
<td class=br>52:91</td><td class=br>-39</td>
<td class=bc>3 - 1 - 13</td>
<td class=br><strong>7</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1639&x=-391&p=Ja%20Ou%C5%99ada">Ja Ouřada</a></td><td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kL>5:6</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>5:6</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=br>33:62</td><td class=br>-29</td>
<td class=bc>1 - 1 - 15</td>
<td class=br><strong>3</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2025&x=-391&p=Vo%20Gorej">Vo Gorej</a></td><td class=kL>0:2</td>
<td class=kL>0:10</td>
<td class=kL>4:7</td>
<td class=kL>0:4</td>
<td class=kL>0:8</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>0:6</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>3:7</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=br>19:82</td><td class=br>-63</td>
<td class=bc>0 - 1 - 16</td>
<td class=br><strong>1</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Vo Kraus</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Ja Medvec</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>Ja Ouřada</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Pa Kubrt</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>9 : 3</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ja Medvec</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vo Kraus</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ja Medvec</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Pa Kubrt</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Mi Touš</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Mi Touš</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>Ji Kropáček</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pa Kubrt</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Ji Kropáček</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Ja Medvec</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Vo Kraus</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ji Kropáček</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ja Medvec</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ji Kropáček</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pa Kubrt</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Vo Kraus</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Touš</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=blW>Vo Kraus</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Vo Kraus</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Pa Kubrt</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Ja Medvec</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Pa Kubrt</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Pa Kubrt</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Vo Kraus</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>10 : 7</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Pa Kubrt</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1941&x=-391&p=Ja%20Kopeck%C3%BD">Ja Kopecký</a></td><td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kT>0:0</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>7:0</td>
<td class=br>35:8</td><td class=br>+27</td>
<td class=bc>9 - 1 - 0</td>
<td class=br><strong>19</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1947&x=-391&p=Lu%20Holub">Lu Holub</a></td><td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=br>33:14</td><td class=br>+19</td>
<td class=bc>8 - 1 - 1</td>
<td class=br><strong>17</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2018&x=-391&p=Ja%20Janou%C5%A1kovec">Ja Janouškovec</a></td><td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=br>37:14</td><td class=br>+23</td>
<td class=bc>8 - 0 - 2</td>
<td class=br><strong>16</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1626&x=-391&p=Mi%20Hor%C3%A1kov%C3%A1">Mi Horáková</a></td><td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>3:0</td>
<td class=br>36:20</td><td class=br>+16</td>
<td class=bc>6 - 2 - 2</td>
<td class=br><strong>14</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1896&x=-391&p=Ra%20Hrn%C4%8D%C3%AD%C5%99">Ra Hrnčíř</a></td><td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>33:19</td><td class=br>+14</td>
<td class=bc>6 - 0 - 4</td>
<td class=br><strong>12</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1959&x=-391&p=On%20Chlebo">On Chlebo</a></td><td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=br>20:16</td><td class=br>+4</td>
<td class=bc>5 - 0 - 5</td>
<td class=br><strong>10</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/4</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1999&x=-391&p=Fi%20Pano%C5%A1">Fi Panoš</a></td><td class=kT>0:0</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=br>21:20</td><td class=br>+1</td>
<td class=bc>4 - 2 - 4</td>
<td class=br><strong>10</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/4</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1076&x=-391&p=Mi%20Zeman">Mi Zeman</a></td><td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=br>13:30</td><td class=br>-17</td>
<td class=bc>2 - 1 - 7</td>
<td class=br><strong>5</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2021&x=-391&p=Kr%20Novotn%C3%BD">Kr Novotný</a></td><td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>13:26</td><td class=br>-13</td>
<td class=bc>2 - 0 - 8</td>
<td class=br><strong>4</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2027&x=-391&p=Ve%20Kubrt">Ve Kubrt</a></td><td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>9:38</td><td class=br>-29</td>
<td class=bc>1 - 1 - 8</td>
<td class=br><strong>3</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1950&x=-391&p=Ad%20Sl%C3%A1dek">Ad Sládek</a></td><td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>1:46</td><td class=br>-45</td>
<td class=bc>0 - 0 - 10</td>
<td class=br><strong>0</strong></td><td class=d>11.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Ad Sládek</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ja Janouškovec</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ja Kopecký</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=blW>Lu Holub</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=bl>Ve Kubrt</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ad Sládek</td><td class=bc>-</td><td class=blW>Kr Novotný</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ja Janouškovec</td><td class=bc>-</td><td class=bl>Ve Kubrt</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ja Kopecký</td><td class=bc>-</td><td class=bl>Lu Holub</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>On Chlebo</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Kr Novotný</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ad Sládek</td><td class=bc>-</td><td class=blW>Ve Kubrt</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Lu Holub</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ja Janouškovec</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=bl>Fi Panoš</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Ve Kubrt</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Kr Novotný</td><td class=bc>-</td><td class=blW>Lu Holub</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ad Sládek</td><td class=bc>-</td><td class=blW>On Chlebo</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Fi Panoš</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ja Janouškovec</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ve Kubrt</td><td class=bc>-</td><td class=blW>Lu Holub</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kr Novotný</td><td class=bc>-</td><td class=blW>Fi Panoš</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ja Kopecký</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Ad Sládek</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Lu Holub</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ve Kubrt</td><td class=bc>-</td><td class=blW>Fi Panoš</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ja Janouškovec</td><td class=bc>-</td><td class=bl>Ad Sládek</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Kr Novotný</td><td class=bc>-</td><td class=blW>Ja Kopecký</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>On Chlebo</td><td class=bc>-</td><td class=bl>Fi Panoš</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ve Kubrt</td><td class=bc>-</td><td class=blW>Ja Kopecký</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ja Janouškovec</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Lu Holub</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ad Sládek</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Ja Kopecký</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Lu Holub</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ve Kubrt</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Fi Panoš</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ve Kubrt</td><td class=bc>-</td><td class=blW>Kr Novotný</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=blW>Ja Janouškovec</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Lu Holub</td><td class=bc>-</td><td class=bl>Ad Sládek</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ja Kopecký</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ja Kopecký</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Lu Holub</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Fi Panoš</td><td class=bc>-</td><td class=bl>Ad Sládek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>On Chlebo</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ja Janouškovec</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ja Kopecký</td><td class=bc>-</td><td class=bl>Ad Sládek</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>On Chlebo</td><td class=bc>-</td><td class=bl>Ve Kubrt</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>2 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
