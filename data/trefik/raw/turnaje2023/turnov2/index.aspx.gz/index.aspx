<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Turnov</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Turnov, 11. březen 2023</span></h2></div></div></div></div><p><div align="center">
<div align=center>
<a href="kriz.aspx">Zápasy ve skupinách (Basic and placement groups)</a><br>
<a href="Turnov_playoff.aspx ">Zápasy o umístění (Placement matches)</a><br>
<a href="utokturnaje.aspx">Tabulka útočníků (Best forwards)</a><br>
<a href="obranaturnaje.aspx">Tabulka obránců (Best defenders)</a><br>
<a href="kluby.aspx">Soutěž klubů</a><br>
</div>
<p class=v>Konečné pořadí turnaje (Final table)<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0 class="rnk">
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">M</th>
<th align="center">+</th>
<th align="center">=</th>
<th align="center">-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">Pts</th>
<th align="center">CZ pts</th>
<th>&nbsp;</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=409&x=388">Petr Patrik</a></td>
<td class=al>THC Stiga Elites</td>
<td class=ar>41</td>
<td class=ar>40</td>
<td class=ar>0</td>
<td class=ar>1</td>
<td class=ar>205</td>
<td class=al>&nbsp;:&nbsp;52</td>
<td class=ar>80</td>
<td class=art>160</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>2.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=386&x=388">Sládek Kuba</a></td>
<td class=bl>THC Stiga-Game Příbram</td>
<td class=br>44</td>
<td class=br>23</td>
<td class=br>6</td>
<td class=br>15</td>
<td class=br>121</td>
<td class=bl>&nbsp;:&nbsp;100</td>
<td class=br>52</td>
<td class=brt>152</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>3.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=993&x=388">Chylík ml. Jiří</a></td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>42</td>
<td class=ar>29</td>
<td class=ar>6</td>
<td class=ar>7</td>
<td class=ar>144</td>
<td class=al>&nbsp;:&nbsp;75</td>
<td class=ar>64</td>
<td class=art>146</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>4.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=448&x=388">Waclawek Tomáš</a></td>
<td class=bl>THC Třinec</td>
<td class=br>42</td>
<td class=br>21</td>
<td class=br>5</td>
<td class=br>16</td>
<td class=br>134</td>
<td class=bl>&nbsp;:&nbsp;114</td>
<td class=br>47</td>
<td class=brt>141</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>5.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1477&x=388">Kobrle Michal</a></td>
<td class=al>THC Stiga Elites</td>
<td class=ar>37</td>
<td class=ar>26</td>
<td class=ar>5</td>
<td class=ar>6</td>
<td class=ar>183</td>
<td class=al>&nbsp;:&nbsp;84</td>
<td class=ar>57</td>
<td class=art>137</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>6.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=64&x=388">Šmíd David</a></td>
<td class=bl>THC Stiga Elites</td>
<td class=br>36</td>
<td class=br>19</td>
<td class=br>6</td>
<td class=br>11</td>
<td class=br>123</td>
<td class=bl>&nbsp;:&nbsp;87</td>
<td class=br>44</td>
<td class=brt>134</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>7.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1&x=388">Plešák Pavel</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>37</td>
<td class=ar>18</td>
<td class=ar>10</td>
<td class=ar>9</td>
<td class=ar>134</td>
<td class=al>&nbsp;:&nbsp;108</td>
<td class=ar>46</td>
<td class=art>132</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>8.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=4&x=388">Kraus Vladimír</a></td>
<td class=bl>Rokycany</td>
<td class=br>38</td>
<td class=br>18</td>
<td class=br>1</td>
<td class=br>19</td>
<td class=br>114</td>
<td class=bl>&nbsp;:&nbsp;107</td>
<td class=br>37</td>
<td class=brt>131</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>9.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1065&x=388">Herold Kryštof</a></td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>35</td>
<td class=ar>22</td>
<td class=ar>5</td>
<td class=ar>8</td>
<td class=ar>120</td>
<td class=al>&nbsp;:&nbsp;68</td>
<td class=ar>49</td>
<td class=art>128</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>10.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1251&x=388">Sládek Honza</a></td>
<td class=bl>THC Stiga Elites</td>
<td class=br>35</td>
<td class=br>19</td>
<td class=br>7</td>
<td class=br>9</td>
<td class=br>100</td>
<td class=bl>&nbsp;:&nbsp;75</td>
<td class=br>45</td>
<td class=brt>127</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>11.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=567&x=388">Lebl Kryštof</a></td>
<td class=al>Big Band</td>
<td class=ar>33</td>
<td class=ar>19</td>
<td class=ar>4</td>
<td class=ar>10</td>
<td class=ar>114</td>
<td class=al>&nbsp;:&nbsp;69</td>
<td class=ar>42</td>
<td class=art>126</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>12.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1641&x=388">Klazar Matyáš</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>32</td>
<td class=br>18</td>
<td class=br>3</td>
<td class=br>11</td>
<td class=br>88</td>
<td class=bl>&nbsp;:&nbsp;78</td>
<td class=br>39</td>
<td class=brt>125</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>13.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=101&x=388">Kubica Miloslav</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>34</td>
<td class=ar>18</td>
<td class=ar>3</td>
<td class=ar>13</td>
<td class=ar>114</td>
<td class=al>&nbsp;:&nbsp;92</td>
<td class=ar>39</td>
<td class=art>124</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>14.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1876&x=388">Kopřiva Adam</a></td>
<td class=bl>BSE United</td>
<td class=br>33</td>
<td class=br>9</td>
<td class=br>10</td>
<td class=br>14</td>
<td class=br>73</td>
<td class=bl>&nbsp;:&nbsp;103</td>
<td class=br>28</td>
<td class=brt>123</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>15.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=248&x=388">Ženíšek Martin</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>32</td>
<td class=ar>9</td>
<td class=ar>10</td>
<td class=ar>13</td>
<td class=ar>90</td>
<td class=al>&nbsp;:&nbsp;96</td>
<td class=ar>28</td>
<td class=art>122</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>16.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1872&x=388">Fuchs Petr</a></td>
<td class=bl>Big Band</td>
<td class=br>33</td>
<td class=br>12</td>
<td class=br>3</td>
<td class=br>18</td>
<td class=br>75</td>
<td class=bl>&nbsp;:&nbsp;99</td>
<td class=br>27</td>
<td class=brt>121</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>17.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=818&x=388">Jež Robert</a></td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>29</td>
<td class=ar>14</td>
<td class=ar>3</td>
<td class=ar>12</td>
<td class=ar>78</td>
<td class=al>&nbsp;:&nbsp;86</td>
<td class=ar>31</td>
<td class=art>119</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>18.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=26&x=388">Ševr Miloš</a></td>
<td class=bl>THC Stiga Elites</td>
<td class=br>29</td>
<td class=br>12</td>
<td class=br>4</td>
<td class=br>13</td>
<td class=br>67</td>
<td class=bl>&nbsp;:&nbsp;77</td>
<td class=br>28</td>
<td class=brt>118</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>19.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=310&x=388">Černoch Miroslav</a></td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>30</td>
<td class=ar>12</td>
<td class=ar>4</td>
<td class=ar>14</td>
<td class=ar>88</td>
<td class=al>&nbsp;:&nbsp;71</td>
<td class=ar>28</td>
<td class=art>117</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>20.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=261&x=388">Cibulka David</a></td>
<td class=bl>THC Třinec</td>
<td class=br>30</td>
<td class=br>11</td>
<td class=br>6</td>
<td class=br>13</td>
<td class=br>82</td>
<td class=bl>&nbsp;:&nbsp;86</td>
<td class=br>28</td>
<td class=brt>116</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>21.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=40&x=388">Matýsek Daniel</a></td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>29</td>
<td class=ar>12</td>
<td class=ar>4</td>
<td class=ar>13</td>
<td class=ar>73</td>
<td class=al>&nbsp;:&nbsp;72</td>
<td class=ar>28</td>
<td class=art>115</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>22.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1912&x=388">Krejza Aleš</a></td>
<td class=bl>THC Třinec</td>
<td class=br>29</td>
<td class=br>10</td>
<td class=br>7</td>
<td class=br>12</td>
<td class=br>90</td>
<td class=bl>&nbsp;:&nbsp;81</td>
<td class=br>27</td>
<td class=brt>114</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>23.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=18&x=388">Šurýn Antonín</a></td>
<td class=al>Big Band</td>
<td class=ar>30</td>
<td class=ar>10</td>
<td class=ar>5</td>
<td class=ar>15</td>
<td class=ar>57</td>
<td class=al>&nbsp;:&nbsp;79</td>
<td class=ar>25</td>
<td class=art>113</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>24.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1940&x=388">Košňar Martin</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>30</td>
<td class=br>11</td>
<td class=br>0</td>
<td class=br>19</td>
<td class=br>74</td>
<td class=bl>&nbsp;:&nbsp;107</td>
<td class=br>22</td>
<td class=brt>112</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>25.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=201&x=388">Bucek Tomáš</a></td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>38</td>
<td class=ar>22</td>
<td class=ar>3</td>
<td class=ar>13</td>
<td class=ar>135</td>
<td class=al>&nbsp;:&nbsp;83</td>
<td class=ar>47</td>
<td class=art>111</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>26.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=53&x=388">Pikl Václav</a></td>
<td class=bl>THC Stiga Elites</td>
<td class=br>40</td>
<td class=br>22</td>
<td class=br>2</td>
<td class=br>16</td>
<td class=br>145</td>
<td class=bl>&nbsp;:&nbsp;79</td>
<td class=br>46</td>
<td class=brt>109</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>27.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1117&x=388">Kahoun ml. Tomáš</a></td>
<td class=al>BSE United</td>
<td class=ar>38</td>
<td class=ar>16</td>
<td class=ar>4</td>
<td class=ar>18</td>
<td class=ar>93</td>
<td class=al>&nbsp;:&nbsp;115</td>
<td class=ar>36</td>
<td class=art>107</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>28.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=70&x=388">Srba Stanislav</a></td>
<td class=bl>SHC Cheb</td>
<td class=br>36</td>
<td class=br>12</td>
<td class=br>5</td>
<td class=br>19</td>
<td class=br>80</td>
<td class=bl>&nbsp;:&nbsp;107</td>
<td class=br>29</td>
<td class=brt>106</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>29.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=32&x=388">Kropáček Jiří</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>33</td>
<td class=ar>14</td>
<td class=ar>6</td>
<td class=ar>13</td>
<td class=ar>79</td>
<td class=al>&nbsp;:&nbsp;81</td>
<td class=ar>34</td>
<td class=art>105</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>30.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1058&x=388">Marek František</a></td>
<td class=bl>BSE United</td>
<td class=br>34</td>
<td class=br>12</td>
<td class=br>5</td>
<td class=br>17</td>
<td class=br>77</td>
<td class=bl>&nbsp;:&nbsp;88</td>
<td class=br>29</td>
<td class=brt>104</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>31.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=204&x=388">Nechutný Hynek</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>32</td>
<td class=ar>9</td>
<td class=ar>3</td>
<td class=ar>20</td>
<td class=ar>68</td>
<td class=al>&nbsp;:&nbsp;87</td>
<td class=ar>21</td>
<td class=art>103</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>32.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1941&x=388">Kopecký Jaroslav</a></td>
<td class=bl>SHC Cheb</td>
<td class=br>34</td>
<td class=br>6</td>
<td class=br>5</td>
<td class=br>23</td>
<td class=br>70</td>
<td class=bl>&nbsp;:&nbsp;148</td>
<td class=br>17</td>
<td class=brt>102</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>33.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1657&x=388">Perkner Jonáš</a></td>
<td class=al>Big Band</td>
<td class=ar>29</td>
<td class=ar>5</td>
<td class=ar>6</td>
<td class=ar>18</td>
<td class=ar>56</td>
<td class=al>&nbsp;:&nbsp;106</td>
<td class=ar>16</td>
<td class=art>100</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>34.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1927&x=388">Kraus Vojtěch</a></td>
<td class=bl>Rokycany</td>
<td class=br>29</td>
<td class=br>5</td>
<td class=br>7</td>
<td class=br>17</td>
<td class=br>54</td>
<td class=bl>&nbsp;:&nbsp;93</td>
<td class=br>17</td>
<td class=brt>99</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>35.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1869&x=388">Klazar Petr</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>30</td>
<td class=ar>3</td>
<td class=ar>2</td>
<td class=ar>25</td>
<td class=ar>41</td>
<td class=al>&nbsp;:&nbsp;130</td>
<td class=ar>8</td>
<td class=art>98</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>36.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1896&x=388">Hrnčíř Radek</a></td>
<td class=bl>Big Band</td>
<td class=br>30</td>
<td class=br>3</td>
<td class=br>5</td>
<td class=br>22</td>
<td class=br>48</td>
<td class=bl>&nbsp;:&nbsp;143</td>
<td class=br>11</td>
<td class=brt>97</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>37.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1999&x=388">Panoš Filip</a></td>
<td class=al>Pelhřimov</td>
<td class=ar>29</td>
<td class=ar>0</td>
<td class=ar>0</td>
<td class=ar>29</td>
<td class=ar>16</td>
<td class=al>&nbsp;:&nbsp;177</td>
<td class=ar>0</td>
<td class=art>96</td>
<td class=ar>&nbsp;</td>
</tr></table></td></tr></table></div></p>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
