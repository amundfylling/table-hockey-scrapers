<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Cheb</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../cheb">Cheb, 19. listopad 2022</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Základní skupiny (Basic groups)</a><br>
<a href="#final">Výkonnostní skupiny (Final groups)</a><br>
<a name="basic"><p class=vm>Základní skupiny (Basic groups)</p></a>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Pa Petr</td><td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>8:0</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kW>7:1</td>
<td class=kW>11:3</td>
<td class=kW>6:2</td>
<td class=kW>16:3</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>8:0</td>
<td class=kW>6:0</td>
<td class=kW>9:1</td>
<td class=kW>7:0</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kW>8:2</td>
<td class=kW>8:1</td>
<td class=kW>12:0</td>
<td class=br>149:28</td><td class=br>+121</td>
<td class=bc>21 - 0 - 0</td>
<td class=br><strong>42</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ku Sládek</td><td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>6:3</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=br>70:34</td><td class=br>+36</td>
<td class=bc>16 - 1 - 4</td>
<td class=br><strong>33</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Da Matýsek</td><td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>8:7</td>
<td class=kW>3:2</td>
<td class=kW>7:3</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>7:3</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kW>6:5</td>
<td class=kW>3:0</td>
<td class=kW>9:1</td>
<td class=kW>4:1</td>
<td class=br>80:44</td><td class=br>+36</td>
<td class=bc>15 - 3 - 3</td>
<td class=br><strong>33</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ji Chylík ml.</td><td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kL>0:3</td>
<td class=kW>6:1</td>
<td class=kW>7:0</td>
<td class=kW>2:1</td>
<td class=kW>8:0</td>
<td class=br>65:28</td><td class=br>+37</td>
<td class=bc>15 - 3 - 3</td>
<td class=br><strong>33</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Mi Černoch</td><td class=kL>0:8</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=br>61:33</td><td class=br>+28</td>
<td class=bc>15 - 1 - 5</td>
<td class=br><strong>31</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Vá Pikl</td><td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kT>0:0</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>10:0</td>
<td class=br>61:35</td><td class=br>+26</td>
<td class=bc>11 - 4 - 6</td>
<td class=br><strong>26</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>St Srba</td><td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=kW>7:1</td>
<td class=br>42:37</td><td class=br>+5</td>
<td class=bc>11 - 4 - 6</td>
<td class=br><strong>26</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>To Bucek</td><td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kW>8:3</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kW>7:0</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>11:0</td>
<td class=kW>7:0</td>
<td class=br>71:36</td><td class=br>+35</td>
<td class=bc>11 - 3 - 7</td>
<td class=br><strong>25</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>To Kahoun ml.</td><td class=kL>3:11</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=br>56:50</td><td class=br>+6</td>
<td class=bc>9 - 6 - 6</td>
<td class=br><strong>24</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>Al Krejza</td><td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>5:3</td>
<td class=kT>0:0</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=kL>3:6</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=kW>5:0</td>
<td class=br>65:55</td><td class=br>+10</td>
<td class=bc>10 - 3 - 8</td>
<td class=br><strong>23</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>A</td><td class=d>11.</td><td class=kt>Mi Uhlíř</td><td class=kL>3:16</td>
<td class=kL>1:5</td>
<td class=kL>7:8</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>7:6</td>
<td class=kT>4:4</td>
<td class=kL>4:7</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kL>4:5</td>
<td class=kW>10:0</td>
<td class=br>87:85</td><td class=br>+2</td>
<td class=bc>9 - 3 - 9</td>
<td class=br><strong>21</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>A</td><td class=d>12.</td><td class=kt>Lu Černý</td><td class=kL>2:5</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>3:8</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>7:3</td>
<td class=kW>6:2</td>
<td class=kW>10:0</td>
<td class=br>72:62</td><td class=br>+10</td>
<td class=bc>9 - 3 - 9</td>
<td class=br><strong>21</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Ji Kropáček</td><td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>3:7</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kL>6:7</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=br>60:59</td><td class=br>+1</td>
<td class=bc>7 - 6 - 8</td>
<td class=br><strong>20</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>B</td><td class=d>14.</td><td class=kt>An Šurýn</td><td class=kL>0:8</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kW>5:4</td>
<td class=kW>5:0</td>
<td class=kW>7:2</td>
<td class=br>53:60</td><td class=br>-7</td>
<td class=bc>8 - 4 - 9</td>
<td class=br><strong>20</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>B</td><td class=d>15.</td><td class=kt>Ro Hejda</td><td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>0:1</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kW>7:4</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kW>6:0</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=br>58:65</td><td class=br>-7</td>
<td class=bc>8 - 2 - 11</td>
<td class=br><strong>18</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>B</td><td class=d>16.</td><td class=kt>Pe Holub</td><td class=kL>1:9</td>
<td class=kL>2:4</td>
<td class=kL>3:7</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kL>2:5</td>
<td class=kW>6:3</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>8:2</td>
<td class=br>53:67</td><td class=br>-14</td>
<td class=bc>8 - 1 - 12</td>
<td class=br><strong>17</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>B</td><td class=d>17.</td><td class=kt>Jo Perkner</td><td class=kL>0:7</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kL>3:5</td>
<td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=br>35:54</td><td class=br>-19</td>
<td class=bc>6 - 2 - 13</td>
<td class=br><strong>14</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>B</td><td class=d>18.</td><td class=kt>Jo Gruncl</td><td class=kL>1:7</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kL>1:5</td>
<td class=kT>0:0</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=br>42:66</td><td class=br>-24</td>
<td class=bc>5 - 3 - 13</td>
<td class=br><strong>13</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>B</td><td class=d>19.</td><td class=kt>An Ouřada</td><td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>5:6</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kL>3:6</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>6:4</td>
<td class=kW>3:0</td>
<td class=br>50:88</td><td class=br>-38</td>
<td class=bc>4 - 0 - 17</td>
<td class=br><strong>8</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>C</td><td class=d>20.</td><td class=kt>Ja Kopecký</td><td class=kL>2:8</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>3:7</td>
<td class=kL>1:6</td>
<td class=kL>4:5</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=br>27:84</td><td class=br>-57</td>
<td class=bc>2 - 3 - 16</td>
<td class=br><strong>7</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>C</td><td class=d>21.</td><td class=kt>Da Hrachovec</td><td class=kL>1:8</td>
<td class=kL>0:3</td>
<td class=kL>1:9</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>0:1</td>
<td class=kL>0:11</td>
<td class=kL>2:4</td>
<td class=kL>0:7</td>
<td class=kW>5:4</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>1:6</td>
<td class=kL>4:6</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=br>29:101</td><td class=br>-72</td>
<td class=bc>2 - 1 - 18</td>
<td class=br><strong>5</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>C</td><td class=d>22.</td><td class=kt>Ja Kubica</td><td class=kL>0:12</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>0:8</td>
<td class=kL>0:3</td>
<td class=kL>0:10</td>
<td class=kL>1:7</td>
<td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kL>2:7</td>
<td class=kL>2:8</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=br>15:130</td><td class=br>-115</td>
<td class=bc>1 - 0 - 20</td>
<td class=br><strong>2</strong></td><td class=d>22.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Lu Černý</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Kubica</td><td class=bc>-</td><td class=blW>Ja Kopecký</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Lu Černý</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>11 : 0</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ro Hejda</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ja Kubica</td><td class=bc>-</td><td class=blW>Jo Gruncl</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Lu Černý</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ro Hejda</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ja Kubica</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Lu Černý</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Jo Gruncl</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=blW>Ji Kropáček</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ja Kubica</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Lu Černý</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ro Hejda</td><td class=bc>-</td><td class=bl>Ja Kubica</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Lu Černý</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ja Kubica</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Lu Černý</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ja Kubica</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Ro Hejda</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Jo Gruncl</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>An Ouřada</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Lu Černý</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ja Kubica</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ja Kubica</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Lu Černý</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ja Kopecký</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Ja Kubica</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Lu Černý</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>An Ouřada</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Ji Kropáček</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Ja Kubica</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Ro Hejda</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Lu Černý</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Ji Kropáček</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Ja Kubica</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Ro Hejda</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Lu Černý</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>An Ouřada</td><td class=bc>-</td><td class=bl>Ja Kubica</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Ro Hejda</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Lu Černý</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>Ja Kubica</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Lu Černý</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Lu Černý</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ja Kubica</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>6 : 7</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Lu Černý</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 11</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ja Kubica</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Lu Černý</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Jo Gruncl</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>8 : 7</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ja Kubica</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>Lu Černý</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Jo Gruncl</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ro Hejda</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ja Kubica</td><td class=bc>-</td><td class=blW>Lu Černý</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>An Ouřada</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Lu Černý</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ja Kubica</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 12</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Lu Černý</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ja Kubica</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Lu Černý</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 16</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ja Kubica</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Mi Kobrle</td><td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kW>5:2</td>
<td class=kW>7:5</td>
<td class=kW>7:3</td>
<td class=kW>5:4</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kW>9:2</td>
<td class=kW>4:2</td>
<td class=kW>7:3</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=kW>7:0</td>
<td class=kW>7:0</td>
<td class=kW>9:1</td>
<td class=kW>8:0</td>
<td class=kW>9:1</td>
<td class=br>126:38</td><td class=br>+88</td>
<td class=bc>21 - 0 - 0</td>
<td class=br><strong>42</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Kr Lebl</td><td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>8:1</td>
<td class=kW>5:4</td>
<td class=kW>9:0</td>
<td class=kW>9:0</td>
<td class=br>87:40</td><td class=br>+47</td>
<td class=bc>17 - 1 - 3</td>
<td class=br><strong>35</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Pa Plešák</td><td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>5:4</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kW>8:2</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>12:0</td>
<td class=br>98:47</td><td class=br>+51</td>
<td class=bc>15 - 3 - 3</td>
<td class=br><strong>33</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Kr Herold</td><td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>8:2</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kW>7:1</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=kW>8:0</td>
<td class=kW>6:0</td>
<td class=kW>8:0</td>
<td class=br>90:36</td><td class=br>+54</td>
<td class=bc>15 - 1 - 5</td>
<td class=br><strong>31</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ja Matýsek</td><td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>7:0</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>7:0</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=br>89:36</td><td class=br>+53</td>
<td class=bc>14 - 3 - 4</td>
<td class=br><strong>31</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Mi Kubica</td><td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kT>4:4</td>
<td class=kL>0:7</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kW>5:4</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>8:0</td>
<td class=br>70:57</td><td class=br>+13</td>
<td class=bc>12 - 2 - 7</td>
<td class=br><strong>26</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Vl Kraus</td><td class=kL>5:7</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:3</td>
<td class=kL>1:4</td>
<td class=kW>5:4</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>8:1</td>
<td class=br>72:55</td><td class=br>+17</td>
<td class=bc>12 - 2 - 7</td>
<td class=br><strong>26</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ad Kopřiva</td><td class=kL>3:7</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:4</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>8:1</td>
<td class=br>65:58</td><td class=br>+7</td>
<td class=bc>11 - 4 - 6</td>
<td class=br><strong>26</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Ma Ženíšek</td><td class=kL>4:5</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>3:6</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kL>4:6</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>8:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=kW>8:3</td>
<td class=kW>7:0</td>
<td class=br>84:59</td><td class=br>+25</td>
<td class=bc>11 - 2 - 8</td>
<td class=br><strong>24</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>Ji Vácha</td><td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kL>4:5</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kW>7:2</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>7:0</td>
<td class=br>71:57</td><td class=br>+14</td>
<td class=bc>12 - 0 - 9</td>
<td class=br><strong>24</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>A</td><td class=d>11.</td><td class=kt>Ma Klazar</td><td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>4:5</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kT>5:5</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>8:2</td>
<td class=kW>7:0</td>
<td class=kW>9:0</td>
<td class=br>78:55</td><td class=br>+23</td>
<td class=bc>9 - 3 - 9</td>
<td class=br><strong>21</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>A</td><td class=d>12.</td><td class=kt>Pe Fuchs</td><td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>6:4</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>8:2</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=br>66:55</td><td class=br>+11</td>
<td class=bc>9 - 3 - 9</td>
<td class=br><strong>21</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Mi Mašika</td><td class=kL>2:9</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kL>2:8</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kL>0:1</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kL>0:1</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>10:0</td>
<td class=br>55:52</td><td class=br>+3</td>
<td class=bc>10 - 0 - 11</td>
<td class=br><strong>20</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>B</td><td class=d>14.</td><td class=kt>Mi Ševr</td><td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kW>9:2</td>
<td class=kW>6:4</td>
<td class=kW>10:3</td>
<td class=kW>11:0</td>
<td class=br>72:57</td><td class=br>+15</td>
<td class=bc>8 - 3 - 10</td>
<td class=br><strong>19</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>B</td><td class=d>15.</td><td class=kt>Ma Košňar</td><td class=kL>3:7</td>
<td class=kL>3:4</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>2:8</td>
<td class=kL>2:7</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kL>0:1</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>10:0</td>
<td class=br>51:64</td><td class=br>-13</td>
<td class=bc>7 - 3 - 11</td>
<td class=br><strong>17</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>B</td><td class=d>16.</td><td class=kt>Hy Nechutný</td><td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>2:8</td>
<td class=kW>4:2</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kL>3:5</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kW>7:0</td>
<td class=br>48:60</td><td class=br>-12</td>
<td class=bc>7 - 2 - 12</td>
<td class=br><strong>16</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>B</td><td class=d>17.</td><td class=kt>Ja Ouřada</td><td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>1:7</td>
<td class=kL>0:7</td>
<td class=kL>2:5</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kT>5:5</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>6:0</td>
<td class=kT>1:1</td>
<td class=kW>9:1</td>
<td class=kW>10:2</td>
<td class=br>52:67</td><td class=br>-15</td>
<td class=bc>6 - 4 - 11</td>
<td class=br><strong>16</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>B</td><td class=d>18.</td><td class=kt>Vojta Kraus</td><td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kL>0:7</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>2:8</td>
<td class=kL>0:1</td>
<td class=kT>4:4</td>
<td class=kW>1:0</td>
<td class=kL>2:6</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=br>39:84</td><td class=br>-45</td>
<td class=bc>5 - 1 - 15</td>
<td class=br><strong>11</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>B</td><td class=d>19.</td><td class=kt>Ra Hrnčíř</td><td class=kL>0:7</td>
<td class=kL>1:8</td>
<td class=kL>3:5</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kT>4:4</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>2:9</td>
<td class=kL>0:3</td>
<td class=kW>5:3</td>
<td class=kL>0:6</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=br>40:95</td><td class=br>-55</td>
<td class=bc>4 - 1 - 16</td>
<td class=br><strong>9</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>C</td><td class=d>20.</td><td class=kt>Mi Ouřada</td><td class=kL>1:9</td>
<td class=kL>4:5</td>
<td class=kL>1:5</td>
<td class=kL>0:8</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>2:8</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>4:6</td>
<td class=kW>3:1</td>
<td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=br>36:92</td><td class=br>-56</td>
<td class=bc>3 - 2 - 16</td>
<td class=br><strong>8</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>C</td><td class=d>21.</td><td class=kt>Mi Horáková</td><td class=kL>0:8</td>
<td class=kL>0:9</td>
<td class=kL>2:7</td>
<td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>3:8</td>
<td class=kL>3:4</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>3:10</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>1:9</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>8:1</td>
<td class=br>37:113</td><td class=br>-76</td>
<td class=bc>2 - 2 - 17</td>
<td class=br><strong>6</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>C</td><td class=d>22.</td><td class=kt>Ro Kubinec</td><td class=kL>1:9</td>
<td class=kL>0:9</td>
<td class=kL>0:12</td>
<td class=kL>0:8</td>
<td class=kL>0:6</td>
<td class=kL>0:8</td>
<td class=kL>1:8</td>
<td class=kL>1:8</td>
<td class=kL>0:7</td>
<td class=kL>0:7</td>
<td class=kL>0:9</td>
<td class=kL>0:4</td>
<td class=kL>0:10</td>
<td class=kL>0:11</td>
<td class=kL>0:10</td>
<td class=kL>0:7</td>
<td class=kL>2:10</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>1:8</td>
<td class=kx>*</td>
<td class=br>10:159</td><td class=br>-149</td>
<td class=bc>0 - 0 - 21</td>
<td class=br><strong>0</strong></td><td class=d>22.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ro Kubinec</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Vojta Kraus</td><td class=bc>-</td><td class=bl>Mi Ouřada</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ro Kubinec</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Mi Ouřada</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ro Kubinec</td><td class=bc>11 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=bl>Mi Ouřada</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Vojta Kraus</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ro Kubinec</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=bl>Mi Ouřada</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ro Kubinec</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Ouřada</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ro Kubinec</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Ouřada</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ro Kubinec</td><td class=bc>-</td><td class=blW>Mi Ouřada</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Mi Ouřada</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ro Kubinec</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Mašika</td><td class=bc>-</td><td class=bl>Mi Ouřada</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ro Kubinec</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Ouřada</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ro Kubinec</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>10 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Mi Ouřada</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro Kubinec</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 12</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Ja Ouřada</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Ouřada</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Mašika</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Ja Ouřada</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro Kubinec</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Ouřada</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Ja Ouřada</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ro Kubinec</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Ouřada</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ro Kubinec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Vojta Kraus</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ja Ouřada</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Mi Ouřada</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>7 : 5</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Ro Kubinec</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Vojta Kraus</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mi Ouřada</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Mašika</td><td class=bc>-</td><td class=bl>Ro Kubinec</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Mi Ouřada</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ro Kubinec</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ja Ouřada</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Ro Kubinec</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Ouřada</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Vojta Kraus</td><td class=bc>-</td><td class=bl>Ro Kubinec</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Ouřada</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ro Kubinec</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Ouřada</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Ro Kubinec</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Mi Ouřada</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ja Ouřada</td><td class=bc>-</td><td class=bl>Ro Kubinec</td><td class=bc>10 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Mi Ouřada</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<hr><a name="final"><p class=vm>Výkonnostní skupiny (Final groups)</p></a>
<p class=v>Group A</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt>Mi Kobrle</td><td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>5:1 K</td>
<td class=kW>5:4 K</td>
<td class=kW>3:2</td>
<td class=kW>3:1 K</td>
<td class=kW>3:2 K</td>
<td class=kW>3:1</td>
<td class=kW>5:2 K</td>
<td class=kW>7:3 K</td>
<td class=kW>5:4 K</td>
<td class=kW>7:5 K</td>
<td class=kW>4:1 K</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=kW>6:2</td>
<td class=kW>5:2 K</td>
<td class=kT>3:3</td>
<td class=kW>5:3 K</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>8:2</td>
<td class=br>103:46</td><td class=br>+57</td>
<td class=bc>20 - 3 - 0</td>
<td class=br><strong>43</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt>Pa Petr</td><td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>8:0 K</td>
<td class=kW>5:1 K</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kW>4:3 K</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=kW>2:0 K</td>
<td class=kW>9:0</td>
<td class=kT>5:5</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>7:1 K</td>
<td class=kW>5:2 K</td>
<td class=kW>6:2 K</td>
<td class=kW>7:2</td>
<td class=kW>6:2 K</td>
<td class=kW>7:2</td>
<td class=kW>11:3 K</td>
<td class=kW>16:3 K</td>
<td class=kW>5:2 K</td>
<td class=br>135:37</td><td class=br>+98</td>
<td class=bc>20 - 2 - 1</td>
<td class=br><strong>42</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt>Mi Černoch</td><td class=kL>0:2</td>
<td class=kL>0:8 K</td>
<td class=kx>*</td>
<td class=kL>1:2 K</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kW>4:1 K</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kL>1:3 K</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>1:0 K</td>
<td class=kW>2:1 K</td>
<td class=kL>1:3 K</td>
<td class=kW>3:2</td>
<td class=kW>7:1 K</td>
<td class=kW>2:1</td>
<td class=kW>3:0 K</td>
<td class=kW>5:1 K</td>
<td class=kW>3:1 K</td>
<td class=br>59:43</td><td class=br>+16</td>
<td class=bc>15 - 2 - 6</td>
<td class=br><strong>32</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt>Ji Chylík ml.</td><td class=kT>2:2</td>
<td class=kL>1:5 K</td>
<td class=kW>2:1 K</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>1:2 K</td>
<td class=kW>5:0</td>
<td class=kL>0:3</td>
<td class=kW>2:1 K</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2 K</td>
<td class=kW>3:0 K</td>
<td class=kW>3:2</td>
<td class=kW>4:2 K</td>
<td class=kW>6:3</td>
<td class=kT>1:1 K</td>
<td class=kW>4:3 K</td>
<td class=kW>4:0 K</td>
<td class=br>64:47</td><td class=br>+17</td>
<td class=bc>13 - 5 - 5</td>
<td class=br><strong>31</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>Kr Lebl</td><td class=kL>1:5 K</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:2 K</td>
<td class=kW>5:1</td>
<td class=kL>2:5 K</td>
<td class=kW>2:1 K</td>
<td class=kW>2:1</td>
<td class=kW>5:1 K</td>
<td class=kW>3:0 K</td>
<td class=kW>4:3 K</td>
<td class=kL>2:3 K</td>
<td class=kW>4:1 K</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kW>5:4 K</td>
<td class=kW>2:1</td>
<td class=kW>3:1 K</td>
<td class=kW>2:1</td>
<td class=kL>5:6</td>
<td class=kW>5:3</td>
<td class=br>69:52</td><td class=br>+17</td>
<td class=bc>14 - 2 - 7</td>
<td class=br><strong>30</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>Ja Matýsek</td><td class=kL>4:5 K</td>
<td class=kL>2:5</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kL>2:4 K</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>2:2 K</td>
<td class=kL>2:3 K</td>
<td class=kW>4:3</td>
<td class=kW>7:0 K</td>
<td class=kT>2:2 K</td>
<td class=kW>5:2 K</td>
<td class=kW>6:2 K</td>
<td class=kL>3:4 K</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2 K</td>
<td class=kL>2:3</td>
<td class=kW>3:2 K</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=br>75:54</td><td class=br>+21</td>
<td class=bc>13 - 4 - 6</td>
<td class=br><strong>30</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Ku Sládek</td><td class=kL>2:3</td>
<td class=kL>3:4 K</td>
<td class=kL>1:4 K</td>
<td class=kW>2:1 K</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1 K</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>4:1 K</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1 K</td>
<td class=kW>2:1</td>
<td class=kL>2:4 K</td>
<td class=kL>1:2</td>
<td class=kW>4:1 K</td>
<td class=kW>5:1 K</td>
<td class=kL>1:4 K</td>
<td class=br>70:52</td><td class=br>+18</td>
<td class=bc>13 - 2 - 8</td>
<td class=br><strong>28</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>Pa Plešák</td><td class=kL>1:3 K</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kW>5:2 K</td>
<td class=kT>2:2 K</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>1:3 K</td>
<td class=kL>3:4</td>
<td class=kW>6:1 K</td>
<td class=kT>3:3 K</td>
<td class=kW>4:2 K</td>
<td class=kW>3:2 K</td>
<td class=kW>5:4 K</td>
<td class=kW>5:4</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>5:3 K</td>
<td class=kT>3:3</td>
<td class=kT>3:3 K</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=br>71:61</td><td class=br>+10</td>
<td class=bc>11 - 6 - 6</td>
<td class=br><strong>28</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>Kr Herold</td><td class=kL>2:3 K</td>
<td class=kL>0:6</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kL>1:2 K</td>
<td class=kW>3:2 K</td>
<td class=kL>2:3</td>
<td class=kW>3:1 K</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>4:4 K</td>
<td class=kL>2:3 K</td>
<td class=kW>2:0 K</td>
<td class=kW>4:2 K</td>
<td class=kL>1:3 K</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2 K</td>
<td class=kW>3:1</td>
<td class=kW>4:2 K</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=br>66:51</td><td class=br>+15</td>
<td class=bc>13 - 1 - 9</td>
<td class=br><strong>27</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Vá Pikl</td><td class=kL>1:3</td>
<td class=kL>0:2 K</td>
<td class=kW>3:1 K</td>
<td class=kL>1:2 K</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>1:4 K</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kL>1:5</td>
<td class=kL>0:4 K</td>
<td class=kL>0:5 K</td>
<td class=kT>2:2 K</td>
<td class=kW>3:2</td>
<td class=kW>4:0 K</td>
<td class=kW>4:0</td>
<td class=kW>5:0 K</td>
<td class=kW>3:1 K</td>
<td class=kT>3:3 K</td>
<td class=br>56:54</td><td class=br>+2</td>
<td class=bc>11 - 2 - 10</td>
<td class=br><strong>24</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>Mi Kubica</td><td class=kL>2:5 K</td>
<td class=kL>0:9</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>1:5 K</td>
<td class=kL>0:7 K</td>
<td class=kT>3:3</td>
<td class=kL>1:6 K</td>
<td class=kT>4:4 K</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>2:0 K</td>
<td class=kL>2:3 K</td>
<td class=kW>4:2 K</td>
<td class=kW>3:1 K</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kL>1:4 K</td>
<td class=kW>3:1</td>
<td class=kW>5:4 K</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=br>58:75</td><td class=br>-17</td>
<td class=bc>10 - 2 - 11</td>
<td class=br><strong>22</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>Ad Kopřiva</td><td class=kL>3:7 K</td>
<td class=kT>5:5</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>0:3 K</td>
<td class=kT>2:2 K</td>
<td class=kL>1:5</td>
<td class=kT>3:3 K</td>
<td class=kW>3:2 K</td>
<td class=kL>2:3</td>
<td class=kL>0:2 K</td>
<td class=kx>*</td>
<td class=kW>4:3 K</td>
<td class=kT>2:2 K</td>
<td class=kW>5:4 K</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kL>1:4 K</td>
<td class=kW>5:3</td>
<td class=kL>2:5 K</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=br>65:76</td><td class=br>-11</td>
<td class=bc>9 - 4 - 10</td>
<td class=br><strong>22</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt>Ma Ženíšek</td><td class=kL>4:5 K</td>
<td class=kL>0:6</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kL>3:4 K</td>
<td class=kL>2:5 K</td>
<td class=kL>2:5</td>
<td class=kL>2:4 K</td>
<td class=kL>0:2 K</td>
<td class=kL>2:4</td>
<td class=kW>3:2 K</td>
<td class=kL>3:4 K</td>
<td class=kx>*</td>
<td class=kL>3:6 K</td>
<td class=kW>6:1 K</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>4:1 K</td>
<td class=kL>0:5</td>
<td class=kL>4:6 K</td>
<td class=kW>5:2</td>
<td class=kW>7:3</td>
<td class=kW>5:2</td>
<td class=br>72:80</td><td class=br>-8</td>
<td class=bc>9 - 1 - 13</td>
<td class=br><strong>19</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt>Vl Kraus</td><td class=kL>5:7 K</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kW>3:2 K</td>
<td class=kL>2:6 K</td>
<td class=kL>3:5</td>
<td class=kL>2:3 K</td>
<td class=kL>2:4 K</td>
<td class=kL>1:4</td>
<td class=kL>2:4 K</td>
<td class=kT>2:2 K</td>
<td class=kW>6:3 K</td>
<td class=kx>*</td>
<td class=kL>1:4 K</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kW>5:4 K</td>
<td class=kL>2:5</td>
<td class=kW>3:2 K</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>5:4</td>
<td class=br>67:81</td><td class=br>-14</td>
<td class=bc>9 - 1 - 13</td>
<td class=br><strong>19</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt>Ji Vácha</td><td class=kL>1:4 K</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:4 K</td>
<td class=kW>4:3 K</td>
<td class=kL>1:5</td>
<td class=kL>4:5 K</td>
<td class=kW>3:1 K</td>
<td class=kW>5:1</td>
<td class=kL>1:3 K</td>
<td class=kL>4:5 K</td>
<td class=kL>1:6 K</td>
<td class=kW>4:1 K</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kL>1:5</td>
<td class=kL>1:5 K</td>
<td class=kL>2:5</td>
<td class=kW>5:0 K</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=br>56:69</td><td class=br>-13</td>
<td class=bc>9 - 1 - 13</td>
<td class=br><strong>19</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt>To Bucek</td><td class=kL>1:6</td>
<td class=kL>1:7 K</td>
<td class=kL>0:1 K</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>1:4 K</td>
<td class=kL>4:5</td>
<td class=kW>5:2</td>
<td class=kW>4:0 K</td>
<td class=kL>0:2</td>
<td class=kW>5:2</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=kW>3:0 K</td>
<td class=kT>1:1</td>
<td class=kL>3:4 K</td>
<td class=kW>5:1</td>
<td class=kL>0:1 K</td>
<td class=kT>4:4 K</td>
<td class=kW>8:3 K</td>
<td class=br>58:59</td><td class=br>-1</td>
<td class=bc>6 - 7 - 10</td>
<td class=br><strong>19</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Da Matýsek</td><td class=kL>2:7</td>
<td class=kL>2:5 K</td>
<td class=kL>1:2 K</td>
<td class=kT>2:2 K</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>5:0 K</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=kW>1:0 K</td>
<td class=kL>3:5</td>
<td class=kW>4:1 K</td>
<td class=kT>2:2</td>
<td class=kW>2:1 K</td>
<td class=kW>8:7 K</td>
<td class=kW>3:2 K</td>
<td class=br>54:66</td><td class=br>-12</td>
<td class=bc>7 - 5 - 11</td>
<td class=br><strong>19</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>St Srba</td><td class=kL>2:6</td>
<td class=kL>2:6 K</td>
<td class=kW>3:1 K</td>
<td class=kL>0:3 K</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>1:2 K</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2 K</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kL>0:3 K</td>
<td class=kL>0:1 K</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>3:2 K</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kL>1:5 K</td>
<td class=kW>2:1 K</td>
<td class=br>39:61</td><td class=br>-22</td>
<td class=bc>7 - 4 - 12</td>
<td class=br><strong>18</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Ma Klazar</td><td class=kL>2:5 K</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>4:5 K</td>
<td class=kL>2:3 K</td>
<td class=kL>1:2</td>
<td class=kL>3:5 K</td>
<td class=kL>2:4 K</td>
<td class=kL>2:3</td>
<td class=kW>4:1 K</td>
<td class=kW>4:1 K</td>
<td class=kL>1:4 K</td>
<td class=kL>4:5 K</td>
<td class=kW>5:1 K</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2 K</td>
<td class=kT>4:4</td>
<td class=kW>6:2</td>
<td class=kL>0:7</td>
<td class=br>62:72</td><td class=br>-10</td>
<td class=bc>7 - 3 - 13</td>
<td class=br><strong>17</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Al Krejza</td><td class=kT>3:3</td>
<td class=kL>2:6 K</td>
<td class=kL>1:7 K</td>
<td class=kL>2:4 K</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>4:2 K</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>0:4 K</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>4:3 K</td>
<td class=kL>1:4 K</td>
<td class=kL>2:3 K</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kT>1:1 K</td>
<td class=kL>1:4 K</td>
<td class=kW>5:3 K</td>
<td class=br>57:73</td><td class=br>-16</td>
<td class=bc>7 - 3 - 13</td>
<td class=br><strong>17</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Pe Fuchs</td><td class=kL>3:5 K</td>
<td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kL>3:6</td>
<td class=kL>1:3 K</td>
<td class=kL>2:3 K</td>
<td class=kW>2:1</td>
<td class=kT>3:3 K</td>
<td class=kL>2:4 K</td>
<td class=kL>0:4</td>
<td class=kL>4:5 K</td>
<td class=kW>5:2 K</td>
<td class=kW>6:4 K</td>
<td class=kL>2:3 K</td>
<td class=kL>0:5 K</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=br>52:79</td><td class=br>-27</td>
<td class=bc>5 - 4 - 14</td>
<td class=br><strong>14</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>To Kahoun ml.</td><td class=kL>2:5</td>
<td class=kL>3:11 K</td>
<td class=kL>0:3 K</td>
<td class=kT>1:1 K</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>1:4 K</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>0:5 K</td>
<td class=kW>4:3</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kW>1:0 K</td>
<td class=kL>1:2 K</td>
<td class=kT>2:2 K</td>
<td class=kT>4:4</td>
<td class=kT>1:1 K</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kT>4:4 K</td>
<td class=kT>3:3 K</td>
<td class=br>40:76</td><td class=br>-36</td>
<td class=bc>3 - 6 - 14</td>
<td class=br><strong>12</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Mi Uhlíř</td><td class=kL>0:3</td>
<td class=kL>3:16 K</td>
<td class=kL>1:5 K</td>
<td class=kL>3:4 K</td>
<td class=kW>6:5</td>
<td class=kL>1:2</td>
<td class=kL>1:5 K</td>
<td class=kL>1:7</td>
<td class=kL>1:7</td>
<td class=kL>1:3 K</td>
<td class=kL>1:2</td>
<td class=kL>2:7</td>
<td class=kL>3:7</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kT>4:4 K</td>
<td class=kL>7:8 K</td>
<td class=kW>5:1 K</td>
<td class=kL>2:6</td>
<td class=kW>4:1 K</td>
<td class=kW>3:1</td>
<td class=kT>4:4 K</td>
<td class=kx>*</td>
<td class=kW>5:3 K</td>
<td class=br>62:109</td><td class=br>-47</td>
<td class=bc>5 - 2 - 16</td>
<td class=br><strong>12</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Lu Černý</td><td class=kL>2:8</td>
<td class=kL>2:5 K</td>
<td class=kL>1:3 K</td>
<td class=kL>0:4 K</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kW>4:1 K</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kT>3:3 K</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kW>3:2</td>
<td class=kL>3:8 K</td>
<td class=kL>2:3 K</td>
<td class=kL>1:2 K</td>
<td class=kW>7:0</td>
<td class=kL>3:5 K</td>
<td class=kL>2:3</td>
<td class=kT>3:3 K</td>
<td class=kL>3:5 K</td>
<td class=kx>*</td>
<td class=br>55:92</td><td class=br>-37</td>
<td class=bc>3 - 2 - 18</td>
<td class=br><strong>8</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Lu Černý</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Lu Černý</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Lu Černý</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Lu Černý</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Lu Černý</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Lu Černý</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Lu Černý</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Lu Černý</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Lu Černý</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Lu Černý</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Lu Černý</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Lu Černý</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>1 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Mi Mašika</td><td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>5:0</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=br>37:28</td><td class=br>+9</td>
<td class=bc>8 - 3 - 2</td>
<td class=br><strong>19</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Ji Kropáček</td><td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>9:5</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=br>53:35</td><td class=br>+18</td>
<td class=bc>7 - 5 - 1</td>
<td class=br><strong>19</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Ro Hejda</td><td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kL>0:5</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>5:4</td>
<td class=br>46:33</td><td class=br>+13</td>
<td class=bc>8 - 3 - 2</td>
<td class=br><strong>19</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Mi Ševr</td><td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>9:0</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=br>46:24</td><td class=br>+22</td>
<td class=bc>7 - 4 - 2</td>
<td class=br><strong>18</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=d>5.</td><td class=kt>An Šurýn</td><td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=br>35:28</td><td class=br>+7</td>
<td class=bc>7 - 4 - 2</td>
<td class=br><strong>18</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=d>6.</td><td class=kt>Pe Holub</td><td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kW>5:0</td>
<td class=kW>5:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=br>45:29</td><td class=br>+16</td>
<td class=bc>7 - 2 - 4</td>
<td class=br><strong>16</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/4</td><td class=d>7.</td><td class=kt>Jo Perkner</td><td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=br>33:31</td><td class=br>+2</td>
<td class=bc>6 - 3 - 4</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/4</td><td class=d>8.</td><td class=kt>Hy Nechutný</td><td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=br>27:26</td><td class=br>+1</td>
<td class=bc>4 - 6 - 3</td>
<td class=br><strong>14</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Vojta Kraus</td><td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=br>38:30</td><td class=br>+8</td>
<td class=bc>7 - 0 - 6</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ja Ouřada</td><td class=kW>5:2</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>0:9</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=br>31:45</td><td class=br>-14</td>
<td class=bc>4 - 2 - 7</td>
<td class=br><strong>10</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Ma Košňar</td><td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=br>17:30</td><td class=br>-13</td>
<td class=bc>2 - 4 - 7</td>
<td class=br><strong>8</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>An Ouřada</td><td class=kL>2:3</td>
<td class=kL>5:9</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>4:5</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=br>29:47</td><td class=br>-18</td>
<td class=bc>3 - 0 - 10</td>
<td class=br><strong>6</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Jo Gruncl</td><td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kT>0:0</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=br>17:45</td><td class=br>-28</td>
<td class=bc>1 - 1 - 11</td>
<td class=br><strong>3</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Ra Hrnčíř</td><td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>4:5</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=br>18:41</td><td class=br>-23</td>
<td class=bc>1 - 1 - 11</td>
<td class=br><strong>3</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Mi Mašika</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>An Ouřada</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Mašika</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ro Hejda</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Vojta Kraus</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Jo Gruncl</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Vojta Kraus</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Ja Ouřada</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Mašika</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Ro Hejda</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Ja Ouřada</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Vojta Kraus</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Mi Mašika</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Vojta Kraus</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>An Ouřada</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ro Hejda</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Ro Hejda</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ro Hejda</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=blW>Ji Kropáček</td><td class=bc>5 : 9</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Ro Hejda</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ja Ouřada</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Ji Kropáček</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vojta Kraus</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>An Ouřada</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ji Kropáček</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ja Ouřada</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>An Ouřada</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ro Hejda</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Ji Kropáček</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=blW>Vojta Kraus</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ro Hejda</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ja Ouřada</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ro Hejda</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Vojta Kraus</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Mi Mašika</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>An Ouřada</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ro Hejda</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Ja Ouřada</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Da Hrachovec</td><td class=kx>*</td>
<td class=kT>4:4 + 3:2</td>
<td class=kW>4:3 + 5:1</td>
<td class=kW>5:2 + 9:1</td>
<td class=kW>3:0 + 8:0</td>
<td class=kW>9:2 + 12:1</td>
<td class=br>62:16</td><td class=br>+46</td>
<td class=bc>9 - 1 - 0</td>
<td class=br><strong>19</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Mi Ouřada</td><td class=kT>4:4 + 2:3</td>
<td class=kx>*</td>
<td class=kL>3:4 + 6:1</td>
<td class=kL>1:3 + 6:3</td>
<td class=kW>2:1 + 2:0</td>
<td class=kL>4:5 + 5:1</td>
<td class=br>35:25</td><td class=br>+10</td>
<td class=bc>5 - 1 - 4</td>
<td class=br><strong>11</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Mi Horáková</td><td class=kL>3:4 + 1:5</td>
<td class=kW>4:3 + 1:6</td>
<td class=kx>*</td>
<td class=kT>1:1 + 2:5</td>
<td class=kW>5:2 + 3:2</td>
<td class=kW>6:1 + 8:0</td>
<td class=br>34:29</td><td class=br>+5</td>
<td class=bc>5 - 1 - 4</td>
<td class=br><strong>11</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Ja Kopecký</td><td class=kL>2:5 + 1:9</td>
<td class=kW>3:1 + 3:6</td>
<td class=kT>1:1 + 5:2</td>
<td class=kx>*</td>
<td class=kL>1:2 + 2:2</td>
<td class=kW>5:0 + 5:2</td>
<td class=br>28:30</td><td class=br>-2</td>
<td class=bc>4 - 2 - 4</td>
<td class=br><strong>10</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=d>5.</td><td class=kt>Ja Kubica</td><td class=kL>0:3 + 0:8</td>
<td class=kL>1:2 + 0:2</td>
<td class=kL>2:5 + 2:3</td>
<td class=kW>2:1 + 2:2</td>
<td class=kx>*</td>
<td class=kT>1:1 + 0:0</td>
<td class=br>10:27</td><td class=br>-17</td>
<td class=bc>1 - 3 - 6</td>
<td class=br><strong>5</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=d>6.</td><td class=kt>Ro Kubinec</td><td class=kL>2:9 + 1:12</td>
<td class=kW>5:4 + 1:5</td>
<td class=kL>1:6 + 0:8</td>
<td class=kL>0:5 + 2:5</td>
<td class=kT>1:1 + 0:0</td>
<td class=kx>*</td>
<td class=br>13:55</td><td class=br>-42</td>
<td class=bc>1 - 2 - 7</td>
<td class=br><strong>4</strong></td><td class=d>6.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ja Kopecký</td><td class=bc>-</td><td class=bl>Ro Kubinec</td><td class=bc>5 : 0 + 5 : 2</tr></td>
<tr><td class=brW>Mi Ouřada</td><td class=bc>-</td><td class=bl>Ja Kubica</td><td class=bc>2 : 1 + 2 : 0</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 3 + 5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ro Kubinec</td><td class=bc>-</td><td class=bl>Ja Kubica</td><td class=bc>1 : 1 + 0 : 0</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>1 : 1 + 5 : 2</tr></td>
<tr><td class=br>Mi Ouřada</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>4 : 4 + 2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ja Kubica</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>2 : 5 + 2 : 3</tr></td>
<tr><td class=br>Ro Kubinec</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>2 : 9 + 1 : 12</tr></td>
<tr><td class=brW>Ja Kopecký</td><td class=bc>-</td><td class=bl>Mi Ouřada</td><td class=bc>3 : 1 + 3 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Mi Ouřada</td><td class=bc>4 : 3 + 1 : 6</tr></td>
<tr><td class=brW>Ja Kubica</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>2 : 1 + 2 : 2</tr></td>
<tr><td class=br>Ro Kubinec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>5 : 2 + 9 : 1</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Ro Kubinec</td><td class=bc>6 : 1 + 8 : 0</tr></td>
<tr><td class=br>Ja Kubica</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Mi Ouřada</td><td class=bc>-</td><td class=blW>Ro Kubinec</td><td class=bc>4 : 5 + 5 : 1</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Ja Kubica</td><td class=bc>3 : 0 + 8 : 0</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
