<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR veteráni</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../mrv">MR veteráni, 28. květen 2023</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<p class=v>Group V1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=64&x=-397&p=Da%20%C5%A0m%C3%ADd">Da Šmíd</a></td><td class=ic>CZE</td><td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>5:6</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=br>41:20</td><td class=br>+21</td>
<td class=bc>9 - 1 - 2</td>
<td class=br><strong>19</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=248&x=-397&p=Ma%20%C5%BDen%C3%AD%C5%A1ek">Ma Ženíšek</a></td><td class=ic>CZE</td><td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kW>8:3</td>
<td class=br>48:29</td><td class=br>+19</td>
<td class=bc>9 - 0 - 3</td>
<td class=br><strong>18</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=261&x=-397&p=Da%20Cibulka">Da Cibulka</a></td><td class=ic>CZE</td><td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>8:0</td>
<td class=kW>9:0</td>
<td class=br>41:18</td><td class=br>+23</td>
<td class=bc>8 - 1 - 3</td>
<td class=br><strong>17</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=4&x=-397&p=Vl%20Kraus">Vl Kraus</a></td><td class=ic>CZE</td><td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=br>35:23</td><td class=br>+12</td>
<td class=bc>6 - 3 - 3</td>
<td class=br><strong>15</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1630&x=-397&p=Pe%20Holub">Pe Holub</a></td><td class=ic>CZE</td><td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kT>5:5</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>9:1</td>
<td class=br>42:32</td><td class=br>+10</td>
<td class=bc>6 - 2 - 4</td>
<td class=br><strong>14</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=41&x=-397&p=Da%20Hrachovec">Da Hrachovec</a></td><td class=ic>CZE</td><td class=kL>1:6</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kL>1:6</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kW>9:2</td>
<td class=br>34:31</td><td class=br>+3</td>
<td class=bc>6 - 2 - 4</td>
<td class=br><strong>14</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=40&x=-397&p=Da%20Mat%C3%BDsek">Da Matýsek</a></td><td class=ic>CZE</td><td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kW>6:1</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kW>10:1</td>
<td class=br>44:24</td><td class=br>+20</td>
<td class=bc>5 - 3 - 4</td>
<td class=br><strong>13</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=176&x=-397&p=Zd%20Lopaur">Zd Lopaur</a></td><td class=ic>CZE</td><td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kL>1:7</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>9:1</td>
<td class=br>36:35</td><td class=br>+1</td>
<td class=bc>5 - 2 - 5</td>
<td class=br><strong>12</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1318&x=-397&p=Jo%20Sedl%C3%A1%C4%8Dek">Jo Sedláček</a></td><td class=ic>CZE</td><td class=kW>6:5</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>3:6</td>
<td class=kT>5:5</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=br>38:41</td><td class=br>-3</td>
<td class=bc>4 - 4 - 4</td>
<td class=br><strong>12</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=70&x=-397&p=St%20Srba">St Srba</a></td><td class=ic>CZE</td><td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>1:0</td>
<td class=kW>9:1</td>
<td class=br>30:27</td><td class=br>+3</td>
<td class=bc>4 - 3 - 5</td>
<td class=br><strong>11</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=227&x=-397&p=Mi%20Ma%C5%A1ika">Mi Mašika</a></td><td class=ic>CZE</td><td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kW>6:1</td>
<td class=br>19:34</td><td class=br>-15</td>
<td class=bc>2 - 2 - 8</td>
<td class=br><strong>6</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=204&x=-397&p=Hy%20Nechutn%C3%BD">Hy Nechutný</a></td><td class=ic>CZE</td><td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>0:8</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=br>17:34</td><td class=br>-17</td>
<td class=bc>1 - 3 - 8</td>
<td class=br><strong>5</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1985&x=-397&p=Vl%20Fiedler">Vl Fiedler</a></td><td class=ic>CZE</td><td class=kL>0:6</td>
<td class=kL>3:8</td>
<td class=kL>0:9</td>
<td class=kL>0:6</td>
<td class=kL>1:9</td>
<td class=kL>2:9</td>
<td class=kL>1:10</td>
<td class=kL>1:9</td>
<td class=kL>2:5</td>
<td class=kL>1:9</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=br>13:90</td><td class=br>-77</td>
<td class=bc>0 - 0 - 12</td>
<td class=br><strong>0</strong></td><td class=d>13.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Vl Fiedler</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Vl Fiedler</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Vl Fiedler</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Vl Fiedler</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>2 : 9</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Vl Fiedler</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Vl Fiedler</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vl Fiedler</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>5 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Vl Fiedler</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vl Fiedler</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Vl Fiedler</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Vl Fiedler</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Da Hrachovec</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Vl Fiedler</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>2 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group V2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=310&x=-397&p=Mi%20%C4%8Cernoch">Mi Černoch</a></td><td class=ic>CZE</td><td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kL>0:6</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kW>6:3</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=br>37:18</td><td class=br>+19</td>
<td class=bc>7 - 3 - 1</td>
<td class=br><strong>17</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=32&x=-397&p=Ji%20Krop%C3%A1%C4%8Dek">Ji Kropáček</a></td><td class=ic>CZE</td><td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>5:4</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>8:2</td>
<td class=br>47:27</td><td class=br>+20</td>
<td class=bc>8 - 1 - 2</td>
<td class=br><strong>17</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1&x=-397&p=Pa%20Ple%C5%A1%C3%A1k">Pa Plešák</a></td><td class=ic>CZE</td><td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=kW>7:2</td>
<td class=br>45:19</td><td class=br>+26</td>
<td class=bc>8 - 1 - 2</td>
<td class=br><strong>17</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=201&x=-397&p=To%20Bucek">To Bucek</a></td><td class=ic>CZE</td><td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kW>8:1</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=br>40:14</td><td class=br>+26</td>
<td class=bc>6 - 3 - 2</td>
<td class=br><strong>15</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=818&x=-397&p=Ro%20Je%C5%BE">Ro Jež</a></td><td class=ic>CZE</td><td class=kW>6:0</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=br>40:26</td><td class=br>+14</td>
<td class=bc>7 - 0 - 4</td>
<td class=br><strong>14</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=53&x=-397&p=V%C3%A1%20Pikl">Vá Pikl</a></td><td class=ic>CZE</td><td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>9:1</td>
<td class=kW>5:1</td>
<td class=br>36:24</td><td class=br>+12</td>
<td class=bc>6 - 2 - 3</td>
<td class=br><strong>14</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1912&x=-397&p=Al%20Krejza">Al Krejza</a></td><td class=ic>CZE</td><td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>8:1</td>
<td class=br>40:20</td><td class=br>+20</td>
<td class=bc>6 - 2 - 3</td>
<td class=br><strong>14</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=10&x=-397&p=Ja%20Medvec">Ja Medvec</a></td><td class=ic>CZE</td><td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>1:8</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>11:4</td>
<td class=br>34:39</td><td class=br>-5</td>
<td class=bc>3 - 2 - 6</td>
<td class=br><strong>8</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1058&x=-397&p=Fr%20Marek">Fr Marek</a></td><td class=ic>CZE</td><td class=kL>0:4</td>
<td class=kL>4:5</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=br>25:41</td><td class=br>-16</td>
<td class=bc>3 - 0 - 8</td>
<td class=br><strong>6</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=89&x=-397&p=Jo%20Gruncl">Jo Gruncl</a></td><td class=ic>CZE</td><td class=kL>0:7</td>
<td class=kL>3:4</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>8:1</td>
<td class=br>23:46</td><td class=br>-23</td>
<td class=bc>3 - 0 - 8</td>
<td class=br><strong>6</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1896&x=-397&p=Ra%20Hrn%C4%8D%C3%AD%C5%99">Ra Hrnčíř</a></td><td class=ic>CZE</td><td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>0:7</td>
<td class=kL>1:9</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=br>16:55</td><td class=br>-39</td>
<td class=bc>1 - 1 - 9</td>
<td class=br><strong>3</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1626&x=-397&p=Mi%20Hor%C3%A1kov%C3%A1">Mi Horáková</a></td><td class=ic>CZE</td><td class=kL>1:4</td>
<td class=kL>2:8</td>
<td class=kL>2:7</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:8</td>
<td class=kL>4:11</td>
<td class=kL>0:5</td>
<td class=kL>1:8</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=br>18:72</td><td class=br>-54</td>
<td class=bc>0 - 1 - 10</td>
<td class=br><strong>1</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Jo Gruncl</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ji Kropáček</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ja Medvec</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>11 : 4</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ja Medvec</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Ji Kropáček</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Ja Medvec</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ji Kropáček</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Jo Gruncl</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Ji Kropáček</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Jo Gruncl</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Jo Gruncl</td><td class=bc>-</td><td class=blW>Ji Kropáček</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ja Medvec</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Jo Gruncl</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ja Medvec</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>1 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
