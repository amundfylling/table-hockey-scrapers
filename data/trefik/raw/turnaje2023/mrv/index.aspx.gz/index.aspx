<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR veteráni</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>MR veteráni, 28. květen 2023</span></h2></div></div></div></div><p><div align="center">
<div align=center>
<a href="kriz.aspx">Zápasy ve skupinách (Basic and placement groups)</a><br>
<a href="MR_veterani_playoff.aspx ">Zápasy o umístění (Placement matches)</a><br>
<a href="utokturnaje.aspx">Tabulka útočníků (Best forwards)</a><br>
<a href="obranaturnaje.aspx">Tabulka obránců (Best defenders)</a><br>
</div>
<table border=0 cellpadding=2 cellspacing=0 class="rnk">
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">M</th>
<th align="center">+</th>
<th align="center">=</th>
<th align="center">-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1&x=-397&p=Pavel%20Ple%C5%A1%C3%A1k">Pavel Plešák</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>23</td>
<td class=ar>17</td>
<td class=ar>1</td>
<td class=ar>5</td>
<td class=ar>91</td>
<td class=al>&nbsp;:&nbsp;55</td>
</tr><tr><td class=br>2.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=64&x=-397&p=David%20%C5%A0m%C3%ADd">David Šmíd</a></td>
<td class=bl>THC Stiga Elites</td>
<td class=br>23</td>
<td class=br>16</td>
<td class=br>1</td>
<td class=br>6</td>
<td class=br>71</td>
<td class=bl>&nbsp;:&nbsp;44</td>
</tr><tr><td class=ar>3.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=4&x=-397&p=Vladim%C3%ADr%20Kraus">Vladimír Kraus</a></td>
<td class=al>Rokycany</td>
<td class=ar>25</td>
<td class=ar>14</td>
<td class=ar>3</td>
<td class=ar>8</td>
<td class=ar>69</td>
<td class=al>&nbsp;:&nbsp;52</td>
</tr><tr><td class=br>4.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=261&x=-397&p=David%20Cibulka">David Cibulka</a></td>
<td class=bl>THC Třinec</td>
<td class=br>24</td>
<td class=br>12</td>
<td class=br>1</td>
<td class=br>11</td>
<td class=br>72</td>
<td class=bl>&nbsp;:&nbsp;51</td>
</tr><tr><td class=ar>5.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=310&x=-397&p=Miroslav%20%C4%8Cernoch">Miroslav Černoch</a></td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>16</td>
<td class=ar>9</td>
<td class=ar>3</td>
<td class=ar>4</td>
<td class=ar>45</td>
<td class=al>&nbsp;:&nbsp;28</td>
</tr><tr><td class=br>6.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=248&x=-397&p=Martin%20%C5%BDen%C3%AD%C5%A1ek">Martin Ženíšek</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>15</td>
<td class=br>9</td>
<td class=br>0</td>
<td class=br>6</td>
<td class=br>55</td>
<td class=bl>&nbsp;:&nbsp;42</td>
</tr><tr><td class=ar>7.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=32&x=-397&p=Ji%C5%99%C3%AD%20Krop%C3%A1%C4%8Dek">Jiří Kropáček</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>16</td>
<td class=ar>10</td>
<td class=ar>1</td>
<td class=ar>5</td>
<td class=ar>62</td>
<td class=al>&nbsp;:&nbsp;49</td>
</tr><tr><td class=br>8.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=201&x=-397&p=Tom%C3%A1%C5%A1%20Bucek">Tomáš Bucek</a></td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>14</td>
<td class=br>6</td>
<td class=br>3</td>
<td class=br>5</td>
<td class=br>43</td>
<td class=bl>&nbsp;:&nbsp;21</td>
</tr><tr><td class=ar>9.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=818&x=-397&p=Robert%20Je%C5%BE">Robert Jež</a></td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>11</td>
<td class=ar>7</td>
<td class=ar>0</td>
<td class=ar>4</td>
<td class=ar>40</td>
<td class=al>&nbsp;:&nbsp;26</td>
</tr><tr><td class=br>10.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1630&x=-397&p=Petr%20Holub">Petr Holub</a></td>
<td class=bl>SHC Cheb</td>
<td class=br>12</td>
<td class=br>6</td>
<td class=br>2</td>
<td class=br>4</td>
<td class=br>42</td>
<td class=bl>&nbsp;:&nbsp;32</td>
</tr><tr><td class=ar>11.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=53&x=-397&p=V%C3%A1clav%20Pikl">Václav Pikl</a></td>
<td class=al>THC Stiga Elites</td>
<td class=ar>11</td>
<td class=ar>6</td>
<td class=ar>2</td>
<td class=ar>3</td>
<td class=ar>36</td>
<td class=al>&nbsp;:&nbsp;24</td>
</tr><tr><td class=br>12.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=41&x=-397&p=Daniel%20Hrachovec">Daniel Hrachovec</a></td>
<td class=bl>SHC Cheb</td>
<td class=br>12</td>
<td class=br>6</td>
<td class=br>2</td>
<td class=br>4</td>
<td class=br>34</td>
<td class=bl>&nbsp;:&nbsp;31</td>
</tr><tr><td class=ar>13.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1912&x=-397&p=Ale%C5%A1%20Krejza">Aleš Krejza</a></td>
<td class=al>THC Třinec</td>
<td class=ar>11</td>
<td class=ar>6</td>
<td class=ar>2</td>
<td class=ar>3</td>
<td class=ar>40</td>
<td class=al>&nbsp;:&nbsp;20</td>
</tr><tr><td class=br>14.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=40&x=-397&p=Daniel%20Mat%C3%BDsek">Daniel Matýsek</a></td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>12</td>
<td class=br>5</td>
<td class=br>3</td>
<td class=br>4</td>
<td class=br>44</td>
<td class=bl>&nbsp;:&nbsp;24</td>
</tr><tr><td class=ar>15.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=176&x=-397&p=Zden%C4%9Bk%20Lopaur">Zdeněk Lopaur</a></td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>12</td>
<td class=ar>5</td>
<td class=ar>2</td>
<td class=ar>5</td>
<td class=ar>36</td>
<td class=al>&nbsp;:&nbsp;35</td>
</tr><tr><td class=br>16.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=10&x=-397&p=Jan%20Medvec">Jan Medvec</a></td>
<td class=bl>SHC Cheb</td>
<td class=br>11</td>
<td class=br>3</td>
<td class=br>2</td>
<td class=br>6</td>
<td class=br>34</td>
<td class=bl>&nbsp;:&nbsp;39</td>
</tr><tr><td class=ar>17.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1318&x=-397&p=Josef%20Sedl%C3%A1%C4%8Dek">Josef Sedláček</a></td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>12</td>
<td class=ar>4</td>
<td class=ar>4</td>
<td class=ar>4</td>
<td class=ar>38</td>
<td class=al>&nbsp;:&nbsp;41</td>
</tr><tr><td class=br>18.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1058&x=-397&p=Franti%C5%A1ek%20Marek">František Marek</a></td>
<td class=bl>BSE United</td>
<td class=br>11</td>
<td class=br>3</td>
<td class=br>0</td>
<td class=br>8</td>
<td class=br>25</td>
<td class=bl>&nbsp;:&nbsp;41</td>
</tr><tr><td class=ar>19.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=70&x=-397&p=Stanislav%20Srba">Stanislav Srba</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>12</td>
<td class=ar>4</td>
<td class=ar>3</td>
<td class=ar>5</td>
<td class=ar>30</td>
<td class=al>&nbsp;:&nbsp;27</td>
</tr><tr><td class=br>20.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=89&x=-397&p=Josef%20Gruncl">Josef Gruncl</a></td>
<td class=bl>SHC Cheb</td>
<td class=br>11</td>
<td class=br>3</td>
<td class=br>0</td>
<td class=br>8</td>
<td class=br>23</td>
<td class=bl>&nbsp;:&nbsp;46</td>
</tr><tr><td class=ar>21.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=227&x=-397&p=Michal%20Ma%C5%A1ika">Michal Mašika</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>12</td>
<td class=ar>2</td>
<td class=ar>2</td>
<td class=ar>8</td>
<td class=ar>19</td>
<td class=al>&nbsp;:&nbsp;34</td>
</tr><tr><td class=br>22.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1896&x=-397&p=Radek%20Hrn%C4%8D%C3%AD%C5%99">Radek Hrnčíř</a></td>
<td class=bl>Big Band</td>
<td class=br>11</td>
<td class=br>1</td>
<td class=br>1</td>
<td class=br>9</td>
<td class=br>16</td>
<td class=bl>&nbsp;:&nbsp;55</td>
</tr><tr><td class=ar>23.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=204&x=-397&p=Hynek%20Nechutn%C3%BD">Hynek Nechutný</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>12</td>
<td class=ar>1</td>
<td class=ar>3</td>
<td class=ar>8</td>
<td class=ar>17</td>
<td class=al>&nbsp;:&nbsp;34</td>
</tr><tr><td class=br>24.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1626&x=-397&p=Miroslava%20Hor%C3%A1kov%C3%A1">Miroslava Horáková</a></td>
<td class=bl>SHC Cheb</td>
<td class=br>11</td>
<td class=br>0</td>
<td class=br>1</td>
<td class=br>10</td>
<td class=br>18</td>
<td class=bl>&nbsp;:&nbsp;72</td>
</tr><tr><td class=ar>25.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1985&x=-397&p=Vladim%C3%ADr%20Fiedler">Vladimír Fiedler</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>12</td>
<td class=ar>0</td>
<td class=ar>0</td>
<td class=ar>12</td>
<td class=ar>13</td>
<td class=al>&nbsp;:&nbsp;90</td>
</tr></table></td></tr></table></div></p>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
