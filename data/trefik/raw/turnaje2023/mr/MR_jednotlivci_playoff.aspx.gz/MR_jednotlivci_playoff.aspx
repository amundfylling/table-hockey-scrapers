<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR jednotlivci</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../mr">Play-Off</a></span></h2></div></div></div></div><p><div align="center">
<table border=0 cellpadding=2 cellspacing=0>
<tr><th colspan=11 class="hh"><font size="+1"><strong>Finals</strong></font></th></tr>
<tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=409&x=-398&p=Petr%20Patrik">Petr Patrik</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=1477&x=-398&p=Kobrle%20Michal"><b>Kobrle Michal</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;1 : 4&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:8&nbsp;&nbsp;</td>
<td class=bl>4:8&nbsp;&nbsp;</td>
<td class=bl>7:2&nbsp;&nbsp;</td>
<td class=bl>4:5 P&nbsp;&nbsp;</td>
<td class=bl>4:7&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>1/2</strong></font></th></tr>
<tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=409&x=-398&p=Petr%20Patrik"><b>Petr Patrik</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=567&x=-398&p=Lebl%20Kry%C5%A1tof">Lebl Kryštof</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>6:2&nbsp;&nbsp;</td>
<td class=al>5:3&nbsp;&nbsp;</td>
<td class=al>4:3 P&nbsp;&nbsp;</td>
<td class=al>4:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=993&x=-398&p=Chyl%C3%ADk%20ml.%20Ji%C5%99%C3%AD">Chylík ml. Jiří</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=1477&x=-398&p=Kobrle%20Michal"><b>Kobrle Michal</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;1 : 4&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:5&nbsp;&nbsp;</td>
<td class=bl>5:2&nbsp;&nbsp;</td>
<td class=bl>5:6 P&nbsp;&nbsp;</td>
<td class=bl>2:3&nbsp;&nbsp;</td>
<td class=bl>2:6&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>3rd</strong></font></th></tr>
<tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=993&x=-398&p=Chyl%C3%ADk%20ml.%20Ji%C5%99%C3%AD"><b>Chylík ml. Jiří</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=567&x=-398&p=Lebl%20Kry%C5%A1tof">Lebl Kryštof</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>3:1&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>4:3&nbsp;&nbsp;</td>
<td class=al>2:0&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>1/4</strong></font></th></tr>
<tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=409&x=-398&p=Petr%20Patrik"><b>Petr Patrik</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=1065&x=-398&p=Herold%20Kry%C5%A1tof">Herold Kryštof</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>5:1&nbsp;&nbsp;</td>
<td class=bl>8:0&nbsp;&nbsp;</td>
<td class=bl>6:1&nbsp;&nbsp;</td>
<td class=bl>5:1&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=961&x=-398&p=Bo%C5%A1t%C3%ADk%20Michal">Boštík Michal</a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=567&x=-398&p=Lebl%20Kry%C5%A1tof"><b>Lebl Kryštof</b></a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;2 : 4&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:6&nbsp;&nbsp;</td>
<td class=al>4:5 P&nbsp;&nbsp;</td>
<td class=al>2:3 P&nbsp;&nbsp;</td>
<td class=al>4:3&nbsp;&nbsp;</td>
<td class=al>4:2&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=1477&x=-398&p=Kobrle%20Michal"><b>Kobrle Michal</b></a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=1&x=-398&p=Ple%C5%A1%C3%A1k%20Pavel">Plešák Pavel</a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>4:0&nbsp;&nbsp;</td>
<td class=bl>4:0&nbsp;&nbsp;</td>
<td class=bl>5:4 P&nbsp;&nbsp;</td>
<td class=bl>5:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=993&x=-398&p=Chyl%C3%ADk%20ml.%20Ji%C5%99%C3%AD"><b>Chylík ml. Jiří</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=1641&x=-398&p=Klazar%20Maty%C3%A1%C5%A1">Klazar Matyáš</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>0:5&nbsp;&nbsp;</td>
<td class=al>2:3 P&nbsp;&nbsp;</td>
<td class=al>4:5 P&nbsp;&nbsp;</td>
<td class=al>4:1&nbsp;&nbsp;</td>
<td class=al>4:2&nbsp;&nbsp;</td>
<td class=al>3:2 P&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>O 19. místo</strong></font></th></tr>
<tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=53&x=-398&p=Pikl%20V%C3%A1clav">Pikl Václav</a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=4&x=-398&p=Kraus%20Vladim%C3%ADr"><b>Kraus Vladimír</b></a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;1 : 2&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:1&nbsp;&nbsp;</td>
<td class=al>0:2&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>O 21. místo</strong></font></th></tr>
<tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=1927&x=-398&p=Kraus%20Vojt%C4%9Bch">Kraus Vojtěch</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=70&x=-398&p=Srba%20Stanislav"><b>Srba Stanislav</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;1 : 2&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>0:4&nbsp;&nbsp;</td>
<td class=bl>2:1&nbsp;&nbsp;</td>
<td class=bl>1:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>O 23. místo</strong></font></th></tr>
<tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=204&x=-398&p=Nechutn%C3%BD%20Hynek"><b>Nechutný Hynek</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=176&x=-398&p=Lopaur%20Zden%C4%9Bk">Lopaur Zdeněk</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;2 : 1&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>0:2&nbsp;&nbsp;</td>
<td class=al>3:2 P&nbsp;&nbsp;</td>
<td class=al>3:2 P&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>O 25. místo</strong></font></th></tr>
<tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=1058&x=-398&p=Marek%20Franti%C5%A1ek">Marek František</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=1318&x=-398&p=Sedl%C3%A1%C4%8Dek%20Josef"><b>Sedláček Josef</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;0 : 2&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:4&nbsp;&nbsp;</td>
<td class=bl>1:2 P&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>O 27. místo</strong></font></th></tr>
<tr><td class=ar><a href="../../../thstats/overview_b.aspx?idpl=818&x=-398&p=Je%C5%BE%20Robert"><b>Jež Robert</b></a>&nbsp;&nbsp;</td>
<td class=al>- <a href="../../../thstats/overview_b.aspx?idpl=1940&x=-398&p=Ko%C5%A1%C5%88ar%20Martin">Košňar Martin</a>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;2 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>4:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>O 29. místo</strong></font></th></tr>
<tr><td class=br><a href="../../../thstats/overview_b.aspx?idpl=1626&x=-398&p=Hor%C3%A1kov%C3%A1%20Miroslava">Horáková Miroslava</a>&nbsp;&nbsp;</td>
<td class=bl>- <a href="../../../thstats/overview_b.aspx?idpl=41&x=-398&p=Hrachovec%20Daniel"><b>Hrachovec Daniel</b></a>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;0 : 2&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:5&nbsp;&nbsp;</td>
<td class=bl>2:9&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
