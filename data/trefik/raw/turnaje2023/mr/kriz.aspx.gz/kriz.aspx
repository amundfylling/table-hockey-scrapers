<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR jednotlivci</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../mr">MR jednotlivci, 28. květen 2023</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Základní skupiny (Basic groups)</a><br>
<a href="#final">Výkonnostní skupiny (Final groups)</a><br>
<a name="basic"><p class=vm>Základní skupiny (Basic groups)</p></a>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=409&x=-398&p=Pa%20Petr">Pa Petr</a></td><td class=ic>CZE</td><td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kW>7:2</td>
<td class=kW>7:3</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=kW>8:4</td>
<td class=kW>4:1</td>
<td class=kW>9:1</td>
<td class=kW>10:0</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=kW>19:0</td>
<td class=kW>11:0</td>
<td class=kW>11:1</td>
<td class=br>117:22</td><td class=br>+95</td>
<td class=bc>14 - 2 - 0</td>
<td class=br><strong>30</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=961&x=-398&p=Mi%20Bo%C5%A1t%C3%ADk">Mi Boštík</a></td><td class=ic>CZE</td><td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>10:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=br>63:22</td><td class=br>+41</td>
<td class=bc>10 - 6 - 0</td>
<td class=br><strong>26</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1&x=-398&p=Pa%20Ple%C5%A1%C3%A1k">Pa Plešák</a></td><td class=ic>CZE</td><td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>10:4</td>
<td class=kW>2:1</td>
<td class=kW>6:4</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=br>70:37</td><td class=br>+33</td>
<td class=bc>11 - 4 - 1</td>
<td class=br><strong>26</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=567&x=-398&p=Kr%20Lebl">Kr Lebl</a></td><td class=ic>CZE</td><td class=kL>4:5</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kT>0:0</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>8:1</td>
<td class=kW>3:0</td>
<td class=kW>9:0</td>
<td class=br>66:29</td><td class=br>+37</td>
<td class=bc>11 - 2 - 3</td>
<td class=br><strong>24</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=101&x=-398&p=Mi%20Kubica">Mi Kubica</a></td><td class=ic>CZE</td><td class=kL>2:7</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kW>7:4</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>8:2</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=br>61:34</td><td class=br>+27</td>
<td class=bc>10 - 3 - 3</td>
<td class=br><strong>23</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=318&x=-398&p=Ji%20V%C3%A1cha">Ji Vácha</a></td><td class=ic>CZE</td><td class=kL>3:7</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>8:2</td>
<td class=kW>7:3</td>
<td class=br>52:40</td><td class=br>+12</td>
<td class=bc>10 - 0 - 6</td>
<td class=br><strong>20</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1641&x=-398&p=Ma%20Klazar">Ma Klazar</a></td><td class=ic>CZE</td><td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=br>48:36</td><td class=br>+12</td>
<td class=bc>8 - 4 - 4</td>
<td class=br><strong>20</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1876&x=-398&p=Ad%20Kop%C5%99iva">Ad Kopřiva</a></td><td class=ic>CZE</td><td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>7:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kW>6:4</td>
<td class=kW>5:1</td>
<td class=kW>10:0</td>
<td class=kW>3:0</td>
<td class=kW>9:1</td>
<td class=br>57:41</td><td class=br>+16</td>
<td class=bc>8 - 3 - 5</td>
<td class=br><strong>19</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1599&x=-398&p=Mi%20Uhl%C3%AD%C5%99">Mi Uhlíř</a></td><td class=ic>CZE</td><td class=kL>4:8</td>
<td class=kL>3:10</td>
<td class=kL>4:10</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>9:1</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=br>63:61</td><td class=br>+2</td>
<td class=bc>9 - 0 - 7</td>
<td class=br><strong>18</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=53&x=-398&p=V%C3%A1%20Pikl">Vá Pikl</a></td><td class=ic>CZE</td><td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=br>34:32</td><td class=br>+2</td>
<td class=bc>5 - 4 - 7</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1927&x=-398&p=Vo%20Kraus">Vo Kraus</a></td><td class=ic>CZE</td><td class=kL>1:9</td>
<td class=kL>2:4</td>
<td class=kL>4:6</td>
<td class=kL>0:5</td>
<td class=kL>4:7</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=br>40:56</td><td class=br>-16</td>
<td class=bc>6 - 1 - 9</td>
<td class=br><strong>13</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=204&x=-398&p=Hy%20Nechutn%C3%BD">Hy Nechutný</a></td><td class=ic>CZE</td><td class=kL>0:10</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kL>3:6</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>4:1</td>
<td class=br>31:48</td><td class=br>-17</td>
<td class=bc>4 - 3 - 9</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1058&x=-398&p=Fr%20Marek">Fr Marek</a></td><td class=ic>CZE</td><td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>4:6</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>6:4</td>
<td class=kL>4:6</td>
<td class=kW>7:0</td>
<td class=br>40:61</td><td class=br>-21</td>
<td class=bc>4 - 2 - 10</td>
<td class=br><strong>10</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=818&x=-398&p=Ro%20Je%C5%BE">Ro Jež</a></td><td class=ic>CZE</td><td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=br>35:58</td><td class=br>-23</td>
<td class=bc>2 - 2 - 12</td>
<td class=br><strong>6</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1626&x=-398&p=Mi%20Hor%C3%A1kov%C3%A1">Mi Horáková</a></td><td class=ic>CZE</td><td class=kL>0:19</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>1:8</td>
<td class=kL>2:8</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>0:10</td>
<td class=kL>1:9</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>4:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>10:2</td>
<td class=br>31:104</td><td class=br>-73</td>
<td class=bc>2 - 1 - 13</td>
<td class=br><strong>5</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1896&x=-398&p=Ra%20Hrn%C4%8D%C3%AD%C5%99">Ra Hrnčíř</a></td><td class=ic>CZE</td><td class=kL>0:11</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>2:8</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kW>6:4</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=br>20:75</td><td class=br>-55</td>
<td class=bc>1 - 2 - 13</td>
<td class=br><strong>4</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1999&x=-398&p=Fi%20Pano%C5%A1">Fi Panoš</a></td><td class=ic>CZE</td><td class=kL>1:11</td>
<td class=kL>0:6</td>
<td class=kL>2:7</td>
<td class=kL>0:9</td>
<td class=kL>0:3</td>
<td class=kL>3:7</td>
<td class=kL>0:3</td>
<td class=kL>1:9</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kW>3:2</td>
<td class=kL>2:10</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=br>16:88</td><td class=br>-72</td>
<td class=bc>1 - 1 - 14</td>
<td class=br><strong>3</strong></td><td class=d>17.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>19 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Fi Panoš</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Fi Panoš</td><td class=bc>10 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>11 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Vo Kraus</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Vo Kraus</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Uhlíř</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Vo Kraus</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Fi Panoš</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vo Kraus</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Mi Uhlíř</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 11</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>3 : 10</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>4 : 10</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Vo Kraus</td><td class=bc>-</td><td class=bl>Fi Panoš</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Uhlíř</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>4 : 8</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Fi Panoš</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Fi Panoš</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Vo Kraus</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Fi Panoš</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Fi Panoš</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Uhlíř</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Fi Panoš</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>5 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=993&x=-398&p=Ji%20Chyl%C3%ADk%20ml.">Ji Chylík ml.</a></td><td class=ic>CZE</td><td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>8:2</td>
<td class=kW>5:3</td>
<td class=kW>7:0</td>
<td class=kW>8:3</td>
<td class=kW>5:2</td>
<td class=br>82:26</td><td class=br>+56</td>
<td class=bc>16 - 1 - 0</td>
<td class=br><strong>33</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1477&x=-398&p=Mi%20Kobrle">Mi Kobrle</a></td><td class=ic>CZE</td><td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>5:4</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kW>8:2</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=kW>5:2</td>
<td class=kW>9:2</td>
<td class=kW>8:3</td>
<td class=kW>10:1</td>
<td class=kW>9:2</td>
<td class=kW>8:2</td>
<td class=kW>7:4</td>
<td class=br>110:35</td><td class=br>+75</td>
<td class=bc>16 - 0 - 1</td>
<td class=br><strong>32</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=310&x=-398&p=Mi%20%C4%8Cernoch">Mi Černoch</a></td><td class=ic>CZE</td><td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>8:1</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>8:4</td>
<td class=kW>6:1</td>
<td class=kW>9:2</td>
<td class=kW>2:0</td>
<td class=br>69:27</td><td class=br>+42</td>
<td class=bc>13 - 1 - 3</td>
<td class=br><strong>27</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=40&x=-398&p=Da%20Mat%C3%BDsek">Da Matýsek</a></td><td class=ic>CZE</td><td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kW>7:0</td>
<td class=kW>8:2</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=br>66:32</td><td class=br>+34</td>
<td class=bc>12 - 2 - 3</td>
<td class=br><strong>26</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1872&x=-398&p=Pe%20Fuchs">Pe Fuchs</a></td><td class=ic>CZE</td><td class=kL>3:5</td>
<td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>7:3</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>8:4</td>
<td class=kW>6:3</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=br>69:48</td><td class=br>+21</td>
<td class=bc>10 - 2 - 5</td>
<td class=br><strong>22</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1912&x=-398&p=Al%20Krejza">Al Krejza</a></td><td class=ic>CZE</td><td class=kL>0:3</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=br>51:34</td><td class=br>+17</td>
<td class=bc>10 - 2 - 5</td>
<td class=br><strong>22</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1065&x=-398&p=Kr%20Herold">Kr Herold</a></td><td class=ic>CZE</td><td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kT>5:5</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=br>59:44</td><td class=br>+15</td>
<td class=bc>8 - 4 - 5</td>
<td class=br><strong>20</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=248&x=-398&p=Ma%20%C5%BDen%C3%AD%C5%A1ek">Ma Ženíšek</a></td><td class=ic>CZE</td><td class=kL>3:4</td>
<td class=kL>2:8</td>
<td class=kL>1:8</td>
<td class=kL>1:5</td>
<td class=kL>3:7</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>7:1</td>
<td class=kW>5:4</td>
<td class=kW>8:2</td>
<td class=kW>8:2</td>
<td class=br>67:59</td><td class=br>+8</td>
<td class=bc>9 - 1 - 7</td>
<td class=br><strong>19</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=201&x=-398&p=To%20Bucek">To Bucek</a></td><td class=ic>CZE</td><td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>7:2</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=br>50:43</td><td class=br>+7</td>
<td class=bc>7 - 2 - 8</td>
<td class=br><strong>16</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=4&x=-398&p=Vl%20Kraus">Vl Kraus</a></td><td class=ic>CZE</td><td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>9:1</td>
<td class=kW>7:1</td>
<td class=br>55:46</td><td class=br>+9</td>
<td class=bc>7 - 2 - 8</td>
<td class=br><strong>16</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=70&x=-398&p=St%20Srba">St Srba</a></td><td class=ic>CZE</td><td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kT>0:0</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=br>29:45</td><td class=br>-16</td>
<td class=bc>6 - 3 - 8</td>
<td class=br><strong>15</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=176&x=-398&p=Zd%20Lopaur">Zd Lopaur</a></td><td class=ic>CZE</td><td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>2:8</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kW>6:4</td>
<td class=kW>4:3</td>
<td class=br>46:60</td><td class=br>-14</td>
<td class=bc>7 - 1 - 9</td>
<td class=br><strong>15</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1318&x=-398&p=Jo%20Sedl%C3%A1%C4%8Dek">Jo Sedláček</a></td><td class=ic>CZE</td><td class=kL>0:5</td>
<td class=kL>2:9</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=br>45:59</td><td class=br>-14</td>
<td class=bc>6 - 1 - 10</td>
<td class=br><strong>13</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1940&x=-398&p=Ma%20Ko%C5%A1%C5%88ar">Ma Košňar</a></td><td class=ic>CZE</td><td class=kL>2:8</td>
<td class=kL>3:8</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=br>32:72</td><td class=br>-40</td>
<td class=bc>4 - 2 - 11</td>
<td class=br><strong>10</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=41&x=-398&p=Da%20Hrachovec">Da Hrachovec</a></td><td class=ic>CZE</td><td class=kL>3:5</td>
<td class=kL>1:10</td>
<td class=kL>4:8</td>
<td class=kL>3:5</td>
<td class=kL>4:8</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kL>1:7</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=br>35:85</td><td class=br>-50</td>
<td class=bc>2 - 2 - 13</td>
<td class=br><strong>6</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1968&x=-398&p=Mi%20Tou%C5%A1">Mi Touš</a></td><td class=ic>CZE</td><td class=kL>0:7</td>
<td class=kL>2:9</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kT>5:5</td>
<td class=kL>4:5</td>
<td class=kL>2:7</td>
<td class=kL>1:6</td>
<td class=kT>0:0</td>
<td class=kW>6:3</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=br>38:84</td><td class=br>-46</td>
<td class=bc>1 - 4 - 12</td>
<td class=br><strong>6</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2018&x=-398&p=Ja%20Janou%C5%A1kovec">Ja Janouškovec</a></td><td class=ic>CZE</td><td class=kL>3:8</td>
<td class=kL>2:8</td>
<td class=kL>2:9</td>
<td class=kL>2:4</td>
<td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>2:8</td>
<td class=kL>0:7</td>
<td class=kL>1:9</td>
<td class=kL>0:3</td>
<td class=kL>4:6</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=br>35:93</td><td class=br>-58</td>
<td class=bc>2 - 1 - 14</td>
<td class=br><strong>5</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1941&x=-398&p=Ja%20Kopeck%C3%BD">Ja Kopecký</a></td><td class=ic>CZE</td><td class=kL>2:5</td>
<td class=kL>4:7</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>2:8</td>
<td class=kL>2:5</td>
<td class=kL>1:7</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=br>32:78</td><td class=br>-46</td>
<td class=bc>1 - 1 - 15</td>
<td class=br><strong>3</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>8 : 4</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ja Janouškovec</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ja Kopecký</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Mi Touš</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=blW>Ja Janouškovec</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Touš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Da Hrachovec</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Hrachovec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>8 : 4</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Da Hrachovec</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<hr><a name="final"><p class=vm>Výkonnostní skupiny (Final groups)</p></a>
<p class=v>Group A</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/8</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=409&x=-398&p=Pa%20Petr">Pa Petr</a></td><td class=ic>CZE</td><td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kT>1:1 K</td>
<td class=kW>5:4 K</td>
<td class=kT>3:3 K</td>
<td class=kW>6:0 K</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>7:3 K</td>
<td class=kW>7:2 K</td>
<td class=kW>7:2</td>
<td class=kW>4:0 K</td>
<td class=kW>3:1</td>
<td class=br>68:25</td><td class=br>+43</td>
<td class=bc>12 - 3 - 0</td>
<td class=br><strong>27</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/8</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=993&x=-398&p=Ji%20Chyl%C3%ADk%20ml.">Ji Chylík ml.</a></td><td class=ic>CZE</td><td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:3 K</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kT>3:3 K</td>
<td class=kW>5:0 K</td>
<td class=kW>3:1 K</td>
<td class=kW>5:3 K</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>3:0 K</td>
<td class=kW>3:2</td>
<td class=kW>4:3 K</td>
<td class=br>55:30</td><td class=br>+25</td>
<td class=bc>11 - 3 - 1</td>
<td class=br><strong>25</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/8</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1477&x=-398&p=Mi%20Kobrle">Mi Kobrle</a></td><td class=ic>CZE</td><td class=kL>1:2</td>
<td class=kL>3:4 K</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>5:0 K</td>
<td class=kW>5:3 K</td>
<td class=kW>4:2 K</td>
<td class=kW>5:4 K</td>
<td class=kW>6:4</td>
<td class=kW>7:2</td>
<td class=kW>7:1 K</td>
<td class=kW>4:2</td>
<td class=kW>8:2 K</td>
<td class=br>69:34</td><td class=br>+35</td>
<td class=bc>11 - 2 - 2</td>
<td class=br><strong>24</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/8</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=961&x=-398&p=Mi%20Bo%C5%A1t%C3%ADk">Mi Boštík</a></td><td class=ic>CZE</td><td class=kT>1:1 K</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:1 K</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2 K</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>3:2 K</td>
<td class=kT>1:1 K</td>
<td class=kW>6:3</td>
<td class=kT>4:4 K</td>
<td class=kL>2:4</td>
<td class=br>41:39</td><td class=br>+2</td>
<td class=bc>6 - 5 - 4</td>
<td class=br><strong>17</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/8</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=567&x=-398&p=Kr%20Lebl">Kr Lebl</a></td><td class=ic>CZE</td><td class=kL>4:5 K</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:6 K</td>
<td class=kx>*</td>
<td class=kT>3:3 K</td>
<td class=kL>1:3 K</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1 K</td>
<td class=kW>3:1 K</td>
<td class=kT>2:2</td>
<td class=kW>6:2 K</td>
<td class=kW>3:0</td>
<td class=br>42:34</td><td class=br>+8</td>
<td class=bc>6 - 5 - 4</td>
<td class=br><strong>17</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/8</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1&x=-398&p=Pa%20Ple%C5%A1%C3%A1k">Pa Plešák</a></td><td class=ic>CZE</td><td class=kT>3:3 K</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2 K</td>
<td class=kT>3:3 K</td>
<td class=kx>*</td>
<td class=kW>3:2 K</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>6:1 K</td>
<td class=kL>2:5 K</td>
<td class=kT>2:2</td>
<td class=kT>3:3 K</td>
<td class=kW>2:0</td>
<td class=br>44:41</td><td class=br>+3</td>
<td class=bc>4 - 8 - 3</td>
<td class=br><strong>16</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/8</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1641&x=-398&p=Ma%20Klazar">Ma Klazar</a></td><td class=ic>CZE</td><td class=kL>0:6 K</td>
<td class=kW>3:2</td>
<td class=kL>0:5</td>
<td class=kT>2:2 K</td>
<td class=kW>3:1 K</td>
<td class=kL>2:3 K</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kL>2:4 K</td>
<td class=kL>1:3 K</td>
<td class=kW>3:0</td>
<td class=kW>6:0 K</td>
<td class=kW>5:2</td>
<td class=br>39:36</td><td class=br>+3</td>
<td class=bc>7 - 2 - 6</td>
<td class=br><strong>16</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/8</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1065&x=-398&p=Kr%20Herold">Kr Herold</a></td><td class=ic>CZE</td><td class=kL>0:5</td>
<td class=kT>3:3 K</td>
<td class=kL>0:5 K</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kL>1:3 K</td>
<td class=kW>4:2 K</td>
<td class=kT>3:3 K</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kL>2:6 K</td>
<td class=kL>2:3</td>
<td class=kW>4:1 K</td>
<td class=br>39:39</td><td class=br>0</td>
<td class=bc>6 - 3 - 6</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=40&x=-398&p=Da%20Mat%C3%BDsek">Da Matýsek</a></td><td class=ic>CZE</td><td class=kL>2:6</td>
<td class=kL>0:5 K</td>
<td class=kL>3:5 K</td>
<td class=kL>2:4</td>
<td class=kL>0:1</td>
<td class=kW>5:2</td>
<td class=kL>1:4</td>
<td class=kW>3:1 K</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=kW>5:0 K</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kT>3:3 K</td>
<td class=kL>1:3</td>
<td class=kW>5:1 K</td>
<td class=br>40:38</td><td class=br>+2</td>
<td class=bc>6 - 2 - 7</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=310&x=-398&p=Mi%20%C4%8Cernoch">Mi Černoch</a></td><td class=ic>CZE</td><td class=kL>2:4</td>
<td class=kL>1:3 K</td>
<td class=kL>2:4 K</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kL>2:4 K</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=kW>4:2 K</td>
<td class=kW>6:1</td>
<td class=kT>4:4</td>
<td class=kW>2:1 K</td>
<td class=kW>4:2</td>
<td class=kW>8:1 K</td>
<td class=br>41:44</td><td class=br>-3</td>
<td class=bc>5 - 3 - 7</td>
<td class=br><strong>13</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1872&x=-398&p=Pe%20Fuchs">Pe Fuchs</a></td><td class=ic>CZE</td><td class=kL>1:5</td>
<td class=kL>3:5 K</td>
<td class=kL>4:5 K</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kT>3:3 K</td>
<td class=kL>0:5 K</td>
<td class=kL>2:4 K</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2 K</td>
<td class=kW>4:2</td>
<td class=kW>7:3 K</td>
<td class=br>42:50</td><td class=br>-8</td>
<td class=bc>4 - 4 - 7</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=318&x=-398&p=Ji%20V%C3%A1cha">Ji Vácha</a></td><td class=ic>CZE</td><td class=kL>3:7 K</td>
<td class=kL>2:3</td>
<td class=kL>4:6</td>
<td class=kL>2:3 K</td>
<td class=kL>1:3 K</td>
<td class=kL>1:6 K</td>
<td class=kW>4:2 K</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:2 K</td>
<td class=kL>2:6</td>
<td class=kW>3:1 K</td>
<td class=kW>6:3</td>
<td class=br>36:52</td><td class=br>-16</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=101&x=-398&p=Mi%20Kubica">Mi Kubica</a></td><td class=ic>CZE</td><td class=kL>2:7 K</td>
<td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kT>1:1 K</td>
<td class=kL>1:3 K</td>
<td class=kW>5:2 K</td>
<td class=kW>3:1 K</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3 K</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2 K</td>
<td class=kW>5:2</td>
<td class=br>34:52</td><td class=br>-18</td>
<td class=bc>4 - 3 - 8</td>
<td class=br><strong>11</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1912&x=-398&p=Al%20Krejza">Al Krejza</a></td><td class=ic>CZE</td><td class=kL>2:7</td>
<td class=kL>0:3 K</td>
<td class=kL>1:7 K</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kW>6:2 K</td>
<td class=kT>3:3 K</td>
<td class=kL>1:2 K</td>
<td class=kL>2:4 K</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>5:1 K</td>
<td class=br>38:50</td><td class=br>-12</td>
<td class=bc>3 - 4 - 8</td>
<td class=br><strong>10</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1876&x=-398&p=Ad%20Kop%C5%99iva">Ad Kopřiva</a></td><td class=ic>CZE</td><td class=kL>0:4 K</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kT>4:4 K</td>
<td class=kL>2:6 K</td>
<td class=kT>3:3 K</td>
<td class=kL>0:6 K</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:3 K</td>
<td class=kL>2:4 K</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=br>33:55</td><td class=br>-22</td>
<td class=bc>3 - 2 - 10</td>
<td class=br><strong>8</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=248&x=-398&p=Ma%20%C5%BDen%C3%AD%C5%A1ek">Ma Ženíšek</a></td><td class=ic>CZE</td><td class=kL>1:3</td>
<td class=kL>3:4 K</td>
<td class=kL>2:8 K</td>
<td class=kW>4:2</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>1:4 K</td>
<td class=kL>1:5 K</td>
<td class=kL>1:8 K</td>
<td class=kL>3:7 K</td>
<td class=kL>3:6</td>
<td class=kL>2:5</td>
<td class=kL>1:5 K</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=br>28:70</td><td class=br>-42</td>
<td class=bc>2 - 0 - 13</td>
<td class=br><strong>4</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ji Vácha</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>4 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ji Vácha</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Ji Vácha</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ji Vácha</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 7</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
