<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR jednotlivci</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>MR jednotlivci, 28. květen 2023</span></h2></div></div></div></div><p><div align="center">
<div align=center>
<a href="kriz.aspx">Zápasy ve skupinách (Basic and placement groups)</a><br>
<a href="MR_jednotlivci_playoff.aspx ">Zápasy o umístění (Placement matches)</a><br>
<a href="utokturnaje.aspx">Tabulka útočníků (Best forwards)</a><br>
<a href="obranaturnaje.aspx">Tabulka obránců (Best defenders)</a><br>
</div>
<table border=0 cellpadding=2 cellspacing=0 class="rnk">
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">M</th>
<th align="center">+</th>
<th align="center">=</th>
<th align="center">-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1477&x=-398&p=Michal%20Kobrle">Michal Kobrle</a></td>
<td class=al>THC Stiga Elites</td>
<td class=ar>39</td>
<td class=ar>33</td>
<td class=ar>2</td>
<td class=ar>4</td>
<td class=ar>212</td>
<td class=al>&nbsp;:&nbsp;97</td>
</tr><tr><td class=br>2.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=409&x=-398&p=Patrik%20Petr">Patrik Petr</a></td>
<td class=bl>THC Stiga Elites</td>
<td class=br>37</td>
<td class=br>30</td>
<td class=br>3</td>
<td class=br>4</td>
<td class=br>217</td>
<td class=bl>&nbsp;:&nbsp;76</td>
</tr><tr><td class=ar>3.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=993&x=-398&p=Ji%C5%99%C3%AD%20Chyl%C3%ADk%20ml.">Jiří Chylík ml.</a></td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>42</td>
<td class=ar>29</td>
<td class=ar>3</td>
<td class=ar>10</td>
<td class=ar>158</td>
<td class=al>&nbsp;:&nbsp;94</td>
</tr><tr><td class=br>4.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=567&x=-398&p=Kry%C5%A1tof%20Lebl">Kryštof Lebl</a></td>
<td class=bl>Big Band</td>
<td class=br>39</td>
<td class=br>20</td>
<td class=br>6</td>
<td class=br>13</td>
<td class=br>128</td>
<td class=bl>&nbsp;:&nbsp;93</td>
</tr><tr><td class=ar>5.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=961&x=-398&p=Michal%20Bo%C5%A1t%C3%ADk">Michal Boštík</a></td>
<td class=al>THC Stiga Elites</td>
<td class=ar>30</td>
<td class=ar>16</td>
<td class=ar>6</td>
<td class=ar>8</td>
<td class=ar>104</td>
<td class=al>&nbsp;:&nbsp;70</td>
</tr><tr><td class=br>6.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1&x=-398&p=Pavel%20Ple%C5%A1%C3%A1k">Pavel Plešák</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>28</td>
<td class=br>13</td>
<td class=br>8</td>
<td class=br>7</td>
<td class=br>98</td>
<td class=bl>&nbsp;:&nbsp;77</td>
</tr><tr><td class=ar>7.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1641&x=-398&p=Maty%C3%A1%C5%A1%20Klazar">Matyáš Klazar</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>31</td>
<td class=ar>16</td>
<td class=ar>5</td>
<td class=ar>10</td>
<td class=ar>90</td>
<td class=al>&nbsp;:&nbsp;72</td>
</tr><tr><td class=br>8.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1065&x=-398&p=Kry%C5%A1tof%20Herold">Kryštof Herold</a></td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>29</td>
<td class=br>12</td>
<td class=br>5</td>
<td class=br>12</td>
<td class=br>84</td>
<td class=bl>&nbsp;:&nbsp;84</td>
</tr><tr><td class=ar>9.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=40&x=-398&p=Daniel%20Mat%C3%BDsek">Daniel Matýsek</a></td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>25</td>
<td class=ar>15</td>
<td class=ar>2</td>
<td class=ar>8</td>
<td class=ar>85</td>
<td class=al>&nbsp;:&nbsp;53</td>
</tr><tr><td class=br>10.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=310&x=-398&p=Miroslav%20%C4%8Cernoch">Miroslav Černoch</a></td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>25</td>
<td class=br>15</td>
<td class=br>3</td>
<td class=br>7</td>
<td class=br>89</td>
<td class=bl>&nbsp;:&nbsp;54</td>
</tr><tr><td class=ar>11.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1872&x=-398&p=Petr%20Fuchs">Petr Fuchs</a></td>
<td class=al>Big Band</td>
<td class=ar>25</td>
<td class=ar>12</td>
<td class=ar>5</td>
<td class=ar>8</td>
<td class=ar>88</td>
<td class=al>&nbsp;:&nbsp;71</td>
</tr><tr><td class=br>12.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=318&x=-398&p=Ji%C5%99%C3%AD%20V%C3%A1cha">Jiří Vácha</a></td>
<td class=bl>SHC Cheb</td>
<td class=br>24</td>
<td class=br>12</td>
<td class=br>1</td>
<td class=br>11</td>
<td class=br>71</td>
<td class=bl>&nbsp;:&nbsp;68</td>
</tr><tr><td class=ar>13.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=101&x=-398&p=Miloslav%20Kubica">Miloslav Kubica</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>24</td>
<td class=ar>11</td>
<td class=ar>5</td>
<td class=ar>8</td>
<td class=ar>77</td>
<td class=al>&nbsp;:&nbsp;67</td>
</tr><tr><td class=br>14.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1912&x=-398&p=Ale%C5%A1%20Krejza">Aleš Krejza</a></td>
<td class=bl>THC Třinec</td>
<td class=br>25</td>
<td class=br>11</td>
<td class=br>5</td>
<td class=br>9</td>
<td class=br>71</td>
<td class=bl>&nbsp;:&nbsp;62</td>
</tr><tr><td class=ar>15.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1876&x=-398&p=Adam%20Kop%C5%99iva">Adam Kopřiva</a></td>
<td class=al>BSE United</td>
<td class=ar>24</td>
<td class=ar>11</td>
<td class=ar>3</td>
<td class=ar>10</td>
<td class=ar>78</td>
<td class=al>&nbsp;:&nbsp;66</td>
</tr><tr><td class=br>16.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=248&x=-398&p=Martin%20%C5%BDen%C3%AD%C5%A1ek">Martin Ženíšek</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>25</td>
<td class=br>11</td>
<td class=br>1</td>
<td class=br>13</td>
<td class=br>83</td>
<td class=bl>&nbsp;:&nbsp;88</td>
</tr><tr><td class=ar>17.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1599&x=-398&p=Miroslav%20Uhl%C3%AD%C5%99">Miroslav Uhlíř</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>16</td>
<td class=ar>9</td>
<td class=ar>0</td>
<td class=ar>7</td>
<td class=ar>63</td>
<td class=al>&nbsp;:&nbsp;61</td>
</tr><tr><td class=br>18.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=201&x=-398&p=Tom%C3%A1%C5%A1%20Bucek">Tomáš Bucek</a></td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>17</td>
<td class=br>7</td>
<td class=br>2</td>
<td class=br>8</td>
<td class=br>50</td>
<td class=bl>&nbsp;:&nbsp;43</td>
</tr><tr><td class=ar>19.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=4&x=-398&p=Vladim%C3%ADr%20Kraus">Vladimír Kraus</a></td>
<td class=al>Rokycany</td>
<td class=ar>20</td>
<td class=ar>9</td>
<td class=ar>2</td>
<td class=ar>9</td>
<td class=ar>61</td>
<td class=al>&nbsp;:&nbsp;51</td>
</tr><tr><td class=br>20.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=53&x=-398&p=V%C3%A1clav%20Pikl">Václav Pikl</a></td>
<td class=bl>THC Stiga Elites</td>
<td class=br>19</td>
<td class=br>6</td>
<td class=br>4</td>
<td class=br>9</td>
<td class=br>39</td>
<td class=bl>&nbsp;:&nbsp;38</td>
</tr><tr><td class=ar>21.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=70&x=-398&p=Stanislav%20Srba">Stanislav Srba</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>20</td>
<td class=ar>8</td>
<td class=ar>3</td>
<td class=ar>9</td>
<td class=ar>36</td>
<td class=al>&nbsp;:&nbsp;48</td>
</tr><tr><td class=br>22.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1927&x=-398&p=Vojt%C4%9Bch%20Kraus">Vojtěch Kraus</a></td>
<td class=bl>Rokycany</td>
<td class=br>19</td>
<td class=br>7</td>
<td class=br>1</td>
<td class=br>11</td>
<td class=br>43</td>
<td class=bl>&nbsp;:&nbsp;63</td>
</tr><tr><td class=ar>23.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=204&x=-398&p=Hynek%20Nechutn%C3%BD">Hynek Nechutný</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>19</td>
<td class=ar>6</td>
<td class=ar>3</td>
<td class=ar>10</td>
<td class=ar>37</td>
<td class=al>&nbsp;:&nbsp;54</td>
</tr><tr><td class=br>24.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=176&x=-398&p=Zden%C4%9Bk%20Lopaur">Zdeněk Lopaur</a></td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>20</td>
<td class=br>8</td>
<td class=br>1</td>
<td class=br>11</td>
<td class=br>52</td>
<td class=bl>&nbsp;:&nbsp;66</td>
</tr><tr><td class=ar>25.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1318&x=-398&p=Josef%20Sedl%C3%A1%C4%8Dek">Josef Sedláček</a></td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>19</td>
<td class=ar>8</td>
<td class=ar>1</td>
<td class=ar>10</td>
<td class=ar>51</td>
<td class=al>&nbsp;:&nbsp;63</td>
</tr><tr><td class=br>26.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1058&x=-398&p=Franti%C5%A1ek%20Marek">František Marek</a></td>
<td class=bl>BSE United</td>
<td class=br>18</td>
<td class=br>4</td>
<td class=br>2</td>
<td class=br>12</td>
<td class=br>44</td>
<td class=bl>&nbsp;:&nbsp;67</td>
</tr><tr><td class=ar>27.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=818&x=-398&p=Robert%20Je%C5%BE">Robert Jež</a></td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>18</td>
<td class=ar>4</td>
<td class=ar>2</td>
<td class=ar>12</td>
<td class=ar>42</td>
<td class=al>&nbsp;:&nbsp;62</td>
</tr><tr><td class=br>28.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1940&x=-398&p=Martin%20Ko%C5%A1%C5%88ar">Martin Košňar</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>19</td>
<td class=br>4</td>
<td class=br>2</td>
<td class=br>13</td>
<td class=br>36</td>
<td class=bl>&nbsp;:&nbsp;79</td>
</tr><tr><td class=ar>29.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=41&x=-398&p=Daniel%20Hrachovec">Daniel Hrachovec</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>19</td>
<td class=ar>4</td>
<td class=ar>2</td>
<td class=ar>13</td>
<td class=ar>49</td>
<td class=al>&nbsp;:&nbsp;89</td>
</tr><tr><td class=br>30.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1626&x=-398&p=Miroslava%20Hor%C3%A1kov%C3%A1">Miroslava Horáková</a></td>
<td class=bl>SHC Cheb</td>
<td class=br>18</td>
<td class=br>2</td>
<td class=br>1</td>
<td class=br>15</td>
<td class=br>35</td>
<td class=bl>&nbsp;:&nbsp;118</td>
</tr><tr><td class=ar>31.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1968&x=-398&p=Michal%20Tou%C5%A1">Michal Touš</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>17</td>
<td class=ar>1</td>
<td class=ar>4</td>
<td class=ar>12</td>
<td class=ar>38</td>
<td class=al>&nbsp;:&nbsp;84</td>
</tr><tr><td class=br>32.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1896&x=-398&p=Radek%20Hrn%C4%8D%C3%AD%C5%99">Radek Hrnčíř</a></td>
<td class=bl>Big Band</td>
<td class=br>16</td>
<td class=br>1</td>
<td class=br>2</td>
<td class=br>13</td>
<td class=br>20</td>
<td class=bl>&nbsp;:&nbsp;75</td>
</tr><tr><td class=ar>33.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=2018&x=-398&p=Jan%20Janou%C5%A1kovec">Jan Janouškovec</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>17</td>
<td class=ar>2</td>
<td class=ar>1</td>
<td class=ar>14</td>
<td class=ar>35</td>
<td class=al>&nbsp;:&nbsp;93</td>
</tr><tr><td class=br>34.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1999&x=-398&p=Filip%20Pano%C5%A1">Filip Panoš</a></td>
<td class=bl>Pelhřimov</td>
<td class=br>16</td>
<td class=br>1</td>
<td class=br>1</td>
<td class=br>14</td>
<td class=br>16</td>
<td class=bl>&nbsp;:&nbsp;88</td>
</tr><tr><td class=ar>35.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1941&x=-398&p=Jaroslav%20Kopeck%C3%BD">Jaroslav Kopecký</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>17</td>
<td class=ar>1</td>
<td class=ar>1</td>
<td class=ar>15</td>
<td class=ar>32</td>
<td class=al>&nbsp;:&nbsp;78</td>
</tr></table></td></tr></table></div></p>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
