<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Plzeň</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Plzeň, 21. leden 2023</span></h2></div></div></div></div><p><div align="center">
<div align=center>
<a href="kriz.aspx">Zápasy ve skupinách (Basic and placement groups)</a><br>
<a href="Plzen_playoff.aspx ">Zápasy o umístění (Placement matches)</a><br>
<a href="utokturnaje.aspx">Tabulka útočníků (Best forwards)</a><br>
<a href="obranaturnaje.aspx">Tabulka obránců (Best defenders)</a><br>
<a href="kluby.aspx">Soutěž klubů</a><br>
</div>
<p class=v>Konečné pořadí turnaje (Final table)<br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0 class="rnk">
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">M</th>
<th align="center">+</th>
<th align="center">=</th>
<th align="center">-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">Pts</th>
<th align="center">CZ pts</th>
<th>&nbsp;</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=409&x=386">Petr Patrik</a></td>
<td class=al>THC Stiga Elites</td>
<td class=ar>45</td>
<td class=ar>39</td>
<td class=ar>1</td>
<td class=ar>5</td>
<td class=ar>264</td>
<td class=al>&nbsp;:&nbsp;81</td>
<td class=ar>79</td>
<td class=art>160</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>2.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1477&x=386">Kobrle Michal</a></td>
<td class=bl>THC Stiga Elites</td>
<td class=br>45</td>
<td class=br>33</td>
<td class=br>3</td>
<td class=br>9</td>
<td class=br>229</td>
<td class=bl>&nbsp;:&nbsp;103</td>
<td class=br>69</td>
<td class=brt>152</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>3.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1406&x=386">Matýsek Jakub</a></td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>43</td>
<td class=ar>32</td>
<td class=ar>3</td>
<td class=ar>8</td>
<td class=ar>193</td>
<td class=al>&nbsp;:&nbsp;111</td>
<td class=ar>67</td>
<td class=art>146</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>4.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=961&x=386">Boštík Michal</a></td>
<td class=bl>THC Stiga Elites</td>
<td class=br>42</td>
<td class=br>27</td>
<td class=br>3</td>
<td class=br>12</td>
<td class=br>152</td>
<td class=bl>&nbsp;:&nbsp;102</td>
<td class=br>57</td>
<td class=brt>141</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>5.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=567&x=386">Lebl Kryštof</a></td>
<td class=al>Big Band</td>
<td class=ar>39</td>
<td class=ar>28</td>
<td class=ar>5</td>
<td class=ar>6</td>
<td class=ar>154</td>
<td class=al>&nbsp;:&nbsp;70</td>
<td class=ar>61</td>
<td class=art>137</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>6.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=40&x=386">Matýsek Daniel</a></td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>40</td>
<td class=br>25</td>
<td class=br>4</td>
<td class=br>11</td>
<td class=br>132</td>
<td class=bl>&nbsp;:&nbsp;98</td>
<td class=br>54</td>
<td class=brt>134</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>7.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=101&x=386">Kubica Miloslav</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>38</td>
<td class=ar>21</td>
<td class=ar>6</td>
<td class=ar>11</td>
<td class=ar>158</td>
<td class=al>&nbsp;:&nbsp;111</td>
<td class=ar>48</td>
<td class=art>132</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>8.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1&x=386">Plešák Pavel</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>39</td>
<td class=br>20</td>
<td class=br>5</td>
<td class=br>14</td>
<td class=br>136</td>
<td class=bl>&nbsp;:&nbsp;113</td>
<td class=br>45</td>
<td class=brt>131</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>9.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=993&x=386">Chylík ml. Jiří</a></td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>36</td>
<td class=ar>25</td>
<td class=ar>2</td>
<td class=ar>9</td>
<td class=ar>124</td>
<td class=al>&nbsp;:&nbsp;74</td>
<td class=ar>52</td>
<td class=art>128</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>10.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1065&x=386">Herold Kryštof</a></td>
<td class=bl>HCS Žabka Praha</td>
<td class=br>35</td>
<td class=br>18</td>
<td class=br>7</td>
<td class=br>10</td>
<td class=br>118</td>
<td class=bl>&nbsp;:&nbsp;91</td>
<td class=br>43</td>
<td class=brt>127</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>11.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=310&x=386">Černoch Miroslav</a></td>
<td class=al>HCS Žabka Praha</td>
<td class=ar>35</td>
<td class=ar>19</td>
<td class=ar>3</td>
<td class=ar>13</td>
<td class=ar>115</td>
<td class=al>&nbsp;:&nbsp;70</td>
<td class=ar>41</td>
<td class=art>126</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>12.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=4&x=386">Kraus Vladimír</a></td>
<td class=bl>Rokycany</td>
<td class=br>35</td>
<td class=br>19</td>
<td class=br>4</td>
<td class=br>12</td>
<td class=br>93</td>
<td class=bl>&nbsp;:&nbsp;84</td>
<td class=br>42</td>
<td class=brt>125</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>13.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=318&x=386">Vácha Jiří</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>35</td>
<td class=ar>18</td>
<td class=ar>3</td>
<td class=ar>14</td>
<td class=ar>116</td>
<td class=al>&nbsp;:&nbsp;107</td>
<td class=ar>39</td>
<td class=art>124</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>14.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=53&x=386">Pikl Václav</a></td>
<td class=bl>THC Stiga Elites</td>
<td class=br>34</td>
<td class=br>16</td>
<td class=br>5</td>
<td class=br>13</td>
<td class=br>103</td>
<td class=bl>&nbsp;:&nbsp;82</td>
<td class=br>37</td>
<td class=brt>123</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>15.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1599&x=386">Uhlíř Miroslav</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>35</td>
<td class=ar>16</td>
<td class=ar>2</td>
<td class=ar>17</td>
<td class=ar>122</td>
<td class=al>&nbsp;:&nbsp;150</td>
<td class=ar>34</td>
<td class=art>122</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>16.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=201&x=386">Bucek Tomáš</a></td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>34</td>
<td class=br>16</td>
<td class=br>4</td>
<td class=br>14</td>
<td class=br>99</td>
<td class=bl>&nbsp;:&nbsp;97</td>
<td class=br>36</td>
<td class=brt>121</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>17.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=248&x=386">Ženíšek Martin</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>31</td>
<td class=ar>15</td>
<td class=ar>3</td>
<td class=ar>13</td>
<td class=ar>109</td>
<td class=al>&nbsp;:&nbsp;88</td>
<td class=ar>33</td>
<td class=art>119</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>18.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=108&x=386">Hejda Roman</a></td>
<td class=bl>SHC Cheb</td>
<td class=br>31</td>
<td class=br>13</td>
<td class=br>4</td>
<td class=br>14</td>
<td class=br>98</td>
<td class=bl>&nbsp;:&nbsp;97</td>
<td class=br>30</td>
<td class=brt>118</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>19.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=70&x=386">Srba Stanislav</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>31</td>
<td class=ar>12</td>
<td class=ar>2</td>
<td class=ar>17</td>
<td class=ar>68</td>
<td class=al>&nbsp;:&nbsp;104</td>
<td class=ar>26</td>
<td class=art>117</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>20.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=26&x=386">Ševr Miloš</a></td>
<td class=bl>THC Stiga Elites</td>
<td class=br>31</td>
<td class=br>13</td>
<td class=br>2</td>
<td class=br>16</td>
<td class=br>89</td>
<td class=bl>&nbsp;:&nbsp;83</td>
<td class=br>28</td>
<td class=brt>116</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>21.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1872&x=386">Fuchs Petr</a></td>
<td class=al>Big Band</td>
<td class=ar>31</td>
<td class=ar>12</td>
<td class=ar>1</td>
<td class=ar>18</td>
<td class=ar>83</td>
<td class=al>&nbsp;:&nbsp;92</td>
<td class=ar>25</td>
<td class=art>115</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>22.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1058&x=386">Marek František</a></td>
<td class=bl>BSE United</td>
<td class=br>31</td>
<td class=br>11</td>
<td class=br>0</td>
<td class=br>20</td>
<td class=br>75</td>
<td class=bl>&nbsp;:&nbsp;121</td>
<td class=br>22</td>
<td class=brt>114</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>23.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=818&x=386">Jež Robert</a></td>
<td class=al>Stiga HC Benátky</td>
<td class=ar>31</td>
<td class=ar>11</td>
<td class=ar>4</td>
<td class=ar>16</td>
<td class=ar>102</td>
<td class=al>&nbsp;:&nbsp;109</td>
<td class=ar>26</td>
<td class=art>113</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>24.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1630&x=386">Holub Petr</a></td>
<td class=bl>SHC Cheb</td>
<td class=br>31</td>
<td class=br>7</td>
<td class=br>3</td>
<td class=br>21</td>
<td class=br>70</td>
<td class=bl>&nbsp;:&nbsp;122</td>
<td class=br>17</td>
<td class=brt>112</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>25.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1912&x=386">Krejza Aleš</a></td>
<td class=al>THC Třinec</td>
<td class=ar>41</td>
<td class=ar>28</td>
<td class=ar>1</td>
<td class=ar>12</td>
<td class=ar>162</td>
<td class=al>&nbsp;:&nbsp;87</td>
<td class=ar>57</td>
<td class=art>111</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>26.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1876&x=386">Kopřiva Adam</a></td>
<td class=bl>BSE United</td>
<td class=br>42</td>
<td class=br>25</td>
<td class=br>3</td>
<td class=br>14</td>
<td class=br>141</td>
<td class=bl>&nbsp;:&nbsp;104</td>
<td class=br>53</td>
<td class=brt>109</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>27.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1639&x=386">Ouřada Jaroslav</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>39</td>
<td class=ar>15</td>
<td class=ar>3</td>
<td class=ar>21</td>
<td class=ar>100</td>
<td class=al>&nbsp;:&nbsp;133</td>
<td class=ar>33</td>
<td class=art>107</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>28.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=176&x=386">Lopaur Zdeněk</a></td>
<td class=bl>Stiga HC Benátky</td>
<td class=br>38</td>
<td class=br>17</td>
<td class=br>5</td>
<td class=br>16</td>
<td class=br>123</td>
<td class=bl>&nbsp;:&nbsp;111</td>
<td class=br>39</td>
<td class=brt>106</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>29.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=18&x=386">Šurýn Antonín</a></td>
<td class=al>Big Band</td>
<td class=ar>34</td>
<td class=ar>17</td>
<td class=ar>6</td>
<td class=ar>11</td>
<td class=ar>88</td>
<td class=al>&nbsp;:&nbsp;81</td>
<td class=ar>40</td>
<td class=art>105</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>30.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=227&x=386">Mašika Michal</a></td>
<td class=bl>SHC Cheb</td>
<td class=br>36</td>
<td class=br>16</td>
<td class=br>3</td>
<td class=br>17</td>
<td class=br>90</td>
<td class=bl>&nbsp;:&nbsp;95</td>
<td class=br>35</td>
<td class=brt>104</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>31.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=10&x=386">Medvec Jan</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>34</td>
<td class=ar>13</td>
<td class=ar>6</td>
<td class=ar>15</td>
<td class=ar>111</td>
<td class=al>&nbsp;:&nbsp;117</td>
<td class=ar>32</td>
<td class=art>103</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>32.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1405&x=386">Kubrt Pavel</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>34</td>
<td class=br>9</td>
<td class=br>9</td>
<td class=br>16</td>
<td class=br>96</td>
<td class=bl>&nbsp;:&nbsp;117</td>
<td class=br>27</td>
<td class=brt>102</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>33.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=32&x=386">Kropáček Jiří</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>31</td>
<td class=ar>13</td>
<td class=ar>6</td>
<td class=ar>12</td>
<td class=ar>101</td>
<td class=al>&nbsp;:&nbsp;102</td>
<td class=ar>32</td>
<td class=art>100</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>34.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=204&x=386">Nechutný Hynek</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>31</td>
<td class=br>9</td>
<td class=br>7</td>
<td class=br>15</td>
<td class=br>75</td>
<td class=bl>&nbsp;:&nbsp;79</td>
<td class=br>25</td>
<td class=brt>99</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>35.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1940&x=386">Košňar Martin</a></td>
<td class=al>Gladiators Plzeň</td>
<td class=ar>31</td>
<td class=ar>9</td>
<td class=ar>3</td>
<td class=ar>19</td>
<td class=ar>64</td>
<td class=al>&nbsp;:&nbsp;96</td>
<td class=ar>21</td>
<td class=art>98</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>36.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1927&x=386">Kraus Vojtěch</a></td>
<td class=bl>Rokycany</td>
<td class=br>31</td>
<td class=br>12</td>
<td class=br>2</td>
<td class=br>17</td>
<td class=br>81</td>
<td class=bl>&nbsp;:&nbsp;96</td>
<td class=br>26</td>
<td class=brt>97</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>37.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1657&x=386">Perkner Jonáš</a></td>
<td class=al>Big Band</td>
<td class=ar>31</td>
<td class=ar>9</td>
<td class=ar>2</td>
<td class=ar>20</td>
<td class=ar>44</td>
<td class=al>&nbsp;:&nbsp;95</td>
<td class=ar>20</td>
<td class=art>96</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>38.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1941&x=386">Kopecký Jaroslav</a></td>
<td class=bl>SHC Cheb</td>
<td class=br>31</td>
<td class=br>10</td>
<td class=br>4</td>
<td class=br>17</td>
<td class=br>77</td>
<td class=bl>&nbsp;:&nbsp;86</td>
<td class=br>24</td>
<td class=brt>95</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>39.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=89&x=386">Gruncl Josef</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>31</td>
<td class=ar>6</td>
<td class=ar>5</td>
<td class=ar>20</td>
<td class=ar>54</td>
<td class=al>&nbsp;:&nbsp;113</td>
<td class=ar>17</td>
<td class=art>94</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>40.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1869&x=386">Klazar Petr</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>31</td>
<td class=br>4</td>
<td class=br>3</td>
<td class=br>24</td>
<td class=br>58</td>
<td class=bl>&nbsp;:&nbsp;136</td>
<td class=br>11</td>
<td class=brt>93</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>41.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1967&x=386">Ouřada Antonín</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>31</td>
<td class=ar>5</td>
<td class=ar>2</td>
<td class=ar>24</td>
<td class=ar>61</td>
<td class=al>&nbsp;:&nbsp;143</td>
<td class=ar>12</td>
<td class=art>92</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>42.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1968&x=386">Touš Michal</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>15</td>
<td class=br>4</td>
<td class=br>2</td>
<td class=br>9</td>
<td class=br>38</td>
<td class=bl>&nbsp;:&nbsp;60</td>
<td class=br>10</td>
<td class=brt>91</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>43.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1947&x=386">Holub Lukáš</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>25</td>
<td class=ar>7</td>
<td class=ar>3</td>
<td class=ar>15</td>
<td class=ar>50</td>
<td class=al>&nbsp;:&nbsp;96</td>
<td class=ar>17</td>
<td class=art>90</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>44.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1896&x=386">Hrnčíř Radek</a></td>
<td class=bl>Big Band</td>
<td class=br>25</td>
<td class=br>7</td>
<td class=br>2</td>
<td class=br>16</td>
<td class=br>56</td>
<td class=bl>&nbsp;:&nbsp;100</td>
<td class=br>16</td>
<td class=brt>89</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>45.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1626&x=386">Horáková Miroslava</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>25</td>
<td class=ar>5</td>
<td class=ar>4</td>
<td class=ar>16</td>
<td class=ar>64</td>
<td class=al>&nbsp;:&nbsp;128</td>
<td class=ar>14</td>
<td class=art>88</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>46.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1973&x=386">Sabo Branislav</a></td>
<td class=bl>*THC Predators (SVK)</td>
<td class=br>25</td>
<td class=br>5</td>
<td class=br>2</td>
<td class=br>18</td>
<td class=br>62</td>
<td class=bl>&nbsp;:&nbsp;99</td>
<td class=br>12</td>
<td class=brt>86</td>
<td class=br>&nbsp;</td>
</tr><tr><td class=ar>47.</td>
<td class=al><a href="../../../thstats/overview_co.aspx?idpl=1959&x=386">Chlebo Ondřej</a></td>
<td class=al>BSE United</td>
<td class=ar>25</td>
<td class=ar>3</td>
<td class=ar>1</td>
<td class=ar>21</td>
<td class=ar>39</td>
<td class=al>&nbsp;:&nbsp;128</td>
<td class=ar>7</td>
<td class=art>84</td>
<td class=ar>&nbsp;</td>
</tr><tr><td class=br>48.</td>
<td class=bl><a href="../../../thstats/overview_co.aspx?idpl=1970&x=386">Písečka Jiří</a></td>
<td class=bl>České Budějovice</td>
<td class=br>25</td>
<td class=br>4</td>
<td class=br>1</td>
<td class=br>20</td>
<td class=br>53</td>
<td class=bl>&nbsp;:&nbsp;128</td>
<td class=br>9</td>
<td class=brt>83</td>
<td class=br>&nbsp;</td>
</tr></table></td></tr></table></div></p>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
