<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2023">Czech Open</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 4</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1616&x=-390&p=Em%20Larsson">Em Larsson</a></td><td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>5:6</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=br>61:20</td><td class=br>+41</td>
<td class=bc>12 - 0 - 2</td>
<td class=br><strong>24</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1772&x=-390&p=El%20Silin%C5%A1">El Silinš</a></td><td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=br>59:27</td><td class=br>+32</td>
<td class=bc>11 - 1 - 2</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1977&x=-390&p=Ti%20Dion">Ti Dion</a></td><td class=kW>6:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>8:3</td>
<td class=kW>4:3</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>8:0</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=br>62:32</td><td class=br>+30</td>
<td class=bc>11 - 1 - 2</td>
<td class=br><strong>23</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1579&x=-390&p=Vi%20Henttonen">Vi Henttonen</a></td><td class=kL>0:6</td>
<td class=kT>4:4</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>44:28</td><td class=br>+16</td>
<td class=bc>10 - 1 - 3</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1065&x=-390&p=Kr%20Herold">Kr Herold</a></td><td class=kL>0:6</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>7:1</td>
<td class=br>46:30</td><td class=br>+16</td>
<td class=bc>9 - 1 - 4</td>
<td class=br><strong>19</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2003&x=-390&p=An%20Kimberg">An Kimberg</a></td><td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>40:23</td><td class=br>+17</td>
<td class=bc>8 - 2 - 4</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=53&x=-390&p=V%C3%A1%20Pikl">Vá Pikl</a></td><td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kW>6:3</td>
<td class=kW>6:0</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kT>4:4</td>
<td class=kW>6:0</td>
<td class=br>40:26</td><td class=br>+14</td>
<td class=bc>8 - 1 - 5</td>
<td class=br><strong>17</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1117&x=-390&p=To%20Kahoun%20ml.">To Kahoun ml.</a></td><td class=kL>0:3</td>
<td class=kL>2:6</td>
<td class=kL>3:8</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>9:0</td>
<td class=kL>3:7</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=br>40:37</td><td class=br>+3</td>
<td class=bc>7 - 2 - 5</td>
<td class=br><strong>16</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2000&x=-390&p=Da%20Hasler">Da Hasler</a></td><td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kW>7:2</td>
<td class=br>35:37</td><td class=br>-2</td>
<td class=bc>6 - 1 - 7</td>
<td class=br><strong>13</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1409&x=-390&p=Ji%20Mal%C3%ADk">Ji Malík</a></td><td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>0:9</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=br>24:54</td><td class=br>-30</td>
<td class=bc>3 - 2 - 9</td>
<td class=br><strong>8</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=818&x=-390&p=Ro%20Je%C5%BE">Ro Jež</a></td><td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kW>3:0</td>
<td class=kW>7:3</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>10:0</td>
<td class=br>39:42</td><td class=br>-3</td>
<td class=bc>4 - 0 - 10</td>
<td class=br><strong>8</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=4&x=-390&p=Vl%20Kraus">Vl Kraus</a></td><td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=kW>6:1</td>
<td class=br>35:44</td><td class=br>-9</td>
<td class=bc>3 - 1 - 10</td>
<td class=br><strong>7</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2005&x=-390&p=Do%20Zupan%C4%8Di%C4%8D">Do Zupančič</a></td><td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>0:8</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=br>15:49</td><td class=br>-34</td>
<td class=bc>3 - 1 - 10</td>
<td class=br><strong>7</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1941&x=-390&p=Ja%20Kopeck%C3%BD">Ja Kopecký</a></td><td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>1:7</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=br>24:47</td><td class=br>-23</td>
<td class=bc>2 - 2 - 10</td>
<td class=br><strong>6</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2020&x=-390&p=Da%20Jerabek">Da Jerabek</a></td><td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kL>0:10</td>
<td class=kL>1:6</td>
<td class=kL>0:1</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=br>8:76</td><td class=br>-68</td>
<td class=bc>0 - 0 - 14</td>
<td class=br><strong>0</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Do Zupančič</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Da Hasler</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Da Jerabek</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>4 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
