<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2023">Czech Open</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=910&x=-390&p=Vl%20Gobyov%C3%A1">Vl Gobyová</a></td><td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=br>50:12</td><td class=br>+38</td>
<td class=bc>12 - 1 - 0</td>
<td class=br><strong>25</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1896&x=-390&p=Ra%20Hrn%C4%8D%C3%AD%C5%99">Ra Hrnčíř</a></td><td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kT>0:0</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>36:14</td><td class=br>+22</td>
<td class=bc>9 - 2 - 2</td>
<td class=br><strong>20</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2020&x=-390&p=Da%20Jerabek">Da Jerabek</a></td><td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>40:12</td><td class=br>+28</td>
<td class=bc>10 - 0 - 3</td>
<td class=br><strong>20</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1941&x=-390&p=Ja%20Kopeck%C3%BD">Ja Kopecký</a></td><td class=kL>0:4</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=br>32:19</td><td class=br>+13</td>
<td class=bc>7 - 3 - 3</td>
<td class=br><strong>17</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1959&x=-390&p=On%20Chlebo">On Chlebo</a></td><td class=kL>2:5</td>
<td class=kT>0:0</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=br>31:23</td><td class=br>+8</td>
<td class=bc>7 - 2 - 4</td>
<td class=br><strong>16</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2025&x=-390&p=Vo%20Gorej">Vo Gorej</a></td><td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>0:2</td>
<td class=kW>6:1</td>
<td class=kW>8:0</td>
<td class=kW>8:0</td>
<td class=br>37:20</td><td class=br>+17</td>
<td class=bc>6 - 4 - 3</td>
<td class=br><strong>16</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2018&x=-390&p=Ja%20Janou%C5%A1kovec">Ja Janouškovec</a></td><td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>7:0</td>
<td class=br>34:30</td><td class=br>+4</td>
<td class=bc>6 - 2 - 5</td>
<td class=br><strong>14</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1626&x=-390&p=Mi%20Hor%C3%A1kov%C3%A1">Mi Horáková</a></td><td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>6:0</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=br>41:35</td><td class=br>+6</td>
<td class=bc>7 - 0 - 6</td>
<td class=br><strong>14</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1869&x=-390&p=Pe%20Klazar">Pe Klazar</a></td><td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kW>5:0</td>
<td class=kW>4:3</td>
<td class=br>28:35</td><td class=br>-7</td>
<td class=bc>4 - 2 - 7</td>
<td class=br><strong>10</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1999&x=-390&p=Fi%20Pano%C5%A1">Fi Panoš</a></td><td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kT>0:0</td>
<td class=kW>1:0</td>
<td class=br>8:24</td><td class=br>-16</td>
<td class=bc>2 - 4 - 7</td>
<td class=br><strong>8</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2004&x=-390&p=Ur%20Me%C5%BEek">Ur Mežek</a></td><td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>4:8</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=br>25:46</td><td class=br>-21</td>
<td class=bc>3 - 2 - 8</td>
<td class=br><strong>8</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2019&x=-390&p=Pa%20Janou%C5%A1kovec">Pa Janouškovec</a></td><td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kW>8:4</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>4:0</td>
<td class=br>23:40</td><td class=br>-17</td>
<td class=bc>3 - 1 - 9</td>
<td class=br><strong>7</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2021&x=-390&p=Kr%20Novotn%C3%BD">Kr Novotný</a></td><td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>0:8</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=br>11:45</td><td class=br>-34</td>
<td class=bc>1 - 3 - 9</td>
<td class=br><strong>5</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2023&x=-390&p=Al%20Vinnichuk">Al Vinnichuk</a></td><td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:8</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=br>8:49</td><td class=br>-41</td>
<td class=bc>1 - 0 - 12</td>
<td class=br><strong>2</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Al Vinnichuk</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ur Mežek</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Pa Janouškovec</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=blW>On Chlebo</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Al Vinnichuk</td><td class=bc>-</td><td class=blW>Vo Gorej</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ur Mežek</td><td class=bc>-</td><td class=blW>Ja Janouškovec</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Da Jerabek</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ja Kopecký</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Fi Panoš</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Vo Gorej</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Al Vinnichuk</td><td class=bc>-</td><td class=blW>Ja Janouškovec</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ur Mežek</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>On Chlebo</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=bl>Fi Panoš</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=blW>Ja Janouškovec</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Vo Gorej</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Al Vinnichuk</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ur Mežek</td><td class=bc>-</td><td class=bl>Fi Panoš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ja Kopecký</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Da Jerabek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=blW>Kr Novotný</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>On Chlebo</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Vinnichuk</td><td class=bc>-</td><td class=blW>Fi Panoš</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ur Mežek</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ja Kopecký</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Da Jerabek</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>On Chlebo</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=blW>Fi Panoš</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Al Vinnichuk</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ur Mežek</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Kr Novotný</td><td class=bc>-</td><td class=blW>On Chlebo</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Da Jerabek</td><td class=bc>-</td><td class=bl>Fi Panoš</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ja Janouškovec</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al Vinnichuk</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kr Novotný</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Jerabek</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ja Janouškovec</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pa Janouškovec</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al Vinnichuk</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>On Chlebo</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr Novotný</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Da Jerabek</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Pa Janouškovec</td><td class=bc>-</td><td class=bl>Al Vinnichuk</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ja Kopecký</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Ur Mežek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kr Novotný</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Da Jerabek</td><td class=bc>-</td><td class=bl>Al Vinnichuk</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Vo Gorej</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>On Chlebo</td><td class=bc>-</td><td class=bl>Al Vinnichuk</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kr Novotný</td><td class=bc>-</td><td class=blW>Vo Gorej</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Da Jerabek</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ja Kopecký</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Al Vinnichuk</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=blW>Vo Gorej</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Novotný</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Jerabek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ja Kopecký</td><td class=bc>-</td><td class=bl>Al Vinnichuk</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=blW>Ja Janouškovec</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Da Jerabek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr Novotný</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ur Mežek</td><td class=bc>-</td><td class=bl>Al Vinnichuk</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ja Kopecký</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Da Jerabek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
