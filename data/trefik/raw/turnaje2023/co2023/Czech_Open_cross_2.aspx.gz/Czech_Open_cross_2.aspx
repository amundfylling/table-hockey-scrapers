<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2023">Czech Open</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1649&x=-390&p=Ra%20Miglinieks">Ra Miglinieks</a></td><td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=kW>7:0</td>
<td class=kW>6:0</td>
<td class=br>72:16</td><td class=br>+56</td>
<td class=bc>13 - 1 - 0</td>
<td class=br><strong>27</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=347&x=-390&p=Ma%20Papp">Ma Papp</a></td><td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kL>4:5</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=br>45:28</td><td class=br>+17</td>
<td class=bc>11 - 0 - 3</td>
<td class=br><strong>22</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=567&x=-390&p=Kr%20Lebl">Kr Lebl</a></td><td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kL>1:3</td>
<td class=kW>7:1</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>8:0</td>
<td class=br>61:17</td><td class=br>+44</td>
<td class=bc>11 - 0 - 3</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1978&x=-390&p=My%20Verbytskyy">My Verbytskyy</a></td><td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=br>41:32</td><td class=br>+9</td>
<td class=bc>8 - 2 - 4</td>
<td class=br><strong>18</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=344&x=-390&p=Ge%20Regula">Ge Regula</a></td><td class=kL>1:6</td>
<td class=kW>3:0</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kW>7:0</td>
<td class=kW>7:0</td>
<td class=br>50:33</td><td class=br>+17</td>
<td class=bc>8 - 2 - 4</td>
<td class=br><strong>18</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=448&x=-390&p=To%20Waclawek">To Waclawek</a></td><td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>7:0</td>
<td class=kW>4:1</td>
<td class=kW>7:3</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=br>56:29</td><td class=br>+27</td>
<td class=bc>8 - 2 - 4</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2006&x=-390&p=G%C3%B6%20L%C3%B6nnqvist">Gö Lönnqvist</a></td><td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=br>46:39</td><td class=br>+7</td>
<td class=bc>7 - 3 - 4</td>
<td class=br><strong>17</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=961&x=-390&p=Mi%20Bo%C5%A1t%C3%ADk">Mi Boštík</a></td><td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=br>51:36</td><td class=br>+15</td>
<td class=bc>8 - 0 - 6</td>
<td class=br><strong>16</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1828&x=-390&p=Tr%20Mansson">Tr Mansson</a></td><td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>9:0</td>
<td class=kW>9:1</td>
<td class=br>40:28</td><td class=br>+12</td>
<td class=bc>6 - 1 - 7</td>
<td class=br><strong>13</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=18&x=-390&p=An%20%C5%A0ur%C3%BDn">An Šurýn</a></td><td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>7:2</td>
<td class=kL>3:4</td>
<td class=kW>5:0</td>
<td class=br>33:43</td><td class=br>-10</td>
<td class=bc>6 - 0 - 8</td>
<td class=br><strong>12</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1927&x=-390&p=Vo%20Kraus">Vo Kraus</a></td><td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>0:7</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=br>27:44</td><td class=br>-17</td>
<td class=bc>4 - 0 - 10</td>
<td class=br><strong>8</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1058&x=-390&p=Fr%20Marek">Fr Marek</a></td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>0:5</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=br>21:42</td><td class=br>-21</td>
<td class=bc>4 - 0 - 10</td>
<td class=br><strong>8</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1973&x=-390&p=Br%20Sabo">Br Sabo</a></td><td class=kL>0:8</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>3:7</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kL>1:6</td>
<td class=kW>5:0</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=br>27:59</td><td class=br>-32</td>
<td class=bc>2 - 2 - 10</td>
<td class=br><strong>6</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2004&x=-390&p=Ur%20Me%C5%BEek">Ur Mežek</a></td><td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kL>0:9</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=br>17:69</td><td class=br>-52</td>
<td class=bc>1 - 2 - 11</td>
<td class=br><strong>4</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1959&x=-390&p=On%20Chlebo">On Chlebo</a></td><td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>0:8</td>
<td class=kL>1:7</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>1:9</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=br>5:77</td><td class=br>-72</td>
<td class=bc>0 - 1 - 13</td>
<td class=br><strong>1</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Gö Lönnqvist</td><td class=bc>-</td><td class=blW>Ge Regula</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=blW>Ma Papp</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>0 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
