<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2023">Czech Open</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 5</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2002&x=-390&p=Hu%20L%C3%B6nnqvist">Hu Lönnqvist</a></td><td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>8:1</td>
<td class=kW>6:1</td>
<td class=br>54:18</td><td class=br>+36</td>
<td class=bc>11 - 2 - 1</td>
<td class=br><strong>24</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2026&x=-390&p=An%20Kuznecovs">An Kuznecovs</a></td><td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>8:2</td>
<td class=kW>5:3</td>
<td class=kW>7:3</td>
<td class=kW>14:1</td>
<td class=br>73:33</td><td class=br>+40</td>
<td class=bc>11 - 1 - 2</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=64&x=-390&p=Da%20%C5%A0m%C3%ADd">Da Šmíd</a></td><td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kW>8:2</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=br>52:23</td><td class=br>+29</td>
<td class=bc>9 - 2 - 3</td>
<td class=br><strong>20</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2024&x=-390&p=Em%20Liepins">Em Liepins</a></td><td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kW>6:4</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kL>1:2</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>15:0</td>
<td class=br>62:30</td><td class=br>+32</td>
<td class=bc>9 - 1 - 4</td>
<td class=br><strong>19</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1641&x=-390&p=Ma%20Klazar">Ma Klazar</a></td><td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=br>39:25</td><td class=br>+14</td>
<td class=bc>8 - 1 - 5</td>
<td class=br><strong>17</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1650&x=-390&p=Va%20Dietze">Va Dietze</a></td><td class=kL>1:6</td>
<td class=kT>4:4</td>
<td class=kL>2:8</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>7:2</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>9:1</td>
<td class=br>58:41</td><td class=br>+17</td>
<td class=bc>7 - 3 - 4</td>
<td class=br><strong>17</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1033&x=-390&p=Si%20Thomas">Si Thomas</a></td><td class=kT>1:1</td>
<td class=kL>2:7</td>
<td class=kW>4:1</td>
<td class=kL>2:7</td>
<td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kT>5:5</td>
<td class=kW>6:2</td>
<td class=kL>2:5</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=br>49:39</td><td class=br>+10</td>
<td class=bc>7 - 2 - 5</td>
<td class=br><strong>16</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1845&x=-390&p=My%20Shalomayev">My Shalomayev</a></td><td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>4:6</td>
<td class=kW>2:1</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>8:1</td>
<td class=kW>12:1</td>
<td class=br>57:37</td><td class=br>+20</td>
<td class=bc>7 - 2 - 5</td>
<td class=br><strong>16</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1291&x=-390&p=Ma%20Dion">Ma Dion</a></td><td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>8:1</td>
<td class=br>34:41</td><td class=br>-7</td>
<td class=bc>6 - 2 - 6</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2001&x=-390&p=Gl%20Storozhenko">Gl Storozhenko</a></td><td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kT>5:5</td>
<td class=kL>1:6</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>12:1</td>
<td class=kW>10:3</td>
<td class=br>50:51</td><td class=br>-1</td>
<td class=bc>5 - 2 - 7</td>
<td class=br><strong>12</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2017&x=-390&p=Ka%20Pirumshoeva">Ka Pirumshoeva</a></td><td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>7:0</td>
<td class=br>27:38</td><td class=br>-11</td>
<td class=bc>5 - 1 - 8</td>
<td class=br><strong>11</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1940&x=-390&p=Ma%20Ko%C5%A1%C5%88ar">Ma Košňar</a></td><td class=kL>1:3</td>
<td class=kL>2:8</td>
<td class=kL>0:3</td>
<td class=kL>4:5</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kW>5:3</td>
<td class=kW>7:0</td>
<td class=br>36:42</td><td class=br>-6</td>
<td class=bc>4 - 2 - 8</td>
<td class=br><strong>10</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=204&x=-390&p=Hy%20Nechutn%C3%BD">Hy Nechutný</a></td><td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>4:0</td>
<td class=br>24:40</td><td class=br>-16</td>
<td class=bc>2 - 4 - 8</td>
<td class=br><strong>8</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1896&x=-390&p=Ra%20Hrn%C4%8D%C3%AD%C5%99">Ra Hrnčíř</a></td><td class=kL>1:8</td>
<td class=kL>3:7</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>1:8</td>
<td class=kL>1:2</td>
<td class=kL>1:12</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=br>24:74</td><td class=br>-50</td>
<td class=bc>1 - 1 - 12</td>
<td class=br><strong>3</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2018&x=-390&p=Ja%20Janou%C5%A1kovec">Ja Janouškovec</a></td><td class=kL>1:6</td>
<td class=kL>1:14</td>
<td class=kL>0:7</td>
<td class=kL>0:15</td>
<td class=kL>0:7</td>
<td class=kL>1:9</td>
<td class=kL>0:6</td>
<td class=kL>1:12</td>
<td class=kL>1:8</td>
<td class=kL>3:10</td>
<td class=kL>0:7</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=br>8:115</td><td class=br>-107</td>
<td class=bc>0 - 0 - 14</td>
<td class=br><strong>0</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ma Dion</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>1 : 12</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 12</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>An Kuznecovs</td><td class=bc>-</td><td class=blW>Hu Lönnqvist</td><td class=bc>3 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
