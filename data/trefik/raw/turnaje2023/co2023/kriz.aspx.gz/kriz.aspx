<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2023">Czech Open, 22. duben 2023</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Základní skupiny (Basic groups)</a><br>
<a href="#final">Výkonnostní skupiny (Final groups)</a><br>
<a name="basic"><p class=vm>Základní skupiny (Basic groups)</p></a>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1761&x=-390&p=Ra%20Kalnin%C5%A1">Ra Kalninš</a></td><td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>7:1</td>
<td class=kW>7:1</td>
<td class=kW>8:2</td>
<td class=kW>11:0</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=br>80:21</td><td class=br>+59</td>
<td class=bc>13 - 1 - 0</td>
<td class=br><strong>27</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1251&x=-390&p=Ho%20Sl%C3%A1dek">Ho Sládek</a></td><td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>3:6</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kW>9:1</td>
<td class=br>52:30</td><td class=br>+22</td>
<td class=bc>10 - 2 - 2</td>
<td class=br><strong>22</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1975&x=-390&p=Gu%20Hermansson">Gu Hermansson</a></td><td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=br>52:26</td><td class=br>+26</td>
<td class=bc>9 - 2 - 3</td>
<td class=br><strong>20</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=248&x=-390&p=Ma%20%C5%BDen%C3%AD%C5%A1ek">Ma Ženíšek</a></td><td class=kL>2:3</td>
<td class=kW>6:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kW>6:0</td>
<td class=kW>8:0</td>
<td class=br>57:31</td><td class=br>+26</td>
<td class=bc>9 - 1 - 4</td>
<td class=br><strong>19</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2022&x=-390&p=Da%20Hrustaljova">Da Hrustaljova</a></td><td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=br>34:24</td><td class=br>+10</td>
<td class=bc>8 - 2 - 4</td>
<td class=br><strong>18</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1622&x=-390&p=He%20Petuch">He Petuch</a></td><td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=br>39:33</td><td class=br>+6</td>
<td class=bc>6 - 3 - 5</td>
<td class=br><strong>15</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1488&x=-390&p=Ra%20Pommerenke">Ra Pommerenke</a></td><td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=br>34:32</td><td class=br>+2</td>
<td class=bc>5 - 5 - 4</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1980&x=-390&p=Ja%20Zalite">Ja Zalite</a></td><td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>8:0</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=kW>8:0</td>
<td class=br>44:21</td><td class=br>+23</td>
<td class=bc>6 - 3 - 5</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=32&x=-390&p=Ji%20Krop%C3%A1%C4%8Dek">Ji Kropáček</a></td><td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>4:5</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>6:4</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kW>8:2</td>
<td class=br>38:49</td><td class=br>-11</td>
<td class=bc>7 - 0 - 7</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=26&x=-390&p=Mi%20%C5%A0evr">Mi Ševr</a></td><td class=kL>1:7</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>8:2</td>
<td class=kW>7:0</td>
<td class=br>47:41</td><td class=br>+6</td>
<td class=bc>5 - 4 - 5</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1318&x=-390&p=Jo%20Sedl%C3%A1%C4%8Dek">Jo Sedláček</a></td><td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kL>4:6</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=br>33:50</td><td class=br>-17</td>
<td class=bc>5 - 1 - 8</td>
<td class=br><strong>11</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1630&x=-390&p=Pe%20Holub">Pe Holub</a></td><td class=kL>2:8</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>0:8</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=br>35:49</td><td class=br>-14</td>
<td class=bc>3 - 3 - 8</td>
<td class=br><strong>9</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2014&x=-390&p=Ma%20Hlava%C4%8Dka">Ma Hlavačka</a></td><td class=kL>0:11</td>
<td class=kL>3:6</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kW>3:1</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>27:58</td><td class=br>-31</td>
<td class=bc>3 - 0 - 11</td>
<td class=br><strong>6</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=910&x=-390&p=Vl%20Gobyov%C3%A1">Vl Gobyová</a></td><td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kL>2:8</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=br>18:52</td><td class=br>-34</td>
<td class=bc>1 - 3 - 10</td>
<td class=br><strong>5</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1999&x=-390&p=Fi%20Pano%C5%A1">Fi Panoš</a></td><td class=kL>2:5</td>
<td class=kL>1:9</td>
<td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kL>0:2</td>
<td class=kL>0:8</td>
<td class=kL>2:8</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=br>8:81</td><td class=br>-73</td>
<td class=bc>0 - 0 - 14</td>
<td class=br><strong>0</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Ja Zalite</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>2 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1649&x=-390&p=Ra%20Miglinieks">Ra Miglinieks</a></td><td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=kW>7:0</td>
<td class=kW>6:0</td>
<td class=br>72:16</td><td class=br>+56</td>
<td class=bc>13 - 1 - 0</td>
<td class=br><strong>27</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=347&x=-390&p=Ma%20Papp">Ma Papp</a></td><td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kL>4:5</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=br>45:28</td><td class=br>+17</td>
<td class=bc>11 - 0 - 3</td>
<td class=br><strong>22</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=567&x=-390&p=Kr%20Lebl">Kr Lebl</a></td><td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kL>1:3</td>
<td class=kW>7:1</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>8:0</td>
<td class=br>61:17</td><td class=br>+44</td>
<td class=bc>11 - 0 - 3</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1978&x=-390&p=My%20Verbytskyy">My Verbytskyy</a></td><td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=br>41:32</td><td class=br>+9</td>
<td class=bc>8 - 2 - 4</td>
<td class=br><strong>18</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=344&x=-390&p=Ge%20Regula">Ge Regula</a></td><td class=kL>1:6</td>
<td class=kW>3:0</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kW>7:0</td>
<td class=kW>7:0</td>
<td class=br>50:33</td><td class=br>+17</td>
<td class=bc>8 - 2 - 4</td>
<td class=br><strong>18</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=448&x=-390&p=To%20Waclawek">To Waclawek</a></td><td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>7:0</td>
<td class=kW>4:1</td>
<td class=kW>7:3</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=br>56:29</td><td class=br>+27</td>
<td class=bc>8 - 2 - 4</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2006&x=-390&p=G%C3%B6%20L%C3%B6nnqvist">Gö Lönnqvist</a></td><td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=br>46:39</td><td class=br>+7</td>
<td class=bc>7 - 3 - 4</td>
<td class=br><strong>17</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=961&x=-390&p=Mi%20Bo%C5%A1t%C3%ADk">Mi Boštík</a></td><td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=br>51:36</td><td class=br>+15</td>
<td class=bc>8 - 0 - 6</td>
<td class=br><strong>16</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1828&x=-390&p=Tr%20Mansson">Tr Mansson</a></td><td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kW>9:0</td>
<td class=kW>9:1</td>
<td class=br>40:28</td><td class=br>+12</td>
<td class=bc>6 - 1 - 7</td>
<td class=br><strong>13</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=18&x=-390&p=An%20%C5%A0ur%C3%BDn">An Šurýn</a></td><td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>7:2</td>
<td class=kL>3:4</td>
<td class=kW>5:0</td>
<td class=br>33:43</td><td class=br>-10</td>
<td class=bc>6 - 0 - 8</td>
<td class=br><strong>12</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1927&x=-390&p=Vo%20Kraus">Vo Kraus</a></td><td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>0:7</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=br>27:44</td><td class=br>-17</td>
<td class=bc>4 - 0 - 10</td>
<td class=br><strong>8</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1058&x=-390&p=Fr%20Marek">Fr Marek</a></td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>0:5</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=br>21:42</td><td class=br>-21</td>
<td class=bc>4 - 0 - 10</td>
<td class=br><strong>8</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1973&x=-390&p=Br%20Sabo">Br Sabo</a></td><td class=kL>0:8</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>3:7</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kL>1:6</td>
<td class=kW>5:0</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=br>27:59</td><td class=br>-32</td>
<td class=bc>2 - 2 - 10</td>
<td class=br><strong>6</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2004&x=-390&p=Ur%20Me%C5%BEek">Ur Mežek</a></td><td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kL>0:9</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=br>17:69</td><td class=br>-52</td>
<td class=bc>1 - 2 - 11</td>
<td class=br><strong>4</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1959&x=-390&p=On%20Chlebo">On Chlebo</a></td><td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>0:8</td>
<td class=kL>1:7</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>1:9</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=br>5:77</td><td class=br>-72</td>
<td class=bc>0 - 1 - 13</td>
<td class=br><strong>1</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Gö Lönnqvist</td><td class=bc>-</td><td class=blW>Ge Regula</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=blW>Ma Papp</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>0 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 3</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=409&x=-390&p=Pa%20Petr">Pa Petr</a></td><td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=kW>10:0</td>
<td class=br>74:26</td><td class=br>+48</td>
<td class=bc>10 - 4 - 0</td>
<td class=br><strong>24</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=993&x=-390&p=Ji%20Chyl%C3%ADk%20ml.">Ji Chylík ml.</a></td><td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kW>7:2</td>
<td class=kW>3:0</td>
<td class=kW>8:0</td>
<td class=br>62:22</td><td class=br>+40</td>
<td class=bc>10 - 3 - 1</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1&x=-390&p=Pa%20Ple%C5%A1%C3%A1k">Pa Plešák</a></td><td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>9:1</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>12:0</td>
<td class=br>63:24</td><td class=br>+39</td>
<td class=bc>8 - 5 - 1</td>
<td class=br><strong>21</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=101&x=-390&p=Mi%20Kubica">Mi Kubica</a></td><td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kW>6:2</td>
<td class=kW>10:1</td>
<td class=kW>6:2</td>
<td class=kW>8:0</td>
<td class=br>63:27</td><td class=br>+36</td>
<td class=bc>9 - 2 - 3</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1815&x=-390&p=An%20Bo%C5%BEi%C4%8D">An Božič</a></td><td class=kT>3:3</td>
<td class=kL>1:7</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=br>54:32</td><td class=br>+22</td>
<td class=bc>8 - 4 - 2</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1876&x=-390&p=Ad%20Kop%C5%99iva">Ad Kopřiva</a></td><td class=kT>3:3</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>9:3</td>
<td class=kW>8:4</td>
<td class=kW>7:3</td>
<td class=kW>4:0</td>
<td class=kW>10:0</td>
<td class=br>60:44</td><td class=br>+16</td>
<td class=bc>8 - 2 - 4</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=261&x=-390&p=Da%20Cibulka">Da Cibulka</a></td><td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>9:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>9:0</td>
<td class=br>53:32</td><td class=br>+21</td>
<td class=bc>6 - 3 - 5</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=40&x=-390&p=Da%20Mat%C3%BDsek">Da Matýsek</a></td><td class=kL>0:6</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=kW>7:0</td>
<td class=br>42:28</td><td class=br>+14</td>
<td class=bc>5 - 5 - 4</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1981&x=-390&p=Po%20Kvasnikova">Po Kvasnikova</a></td><td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kW>2:0</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=br>38:37</td><td class=br>+1</td>
<td class=bc>5 - 4 - 5</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=474&x=-390&p=Mi%20Margolis">Mi Margolis</a></td><td class=kL>1:6</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=br>33:43</td><td class=br>-10</td>
<td class=bc>6 - 1 - 7</td>
<td class=br><strong>13</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1957&x=-390&p=Er%20Bernhauser">Er Bernhauser</a></td><td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>3:9</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=br>31:56</td><td class=br>-25</td>
<td class=bc>4 - 1 - 9</td>
<td class=br><strong>9</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1917&x=-390&p=Fr%20Rasche">Fr Rasche</a></td><td class=kL>2:6</td>
<td class=kL>3:6</td>
<td class=kL>1:9</td>
<td class=kL>2:6</td>
<td class=kL>2:7</td>
<td class=kL>4:8</td>
<td class=kL>2:9</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=br>43:69</td><td class=br>-26</td>
<td class=bc>4 - 1 - 9</td>
<td class=br><strong>9</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1430&x=-390&p=Da%20Kadlec">Da Kadlec</a></td><td class=kL>0:5</td>
<td class=kL>2:7</td>
<td class=kL>1:7</td>
<td class=kL>1:10</td>
<td class=kL>1:6</td>
<td class=kL>3:7</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>0:7</td>
<td class=kW>5:0</td>
<td class=br>26:67</td><td class=br>-41</td>
<td class=bc>2 - 1 - 11</td>
<td class=br><strong>5</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1869&x=-390&p=Pe%20Klazar">Pe Klazar</a></td><td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>0:8</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kW>7:0</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=br>24:58</td><td class=br>-34</td>
<td class=bc>2 - 0 - 12</td>
<td class=br><strong>4</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2021&x=-390&p=Kr%20Novotn%C3%BD">Kr Novotný</a></td><td class=kL>0:10</td>
<td class=kL>0:8</td>
<td class=kL>0:12</td>
<td class=kL>0:8</td>
<td class=kL>0:7</td>
<td class=kL>0:10</td>
<td class=kL>0:9</td>
<td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=br>4:105</td><td class=br>-101</td>
<td class=bc>0 - 0 - 14</td>
<td class=br><strong>0</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Er Bernhauser</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Mi Margolis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>5 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 4</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1616&x=-390&p=Em%20Larsson">Em Larsson</a></td><td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>5:6</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=br>61:20</td><td class=br>+41</td>
<td class=bc>12 - 0 - 2</td>
<td class=br><strong>24</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1772&x=-390&p=El%20Silin%C5%A1">El Silinš</a></td><td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=br>59:27</td><td class=br>+32</td>
<td class=bc>11 - 1 - 2</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1977&x=-390&p=Ti%20Dion">Ti Dion</a></td><td class=kW>6:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>8:3</td>
<td class=kW>4:3</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>8:0</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=br>62:32</td><td class=br>+30</td>
<td class=bc>11 - 1 - 2</td>
<td class=br><strong>23</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1579&x=-390&p=Vi%20Henttonen">Vi Henttonen</a></td><td class=kL>0:6</td>
<td class=kT>4:4</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>44:28</td><td class=br>+16</td>
<td class=bc>10 - 1 - 3</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1065&x=-390&p=Kr%20Herold">Kr Herold</a></td><td class=kL>0:6</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>7:1</td>
<td class=br>46:30</td><td class=br>+16</td>
<td class=bc>9 - 1 - 4</td>
<td class=br><strong>19</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2003&x=-390&p=An%20Kimberg">An Kimberg</a></td><td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>40:23</td><td class=br>+17</td>
<td class=bc>8 - 2 - 4</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=53&x=-390&p=V%C3%A1%20Pikl">Vá Pikl</a></td><td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kW>6:3</td>
<td class=kW>6:0</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kT>4:4</td>
<td class=kW>6:0</td>
<td class=br>40:26</td><td class=br>+14</td>
<td class=bc>8 - 1 - 5</td>
<td class=br><strong>17</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1117&x=-390&p=To%20Kahoun%20ml.">To Kahoun ml.</a></td><td class=kL>0:3</td>
<td class=kL>2:6</td>
<td class=kL>3:8</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>9:0</td>
<td class=kL>3:7</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=br>40:37</td><td class=br>+3</td>
<td class=bc>7 - 2 - 5</td>
<td class=br><strong>16</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2000&x=-390&p=Da%20Hasler">Da Hasler</a></td><td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kW>7:2</td>
<td class=br>35:37</td><td class=br>-2</td>
<td class=bc>6 - 1 - 7</td>
<td class=br><strong>13</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1409&x=-390&p=Ji%20Mal%C3%ADk">Ji Malík</a></td><td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>0:9</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=br>24:54</td><td class=br>-30</td>
<td class=bc>3 - 2 - 9</td>
<td class=br><strong>8</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=818&x=-390&p=Ro%20Je%C5%BE">Ro Jež</a></td><td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kW>3:0</td>
<td class=kW>7:3</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>10:0</td>
<td class=br>39:42</td><td class=br>-3</td>
<td class=bc>4 - 0 - 10</td>
<td class=br><strong>8</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=4&x=-390&p=Vl%20Kraus">Vl Kraus</a></td><td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=kW>6:1</td>
<td class=br>35:44</td><td class=br>-9</td>
<td class=bc>3 - 1 - 10</td>
<td class=br><strong>7</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2005&x=-390&p=Do%20Zupan%C4%8Di%C4%8D">Do Zupančič</a></td><td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>0:8</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=br>15:49</td><td class=br>-34</td>
<td class=bc>3 - 1 - 10</td>
<td class=br><strong>7</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1941&x=-390&p=Ja%20Kopeck%C3%BD">Ja Kopecký</a></td><td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>1:7</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=br>24:47</td><td class=br>-23</td>
<td class=bc>2 - 2 - 10</td>
<td class=br><strong>6</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2020&x=-390&p=Da%20Jerabek">Da Jerabek</a></td><td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kL>0:10</td>
<td class=kL>1:6</td>
<td class=kL>0:1</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=br>8:76</td><td class=br>-68</td>
<td class=bc>0 - 0 - 14</td>
<td class=br><strong>0</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Do Zupančič</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Da Hasler</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Da Jerabek</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>4 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 5</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2002&x=-390&p=Hu%20L%C3%B6nnqvist">Hu Lönnqvist</a></td><td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>8:1</td>
<td class=kW>6:1</td>
<td class=br>54:18</td><td class=br>+36</td>
<td class=bc>11 - 2 - 1</td>
<td class=br><strong>24</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2026&x=-390&p=An%20Kuznecovs">An Kuznecovs</a></td><td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>8:2</td>
<td class=kW>5:3</td>
<td class=kW>7:3</td>
<td class=kW>14:1</td>
<td class=br>73:33</td><td class=br>+40</td>
<td class=bc>11 - 1 - 2</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=64&x=-390&p=Da%20%C5%A0m%C3%ADd">Da Šmíd</a></td><td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kW>8:2</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=br>52:23</td><td class=br>+29</td>
<td class=bc>9 - 2 - 3</td>
<td class=br><strong>20</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2024&x=-390&p=Em%20Liepins">Em Liepins</a></td><td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kW>6:4</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kL>1:2</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>15:0</td>
<td class=br>62:30</td><td class=br>+32</td>
<td class=bc>9 - 1 - 4</td>
<td class=br><strong>19</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1641&x=-390&p=Ma%20Klazar">Ma Klazar</a></td><td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=br>39:25</td><td class=br>+14</td>
<td class=bc>8 - 1 - 5</td>
<td class=br><strong>17</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1650&x=-390&p=Va%20Dietze">Va Dietze</a></td><td class=kL>1:6</td>
<td class=kT>4:4</td>
<td class=kL>2:8</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>7:2</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>9:1</td>
<td class=br>58:41</td><td class=br>+17</td>
<td class=bc>7 - 3 - 4</td>
<td class=br><strong>17</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1033&x=-390&p=Si%20Thomas">Si Thomas</a></td><td class=kT>1:1</td>
<td class=kL>2:7</td>
<td class=kW>4:1</td>
<td class=kL>2:7</td>
<td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kT>5:5</td>
<td class=kW>6:2</td>
<td class=kL>2:5</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=br>49:39</td><td class=br>+10</td>
<td class=bc>7 - 2 - 5</td>
<td class=br><strong>16</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1845&x=-390&p=My%20Shalomayev">My Shalomayev</a></td><td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>4:6</td>
<td class=kW>2:1</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>8:1</td>
<td class=kW>12:1</td>
<td class=br>57:37</td><td class=br>+20</td>
<td class=bc>7 - 2 - 5</td>
<td class=br><strong>16</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1291&x=-390&p=Ma%20Dion">Ma Dion</a></td><td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>8:1</td>
<td class=br>34:41</td><td class=br>-7</td>
<td class=bc>6 - 2 - 6</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2001&x=-390&p=Gl%20Storozhenko">Gl Storozhenko</a></td><td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kT>5:5</td>
<td class=kL>1:6</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>12:1</td>
<td class=kW>10:3</td>
<td class=br>50:51</td><td class=br>-1</td>
<td class=bc>5 - 2 - 7</td>
<td class=br><strong>12</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2017&x=-390&p=Ka%20Pirumshoeva">Ka Pirumshoeva</a></td><td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>7:0</td>
<td class=br>27:38</td><td class=br>-11</td>
<td class=bc>5 - 1 - 8</td>
<td class=br><strong>11</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1940&x=-390&p=Ma%20Ko%C5%A1%C5%88ar">Ma Košňar</a></td><td class=kL>1:3</td>
<td class=kL>2:8</td>
<td class=kL>0:3</td>
<td class=kL>4:5</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kW>5:3</td>
<td class=kW>7:0</td>
<td class=br>36:42</td><td class=br>-6</td>
<td class=bc>4 - 2 - 8</td>
<td class=br><strong>10</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=204&x=-390&p=Hy%20Nechutn%C3%BD">Hy Nechutný</a></td><td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>4:0</td>
<td class=br>24:40</td><td class=br>-16</td>
<td class=bc>2 - 4 - 8</td>
<td class=br><strong>8</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1896&x=-390&p=Ra%20Hrn%C4%8D%C3%AD%C5%99">Ra Hrnčíř</a></td><td class=kL>1:8</td>
<td class=kL>3:7</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>1:8</td>
<td class=kL>1:2</td>
<td class=kL>1:12</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=br>24:74</td><td class=br>-50</td>
<td class=bc>1 - 1 - 12</td>
<td class=br><strong>3</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2018&x=-390&p=Ja%20Janou%C5%A1kovec">Ja Janouškovec</a></td><td class=kL>1:6</td>
<td class=kL>1:14</td>
<td class=kL>0:7</td>
<td class=kL>0:15</td>
<td class=kL>0:7</td>
<td class=kL>1:9</td>
<td class=kL>0:6</td>
<td class=kL>1:12</td>
<td class=kL>1:8</td>
<td class=kL>3:10</td>
<td class=kL>0:7</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=br>8:115</td><td class=br>-107</td>
<td class=bc>0 - 0 - 14</td>
<td class=br><strong>0</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ma Dion</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>1 : 12</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 12</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>An Kuznecovs</td><td class=bc>-</td><td class=blW>Hu Lönnqvist</td><td class=bc>3 : 5</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 6</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1174&x=-390&p=Ma%20Mad%C4%9Bra">Ma Maděra</a></td><td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>7:3</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>9:3</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>9:1</td>
<td class=kW>7:2</td>
<td class=kW>7:0</td>
<td class=kW>11:3</td>
<td class=br>82:23</td><td class=br>+59</td>
<td class=bc>14 - 0 - 1</td>
<td class=br><strong>28</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=310&x=-390&p=Mi%20%C4%8Cernoch">Mi Černoch</a></td><td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kT>0:0</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>8:0</td>
<td class=kW>9:0</td>
<td class=br>60:17</td><td class=br>+43</td>
<td class=bc>13 - 1 - 1</td>
<td class=br><strong>27</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1477&x=-390&p=Mi%20Kobrle">Mi Kobrle</a></td><td class=kL>3:7</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>12:1</td>
<td class=kW>7:1</td>
<td class=kW>9:4</td>
<td class=br>81:28</td><td class=br>+53</td>
<td class=bc>13 - 0 - 2</td>
<td class=br><strong>26</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=386&x=-390&p=Ku%20Sl%C3%A1dek">Ku Sládek</a></td><td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kW>9:2</td>
<td class=kW>9:0</td>
<td class=kW>5:2</td>
<td class=br>54:31</td><td class=br>+23</td>
<td class=bc>9 - 3 - 3</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=893&x=-390&p=Ne%20%C5%A0krlep">Ne Škrlep</a></td><td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kW>3:0</td>
<td class=kW>14:1</td>
<td class=kW>8:1</td>
<td class=kW>8:0</td>
<td class=br>59:26</td><td class=br>+33</td>
<td class=bc>10 - 0 - 5</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1872&x=-390&p=Pe%20Fuchs">Pe Fuchs</a></td><td class=kL>2:6</td>
<td class=kT>0:0</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=br>44:32</td><td class=br>+12</td>
<td class=bc>7 - 5 - 3</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=201&x=-390&p=To%20Bucek">To Bucek</a></td><td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>7:1</td>
<td class=kW>9:1</td>
<td class=kW>5:2</td>
<td class=br>51:33</td><td class=br>+18</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=346&x=-390&p=B%C3%A1%20Nagy">Bá Nagy</a></td><td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>38:36</td><td class=br>+2</td>
<td class=bc>6 - 2 - 7</td>
<td class=br><strong>14</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1912&x=-390&p=Al%20Krejza">Al Krejza</a></td><td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kW>6:1</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>7:2</td>
<td class=kW>10:1</td>
<td class=kW>7:1</td>
<td class=br>50:40</td><td class=br>+10</td>
<td class=bc>7 - 0 - 8</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=70&x=-390&p=St%20Srba">St Srba</a></td><td class=kL>3:9</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kL>3:6</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=br>37:43</td><td class=br>-6</td>
<td class=bc>6 - 2 - 7</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=227&x=-390&p=Mi%20Ma%C5%A1ika">Mi Mašika</a></td><td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>8:1</td>
<td class=kW>4:0</td>
<td class=kW>8:1</td>
<td class=br>37:34</td><td class=br>+3</td>
<td class=bc>4 - 4 - 7</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1587&x=-390&p=Ad%20Herold">Ad Herold</a></td><td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kT>0:0</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=br>25:46</td><td class=br>-21</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=176&x=-390&p=Zd%20Lopaur">Zd Lopaur</a></td><td class=kL>1:9</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>9:1</td>
<td class=kW>9:0</td>
<td class=kW>6:0</td>
<td class=br>44:42</td><td class=br>+2</td>
<td class=bc>4 - 2 - 9</td>
<td class=br><strong>10</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1626&x=-390&p=Mi%20Hor%C3%A1kov%C3%A1">Mi Horáková</a></td><td class=kL>2:7</td>
<td class=kL>2:6</td>
<td class=kL>1:12</td>
<td class=kL>2:9</td>
<td class=kL>1:14</td>
<td class=kL>2:5</td>
<td class=kL>1:7</td>
<td class=kL>0:6</td>
<td class=kL>2:7</td>
<td class=kL>2:6</td>
<td class=kL>1:8</td>
<td class=kL>0:3</td>
<td class=kL>1:9</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=br>25:103</td><td class=br>-78</td>
<td class=bc>2 - 0 - 13</td>
<td class=br><strong>4</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2019&x=-390&p=Pa%20Janou%C5%A1kovec">Pa Janouškovec</a></td><td class=kL>0:7</td>
<td class=kL>0:8</td>
<td class=kL>1:7</td>
<td class=kL>0:9</td>
<td class=kL>1:8</td>
<td class=kL>1:5</td>
<td class=kL>1:9</td>
<td class=kL>0:5</td>
<td class=kL>1:10</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>0:9</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=br>12:94</td><td class=br>-82</td>
<td class=bc>1 - 0 - 14</td>
<td class=br><strong>2</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>C</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2025&x=-390&p=Vo%20Gorej">Vo Gorej</a></td><td class=kL>3:11</td>
<td class=kL>0:9</td>
<td class=kL>4:9</td>
<td class=kL>2:5</td>
<td class=kL>0:8</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kL>1:8</td>
<td class=kL>3:5</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=br>22:93</td><td class=br>-71</td>
<td class=bc>0 - 0 - 15</td>
<td class=br><strong>0</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>Bá Nagy</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ad Herold</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>3 : 11</tr></td>
<tr><td class=brW>Ad Herold</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Bá Nagy</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ma Maděra</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ad Herold</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>Pa Janouškovec</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ad Herold</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Bá Nagy</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>Ad Herold</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Bá Nagy</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ad Herold</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Bá Nagy</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Ad Herold</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Mi Mašika</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Bá Nagy</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>Ad Herold</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ad Herold</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Mašika</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Bá Nagy</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>12 : 1</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ad Herold</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Bá Nagy</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=blW>Ad Herold</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>9 : 4</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Bá Nagy</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>9 : 3</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Bá Nagy</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ad Herold</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Ad Herold</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>1 : 14</tr></td>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Bá Nagy</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ad Herold</td><td class=bc>-</td><td class=blW>St Srba</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=blW>Bá Nagy</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ad Herold</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<hr><a name="final"><p class=vm>Výkonnostní skupiny (Final groups)</p></a>
<p class=v>Group A1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>25</td>
<td class=ic>26</td>
<td class=ic>27</td>
<td class=ic>28</td>
<td class=ic>29</td>
<td class=ic>30</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1761&x=-390&p=Ra%20Kalnin%C5%A1">Ra Kalninš</a></td><td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>6:3 K</td>
<td class=kL>3:4</td>
<td class=kW>7:4</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>6:1 K</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kW>6:2</td>
<td class=kW>7:1</td>
<td class=kW>3:2 K</td>
<td class=kW>5:2 K</td>
<td class=kL>0:5</td>
<td class=kW>8:2</td>
<td class=kW>5:2</td>
<td class=kW>4:0 K</td>
<td class=kW>5:2 K</td>
<td class=kW>6:0</td>
<td class=kW>10:0</td>
<td class=kW>8:2</td>
<td class=kW>8:1</td>
<td class=kW>7:1 K</td>
<td class=kW>4:2</td>
<td class=kT>2:2 K</td>
<td class=kW>8:1</td>
<td class=kW>7:2 K</td>
<td class=br>149:52</td><td class=br>+97</td>
<td class=bc>25 - 1 - 3</td>
<td class=br><strong>51</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=409&x=-390&p=Pa%20Petr">Pa Petr</a></td><td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>5:5 K</td>
<td class=kW>5:1</td>
<td class=kL>0:5</td>
<td class=kT>3:3 K</td>
<td class=kW>8:1</td>
<td class=kT>3:3 K</td>
<td class=kW>6:2 K</td>
<td class=kW>6:0 K</td>
<td class=kW>9:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kT>3:3 K</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kL>1:2</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>7:3</td>
<td class=kW>4:3 K</td>
<td class=kW>7:2</td>
<td class=kW>2:1</td>
<td class=kW>6:1 K</td>
<td class=kW>7:2</td>
<td class=kW>5:1 K</td>
<td class=kW>6:1</td>
<td class=br>129:56</td><td class=br>+73</td>
<td class=bc>20 - 5 - 4</td>
<td class=br><strong>45</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2002&x=-390&p=Hu%20L%C3%B6nnqvist">Hu Lönnqvist</a></td><td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:1 K</td>
<td class=kT>2:2</td>
<td class=kW>5:3 K</td>
<td class=kW>6:1 K</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>3:1 K</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kL>1:5</td>
<td class=kT>1:1 K</td>
<td class=kT>3:3 K</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>1:0 K</td>
<td class=kW>4:1 K</td>
<td class=kW>6:4</td>
<td class=kW>6:1 K</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=br>94:55</td><td class=br>+39</td>
<td class=bc>19 - 4 - 6</td>
<td class=br><strong>42</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1251&x=-390&p=Ho%20Sl%C3%A1dek">Ho Sládek</a></td><td class=kL>3:6 K</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kW>6:4</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kW>2:0 K</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>3:6 K</td>
<td class=kW>3:1 K</td>
<td class=kT>4:4</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>3:2 K</td>
<td class=kW>4:1 K</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kT>4:4 K</td>
<td class=kW>5:4</td>
<td class=kW>3:0 K</td>
<td class=kW>4:2</td>
<td class=kW>4:1 K</td>
<td class=br>99:67</td><td class=br>+32</td>
<td class=bc>18 - 5 - 6</td>
<td class=br><strong>41</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2024&x=-390&p=Em%20Liepins">Em Liepins</a></td><td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3 K</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kL>2:3 K</td>
<td class=kT>3:3 K</td>
<td class=kW>7:3</td>
<td class=kW>5:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>6:4 K</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kW>4:2</td>
<td class=kW>7:2 K</td>
<td class=kW>3:2 K</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2 K</td>
<td class=kW>6:1 K</td>
<td class=kW>2:0</td>
<td class=kL>2:3 K</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=br>104:62</td><td class=br>+42</td>
<td class=bc>18 - 4 - 7</td>
<td class=br><strong>40</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=993&x=-390&p=Ji%20Chyl%C3%ADk%20ml.">Ji Chylík ml.</a></td><td class=kL>4:7</td>
<td class=kT>5:5 K</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>7:1 K</td>
<td class=kL>1:2</td>
<td class=kW>3:0 K</td>
<td class=kT>1:1 K</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>6:0 K</td>
<td class=kW>1:0</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kT>3:3</td>
<td class=kW>5:2 K</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kL>3:4 K</td>
<td class=kW>7:0</td>
<td class=kW>4:2 K</td>
<td class=kW>3:0</td>
<td class=br>101:61</td><td class=br>+40</td>
<td class=bc>17 - 6 - 6</td>
<td class=br><strong>40</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2026&x=-390&p=An%20Kuznecovs">An Kuznecovs</a></td><td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>3:5 K</td>
<td class=kL>4:6</td>
<td class=kW>3:2 K</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kT>4:4 K</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>5:2 K</td>
<td class=kW>3:2</td>
<td class=kL>4:5</td>
<td class=kW>3:1</td>
<td class=kW>7:2 K</td>
<td class=kL>2:3 K</td>
<td class=kW>6:4</td>
<td class=kW>6:2</td>
<td class=kW>5:2 K</td>
<td class=kW>3:2 K</td>
<td class=kW>2:1</td>
<td class=kW>4:1 K</td>
<td class=kL>1:5</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=br>109:81</td><td class=br>+28</td>
<td class=bc>19 - 1 - 9</td>
<td class=br><strong>39</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1650&x=-390&p=Va%20Dietze">Va Dietze</a></td><td class=kL>3:5</td>
<td class=kW>5:0</td>
<td class=kL>1:6 K</td>
<td class=kW>3:2</td>
<td class=kT>3:3 K</td>
<td class=kL>2:3</td>
<td class=kT>4:4 K</td>
<td class=kx>*</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>7:2 K</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kL>0:3</td>
<td class=kW>5:3 K</td>
<td class=kL>2:8 K</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>2:3 K</td>
<td class=kL>3:4 K</td>
<td class=kW>5:2</td>
<td class=kT>3:3 K</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=br>98:80</td><td class=br>+18</td>
<td class=bc>15 - 5 - 9</td>
<td class=br><strong>35</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1815&x=-390&p=An%20Bo%C5%BEi%C4%8D">An Božič</a></td><td class=kL>0:3</td>
<td class=kT>3:3 K</td>
<td class=kW>4:2</td>
<td class=kL>3:5</td>
<td class=kL>3:7</td>
<td class=kL>1:7 K</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:5 K</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kW>5:1</td>
<td class=kW>3:1 K</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>2:0</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kW>2:1 K</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kW>6:2 K</td>
<td class=kW>6:0</td>
<td class=kT>4:4 K</td>
<td class=kW>5:1</td>
<td class=br>91:72</td><td class=br>+19</td>
<td class=bc>14 - 6 - 9</td>
<td class=br><strong>34</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1975&x=-390&p=Gu%20Hermansson">Gu Hermansson</a></td><td class=kL>1:6 K</td>
<td class=kL>1:8</td>
<td class=kL>2:5</td>
<td class=kL>0:2 K</td>
<td class=kL>4:5</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kW>5:1 K</td>
<td class=kT>2:2 K</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kL>1:3 K</td>
<td class=kT>2:2 K</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kW>4:2 K</td>
<td class=kW>5:0</td>
<td class=kW>4:1 K</td>
<td class=kW>2:1</td>
<td class=kW>7:2 K</td>
<td class=br>83:69</td><td class=br>+14</td>
<td class=bc>13 - 8 - 8</td>
<td class=br><strong>34</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=101&x=-390&p=Mi%20Kubica">Mi Kubica</a></td><td class=kL>1:3</td>
<td class=kT>3:3 K</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>0:3 K</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>5:2 K</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>2:6 K</td>
<td class=kW>5:2 K</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>7:1 K</td>
<td class=kL>2:5</td>
<td class=kL>1:7</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kL>1:4 K</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>3:0 K</td>
<td class=kW>3:1</td>
<td class=kT>1:1 K</td>
<td class=kW>5:0</td>
<td class=br>83:70</td><td class=br>+13</td>
<td class=bc>15 - 3 - 11</td>
<td class=br><strong>33</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1&x=-390&p=Pa%20Ple%C5%A1%C3%A1k">Pa Plešák</a></td><td class=kW>3:1</td>
<td class=kL>2:6 K</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kT>1:1 K</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2</td>
<td class=kW>6:2 K</td>
<td class=kx>*</td>
<td class=kT>1:1 K</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kW>4:0 K</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kT>4:4 K</td>
<td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kW>2:1 K</td>
<td class=kW>6:1</td>
<td class=kT>4:4 K</td>
<td class=kW>6:0</td>
<td class=br>82:69</td><td class=br>+13</td>
<td class=bc>12 - 8 - 9</td>
<td class=br><strong>32</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=40&x=-390&p=Da%20Mat%C3%BDsek">Da Matýsek</a></td><td class=kL>2:6</td>
<td class=kL>0:6 K</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kT>1:1 K</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kT>2:2 K</td>
<td class=kW>3:2</td>
<td class=kL>2:5 K</td>
<td class=kT>1:1 K</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>3:4 K</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kT>2:2 K</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kL>0:2 K</td>
<td class=kL>0:1</td>
<td class=kW>5:2 K</td>
<td class=kW>5:0</td>
<td class=br>67:70</td><td class=br>-3</td>
<td class=bc>12 - 7 - 10</td>
<td class=br><strong>31</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1845&x=-390&p=My%20Shalomayev">My Shalomayev</a></td><td class=kL>1:7</td>
<td class=kL>2:9</td>
<td class=kL>1:3 K</td>
<td class=kT>3:3</td>
<td class=kL>4:6 K</td>
<td class=kT>2:2</td>
<td class=kL>2:5 K</td>
<td class=kL>2:7 K</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kL>0:5 K</td>
<td class=kT>1:1 K</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>2:1 K</td>
<td class=kW>6:1 K</td>
<td class=kW>3:0</td>
<td class=kW>6:1 K</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=br>78:82</td><td class=br>-4</td>
<td class=bc>13 - 4 - 12</td>
<td class=br><strong>30</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=248&x=-390&p=Ma%20%C5%BDen%C3%AD%C5%A1ek">Ma Ženíšek</a></td><td class=kL>2:3 K</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kW>6:3 K</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kL>1:5 K</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:2 K</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kT>1:1 K</td>
<td class=kL>2:3 K</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kW>7:3</td>
<td class=kW>6:2</td>
<td class=kW>6:2 K</td>
<td class=kL>4:5</td>
<td class=kW>3:2 K</td>
<td class=kW>5:1</td>
<td class=kW>6:2 K</td>
<td class=br>89:79</td><td class=br>+10</td>
<td class=bc>13 - 4 - 12</td>
<td class=br><strong>30</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2022&x=-390&p=Da%20Hrustaljova">Da Hrustaljova</a></td><td class=kL>2:5 K</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3 K</td>
<td class=kW>2:0</td>
<td class=kL>3:4</td>
<td class=kW>5:4</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kW>2:1 K</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>1:0 K</td>
<td class=kW>2:0 K</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>4:2 K</td>
<td class=kT>1:1</td>
<td class=kL>1:2 K</td>
<td class=kW>2:0</td>
<td class=kW>4:2 K</td>
<td class=br>67:66</td><td class=br>+1</td>
<td class=bc>14 - 2 - 13</td>
<td class=br><strong>30</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1876&x=-390&p=Ad%20Kop%C5%99iva">Ad Kopřiva</a></td><td class=kW>5:0</td>
<td class=kT>3:3 K</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>0:6 K</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kL>1:3 K</td>
<td class=kT>3:3</td>
<td class=kL>1:7 K</td>
<td class=kL>0:4 K</td>
<td class=kW>4:3 K</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kW>5:3 K</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kT>3:3 K</td>
<td class=kW>3:0</td>
<td class=kW>5:2 K</td>
<td class=kT>5:5</td>
<td class=br>81:83</td><td class=br>-2</td>
<td class=bc>12 - 6 - 11</td>
<td class=br><strong>30</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1033&x=-390&p=Si%20Thomas">Si Thomas</a></td><td class=kL>2:8</td>
<td class=kL>0:2</td>
<td class=kT>1:1 K</td>
<td class=kL>0:4</td>
<td class=kL>2:7 K</td>
<td class=kL>0:1</td>
<td class=kL>2:7 K</td>
<td class=kL>3:5 K</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>5:0 K</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:1 K</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=kL>0:4 K</td>
<td class=kT>5:5 K</td>
<td class=kT>3:3</td>
<td class=kW>5:0 K</td>
<td class=kL>1:6</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=br>74:78</td><td class=br>-4</td>
<td class=bc>11 - 7 - 11</td>
<td class=br><strong>29</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=64&x=-390&p=Da%20%C5%A0m%C3%ADd">Da Šmíd</a></td><td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kT>3:3 K</td>
<td class=kL>0:2</td>
<td class=kL>2:3 K</td>
<td class=kL>3:5</td>
<td class=kW>3:2 K</td>
<td class=kW>8:2 K</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kW>7:1</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kT>1:1 K</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>1:4 K</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kW>5:0 K</td>
<td class=kW>7:2 K</td>
<td class=kL>1:5</td>
<td class=kL>2:3 K</td>
<td class=kW>3:2</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>7:2</td>
<td class=br>85:80</td><td class=br>+5</td>
<td class=bc>13 - 3 - 13</td>
<td class=br><strong>29</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1980&x=-390&p=Ja%20Zalite">Ja Zalite</a></td><td class=kL>0:4 K</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3 K</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>4:6</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kW>3:1 K</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kT>1:1 K</td>
<td class=kL>0:1 K</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1</td>
<td class=kL>0:2 K</td>
<td class=kW>2:0</td>
<td class=kW>6:1 K</td>
<td class=br>55:62</td><td class=br>-7</td>
<td class=bc>9 - 6 - 14</td>
<td class=br><strong>24</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1488&x=-390&p=Ra%20Pommerenke">Ra Pommerenke</a></td><td class=kL>2:5 K</td>
<td class=kL>1:7</td>
<td class=kW>3:1</td>
<td class=kL>1:4 K</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kW>3:2 K</td>
<td class=kL>0:2 K</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>0:1</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1</td>
<td class=kT>4:4 K</td>
<td class=kW>4:1</td>
<td class=kW>5:4 K</td>
<td class=br>56:82</td><td class=br>-26</td>
<td class=bc>8 - 6 - 15</td>
<td class=br><strong>22</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1641&x=-390&p=Ma%20Klazar">Ma Klazar</a></td><td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>0:1 K</td>
<td class=kL>3:6</td>
<td class=kL>2:3 K</td>
<td class=kL>0:6</td>
<td class=kL>2:5 K</td>
<td class=kW>3:2 K</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>1:2 K</td>
<td class=kW>4:2</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kW>4:0 K</td>
<td class=kL>0:5 K</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:1 K</td>
<td class=kL>3:4</td>
<td class=kW>3:2 K</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=br>61:87</td><td class=br>-26</td>
<td class=bc>9 - 4 - 16</td>
<td class=br><strong>22</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2001&x=-390&p=Gl%20Storozhenko">Gl Storozhenko</a></td><td class=kL>0:10</td>
<td class=kL>3:7</td>
<td class=kL>1:4 K</td>
<td class=kT>3:3</td>
<td class=kL>1:6 K</td>
<td class=kT>3:3</td>
<td class=kL>2:3 K</td>
<td class=kW>4:3 K</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>4:5</td>
<td class=kL>1:6 K</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kW>5:1</td>
<td class=kT>5:5 K</td>
<td class=kL>2:7 K</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>1:3 K</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:3 K</td>
<td class=kW>7:1</td>
<td class=kW>8:4</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=br>76:109</td><td class=br>-33</td>
<td class=bc>8 - 4 - 17</td>
<td class=br><strong>20</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=261&x=-390&p=Da%20Cibulka">Da Cibulka</a></td><td class=kL>2:8</td>
<td class=kL>3:4 K</td>
<td class=kL>4:6</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>2:5 K</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>1:2 K</td>
<td class=kT>0:0</td>
<td class=kW>4:1 K</td>
<td class=kT>4:4 K</td>
<td class=kT>2:2 K</td>
<td class=kL>0:3</td>
<td class=kL>3:7</td>
<td class=kL>3:4</td>
<td class=kL>3:5 K</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>4:5</td>
<td class=kW>5:2 K</td>
<td class=kW>4:3</td>
<td class=kL>0:2 K</td>
<td class=kT>1:1</td>
<td class=br>74:95</td><td class=br>-21</td>
<td class=bc>7 - 5 - 17</td>
<td class=br><strong>19</strong></td><td class=d>24.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>25.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1291&x=-390&p=Ma%20Dion">Ma Dion</a></td><td class=kL>1:8</td>
<td class=kL>2:7</td>
<td class=kL>1:6 K</td>
<td class=kL>0:4</td>
<td class=kW>3:2 K</td>
<td class=kL>3:5</td>
<td class=kL>1:4 K</td>
<td class=kT>3:3 K</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kW>6:2</td>
<td class=kL>0:3</td>
<td class=kL>1:6 K</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>0:5 K</td>
<td class=kW>3:2 K</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3 K</td>
<td class=kL>3:4 K</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=br>59:103</td><td class=br>-44</td>
<td class=bc>8 - 3 - 18</td>
<td class=br><strong>19</strong></td><td class=d>25.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>26.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=26&x=-390&p=Mi%20%C5%A0evr">Mi Ševr</a></td><td class=kL>1:7 K</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kT>4:4 K</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kL>2:4 K</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kL>2:6 K</td>
<td class=kL>2:4 K</td>
<td class=kL>1:6</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2 K</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:3 K</td>
<td class=kL>0:3</td>
<td class=kL>0:1 K</td>
<td class=br>60:108</td><td class=br>-48</td>
<td class=bc>6 - 4 - 19</td>
<td class=br><strong>16</strong></td><td class=d>26.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>27.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=474&x=-390&p=Mi%20Margolis">Mi Margolis</a></td><td class=kL>2:4</td>
<td class=kL>1:6 K</td>
<td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kW>3:1</td>
<td class=kW>4:3 K</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>2:6 K</td>
<td class=kL>0:5</td>
<td class=kL>0:3 K</td>
<td class=kL>1:2 K</td>
<td class=kW>2:0 K</td>
<td class=kL>1:4</td>
<td class=kW>5:4</td>
<td class=kT>1:1</td>
<td class=kT>3:3 K</td>
<td class=kL>3:5</td>
<td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kL>4:8</td>
<td class=kL>2:5 K</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>2:1 K</td>
<td class=kW>1:0</td>
<td class=br>61:104</td><td class=br>-43</td>
<td class=bc>6 - 4 - 19</td>
<td class=br><strong>16</strong></td><td class=d>27.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>28.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1622&x=-390&p=He%20Petuch">He Petuch</a></td><td class=kT>2:2 K</td>
<td class=kL>2:7</td>
<td class=kT>1:1</td>
<td class=kL>0:3 K</td>
<td class=kL>0:5</td>
<td class=kL>0:7</td>
<td class=kL>3:4</td>
<td class=kL>2:7</td>
<td class=kL>0:6</td>
<td class=kL>1:4 K</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kW>1:0</td>
<td class=kL>2:4</td>
<td class=kL>2:3 K</td>
<td class=kW>2:1 K</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>2:0 K</td>
<td class=kT>4:4 K</td>
<td class=kL>3:5</td>
<td class=kW>2:0</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kL>3:4 K</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>1:2 K</td>
<td class=br>53:96</td><td class=br>-43</td>
<td class=bc>6 - 4 - 19</td>
<td class=br><strong>16</strong></td><td class=d>28.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>29.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1981&x=-390&p=Po%20Kvasnikova">Po Kvasnikova</a></td><td class=kL>1:8</td>
<td class=kL>1:5 K</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>2:4 K</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kT>4:4 K</td>
<td class=kL>1:2</td>
<td class=kT>1:1 K</td>
<td class=kT>4:4 K</td>
<td class=kL>2:5 K</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>2:5 K</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>2:0 K</td>
<td class=kL>0:4</td>
<td class=kW>3:0</td>
<td class=kL>1:2 K</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=br>44:100</td><td class=br>-56</td>
<td class=bc>4 - 4 - 21</td>
<td class=br><strong>12</strong></td><td class=d>29.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>30.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=32&x=-390&p=Ji%20Krop%C3%A1%C4%8Dek">Ji Kropáček</a></td><td class=kL>2:7 K</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>1:4 K</td>
<td class=kL>0:7</td>
<td class=kL>0:3</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>2:7 K</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kW>4:3</td>
<td class=kL>2:6 K</td>
<td class=kL>2:4 K</td>
<td class=kT>5:5</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kL>1:6 K</td>
<td class=kL>4:5 K</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>1:0 K</td>
<td class=kL>0:1</td>
<td class=kW>2:1 K</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=br>46:130</td><td class=br>-84</td>
<td class=bc>3 - 3 - 23</td>
<td class=br><strong>9</strong></td><td class=d>30.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ja Zalite</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Hu Lönnqvist</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>An Kuznecovs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Em Liepins</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ra Kalninš</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Ma Dion</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ja Zalite</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>An Kuznecovs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Em Liepins</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Hu Lönnqvist</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Da Hrustaljova</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ji Kropáček</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ja Zalite</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mi Margolis</td><td class=bc>-</td><td class=bl>Em Liepins</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Hu Lönnqvist</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>An Kuznecovs</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ja Zalite</td><td class=bc>-</td><td class=blW>Ma Dion</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Em Liepins</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Hu Lönnqvist</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>An Kuznecovs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Da Hrustaljova</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ja Zalite</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ji Kropáček</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Hu Lönnqvist</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>An Kuznecovs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Em Liepins</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ja Zalite</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Hu Lönnqvist</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>An Kuznecovs</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Em Liepins</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Da Hrustaljova</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ja Zalite</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Hu Lönnqvist</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>An Kuznecovs</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Ja Zalite</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Mi Margolis</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Da Cibulka</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Em Liepins</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Mi Kubica</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Hu Lönnqvist</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Kuznecovs</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Hrustaljova</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Po Kvasnikova</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Ja Zalite</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>An Božič</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Hu Lönnqvist</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>An Kuznecovs</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Da Cibulka</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Po Kvasnikova</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Ja Zalite</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>An Kuznecovs</td><td class=bc>-</td><td class=blW>An Božič</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Hu Lönnqvist</td><td class=bc>-</td><td class=bl>Mi Kubica</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>8 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ra Kalninš</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Hu Lönnqvist</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>An Kuznecovs</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ja Zalite</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Hrustaljova</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Hu Lönnqvist</td><td class=bc>-</td><td class=blW>Ja Zalite</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>An Kuznecovs</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=blW>Ma Dion</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Da Hrustaljova</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Em Liepins</td><td class=bc>-</td><td class=bl>Ja Zalite</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Hu Lönnqvist</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>An Kuznecovs</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ma Dion</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Gu Hermansson</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Mi Margolis</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Hu Lönnqvist</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>An Kuznecovs</td><td class=bc>-</td><td class=bl>Ja Zalite</td><td class=bc>6 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Dion</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Gu Hermansson</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Da Hrustaljova</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>An Kuznecovs</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Ja Zalite</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Hu Lönnqvist</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Hu Lönnqvist</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>An Kuznecovs</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Em Liepins</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Da Hrustaljova</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ja Zalite</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>An Božič</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Dion</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>8 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Hu Lönnqvist</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>An Kuznecovs</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Da Hrustaljova</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Ra Kalninš</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Ja Zalite</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Dion</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Gu Hermansson</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Hu Lönnqvist</td><td class=bc>-</td><td class=bl>Da Hrustaljova</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>An Kuznecovs</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Ja Zalite</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Dion</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Em Liepins</td><td class=bc>-</td><td class=blW>Da Hrustaljova</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Hu Lönnqvist</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>An Kuznecovs</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Mi Kubica</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ja Zalite</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Dion</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Da Cibulka</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>An Kuznecovs</td><td class=bc>-</td><td class=blW>Da Hrustaljova</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Em Liepins</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Gu Hermansson</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Hu Lönnqvist</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mi Kubica</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>An Božič</td><td class=bc>-</td><td class=bl>Ja Zalite</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ji Kropáček</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ma Dion</td><td class=bc>-</td><td class=blW>Da Cibulka</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Po Kvasnikova</td><td class=bc>4 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group A2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>25</td>
<td class=ic>26</td>
<td class=ic>27</td>
<td class=ic>28</td>
<td class=ic>29</td>
<td class=ic>30</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1174&x=-390&p=Ma%20Mad%C4%9Bra">Ma Maděra</a></td><td class=kx>*</td>
<td class=kW>7:3 K</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0 K</td>
<td class=kW>6:4</td>
<td class=kW>2:0</td>
<td class=kL>2:4 K</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kW>2:1 K</td>
<td class=kW>6:2 K</td>
<td class=kW>3:1 K</td>
<td class=kW>7:1</td>
<td class=kW>4:0 K</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=kW>5:2 K</td>
<td class=kW>4:1</td>
<td class=kW>9:3 K</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=br>119:53</td><td class=br>+66</td>
<td class=bc>24 - 2 - 3</td>
<td class=br><strong>50</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1477&x=-390&p=Mi%20Kobrle">Mi Kobrle</a></td><td class=kL>3:7 K</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3 K</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kW>3:2 K</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kT>5:5</td>
<td class=kW>3:1</td>
<td class=kW>8:2</td>
<td class=kW>5:1 K</td>
<td class=kW>4:3 K</td>
<td class=kW>6:1 K</td>
<td class=kW>4:3</td>
<td class=kW>4:0 K</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>4:1 K</td>
<td class=kW>6:3</td>
<td class=kW>7:2 K</td>
<td class=kW>8:2</td>
<td class=kW>6:1</td>
<td class=br>123:63</td><td class=br>+60</td>
<td class=bc>23 - 1 - 5</td>
<td class=br><strong>47</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1649&x=-390&p=Ra%20Miglinieks">Ra Miglinieks</a></td><td class=kT>4:4</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>4:1 K</td>
<td class=kW>3:0</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>6:2 K</td>
<td class=kW>3:2 K</td>
<td class=kW>3:0 K</td>
<td class=kW>6:1 K</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kL>3:5</td>
<td class=kT>3:3 K</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>6:3 K</td>
<td class=kW>3:1 K</td>
<td class=kW>6:0</td>
<td class=kW>7:1 K</td>
<td class=kW>2:1</td>
<td class=kW>8:0</td>
<td class=kW>8:0</td>
<td class=br>117:55</td><td class=br>+62</td>
<td class=bc>20 - 5 - 4</td>
<td class=br><strong>45</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1616&x=-390&p=Em%20Larsson">Em Larsson</a></td><td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:3 K</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>5:6 K</td>
<td class=kW>3:2 K</td>
<td class=kW>4:2</td>
<td class=kW>6:0 K</td>
<td class=kW>6:0 K</td>
<td class=kL>1:3 K</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>3:0 K</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>6:2 K</td>
<td class=kW>6:0 K</td>
<td class=br>110:58</td><td class=br>+52</td>
<td class=bc>20 - 4 - 5</td>
<td class=br><strong>44</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1772&x=-390&p=El%20Silin%C5%A1">El Silinš</a></td><td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>3:4 K</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1 K</td>
<td class=kW>4:1 K</td>
<td class=kL>2:3</td>
<td class=kW>4:3 K</td>
<td class=kT>4:4 K</td>
<td class=kL>1:2 K</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kW>7:3</td>
<td class=kW>6:3</td>
<td class=kW>6:2 K</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>4:2 K</td>
<td class=kW>3:2 K</td>
<td class=br>107:55</td><td class=br>+52</td>
<td class=bc>20 - 2 - 7</td>
<td class=br><strong>42</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=567&x=-390&p=Kr%20Lebl">Kr Lebl</a></td><td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:4 K</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>7:1 K</td>
<td class=kL>1:3 K</td>
<td class=kW>3:1 K</td>
<td class=kW>6:1 K</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>7:1 K</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>2:3 K</td>
<td class=kW>6:1 K</td>
<td class=kW>6:0</td>
<td class=kW>3:0 K</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=br>105:56</td><td class=br>+49</td>
<td class=bc>18 - 3 - 8</td>
<td class=br><strong>39</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=386&x=-390&p=Ku%20Sl%C3%A1dek">Ku Sládek</a></td><td class=kL>0:4 K</td>
<td class=kW>3:2 K</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kL>0:3 K</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kW>4:3</td>
<td class=kL>2:3 K</td>
<td class=kT>2:2 K</td>
<td class=kW>4:2 K</td>
<td class=kW>4:1</td>
<td class=kW>5:2 K</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>4:2 K</td>
<td class=kW>6:2</td>
<td class=kW>6:3 K</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=br>78:60</td><td class=br>+18</td>
<td class=bc>16 - 7 - 6</td>
<td class=br><strong>39</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1977&x=-390&p=Ti%20Dion">Ti Dion</a></td><td class=kL>4:6</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kW>6:5 K</td>
<td class=kL>1:3 K</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3 K</td>
<td class=kW>4:1</td>
<td class=kW>4:2 K</td>
<td class=kL>0:3 K</td>
<td class=kW>3:1 K</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kW>5:4</td>
<td class=kW>5:4</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>8:3 K</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:3 K</td>
<td class=kW>5:4 K</td>
<td class=br>102:80</td><td class=br>+22</td>
<td class=bc>17 - 4 - 8</td>
<td class=br><strong>38</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2003&x=-390&p=An%20Kimberg">An Kimberg</a></td><td class=kL>0:2</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kL>2:3 K</td>
<td class=kL>1:4 K</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kT>3:3 K</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>2:3 K</td>
<td class=kL>2:3 K</td>
<td class=kW>3:1 K</td>
<td class=kL>0:3</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>4:1 K</td>
<td class=kW>3:0 K</td>
<td class=br>80:61</td><td class=br>+19</td>
<td class=bc>16 - 5 - 8</td>
<td class=br><strong>37</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=310&x=-390&p=Mi%20%C4%8Cernoch">Mi Černoch</a></td><td class=kW>4:2 K</td>
<td class=kL>2:3 K</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kW>3:0 K</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kL>0:1</td>
<td class=kL>0:1</td>
<td class=kW>4:2 K</td>
<td class=kT>0:0 K</td>
<td class=kW>4:1 K</td>
<td class=kW>3:0</td>
<td class=kW>2:1 K</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2 K</td>
<td class=kW>4:1</td>
<td class=kW>4:1 K</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=br>70:54</td><td class=br>+16</td>
<td class=bc>17 - 1 - 11</td>
<td class=br><strong>35</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1065&x=-390&p=Kr%20Herold">Kr Herold</a></td><td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>0:6 K</td>
<td class=kL>3:4 K</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4 K</td>
<td class=kW>3:2 K</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>0:3 K</td>
<td class=kW>4:2 K</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>6:1</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kT>3:3 K</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>3:1 K</td>
<td class=kW>3:0 K</td>
<td class=br>81:68</td><td class=br>+13</td>
<td class=bc>16 - 2 - 11</td>
<td class=br><strong>34</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1579&x=-390&p=Vi%20Henttonen">Vi Henttonen</a></td><td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>0:6 K</td>
<td class=kT>4:4 K</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>3:0 K</td>
<td class=kW>3:2 K</td>
<td class=kW>3:1</td>
<td class=kW>3:0 K</td>
<td class=kx>*</td>
<td class=kL>1:4 K</td>
<td class=kL>2:4</td>
<td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>5:4</td>
<td class=kW>3:2 K</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>1:2 K</td>
<td class=kW>5:2 K</td>
<td class=br>67:69</td><td class=br>-2</td>
<td class=bc>13 - 6 - 10</td>
<td class=br><strong>32</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=53&x=-390&p=V%C3%A1%20Pikl">Vá Pikl</a></td><td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kW>3:1 K</td>
<td class=kW>2:1 K</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>1:3 K</td>
<td class=kL>1:3 K</td>
<td class=kL>1:3</td>
<td class=kL>2:4 K</td>
<td class=kW>4:1 K</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kL>0:1 K</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>7:2</td>
<td class=kW>6:3 K</td>
<td class=kW>6:0 K</td>
<td class=br>76:65</td><td class=br>+11</td>
<td class=bc>14 - 3 - 12</td>
<td class=br><strong>31</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=961&x=-390&p=Mi%20Bo%C5%A1t%C3%ADk">Mi Boštík</a></td><td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>2:6 K</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:7 K</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1 K</td>
<td class=kL>2:3 K</td>
<td class=kW>4:3 K</td>
<td class=kW>6:0</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>3:5 K</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kL>1:2 K</td>
<td class=kL>3:4 K</td>
<td class=kW>3:1</td>
<td class=kW>5:0 K</td>
<td class=kW>7:1</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=br>91:72</td><td class=br>+19</td>
<td class=bc>15 - 1 - 13</td>
<td class=br><strong>31</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=448&x=-390&p=To%20Waclawek">To Waclawek</a></td><td class=kL>3:4</td>
<td class=kT>5:5</td>
<td class=kL>2:3 K</td>
<td class=kT>4:4</td>
<td class=kL>1:5</td>
<td class=kW>3:1 K</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3 K</td>
<td class=kx>*</td>
<td class=kW>4:1 K</td>
<td class=kT>3:3 K</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kT>4:4 K</td>
<td class=kW>6:1</td>
<td class=kL>2:4</td>
<td class=kL>1:2 K</td>
<td class=kL>2:4 K</td>
<td class=kW>5:0</td>
<td class=kW>5:3 K</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=br>92:80</td><td class=br>+12</td>
<td class=bc>11 - 7 - 11</td>
<td class=br><strong>29</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1828&x=-390&p=Tr%20Mansson">Tr Mansson</a></td><td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>0:3 K</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kL>1:3 K</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>3:2 K</td>
<td class=kL>1:4 K</td>
<td class=kx>*</td>
<td class=kL>1:4 K</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1 K</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>2:3 K</td>
<td class=kW>3:0 K</td>
<td class=kL>3:4</td>
<td class=kL>2:3 K</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=br>64:60</td><td class=br>+4</td>
<td class=bc>12 - 5 - 12</td>
<td class=br><strong>29</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=344&x=-390&p=Ge%20Regula">Ge Regula</a></td><td class=kL>2:5</td>
<td class=kL>2:8</td>
<td class=kL>1:6 K</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kL>1:6 K</td>
<td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>3:4 K</td>
<td class=kT>3:3 K</td>
<td class=kW>4:1 K</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kW>4:0 K</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>3:0 K</td>
<td class=kT>2:2 K</td>
<td class=kW>5:1</td>
<td class=kW>5:2 K</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=br>75:84</td><td class=br>-9</td>
<td class=bc>11 - 5 - 13</td>
<td class=br><strong>27</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=893&x=-390&p=Ne%20%C5%A0krlep">Ne Škrlep</a></td><td class=kL>1:2 K</td>
<td class=kL>1:5 K</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kW>3:2 K</td>
<td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kL>2:4 K</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kL>0:2</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>3:2 K</td>
<td class=kL>1:6 K</td>
<td class=kW>3:0</td>
<td class=kW>3:1 K</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kL>1:2 K</td>
<td class=kW>4:0</td>
<td class=kW>2:0 K</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=br>63:74</td><td class=br>-11</td>
<td class=bc>12 - 2 - 15</td>
<td class=br><strong>26</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1872&x=-390&p=Pe%20Fuchs">Pe Fuchs</a></td><td class=kL>2:6 K</td>
<td class=kL>3:4 K</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kT>0:0 K</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>2:3 K</td>
<td class=kx>*</td>
<td class=kW>6:3 K</td>
<td class=kW>5:3</td>
<td class=kT>3:3 K</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kW>1:0 K</td>
<td class=kW>6:1</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=br>68:81</td><td class=br>-13</td>
<td class=bc>7 - 11 - 11</td>
<td class=br><strong>25</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1912&x=-390&p=Al%20Krejza">Al Krejza</a></td><td class=kL>1:3 K</td>
<td class=kL>1:6 K</td>
<td class=kW>5:3</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kL>2:4 K</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>1:4 K</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kW>6:1 K</td>
<td class=kL>3:6 K</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>2:4 K</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3 K</td>
<td class=kW>3:2</td>
<td class=kW>2:1 K</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=br>70:84</td><td class=br>-14</td>
<td class=bc>11 - 3 - 15</td>
<td class=br><strong>25</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2006&x=-390&p=G%C3%B6%20L%C3%B6nnqvist">Gö Lönnqvist</a></td><td class=kL>1:7</td>
<td class=kL>3:4</td>
<td class=kT>3:3 K</td>
<td class=kL>3:5</td>
<td class=kL>3:7</td>
<td class=kL>1:7 K</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>5:3 K</td>
<td class=kT>4:4 K</td>
<td class=kT>1:1 K</td>
<td class=kL>0:4 K</td>
<td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>5:4 K</td>
<td class=kL>2:4 K</td>
<td class=kW>3:1</td>
<td class=kL>1:2 K</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=br>73:91</td><td class=br>-18</td>
<td class=bc>10 - 5 - 14</td>
<td class=br><strong>25</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=201&x=-390&p=To%20Bucek">To Bucek</a></td><td class=kL>0:4 K</td>
<td class=kL>0:4 K</td>
<td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kL>2:5 K</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2 K</td>
<td class=kL>0:4</td>
<td class=kL>4:5</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kL>1:3 K</td>
<td class=kT>3:3 K</td>
<td class=kW>4:2 K</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kT>1:1</td>
<td class=kW>6:0 K</td>
<td class=kW>3:2</td>
<td class=kW>2:1 K</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=br>76:90</td><td class=br>-14</td>
<td class=bc>9 - 6 - 14</td>
<td class=br><strong>24</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1117&x=-390&p=To%20Kahoun%20ml.">To Kahoun ml.</a></td><td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>0:3 K</td>
<td class=kL>2:6 K</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>3:8 K</td>
<td class=kT>2:2 K</td>
<td class=kL>0:3</td>
<td class=kT>3:3 K</td>
<td class=kL>2:3 K</td>
<td class=kW>1:0 K</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kW>2:1 K</td>
<td class=kW>9:0 K</td>
<td class=br>60:76</td><td class=br>-16</td>
<td class=bc>9 - 6 - 14</td>
<td class=br><strong>24</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=347&x=-390&p=Ma%20Papp">Ma Papp</a></td><td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>3:6 K</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kW>3:2 K</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1 K</td>
<td class=kW>2:1 K</td>
<td class=kW>3:2 K</td>
<td class=kL>0:3 K</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kL>4:5 K</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1 K</td>
<td class=kW>4:2</td>
<td class=kW>3:2 K</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=br>67:87</td><td class=br>-20</td>
<td class=bc>11 - 2 - 16</td>
<td class=br><strong>24</strong></td><td class=d>24.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>25.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1978&x=-390&p=My%20Verbytskyy">My Verbytskyy</a></td><td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>1:3 K</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>1:6 K</td>
<td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>4:3 K</td>
<td class=kW>4:2 K</td>
<td class=kL>0:3 K</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>4:2 K</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>1:2 K</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>4:1 K</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=br>49:80</td><td class=br>-31</td>
<td class=bc>8 - 5 - 16</td>
<td class=br><strong>21</strong></td><td class=d>25.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>26.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=346&x=-390&p=B%C3%A1%20Nagy">Bá Nagy</a></td><td class=kL>2:5 K</td>
<td class=kL>1:4 K</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>2:4 K</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3 K</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kW>4:3</td>
<td class=kL>1:5</td>
<td class=kW>2:1 K</td>
<td class=kL>0:1 K</td>
<td class=kW>3:2 K</td>
<td class=kL>1:3</td>
<td class=kL>0:6 K</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>2:2 K</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=br>42:94</td><td class=br>-52</td>
<td class=bc>7 - 1 - 21</td>
<td class=br><strong>15</strong></td><td class=d>26.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>27.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=18&x=-390&p=An%20%C5%A0ur%C3%BDn">An Šurýn</a></td><td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kL>1:7 K</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>0:3 K</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>0:5 K</td>
<td class=kL>3:5 K</td>
<td class=kW>3:2 K</td>
<td class=kL>2:5 K</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kW>2:1 K</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>2:3 K</td>
<td class=kL>1:4 K</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kW>4:0</td>
<td class=br>50:100</td><td class=br>-50</td>
<td class=bc>7 - 0 - 22</td>
<td class=br><strong>14</strong></td><td class=d>27.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>28.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=70&x=-390&p=St%20Srba">St Srba</a></td><td class=kL>3:9 K</td>
<td class=kL>2:7 K</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>3:6 K</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4 K</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>2:7</td>
<td class=kL>1:7</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>0:2 K</td>
<td class=kT>2:2 K</td>
<td class=kL>1:2 K</td>
<td class=kL>1:2</td>
<td class=kL>1:2 K</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kT>2:2 K</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>45:98</td><td class=br>-53</td>
<td class=bc>2 - 6 - 21</td>
<td class=br><strong>10</strong></td><td class=d>28.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>29.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2000&x=-390&p=Da%20Hasler">Da Hasler</a></td><td class=kL>0:6</td>
<td class=kL>2:8</td>
<td class=kL>0:8</td>
<td class=kL>2:6 K</td>
<td class=kL>2:4 K</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>3:4 K</td>
<td class=kL>1:4 K</td>
<td class=kL>2:6</td>
<td class=kL>1:3 K</td>
<td class=kW>2:1 K</td>
<td class=kL>3:6 K</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>1:2 K</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=br>51:115</td><td class=br>-64</td>
<td class=bc>2 - 3 - 24</td>
<td class=br><strong>7</strong></td><td class=d>29.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>30.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1409&x=-390&p=Ji%20Mal%C3%ADk">Ji Malík</a></td><td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>0:8</td>
<td class=kL>0:6 K</td>
<td class=kL>2:3 K</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>4:5 K</td>
<td class=kL>0:3 K</td>
<td class=kL>2:4</td>
<td class=kL>0:3 K</td>
<td class=kL>2:5 K</td>
<td class=kL>0:6 K</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>0:9 K</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=br>29:137</td><td class=br>-108</td>
<td class=bc>0 - 1 - 28</td>
<td class=br><strong>1</strong></td><td class=d>30.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Gö Lönnqvist</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Kimberg</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Da Hasler</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Gö Lönnqvist</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>An Kimberg</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Hasler</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=blW>Bá Nagy</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Gö Lönnqvist</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Hasler</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>An Kimberg</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Gö Lönnqvist</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Hasler</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>An Kimberg</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Gö Lönnqvist</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Da Hasler</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>An Kimberg</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>An Kimberg</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Gö Lönnqvist</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Hasler</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Gö Lönnqvist</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>An Kimberg</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Hasler</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Da Hasler</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>An Kimberg</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Gö Lönnqvist</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Da Hasler</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>An Kimberg</td><td class=bc>-</td><td class=bl>Gö Lönnqvist</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Da Hasler</td><td class=bc>-</td><td class=blW>Gö Lönnqvist</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>An Kimberg</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>An Kimberg</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Da Hasler</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Gö Lönnqvist</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Da Hasler</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>An Kimberg</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Gö Lönnqvist</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>Da Hasler</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>An Kimberg</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Gö Lönnqvist</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Da Hasler</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>An Kimberg</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Gö Lönnqvist</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Bá Nagy</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>An Kimberg</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Da Hasler</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Gö Lönnqvist</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Em Larsson</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Gö Lönnqvist</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>An Kimberg</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Bá Nagy</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Da Hasler</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Gö Lönnqvist</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Da Hasler</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Bá Nagy</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>An Kimberg</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Gö Lönnqvist</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Da Hasler</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>An Kimberg</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Bá Nagy</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Gö Lönnqvist</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Bá Nagy</td><td class=bc>-</td><td class=bl>Da Hasler</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>An Kimberg</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ge Regula</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Gö Lönnqvist</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Em Larsson</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Bá Nagy</td><td class=bc>-</td><td class=blW>An Kimberg</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>Da Hasler</td><td class=bc>2 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=176&x=-390&p=Zd%20Lopaur">Zd Lopaur</a></td><td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=kW>7:3</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>8:3</td>
<td class=kW>9:2</td>
<td class=br>84:30</td><td class=br>+54</td>
<td class=bc>13 - 2 - 2</td>
<td class=br><strong>28</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1917&x=-390&p=Fr%20Rasche">Fr Rasche</a></td><td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kT>5:5</td>
<td class=kW>8:2</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kW>5:4</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kT>4:4</td>
<td class=br>68:40</td><td class=br>+28</td>
<td class=bc>12 - 4 - 1</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=4&x=-390&p=Vl%20Kraus">Vl Kraus</a></td><td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kT>5:5</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>0:0</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=br>62:32</td><td class=br>+30</td>
<td class=bc>12 - 3 - 2</td>
<td class=br><strong>27</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=227&x=-390&p=Mi%20Ma%C5%A1ika">Mi Mašika</a></td><td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>6:4</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>8:1</td>
<td class=br>59:38</td><td class=br>+21</td>
<td class=bc>10 - 5 - 2</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1940&x=-390&p=Ma%20Ko%C5%A1%C5%88ar">Ma Košňar</a></td><td class=kT>2:2</td>
<td class=kT>5:5</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>7:0</td>
<td class=br>53:36</td><td class=br>+17</td>
<td class=bc>11 - 3 - 3</td>
<td class=br><strong>25</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1318&x=-390&p=Jo%20Sedl%C3%A1%C4%8Dek">Jo Sedláček</a></td><td class=kL>2:4</td>
<td class=kL>2:8</td>
<td class=kT>5:5</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kT>5:5</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=br>58:50</td><td class=br>+8</td>
<td class=bc>9 - 4 - 4</td>
<td class=br><strong>22</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=818&x=-390&p=Ro%20Je%C5%BE">Ro Jež</a></td><td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=br>57:35</td><td class=br>+22</td>
<td class=bc>10 - 2 - 5</td>
<td class=br><strong>22</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1973&x=-390&p=Br%20Sabo">Br Sabo</a></td><td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=br>39:42</td><td class=br>-3</td>
<td class=bc>8 - 1 - 8</td>
<td class=br><strong>17</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1630&x=-390&p=Pe%20Holub">Pe Holub</a></td><td class=kL>1:6</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kL>4:6</td>
<td class=kL>3:6</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>7:2</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kT>0:0</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=br>45:48</td><td class=br>-3</td>
<td class=bc>7 - 2 - 8</td>
<td class=br><strong>16</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=204&x=-390&p=Hy%20Nechutn%C3%BD">Hy Nechutný</a></td><td class=kL>0:6</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=br>30:35</td><td class=br>-5</td>
<td class=bc>5 - 6 - 6</td>
<td class=br><strong>16</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1587&x=-390&p=Ad%20Herold">Ad Herold</a></td><td class=kL>0:6</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>1:8</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=br>34:42</td><td class=br>-8</td>
<td class=bc>7 - 1 - 9</td>
<td class=br><strong>15</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1058&x=-390&p=Fr%20Marek">Fr Marek</a></td><td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kT>0:0</td>
<td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kL>4:5</td>
<td class=kL>0:5</td>
<td class=kW>4:3</td>
<td class=kL>2:7</td>
<td class=kT>2:2</td>
<td class=kW>8:1</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=br>43:54</td><td class=br>-11</td>
<td class=bc>6 - 2 - 9</td>
<td class=br><strong>14</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1957&x=-390&p=Er%20Bernhauser">Er Bernhauser</a></td><td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kT>5:5</td>
<td class=kL>3:6</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=br>46:66</td><td class=br>-20</td>
<td class=bc>4 - 4 - 9</td>
<td class=br><strong>12</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2014&x=-390&p=Ma%20Hlava%C4%8Dka">Ma Hlavačka</a></td><td class=kL>3:7</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=br>38:51</td><td class=br>-13</td>
<td class=bc>4 - 3 - 10</td>
<td class=br><strong>11</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1927&x=-390&p=Vo%20Kraus">Vo Kraus</a></td><td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=br>33:54</td><td class=br>-21</td>
<td class=bc>3 - 4 - 10</td>
<td class=br><strong>10</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2017&x=-390&p=Ka%20Pirumshoeva">Ka Pirumshoeva</a></td><td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kT>0:0</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=br>22:41</td><td class=br>-19</td>
<td class=bc>3 - 1 - 13</td>
<td class=br><strong>7</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2005&x=-390&p=Do%20Zupan%C4%8Di%C4%8D">Do Zupančič</a></td><td class=kL>3:8</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=br>31:53</td><td class=br>-22</td>
<td class=bc>3 - 1 - 13</td>
<td class=br><strong>7</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1430&x=-390&p=Da%20Kadlec">Da Kadlec</a></td><td class=kL>2:9</td>
<td class=kT>4:4</td>
<td class=kL>1:5</td>
<td class=kL>1:8</td>
<td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=br>22:77</td><td class=br>-55</td>
<td class=bc>1 - 2 - 14</td>
<td class=br><strong>4</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Do Zupančič</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Br Sabo</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Mi Mašika</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Ad Herold</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Do Zupančič</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Vo Kraus</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Br Sabo</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Ad Herold</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Fr Rasche</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Do Zupančič</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Ad Herold</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Fr Rasche</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Do Zupančič</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Ad Herold</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Fr Rasche</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Mašika</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>6 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Br Sabo</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Do Zupančič</td><td class=bc>-</td><td class=blW>Ma Hlavačka</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ad Herold</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Fr Rasche</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Er Bernhauser</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ro Jež</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Br Sabo</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Ad Herold</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Do Zupančič</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>Fr Rasche</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=bl>Mi Mašika</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Ad Herold</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Do Zupančič</td><td class=bc>-</td><td class=blW>Fr Rasche</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Ka Pirumshoeva</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ad Herold</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>Fr Rasche</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Do Zupančič</td><td class=bc>-</td><td class=blW>Pe Holub</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Jo Sedláček</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ad Herold</td><td class=bc>-</td><td class=blW>Fr Rasche</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Br Sabo</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Do Zupančič</td><td class=bc>-</td><td class=blW>Ka Pirumshoeva</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Zd Lopaur</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Jo Sedláček</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ad Herold</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Hlavačka</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Br Sabo</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Do Zupančič</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Zd Lopaur</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Fr Rasche</td><td class=bc>-</td><td class=bl>Pe Holub</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ad Herold</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Er Bernhauser</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>Vo Kraus</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Do Zupančič</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Mi Mašika</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Fr Rasche</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ad Herold</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Do Zupančič</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=bl>Ka Pirumshoeva</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ro Jež</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Fr Rasche</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ad Herold</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Br Sabo</td><td class=bc>-</td><td class=bl>Do Zupančič</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Kadlec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=bl>Ro Jež</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Er Bernhauser</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Vo Kraus</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Fr Rasche</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ad Herold</td><td class=bc>-</td><td class=bl>Do Zupančič</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Hlavačka</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Br Sabo</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Er Bernhauser</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pe Holub</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Do Zupančič</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ad Herold</td><td class=bc>-</td><td class=blW>Br Sabo</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Hlavačka</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Vo Kraus</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Jo Sedláček</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Do Zupančič</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ad Herold</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Er Bernhauser</td><td class=bc>-</td><td class=bl>Jo Sedláček</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Zd Lopaur</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ka Pirumshoeva</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mi Mašika</td><td class=bc>-</td><td class=bl>Do Zupančič</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Da Kadlec</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Fr Rasche</td><td class=bc>-</td><td class=bl>Ma Hlavačka</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ad Herold</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Zd Lopaur</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Er Bernhauser</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ro Jež</td><td class=bc>-</td><td class=bl>Do Zupančič</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ka Pirumshoeva</td><td class=bc>-</td><td class=bl>Da Kadlec</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Mašika</td><td class=bc>-</td><td class=bl>Br Sabo</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pe Holub</td><td class=bc>-</td><td class=blW>Ma Hlavačka</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Ad Herold</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Fr Rasche</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=910&x=-390&p=Vl%20Gobyov%C3%A1">Vl Gobyová</a></td><td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=br>50:12</td><td class=br>+38</td>
<td class=bc>12 - 1 - 0</td>
<td class=br><strong>25</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1896&x=-390&p=Ra%20Hrn%C4%8D%C3%AD%C5%99">Ra Hrnčíř</a></td><td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kT>0:0</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>36:14</td><td class=br>+22</td>
<td class=bc>9 - 2 - 2</td>
<td class=br><strong>20</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2020&x=-390&p=Da%20Jerabek">Da Jerabek</a></td><td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>40:12</td><td class=br>+28</td>
<td class=bc>10 - 0 - 3</td>
<td class=br><strong>20</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1941&x=-390&p=Ja%20Kopeck%C3%BD">Ja Kopecký</a></td><td class=kL>0:4</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=br>32:19</td><td class=br>+13</td>
<td class=bc>7 - 3 - 3</td>
<td class=br><strong>17</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1959&x=-390&p=On%20Chlebo">On Chlebo</a></td><td class=kL>2:5</td>
<td class=kT>0:0</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=br>31:23</td><td class=br>+8</td>
<td class=bc>7 - 2 - 4</td>
<td class=br><strong>16</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2025&x=-390&p=Vo%20Gorej">Vo Gorej</a></td><td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>0:2</td>
<td class=kW>6:1</td>
<td class=kW>8:0</td>
<td class=kW>8:0</td>
<td class=br>37:20</td><td class=br>+17</td>
<td class=bc>6 - 4 - 3</td>
<td class=br><strong>16</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2018&x=-390&p=Ja%20Janou%C5%A1kovec">Ja Janouškovec</a></td><td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>7:0</td>
<td class=br>34:30</td><td class=br>+4</td>
<td class=bc>6 - 2 - 5</td>
<td class=br><strong>14</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1626&x=-390&p=Mi%20Hor%C3%A1kov%C3%A1">Mi Horáková</a></td><td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>6:0</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=br>41:35</td><td class=br>+6</td>
<td class=bc>7 - 0 - 6</td>
<td class=br><strong>14</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1869&x=-390&p=Pe%20Klazar">Pe Klazar</a></td><td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kW>5:0</td>
<td class=kW>4:3</td>
<td class=br>28:35</td><td class=br>-7</td>
<td class=bc>4 - 2 - 7</td>
<td class=br><strong>10</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1999&x=-390&p=Fi%20Pano%C5%A1">Fi Panoš</a></td><td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kT>0:0</td>
<td class=kW>1:0</td>
<td class=br>8:24</td><td class=br>-16</td>
<td class=bc>2 - 4 - 7</td>
<td class=br><strong>8</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2004&x=-390&p=Ur%20Me%C5%BEek">Ur Mežek</a></td><td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>4:8</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=br>25:46</td><td class=br>-21</td>
<td class=bc>3 - 2 - 8</td>
<td class=br><strong>8</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2019&x=-390&p=Pa%20Janou%C5%A1kovec">Pa Janouškovec</a></td><td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kW>8:4</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>4:0</td>
<td class=br>23:40</td><td class=br>-17</td>
<td class=bc>3 - 1 - 9</td>
<td class=br><strong>7</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2021&x=-390&p=Kr%20Novotn%C3%BD">Kr Novotný</a></td><td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>0:8</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=br>11:45</td><td class=br>-34</td>
<td class=bc>1 - 3 - 9</td>
<td class=br><strong>5</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2023&x=-390&p=Al%20Vinnichuk">Al Vinnichuk</a></td><td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:8</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=br>8:49</td><td class=br>-41</td>
<td class=bc>1 - 0 - 12</td>
<td class=br><strong>2</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Al Vinnichuk</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ur Mežek</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Pa Janouškovec</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=blW>On Chlebo</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Al Vinnichuk</td><td class=bc>-</td><td class=blW>Vo Gorej</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ur Mežek</td><td class=bc>-</td><td class=blW>Ja Janouškovec</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Da Jerabek</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ja Kopecký</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Fi Panoš</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Vo Gorej</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Al Vinnichuk</td><td class=bc>-</td><td class=blW>Ja Janouškovec</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ur Mežek</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>On Chlebo</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Kopecký</td><td class=bc>-</td><td class=bl>Fi Panoš</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=blW>Ja Janouškovec</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Vo Gorej</td><td class=bc>-</td><td class=bl>Da Jerabek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Al Vinnichuk</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>On Chlebo</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ur Mežek</td><td class=bc>-</td><td class=bl>Fi Panoš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ja Kopecký</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Da Jerabek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=blW>Kr Novotný</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>On Chlebo</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Vinnichuk</td><td class=bc>-</td><td class=blW>Fi Panoš</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ur Mežek</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ja Kopecký</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Da Jerabek</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>On Chlebo</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=blW>Fi Panoš</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Al Vinnichuk</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ur Mežek</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Kr Novotný</td><td class=bc>-</td><td class=blW>On Chlebo</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Da Jerabek</td><td class=bc>-</td><td class=bl>Fi Panoš</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ja Janouškovec</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al Vinnichuk</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kr Novotný</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Jerabek</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ja Janouškovec</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pa Janouškovec</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al Vinnichuk</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>On Chlebo</td><td class=bc>-</td><td class=bl>Ja Kopecký</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr Novotný</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Da Jerabek</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Pa Janouškovec</td><td class=bc>-</td><td class=bl>Al Vinnichuk</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vo Gorej</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ja Kopecký</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Ur Mežek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kr Novotný</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Da Jerabek</td><td class=bc>-</td><td class=bl>Al Vinnichuk</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Vo Gorej</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Pa Janouškovec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>On Chlebo</td><td class=bc>-</td><td class=bl>Al Vinnichuk</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kr Novotný</td><td class=bc>-</td><td class=blW>Vo Gorej</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Da Jerabek</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ja Kopecký</td><td class=bc>-</td><td class=bl>Ur Mežek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Al Vinnichuk</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=blW>Vo Gorej</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Novotný</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Jerabek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ja Kopecký</td><td class=bc>-</td><td class=bl>Al Vinnichuk</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mi Horáková</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=blW>Ja Janouškovec</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=blW>Da Jerabek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr Novotný</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ur Mežek</td><td class=bc>-</td><td class=bl>Al Vinnichuk</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=bl>Vo Gorej</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ja Kopecký</td><td class=bc>-</td><td class=bl>Pa Janouškovec</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Ja Janouškovec</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Da Jerabek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Fi Panoš</td><td class=bc>-</td><td class=bl>Kr Novotný</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>On Chlebo</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
