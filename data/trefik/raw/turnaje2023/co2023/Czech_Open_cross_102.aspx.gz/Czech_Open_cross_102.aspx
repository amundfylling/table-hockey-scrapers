<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Czech Open</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../co2023">Czech Open</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group A2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>25</td>
<td class=ic>26</td>
<td class=ic>27</td>
<td class=ic>28</td>
<td class=ic>29</td>
<td class=ic>30</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1174&x=-390&p=Ma%20Mad%C4%9Bra">Ma Maděra</a></td><td class=kx>*</td>
<td class=kW>7:3 K</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0 K</td>
<td class=kW>6:4</td>
<td class=kW>2:0</td>
<td class=kL>2:4 K</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kW>2:1 K</td>
<td class=kW>6:2 K</td>
<td class=kW>3:1 K</td>
<td class=kW>7:1</td>
<td class=kW>4:0 K</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=kW>5:2 K</td>
<td class=kW>4:1</td>
<td class=kW>9:3 K</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=br>119:53</td><td class=br>+66</td>
<td class=bc>24 - 2 - 3</td>
<td class=br><strong>50</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1477&x=-390&p=Mi%20Kobrle">Mi Kobrle</a></td><td class=kL>3:7 K</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3 K</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kW>3:2 K</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kT>5:5</td>
<td class=kW>3:1</td>
<td class=kW>8:2</td>
<td class=kW>5:1 K</td>
<td class=kW>4:3 K</td>
<td class=kW>6:1 K</td>
<td class=kW>4:3</td>
<td class=kW>4:0 K</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>4:1 K</td>
<td class=kW>6:3</td>
<td class=kW>7:2 K</td>
<td class=kW>8:2</td>
<td class=kW>6:1</td>
<td class=br>123:63</td><td class=br>+60</td>
<td class=bc>23 - 1 - 5</td>
<td class=br><strong>47</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1649&x=-390&p=Ra%20Miglinieks">Ra Miglinieks</a></td><td class=kT>4:4</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>4:1 K</td>
<td class=kW>3:0</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>6:2 K</td>
<td class=kW>3:2 K</td>
<td class=kW>3:0 K</td>
<td class=kW>6:1 K</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kL>3:5</td>
<td class=kT>3:3 K</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>6:3 K</td>
<td class=kW>3:1 K</td>
<td class=kW>6:0</td>
<td class=kW>7:1 K</td>
<td class=kW>2:1</td>
<td class=kW>8:0</td>
<td class=kW>8:0</td>
<td class=br>117:55</td><td class=br>+62</td>
<td class=bc>20 - 5 - 4</td>
<td class=br><strong>45</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1616&x=-390&p=Em%20Larsson">Em Larsson</a></td><td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:3 K</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>5:6 K</td>
<td class=kW>3:2 K</td>
<td class=kW>4:2</td>
<td class=kW>6:0 K</td>
<td class=kW>6:0 K</td>
<td class=kL>1:3 K</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>3:0 K</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>6:2 K</td>
<td class=kW>6:0 K</td>
<td class=br>110:58</td><td class=br>+52</td>
<td class=bc>20 - 4 - 5</td>
<td class=br><strong>44</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1772&x=-390&p=El%20Silin%C5%A1">El Silinš</a></td><td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>3:4 K</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1 K</td>
<td class=kW>4:1 K</td>
<td class=kL>2:3</td>
<td class=kW>4:3 K</td>
<td class=kT>4:4 K</td>
<td class=kL>1:2 K</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kW>7:3</td>
<td class=kW>6:3</td>
<td class=kW>6:2 K</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>4:2 K</td>
<td class=kW>3:2 K</td>
<td class=br>107:55</td><td class=br>+52</td>
<td class=bc>20 - 2 - 7</td>
<td class=br><strong>42</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=567&x=-390&p=Kr%20Lebl">Kr Lebl</a></td><td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:4 K</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>7:1 K</td>
<td class=kL>1:3 K</td>
<td class=kW>3:1 K</td>
<td class=kW>6:1 K</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>7:1 K</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>2:3 K</td>
<td class=kW>6:1 K</td>
<td class=kW>6:0</td>
<td class=kW>3:0 K</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=br>105:56</td><td class=br>+49</td>
<td class=bc>18 - 3 - 8</td>
<td class=br><strong>39</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=386&x=-390&p=Ku%20Sl%C3%A1dek">Ku Sládek</a></td><td class=kL>0:4 K</td>
<td class=kW>3:2 K</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kL>0:3 K</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kW>4:3</td>
<td class=kL>2:3 K</td>
<td class=kT>2:2 K</td>
<td class=kW>4:2 K</td>
<td class=kW>4:1</td>
<td class=kW>5:2 K</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>4:2 K</td>
<td class=kW>6:2</td>
<td class=kW>6:3 K</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=br>78:60</td><td class=br>+18</td>
<td class=bc>16 - 7 - 6</td>
<td class=br><strong>39</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1977&x=-390&p=Ti%20Dion">Ti Dion</a></td><td class=kL>4:6</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kW>6:5 K</td>
<td class=kL>1:3 K</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3 K</td>
<td class=kW>4:1</td>
<td class=kW>4:2 K</td>
<td class=kL>0:3 K</td>
<td class=kW>3:1 K</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kW>5:4</td>
<td class=kW>5:4</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>8:3 K</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:3 K</td>
<td class=kW>5:4 K</td>
<td class=br>102:80</td><td class=br>+22</td>
<td class=bc>17 - 4 - 8</td>
<td class=br><strong>38</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2003&x=-390&p=An%20Kimberg">An Kimberg</a></td><td class=kL>0:2</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kL>2:3 K</td>
<td class=kL>1:4 K</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kT>3:3 K</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>2:3 K</td>
<td class=kL>2:3 K</td>
<td class=kW>3:1 K</td>
<td class=kL>0:3</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>4:1 K</td>
<td class=kW>3:0 K</td>
<td class=br>80:61</td><td class=br>+19</td>
<td class=bc>16 - 5 - 8</td>
<td class=br><strong>37</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=310&x=-390&p=Mi%20%C4%8Cernoch">Mi Černoch</a></td><td class=kW>4:2 K</td>
<td class=kL>2:3 K</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kW>3:0 K</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kL>0:1</td>
<td class=kL>0:1</td>
<td class=kW>4:2 K</td>
<td class=kT>0:0 K</td>
<td class=kW>4:1 K</td>
<td class=kW>3:0</td>
<td class=kW>2:1 K</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2 K</td>
<td class=kW>4:1</td>
<td class=kW>4:1 K</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=br>70:54</td><td class=br>+16</td>
<td class=bc>17 - 1 - 11</td>
<td class=br><strong>35</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1065&x=-390&p=Kr%20Herold">Kr Herold</a></td><td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>0:6 K</td>
<td class=kL>3:4 K</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4 K</td>
<td class=kW>3:2 K</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>0:3 K</td>
<td class=kW>4:2 K</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>6:1</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kT>3:3 K</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>3:1 K</td>
<td class=kW>3:0 K</td>
<td class=br>81:68</td><td class=br>+13</td>
<td class=bc>16 - 2 - 11</td>
<td class=br><strong>34</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1579&x=-390&p=Vi%20Henttonen">Vi Henttonen</a></td><td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>0:6 K</td>
<td class=kT>4:4 K</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>3:0 K</td>
<td class=kW>3:2 K</td>
<td class=kW>3:1</td>
<td class=kW>3:0 K</td>
<td class=kx>*</td>
<td class=kL>1:4 K</td>
<td class=kL>2:4</td>
<td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>5:4</td>
<td class=kW>3:2 K</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>1:2 K</td>
<td class=kW>5:2 K</td>
<td class=br>67:69</td><td class=br>-2</td>
<td class=bc>13 - 6 - 10</td>
<td class=br><strong>32</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=53&x=-390&p=V%C3%A1%20Pikl">Vá Pikl</a></td><td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kW>3:1 K</td>
<td class=kW>2:1 K</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>1:3 K</td>
<td class=kL>1:3 K</td>
<td class=kL>1:3</td>
<td class=kL>2:4 K</td>
<td class=kW>4:1 K</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kL>0:1 K</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>7:2</td>
<td class=kW>6:3 K</td>
<td class=kW>6:0 K</td>
<td class=br>76:65</td><td class=br>+11</td>
<td class=bc>14 - 3 - 12</td>
<td class=br><strong>31</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=961&x=-390&p=Mi%20Bo%C5%A1t%C3%ADk">Mi Boštík</a></td><td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>2:6 K</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:7 K</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1 K</td>
<td class=kL>2:3 K</td>
<td class=kW>4:3 K</td>
<td class=kW>6:0</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>3:5 K</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kL>1:2 K</td>
<td class=kL>3:4 K</td>
<td class=kW>3:1</td>
<td class=kW>5:0 K</td>
<td class=kW>7:1</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=br>91:72</td><td class=br>+19</td>
<td class=bc>15 - 1 - 13</td>
<td class=br><strong>31</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=448&x=-390&p=To%20Waclawek">To Waclawek</a></td><td class=kL>3:4</td>
<td class=kT>5:5</td>
<td class=kL>2:3 K</td>
<td class=kT>4:4</td>
<td class=kL>1:5</td>
<td class=kW>3:1 K</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3 K</td>
<td class=kx>*</td>
<td class=kW>4:1 K</td>
<td class=kT>3:3 K</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kT>4:4 K</td>
<td class=kW>6:1</td>
<td class=kL>2:4</td>
<td class=kL>1:2 K</td>
<td class=kL>2:4 K</td>
<td class=kW>5:0</td>
<td class=kW>5:3 K</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=br>92:80</td><td class=br>+12</td>
<td class=bc>11 - 7 - 11</td>
<td class=br><strong>29</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1828&x=-390&p=Tr%20Mansson">Tr Mansson</a></td><td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>0:3 K</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kL>1:3 K</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>3:2 K</td>
<td class=kL>1:4 K</td>
<td class=kx>*</td>
<td class=kL>1:4 K</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1 K</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>2:3 K</td>
<td class=kW>3:0 K</td>
<td class=kL>3:4</td>
<td class=kL>2:3 K</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=br>64:60</td><td class=br>+4</td>
<td class=bc>12 - 5 - 12</td>
<td class=br><strong>29</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=344&x=-390&p=Ge%20Regula">Ge Regula</a></td><td class=kL>2:5</td>
<td class=kL>2:8</td>
<td class=kL>1:6 K</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kL>1:6 K</td>
<td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>3:4 K</td>
<td class=kT>3:3 K</td>
<td class=kW>4:1 K</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kW>4:0 K</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>3:0 K</td>
<td class=kT>2:2 K</td>
<td class=kW>5:1</td>
<td class=kW>5:2 K</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=br>75:84</td><td class=br>-9</td>
<td class=bc>11 - 5 - 13</td>
<td class=br><strong>27</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=893&x=-390&p=Ne%20%C5%A0krlep">Ne Škrlep</a></td><td class=kL>1:2 K</td>
<td class=kL>1:5 K</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kW>3:2 K</td>
<td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kL>2:4 K</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kL>0:2</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>3:2 K</td>
<td class=kL>1:6 K</td>
<td class=kW>3:0</td>
<td class=kW>3:1 K</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kL>1:2 K</td>
<td class=kW>4:0</td>
<td class=kW>2:0 K</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=br>63:74</td><td class=br>-11</td>
<td class=bc>12 - 2 - 15</td>
<td class=br><strong>26</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1872&x=-390&p=Pe%20Fuchs">Pe Fuchs</a></td><td class=kL>2:6 K</td>
<td class=kL>3:4 K</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kT>0:0 K</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>2:3 K</td>
<td class=kx>*</td>
<td class=kW>6:3 K</td>
<td class=kW>5:3</td>
<td class=kT>3:3 K</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kW>1:0 K</td>
<td class=kW>6:1</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=br>68:81</td><td class=br>-13</td>
<td class=bc>7 - 11 - 11</td>
<td class=br><strong>25</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1912&x=-390&p=Al%20Krejza">Al Krejza</a></td><td class=kL>1:3 K</td>
<td class=kL>1:6 K</td>
<td class=kW>5:3</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kL>2:4 K</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>1:4 K</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kW>6:1 K</td>
<td class=kL>3:6 K</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>2:4 K</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3 K</td>
<td class=kW>3:2</td>
<td class=kW>2:1 K</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=br>70:84</td><td class=br>-14</td>
<td class=bc>11 - 3 - 15</td>
<td class=br><strong>25</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2006&x=-390&p=G%C3%B6%20L%C3%B6nnqvist">Gö Lönnqvist</a></td><td class=kL>1:7</td>
<td class=kL>3:4</td>
<td class=kT>3:3 K</td>
<td class=kL>3:5</td>
<td class=kL>3:7</td>
<td class=kL>1:7 K</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>5:3 K</td>
<td class=kT>4:4 K</td>
<td class=kT>1:1 K</td>
<td class=kL>0:4 K</td>
<td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>5:4 K</td>
<td class=kL>2:4 K</td>
<td class=kW>3:1</td>
<td class=kL>1:2 K</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=br>73:91</td><td class=br>-18</td>
<td class=bc>10 - 5 - 14</td>
<td class=br><strong>25</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=201&x=-390&p=To%20Bucek">To Bucek</a></td><td class=kL>0:4 K</td>
<td class=kL>0:4 K</td>
<td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kL>2:5 K</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2 K</td>
<td class=kL>0:4</td>
<td class=kL>4:5</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kL>1:3 K</td>
<td class=kT>3:3 K</td>
<td class=kW>4:2 K</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kT>1:1</td>
<td class=kW>6:0 K</td>
<td class=kW>3:2</td>
<td class=kW>2:1 K</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=br>76:90</td><td class=br>-14</td>
<td class=bc>9 - 6 - 14</td>
<td class=br><strong>24</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1117&x=-390&p=To%20Kahoun%20ml.">To Kahoun ml.</a></td><td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>0:3 K</td>
<td class=kL>2:6 K</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>3:8 K</td>
<td class=kT>2:2 K</td>
<td class=kL>0:3</td>
<td class=kT>3:3 K</td>
<td class=kL>2:3 K</td>
<td class=kW>1:0 K</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kW>2:1 K</td>
<td class=kW>9:0 K</td>
<td class=br>60:76</td><td class=br>-16</td>
<td class=bc>9 - 6 - 14</td>
<td class=br><strong>24</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=347&x=-390&p=Ma%20Papp">Ma Papp</a></td><td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>3:6 K</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kW>3:2 K</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1 K</td>
<td class=kW>2:1 K</td>
<td class=kW>3:2 K</td>
<td class=kL>0:3 K</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kL>4:5 K</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1 K</td>
<td class=kW>4:2</td>
<td class=kW>3:2 K</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=br>67:87</td><td class=br>-20</td>
<td class=bc>11 - 2 - 16</td>
<td class=br><strong>24</strong></td><td class=d>24.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>25.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1978&x=-390&p=My%20Verbytskyy">My Verbytskyy</a></td><td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>1:3 K</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>1:6 K</td>
<td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>4:3 K</td>
<td class=kW>4:2 K</td>
<td class=kL>0:3 K</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>4:2 K</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>1:2 K</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>4:1 K</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=br>49:80</td><td class=br>-31</td>
<td class=bc>8 - 5 - 16</td>
<td class=br><strong>21</strong></td><td class=d>25.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>26.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=346&x=-390&p=B%C3%A1%20Nagy">Bá Nagy</a></td><td class=kL>2:5 K</td>
<td class=kL>1:4 K</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>2:4 K</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3 K</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kW>4:3</td>
<td class=kL>1:5</td>
<td class=kW>2:1 K</td>
<td class=kL>0:1 K</td>
<td class=kW>3:2 K</td>
<td class=kL>1:3</td>
<td class=kL>0:6 K</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>2:2 K</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=br>42:94</td><td class=br>-52</td>
<td class=bc>7 - 1 - 21</td>
<td class=br><strong>15</strong></td><td class=d>26.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>27.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=18&x=-390&p=An%20%C5%A0ur%C3%BDn">An Šurýn</a></td><td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kL>1:7 K</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>0:3 K</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>0:5 K</td>
<td class=kL>3:5 K</td>
<td class=kW>3:2 K</td>
<td class=kL>2:5 K</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kW>2:1 K</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>2:3 K</td>
<td class=kL>1:4 K</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kW>4:0</td>
<td class=br>50:100</td><td class=br>-50</td>
<td class=bc>7 - 0 - 22</td>
<td class=br><strong>14</strong></td><td class=d>27.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>28.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=70&x=-390&p=St%20Srba">St Srba</a></td><td class=kL>3:9 K</td>
<td class=kL>2:7 K</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>3:6 K</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4 K</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>2:7</td>
<td class=kL>1:7</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>0:2 K</td>
<td class=kT>2:2 K</td>
<td class=kL>1:2 K</td>
<td class=kL>1:2</td>
<td class=kL>1:2 K</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kT>2:2 K</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>45:98</td><td class=br>-53</td>
<td class=bc>2 - 6 - 21</td>
<td class=br><strong>10</strong></td><td class=d>28.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>29.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2000&x=-390&p=Da%20Hasler">Da Hasler</a></td><td class=kL>0:6</td>
<td class=kL>2:8</td>
<td class=kL>0:8</td>
<td class=kL>2:6 K</td>
<td class=kL>2:4 K</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>3:4 K</td>
<td class=kL>1:4 K</td>
<td class=kL>2:6</td>
<td class=kL>1:3 K</td>
<td class=kW>2:1 K</td>
<td class=kL>3:6 K</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>1:2 K</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=br>51:115</td><td class=br>-64</td>
<td class=bc>2 - 3 - 24</td>
<td class=br><strong>7</strong></td><td class=d>29.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>30.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1409&x=-390&p=Ji%20Mal%C3%ADk">Ji Malík</a></td><td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>0:8</td>
<td class=kL>0:6 K</td>
<td class=kL>2:3 K</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>4:5 K</td>
<td class=kL>0:3 K</td>
<td class=kL>2:4</td>
<td class=kL>0:3 K</td>
<td class=kL>2:5 K</td>
<td class=kL>0:6 K</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>0:9 K</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=br>29:137</td><td class=br>-108</td>
<td class=bc>0 - 1 - 28</td>
<td class=br><strong>1</strong></td><td class=d>30.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Gö Lönnqvist</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Kimberg</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Da Hasler</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Gö Lönnqvist</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>An Kimberg</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Da Hasler</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=blW>Bá Nagy</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Gö Lönnqvist</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Mi Boštík</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Hasler</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>An Kimberg</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Šurýn</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Gö Lönnqvist</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Hasler</td><td class=bc>-</td><td class=blW>Ne Škrlep</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>An Kimberg</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Gö Lönnqvist</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Boštík</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>An Šurýn</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ne Škrlep</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Ma Maděra</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Da Hasler</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>An Kimberg</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>An Kimberg</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Gö Lönnqvist</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Hasler</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Gö Lönnqvist</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>An Kimberg</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Hasler</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Da Hasler</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>An Kimberg</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Gö Lönnqvist</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>To Kahoun ml.</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Da Hasler</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>An Kimberg</td><td class=bc>-</td><td class=bl>Gö Lönnqvist</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>An Šurýn</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>To Kahoun ml.</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Da Hasler</td><td class=bc>-</td><td class=blW>Gö Lönnqvist</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ji Malík</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>An Kimberg</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>An Kimberg</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Da Hasler</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Gö Lönnqvist</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Da Hasler</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>An Kimberg</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Gö Lönnqvist</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>Da Hasler</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>An Kimberg</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Gö Lönnqvist</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Bá Nagy</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Da Hasler</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>An Kimberg</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Gö Lönnqvist</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>St Srba</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Bá Nagy</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>An Kimberg</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Da Hasler</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Gö Lönnqvist</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ma Maděra</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Em Larsson</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Gö Lönnqvist</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>An Kimberg</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Bá Nagy</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Da Hasler</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ne Škrlep</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Gö Lönnqvist</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Da Hasler</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Bá Nagy</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>An Kimberg</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Mi Boštík</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Gö Lönnqvist</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>St Srba</td><td class=bc>-</td><td class=bl>Da Hasler</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>An Kimberg</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Bá Nagy</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Gö Lönnqvist</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Bá Nagy</td><td class=bc>-</td><td class=bl>Da Hasler</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>An Kimberg</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>To Kahoun ml.</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ge Regula</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ne Škrlep</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ma Maděra</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>An Šurýn</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Gö Lönnqvist</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Boštík</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Em Larsson</td><td class=bc>-</td><td class=bl>Tr Mansson</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ji Malík</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Bá Nagy</td><td class=bc>-</td><td class=blW>An Kimberg</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>St Srba</td><td class=bc>-</td><td class=blW>To Kahoun ml.</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>Da Hasler</td><td class=bc>2 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
