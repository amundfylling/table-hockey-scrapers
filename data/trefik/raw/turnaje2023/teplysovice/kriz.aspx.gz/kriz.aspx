<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Teplýšovice</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../teplysovice">Teplýšovice, 10. prosinec 2022</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Základní skupiny (Basic groups)</a><br>
<a href="#final">Výkonnostní skupiny (Final groups)</a><br>
<a name="basic"><p class=vm>Základní skupiny (Basic groups)</p></a>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Mi Černoch</td><td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>9:0</td>
<td class=kW>5:0</td>
<td class=kW>12:1</td>
<td class=kW>4:0</td>
<td class=br>73:21</td><td class=br>+52</td>
<td class=bc>14 - 2 - 1</td>
<td class=br><strong>30</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ja Matýsek</td><td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>7:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>7:2</td>
<td class=kW>9:2</td>
<td class=br>72:35</td><td class=br>+37</td>
<td class=bc>13 - 1 - 3</td>
<td class=br><strong>27</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Pa Plešák</td><td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>6:4</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>9:2</td>
<td class=kW>8:1</td>
<td class=kW>8:3</td>
<td class=kW>7:0</td>
<td class=kW>6:1</td>
<td class=br>80:35</td><td class=br>+45</td>
<td class=bc>12 - 2 - 3</td>
<td class=br><strong>26</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Mi Kobrle</td><td class=kW>3:1</td>
<td class=kL>5:7</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>3:6</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=kW>6:3</td>
<td class=kW>8:4</td>
<td class=kW>9:1</td>
<td class=kW>9:0</td>
<td class=kW>9:1</td>
<td class=kW>9:1</td>
<td class=kW>7:1</td>
<td class=br>94:39</td><td class=br>+55</td>
<td class=bc>12 - 1 - 4</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Da Matýsek</td><td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>6:0</td>
<td class=kW>6:5</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>8:0</td>
<td class=kW>6:3</td>
<td class=br>61:34</td><td class=br>+27</td>
<td class=bc>10 - 4 - 3</td>
<td class=br><strong>24</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ma Ženíšek</td><td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>4:6</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>6:3</td>
<td class=kW>7:2</td>
<td class=br>69:44</td><td class=br>+25</td>
<td class=bc>11 - 1 - 5</td>
<td class=br><strong>23</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Al Krejza</td><td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>3:6</td>
<td class=kW>1:0</td>
<td class=kW>8:2</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=br>53:41</td><td class=br>+12</td>
<td class=bc>9 - 3 - 5</td>
<td class=br><strong>21</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Vl Kraus</td><td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>8:1</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=br>58:40</td><td class=br>+18</td>
<td class=bc>9 - 3 - 5</td>
<td class=br><strong>21</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Hy Nechutný</td><td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=br>49:43</td><td class=br>+6</td>
<td class=bc>9 - 3 - 5</td>
<td class=br><strong>21</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>To Waclawek</td><td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=br>51:42</td><td class=br>+9</td>
<td class=bc>9 - 2 - 6</td>
<td class=br><strong>20</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>A</td><td class=d>11.</td><td class=kt>Jo Kůrka</td><td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kL>0:6</td>
<td class=kL>5:6</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kW>7:1</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kW>3:1</td>
<td class=kW>8:0</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=br>68:55</td><td class=br>+13</td>
<td class=bc>8 - 1 - 8</td>
<td class=br><strong>17</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>A</td><td class=d>12.</td><td class=kt>Pe Fuchs</td><td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>3:6</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=br>48:47</td><td class=br>+1</td>
<td class=bc>8 - 1 - 8</td>
<td class=br><strong>17</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Vl Gobyová</td><td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>4:8</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=br>43:59</td><td class=br>-16</td>
<td class=bc>6 - 1 - 10</td>
<td class=br><strong>13</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>B</td><td class=d>14.</td><td class=kt>Vo Goby</td><td class=kL>1:6</td>
<td class=kL>0:1</td>
<td class=kL>2:9</td>
<td class=kL>1:9</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kL>2:8</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>7:3</td>
<td class=br>36:78</td><td class=br>-42</td>
<td class=bc>4 - 0 - 13</td>
<td class=br><strong>8</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>B</td><td class=d>15.</td><td class=kt>Vojta Kraus</td><td class=kL>0:9</td>
<td class=kL>1:3</td>
<td class=kL>1:8</td>
<td class=kL>0:9</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=br>28:72</td><td class=br>-44</td>
<td class=bc>2 - 2 - 13</td>
<td class=br><strong>6</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>B</td><td class=d>16.</td><td class=kt>Pe Klazar</td><td class=kL>0:5</td>
<td class=kL>2:6</td>
<td class=kL>3:8</td>
<td class=kL>1:9</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=br>29:81</td><td class=br>-52</td>
<td class=bc>1 - 2 - 14</td>
<td class=br><strong>4</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>B</td><td class=d>17.</td><td class=kt>Pa Goby</td><td class=kL>1:12</td>
<td class=kL>2:7</td>
<td class=kL>0:7</td>
<td class=kL>1:9</td>
<td class=kL>0:8</td>
<td class=kL>3:6</td>
<td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=br>24:97</td><td class=br>-73</td>
<td class=bc>1 - 1 - 15</td>
<td class=br><strong>3</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>B</td><td class=d>18.</td><td class=kt>Ka Stařecká</td><td class=kL>0:4</td>
<td class=kL>2:9</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>3:6</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>3:7</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=br>23:96</td><td class=br>-73</td>
<td class=bc>0 - 0 - 17</td>
<td class=br><strong>0</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Pa Goby</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Vo Goby</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Jo Kůrka</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Vojta Kraus</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pa Goby</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Vo Goby</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pa Goby</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Jo Kůrka</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vo Goby</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 9</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Pa Goby</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Vo Goby</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Jo Kůrka</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Pa Goby</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Vo Goby</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Pa Goby</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Vo Goby</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Vo Goby</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Pa Goby</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Vo Goby</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Pa Goby</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>7 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Jo Kůrka</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Vo Goby</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Pa Goby</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>Vo Goby</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Vojta Kraus</td><td class=bc>-</td><td class=bl>Pa Goby</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Vo Goby</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>4 : 8</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Pa Goby</td><td class=bc>12 : 1</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jo Kůrka</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Pa Goby</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Vo Goby</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>Pa Goby</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Vo Goby</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Pa Goby</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vo Goby</td><td class=bc>-</td><td class=bl>Pa Goby</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Jo Kůrka</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=bl>Pa Goby</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Vo Goby</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Pa Goby</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Vo Goby</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Jo Kůrka</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vo Goby</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Pa Petr</td><td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>12:4</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kL>4:5</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>16:2</td>
<td class=kW>11:0</td>
<td class=kW>11:1</td>
<td class=kW>9:0</td>
<td class=br>113:22</td><td class=br>+91</td>
<td class=bc>15 - 1 - 1</td>
<td class=br><strong>31</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Kr Herold</td><td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kL>0:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>8:1</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=kW>8:0</td>
<td class=br>75:32</td><td class=br>+43</td>
<td class=bc>12 - 1 - 4</td>
<td class=br><strong>25</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Kr Lebl</td><td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>0:5</td>
<td class=kW>6:0</td>
<td class=kL>1:2</td>
<td class=kW>7:2</td>
<td class=kW>2:0</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>9:0</td>
<td class=kT>3:3</td>
<td class=kW>8:0</td>
<td class=kW>7:0</td>
<td class=br>72:28</td><td class=br>+44</td>
<td class=bc>12 - 1 - 4</td>
<td class=br><strong>25</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ji Chylík ml.</td><td class=kL>4:12</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=br>59:34</td><td class=br>+25</td>
<td class=bc>12 - 1 - 4</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ku Sládek</td><td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>5:0</td>
<td class=kL>0:2</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=br>58:33</td><td class=br>+25</td>
<td class=bc>11 - 1 - 5</td>
<td class=br><strong>23</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>To Bucek</td><td class=kL>1:6</td>
<td class=kW>4:3</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=kW>11:0</td>
<td class=kW>6:0</td>
<td class=br>67:45</td><td class=br>+22</td>
<td class=bc>11 - 1 - 5</td>
<td class=br><strong>23</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ad Kopřiva</td><td class=kL>0:4</td>
<td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>1:0</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=br>54:41</td><td class=br>+13</td>
<td class=bc>11 - 1 - 5</td>
<td class=br><strong>23</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ma Klazar</td><td class=kW>5:4</td>
<td class=kL>2:4</td>
<td class=kL>2:7</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=br>46:37</td><td class=br>+9</td>
<td class=bc>11 - 1 - 5</td>
<td class=br><strong>23</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Vá Pikl</td><td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>10:0</td>
<td class=br>55:33</td><td class=br>+22</td>
<td class=bc>10 - 1 - 6</td>
<td class=br><strong>21</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>A</td><td class=d>10.</td><td class=kt>Mi Ševr</td><td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>0:6</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>8:2</td>
<td class=kW>6:4</td>
<td class=kW>8:0</td>
<td class=kW>7:1</td>
<td class=br>63:43</td><td class=br>+20</td>
<td class=bc>9 - 2 - 6</td>
<td class=br><strong>20</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>A</td><td class=d>11.</td><td class=kt>Jo Perkner</td><td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=br>41:49</td><td class=br>-8</td>
<td class=bc>6 - 3 - 8</td>
<td class=br><strong>15</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>A</td><td class=d>12.</td><td class=kt>Fr Marek</td><td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>8:0</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=kW>5:4</td>
<td class=kW>5:0</td>
<td class=br>49:43</td><td class=br>+6</td>
<td class=bc>6 - 1 - 10</td>
<td class=br><strong>13</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Ma Košňar</td><td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>6:0</td>
<td class=br>43:59</td><td class=br>-16</td>
<td class=bc>5 - 2 - 10</td>
<td class=br><strong>12</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>B</td><td class=d>14.</td><td class=kt>Pa Pohořalý</td><td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kL>0:8</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kW>5:3</td>
<td class=br>35:61</td><td class=br>-26</td>
<td class=bc>5 - 0 - 12</td>
<td class=br><strong>10</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>B</td><td class=d>15.</td><td class=kt>Ad Kratochvíl</td><td class=kL>2:16</td>
<td class=kL>1:8</td>
<td class=kL>0:9</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>0:7</td>
<td class=kL>2:8</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=br>30:91</td><td class=br>-61</td>
<td class=bc>3 - 0 - 14</td>
<td class=br><strong>6</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>B</td><td class=d>16.</td><td class=kt>Ra Hrnčíř</td><td class=kL>0:11</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>0:8</td>
<td class=kL>3:5</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>4:6</td>
<td class=kT>1:1</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=br>30:75</td><td class=br>-45</td>
<td class=bc>2 - 2 - 13</td>
<td class=br><strong>6</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>B</td><td class=d>17.</td><td class=kt>Ji Písečka</td><td class=kL>1:11</td>
<td class=kL>0:6</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>0:11</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:8</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kT>4:4</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=br>25:95</td><td class=br>-70</td>
<td class=bc>2 - 1 - 14</td>
<td class=br><strong>5</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>B</td><td class=d>18.</td><td class=kt>Zu Stařecká</td><td class=kL>0:9</td>
<td class=kL>0:8</td>
<td class=kL>0:7</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>0:10</td>
<td class=kL>1:7</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>3:5</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=br>9:103</td><td class=br>-94</td>
<td class=bc>0 - 0 - 17</td>
<td class=br><strong>0</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Zu Stařecká</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ad Kratochvíl</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Pa Pohořalý</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Zu Stařecká</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ad Kratochvíl</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Zu Stařecká</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ad Kratochvíl</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>4 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Zu Stařecká</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ad Kratochvíl</td><td class=bc>-</td><td class=blW>Pa Pohořalý</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=blW>Pa Pohořalý</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Zu Stařecká</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ad Kratochvíl</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Zu Stařecká</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Ad Kratochvíl</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Zu Stařecká</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ad Kratochvíl</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ji Písečka</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Zu Stařecká</td><td class=bc>-</td><td class=blW>Ad Kratochvíl</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ad Kratochvíl</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ji Písečka</td><td class=bc>-</td><td class=bl>Zu Stařecká</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Ad Kratochvíl</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Zu Stařecká</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ad Kratochvíl</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Zu Stařecká</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ad Kratochvíl</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Zu Stařecká</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>11 : 0</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>12 : 4</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ad Kratochvíl</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Zu Stařecká</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ad Kratochvíl</td><td class=bc>16 : 2</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Zu Stařecká</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ad Kratochvíl</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Zu Stařecká</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>11 : 1</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Zu Stařecká</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ad Kratochvíl</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Zu Stařecká</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ad Kratochvíl</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<hr><a name="final"><p class=vm>Výkonnostní skupiny (Final groups)</p></a>
<p class=v>Group A</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt>Pa Petr</td><td class=kx>*</td>
<td class=kW>12:4 K</td>
<td class=kW>8:1</td>
<td class=kW>6:2</td>
<td class=kL>1:2</td>
<td class=kW>4:2 K</td>
<td class=kW>3:2 K</td>
<td class=kW>8:1</td>
<td class=kW>4:0 K</td>
<td class=kW>9:0</td>
<td class=kW>4:0 K</td>
<td class=kW>6:1 K</td>
<td class=kT>2:2 K</td>
<td class=kW>3:0</td>
<td class=kL>4:5 K</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>8:3</td>
<td class=kW>4:0 K</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>5:1 K</td>
<td class=kW>5:0 K</td>
<td class=br>118:35</td><td class=br>+83</td>
<td class=bc>20 - 1 - 2</td>
<td class=br><strong>41</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt>Ji Chylík ml.</td><td class=kL>4:12 K</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3 K</td>
<td class=kT>1:1 K</td>
<td class=kW>4:2</td>
<td class=kL>2:5 K</td>
<td class=kT>3:3</td>
<td class=kW>3:0 K</td>
<td class=kW>4:1 K</td>
<td class=kW>5:3 K</td>
<td class=kW>4:3</td>
<td class=kL>2:3 K</td>
<td class=kT>0:0</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>5:0 K</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>3:0 K</td>
<td class=kW>3:0 K</td>
<td class=br>72:56</td><td class=br>+16</td>
<td class=bc>14 - 4 - 5</td>
<td class=br><strong>32</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt>Mi Černoch</td><td class=kL>1:8</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:2 K</td>
<td class=kL>1:3 K</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2</td>
<td class=kW>3:2 K</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>2:0 K</td>
<td class=kW>3:2</td>
<td class=kW>2:0 K</td>
<td class=kT>2:2 K</td>
<td class=kW>5:1 K</td>
<td class=kW>6:2 K</td>
<td class=kL>2:3</td>
<td class=kW>3:1 K</td>
<td class=kW>3:2 K</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=br>63:43</td><td class=br>+20</td>
<td class=bc>13 - 5 - 5</td>
<td class=br><strong>31</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt>Pa Plešák</td><td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>2:4 K</td>
<td class=kx>*</td>
<td class=kW>4:1 K</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kW>3:0 K</td>
<td class=kT>0:0</td>
<td class=kL>2:6 K</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2</td>
<td class=kT>3:3 K</td>
<td class=kW>6:4 K</td>
<td class=kW>3:2 K</td>
<td class=kW>7:1 K</td>
<td class=kT>2:2</td>
<td class=kW>2:1 K</td>
<td class=kL>2:4 K</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=br>63:51</td><td class=br>+12</td>
<td class=bc>12 - 6 - 5</td>
<td class=br><strong>30</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>Mi Kobrle</td><td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>3:1 K</td>
<td class=kL>1:4 K</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kW>5:2 K</td>
<td class=kT>1:1</td>
<td class=kL>5:7 K</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kT>3:3</td>
<td class=kW>6:2 K</td>
<td class=kW>5:1</td>
<td class=kL>3:6 K</td>
<td class=kW>4:1 K</td>
<td class=kL>2:3 K</td>
<td class=kT>2:2 K</td>
<td class=kW>7:1</td>
<td class=kW>6:3 K</td>
<td class=kW>6:0 K</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=br>89:52</td><td class=br>+37</td>
<td class=bc>13 - 4 - 6</td>
<td class=br><strong>30</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>Kr Herold</td><td class=kL>2:4 K</td>
<td class=kW>3:2 K</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>6:2 K</td>
<td class=kT>3:3</td>
<td class=kW>3:1 K</td>
<td class=kT>2:2</td>
<td class=kT>4:4 K</td>
<td class=kL>3:4 K</td>
<td class=kL>0:2 K</td>
<td class=kW>5:3</td>
<td class=kW>4:2 K</td>
<td class=kL>1:4</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>4:5 K</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>5:1 K</td>
<td class=kW>3:1 K</td>
<td class=br>73:55</td><td class=br>+18</td>
<td class=bc>12 - 5 - 6</td>
<td class=br><strong>29</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Ku Sládek</td><td class=kL>2:3 K</td>
<td class=kT>1:1 K</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kL>2:6 K</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>5:0 K</td>
<td class=kW>4:3</td>
<td class=kW>4:3 K</td>
<td class=kW>6:3 K</td>
<td class=kW>4:2 K</td>
<td class=kT>3:3</td>
<td class=kL>0:2 K</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>5:0 K</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kL>2:3 K</td>
<td class=kL>1:2 K</td>
<td class=br>65:39</td><td class=br>+26</td>
<td class=bc>13 - 3 - 7</td>
<td class=br><strong>29</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>Da Matýsek</td><td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kT>2:2 K</td>
<td class=kL>0:3 K</td>
<td class=kL>2:5 K</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>3:2 K</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>6:0 K</td>
<td class=kW>3:0</td>
<td class=kL>1:2 K</td>
<td class=kW>5:1 K</td>
<td class=kT>1:1 K</td>
<td class=kW>3:1 K</td>
<td class=kW>2:0</td>
<td class=kW>4:0 K</td>
<td class=kW>6:5 K</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=br>58:43</td><td class=br>+15</td>
<td class=bc>13 - 3 - 7</td>
<td class=br><strong>29</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>Kr Lebl</td><td class=kL>0:4 K</td>
<td class=kW>5:2 K</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kT>1:1</td>
<td class=kL>1:3 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>2:0 K</td>
<td class=kW>6:0 K</td>
<td class=kW>6:0 K</td>
<td class=kL>2:4</td>
<td class=kW>7:2 K</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2 K</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2 K</td>
<td class=kW>4:3 K</td>
<td class=br>62:42</td><td class=br>+20</td>
<td class=bc>11 - 6 - 6</td>
<td class=br><strong>28</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Ja Matýsek</td><td class=kL>0:9</td>
<td class=kT>3:3</td>
<td class=kL>2:3 K</td>
<td class=kW>6:2 K</td>
<td class=kW>7:5 K</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>2:3 K</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kW>6:2</td>
<td class=kW>5:1 K</td>
<td class=kL>1:2</td>
<td class=kT>2:2 K</td>
<td class=kL>2:3 K</td>
<td class=kW>3:2 K</td>
<td class=kW>2:1 K</td>
<td class=kW>3:0</td>
<td class=kW>4:2 K</td>
<td class=kW>6:2 K</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=br>72:65</td><td class=br>+7</td>
<td class=bc>11 - 3 - 9</td>
<td class=br><strong>25</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>Vá Pikl</td><td class=kL>0:4 K</td>
<td class=kL>0:3 K</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kT>4:4 K</td>
<td class=kL>3:4 K</td>
<td class=kW>2:1</td>
<td class=kL>0:2 K</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>2:1 K</td>
<td class=kL>2:5 K</td>
<td class=kW>3:0</td>
<td class=kL>2:3 K</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>4:1 K</td>
<td class=kL>3:4</td>
<td class=kW>7:0</td>
<td class=kW>3:1 K</td>
<td class=kW>2:1 K</td>
<td class=br>59:49</td><td class=br>+10</td>
<td class=bc>11 - 2 - 10</td>
<td class=br><strong>24</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>To Bucek</td><td class=kL>1:6 K</td>
<td class=kL>1:4 K</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kW>4:3 K</td>
<td class=kL>3:6 K</td>
<td class=kL>0:4</td>
<td class=kL>0:6 K</td>
<td class=kW>4:1</td>
<td class=kL>1:2 K</td>
<td class=kx>*</td>
<td class=kW>5:1 K</td>
<td class=kL>1:2</td>
<td class=kW>3:1 K</td>
<td class=kW>4:2</td>
<td class=kW>6:4</td>
<td class=kW>6:4</td>
<td class=kW>2:1</td>
<td class=kT>4:4 K</td>
<td class=kW>3:0</td>
<td class=kT>4:4</td>
<td class=kW>4:3 K</td>
<td class=kW>4:3 K</td>
<td class=br>61:75</td><td class=br>-14</td>
<td class=bc>11 - 2 - 10</td>
<td class=br><strong>24</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt>Mi Ševr</td><td class=kT>2:2 K</td>
<td class=kL>3:5 K</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kW>2:0 K</td>
<td class=kL>2:4 K</td>
<td class=kL>1:2</td>
<td class=kL>0:6 K</td>
<td class=kL>2:6</td>
<td class=kW>5:2 K</td>
<td class=kL>1:5 K</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kW>4:1 K</td>
<td class=kW>7:3</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kL>2:3 K</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>5:2 K</td>
<td class=kT>2:2 K</td>
<td class=br>65:64</td><td class=br>+1</td>
<td class=bc>10 - 3 - 10</td>
<td class=br><strong>23</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt>To Waclawek</td><td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kL>0:2 K</td>
<td class=kT>2:2 K</td>
<td class=kL>2:6 K</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kL>0:6 K</td>
<td class=kW>4:2</td>
<td class=kL>1:5 K</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:1 K</td>
<td class=kL>2:3 K</td>
<td class=kT>3:3 K</td>
<td class=kW>4:1 K</td>
<td class=kW>4:3</td>
<td class=kW>4:0 K</td>
<td class=kW>5:3 K</td>
<td class=kW>4:2</td>
<td class=kL>0:4</td>
<td class=br>56:66</td><td class=br>-10</td>
<td class=bc>9 - 4 - 10</td>
<td class=br><strong>22</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt>Ma Klazar</td><td class=kW>5:4 K</td>
<td class=kW>3:2 K</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>2:4 K</td>
<td class=kW>2:0 K</td>
<td class=kL>0:3</td>
<td class=kL>2:7 K</td>
<td class=kW>2:1</td>
<td class=kW>3:2 K</td>
<td class=kL>1:3 K</td>
<td class=kL>1:4 K</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>1:4 K</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kT>2:2 K</td>
<td class=kW>4:2 K</td>
<td class=br>48:63</td><td class=br>-15</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt>Hy Nechutný</td><td class=kL>0:5</td>
<td class=kT>0:0</td>
<td class=kL>0:2 K</td>
<td class=kT>3:3 K</td>
<td class=kW>6:3 K</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kW>2:1 K</td>
<td class=kL>0:1</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kL>3:7</td>
<td class=kL>1:2 K</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kL>1:5 K</td>
<td class=kL>3:6 K</td>
<td class=kT>3:3 K</td>
<td class=kT>3:3</td>
<td class=kW>4:1 K</td>
<td class=kL>1:7 K</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=br>48:65</td><td class=br>-17</td>
<td class=bc>7 - 6 - 10</td>
<td class=br><strong>20</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ma Ženíšek</td><td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kT>2:2 K</td>
<td class=kL>4:6 K</td>
<td class=kL>1:4 K</td>
<td class=kL>4:5</td>
<td class=kL>0:3</td>
<td class=kL>1:5 K</td>
<td class=kT>1:1</td>
<td class=kW>3:2 K</td>
<td class=kL>1:5</td>
<td class=kL>4:6</td>
<td class=kL>2:4</td>
<td class=kW>3:2 K</td>
<td class=kL>1:3</td>
<td class=kW>5:1 K</td>
<td class=kx>*</td>
<td class=kW>6:3 K</td>
<td class=kL>2:4 K</td>
<td class=kT>3:3</td>
<td class=kL>1:2 K</td>
<td class=kW>6:3 K</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=br>67:74</td><td class=br>-7</td>
<td class=bc>8 - 3 - 12</td>
<td class=br><strong>19</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Al Krejza</td><td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kL>1:5 K</td>
<td class=kL>2:3 K</td>
<td class=kW>3:2 K</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kT>1:1 K</td>
<td class=kL>3:5</td>
<td class=kL>2:3 K</td>
<td class=kL>1:4</td>
<td class=kL>4:6</td>
<td class=kL>1:3</td>
<td class=kT>3:3 K</td>
<td class=kW>4:3</td>
<td class=kW>6:3 K</td>
<td class=kL>3:6 K</td>
<td class=kx>*</td>
<td class=kT>1:1 K</td>
<td class=kW>4:1</td>
<td class=kL>3:6 K</td>
<td class=kW>3:2 K</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>62:72</td><td class=br>-10</td>
<td class=bc>7 - 4 - 12</td>
<td class=br><strong>18</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Vl Kraus</td><td class=kL>3:8</td>
<td class=kL>2:3</td>
<td class=kL>2:6 K</td>
<td class=kL>1:7 K</td>
<td class=kT>2:2 K</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kL>1:3 K</td>
<td class=kT>2:2</td>
<td class=kL>1:2 K</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>1:4 K</td>
<td class=kL>2:3</td>
<td class=kT>3:3 K</td>
<td class=kW>4:2 K</td>
<td class=kT>1:1 K</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:2 K</td>
<td class=kW>6:1 K</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=br>49:70</td><td class=br>-21</td>
<td class=bc>6 - 4 - 13</td>
<td class=br><strong>16</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Ad Kopřiva</td><td class=kL>0:4 K</td>
<td class=kL>0:5 K</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>1:7</td>
<td class=kW>5:4 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:2</td>
<td class=kW>2:1 K</td>
<td class=kL>0:3</td>
<td class=kL>1:4 K</td>
<td class=kT>4:4 K</td>
<td class=kW>3:2 K</td>
<td class=kL>3:4</td>
<td class=kW>4:1 K</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>1:3 K</td>
<td class=kW>2:1 K</td>
<td class=br>40:73</td><td class=br>-33</td>
<td class=bc>6 - 4 - 13</td>
<td class=br><strong>16</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Pe Fuchs</td><td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>1:3 K</td>
<td class=kL>1:2 K</td>
<td class=kL>3:6 K</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>0:4 K</td>
<td class=kT>3:3</td>
<td class=kL>2:4 K</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>0:4 K</td>
<td class=kW>3:2</td>
<td class=kL>1:4 K</td>
<td class=kW>2:1 K</td>
<td class=kW>6:3 K</td>
<td class=kL>2:4 K</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kT>5:5 K</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=br>50:76</td><td class=br>-26</td>
<td class=bc>6 - 3 - 14</td>
<td class=br><strong>15</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Jo Kůrka</td><td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>2:3 K</td>
<td class=kW>4:2 K</td>
<td class=kL>0:6 K</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kL>5:6 K</td>
<td class=kL>2:4</td>
<td class=kL>2:6 K</td>
<td class=kL>0:7</td>
<td class=kT>4:4</td>
<td class=kL>1:6</td>
<td class=kL>3:5 K</td>
<td class=kL>0:1</td>
<td class=kW>7:1 K</td>
<td class=kL>3:6 K</td>
<td class=kL>2:3 K</td>
<td class=kL>1:6 K</td>
<td class=kW>3:1</td>
<td class=kT>5:5 K</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=br>57:89</td><td class=br>-32</td>
<td class=bc>6 - 2 - 15</td>
<td class=br><strong>14</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Jo Perkner</td><td class=kL>1:5 K</td>
<td class=kL>0:3 K</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>1:5 K</td>
<td class=kW>3:2 K</td>
<td class=kL>0:2</td>
<td class=kL>2:4 K</td>
<td class=kL>3:5</td>
<td class=kL>1:3 K</td>
<td class=kL>3:4 K</td>
<td class=kL>2:5 K</td>
<td class=kL>2:4</td>
<td class=kT>2:2 K</td>
<td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1 K</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>4:2 K</td>
<td class=br>41:81</td><td class=br>-40</td>
<td class=bc>4 - 1 - 18</td>
<td class=br><strong>9</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Fr Marek</td><td class=kL>0:5 K</td>
<td class=kL>0:3 K</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kL>1:3 K</td>
<td class=kW>2:1 K</td>
<td class=kL>1:4</td>
<td class=kL>3:4 K</td>
<td class=kL>1:5</td>
<td class=kL>1:2 K</td>
<td class=kL>3:4 K</td>
<td class=kT>2:2 K</td>
<td class=kW>4:0</td>
<td class=kL>2:4 K</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>1:2 K</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>2:4 K</td>
<td class=kx>*</td>
<td class=br>39:79</td><td class=br>-40</td>
<td class=bc>2 - 3 - 18</td>
<td class=br><strong>7</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Hy Nechutný</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Jo Kůrka</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Jo Kůrka</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Al Krejza</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vl Kraus</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>Ku Sládek</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ad Kopřiva</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Ma Klazar</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>To Waclawek</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Jo Kůrka</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pe Fuchs</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ma Ženíšek</td><td class=bc>-</td><td class=blW>Kr Herold</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>Ji Chylík ml.</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Vl Kraus</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Hy Nechutný</td><td class=bc>-</td><td class=bl>Ad Kopřiva</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>To Waclawek</td><td class=bc>-</td><td class=bl>Ma Klazar</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jo Kůrka</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Pe Fuchs</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Kr Herold</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ma Ženíšek</td><td class=bc>-</td><td class=bl>Ji Chylík ml.</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Al Krejza</td><td class=bc>-</td><td class=blW>Ku Sládek</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=blW>Vl Kraus</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Klazar</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ku Sládek</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Pe Fuchs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ma Ženíšek</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Kr Herold</td><td class=bc>-</td><td class=blW>Hy Nechutný</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Jo Kůrka</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Al Krejza</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Jo Perkner</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>To Waclawek</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Pe Fuchs</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kr Herold</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ji Chylík ml.</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ku Sládek</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ad Kopřiva</td><td class=bc>-</td><td class=bl>Ma Ženíšek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Klazar</td><td class=bc>-</td><td class=blW>Al Krejza</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>Vl Kraus</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Hy Nechutný</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>To Waclawek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Jo Kůrka</td><td class=bc>3 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Pa Pohořalý</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>7:3</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=br>43:23</td><td class=br>+20</td>
<td class=bc>9 - 1 - 1</td>
<td class=br><strong>19</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Ma Košňar</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>9:0</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>8:0</td>
<td class=br>46:10</td><td class=br>+36</td>
<td class=bc>7 - 3 - 1</td>
<td class=br><strong>17</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Vojta Kraus</td><td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=br>30:14</td><td class=br>+16</td>
<td class=bc>8 - 0 - 3</td>
<td class=br><strong>16</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Pe Klazar</td><td class=kL>3:6</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>7:1</td>
<td class=kL>1:2</td>
<td class=kW>7:1</td>
<td class=br>34:26</td><td class=br>+8</td>
<td class=bc>7 - 0 - 4</td>
<td class=br><strong>14</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=d>5.</td><td class=kt>Ra Hrnčíř</td><td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kW>1:0</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=br>25:19</td><td class=br>+6</td>
<td class=bc>7 - 0 - 4</td>
<td class=br><strong>14</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=d>6.</td><td class=kt>Vl Gobyová</td><td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=br>31:21</td><td class=br>+10</td>
<td class=bc>6 - 1 - 4</td>
<td class=br><strong>13</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/4</td><td class=d>7.</td><td class=kt>Vo Goby</td><td class=kL>3:7</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=br>32:27</td><td class=br>+5</td>
<td class=bc>5 - 2 - 4</td>
<td class=br><strong>12</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/4</td><td class=d>8.</td><td class=kt>Pa Goby</td><td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=br>19:28</td><td class=br>-9</td>
<td class=bc>3 - 2 - 6</td>
<td class=br><strong>8</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Ad Kratochvíl</td><td class=kW>4:2</td>
<td class=kL>0:9</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=br>19:34</td><td class=br>-15</td>
<td class=bc>3 - 1 - 7</td>
<td class=br><strong>7</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ji Písečka</td><td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=br>19:38</td><td class=br>-19</td>
<td class=bc>2 - 2 - 7</td>
<td class=br><strong>6</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Ka Stařecká</td><td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=br>22:39</td><td class=br>-17</td>
<td class=bc>3 - 0 - 8</td>
<td class=br><strong>6</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Zu Stařecká</td><td class=kL>1:3</td>
<td class=kL>0:8</td>
<td class=kL>0:3</td>
<td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=br>10:51</td><td class=br>-41</td>
<td class=bc>0 - 0 - 11</td>
<td class=br><strong>0</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Zu Stařecká</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Vo Goby</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Pa Goby</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ad Kratochvíl</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Zu Stařecká</td><td class=bc>-</td><td class=blW>Ka Stařecká</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Pa Goby</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Vo Goby</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Vojta Kraus</td><td class=bc>-</td><td class=bl>Ad Kratochvíl</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Ji Písečka</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Zu Stařecká</td><td class=bc>-</td><td class=blW>Pa Goby</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Pe Klazar</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Vo Goby</td><td class=bc>-</td><td class=bl>Ad Kratochvíl</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Vojta Kraus</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=bl>Pa Goby</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Zu Stařecká</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Ad Kratochvíl</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=blW>Vojta Kraus</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vo Goby</td><td class=bc>-</td><td class=blW>Pa Pohořalý</td><td class=bc>3 : 7</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Pa Goby</td><td class=bc>-</td><td class=bl>Ra Hrnčíř</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ka Stařecká</td><td class=bc>-</td><td class=bl>Ad Kratochvíl</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Zu Stařecká</td><td class=bc>-</td><td class=blW>Vojta Kraus</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Pa Pohořalý</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Košňar</td><td class=bc>-</td><td class=bl>Vo Goby</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Pe Klazar</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Pa Goby</td><td class=bc>-</td><td class=blW>Ad Kratochvíl</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=blW>Vojta Kraus</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Pa Pohořalý</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Zu Stařecká</td><td class=bc>-</td><td class=blW>Vo Goby</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Vojta Kraus</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Pa Pohořalý</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pa Goby</td><td class=bc>-</td><td class=bl>Vo Goby</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Zu Stařecká</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ad Kratochvíl</td><td class=bc>-</td><td class=bl>Pa Pohořalý</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>Vo Goby</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pa Goby</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ji Písečka</td><td class=bc>-</td><td class=bl>Zu Stařecká</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ka Stařecká</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Vojta Kraus</td><td class=bc>-</td><td class=blW>Vo Goby</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ad Kratochvíl</td><td class=bc>-</td><td class=blW>Ma Košňar</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Zu Stařecká</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pa Goby</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ji Písečka</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Ma Košňar</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vojta Kraus</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ad Kratochvíl</td><td class=bc>-</td><td class=bl>Zu Stařecká</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=blW>Ka Stařecká</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Pa Goby</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Vo Goby</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Zu Stařecká</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Vojta Kraus</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ad Kratochvíl</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pe Klazar</td><td class=bc>-</td><td class=bl>Pa Goby</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ra Hrnčíř</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ma Košňar</td><td class=bc>-</td><td class=bl>Zu Stařecká</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Vo Goby</td><td class=bc>-</td><td class=bl>Ka Stařecká</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Pa Pohořalý</td><td class=bc>-</td><td class=bl>Ji Písečka</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Vojta Kraus</td><td class=bc>-</td><td class=bl>Pa Goby</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ad Kratochvíl</td><td class=bc>-</td><td class=blW>Ra Hrnčíř</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Pe Klazar</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
