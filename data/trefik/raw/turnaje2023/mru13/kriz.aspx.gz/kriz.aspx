<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR U13</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span><a href="../mru13">MR U13, 28. květen 2023</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<p class=v>Group U13</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1927&x=-395&p=Vo%20Kraus">Vo Kraus</a></td><td class=ic>CZE</td><td class=kx>*</td>
<td class=kW>5:3 + 4:0</td>
<td class=kL>1:2 + 6:2</td>
<td class=kW>6:1 + 5:1</td>
<td class=br>27:9</td><td class=br>+18</td>
<td class=bc>5 - 0 - 1</td>
<td class=br><strong>10</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=2018&x=-395&p=Ja%20Janou%C5%A1kovec">Ja Janouškovec</a></td><td class=ic>CZE</td><td class=kL>3:5 + 0:4</td>
<td class=kx>*</td>
<td class=kW>9:1 + 6:5</td>
<td class=kW>7:1 + 7:1</td>
<td class=br>32:17</td><td class=br>+15</td>
<td class=bc>4 - 0 - 2</td>
<td class=br><strong>8</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1968&x=-395&p=Mi%20Tou%C5%A1">Mi Touš</a></td><td class=ic>CZE</td><td class=kW>2:1 + 2:6</td>
<td class=kL>1:9 + 5:6</td>
<td class=kx>*</td>
<td class=kW>10:1 + 5:1</td>
<td class=br>25:24</td><td class=br>+1</td>
<td class=bc>3 - 0 - 3</td>
<td class=br><strong>6</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt><a href="../../../thstats/overview_b.aspx?idpl=1986&x=-395&p=Ad%20Medvecov%C3%A1">Ad Medvecová</a></td><td class=ic>CZE</td><td class=kL>1:6 + 1:5</td>
<td class=kL>1:7 + 1:7</td>
<td class=kL>1:10 + 1:5</td>
<td class=kx>*</td>
<td class=br>6:40</td><td class=br>-34</td>
<td class=bc>0 - 0 - 6</td>
<td class=br><strong>0</strong></td><td class=d>4.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ja Janouškovec</td><td class=bc>-</td><td class=bl>Mi Touš</td><td class=bc>9 : 1 + 6 : 5</tr></td>
<tr><td class=brW>Vo Kraus</td><td class=bc>-</td><td class=bl>Ad Medvecová</td><td class=bc>6 : 1 + 5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ja Janouškovec</td><td class=bc>-</td><td class=blW>Vo Kraus</td><td class=bc>3 : 5 + 0 : 4</tr></td>
<tr><td class=brW>Mi Touš</td><td class=bc>-</td><td class=bl>Ad Medvecová</td><td class=bc>10 : 1 + 5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Vo Kraus</td><td class=bc>-</td><td class=blW>Mi Touš</td><td class=bc>1 : 2 + 6 : 2</tr></td>
<tr><td class=br>Ad Medvecová</td><td class=bc>-</td><td class=blW>Ja Janouškovec</td><td class=bc>1 : 7 + 1 : 7</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
