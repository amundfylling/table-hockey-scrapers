<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>MR junioři</title><link rel="StyleSheet" href="../css.css" type="text/css"><link rel="StyleSheet" href="../xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="https://www.stolni-hokej.cz/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="../data/pohar.aspx">pohár</a>
&nbsp;<a href="../data/poharjun.aspx">J</a>
&nbsp;<a href="../data/poharzeny.aspx">Ž</a>
&nbsp;<a href="../data/poharvet.aspx">V</a>
&nbsp;<a href="../data/novacci.aspx">N</a>
&nbsp;&nbsp;&nbsp;<a href="../data/computer.aspx">computer</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/repr.aspx">repre</a>&nbsp;
<a href="../data/reprJ.aspx">J</a>&nbsp;
<a href="../data/reprZ.aspx">Ž</a>&nbsp;
<a href="../data/reprV.aspx">V</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/poh_utok.aspx">g+</a>&nbsp;
<a href="../data/poh_obr.aspx">g-</a>&nbsp;
<a href="../data/nuly.aspx">G0</a>&nbsp;
&nbsp;
&nbsp;
<a href="../data/kluby.aspx">kluby</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet.aspx">EET</a>&nbsp;
<a href="../data/krize1.aspx">X-EET</a>&nbsp;
<a href="../data/klubove_eet.aspx">K-EET</a>&nbsp;
<a href="../data/serie.aspx">WR-EET</a>&nbsp;

&nbsp;
&nbsp;

<a href="../data/eet_group_101.aspx">A-EET</a>&nbsp;
<a href="../data/eet_group_103.aspx">B-EET</a>&nbsp;
<a href="../data/eet_group_105.aspx">C-EET</a>&nbsp;


&nbsp;&nbsp;&nbsp;<a href="https://www.stolni-hokej.cz/pohar.html">sezóna</a>
&nbsp;
<a href="../data/cc_hist.aspx">historie</a>

</li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>MR junioři, 28. květen 2023</span></h2></div></div></div></div><p><div align="center">
<div align=center>
<a href="kriz.aspx">Zápasy ve skupinách (Basic and placement groups)</a><br>
<a href="MR_juniori_playoff.aspx ">Zápasy o umístění (Placement matches)</a><br>
<a href="utokturnaje.aspx">Tabulka útočníků (Best forwards)</a><br>
<a href="obranaturnaje.aspx">Tabulka obránců (Best defenders)</a><br>
</div>
<table border=0 cellpadding=2 cellspacing=0 class="rnk">
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">M</th>
<th align="center">+</th>
<th align="center">=</th>
<th align="center">-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1876&x=-394&p=Adam%20Kop%C5%99iva">Adam Kopřiva</a></td>
<td class=al>BSE United</td>
<td class=ar>14</td>
<td class=ar>12</td>
<td class=ar>1</td>
<td class=ar>1</td>
<td class=ar>52</td>
<td class=al>&nbsp;:&nbsp;14</td>
</tr><tr><td class=br>2.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1641&x=-394&p=Maty%C3%A1%C5%A1%20Klazar">Matyáš Klazar</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>14</td>
<td class=br>8</td>
<td class=br>3</td>
<td class=br>3</td>
<td class=br>39</td>
<td class=bl>&nbsp;:&nbsp;19</td>
</tr><tr><td class=ar>3.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1927&x=-394&p=Vojt%C4%9Bch%20Kraus">Vojtěch Kraus</a></td>
<td class=al>Rokycany</td>
<td class=ar>16</td>
<td class=ar>8</td>
<td class=ar>0</td>
<td class=ar>8</td>
<td class=ar>33</td>
<td class=al>&nbsp;:&nbsp;29</td>
</tr><tr><td class=br>4.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1968&x=-394&p=Michal%20Tou%C5%A1">Michal Touš</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>16</td>
<td class=br>7</td>
<td class=br>2</td>
<td class=br>7</td>
<td class=br>39</td>
<td class=bl>&nbsp;:&nbsp;35</td>
</tr><tr><td class=ar>5.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1657&x=-394&p=Jon%C3%A1%C5%A1%20Perkner">Jonáš Perkner</a></td>
<td class=al>Big Band</td>
<td class=ar>8</td>
<td class=ar>4</td>
<td class=ar>1</td>
<td class=ar>3</td>
<td class=ar>23</td>
<td class=al>&nbsp;:&nbsp;24</td>
</tr><tr><td class=br>6.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=2018&x=-394&p=Jan%20Janou%C5%A1kovec">Jan Janouškovec</a></td>
<td class=bl>Gladiators Plzeň</td>
<td class=br>8</td>
<td class=br>4</td>
<td class=br>0</td>
<td class=br>4</td>
<td class=br>23</td>
<td class=bl>&nbsp;:&nbsp;22</td>
</tr><tr><td class=ar>7.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=1947&x=-394&p=Luk%C3%A1%C5%A1%20Holub">Lukáš Holub</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>8</td>
<td class=ar>2</td>
<td class=ar>0</td>
<td class=ar>6</td>
<td class=ar>12</td>
<td class=al>&nbsp;:&nbsp;26</td>
</tr><tr><td class=br>8.</td>
<td class=bl><a href="../../../thstats/overview_b.aspx?idpl=1999&x=-394&p=Filip%20Pano%C5%A1">Filip Panoš</a></td>
<td class=bl>Pelhřimov</td>
<td class=br>8</td>
<td class=br>0</td>
<td class=br>2</td>
<td class=br>6</td>
<td class=br>6</td>
<td class=bl>&nbsp;:&nbsp;30</td>
</tr><tr><td class=ar>9.</td>
<td class=al><a href="../../../thstats/overview_b.aspx?idpl=2029&x=-394&p=Ond%C5%99ej%20Gruncl">Ondřej Gruncl</a></td>
<td class=al>SHC Cheb</td>
<td class=ar>8</td>
<td class=ar>0</td>
<td class=ar>1</td>
<td class=ar>7</td>
<td class=ar>7</td>
<td class=al>&nbsp;:&nbsp;35</td>
</tr></table></td></tr></table></div></p>
</div></p>
<div class="pata"><br><a href="https://www.trefik.cz" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
