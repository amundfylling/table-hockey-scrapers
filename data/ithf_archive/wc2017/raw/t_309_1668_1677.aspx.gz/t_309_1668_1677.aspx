<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Team Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Team Open : Estonia &nbsp;&nbsp;vs.&nbsp;&nbsp;Switzerland &nbsp;&nbsp;19:3</span></h2></div></div></div></div><h3 align="right">Round: 3&nbsp;&nbsp;</h3>
<p><div align="center">
<table border=1 cellpadding="0" cellspacing="0" ><tr>
<table border="0" cellpadding="1" cellspacing="0" width="95%"><tr><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Maria Saveljeva<br>3-0-0 (15:6)</td></tr>
<tr><td class="k">Igor Saveljev<br>3-0-0 (15:8)</td></tr>
<tr><td class="k">Jevgeni Lvov<br>2-0-1 (14:7)</td></tr>
<tr><td class="k">Yuri Artamonov<br>4-1-0 (19:6)</td></tr>
<tr><td class="k">Alen Shekarev<br>4-0-1 (19:8)</td></tr>
<tr><td class="k">Mark-Julius Pikat<br>1-1-0 (8:7)</td></tr>
<tr><td class="k">Aleksandr Metelitsa<br>1-0-1 (9:5)</td></tr>
<tr><td class="k">Vafa Hamdamov<br>1-1-0 (8:3)</td></tr>
</table></td>
<td valign="top"><table border="0" cellspacing="0" cellpadding="0" width="100%"><tr><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 1</td></tr>
<tr><td class="hrac_sk_v">Maria Saveljeva</td><td class="vysledek" width="60">&nbsp; 7 : 4 &nbsp;</td><td class="hrac_sk">Jean-Claude Klaus</td></tr>
<tr><td class="hrac_sk_v">Igor Saveljev</td><td class="vysledek" width="60">&nbsp; 5 : 3 &nbsp;</td><td class="hrac_sk">Rolf Locher</td></tr>
<tr><td class="hrac_sk_v">Jevgeni Lvov</td><td class="vysledek" width="60">&nbsp; 5 : 2 &nbsp;</td><td class="hrac_sk">Ramon Klaus</td></tr>
<tr><td class="hrac_sk_v">Yuri Artamonov</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">Olli Majaniemi</td></tr>
<tr><td class="hrac_sk_v">Alen Shekarev</td><td class="vysledek" width="60">&nbsp; 5 : 0 &nbsp;</td><td class="hrac_sk">Beat Luginbühl</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;5:0</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 2</td></tr>
<tr><td class="hrac_sk">Alen Shekarev</td><td class="vysledek" width="60">&nbsp; 2 : 3 &nbsp;</td><td class="hrac_sk_v">Rolf Locher</td></tr>
<tr><td class="hrac_sk_v">Maria Saveljeva</td><td class="vysledek" width="60">&nbsp; 3 : 2 &nbsp;</td><td class="hrac_sk">Ramon Klaus</td></tr>
<tr><td class="hrac_sk_v">Igor Saveljev</td><td class="vysledek" width="60">&nbsp; 5 : 2 &nbsp;</td><td class="hrac_sk">Olli Majaniemi</td></tr>
<tr><td class="hrac_sk_v">Jevgeni Lvov</td><td class="vysledek" width="60">&nbsp; 5 : 0 &nbsp;</td><td class="hrac_sk">Beat Luginbühl</td></tr>
<tr><td class="hrac_sk">Yuri Artamonov</td><td class="vysledek" width="60">&nbsp; 2 : 2 &nbsp;</td><td class="hrac_sk">Jean-Claude Klaus</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;8:1</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td>
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 3</td></tr>
<tr><td class="hrac_sk_v">Yuri Artamonov</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">Ramon Klaus</td></tr>
<tr><td class="hrac_sk_v">Alen Shekarev</td><td class="vysledek" width="60">&nbsp; 5 : 1 &nbsp;</td><td class="hrac_sk">Olli Majaniemi</td></tr>
<tr><td class="hrac_sk_v">Maria Saveljeva</td><td class="vysledek" width="60">&nbsp; 5 : 0 &nbsp;</td><td class="hrac_sk">Beat Luginbühl</td></tr>
<tr><td class="hrac_sk_v">Igor Saveljev</td><td class="vysledek" width="60">&nbsp; 5 : 3 &nbsp;</td><td class="hrac_sk">Jean-Claude Klaus</td></tr>
<tr><td class="hrac_sk">Jevgeni Lvov</td><td class="vysledek" width="60">&nbsp; 4 : 5 &nbsp;</td><td class="hrac_sk_v">Rolf Locher</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;12:2</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 4</td></tr>
<tr><td class="hrac_sk_v">Mark-Julius Pikat</td><td class="vysledek" width="60">&nbsp; 4 : 3 &nbsp;</td><td class="hrac_sk">Olli Majaniemi</td></tr>
<tr><td class="hrac_sk_v">Yuri Artamonov</td><td class="vysledek" width="60">&nbsp; 5 : 0 &nbsp;</td><td class="hrac_sk">Beat Luginbühl</td></tr>
<tr><td class="hrac_sk_v">Alen Shekarev</td><td class="vysledek" width="60">&nbsp; 4 : 2 &nbsp;</td><td class="hrac_sk">Jean-Claude Klaus</td></tr>
<tr><td class="hrac_sk">Aleksandr Metelitsa</td><td class="vysledek" width="60">&nbsp; 2 : 4 &nbsp;</td><td class="hrac_sk_v">Rolf Locher</td></tr>
<tr><td class="hrac_sk">Vafa Hamdamov</td><td class="vysledek" width="60">&nbsp; 3 : 3 &nbsp;</td><td class="hrac_sk">Ramon Klaus</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;15:3</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td align="center" colspan="3">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 5</td></tr>
<tr><td class="hrac_sk_v">Vafa Hamdamov</td><td class="vysledek" width="60">&nbsp; 5 : 0 &nbsp;</td><td class="hrac_sk">Beat Luginbühl</td></tr>
<tr><td class="hrac_sk">Mark-Julius Pikat</td><td class="vysledek" width="60">&nbsp; 4 : 4 &nbsp;</td><td class="hrac_sk">Jean-Claude Klaus</td></tr>
<tr><td class="hrac_sk_v">Yuri Artamonov</td><td class="vysledek" width="60">&nbsp; 4 : 2 &nbsp;</td><td class="hrac_sk">Rolf Locher</td></tr>
<tr><td class="hrac_sk_v">Alen Shekarev</td><td class="vysledek" width="60">&nbsp; 3 : 2 &nbsp;</td><td class="hrac_sk">Ramon Klaus</td></tr>
<tr><td class="hrac_sk_v">Aleksandr Metelitsa</td><td class="vysledek" width="60">&nbsp; 7 : 1 &nbsp;</td><td class="hrac_sk">Olli Majaniemi</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;19:3</td></tr></table>
</td></tr></table></td><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Jean-Claude Klaus<br>0-2-3 (15:22)</td></tr>
<tr><td class="k">Rolf Locher<br>3-0-2 (17:17)</td></tr>
<tr><td class="k">Ramon Klaus<br>0-1-4 (10:18)</td></tr>
<tr><td class="k">Olli Majaniemi<br>0-0-5 (8:25)</td></tr>
<tr><td class="k">Beat Luginbühl<br>0-0-5 (0:25)</td></tr>
</table></td></tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
