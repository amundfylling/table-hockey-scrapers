<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Team Veterans</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Team Veterans Results</span></h2></div></div></div></div><h3 align="right">Final Groups&nbsp;&nbsp;</h3>
<p><div align="center">
<div align=center><a href="Team_Veterans_krizB.aspx#basic">Basic Groups</a><br>
<p class=v>Group VTA1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Czech Republic V</td><td class=kx>*</td>
<td class=kW><a href="t_312_1690_1698.aspx">4:3</a></td>
<td class=kW><a href="t_312_1689_1690.aspx">5:1</a></td>
<td class=kW><a href="t_312_1690_1692.aspx">7:1 K</a></td>
<td class=br>16:5</td><td class=br>+11</td>
<td class=bc>3 - 0 - 0</td>
<td class=br><strong>6</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Russia V</td><td class=kL><a href="t_312_1690_1698.aspx">3:4</a></td>
<td class=kx>*</td>
<td class=kW><a href="t_312_1689_1698.aspx">5:1 K</a></td>
<td class=kW><a href="t_312_1692_1698.aspx">7:2</a></td>
<td class=br>15:7</td><td class=br>+8</td>
<td class=bc>2 - 0 - 1</td>
<td class=br><strong>4</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Croatia V</td><td class=kL><a href="t_312_1689_1690.aspx">1:5</a></td>
<td class=kL><a href="t_312_1689_1698.aspx">1:5 K</a></td>
<td class=kx>*</td>
<td class=kW><a href="t_312_1689_1692.aspx">5:3</a></td>
<td class=br>7:13</td><td class=br>-6</td>
<td class=bc>1 - 0 - 2</td>
<td class=br><strong>2</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Finland V</td><td class=kL><a href="t_312_1690_1692.aspx">1:7 K</a></td>
<td class=kL><a href="t_312_1692_1698.aspx">2:7</a></td>
<td class=kL><a href="t_312_1689_1692.aspx">3:5</a></td>
<td class=kx>*</td>
<td class=br>6:19</td><td class=br>-13</td>
<td class=bc>0 - 0 - 3</td>
<td class=br><strong>0</strong></td><td class=d>4.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Russia V</td><td class=bc>-</td><td class=blW>Czech Republic V</td><td class=bc><a href="t_312_1690_1698.aspx">3 : 4</a></tr></td>
<tr><td class=brW>Croatia V</td><td class=bc>-</td><td class=bl>Finland V</td><td class=bc><a href="t_312_1689_1692.aspx">5 : 3</a></tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Finland V</td><td class=bc>-</td><td class=blW>Russia V</td><td class=bc><a href="t_312_1692_1698.aspx">2 : 7</a></tr></td>
<tr><td class=brW>Czech Republic V</td><td class=bc>-</td><td class=bl>Croatia V</td><td class=bc><a href="t_312_1689_1690.aspx">5 : 1</a></tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group VTA2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Latvia V</td><td class=kx>*</td>
<td class=kW><a href="t_312_1695_1700.aspx">4:2</a></td>
<td class=kW><a href="t_312_1695_1697.aspx">4:3 K</a></td>
<td class=kL><a href="t_312_1691_1695.aspx">3:5</a></td>
<td class=br>11:10</td><td class=br>+1</td>
<td class=bc>2 - 0 - 1</td>
<td class=br><strong>4</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Sweden V</td><td class=kL><a href="t_312_1695_1700.aspx">2:4</a></td>
<td class=kx>*</td>
<td class=kW><a href="t_312_1697_1700.aspx">6:2</a></td>
<td class=kW><a href="t_312_1691_1700.aspx">5:2 K</a></td>
<td class=br>13:8</td><td class=br>+5</td>
<td class=bc>2 - 0 - 1</td>
<td class=br><strong>4</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Norway V</td><td class=kL><a href="t_312_1695_1697.aspx">3:4 K</a></td>
<td class=kL><a href="t_312_1697_1700.aspx">2:6</a></td>
<td class=kx>*</td>
<td class=kW><a href="t_312_1691_1697.aspx">5:4</a></td>
<td class=br>10:14</td><td class=br>-4</td>
<td class=bc>1 - 0 - 2</td>
<td class=br><strong>2</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Estonia V</td><td class=kW><a href="t_312_1691_1695.aspx">5:3</a></td>
<td class=kL><a href="t_312_1691_1700.aspx">2:5 K</a></td>
<td class=kL><a href="t_312_1691_1697.aspx">4:5</a></td>
<td class=kx>*</td>
<td class=br>11:13</td><td class=br>-2</td>
<td class=bc>1 - 0 - 2</td>
<td class=br><strong>2</strong></td><td class=d>4.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Sweden V</td><td class=bc>-</td><td class=blW>Latvia V</td><td class=bc><a href="t_312_1695_1700.aspx">2 : 4</a></tr></td>
<tr><td class=br>Estonia V</td><td class=bc>-</td><td class=blW>Norway V</td><td class=bc><a href="t_312_1691_1697.aspx">4 : 5</a></tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Norway V</td><td class=bc>-</td><td class=blW>Sweden V</td><td class=bc><a href="t_312_1697_1700.aspx">2 : 6</a></tr></td>
<tr><td class=br>Latvia V</td><td class=bc>-</td><td class=blW>Estonia V</td><td class=bc><a href="t_312_1691_1695.aspx">3 : 5</a></tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group VTB1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Germany V</td><td class=kx>*</td>
<td class=kW><a href="t_312_1693_1701.aspx">7:1</a></td>
<td class=kW><a href="t_312_1693_1696.aspx">5:2</a></td>
<td class=br>12:3</td><td class=br>+9</td>
<td class=bc>2 - 0 - 0</td>
<td class=br><strong>4</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Switzerland V</td><td class=kL><a href="t_312_1693_1701.aspx">1:7</a></td>
<td class=kx>*</td>
<td class=kW><a href="t_312_1696_1701.aspx">2:0 K</a></td>
<td class=br>3:7</td><td class=br>-4</td>
<td class=bc>1 - 0 - 1</td>
<td class=br><strong>2</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Lithuania V</td><td class=kL><a href="t_312_1693_1696.aspx">2:5</a></td>
<td class=kL><a href="t_312_1696_1701.aspx">0:2 K</a></td>
<td class=kx>*</td>
<td class=br>2:7</td><td class=br>-5</td>
<td class=bc>0 - 0 - 2</td>
<td class=br><strong>0</strong></td><td class=d>3.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Germany V</td><td class=bc>-</td><td class=bl>Switzerland V</td><td class=bc><a href="t_312_1693_1701.aspx">7 : 1</a></tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Lithuania V</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Lithuania V</td><td class=bc>-</td><td class=blW>Germany V</td><td class=bc><a href="t_312_1693_1696.aspx">2 : 5</a></tr></td>
<tr><td class=br>Switzerland V</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group VTB2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Ukraine V</td><td class=kx>*</td>
<td class=kW><a href="t_312_1699_1702.aspx">4:3</a></td>
<td class=kW><a href="t_312_1702_1853.aspx">6:0 K</a></td>
<td class=br>10:3</td><td class=br>+7</td>
<td class=bc>2 - 0 - 0</td>
<td class=br><strong>4</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Slovakia V</td><td class=kL><a href="t_312_1699_1702.aspx">3:4</a></td>
<td class=kx>*</td>
<td class=kW><a href="t_312_1699_1853.aspx">7:1</a></td>
<td class=br>10:5</td><td class=br>+5</td>
<td class=bc>1 - 0 - 1</td>
<td class=br><strong>2</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Belarus V</td><td class=kL><a href="t_312_1702_1853.aspx">0:6 K</a></td>
<td class=kL><a href="t_312_1699_1853.aspx">1:7</a></td>
<td class=kx>*</td>
<td class=br>1:13</td><td class=br>-12</td>
<td class=bc>0 - 0 - 2</td>
<td class=br><strong>0</strong></td><td class=d>3.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Slovakia V</td><td class=bc>-</td><td class=blW>Ukraine V</td><td class=bc><a href="t_312_1699_1702.aspx">3 : 4</a></tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=blW>Belarus V</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Belarus V</td><td class=bc>-</td><td class=blW>Slovakia V</td><td class=bc><a href="t_312_1699_1853.aspx">1 : 7</a></tr></td>
<tr><td class=br>Ukraine V</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</table></div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
