<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Ladies</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Ladies </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group LB</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Si Wikström</td><td class=ic>SWE</td><td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kW>2:1 K</td>
<td class=kW>4:1 K</td>
<td class=kW>8:5 K</td>
<td class=kT>2:2</td>
<td class=kW>7:1</td>
<td class=kW>3:1 K</td>
<td class=kW>2:0 K</td>
<td class=kW>5:2</td>
<td class=br>38:18</td><td class=br>+20</td>
<td class=bc>8 - 1 - 1</td>
<td class=br><strong>17</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>La Kamzola</td><td class=ic>LAT</td><td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>3:2 K</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=kW>4:1 K</td>
<td class=kW>5:1 K</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kW>7:1 K</td>
<td class=br>36:12</td><td class=br>+24</td>
<td class=bc>8 - 0 - 2</td>
<td class=br><strong>16</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Ma Miloradova</td><td class=ic>RUS</td><td class=kL>1:3</td>
<td class=kL>2:3 K</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>4:3 K</td>
<td class=kL>1:2 K</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>6:4 K</td>
<td class=br>29:19</td><td class=br>+10</td>
<td class=bc>7 - 0 - 3</td>
<td class=br><strong>14</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Ha Ivantsova</td><td class=ic>UKR</td><td class=kL>1:2 K</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>1:2 K</td>
<td class=kW>1:0 K</td>
<td class=kW>4:1</td>
<td class=kW>8:4</td>
<td class=kW>4:0 K</td>
<td class=kW>6:1 K</td>
<td class=kW>3:0</td>
<td class=br>31:14</td><td class=br>+17</td>
<td class=bc>7 - 0 - 3</td>
<td class=br><strong>14</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Li Österman</td><td class=ic>SWE</td><td class=kL>1:4 K</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kW>2:1 K</td>
<td class=kx>*</td>
<td class=kW>3:2 K</td>
<td class=kW>3:1</td>
<td class=kL>3:5</td>
<td class=kW>4:2 K</td>
<td class=kW>2:1 K</td>
<td class=kW>4:3</td>
<td class=br>22:28</td><td class=br>-6</td>
<td class=bc>6 - 0 - 4</td>
<td class=br><strong>12</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Iv Mašková</td><td class=ic>CZE</td><td class=kL>5:8 K</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kL>0:1 K</td>
<td class=kL>2:3 K</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kW>3:0 K</td>
<td class=kW>5:1 K</td>
<td class=kW>6:1</td>
<td class=br>31:26</td><td class=br>+5</td>
<td class=bc>5 - 0 - 5</td>
<td class=br><strong>10</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Vl Gobyová</td><td class=ic>CZE</td><td class=kT>2:2</td>
<td class=kL>1:4 K</td>
<td class=kL>3:4 K</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>6:0 K</td>
<td class=kL>1:2</td>
<td class=kW>7:2</td>
<td class=kW>4:3 K</td>
<td class=br>30:27</td><td class=br>+3</td>
<td class=bc>4 - 1 - 5</td>
<td class=br><strong>9</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>An Gripp</td><td class=ic>GER</td><td class=kL>1:7</td>
<td class=kL>1:5 K</td>
<td class=kW>2:1 K</td>
<td class=kL>4:8</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kL>0:6 K</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>3:2 K</td>
<td class=br>25:40</td><td class=br>-15</td>
<td class=bc>4 - 0 - 6</td>
<td class=br><strong>8</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Ha Marešová</td><td class=ic>CZE</td><td class=kL>1:3 K</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>0:4 K</td>
<td class=kL>2:4 K</td>
<td class=kL>0:3 K</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>2:0 K</td>
<td class=kL>2:3</td>
<td class=br>13:23</td><td class=br>-10</td>
<td class=bc>3 - 0 - 7</td>
<td class=br><strong>6</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Id Gripp</td><td class=ic>GER</td><td class=kL>0:2 K</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>1:6 K</td>
<td class=kL>1:2 K</td>
<td class=kL>1:5 K</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kL>0:2 K</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>11:36</td><td class=br>-25</td>
<td class=bc>1 - 0 - 9</td>
<td class=br><strong>2</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Mi Horáková</td><td class=ic>CZE</td><td class=kL>2:5</td>
<td class=kL>1:7 K</td>
<td class=kL>4:6 K</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>3:4 K</td>
<td class=kL>2:3 K</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>20:43</td><td class=br>-23</td>
<td class=bc>1 - 0 - 9</td>
<td class=br><strong>2</strong></td><td class=d>11.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>La Kamzola</td><td class=bc>-</td><td class=bl>Id Gripp</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Si Wikström</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ma Miloradova</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Li Österman</td><td class=bc>-</td><td class=blW>An Gripp</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Id Gripp</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>La Kamzola</td><td class=bc>-</td><td class=bl>Ha Marešová</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Si Wikström</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ma Miloradova</td><td class=bc>-</td><td class=bl>Iv Mašková</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ha Ivantsova</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Li Österman</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=blW>Ha Marešová</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Id Gripp</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>La Kamzola</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Si Wikström</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ma Miloradova</td><td class=bc>-</td><td class=bl>Li Österman</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ha Marešová</td><td class=bc>-</td><td class=blW>Mi Horáková</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Id Gripp</td><td class=bc>-</td><td class=blW>An Gripp</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>La Kamzola</td><td class=bc>-</td><td class=bl>Li Österman</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Si Wikström</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Miloradova</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Iv Mašková</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ha Marešová</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Li Österman</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Id Gripp</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>La Kamzola</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Si Wikström</td><td class=bc>-</td><td class=bl>Ma Miloradova</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Iv Mašková</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Li Österman</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ha Marešová</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Id Gripp</td><td class=bc>-</td><td class=blW>Ma Miloradova</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>La Kamzola</td><td class=bc>-</td><td class=bl>Si Wikström</td><td class=bc>4 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
