<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>50+</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>50+ </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 50+ 3</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Pe Turoň</td><td class=ic>CZE</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kW>9:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>9:0</td>
<td class=br>52:17</td><td class=br>+35</td>
<td class=bc>9 - 1 - 1</td>
<td class=br><strong>19</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Pa Plešák</td><td class=ic>CZE</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kT>3:3</td>
<td class=kT>5:5</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kW>9:1</td>
<td class=kW>6:1</td>
<td class=kW>9:0</td>
<td class=kW>7:1</td>
<td class=br>61:24</td><td class=br>+37</td>
<td class=bc>7 - 4 - 0</td>
<td class=br><strong>18</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Vi Skorobogatov</td><td class=ic>RUS</td><td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>9:0</td>
<td class=kW>5:2</td>
<td class=kW>5:4</td>
<td class=kW>6:0</td>
<td class=kW>7:1</td>
<td class=kW>8:0</td>
<td class=br>60:18</td><td class=br>+42</td>
<td class=bc>9 - 0 - 2</td>
<td class=br><strong>18</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Zd Matoušek st.</td><td class=ic>CZE</td><td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=br>37:24</td><td class=br>+13</td>
<td class=bc>7 - 2 - 2</td>
<td class=br><strong>16</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt>Eg Belševics</td><td class=ic>LAT</td><td class=kL>1:3</td>
<td class=kT>5:5</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>7:4</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>8:0</td>
<td class=br>42:29</td><td class=br>+13</td>
<td class=bc>6 - 2 - 3</td>
<td class=br><strong>14</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt>Mi Ševr</td><td class=ic>CZE</td><td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kL>0:6</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>6:5</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>9:0</td>
<td class=br>45:31</td><td class=br>+14</td>
<td class=bc>5 - 2 - 4</td>
<td class=br><strong>12</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Št Ivan</td><td class=ic>SVK</td><td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>0:9</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=br>23:33</td><td class=br>-10</td>
<td class=bc>5 - 0 - 6</td>
<td class=br><strong>10</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Ke Rafferty</td><td class=ic>USA</td><td class=kW>4:2</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>4:7</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=br>35:33</td><td class=br>+2</td>
<td class=bc>5 - 0 - 6</td>
<td class=br><strong>10</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>C</td><td class=d>9.</td><td class=kt>An Kniaziuk</td><td class=ic>BLR</td><td class=kL>1:9</td>
<td class=kL>1:9</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>5:6</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>8:2</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=br>38:47</td><td class=br>-9</td>
<td class=bc>4 - 0 - 7</td>
<td class=br><strong>8</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>C</td><td class=d>10.</td><td class=kt>Mi Mareš st.</td><td class=ic>CZE</td><td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>2:8</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=br>16:39</td><td class=br>-23</td>
<td class=bc>2 - 1 - 8</td>
<td class=br><strong>5</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>Gy Regula</td><td class=ic>HUN</td><td class=kL>0:5</td>
<td class=kL>0:9</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>6:50</td><td class=br>-44</td>
<td class=bc>1 - 0 - 10</td>
<td class=br><strong>2</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ro Milovanovič</td><td class=ic>SRB</td><td class=kL>0:9</td>
<td class=kL>1:7</td>
<td class=kL>0:8</td>
<td class=kL>0:7</td>
<td class=kL>0:8</td>
<td class=kL>0:9</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>4:74</td><td class=br>-70</td>
<td class=bc>0 - 0 - 11</td>
<td class=br><strong>0</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Eg Belševics</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Št Ivan</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>Vi Skorobogatov</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Mi Mareš st.</td><td class=bc>-</td><td class=bl>Gy Regula</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ro Milovanovič</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Eg Belševics</td><td class=bc>-</td><td class=blW>Vi Skorobogatov</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Št Ivan</td><td class=bc>-</td><td class=bl>Gy Regula</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>Ke Rafferty</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Ro Milovanovič</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Vi Skorobogatov</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Gy Regula</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Eg Belševics</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Št Ivan</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>An Kniaziuk</td><td class=bc>-</td><td class=bl>Ro Milovanovič</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Vi Skorobogatov</td><td class=bc>-</td><td class=bl>Gy Regula</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pe Turoň</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Eg Belševics</td><td class=bc>-</td><td class=bl>Ro Milovanovič</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Št Ivan</td><td class=bc>-</td><td class=blW>Zd Matoušek st.</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>An Kniaziuk</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>8 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Gy Regula</td><td class=bc>-</td><td class=blW>Ke Rafferty</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vi Skorobogatov</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Mi Ševr</td><td class=bc>-</td><td class=bl>Ro Milovanovič</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Eg Belševics</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Št Ivan</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Gy Regula</td><td class=bc>-</td><td class=bl>Ro Milovanovič</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Vi Skorobogatov</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pe Turoň</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Eg Belševics</td><td class=bc>-</td><td class=bl>Št Ivan</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Zd Matoušek st.</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ke Rafferty</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Gy Regula</td><td class=bc>-</td><td class=blW>An Kniaziuk</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vi Skorobogatov</td><td class=bc>-</td><td class=bl>Št Ivan</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=blW>Eg Belševics</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pe Turoň</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ro Milovanovič</td><td class=bc>-</td><td class=blW>Mi Mareš st.</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Št Ivan</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gy Regula</td><td class=bc>-</td><td class=blW>Eg Belševics</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vi Skorobogatov</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Ševr</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ro Milovanovič</td><td class=bc>-</td><td class=blW>Št Ivan</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Eg Belševics</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ke Rafferty</td><td class=bc>-</td><td class=bl>Pe Turoň</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Gy Regula</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Vi Skorobogatov</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>Št Ivan</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Eg Belševics</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Milovanovič</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Vi Skorobogatov</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Gy Regula</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>An Kniaziuk</td><td class=bc>-</td><td class=bl>Eg Belševics</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Mi Ševr</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ro Milovanovič</td><td class=bc>-</td><td class=blW>Vi Skorobogatov</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Gy Regula</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Št Ivan</td><td class=bc>-</td><td class=blW>Pe Turoň</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>Mi Ševr</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>Vi Skorobogatov</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Zd Matoušek st.</td><td class=bc>-</td><td class=bl>Gy Regula</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ro Milovanovič</td><td class=bc>-</td><td class=blW>Ke Rafferty</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
