<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Team Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Team Open : Ukraine &nbsp;&nbsp;vs.&nbsp;&nbsp;Czech Republic &nbsp;&nbsp;8:12</span></h2></div></div></div></div><h3 align="right">Round: 1/2&nbsp;&nbsp;</h3>
<p><div align="center">
<table border=1 cellpadding="0" cellspacing="0" ><tr>
<table border="0" cellpadding="1" cellspacing="0" width="95%"><tr><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Oleksii Korabel<br>1-0-4 (15:24)</td></tr>
<tr><td class="k">Yevhen Levdansky<br>1-1-3 (9:15)</td></tr>
<tr><td class="k">Mykhaylo Spivakovskyy<br>0-0-2 (3:9)</td></tr>
<tr><td class="k">Evgeniy Matantsev<br>2-2-1 (11:10)</td></tr>
<tr><td class="k">Dmytro Litvinyuk<br>3-1-1 (12:6)</td></tr>
<tr><td class="k">Roman Ignatenko<br>1-1-1 (8:7)</td></tr>
</table></td>
<td valign="top"><table border="0" cellspacing="0" cellpadding="0" width="100%"><tr><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 1</td></tr>
<tr><td class="hrac_sk_v">Oleksii Korabel</td><td class="vysledek" width="60">&nbsp; 4 : 2 &nbsp;</td><td class="hrac_sk">Leoš Hvižď ml.</td></tr>
<tr><td class="hrac_sk">Yevhen Levdansky</td><td class="vysledek" width="60">&nbsp; 2 : 2 &nbsp;</td><td class="hrac_sk">Michal Hvižď</td></tr>
<tr><td class="hrac_sk">Mykhaylo Spivakovskyy</td><td class="vysledek" width="60">&nbsp; 1 : 2 &nbsp;</td><td class="hrac_sk_v">Zdeněk Matoušek ml.</td></tr>
<tr><td class="hrac_sk">Evgeniy Matantsev</td><td class="vysledek" width="60">&nbsp; 1 : 1 &nbsp;</td><td class="hrac_sk">Lukáš Turoň</td></tr>
<tr><td class="hrac_sk">Dmytro Litvinyuk</td><td class="vysledek" width="60">&nbsp; 0 : 1 &nbsp;</td><td class="hrac_sk_v">Patrik Petr</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;1:2</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 2</td></tr>
<tr><td class="hrac_sk_v">Dmytro Litvinyuk</td><td class="vysledek" width="60">&nbsp; 3 : 0 &nbsp;</td><td class="hrac_sk">Michal Hvižď</td></tr>
<tr><td class="hrac_sk">Oleksii Korabel</td><td class="vysledek" width="60">&nbsp; 3 : 6 &nbsp;</td><td class="hrac_sk_v">Zdeněk Matoušek ml.</td></tr>
<tr><td class="hrac_sk_v">Yevhen Levdansky</td><td class="vysledek" width="60">&nbsp; 5 : 1 &nbsp;</td><td class="hrac_sk">Lukáš Turoň</td></tr>
<tr><td class="hrac_sk">Mykhaylo Spivakovskyy</td><td class="vysledek" width="60">&nbsp; 2 : 7 &nbsp;</td><td class="hrac_sk_v">Patrik Petr</td></tr>
<tr><td class="hrac_sk">Evgeniy Matantsev</td><td class="vysledek" width="60">&nbsp; 2 : 3 &nbsp;</td><td class="hrac_sk_v">Leoš Hvižď ml.</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;3:5</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td>
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 3</td></tr>
<tr><td class="hrac_sk">Evgeniy Matantsev</td><td class="vysledek" width="60">&nbsp; 2 : 2 &nbsp;</td><td class="hrac_sk">Zdeněk Matoušek ml.</td></tr>
<tr><td class="hrac_sk_v">Dmytro Litvinyuk</td><td class="vysledek" width="60">&nbsp; 3 : 2 &nbsp;</td><td class="hrac_sk">Lukáš Turoň</td></tr>
<tr><td class="hrac_sk">Oleksii Korabel</td><td class="vysledek" width="60">&nbsp; 4 : 5 &nbsp;</td><td class="hrac_sk_v">Patrik Petr</td></tr>
<tr><td class="hrac_sk">Yevhen Levdansky</td><td class="vysledek" width="60">&nbsp; 1 : 4 &nbsp;</td><td class="hrac_sk_v">Leoš Hvižď ml.</td></tr>
<tr><td class="hrac_sk">Roman Ignatenko</td><td class="vysledek" width="60">&nbsp; 3 : 3 &nbsp;</td><td class="hrac_sk">Michal Hvižď</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;4:7</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 4</td></tr>
<tr><td class="hrac_sk_v">Roman Ignatenko</td><td class="vysledek" width="60">&nbsp; 3 : 1 &nbsp;</td><td class="hrac_sk">Lukáš Turoň</td></tr>
<tr><td class="hrac_sk_v">Evgeniy Matantsev</td><td class="vysledek" width="60">&nbsp; 3 : 2 &nbsp;</td><td class="hrac_sk">Patrik Petr</td></tr>
<tr><td class="hrac_sk_v">Dmytro Litvinyuk</td><td class="vysledek" width="60">&nbsp; 5 : 2 &nbsp;</td><td class="hrac_sk">Leoš Hvižď ml.</td></tr>
<tr><td class="hrac_sk">Oleksii Korabel</td><td class="vysledek" width="60">&nbsp; 4 : 5 &nbsp;</td><td class="hrac_sk_v">Michal Hvižď</td></tr>
<tr><td class="hrac_sk">Yevhen Levdansky</td><td class="vysledek" width="60">&nbsp; 1 : 3 &nbsp;</td><td class="hrac_sk_v">Zdeněk Matoušek ml.</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;7:9</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td align="center" colspan="3">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 5</td></tr>
<tr><td class="hrac_sk">Yevhen Levdansky</td><td class="vysledek" width="60">&nbsp; 0 : 5 &nbsp;</td><td class="hrac_sk_v">Patrik Petr</td></tr>
<tr><td class="hrac_sk">Roman Ignatenko</td><td class="vysledek" width="60">&nbsp; 2 : 3 &nbsp;</td><td class="hrac_sk_v">Leoš Hvižď ml.</td></tr>
<tr><td class="hrac_sk_v">Evgeniy Matantsev</td><td class="vysledek" width="60">&nbsp; 3 : 2 &nbsp;</td><td class="hrac_sk">Michal Hvižď</td></tr>
<tr><td class="hrac_sk">Dmytro Litvinyuk</td><td class="vysledek" width="60">&nbsp; 1 : 1 &nbsp;</td><td class="hrac_sk">Zdeněk Matoušek ml.</td></tr>
<tr><td class="hrac_sk">Oleksii Korabel</td><td class="vysledek" width="60">&nbsp; 0 : 6 &nbsp;</td><td class="hrac_sk_v">Lukáš Turoň</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;8:12</td></tr></table>
</td></tr></table></td><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Leoš Hvižď ml.<br>3-0-2 (14:14)</td></tr>
<tr><td class="k">Michal Hvižď<br>1-2-2 (12:15)</td></tr>
<tr><td class="k">Zdeněk Matoušek ml.<br>3-2-0 (14:8)</td></tr>
<tr><td class="k">Lukáš Turoň<br>1-1-3 (11:12)</td></tr>
<tr><td class="k">Patrik Petr<br>4-0-1 (20:9)</td></tr>
</table></td></tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
