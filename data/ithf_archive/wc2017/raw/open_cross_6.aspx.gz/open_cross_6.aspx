<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Open </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 6</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Al Zaharov</td><td class=ic>RUS</td><td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=kW>8:2</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=br>80:29</td><td class=br>+51</td>
<td class=bc>15 - 0 - 2</td>
<td class=br><strong>30</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ev Matantsev</td><td class=ic>UKR</td><td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>5:0</td>
<td class=kW>5:4</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kW>9:1</td>
<td class=kW>7:2</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>8:1</td>
<td class=kW>7:1</td>
<td class=kW>7:2</td>
<td class=kW>9:3</td>
<td class=kW>12:1</td>
<td class=br>92:32</td><td class=br>+60</td>
<td class=bc>13 - 1 - 3</td>
<td class=br><strong>27</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Je Zaharovs</td><td class=ic>LAT</td><td class=kW>5:3</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>11:1</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>8:3</td>
<td class=kW>10:0</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=br>75:38</td><td class=br>+37</td>
<td class=bc>12 - 3 - 2</td>
<td class=br><strong>27</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Lu Turoň</td><td class=ic>CZE</td><td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=kL>3:5</td>
<td class=kW>6:1</td>
<td class=kW>8:2</td>
<td class=kT>3:3</td>
<td class=kW>8:0</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kW>8:3</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>10:2</td>
<td class=br>84:31</td><td class=br>+53</td>
<td class=bc>12 - 1 - 4</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ed Mucenieks</td><td class=ic>LAT</td><td class=kL>3:6</td>
<td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kL>0:7</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>5:7</td>
<td class=kW>6:1</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>7:3</td>
<td class=kW>7:3</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>9:4</td>
<td class=kW>7:1</td>
<td class=kW>11:2</td>
<td class=br>86:51</td><td class=br>+35</td>
<td class=bc>12 - 1 - 4</td>
<td class=br><strong>25</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ar Stolyarov</td><td class=ic>RUS</td><td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>7:4</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=kW>6:4</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>8:0</td>
<td class=br>71:46</td><td class=br>+25</td>
<td class=bc>12 - 1 - 4</td>
<td class=br><strong>25</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ti Valachovič</td><td class=ic>SVK</td><td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=kW>7:5</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>5:7</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kT>5:5</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>10:1</td>
<td class=br>79:53</td><td class=br>+26</td>
<td class=bc>11 - 2 - 4</td>
<td class=br><strong>24</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>My Shalomayev</td><td class=ic>UKR</td><td class=kL>3:4</td>
<td class=kL>1:9</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=br>54:54</td><td class=br>0</td>
<td class=bc>8 - 3 - 6</td>
<td class=br><strong>19</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ju Rautio</td><td class=ic>FIN</td><td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kL>2:8</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>7:5</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=br>55:56</td><td class=br>-1</td>
<td class=bc>8 - 2 - 7</td>
<td class=br><strong>18</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Fi Hansson</td><td class=ic>SWE</td><td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kW>2:0</td>
<td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=br>39:45</td><td class=br>-6</td>
<td class=bc>8 - 2 - 7</td>
<td class=br><strong>18</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>An Engel</td><td class=ic>DEN</td><td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>1:11</td>
<td class=kL>0:8</td>
<td class=kL>3:7</td>
<td class=kL>4:7</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kL>3:6</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kL>3:6</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=br>55:71</td><td class=br>-16</td>
<td class=bc>8 - 1 - 8</td>
<td class=br><strong>17</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ev Tsyupko</td><td class=ic>ISR</td><td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kT>5:5</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>8:1</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kL>3:5</td>
<td class=kW>6:0</td>
<td class=kW>5:3</td>
<td class=br>55:51</td><td class=br>+4</td>
<td class=bc>5 - 2 - 10</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>An Fjermestad</td><td class=ic>NOR</td><td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kL>4:5</td>
<td class=kL>1:8</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=br>46:62</td><td class=br>-16</td>
<td class=bc>6 - 0 - 11</td>
<td class=br><strong>12</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Al Lorand st.</td><td class=ic>SVK</td><td class=kL>1:7</td>
<td class=kL>1:8</td>
<td class=kL>3:8</td>
<td class=kL>3:8</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kW>6:3</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=br>42:77</td><td class=br>-35</td>
<td class=bc>4 - 1 - 12</td>
<td class=br><strong>9</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Be Skrlep</td><td class=ic>SLO</td><td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>0:10</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>4:6</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>9:2</td>
<td class=kW>4:3</td>
<td class=br>32:80</td><td class=br>-48</td>
<td class=bc>2 - 2 - 13</td>
<td class=br><strong>6</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Vl Voronov</td><td class=ic>LTU</td><td class=kL>2:8</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>4:9</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>0:2</td>
<td class=br>38:75</td><td class=br>-37</td>
<td class=bc>2 - 1 - 14</td>
<td class=br><strong>5</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Pa Petrik</td><td class=ic>LTU</td><td class=kL>0:7</td>
<td class=kL>3:9</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kL>2:9</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=br>25:91</td><td class=br>-66</td>
<td class=bc>2 - 0 - 15</td>
<td class=br><strong>4</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>E</td><td class=d>18.</td><td class=kt>Zy Remeika</td><td class=ic>LTU</td><td class=kL>1:5</td>
<td class=kL>1:12</td>
<td class=kL>1:2</td>
<td class=kL>2:10</td>
<td class=kL>2:11</td>
<td class=kL>0:8</td>
<td class=kL>1:10</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=br>28:94</td><td class=br>-66</td>
<td class=bc>1 - 1 - 15</td>
<td class=br><strong>3</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>An Engel</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>1 : 11</tr></td>
<tr><td class=br>Ev Tsyupko</td><td class=bc>-</td><td class=blW>Al Zaharov</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Fi Hansson</td><td class=bc>-</td><td class=blW>Ti Valachovič</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ed Mucenieks</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Pa Petrik</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Al Zaharov</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>An Engel</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ev Tsyupko</td><td class=bc>-</td><td class=bl>Ti Valachovič</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Fi Hansson</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Ed Mucenieks</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>11 : 2</tr></td>
<tr><td class=br>Pa Petrik</td><td class=bc>-</td><td class=blW>Ju Rautio</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Al Zaharov</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=blW>Ti Valachovič</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>An Engel</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ev Tsyupko</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Fi Hansson</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ed Mucenieks</td><td class=bc>-</td><td class=bl>Pa Petrik</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Ti Valachovič</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Al Zaharov</td><td class=bc>-</td><td class=bl>Lu Turoň</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Ar Stolyarov</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>An Engel</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ev Tsyupko</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Fi Hansson</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Pa Petrik</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ed Mucenieks</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ti Valachovič</td><td class=bc>-</td><td class=bl>Lu Turoň</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Al Zaharov</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>An Engel</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ev Tsyupko</td><td class=bc>-</td><td class=blW>Ju Rautio</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Pa Petrik</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Fi Hansson</td><td class=bc>-</td><td class=blW>Ed Mucenieks</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Ar Stolyarov</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ti Valachovič</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Al Zaharov</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>An Engel</td><td class=bc>-</td><td class=bl>Pa Petrik</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ev Tsyupko</td><td class=bc>-</td><td class=blW>Ed Mucenieks</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Fi Hansson</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ar Stolyarov</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ti Valachovič</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Ju Rautio</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Al Zaharov</td><td class=bc>-</td><td class=bl>Pa Petrik</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=bl>Ed Mucenieks</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>An Engel</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ev Tsyupko</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Fi Hansson</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ar Stolyarov</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Ti Valachovič</td><td class=bc>-</td><td class=bl>Pa Petrik</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Ed Mucenieks</td><td class=bc>4 : 9</tr></td>
<tr><td class=brW>Al Zaharov</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>An Engel</td><td class=bc>-</td><td class=bl>Fi Hansson</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ev Tsyupko</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>8 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=blW>Ju Rautio</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ar Stolyarov</td><td class=bc>-</td><td class=bl>Pa Petrik</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Ed Mucenieks</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ti Valachovič</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Al Lorand st.</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Al Zaharov</td><td class=bc>-</td><td class=bl>Fi Hansson</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>An Engel</td><td class=bc>-</td><td class=bl>Ev Tsyupko</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Pa Petrik</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ed Mucenieks</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ar Stolyarov</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Lu Turoň</td><td class=bc>-</td><td class=bl>Fi Hansson</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ti Valachovič</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Vl Voronov</td><td class=bc>-</td><td class=bl>Ev Tsyupko</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Al Zaharov</td><td class=bc>-</td><td class=bl>An Engel</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=blW>Ed Mucenieks</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 12</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=blW>Fi Hansson</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ar Stolyarov</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Ev Tsyupko</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ti Valachovič</td><td class=bc>-</td><td class=blW>An Engel</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Zaharov</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Pa Petrik</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>3 : 9</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Fi Hansson</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=blW>Ev Tsyupko</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ar Stolyarov</td><td class=bc>-</td><td class=bl>An Engel</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Lu Turoň</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ti Valachovič</td><td class=bc>-</td><td class=blW>Al Zaharov</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ed Mucenieks</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pa Petrik</td><td class=bc>-</td><td class=blW>Fi Hansson</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Ev Tsyupko</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>An Engel</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Ar Stolyarov</td><td class=bc>-</td><td class=bl>Al Zaharov</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ti Valachovič</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=blW>Fi Hansson</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ed Mucenieks</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pa Petrik</td><td class=bc>-</td><td class=blW>Ev Tsyupko</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>An Engel</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Al Zaharov</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ar Stolyarov</td><td class=bc>-</td><td class=bl>Ti Valachovič</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Lu Turoň</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ev Tsyupko</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ed Mucenieks</td><td class=bc>-</td><td class=bl>An Engel</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Pa Petrik</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=blW>Al Zaharov</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ti Valachovič</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ar Stolyarov</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Fi Hansson</td><td class=bc>-</td><td class=bl>Ev Tsyupko</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>An Engel</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ed Mucenieks</td><td class=bc>-</td><td class=blW>Al Zaharov</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Pa Petrik</td><td class=bc>-</td><td class=blW>Vl Voronov</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Ti Valachovič</td><td class=bc>7 : 5</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>2 : 10</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Ar Stolyarov</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>An Engel</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Fi Hansson</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Al Zaharov</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ed Mucenieks</td><td class=bc>-</td><td class=blW>Ti Valachovič</td><td class=bc>5 : 7</tr></td>
<tr><td class=br>Pa Petrik</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Be Skrlep</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ev Tsyupko</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Al Zaharov</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Fi Hansson</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Ti Valachovič</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Lu Turoň</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ed Mucenieks</td><td class=bc>-</td><td class=bl>Ar Stolyarov</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pa Petrik</td><td class=bc>-</td><td class=blW>Be Skrlep</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
