<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Veterans</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Veterans </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group V1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>St Lutay</td><td class=ic>RUS</td><td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>8:2</td>
<td class=kW>9:2</td>
<td class=kW>8:2</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=br>56:20</td><td class=br>+36</td>
<td class=bc>10 - 2 - 0</td>
<td class=br><strong>22</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ki Eriksson</td><td class=ic>FIN</td><td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>9:2</td>
<td class=br>41:22</td><td class=br>+19</td>
<td class=bc>7 - 3 - 2</td>
<td class=br><strong>17</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ig Masloboev</td><td class=ic>RUS</td><td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>8:0</td>
<td class=kW>8:2</td>
<td class=br>42:16</td><td class=br>+26</td>
<td class=bc>7 - 3 - 2</td>
<td class=br><strong>17</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Al Chernov</td><td class=ic>RUS</td><td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=br>33:17</td><td class=br>+16</td>
<td class=bc>4 - 8 - 0</td>
<td class=br><strong>16</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Al Titov</td><td class=ic>RUS</td><td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=br>35:26</td><td class=br>+9</td>
<td class=bc>6 - 3 - 3</td>
<td class=br><strong>15</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Si Thomas</td><td class=ic>IRL</td><td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=br>31:26</td><td class=br>+5</td>
<td class=bc>5 - 3 - 4</td>
<td class=br><strong>13</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Ri Sjöstedt</td><td class=ic>SWE</td><td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>8:2</td>
<td class=kW>8:1</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kL>4:5</td>
<td class=kW>5:0</td>
<td class=br>44:30</td><td class=br>+14</td>
<td class=bc>6 - 1 - 5</td>
<td class=br><strong>13</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Ka Hudec</td><td class=ic>SVK</td><td class=kL>2:8</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>2:8</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>9:1</td>
<td class=br>38:37</td><td class=br>+1</td>
<td class=bc>6 - 1 - 5</td>
<td class=br><strong>13</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ke Rafferty</td><td class=ic>USA</td><td class=kL>2:9</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>1:8</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kW>4:0</td>
<td class=kT>5:5</td>
<td class=br>28:50</td><td class=br>-22</td>
<td class=bc>2 - 4 - 6</td>
<td class=br><strong>8</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Th Haussknecht</td><td class=ic>GER</td><td class=kL>2:8</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=br>26:42</td><td class=br>-16</td>
<td class=bc>3 - 1 - 8</td>
<td class=br><strong>7</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>Ed Kuratnik</td><td class=ic>BLR</td><td class=kL>1:7</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>0:1</td>
<td class=br>21:40</td><td class=br>-19</td>
<td class=bc>2 - 2 - 8</td>
<td class=br><strong>6</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ma Curkovic</td><td class=ic>CRO</td><td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>0:8</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kW>5:2</td>
<td class=kW>5:4</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=br>27:56</td><td class=br>-29</td>
<td class=bc>2 - 1 - 9</td>
<td class=br><strong>5</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Si Vazhnik</td><td class=ic>BLR</td><td class=kL>2:5</td>
<td class=kL>2:9</td>
<td class=kL>2:8</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>1:9</td>
<td class=kT>5:5</td>
<td class=kL>1:6</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=br>24:64</td><td class=br>-40</td>
<td class=bc>1 - 2 - 9</td>
<td class=br><strong>4</strong></td><td class=d>13.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ma Curkovic</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ki Eriksson</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Ri Sjöstedt</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Al Chernov</td><td class=bc>-</td><td class=bl>Ig Masloboev</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Curkovic</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Ri Sjöstedt</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ki Eriksson</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Ig Masloboev</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>St Lutay</td><td class=bc>2 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Al Titov</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Ri Sjöstedt</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ma Curkovic</td><td class=bc>-</td><td class=blW>Ke Rafferty</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Ig Masloboev</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ki Eriksson</td><td class=bc>-</td><td class=blW>St Lutay</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Al Chernov</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ri Sjöstedt</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Titov</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Ig Masloboev</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Ma Curkovic</td><td class=bc>-</td><td class=blW>St Lutay</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=bl>Al Chernov</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ki Eriksson</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Ig Masloboev</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Al Titov</td><td class=bc>-</td><td class=blW>St Lutay</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Al Chernov</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ma Curkovic</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Th Haussknecht</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Ig Masloboev</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ri Sjöstedt</td><td class=bc>-</td><td class=blW>St Lutay</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=bl>Al Chernov</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al Titov</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Th Haussknecht</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ma Curkovic</td><td class=bc>-</td><td class=blW>Ki Eriksson</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ig Masloboev</td><td class=bc>-</td><td class=bl>St Lutay</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=bl>Al Chernov</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Al Titov</td><td class=bc>-</td><td class=bl>Ki Eriksson</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Si Vazhnik</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>St Lutay</td><td class=bc>-</td><td class=bl>Al Chernov</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ig Masloboev</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ke Rafferty</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ri Sjöstedt</td><td class=bc>-</td><td class=blW>Ki Eriksson</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Al Titov</td><td class=bc>-</td><td class=bl>Ma Curkovic</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Al Chernov</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>St Lutay</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ig Masloboev</td><td class=bc>-</td><td class=blW>Ki Eriksson</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Ed Kuratnik</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ri Sjöstedt</td><td class=bc>-</td><td class=blW>Ma Curkovic</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Al Chernov</td><td class=bc>-</td><td class=bl>Ki Eriksson</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>St Lutay</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ig Masloboev</td><td class=bc>-</td><td class=bl>Ma Curkovic</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Al Titov</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=bl>Ki Eriksson</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Al Chernov</td><td class=bc>-</td><td class=bl>Ma Curkovic</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>St Lutay</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ig Masloboev</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ki Eriksson</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Th Haussknecht</td><td class=bc>-</td><td class=bl>Ma Curkovic</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Al Chernov</td><td class=bc>-</td><td class=bl>Al Titov</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>St Lutay</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ig Masloboev</td><td class=bc>-</td><td class=bl>Ri Sjöstedt</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ed Kuratnik</td><td class=bc>-</td><td class=bl>Ma Curkovic</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ki Eriksson</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Al Chernov</td><td class=bc>-</td><td class=bl>Ri Sjöstedt</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>St Lutay</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>9 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
