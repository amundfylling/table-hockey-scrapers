<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Veterans</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Veterans </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group VA2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Ja Dryák</td><td class=ic>CZE</td><td class=kx>*</td>
<td class=kW>3:0 K</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kL>2:4 K</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>5:2 K</td>
<td class=kW>7:3 K</td>
<td class=kW>3:2 K</td>
<td class=br>40:22</td><td class=br>+18</td>
<td class=bc>9 - 1 - 1</td>
<td class=br><strong>19</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Jo Lundin</td><td class=ic>SWE</td><td class=kL>0:3 K</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2 K</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2 K</td>
<td class=kW>4:3 K</td>
<td class=kW>4:2 K</td>
<td class=br>32:22</td><td class=br>+10</td>
<td class=bc>7 - 3 - 1</td>
<td class=br><strong>17</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>An Ekestubbe</td><td class=ic>SWE</td><td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3 K</td>
<td class=kT>1:1</td>
<td class=kW>4:1 K</td>
<td class=kW>2:1 K</td>
<td class=kW>7:3 K</td>
<td class=kT>2:2 K</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kL>2:7</td>
<td class=br>35:28</td><td class=br>+7</td>
<td class=bc>5 - 5 - 1</td>
<td class=br><strong>15</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Dm Petrov</td><td class=ic>RUS</td><td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kT>3:3 K</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>0:2 K</td>
<td class=kW>6:0 K</td>
<td class=kL>2:4 K</td>
<td class=kW>5:2 K</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=br>32:24</td><td class=br>+8</td>
<td class=bc>6 - 1 - 4</td>
<td class=br><strong>13</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Al Žernovojs</td><td class=ic>LAT</td><td class=kW>4:2 K</td>
<td class=kL>2:3 K</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>7:3 K</td>
<td class=kL>3:4 K</td>
<td class=kW>3:2 K</td>
<td class=br>31:28</td><td class=br>+3</td>
<td class=bc>5 - 2 - 4</td>
<td class=br><strong>12</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Ja Sahlgren</td><td class=ic>FIN</td><td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>1:4 K</td>
<td class=kW>2:0 K</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=kL>0:2 K</td>
<td class=kL>1:2 K</td>
<td class=kW>7:0</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=br>20:17</td><td class=br>+3</td>
<td class=bc>4 - 2 - 5</td>
<td class=br><strong>10</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Sa Kalninš</td><td class=ic>LAT</td><td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2 K</td>
<td class=kL>0:6 K</td>
<td class=kW>4:3</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=kW>6:2 K</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=br>23:28</td><td class=br>-5</td>
<td class=bc>2 - 5 - 4</td>
<td class=br><strong>9</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>My Shalomayev</td><td class=ic>UKR</td><td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>3:7 K</td>
<td class=kW>4:2 K</td>
<td class=kT>3:3</td>
<td class=kW>2:0 K</td>
<td class=kL>2:6 K</td>
<td class=kx>*</td>
<td class=kW>3:2 K</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=br>24:38</td><td class=br>-14</td>
<td class=bc>4 - 1 - 6</td>
<td class=br><strong>9</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Ig Saveljev</td><td class=ic>EST</td><td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2 K</td>
<td class=kL>2:5 K</td>
<td class=kL>1:3</td>
<td class=kW>2:1 K</td>
<td class=kT>2:2 K</td>
<td class=kL>2:3 K</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=br>20:23</td><td class=br>-3</td>
<td class=bc>3 - 2 - 6</td>
<td class=br><strong>8</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Kr Curkovic</td><td class=ic>CRO</td><td class=kL>2:5 K</td>
<td class=kL>2:4 K</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>3:7 K</td>
<td class=kL>0:7</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kW>4:0 K</td>
<td class=kW>5:2 K</td>
<td class=br>24:36</td><td class=br>-12</td>
<td class=bc>3 - 1 - 7</td>
<td class=br><strong>7</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Se Mihejevs</td><td class=ic>LAT</td><td class=kL>3:7 K</td>
<td class=kL>3:4 K</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>4:3 K</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kL>1:4</td>
<td class=kL>0:4 K</td>
<td class=kx>*</td>
<td class=kW>4:3 K</td>
<td class=br>21:35</td><td class=br>-14</td>
<td class=bc>3 - 1 - 7</td>
<td class=br><strong>7</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Pa Plešák</td><td class=ic>CZE</td><td class=kL>2:3 K</td>
<td class=kL>2:4 K</td>
<td class=kW>7:2</td>
<td class=kL>2:4</td>
<td class=kL>2:3 K</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kL>0:2</td>
<td class=kL>2:5 K</td>
<td class=kL>3:4 K</td>
<td class=kx>*</td>
<td class=br>30:31</td><td class=br>-1</td>
<td class=bc>3 - 0 - 8</td>
<td class=br><strong>6</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Ja Sahlgren</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Ekestubbe</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Jo Lundin</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Al Žernovojs</td><td class=bc>-</td><td class=blW>Sa Kalninš</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Kr Curkovic</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Jo Lundin</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Kr Curkovic</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Al Žernovojs</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Kr Curkovic</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Jo Lundin</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=bl>Al Žernovojs</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Kr Curkovic</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Ekestubbe</td><td class=bc>-</td><td class=bl>Al Žernovojs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Jo Lundin</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Kr Curkovic</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ja Sahlgren</td><td class=bc>-</td><td class=blW>Al Žernovojs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>An Ekestubbe</td><td class=bc>-</td><td class=bl>Jo Lundin</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=bl>Kr Curkovic</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Al Žernovojs</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Jo Lundin</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ja Dryák</td><td class=bc>-</td><td class=bl>An Ekestubbe</td><td class=bc>4 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
