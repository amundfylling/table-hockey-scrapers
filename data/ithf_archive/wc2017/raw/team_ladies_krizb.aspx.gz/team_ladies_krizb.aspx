<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Team Ladies</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Team Ladies Results</span></h2></div></div></div></div><h3 align="right">Basic Groups&nbsp;&nbsp;</h3>
<p><div align="center">
<p class=v>Group LT</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Russia L</td><td class=kx>*</td>
<td class=kW><a href="t_310_1705_1708.aspx">5:2</a></td>
<td class=kT><a href="t_310_1704_1705.aspx">4:4</a></td>
<td class=kW><a href="t_310_1705_1707.aspx">8:0</a></td>
<td class=kW><a href="t_310_1703_1705.aspx">9:0</a></td>
<td class=br>26:6</td><td class=br>+20</td>
<td class=bc>3 - 1 - 0</td>
<td class=br><strong>7</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ukraine L</td><td class=kL><a href="t_310_1705_1708.aspx">2:5</a></td>
<td class=kx>*</td>
<td class=kW><a href="t_310_1704_1708.aspx">5:2</a></td>
<td class=kW><a href="t_310_1707_1708.aspx">4:1</a></td>
<td class=kW><a href="t_310_1703_1708.aspx">6:1</a></td>
<td class=br>17:9</td><td class=br>+8</td>
<td class=bc>3 - 0 - 1</td>
<td class=br><strong>6</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Latvia L</td><td class=kT><a href="t_310_1704_1705.aspx">4:4</a></td>
<td class=kL><a href="t_310_1704_1708.aspx">2:5</a></td>
<td class=kx>*</td>
<td class=kW><a href="t_310_1704_1707.aspx">6:3</a></td>
<td class=kW><a href="t_310_1703_1704.aspx">9:0</a></td>
<td class=br>21:12</td><td class=br>+9</td>
<td class=bc>2 - 1 - 1</td>
<td class=br><strong>5</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Sweden L</td><td class=kL><a href="t_310_1705_1707.aspx">0:8</a></td>
<td class=kL><a href="t_310_1707_1708.aspx">1:4</a></td>
<td class=kL><a href="t_310_1704_1707.aspx">3:6</a></td>
<td class=kx>*</td>
<td class=kW><a href="t_310_1703_1707.aspx">6:1</a></td>
<td class=br>10:19</td><td class=br>-9</td>
<td class=bc>1 - 0 - 3</td>
<td class=br><strong>2</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>J</td><td class=d>5.</td><td class=kt>Czech Republic L</td><td class=kL><a href="t_310_1703_1705.aspx">0:9</a></td>
<td class=kL><a href="t_310_1703_1708.aspx">1:6</a></td>
<td class=kL><a href="t_310_1703_1704.aspx">0:9</a></td>
<td class=kL><a href="t_310_1703_1707.aspx">1:6</a></td>
<td class=kx>*</td>
<td class=br>2:30</td><td class=br>-28</td>
<td class=bc>0 - 0 - 4</td>
<td class=br><strong>0</strong></td><td class=d>5.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Latvia L</td><td class=bc>-</td><td class=bl>Czech Republic L</td><td class=bc><a href="t_310_1703_1704.aspx">9 : 0</a></tr></td>
<tr><td class=brW>Ukraine L</td><td class=bc>-</td><td class=bl>Sweden L</td><td class=bc><a href="t_310_1707_1708.aspx">4 : 1</a></tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Russia L</td><td class=bc>-</td><td class=bl>Latvia L</td><td class=bc><a href="t_310_1704_1705.aspx">4 : 4</a></tr></td>
<tr><td class=brW>Ukraine L</td><td class=bc>-</td><td class=bl>Czech Republic L</td><td class=bc><a href="t_310_1703_1708.aspx">6 : 1</a></tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Russia L</td><td class=bc>-</td><td class=bl>Ukraine L</td><td class=bc><a href="t_310_1705_1708.aspx">5 : 2</a></tr></td>
<tr><td class=brW>Sweden L</td><td class=bc>-</td><td class=bl>Czech Republic L</td><td class=bc><a href="t_310_1703_1707.aspx">6 : 1</a></tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Latvia L</td><td class=bc>-</td><td class=blW>Ukraine L</td><td class=bc><a href="t_310_1704_1708.aspx">2 : 5</a></tr></td>
<tr><td class=brW>Russia L</td><td class=bc>-</td><td class=bl>Sweden L</td><td class=bc><a href="t_310_1705_1707.aspx">8 : 0</a></tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Latvia L</td><td class=bc>-</td><td class=bl>Sweden L</td><td class=bc><a href="t_310_1704_1707.aspx">6 : 3</a></tr></td>
<tr><td class=brW>Russia L</td><td class=bc>-</td><td class=bl>Czech Republic L</td><td class=bc><a href="t_310_1703_1705.aspx">9 : 0</a></tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</table></div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
