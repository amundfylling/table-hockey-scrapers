<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Team Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Team Open : Slovakia &nbsp;&nbsp;vs.&nbsp;&nbsp;Estonia &nbsp;&nbsp;11:8</span></h2></div></div></div></div><h3 align="right">Round: 7th&nbsp;&nbsp;</h3>
<p><div align="center">
<table border=1 cellpadding="0" cellspacing="0" ><tr>
<table border="0" cellpadding="1" cellspacing="0" width="95%"><tr><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Imrich Blaško<br>2-1-2 (13:10)</td></tr>
<tr><td class="k">Tibor Valachovič<br>2-2-1 (19:16)</td></tr>
<tr><td class="k">Daniel Mitro<br>1-1-3 (10:14)</td></tr>
<tr><td class="k">I Martin Vépy<br>3-1-1 (17:18)</td></tr>
<tr><td class="k">Tomáš Hudec<br>3-1-1 (16:13)</td></tr>
</table></td>
<td valign="top"><table border="0" cellspacing="0" cellpadding="0" width="100%"><tr><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 1</td></tr>
<tr><td class="hrac_sk_v">Imrich Blaško</td><td class="vysledek" width="60">&nbsp; 3 : 2 &nbsp;</td><td class="hrac_sk">Igor Saveljev</td></tr>
<tr><td class="hrac_sk_v">Tibor Valachovič</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">Maria Saveljeva</td></tr>
<tr><td class="hrac_sk">Daniel Mitro</td><td class="vysledek" width="60">&nbsp; 0 : 3 &nbsp;</td><td class="hrac_sk_v">Jevgeni Lvov</td></tr>
<tr><td class="hrac_sk_v">I Martin Vépy</td><td class="vysledek" width="60">&nbsp; 5 : 4 &nbsp;</td><td class="hrac_sk">Yuri Artamonov</td></tr>
<tr><td class="hrac_sk_v">Tomáš Hudec</td><td class="vysledek" width="60">&nbsp; 3 : 1 &nbsp;</td><td class="hrac_sk">Alen Shekarev</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;4:1</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 2</td></tr>
<tr><td class="hrac_sk">Tomáš Hudec</td><td class="vysledek" width="60">&nbsp; 3 : 3 &nbsp;</td><td class="hrac_sk">Maria Saveljeva</td></tr>
<tr><td class="hrac_sk">Imrich Blaško</td><td class="vysledek" width="60">&nbsp; 2 : 3 &nbsp;</td><td class="hrac_sk_v">Jevgeni Lvov</td></tr>
<tr><td class="hrac_sk">Tibor Valachovič</td><td class="vysledek" width="60">&nbsp; 3 : 5 &nbsp;</td><td class="hrac_sk_v">Yuri Artamonov</td></tr>
<tr><td class="hrac_sk_v">Daniel Mitro</td><td class="vysledek" width="60">&nbsp; 3 : 1 &nbsp;</td><td class="hrac_sk">Alen Shekarev</td></tr>
<tr><td class="hrac_sk">I Martin Vépy</td><td class="vysledek" width="60">&nbsp; 3 : 3 &nbsp;</td><td class="hrac_sk">Igor Saveljev</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;5:3</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td>
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 3</td></tr>
<tr><td class="hrac_sk_v">I Martin Vépy</td><td class="vysledek" width="60">&nbsp; 4 : 2 &nbsp;</td><td class="hrac_sk">Jevgeni Lvov</td></tr>
<tr><td class="hrac_sk_v">Tomáš Hudec</td><td class="vysledek" width="60">&nbsp; 4 : 3 &nbsp;</td><td class="hrac_sk">Yuri Artamonov</td></tr>
<tr><td class="hrac_sk_v">Imrich Blaško</td><td class="vysledek" width="60">&nbsp; 5 : 1 &nbsp;</td><td class="hrac_sk">Alen Shekarev</td></tr>
<tr><td class="hrac_sk">Tibor Valachovič</td><td class="vysledek" width="60">&nbsp; 3 : 3 &nbsp;</td><td class="hrac_sk">Igor Saveljev</td></tr>
<tr><td class="hrac_sk">Daniel Mitro</td><td class="vysledek" width="60">&nbsp; 2 : 3 &nbsp;</td><td class="hrac_sk_v">Maria Saveljeva</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;8:4</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 4</td></tr>
<tr><td class="hrac_sk">Daniel Mitro</td><td class="vysledek" width="60">&nbsp; 2 : 2 &nbsp;</td><td class="hrac_sk">Yuri Artamonov</td></tr>
<tr><td class="hrac_sk_v">I Martin Vépy</td><td class="vysledek" width="60">&nbsp; 4 : 2 &nbsp;</td><td class="hrac_sk">Vafa Hamdamov</td></tr>
<tr><td class="hrac_sk_v">Tomáš Hudec</td><td class="vysledek" width="60">&nbsp; 3 : 2 &nbsp;</td><td class="hrac_sk">Igor Saveljev</td></tr>
<tr><td class="hrac_sk">Imrich Blaško</td><td class="vysledek" width="60">&nbsp; 2 : 3 &nbsp;</td><td class="hrac_sk_v">Maria Saveljeva</td></tr>
<tr><td class="hrac_sk">Tibor Valachovič</td><td class="vysledek" width="60">&nbsp; 4 : 4 &nbsp;</td><td class="hrac_sk">Jevgeni Lvov</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;10:5</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td align="center" colspan="3">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 5</td></tr>
<tr><td class="hrac_sk_v">Tibor Valachovič</td><td class="vysledek" width="60">&nbsp; 5 : 3 &nbsp;</td><td class="hrac_sk">Vafa Hamdamov</td></tr>
<tr><td class="hrac_sk">Daniel Mitro</td><td class="vysledek" width="60">&nbsp; 3 : 5 &nbsp;</td><td class="hrac_sk_v">Igor Saveljev</td></tr>
<tr><td class="hrac_sk">I Martin Vépy</td><td class="vysledek" width="60">&nbsp; 1 : 7 &nbsp;</td><td class="hrac_sk_v">Maria Saveljeva</td></tr>
<tr><td class="hrac_sk">Tomáš Hudec</td><td class="vysledek" width="60">&nbsp; 3 : 4 &nbsp;</td><td class="hrac_sk_v">Jevgeni Lvov</td></tr>
<tr><td class="hrac_sk">Imrich Blaško</td><td class="vysledek" width="60">&nbsp; 1 : 1 &nbsp;</td><td class="hrac_sk">Yuri Artamonov</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;11:8</td></tr></table>
</td></tr></table></td><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Igor Saveljev<br>1-2-2 (15:15)</td></tr>
<tr><td class="k">Maria Saveljeva<br>3-1-1 (17:12)</td></tr>
<tr><td class="k">Jevgeni Lvov<br>3-1-1 (16:13)</td></tr>
<tr><td class="k">Yuri Artamonov<br>1-2-2 (15:15)</td></tr>
<tr><td class="k">Alen Shekarev<br>0-0-3 (3:11)</td></tr>
<tr><td class="k">Vafa Hamdamov<br>0-0-2 (5:9)</td></tr>
</table></td></tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
