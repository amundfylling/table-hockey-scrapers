<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Team Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Team Open : Russia &nbsp;&nbsp;vs.&nbsp;&nbsp;Belarus &nbsp;&nbsp;20:4</span></h2></div></div></div></div><h3 align="right">Round: 7&nbsp;&nbsp;</h3>
<p><div align="center">
<table border=1 cellpadding="0" cellspacing="0" ><tr>
<table border="0" cellpadding="1" cellspacing="0" width="95%"><tr><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Veniamin Gerasimov<br>5-0-0 (25:14)</td></tr>
<tr><td class="k">Alexey Titov<br>2-0-0 (9:2)</td></tr>
<tr><td class="k">Maxim Borisov<br>0-0-1 (2:3)</td></tr>
<tr><td class="k">Sergey Ivanov<br>1-0-0 (5:2)</td></tr>
<tr><td class="k">Alexey Zaharov<br>3-0-2 (16:12)</td></tr>
<tr><td class="k">Dmitriy Petrov<br>3-0-1 (14:10)</td></tr>
<tr><td class="k">Arseniy Stolyarov<br>3-1-0 (19:11)</td></tr>
<tr><td class="k">Alexander Miloradov<br>3-0-0 (15:7)</td></tr>
</table></td>
<td valign="top"><table border="0" cellspacing="0" cellpadding="0" width="100%"><tr><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 1</td></tr>
<tr><td class="hrac_sk_v">Veniamin Gerasimov</td><td class="vysledek" width="60">&nbsp; 5 : 4 &nbsp;</td><td class="hrac_sk">Andrei Kniaziuk</td></tr>
<tr><td class="hrac_sk_v">Alexey Titov</td><td class="vysledek" width="60">&nbsp; 4 : 0 &nbsp;</td><td class="hrac_sk">Aliaksandr Bartosh</td></tr>
<tr><td class="hrac_sk">Maxim Borisov</td><td class="vysledek" width="60">&nbsp; 2 : 3 &nbsp;</td><td class="hrac_sk_v">Aliaksandr Dalgou</td></tr>
<tr><td class="hrac_sk_v">Sergey Ivanov</td><td class="vysledek" width="60">&nbsp; 5 : 2 &nbsp;</td><td class="hrac_sk">Siarhei Vazhnik</td></tr>
<tr><td class="hrac_sk">Alexey Zaharov</td><td class="vysledek" width="60">&nbsp; 0 : 5 &nbsp;</td><td class="hrac_sk_v">Eduard Kuratnik</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;3:2</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 2</td></tr>
<tr><td class="hrac_sk_v">Alexey Zaharov</td><td class="vysledek" width="60">&nbsp; 5 : 3 &nbsp;</td><td class="hrac_sk">Aliaksandr Bartosh</td></tr>
<tr><td class="hrac_sk_v">Veniamin Gerasimov</td><td class="vysledek" width="60">&nbsp; 3 : 1 &nbsp;</td><td class="hrac_sk">Aliaksandr Dalgou</td></tr>
<tr><td class="hrac_sk_v">Alexey Titov</td><td class="vysledek" width="60">&nbsp; 5 : 2 &nbsp;</td><td class="hrac_sk">Siarhei Vazhnik</td></tr>
<tr><td class="hrac_sk_v">Dmitriy Petrov</td><td class="vysledek" width="60">&nbsp; 3 : 0 &nbsp;</td><td class="hrac_sk">Eduard Kuratnik</td></tr>
<tr><td class="hrac_sk_v">Arseniy Stolyarov</td><td class="vysledek" width="60">&nbsp; 8 : 3 &nbsp;</td><td class="hrac_sk">Andrei Kniaziuk</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;8:2</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td>
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 3</td></tr>
<tr><td class="hrac_sk_v">Arseniy Stolyarov</td><td class="vysledek" width="60">&nbsp; 5 : 3 &nbsp;</td><td class="hrac_sk">Aliaksandr Dalgou</td></tr>
<tr><td class="hrac_sk_v">Alexey Zaharov</td><td class="vysledek" width="60">&nbsp; 6 : 1 &nbsp;</td><td class="hrac_sk">Siarhei Vazhnik</td></tr>
<tr><td class="hrac_sk_v">Veniamin Gerasimov</td><td class="vysledek" width="60">&nbsp; 6 : 2 &nbsp;</td><td class="hrac_sk">Eduard Kuratnik</td></tr>
<tr><td class="hrac_sk_v">Alexander Miloradov</td><td class="vysledek" width="60">&nbsp; 7 : 3 &nbsp;</td><td class="hrac_sk">Andrei Kniaziuk</td></tr>
<tr><td class="hrac_sk_v">Dmitriy Petrov</td><td class="vysledek" width="60">&nbsp; 4 : 3 &nbsp;</td><td class="hrac_sk">Aliaksandr Bartosh</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;13:2</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 4</td></tr>
<tr><td class="hrac_sk">Dmitriy Petrov</td><td class="vysledek" width="60">&nbsp; 3 : 4 &nbsp;</td><td class="hrac_sk_v">Siarhei Vazhnik</td></tr>
<tr><td class="hrac_sk_v">Arseniy Stolyarov</td><td class="vysledek" width="60">&nbsp; 2 : 1 &nbsp;</td><td class="hrac_sk">Eduard Kuratnik</td></tr>
<tr><td class="hrac_sk">Alexey Zaharov</td><td class="vysledek" width="60">&nbsp; 1 : 2 &nbsp;</td><td class="hrac_sk_v">Andrei Kniaziuk</td></tr>
<tr><td class="hrac_sk_v">Veniamin Gerasimov</td><td class="vysledek" width="60">&nbsp; 6 : 4 &nbsp;</td><td class="hrac_sk">Aliaksandr Bartosh</td></tr>
<tr><td class="hrac_sk_v">Alexander Miloradov</td><td class="vysledek" width="60">&nbsp; 3 : 2 &nbsp;</td><td class="hrac_sk">Aliaksandr Dalgou</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;16:4</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td align="center" colspan="3">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 5</td></tr>
<tr><td class="hrac_sk_v">Alexander Miloradov</td><td class="vysledek" width="60">&nbsp; 5 : 2 &nbsp;</td><td class="hrac_sk">Eduard Kuratnik</td></tr>
<tr><td class="hrac_sk_v">Dmitriy Petrov</td><td class="vysledek" width="60">&nbsp; 4 : 3 &nbsp;</td><td class="hrac_sk">Andrei Kniaziuk</td></tr>
<tr><td class="hrac_sk">Arseniy Stolyarov</td><td class="vysledek" width="60">&nbsp; 4 : 4 &nbsp;</td><td class="hrac_sk">Aliaksandr Bartosh</td></tr>
<tr><td class="hrac_sk_v">Alexey Zaharov</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">Aliaksandr Dalgou</td></tr>
<tr><td class="hrac_sk_v">Veniamin Gerasimov</td><td class="vysledek" width="60">&nbsp; 5 : 3 &nbsp;</td><td class="hrac_sk">Siarhei Vazhnik</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;20:4</td></tr></table>
</td></tr></table></td><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Andrei Kniaziuk<br>1-0-4 (15:25)</td></tr>
<tr><td class="k">Aliaksandr Bartosh<br>0-1-4 (14:23)</td></tr>
<tr><td class="k">Aliaksandr Dalgou<br>1-0-4 (10:17)</td></tr>
<tr><td class="k">Siarhei Vazhnik<br>1-0-4 (12:24)</td></tr>
<tr><td class="k">Eduard Kuratnik<br>1-0-4 (10:16)</td></tr>
</table></td></tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
