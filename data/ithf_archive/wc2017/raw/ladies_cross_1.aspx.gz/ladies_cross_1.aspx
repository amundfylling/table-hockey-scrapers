<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Ladies</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Ladies </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group L1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ca Eriksson</td><td class=ic>SWE</td><td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>1:0</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>9:3</td>
<td class=br>38:13</td><td class=br>+25</td>
<td class=bc>9 - 0 - 1</td>
<td class=br><strong>18</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Vi Gorodnitskaya</td><td class=ic>RUS</td><td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>6:0</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>7:0</td>
<td class=br>38:8</td><td class=br>+30</td>
<td class=bc>8 - 1 - 1</td>
<td class=br><strong>17</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>El Nikitina</td><td class=ic>RUS</td><td class=kL>0:1</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=br>31:12</td><td class=br>+19</td>
<td class=bc>6 - 3 - 1</td>
<td class=br><strong>15</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>El Racenaja</td><td class=ic>LAT</td><td class=kL>3:5</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>6:4</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=br>35:26</td><td class=br>+9</td>
<td class=bc>7 - 0 - 3</td>
<td class=br><strong>14</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>An Garkovska</td><td class=ic>UKR</td><td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kT>0:0</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=br>24:19</td><td class=br>+5</td>
<td class=bc>4 - 3 - 3</td>
<td class=br><strong>11</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Sa Komaraite</td><td class=ic>LTU</td><td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>4:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>2:7</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>11:1</td>
<td class=br>37:26</td><td class=br>+11</td>
<td class=bc>4 - 2 - 4</td>
<td class=br><strong>10</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>La Kamzola</td><td class=ic>LAT</td><td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=br>25:16</td><td class=br>+9</td>
<td class=bc>5 - 0 - 5</td>
<td class=br><strong>10</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Ma Miloradova</td><td class=ic>RUS</td><td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kW>7:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>6:4</td>
<td class=br>27:36</td><td class=br>-9</td>
<td class=bc>3 - 1 - 6</td>
<td class=br><strong>7</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Vl Gobyová</td><td class=ic>CZE</td><td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>4:3</td>
<td class=br>17:39</td><td class=br>-22</td>
<td class=bc>2 - 0 - 8</td>
<td class=br><strong>4</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>An Gripp</td><td class=ic>GER</td><td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=br>12:45</td><td class=br>-33</td>
<td class=bc>2 - 0 - 8</td>
<td class=br><strong>4</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Mi Horáková</td><td class=ic>CZE</td><td class=kL>3:9</td>
<td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>1:11</td>
<td class=kL>1:7</td>
<td class=kL>4:6</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=br>18:62</td><td class=br>-44</td>
<td class=bc>0 - 0 - 10</td>
<td class=br><strong>0</strong></td><td class=d>11.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ca Eriksson</td><td class=bc>-</td><td class=bl>El Racenaja</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>An Garkovska</td><td class=bc>-</td><td class=bl>El Nikitina</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>Ma Miloradova</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Vi Gorodnitskaya</td><td class=bc>-</td><td class=bl>Sa Komaraite</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Gripp</td><td class=bc>-</td><td class=blW>La Kamzola</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>El Racenaja</td><td class=bc>-</td><td class=blW>El Nikitina</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ca Eriksson</td><td class=bc>-</td><td class=bl>Ma Miloradova</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>An Garkovska</td><td class=bc>-</td><td class=bl>Sa Komaraite</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>La Kamzola</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vi Gorodnitskaya</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>El Nikitina</td><td class=bc>-</td><td class=bl>Ma Miloradova</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>El Racenaja</td><td class=bc>-</td><td class=bl>Sa Komaraite</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Ca Eriksson</td><td class=bc>-</td><td class=bl>La Kamzola</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>An Garkovska</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Vl Gobyová</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ma Miloradova</td><td class=bc>-</td><td class=bl>Sa Komaraite</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>El Nikitina</td><td class=bc>-</td><td class=bl>La Kamzola</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>El Racenaja</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ca Eriksson</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Garkovska</td><td class=bc>-</td><td class=bl>Vi Gorodnitskaya</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Sa Komaraite</td><td class=bc>-</td><td class=bl>La Kamzola</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ma Miloradova</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>El Nikitina</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>El Racenaja</td><td class=bc>-</td><td class=blW>Vi Gorodnitskaya</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ca Eriksson</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>La Kamzola</td><td class=bc>-</td><td class=bl>Mi Horáková</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Sa Komaraite</td><td class=bc>-</td><td class=bl>An Gripp</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ma Miloradova</td><td class=bc>-</td><td class=blW>Vi Gorodnitskaya</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>El Nikitina</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>El Racenaja</td><td class=bc>-</td><td class=bl>An Garkovska</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>An Gripp</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>La Kamzola</td><td class=bc>-</td><td class=blW>Vi Gorodnitskaya</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Sa Komaraite</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ma Miloradova</td><td class=bc>-</td><td class=blW>An Garkovska</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>El Nikitina</td><td class=bc>-</td><td class=blW>Ca Eriksson</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>An Gripp</td><td class=bc>-</td><td class=blW>Vi Gorodnitskaya</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Vl Gobyová</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>La Kamzola</td><td class=bc>-</td><td class=bl>An Garkovska</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sa Komaraite</td><td class=bc>-</td><td class=blW>Ca Eriksson</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Miloradova</td><td class=bc>-</td><td class=blW>El Racenaja</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Vi Gorodnitskaya</td><td class=bc>-</td><td class=bl>Vl Gobyová</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>An Gripp</td><td class=bc>-</td><td class=blW>An Garkovska</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Ca Eriksson</td><td class=bc>3 : 9</tr></td>
<tr><td class=br>La Kamzola</td><td class=bc>-</td><td class=blW>El Racenaja</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Sa Komaraite</td><td class=bc>-</td><td class=bl>El Nikitina</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>An Garkovska</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vi Gorodnitskaya</td><td class=bc>-</td><td class=bl>Ca Eriksson</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>An Gripp</td><td class=bc>-</td><td class=blW>El Racenaja</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>El Nikitina</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>La Kamzola</td><td class=bc>-</td><td class=bl>Ma Miloradova</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>An Garkovska</td><td class=bc>-</td><td class=blW>Ca Eriksson</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vl Gobyová</td><td class=bc>-</td><td class=blW>El Racenaja</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vi Gorodnitskaya</td><td class=bc>-</td><td class=blW>El Nikitina</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>An Gripp</td><td class=bc>-</td><td class=bl>Ma Miloradova</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Horáková</td><td class=bc>-</td><td class=blW>Sa Komaraite</td><td class=bc>1 : 11</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
