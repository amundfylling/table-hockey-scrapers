<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Juniors</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Juniors </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group J2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>J</td><td class=d>1.</td><td class=kt>Dm Litvinyuk</td><td class=ic>UKR</td><td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>7:4</td>
<td class=kW>5:3</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>7:2</td>
<td class=kW>9:3</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=br>80:33</td><td class=br>+47</td>
<td class=bc>13 - 3 - 1</td>
<td class=br><strong>29</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>J</td><td class=d>2.</td><td class=kt>Ra Miglinieks</td><td class=ic>LAT</td><td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>0:0</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>6:4</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>9:2</td>
<td class=kW>6:0</td>
<td class=br>66:25</td><td class=br>+41</td>
<td class=bc>13 - 3 - 1</td>
<td class=br><strong>29</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>J</td><td class=d>3.</td><td class=kt>Os Henriksson</td><td class=ic>SWE</td><td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kL>4:6</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>9:4</td>
<td class=kW>7:1</td>
<td class=kW>7:2</td>
<td class=kW>4:3</td>
<td class=kW>7:0</td>
<td class=kW>7:2</td>
<td class=kW>6:3</td>
<td class=kW>10:1</td>
<td class=kW>10:2</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=br>101:37</td><td class=br>+64</td>
<td class=bc>14 - 1 - 2</td>
<td class=br><strong>29</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>J</td><td class=d>4.</td><td class=kt>Ev Matantsev</td><td class=ic>UKR</td><td class=kT>4:4</td>
<td class=kT>0:0</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>8:1</td>
<td class=kW>16:2</td>
<td class=kW>13:0</td>
<td class=kW>7:3</td>
<td class=kW>9:6</td>
<td class=kW>16:0</td>
<td class=kW>9:2</td>
<td class=kW>16:0</td>
<td class=br>122:38</td><td class=br>+84</td>
<td class=bc>11 - 4 - 2</td>
<td class=br><strong>26</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>J</td><td class=d>5.</td><td class=kt>Am Fylling</td><td class=ic>NOR</td><td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kW>6:4</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>10:1</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=br>64:32</td><td class=br>+32</td>
<td class=bc>11 - 3 - 3</td>
<td class=br><strong>25</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>J</td><td class=d>6.</td><td class=kt>Be Suominen</td><td class=ic>FIN</td><td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>9:0</td>
<td class=kW>4:3</td>
<td class=kW>10:4</td>
<td class=kW>8:2</td>
<td class=kW>8:0</td>
<td class=br>70:29</td><td class=br>+41</td>
<td class=bc>11 - 3 - 3</td>
<td class=br><strong>25</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>J</td><td class=d>7.</td><td class=kt>Li Restel</td><td class=ic>GER</td><td class=kL>4:5</td>
<td class=kL>4:6</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>8:0</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=kW>3:0</td>
<td class=kW>9:1</td>
<td class=br>71:35</td><td class=br>+36</td>
<td class=bc>10 - 3 - 4</td>
<td class=br><strong>23</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>J</td><td class=d>8.</td><td class=kt>El Edelis</td><td class=ic>LAT</td><td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kL>4:9</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=kW>10:1</td>
<td class=kW>10:0</td>
<td class=kW>4:1</td>
<td class=br>69:34</td><td class=br>+35</td>
<td class=bc>9 - 3 - 5</td>
<td class=br><strong>21</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>J</td><td class=d>9.</td><td class=kt>Va Dietze</td><td class=ic>GER</td><td class=kT>4:4</td>
<td class=kL>2:6</td>
<td class=kL>1:7</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kW>7:1</td>
<td class=kW>6:2</td>
<td class=kW>11:5</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>5:3</td>
<td class=kW>10:0</td>
<td class=br>70:53</td><td class=br>+17</td>
<td class=bc>9 - 2 - 6</td>
<td class=br><strong>20</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>J</td><td class=d>10.</td><td class=kt>Ho Sládek</td><td class=ic>CZE</td><td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>2:7</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kW>5:1</td>
<td class=kW>8:1</td>
<td class=kW>7:2</td>
<td class=kW>9:1</td>
<td class=br>57:45</td><td class=br>+12</td>
<td class=bc>6 - 3 - 8</td>
<td class=br><strong>15</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>J</td><td class=d>11.</td><td class=kt>Le Haussknecht</td><td class=ic>GER</td><td class=kL>4:7</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>1:8</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kL>3:7</td>
<td class=kL>2:3</td>
<td class=kW>8:1</td>
<td class=kW>8:2</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=br>61:55</td><td class=br>+6</td>
<td class=bc>6 - 3 - 8</td>
<td class=br><strong>15</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>J</td><td class=d>12.</td><td class=kt>Lu Kahoun</td><td class=ic>CZE</td><td class=kL>3:5</td>
<td class=kL>3:7</td>
<td class=kL>0:7</td>
<td class=kL>2:16</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>8:0</td>
<td class=br>40:82</td><td class=br>-42</td>
<td class=bc>6 - 0 - 11</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>J</td><td class=d>13.</td><td class=kt>Jo Roholm</td><td class=ic>FIN</td><td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kL>0:13</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kW>7:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=br>33:67</td><td class=br>-34</td>
<td class=bc>5 - 2 - 10</td>
<td class=br><strong>12</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>J</td><td class=d>14.</td><td class=kt>Mi Skrlep</td><td class=ic>SLO</td><td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kL>3:6</td>
<td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kL>0:9</td>
<td class=kL>0:8</td>
<td class=kL>1:4</td>
<td class=kL>5:11</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kW>6:0</td>
<td class=kW>2:0</td>
<td class=br>36:73</td><td class=br>-37</td>
<td class=bc>4 - 1 - 12</td>
<td class=br><strong>9</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>J</td><td class=d>15.</td><td class=kt>Da Moshnin</td><td class=ic>EST</td><td class=kL>2:7</td>
<td class=kL>0:4</td>
<td class=kL>1:10</td>
<td class=kL>6:9</td>
<td class=kL>1:10</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>1:8</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=br>35:87</td><td class=br>-52</td>
<td class=bc>4 - 0 - 13</td>
<td class=br><strong>8</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>J</td><td class=d>16.</td><td class=kt>Vo Bernát</td><td class=ic>CZE</td><td class=kL>3:9</td>
<td class=kL>0:2</td>
<td class=kL>2:10</td>
<td class=kL>0:16</td>
<td class=kL>1:5</td>
<td class=kL>4:10</td>
<td class=kL>0:7</td>
<td class=kL>1:10</td>
<td class=kL>0:5</td>
<td class=kL>1:8</td>
<td class=kL>2:8</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>8:0</td>
<td class=br>33:108</td><td class=br>-75</td>
<td class=bc>2 - 1 - 14</td>
<td class=br><strong>5</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>J</td><td class=d>17.</td><td class=kt>Fi Kalinouski</td><td class=ic>BLR</td><td class=kL>0:6</td>
<td class=kL>2:9</td>
<td class=kL>0:6</td>
<td class=kL>2:9</td>
<td class=kL>0:4</td>
<td class=kL>2:8</td>
<td class=kL>0:3</td>
<td class=kL>0:10</td>
<td class=kL>3:5</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=br>19:89</td><td class=br>-70</td>
<td class=bc>1 - 0 - 16</td>
<td class=br><strong>2</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>J</td><td class=d>18.</td><td class=kt>Mo Skrlep</td><td class=ic>SLO</td><td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>0:16</td>
<td class=kL>1:7</td>
<td class=kL>0:8</td>
<td class=kL>1:9</td>
<td class=kL>1:4</td>
<td class=kL>0:10</td>
<td class=kL>1:9</td>
<td class=kL>1:6</td>
<td class=kL>0:8</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kL>2:6</td>
<td class=kL>0:8</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=br>9:114</td><td class=br>-105</td>
<td class=bc>0 - 1 - 16</td>
<td class=br><strong>1</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>4 : 10</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>El Edelis</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=blW>Jo Roholm</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Da Moshnin</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>11 : 5</tr></td>
<tr><td class=brW>El Edelis</td><td class=bc>-</td><td class=bl>Jo Roholm</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Le Haussknecht</td><td class=bc>-</td><td class=bl>Da Moshnin</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Os Henriksson</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 16</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Jo Roholm</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Li Restel</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>El Edelis</td><td class=bc>-</td><td class=bl>Da Moshnin</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Os Henriksson</td><td class=bc>-</td><td class=bl>Dm Litvinyuk</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=blW>Mi Skrlep</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Jo Roholm</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Da Moshnin</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>El Edelis</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Le Haussknecht</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Jo Roholm</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=blW>Li Restel</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Da Moshnin</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>0 : 16</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=bl>Dm Litvinyuk</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>El Edelis</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Jo Roholm</td><td class=bc>-</td><td class=blW>Li Restel</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Da Moshnin</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>El Edelis</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>4 : 9</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Li Restel</td><td class=bc>-</td><td class=bl>Da Moshnin</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Jo Roholm</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>2 : 10</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>El Edelis</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Da Moshnin</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jo Roholm</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Mi Skrlep</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>El Edelis</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Da Moshnin</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Li Restel</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Jo Roholm</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=blW>Le Haussknecht</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>El Edelis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Da Moshnin</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=blW>Le Haussknecht</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jo Roholm</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>El Edelis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Moshnin</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 10</tr></td>
<tr><td class=brW>Li Restel</td><td class=bc>-</td><td class=bl>El Edelis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Jo Roholm</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>El Edelis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Da Moshnin</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Li Restel</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Jo Roholm</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Mi Skrlep</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Le Haussknecht</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Dm Litvinyuk</td><td class=bc>-</td><td class=blW>El Edelis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Da Moshnin</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Li Restel</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Jo Roholm</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Os Henriksson</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>El Edelis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>9 : 3</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Moshnin</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Li Restel</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Jo Roholm</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=bl>El Edelis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>16 : 0</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Da Moshnin</td><td class=bc>-</td><td class=blW>Jo Roholm</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Le Haussknecht</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Fi Kalinouski</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Jo Roholm</td><td class=bc>13 : 0</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Da Moshnin</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>El Edelis</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Jo Roholm</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Da Moshnin</td><td class=bc>9 : 6</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>El Edelis</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=blW>Mi Skrlep</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Jo Roholm</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Li Restel</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Da Moshnin</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
