<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Team Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Team Open : Slovakia &nbsp;&nbsp;vs.&nbsp;&nbsp;Lithuania &nbsp;&nbsp;19:2</span></h2></div></div></div></div><h3 align="right">Round: 3&nbsp;&nbsp;</h3>
<p><div align="center">
<table border=1 cellpadding="0" cellspacing="0" ><tr>
<table border="0" cellpadding="1" cellspacing="0" width="95%"><tr><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Imrich Blaško<br>5-0-0 (24:7)</td></tr>
<tr><td class="k">Tibor Valachovič<br>4-1-0 (33:10)</td></tr>
<tr><td class="k">Daniel Mitro<br>2-2-1 (13:9)</td></tr>
<tr><td class="k">I Martin Vépy<br>5-0-0 (21:6)</td></tr>
<tr><td class="k">Karol Hudec<br>1-0-1 (9:5)</td></tr>
<tr><td class="k">Tomáš Hudec<br>2-1-0 (10:5)</td></tr>
</table></td>
<td valign="top"><table border="0" cellspacing="0" cellpadding="0" width="100%"><tr><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 1</td></tr>
<tr><td class="hrac_sk_v">Imrich Blaško</td><td class="vysledek" width="60">&nbsp; 2 : 0 &nbsp;</td><td class="hrac_sk">Simonas Pleikys</td></tr>
<tr><td class="hrac_sk_v">Tibor Valachovič</td><td class="vysledek" width="60">&nbsp; 10 : 0 &nbsp;</td><td class="hrac_sk">Audrius Pleikys</td></tr>
<tr><td class="hrac_sk">Daniel Mitro</td><td class="vysledek" width="60">&nbsp; 3 : 3 &nbsp;</td><td class="hrac_sk">Mazvydas Satkus</td></tr>
<tr><td class="hrac_sk_v">I Martin Vépy</td><td class="vysledek" width="60">&nbsp; 6 : 3 &nbsp;</td><td class="hrac_sk">Vladimir Voronov</td></tr>
<tr><td class="hrac_sk">Karol Hudec</td><td class="vysledek" width="60">&nbsp; 4 : 5 &nbsp;</td><td class="hrac_sk_v">Sandra Komaraite</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;3:1</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 2</td></tr>
<tr><td class="hrac_sk_v">Karol Hudec</td><td class="vysledek" width="60">&nbsp; 5 : 0 &nbsp;</td><td class="hrac_sk">Audrius Pleikys</td></tr>
<tr><td class="hrac_sk_v">Imrich Blaško</td><td class="vysledek" width="60">&nbsp; 5 : 2 &nbsp;</td><td class="hrac_sk">Mazvydas Satkus</td></tr>
<tr><td class="hrac_sk_v">Tibor Valachovič</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">Vladimir Voronov</td></tr>
<tr><td class="hrac_sk_v">Daniel Mitro</td><td class="vysledek" width="60">&nbsp; 3 : 1 &nbsp;</td><td class="hrac_sk">Sandra Komaraite</td></tr>
<tr><td class="hrac_sk_v">I Martin Vépy</td><td class="vysledek" width="60">&nbsp; 3 : 0 &nbsp;</td><td class="hrac_sk">Simonas Pleikys</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;8:1</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td>
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 3</td></tr>
<tr><td class="hrac_sk_v">I Martin Vépy</td><td class="vysledek" width="60">&nbsp; 3 : 2 &nbsp;</td><td class="hrac_sk">Mazvydas Satkus</td></tr>
<tr><td class="hrac_sk_v">Tomáš Hudec</td><td class="vysledek" width="60">&nbsp; 6 : 2 &nbsp;</td><td class="hrac_sk">Vladimir Voronov</td></tr>
<tr><td class="hrac_sk_v">Imrich Blaško</td><td class="vysledek" width="60">&nbsp; 7 : 1 &nbsp;</td><td class="hrac_sk">Sandra Komaraite</td></tr>
<tr><td class="hrac_sk_v">Tibor Valachovič</td><td class="vysledek" width="60">&nbsp; 6 : 3 &nbsp;</td><td class="hrac_sk">Simonas Pleikys</td></tr>
<tr><td class="hrac_sk">Daniel Mitro</td><td class="vysledek" width="60">&nbsp; 1 : 1 &nbsp;</td><td class="hrac_sk">Audrius Pleikys</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;12:1</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 4</td></tr>
<tr><td class="hrac_sk_v">Daniel Mitro</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">Vladimir Voronov</td></tr>
<tr><td class="hrac_sk_v">I Martin Vépy</td><td class="vysledek" width="60">&nbsp; 5 : 1 &nbsp;</td><td class="hrac_sk">Sandra Komaraite</td></tr>
<tr><td class="hrac_sk_v">Tomáš Hudec</td><td class="vysledek" width="60">&nbsp; 1 : 0 &nbsp;</td><td class="hrac_sk">Simonas Pleikys</td></tr>
<tr><td class="hrac_sk_v">Imrich Blaško</td><td class="vysledek" width="60">&nbsp; 3 : 2 &nbsp;</td><td class="hrac_sk">Audrius Pleikys</td></tr>
<tr><td class="hrac_sk">Tibor Valachovič</td><td class="vysledek" width="60">&nbsp; 4 : 4 &nbsp;</td><td class="hrac_sk">Mazvydas Satkus</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;16:1</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td align="center" colspan="3">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 5</td></tr>
<tr><td class="hrac_sk_v">Tibor Valachovič</td><td class="vysledek" width="60">&nbsp; 9 : 2 &nbsp;</td><td class="hrac_sk">Sandra Komaraite</td></tr>
<tr><td class="hrac_sk">Daniel Mitro</td><td class="vysledek" width="60">&nbsp; 2 : 3 &nbsp;</td><td class="hrac_sk_v">Simonas Pleikys</td></tr>
<tr><td class="hrac_sk_v">I Martin Vépy</td><td class="vysledek" width="60">&nbsp; 4 : 0 &nbsp;</td><td class="hrac_sk">Audrius Pleikys</td></tr>
<tr><td class="hrac_sk">Tomáš Hudec</td><td class="vysledek" width="60">&nbsp; 3 : 3 &nbsp;</td><td class="hrac_sk">Mazvydas Satkus</td></tr>
<tr><td class="hrac_sk_v">Imrich Blaško</td><td class="vysledek" width="60">&nbsp; 7 : 2 &nbsp;</td><td class="hrac_sk">Vladimir Voronov</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;19:2</td></tr></table>
</td></tr></table></td><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Simonas Pleikys<br>1-0-4 (6:14)</td></tr>
<tr><td class="k">Audrius Pleikys<br>0-1-4 (3:23)</td></tr>
<tr><td class="k">Mazvydas Satkus<br>0-3-2 (14:18)</td></tr>
<tr><td class="k">Vladimir Voronov<br>0-0-5 (9:27)</td></tr>
<tr><td class="k">Sandra Komaraite<br>1-0-4 (10:28)</td></tr>
</table></td></tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
