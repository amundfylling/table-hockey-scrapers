<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Open </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group A2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>25</td>
<td class=ic>26</td>
<td class=ic>27</td>
<td class=ic>28</td>
<td class=ic>29</td>
<td class=ic>30</td>
<td class=ic>31</td>
<td class=ic>32</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt>Ed Caics</td><td class=ic>LAT</td><td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>10:1</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kW>4:2 K</td>
<td class=kL>3:4 K</td>
<td class=kT>5:5</td>
<td class=kW>5:2</td>
<td class=kT>5:5</td>
<td class=kL>0:3</td>
<td class=kW>8:0</td>
<td class=kW>3:0</td>
<td class=kW>8:4</td>
<td class=kW>6:2</td>
<td class=kW>3:2 K</td>
<td class=kW>4:1</td>
<td class=kW>5:3 K</td>
<td class=kL>1:4</td>
<td class=kW>6:1 K</td>
<td class=kW>7:5 K</td>
<td class=kW>5:3</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>9:3</td>
<td class=kW>8:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3 K</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>9:0</td>
<td class=br>152:73</td><td class=br>+79</td>
<td class=bc>22 - 4 - 5</td>
<td class=br><strong>48</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt>Ya Galuzo</td><td class=ic>RUS</td><td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:1 K</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kW>5:2 K</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>9:2</td>
<td class=kW>2:1</td>
<td class=kL>2:3 K</td>
<td class=kW>4:1 K</td>
<td class=kW>4:1</td>
<td class=kW>6:1 K</td>
<td class=kW>5:4 K</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>9:1</td>
<td class=kW>7:1 K</td>
<td class=br>126:56</td><td class=br>+70</td>
<td class=bc>21 - 6 - 4</td>
<td class=br><strong>48</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt>Ev Matantsev</td><td class=ic>UKR</td><td class=kL>1:10</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>0:1 K</td>
<td class=kW>5:3</td>
<td class=kL>2:6</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kW>5:0 K</td>
<td class=kW>6:1</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kT>4:4 K</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>2:4 K</td>
<td class=kW>7:1</td>
<td class=kW>5:4 K</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kW>4:1 K</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kW>7:1</td>
<td class=kW>7:4</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>7:1</td>
<td class=kW>9:1 K</td>
<td class=kW>8:3</td>
<td class=br>129:80</td><td class=br>+49</td>
<td class=bc>20 - 4 - 7</td>
<td class=br><strong>44</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt>Al Miloradov</td><td class=ic>RUS</td><td class=kL>1:4</td>
<td class=kL>1:5 K</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kW>6:0</td>
<td class=kT>1:1 K</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>10:3</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>6:1 K</td>
<td class=kW>2:1 K</td>
<td class=kW>4:1</td>
<td class=kW>3:0 K</td>
<td class=kW>3:0 K</td>
<td class=kW>5:2</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kT>4:4 K</td>
<td class=br>107:73</td><td class=br>+34</td>
<td class=bc>19 - 5 - 7</td>
<td class=br><strong>43</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>Al Zaharov</td><td class=ic>RUS</td><td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>1:0 K</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kL>2:4</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>2:1 K</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kL>3:5 K</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kL>4:6</td>
<td class=kL>2:3 K</td>
<td class=kW>6:3</td>
<td class=kW>6:3 K</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>6:2 K</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>8:5</td>
<td class=kW>4:3</td>
<td class=kW>4:3 K</td>
<td class=kW>6:3</td>
<td class=br>112:75</td><td class=br>+37</td>
<td class=bc>19 - 4 - 8</td>
<td class=br><strong>42</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>Le Hvižď ml.</td><td class=ic>CZE</td><td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>3:0 K</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>3:1 K</td>
<td class=kT>3:3 K</td>
<td class=kL>3:4</td>
<td class=kT>3:3 K</td>
<td class=kT>1:1 K</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>3:6 K</td>
<td class=kL>4:5</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kT>1:1 K</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=br>96:67</td><td class=br>+29</td>
<td class=bc>16 - 10 - 5</td>
<td class=br><strong>42</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Ke Eriksson</td><td class=ic>FIN</td><td class=kL>2:4 K</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>5:4 K</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kW>5:2 K</td>
<td class=kL>0:3</td>
<td class=kW>4:3 K</td>
<td class=kW>3:1</td>
<td class=kT>3:3 K</td>
<td class=kW>4:3 K</td>
<td class=kW>8:3</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>7:2</td>
<td class=kW>7:4</td>
<td class=kW>2:0</td>
<td class=kL>3:4 K</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>8:3</td>
<td class=br>115:84</td><td class=br>+31</td>
<td class=bc>19 - 3 - 9</td>
<td class=br><strong>41</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>Pa Petr</td><td class=ic>CZE</td><td class=kW>4:3 K</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kL>4:5 K</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>9:4</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kT>2:2 K</td>
<td class=kL>2:4</td>
<td class=kT>2:2 K</td>
<td class=kW>8:2</td>
<td class=kW>6:1 K</td>
<td class=kW>5:2 K</td>
<td class=kW>5:2</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1 K</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>6:3</td>
<td class=br>114:88</td><td class=br>+26</td>
<td class=bc>17 - 4 - 10</td>
<td class=br><strong>38</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>Dm Malygin</td><td class=ic>RUS</td><td class=kT>5:5</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>1:7</td>
<td class=kL>0:3 K</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kT>2:2 K</td>
<td class=kW>3:2 K</td>
<td class=kT>3:3</td>
<td class=kT>2:2 K</td>
<td class=kL>1:5 K</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>3:0</td>
<td class=kL>2:4 K</td>
<td class=kW>9:2</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=kW>4:0 K</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=br>94:84</td><td class=br>+10</td>
<td class=bc>13 - 11 - 7</td>
<td class=br><strong>37</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Lu Turoň</td><td class=ic>CZE</td><td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kL>0:5 K</td>
<td class=kL>0:6</td>
<td class=kL>1:2 K</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>0:2 K</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>5:2 K</td>
<td class=kW>7:0</td>
<td class=kW>7:0 K</td>
<td class=kW>6:0</td>
<td class=kW>5:2</td>
<td class=kL>3:5 K</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>4:0</td>
<td class=kT>5:5</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=kW>6:1 K</td>
<td class=kW>4:0</td>
<td class=br>104:72</td><td class=br>+32</td>
<td class=bc>16 - 5 - 10</td>
<td class=br><strong>37</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>Ma Nilsson</td><td class=ic>SWE</td><td class=kT>5:5</td>
<td class=kL>2:5 K</td>
<td class=kL>1:6</td>
<td class=kT>1:1 K</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>2:7</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>1:0</td>
<td class=kW>5:3</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kT>2:2 K</td>
<td class=kW>5:2 K</td>
<td class=kW>5:0</td>
<td class=kW>5:3 K</td>
<td class=kL>3:4 K</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>6:2 K</td>
<td class=br>108:90</td><td class=br>+18</td>
<td class=bc>16 - 4 - 11</td>
<td class=br><strong>36</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>Gr Dubinin</td><td class=ic>RUS</td><td class=kW>3:0</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>1:3 K</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2 K</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=kW>6:2</td>
<td class=kL>1:2 K</td>
<td class=kW>3:0 K</td>
<td class=kL>3:4</td>
<td class=kW>4:0</td>
<td class=kW>6:3</td>
<td class=kW>5:3</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>6:3</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kT>2:2 K</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2 K</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=br>94:69</td><td class=br>+25</td>
<td class=bc>16 - 4 - 11</td>
<td class=br><strong>36</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt>Ja Pelkonen</td><td class=ic>FIN</td><td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kT>3:3 K</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kL>2:3 K</td>
<td class=kL>1:2</td>
<td class=kW>7:2</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:0 K</td>
<td class=kL>2:3 K</td>
<td class=kL>0:3</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>6:4</td>
<td class=kW>8:1</td>
<td class=kW>8:4</td>
<td class=kW>5:3</td>
<td class=kW>3:2 K</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>5:0 K</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=br>96:80</td><td class=br>+16</td>
<td class=bc>14 - 6 - 11</td>
<td class=br><strong>34</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt>Je Zaharovs</td><td class=ic>LAT</td><td class=kL>0:3</td>
<td class=kL>1:7</td>
<td class=kT>4:4 K</td>
<td class=kL>3:6</td>
<td class=kW>5:3 K</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kL>4:9</td>
<td class=kT>3:3</td>
<td class=kW>2:0 K</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kW>4:3 K</td>
<td class=kL>3:6</td>
<td class=kT>1:1 K</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>2:6 K</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kT>3:3 K</td>
<td class=kW>5:1</td>
<td class=br>94:96</td><td class=br>-2</td>
<td class=bc>13 - 8 - 10</td>
<td class=br><strong>34</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt>Ol Korabel</td><td class=ic>UKR</td><td class=kL>4:8</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kT>3:3 K</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kT>2:2 K</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kW>2:1 K</td>
<td class=kL>0:3 K</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:0 K</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>4:6</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kT>3:3 K</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>5:1 K</td>
<td class=kW>7:1</td>
<td class=kT>2:2</td>
<td class=br>88:86</td><td class=br>+2</td>
<td class=bc>12 - 8 - 11</td>
<td class=br><strong>32</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt>Al Titov</td><td class=ic>RUS</td><td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kT>1:1 K</td>
<td class=kW>3:0</td>
<td class=kL>1:5</td>
<td class=kW>5:1 K</td>
<td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kL>0:3 K</td>
<td class=kW>3:2 K</td>
<td class=kW>2:0</td>
<td class=kL>0:3 K</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kT>4:4 K</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>1:0 K</td>
<td class=kL>2:4</td>
<td class=kW>7:1</td>
<td class=br>73:75</td><td class=br>-2</td>
<td class=bc>13 - 6 - 12</td>
<td class=br><strong>32</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Pe Tměj</td><td class=ic>CZE</td><td class=kL>2:3 K</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>6:4</td>
<td class=kL>2:3</td>
<td class=kL>2:5 K</td>
<td class=kT>2:2 K</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>1:1 K</td>
<td class=kL>3:4</td>
<td class=kT>1:1 K</td>
<td class=kW>4:3 K</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>4:6</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>4:1 K</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=br>75:71</td><td class=br>+4</td>
<td class=bc>13 - 5 - 13</td>
<td class=br><strong>31</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Ar Stolyarov</td><td class=ic>RUS</td><td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kW>4:2 K</td>
<td class=kL>3:10</td>
<td class=kW>3:2 K</td>
<td class=kL>0:2</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kL>2:5 K</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>3:4 K</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>3:4 K</td>
<td class=kL>1:2</td>
<td class=kW>7:3</td>
<td class=kT>4:4 K</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>7:3</td>
<td class=kW>5:3</td>
<td class=kW>5:4</td>
<td class=kW>8:3</td>
<td class=kT>2:2</td>
<td class=kL>2:4 K</td>
<td class=kW>4:0</td>
<td class=br>93:92</td><td class=br>+1</td>
<td class=bc>13 - 5 - 13</td>
<td class=br><strong>31</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Kr Lebl</td><td class=ic>CZE</td><td class=kL>3:5 K</td>
<td class=kL>2:7</td>
<td class=kL>1:7</td>
<td class=kW>4:2</td>
<td class=kL>3:6</td>
<td class=kT>1:1</td>
<td class=kL>3:4 K</td>
<td class=kT>2:2 K</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kW>4:2</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kW>6:3</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kT>1:1 K</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kT>3:3 K</td>
<td class=kL>2:3 K</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kW>2:1 K</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=br>85:95</td><td class=br>-10</td>
<td class=bc>13 - 4 - 14</td>
<td class=br><strong>30</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Ed Mucenieks</td><td class=ic>LAT</td><td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>4:5 K</td>
<td class=kT>3:3</td>
<td class=kL>3:6 K</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>2:8</td>
<td class=kT>3:3</td>
<td class=kL>0:7 K</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kT>1:1 K</td>
<td class=kW>6:4</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>4:3 K</td>
<td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kL>5:7 K</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kL>2:5</td>
<td class=kW>9:3</td>
<td class=kL>1:8</td>
<td class=kL>0:2</td>
<td class=kW>6:1 K</td>
<td class=kW>5:3</td>
<td class=br>92:106</td><td class=br>-14</td>
<td class=bc>10 - 8 - 13</td>
<td class=br><strong>28</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Sa Sainio</td><td class=ic>FIN</td><td class=kL>1:6 K</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kT>3:3 K</td>
<td class=kL>1:6 K</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kT>1:1 K</td>
<td class=kW>2:1</td>
<td class=kT>3:3 K</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3 K</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kL>2:4 K</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=br>69:87</td><td class=br>-18</td>
<td class=bc>9 - 10 - 12</td>
<td class=br><strong>28</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Ma Klippen</td><td class=ic>NOR</td><td class=kL>5:7 K</td>
<td class=kL>2:9</td>
<td class=kW>6:2</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>3:4 K</td>
<td class=kL>2:5 K</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kL>4:6</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>3:4 K</td>
<td class=kL>3:7</td>
<td class=kW>3:2 K</td>
<td class=kL>2:5</td>
<td class=kT>3:3 K</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>6:0</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kW>5:4</td>
<td class=kT>3:3</td>
<td class=kW>1:0 K</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kL>1:3</td>
<td class=br>91:104</td><td class=br>-13</td>
<td class=bc>11 - 5 - 15</td>
<td class=br><strong>27</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Ti Valachovič</td><td class=ic>SVK</td><td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>1:4 K</td>
<td class=kL>2:4</td>
<td class=kL>2:6 K</td>
<td class=kL>1:4</td>
<td class=kL>3:8</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kW>5:3 K</td>
<td class=kW>4:1</td>
<td class=kL>3:6</td>
<td class=kL>1:8</td>
<td class=kW>6:2 K</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kT>4:4 K</td>
<td class=kL>3:4</td>
<td class=kW>7:5 K</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kW>7:1</td>
<td class=kW>2:0</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kW>7:4</td>
<td class=kT>3:3</td>
<td class=kW>4:2 K</td>
<td class=kW>5:0</td>
<td class=br>92:105</td><td class=br>-13</td>
<td class=bc>11 - 5 - 15</td>
<td class=br><strong>27</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Ra Miglinieks</td><td class=ic>LAT</td><td class=kL>2:6</td>
<td class=kW>3:2 K</td>
<td class=kL>2:5</td>
<td class=kL>1:6 K</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kW>6:1</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2 K</td>
<td class=kW>4:2</td>
<td class=kL>4:8</td>
<td class=kL>1:7</td>
<td class=kT>1:1</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=kW>5:1</td>
<td class=kL>3:4 K</td>
<td class=kT>3:3 K</td>
<td class=kL>2:7</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1 K</td>
<td class=br>71:100</td><td class=br>-29</td>
<td class=bc>11 - 5 - 15</td>
<td class=br><strong>27</strong></td><td class=d>24.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>25.</td><td class=kt>Pe Ostlund</td><td class=ic>SWE</td><td class=kL>2:6</td>
<td class=kL>1:4 K</td>
<td class=kW>4:2</td>
<td class=kL>1:2 K</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>2:5 K</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>4:5</td>
<td class=kL>1:7</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kW>5:2 K</td>
<td class=kT>2:2 K</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>3:2 K</td>
<td class=br>71:88</td><td class=br>-17</td>
<td class=bc>10 - 7 - 14</td>
<td class=br><strong>27</strong></td><td class=d>25.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>26.</td><td class=kt>Em Larsson</td><td class=ic>SWE</td><td class=kL>3:9</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>6:3 K</td>
<td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kW>4:2 K</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kT>2:2 K</td>
<td class=kL>2:3 K</td>
<td class=kT>4:4</td>
<td class=kT>3:3 K</td>
<td class=kT>4:4 K</td>
<td class=kW>6:4</td>
<td class=kL>3:7</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>3:2 K</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=br>70:118</td><td class=br>-48</td>
<td class=bc>8 - 5 - 18</td>
<td class=br><strong>21</strong></td><td class=d>26.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>27.</td><td class=kt>Kr Curkovic</td><td class=ic>CRO</td><td class=kL>2:8</td>
<td class=kL>1:6 K</td>
<td class=kL>4:7</td>
<td class=kL>0:3 K</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kL>4:7</td>
<td class=kL>2:5</td>
<td class=kL>2:9</td>
<td class=kL>0:4</td>
<td class=kL>3:5 K</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>3:5</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kW>5:1</td>
<td class=kW>4:3 K</td>
<td class=kL>2:5 K</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>6:4 K</td>
<td class=kL>3:5</td>
<td class=kW>3:0</td>
<td class=kT>4:4</td>
<td class=kW>4:3 K</td>
<td class=br>89:125</td><td class=br>-36</td>
<td class=bc>9 - 3 - 19</td>
<td class=br><strong>21</strong></td><td class=d>27.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>28.</td><td class=kt>Ma Saveljeva</td><td class=ic>EST</td><td class=kT>3:3</td>
<td class=kL>4:5 K</td>
<td class=kL>2:5</td>
<td class=kL>0:3 K</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kT>5:5</td>
<td class=kW>4:3 K</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kL>1:3</td>
<td class=kL>3:9</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=kT>3:3 K</td>
<td class=kT>2:2 K</td>
<td class=kL>3:4</td>
<td class=kL>4:6 K</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>10:5 K</td>
<td class=br>87:108</td><td class=br>-21</td>
<td class=bc>6 - 9 - 16</td>
<td class=br><strong>21</strong></td><td class=d>28.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>29.</td><td class=kt>Dm Petrov</td><td class=ic>RUS</td><td class=kW>3:2 K</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>5:8</td>
<td class=kL>2:6</td>
<td class=kW>4:3 K</td>
<td class=kL>1:3 K</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:4 K</td>
<td class=kL>3:8</td>
<td class=kL>1:2 K</td>
<td class=kW>8:1</td>
<td class=kW>4:2 K</td>
<td class=kL>0:1 K</td>
<td class=kL>4:7</td>
<td class=kW>7:2</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=br>84:109</td><td class=br>-25</td>
<td class=bc>8 - 3 - 20</td>
<td class=br><strong>19</strong></td><td class=d>29.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>30.</td><td class=kt>ml Chylík</td><td class=ic>CZE</td><td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>1:7</td>
<td class=kL>4:5</td>
<td class=kL>3:4</td>
<td class=kT>1:1 K</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>0:4 K</td>
<td class=kL>0:2</td>
<td class=kL>3:5</td>
<td class=kT>2:2 K</td>
<td class=kL>0:5 K</td>
<td class=kL>3:4</td>
<td class=kL>1:5 K</td>
<td class=kL>0:1 K</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kL>2:3 K</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kL>3:7</td>
<td class=kW>7:1</td>
<td class=br>55:102</td><td class=br>-47</td>
<td class=bc>3 - 7 - 21</td>
<td class=br><strong>13</strong></td><td class=d>30.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>31.</td><td class=kt>My Shalomayev</td><td class=ic>UKR</td><td class=kL>1:4</td>
<td class=kL>1:9</td>
<td class=kL>1:9 K</td>
<td class=kL>2:4</td>
<td class=kL>3:4 K</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>1:6 K</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kT>3:3 K</td>
<td class=kL>1:7</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kW>4:2 K</td>
<td class=kL>3:4</td>
<td class=kL>1:6 K</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>2:4 K</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kW>7:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=br>58:136</td><td class=br>-78</td>
<td class=bc>4 - 3 - 24</td>
<td class=br><strong>11</strong></td><td class=d>31.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>32.</td><td class=kt>Ge Regula</td><td class=ic>HUN</td><td class=kL>0:9</td>
<td class=kL>1:7 K</td>
<td class=kL>3:8</td>
<td class=kT>4:4 K</td>
<td class=kL>3:6</td>
<td class=kL>2:6</td>
<td class=kL>3:8</td>
<td class=kL>3:6</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kL>2:6 K</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kL>0:5</td>
<td class=kL>1:2 K</td>
<td class=kL>2:3 K</td>
<td class=kL>2:3</td>
<td class=kL>3:4 K</td>
<td class=kL>5:10 K</td>
<td class=kT>2:2</td>
<td class=kL>1:7</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=br>61:151</td><td class=br>-90</td>
<td class=bc>1 - 4 - 26</td>
<td class=br><strong>6</strong></td><td class=d>32.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Al Zaharov</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=bl>Ma Saveljeva</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=bl>Dm Malygin</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Pe Tměj</td><td class=bc>-</td><td class=bl>Kr Curkovic</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Lu Turoň</td><td class=bc>-</td><td class=blW>Gr Dubinin</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Pe Ostlund</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ed Mucenieks</td><td class=bc>-</td><td class=bl>Ja Pelkonen</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Nilsson</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ar Stolyarov</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Sa Sainio</td><td class=bc>-</td><td class=blW>Al Miloradov</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ti Valachovič</td><td class=bc>-</td><td class=bl>Al Titov</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>Ya Galuzo</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>Ma Saveljeva</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Dm Malygin</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Al Zaharov</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Kr Curkovic</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=blW>Gr Dubinin</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ke Eriksson</td><td class=bc>-</td><td class=bl>Pe Ostlund</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pe Tměj</td><td class=bc>-</td><td class=blW>Ma Nilsson</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Lu Turoň</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Klippen</td><td class=bc>-</td><td class=blW>Al Miloradov</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ed Mucenieks</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ya Galuzo</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ar Stolyarov</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Sa Sainio</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ti Valachovič</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Sa Sainio</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ti Valachovič</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Kr Curkovic</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Gr Dubinin</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Pe Ostlund</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Al Zaharov</td><td class=bc>-</td><td class=bl>Ja Pelkonen</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=bl>Ma Nilsson</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>Al Miloradov</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Pe Tměj</td><td class=bc>-</td><td class=blW>Ya Galuzo</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Lu Turoň</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Klippen</td><td class=bc>-</td><td class=blW>Ge Regula</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ed Mucenieks</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ma Saveljeva</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ar Stolyarov</td><td class=bc>-</td><td class=blW>Dm Malygin</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Kr Curkovic</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ar Stolyarov</td><td class=bc>-</td><td class=blW>Gr Dubinin</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Sa Sainio</td><td class=bc>-</td><td class=blW>Pe Ostlund</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ti Valachovič</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>Ma Nilsson</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Al Miloradov</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Al Zaharov</td><td class=bc>-</td><td class=bl>Al Titov</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Ya Galuzo</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pe Tměj</td><td class=bc>-</td><td class=bl>Ma Saveljeva</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Lu Turoň</td><td class=bc>-</td><td class=blW>Dm Malygin</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ed Mucenieks</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Kr Curkovic</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ed Mucenieks</td><td class=bc>-</td><td class=blW>Gr Dubinin</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Pe Ostlund</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ar Stolyarov</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Sa Sainio</td><td class=bc>-</td><td class=blW>Ma Nilsson</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ti Valachovič</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>Al Miloradov</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Al Titov</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Ya Galuzo</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Al Zaharov</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>Ma Saveljeva</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=bl>Dm Malygin</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pe Tměj</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Pe Tměj</td><td class=bc>-</td><td class=blW>Pe Ostlund</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ar Stolyarov</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Ma Nilsson</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ti Valachovič</td><td class=bc>-</td><td class=blW>Gr Dubinin</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Al Miloradov</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Sa Sainio</td><td class=bc>-</td><td class=blW>Ya Galuzo</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Al Zaharov</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Al Titov</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Saveljeva</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>Kr Curkovic</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Ed Mucenieks</td><td class=bc>-</td><td class=bl>Dm Malygin</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ke Eriksson</td><td class=bc>-</td><td class=blW>Ma Nilsson</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=blW>Gr Dubinin</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Pe Tměj</td><td class=bc>-</td><td class=blW>Al Miloradov</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Ja Pelkonen</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ma Klippen</td><td class=bc>-</td><td class=blW>Ya Galuzo</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Ed Mucenieks</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ar Stolyarov</td><td class=bc>-</td><td class=bl>Al Titov</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Sa Sainio</td><td class=bc>-</td><td class=blW>Ma Saveljeva</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ti Valachovič</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Kr Curkovic</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Al Zaharov</td><td class=bc>-</td><td class=bl>Dm Malygin</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Pe Ostlund</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Al Miloradov</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ja Pelkonen</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ke Eriksson</td><td class=bc>-</td><td class=blW>Ya Galuzo</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pe Tměj</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Al Titov</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Klippen</td><td class=bc>-</td><td class=bl>Ma Saveljeva</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ed Mucenieks</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ar Stolyarov</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Sa Sainio</td><td class=bc>-</td><td class=bl>Kr Curkovic</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ti Valachovič</td><td class=bc>-</td><td class=bl>Dm Malygin</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>Pe Ostlund</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Ma Nilsson</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Al Zaharov</td><td class=bc>-</td><td class=bl>Gr Dubinin</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ya Galuzo</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Al Miloradov</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Nilsson</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pe Ostlund</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Kr Curkovic</td><td class=bc>-</td><td class=blW>Gr Dubinin</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Saveljeva</td><td class=bc>-</td><td class=bl>Dm Malygin</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Al Zaharov</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pe Tměj</td><td class=bc>-</td><td class=bl>Lu Turoň</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Klippen</td><td class=bc>-</td><td class=blW>Ed Mucenieks</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Sa Sainio</td><td class=bc>-</td><td class=blW>Ti Valachovič</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ya Galuzo</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al Miloradov</td><td class=bc>-</td><td class=bl>Ja Pelkonen</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ma Nilsson</td><td class=bc>-</td><td class=bl>Gr Dubinin</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pe Ostlund</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Kr Curkovic</td><td class=bc>-</td><td class=blW>Dm Malygin</td><td class=bc>2 : 9</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ma Saveljeva</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>9 : 4</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Lu Turoň</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>Ed Mucenieks</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pe Tměj</td><td class=bc>-</td><td class=bl>Ar Stolyarov</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Klippen</td><td class=bc>-</td><td class=bl>Ti Valachovič</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Sa Sainio</td><td class=bc>-</td><td class=bl>Al Zaharov</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ma Saveljeva</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ya Galuzo</td><td class=bc>-</td><td class=bl>Gr Dubinin</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Al Miloradov</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Nilsson</td><td class=bc>-</td><td class=blW>Dm Malygin</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Pe Ostlund</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kr Curkovic</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Sa Sainio</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ed Mucenieks</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Ar Stolyarov</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>Ti Valachovič</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Pe Tměj</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Al Zaharov</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>4 : 8</tr></td>
<tr><td class=br>Ma Saveljeva</td><td class=bc>-</td><td class=blW>Gr Dubinin</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ya Galuzo</td><td class=bc>-</td><td class=bl>Dm Malygin</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Al Miloradov</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ma Nilsson</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pe Ostlund</td><td class=bc>-</td><td class=bl>Al Titov</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr Curkovic</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Sa Sainio</td><td class=bc>-</td><td class=bl>Ed Mucenieks</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ti Valachovič</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>Al Zaharov</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pe Tměj</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Klippen</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Kr Curkovic</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Gr Dubinin</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Saveljeva</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Dm Malygin</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ya Galuzo</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Miloradov</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ma Nilsson</td><td class=bc>-</td><td class=bl>Al Titov</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Pe Ostlund</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Klippen</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ed Mucenieks</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Sa Sainio</td><td class=bc>-</td><td class=bl>Ar Stolyarov</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>Ti Valachovič</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=bl>Al Zaharov</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Pe Tměj</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Pe Ostlund</td><td class=bc>-</td><td class=blW>Gr Dubinin</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kr Curkovic</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Dm Malygin</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Saveljeva</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ya Galuzo</td><td class=bc>-</td><td class=bl>Al Titov</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Al Miloradov</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Nilsson</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Pe Tměj</td><td class=bc>-</td><td class=blW>Ed Mucenieks</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Klippen</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Ti Valachovič</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Sa Sainio</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>Al Zaharov</td><td class=bc>5 : 8</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ke Eriksson</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ma Nilsson</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Pe Ostlund</td><td class=bc>-</td><td class=blW>Dm Malygin</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Kr Curkovic</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Saveljeva</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ya Galuzo</td><td class=bc>-</td><td class=bl>Ja Pelkonen</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Al Miloradov</td><td class=bc>-</td><td class=bl>Gr Dubinin</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ke Eriksson</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Pe Tměj</td><td class=bc>-</td><td class=bl>Ti Valachovič</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Al Zaharov</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Sa Sainio</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Lu Turoň</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=blW>Ed Mucenieks</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Pe Ostlund</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kr Curkovic</td><td class=bc>-</td><td class=bl>Al Titov</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Saveljeva</td><td class=bc>-</td><td class=bl>Ja Pelkonen</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Gr Dubinin</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ya Galuzo</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Al Miloradov</td><td class=bc>-</td><td class=blW>Dm Malygin</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Nilsson</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Pe Tměj</td><td class=bc>-</td><td class=bl>Al Zaharov</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Sa Sainio</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Ed Mucenieks</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Ti Valachovič</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Ya Galuzo</td><td class=bc>-</td><td class=blW>Al Zaharov</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Al Miloradov</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Titov</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ma Nilsson</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ke Eriksson</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pe Ostlund</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Pelkonen</td><td class=bc>-</td><td class=blW>Pe Tměj</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Kr Curkovic</td><td class=bc>-</td><td class=bl>Ed Mucenieks</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Gr Dubinin</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Em Larsson</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ma Saveljeva</td><td class=bc>-</td><td class=bl>Ti Valachovič</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Dm Malygin</td><td class=bc>-</td><td class=bl>Sa Sainio</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ya Galuzo</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=bl>Ke Eriksson</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Miloradov</td><td class=bc>-</td><td class=bl>Lu Turoň</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Al Titov</td><td class=bc>-</td><td class=bl>Pe Tměj</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Nilsson</td><td class=bc>-</td><td class=blW>Ed Mucenieks</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pe Ostlund</td><td class=bc>-</td><td class=bl>Ar Stolyarov</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kr Curkovic</td><td class=bc>-</td><td class=bl>Ti Valachovič</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Gr Dubinin</td><td class=bc>-</td><td class=blW>Sa Sainio</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ma Saveljeva</td><td class=bc>-</td><td class=blW>Al Zaharov</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Dm Malygin</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Ma Saveljeva</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Dm Malygin</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Pe Tměj</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ya Galuzo</td><td class=bc>-</td><td class=bl>Ed Mucenieks</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Al Miloradov</td><td class=bc>-</td><td class=bl>Ar Stolyarov</td><td class=bc>10 : 3</tr></td>
<tr><td class=br>Al Titov</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Nilsson</td><td class=bc>-</td><td class=blW>Ti Valachovič</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Sa Sainio</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pe Ostlund</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kr Curkovic</td><td class=bc>-</td><td class=blW>Al Zaharov</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gr Dubinin</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Em Larsson</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>3 : 9</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Pe Tměj</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Ma Saveljeva</td><td class=bc>-</td><td class=blW>Ed Mucenieks</td><td class=bc>3 : 9</tr></td>
<tr><td class=br>Dm Malygin</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ya Galuzo</td><td class=bc>-</td><td class=bl>Ti Valachovič</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Sa Sainio</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Al Miloradov</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Al Titov</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Nilsson</td><td class=bc>-</td><td class=blW>Al Zaharov</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pe Ostlund</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ja Pelkonen</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Kr Curkovic</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Gr Dubinin</td><td class=bc>-</td><td class=bl>Ke Eriksson</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Kr Curkovic</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Gr Dubinin</td><td class=bc>-</td><td class=blW>Pe Tměj</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ed Mucenieks</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Em Larsson</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Saveljeva</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Dm Malygin</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Ti Valachovič</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>Sa Sainio</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ya Galuzo</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Miloradov</td><td class=bc>-</td><td class=bl>Al Zaharov</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al Titov</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Nilsson</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pe Ostlund</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Pelkonen</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Pe Ostlund</td><td class=bc>-</td><td class=bl>Ed Mucenieks</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Kr Curkovic</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Gr Dubinin</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ti Valachovič</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Em Larsson</td><td class=bc>-</td><td class=blW>Sa Sainio</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ma Saveljeva</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Dm Malygin</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Al Zaharov</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ya Galuzo</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>4 : 8</tr></td>
<tr><td class=brW>Al Miloradov</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Al Titov</td><td class=bc>-</td><td class=bl>Ke Eriksson</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Nilsson</td><td class=bc>-</td><td class=bl>Lu Turoň</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Pe Tměj</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=brW>Ma Nilsson</td><td class=bc>-</td><td class=bl>Ar Stolyarov</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Pe Ostlund</td><td class=bc>-</td><td class=blW>Ti Valachovič</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ja Pelkonen</td><td class=bc>-</td><td class=blW>Sa Sainio</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr Curkovic</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Gr Dubinin</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Al Zaharov</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Em Larsson</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Saveljeva</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Dm Malygin</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ya Galuzo</td><td class=bc>-</td><td class=bl>Lu Turoň</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=blW>Pe Tměj</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Miloradov</td><td class=bc>-</td><td class=bl>Ed Mucenieks</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Al Titov</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=brW>Al Miloradov</td><td class=bc>-</td><td class=bl>Ti Valachovič</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Al Titov</td><td class=bc>-</td><td class=bl>Sa Sainio</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ma Nilsson</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Pe Ostlund</td><td class=bc>-</td><td class=bl>Al Zaharov</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ja Pelkonen</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Kr Curkovic</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Gr Dubinin</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Em Larsson</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ma Saveljeva</td><td class=bc>-</td><td class=bl>Lu Turoň</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Dm Malygin</td><td class=bc>-</td><td class=blW>Pe Tměj</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Ed Mucenieks</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ya Galuzo</td><td class=bc>-</td><td class=bl>Ar Stolyarov</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>2 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
