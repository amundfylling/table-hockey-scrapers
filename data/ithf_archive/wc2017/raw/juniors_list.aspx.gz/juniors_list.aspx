<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Juniors</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Juniors Participants</span></h2></div></div></div></div><h3 align="right">36 Participants&nbsp;&nbsp;</h3>
<p><div align="center">
<a href="Juniors_ranking.aspx">Final Rank.</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="Juniors_wr.aspx">WR Order</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="Juniors_krizB.aspx">Basic Groups</a>&nbsp;&nbsp;
<a href="Juniors_cross_1.aspx">J1</a>&nbsp;&nbsp;<a href="Juniors_cross_2.aspx">J2</a>&nbsp;&nbsp;<a href="Juniors_umisteni.aspx">Play-Off</a>&nbsp;&nbsp;&nbsp;<a href="Juniors_inter.aspx">International</a>&nbsp;&nbsp;&nbsp;

<a href="Juniors_off.aspx">Off.</a>&nbsp;&nbsp;&nbsp;
<a href="Juniors_def.aspx">Def.</a>


<br><br><table class="part_bck" align="center">
<tr><td><table class="part" width="100%">
<tr class="nat_head"><td class="nat_header" ><img src="../../ithf/ranking/flags/BLR.gif"></td><td class="nat_header" colspan="8">Belarus</td></tr>
<tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">34</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1727&x=300">Fiodar Kalinouski</a>&nbsp;</td><td class="plby">&nbsp;2005&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=666752">2738</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_2.aspx">J2</a></td><td class="bgr">17.</td><td class="bgp">2 pts</td><td class="bgs">19:89</td><td class="fg">&nbsp;</td></tr><tr class="nat_sum"><td class="nat_sum" colspan="9">17:&nbsp;&nbsp;&nbsp;1+&nbsp;&nbsp;&nbsp;0=&nbsp;&nbsp;&nbsp;16-</td></tr></table></td></tr>
<tr class="nil"><td class="nil" colspan="9">&nbsp;</td></tr>
<tr><td><table class="part" width="100%">
<tr class="nat_head"><td class="nat_header" ><img src="../../ithf/ranking/flags/CHI.gif"></td><td class="nat_header" colspan="8">Chile</td></tr>
<tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">36</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1732&x=300">Nicolas Cornelius</a>&nbsp;</td><td class="plby">&nbsp;2006&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=660701">4742</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_1.aspx">J1</a></td><td class="bgr">18.</td><td class="bgp">0 pts</td><td class="bgs">7:113</td><td class="fg">&nbsp;</td></tr><tr class="nat_sum"><td class="nat_sum" colspan="9">17:&nbsp;&nbsp;&nbsp;0+&nbsp;&nbsp;&nbsp;0=&nbsp;&nbsp;&nbsp;17-</td></tr></table></td></tr>
<tr class="nil"><td class="nil" colspan="9">&nbsp;</td></tr>
<tr><td><table class="part" width="100%">
<tr class="nat_head"><td class="nat_header" ><img src="../../ithf/ranking/flags/CZE.gif"></td><td class="nat_header" colspan="8">Czech Republic</td></tr>
<tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">5</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1477&x=300">Michal Kobrle</a>&nbsp;</td><td class="plby">&nbsp;1999&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=660939">82</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_1.aspx">J1</a></td><td class="bgr">2.</td><td class="bgp">29 pts</td><td class="bgs">75:32</td><td class="fg"><a href="Juniors_umisteni.aspx">p-o</a></td></tr><tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">20</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1251&x=300">Honza Sládek</a>&nbsp;</td><td class="plby">&nbsp;2000&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=655979">144</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_2.aspx">J2</a></td><td class="bgr">10.</td><td class="bgp">15 pts</td><td class="bgs">57:45</td><td class="fg">&nbsp;</td></tr><tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">22</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1406&x=300">Jakub Matýsek</a>&nbsp;</td><td class="plby">&nbsp;&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=659537">285</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_1.aspx">J1</a></td><td class="bgr">11.</td><td class="bgp">15 pts</td><td class="bgs">52:55</td><td class="fg">&nbsp;</td></tr><tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">24</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1118&x=300">Lukáš Kahoun</a>&nbsp;</td><td class="plby">&nbsp;1999&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=652647">349</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_2.aspx">J2</a></td><td class="bgr">12.</td><td class="bgp">12 pts</td><td class="bgs">40:82</td><td class="fg">&nbsp;</td></tr><tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">32</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1636&x=300">Vojtěch Bernát</a>&nbsp;</td><td class="plby">&nbsp;&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=667593">1515</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_2.aspx">J2</a></td><td class="bgr">16.</td><td class="bgp">5 pts</td><td class="bgs">33:108</td><td class="fg">&nbsp;</td></tr><tr class="nat_sum"><td class="nat_sum" colspan="9">91:&nbsp;&nbsp;&nbsp;36+&nbsp;&nbsp;&nbsp;8=&nbsp;&nbsp;&nbsp;47-</td></tr></table></td></tr>
<tr class="nil"><td class="nil" colspan="9">&nbsp;</td></tr>
<tr><td><table class="part" width="100%">
<tr class="nat_head"><td class="nat_header" ><img src="../../ithf/ranking/flags/EST.gif"></td><td class="nat_header" colspan="8">Estonia</td></tr>
<tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">31</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1736&x=300">Denis Andrijashkin</a>&nbsp;</td><td class="plby">&nbsp;2005&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=665760">1010</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_1.aspx">J1</a></td><td class="bgr">16.</td><td class="bgp">6 pts</td><td class="bgs">29:70</td><td class="fg">&nbsp;</td></tr><tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">30</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1733&x=300">Aleksandr Metelitsa</a>&nbsp;</td><td class="plby">&nbsp;1999&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=665762">1035</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_1.aspx">J1</a></td><td class="bgr">15.</td><td class="bgp">7 pts</td><td class="bgs">39:70</td><td class="fg">&nbsp;</td></tr><tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">29</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1735&x=300">Daniil Moshnin</a>&nbsp;</td><td class="plby">&nbsp;2002&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=661298">1340</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_2.aspx">J2</a></td><td class="bgr">15.</td><td class="bgp">8 pts</td><td class="bgs">35:87</td><td class="fg">&nbsp;</td></tr><tr class="nat_sum"><td class="nat_sum" colspan="9">51:&nbsp;&nbsp;&nbsp;9+&nbsp;&nbsp;&nbsp;3=&nbsp;&nbsp;&nbsp;39-</td></tr></table></td></tr>
<tr class="nil"><td class="nil" colspan="9">&nbsp;</td></tr>
<tr><td><table class="part" width="100%">
<tr class="nat_head"><td class="nat_header" ><img src="../../ithf/ranking/flags/FIN.gif"></td><td class="nat_header" colspan="8">Finland</td></tr>
<tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">11</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1615&x=300">Benjamin Suominen</a>&nbsp;</td><td class="plby">&nbsp;2002&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=661180">93</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_2.aspx">J2</a></td><td class="bgr">6.</td><td class="bgp">25 pts</td><td class="bgs">70:29</td><td class="fg">&nbsp;</td></tr><tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">26</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1745&x=300">Tiitus Roholm</a>&nbsp;</td><td class="plby">&nbsp;2006&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=664770">709</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_1.aspx">J1</a></td><td class="bgr">13.</td><td class="bgp">9 pts</td><td class="bgs">40:74</td><td class="fg">&nbsp;</td></tr><tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">25</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1744&x=300">Joonatan Roholm</a>&nbsp;</td><td class="plby">&nbsp;2005&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=664769">773</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_2.aspx">J2</a></td><td class="bgr">13.</td><td class="bgp">12 pts</td><td class="bgs">33:67</td><td class="fg">&nbsp;</td></tr><tr class="nat_sum"><td class="nat_sum" colspan="9">51:&nbsp;&nbsp;&nbsp;19+&nbsp;&nbsp;&nbsp;8=&nbsp;&nbsp;&nbsp;24-</td></tr></table></td></tr>
<tr class="nil"><td class="nil" colspan="9">&nbsp;</td></tr>
<tr><td><table class="part" width="100%">
<tr class="nat_head"><td class="nat_header" ><img src="../../ithf/ranking/flags/GER.gif"></td><td class="nat_header" colspan="8">Germany</td></tr>
<tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">13</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1750&x=300">Linus Restel</a>&nbsp;</td><td class="plby">&nbsp;2001&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=656269">210</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_2.aspx">J2</a></td><td class="bgr">7.</td><td class="bgp">23 pts</td><td class="bgs">71:35</td><td class="fg">&nbsp;</td></tr><tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">18</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1650&x=300">Valentin Dietze</a>&nbsp;</td><td class="plby">&nbsp;2000&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=658291">232</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_2.aspx">J2</a></td><td class="bgr">9.</td><td class="bgp">20 pts</td><td class="bgs">70:53</td><td class="fg">&nbsp;</td></tr><tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">21</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1374&x=300">Leon Haussknecht</a>&nbsp;</td><td class="plby">&nbsp;2000&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=651152">298</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_2.aspx">J2</a></td><td class="bgr">11.</td><td class="bgp">15 pts</td><td class="bgs">61:55</td><td class="fg">&nbsp;</td></tr><tr class="nat_sum"><td class="nat_sum" colspan="9">51:&nbsp;&nbsp;&nbsp;25+&nbsp;&nbsp;&nbsp;8=&nbsp;&nbsp;&nbsp;18-</td></tr></table></td></tr>
<tr class="nil"><td class="nil" colspan="9">&nbsp;</td></tr>
<tr><td><table class="part" width="100%">
<tr class="nat_head"><td class="nat_header" ><img src="../../ithf/ranking/flags/HUN.gif"></td><td class="nat_header" colspan="8">Hungary</td></tr>
<tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">33</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1752&x=300">Mátyás Papp</a>&nbsp;</td><td class="plby">&nbsp;2001&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=652116">1969</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_1.aspx">J1</a></td><td class="bgr">17.</td><td class="bgp">6 pts</td><td class="bgs">29:74</td><td class="fg">&nbsp;</td></tr><tr class="nat_sum"><td class="nat_sum" colspan="9">17:&nbsp;&nbsp;&nbsp;3+&nbsp;&nbsp;&nbsp;0=&nbsp;&nbsp;&nbsp;14-</td></tr></table></td></tr>
<tr class="nil"><td class="nil" colspan="9">&nbsp;</td></tr>
<tr><td><table class="part" width="100%">
<tr class="nat_head"><td class="nat_header" ><img src="../../ithf/ranking/flags/LAT.gif"></td><td class="nat_header" colspan="8">Latvia</td></tr>
<tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">4</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1649&x=300">Raivis Miglinieks</a>&nbsp;</td><td class="plby">&nbsp;2001&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=659307">41</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_2.aspx">J2</a></td><td class="bgr">2.</td><td class="bgp">29 pts</td><td class="bgs">66:25</td><td class="fg"><a href="Juniors_umisteni.aspx">p-o</a></td></tr><tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">15</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1763&x=300">Elians Edelis</a>&nbsp;</td><td class="plby">&nbsp;1999&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=653423">97</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_2.aspx">J2</a></td><td class="bgr">8.</td><td class="bgp">21 pts</td><td class="bgs">69:34</td><td class="fg">&nbsp;</td></tr><tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">16</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1761&x=300">Rainers Kalninš</a>&nbsp;</td><td class="plby">&nbsp;2002&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=655257">150</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_1.aspx">J1</a></td><td class="bgr">8.</td><td class="bgp">21 pts</td><td class="bgs">60:52</td><td class="fg">&nbsp;</td></tr><tr class="nat_sum"><td class="nat_sum" colspan="9">68:&nbsp;&nbsp;&nbsp;37+&nbsp;&nbsp;&nbsp;12=&nbsp;&nbsp;&nbsp;19-</td></tr></table></td></tr>
<tr class="nil"><td class="nil" colspan="9">&nbsp;</td></tr>
<tr><td><table class="part" width="100%">
<tr class="nat_head"><td class="nat_header" ><img src="../../ithf/ranking/flags/NOR.gif"></td><td class="nat_header" colspan="8">Norway</td></tr>
<tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">12</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1784&x=300">Magnus Klippen</a>&nbsp;</td><td class="plby">&nbsp;1999&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=660648">104</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_1.aspx">J1</a></td><td class="bgr">6.</td><td class="bgp">23 pts</td><td class="bgs">64:31</td><td class="fg">&nbsp;</td></tr><tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">9</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1786&x=300">Amund Risa Fylling</a>&nbsp;</td><td class="plby">&nbsp;1999&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=660869">147</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_2.aspx">J2</a></td><td class="bgr">5.</td><td class="bgp">25 pts</td><td class="bgs">64:32</td><td class="fg">&nbsp;</td></tr><tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">17</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1788&x=300">Oystein Klippen</a>&nbsp;</td><td class="plby">&nbsp;2001&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=660637">180</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_1.aspx">J1</a></td><td class="bgr">9.</td><td class="bgp">20 pts</td><td class="bgs">61:43</td><td class="fg">&nbsp;</td></tr><tr class="nat_sum"><td class="nat_sum" colspan="9">51:&nbsp;&nbsp;&nbsp;32+&nbsp;&nbsp;&nbsp;4=&nbsp;&nbsp;&nbsp;15-</td></tr></table></td></tr>
<tr class="nil"><td class="nil" colspan="9">&nbsp;</td></tr>
<tr><td><table class="part" width="100%">
<tr class="nat_head"><td class="nat_header" ><img src="../../ithf/ranking/flags/RUS.gif"></td><td class="nat_header" colspan="8">Russia</td></tr>
<tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">2</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1799&x=300">Nikita Zholobov</a>&nbsp;</td><td class="plby">&nbsp;2002&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=654600">11</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_1.aspx">J1</a></td><td class="bgr">1.</td><td class="bgp">34 pts</td><td class="bgs">102:19</td><td class="fg"><a href="Juniors_umisteni.aspx">p-o</a></td></tr><tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">8</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1804&x=300">Sergey Ivanov</a>&nbsp;</td><td class="plby">&nbsp;2002&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=659159">29</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_1.aspx">J1</a></td><td class="bgr">4.</td><td class="bgp">23 pts</td><td class="bgs">86:46</td><td class="fg"><a href="Juniors_umisteni.aspx">p-o</a></td></tr><tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">14</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1793&x=300">Dmitry Malygin</a>&nbsp;</td><td class="plby">&nbsp;2000&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=655973">37</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_1.aspx">J1</a></td><td class="bgr">7.</td><td class="bgp">22 pts</td><td class="bgs">64:42</td><td class="fg">&nbsp;</td></tr><tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">10</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1800&x=300">Denis Matveev</a>&nbsp;</td><td class="plby">&nbsp;1999&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=656846">101</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_1.aspx">J1</a></td><td class="bgr">5.</td><td class="bgp">23 pts</td><td class="bgs">82:33</td><td class="fg">&nbsp;</td></tr><tr class="nat_sum"><td class="nat_sum" colspan="9">91:&nbsp;&nbsp;&nbsp;60+&nbsp;&nbsp;&nbsp;8=&nbsp;&nbsp;&nbsp;23-</td></tr></table></td></tr>
<tr class="nil"><td class="nil" colspan="9">&nbsp;</td></tr>
<tr><td><table class="part" width="100%">
<tr class="nat_head"><td class="nat_header" ><img src="../../ithf/ranking/flags/SLO.gif"></td><td class="nat_header" colspan="8">Slovenia</td></tr>
<tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">27</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1813&x=300">Miha Skrlep</a>&nbsp;</td><td class="plby">&nbsp;2004&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=654663">991</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_2.aspx">J2</a></td><td class="bgr">14.</td><td class="bgp">9 pts</td><td class="bgs">36:73</td><td class="fg">&nbsp;</td></tr><tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">35</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1814&x=300">Mojca Skrlep</a>&nbsp;</td><td class="plby">&nbsp;2007&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=659599">2129</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_2.aspx">J2</a></td><td class="bgr">18.</td><td class="bgp">1 pts</td><td class="bgs">9:114</td><td class="fg">&nbsp;</td></tr><tr class="nat_sum"><td class="nat_sum" colspan="9">34:&nbsp;&nbsp;&nbsp;4+&nbsp;&nbsp;&nbsp;2=&nbsp;&nbsp;&nbsp;28-</td></tr></table></td></tr>
<tr class="nil"><td class="nil" colspan="9">&nbsp;</td></tr>
<tr><td><table class="part" width="100%">
<tr class="nat_head"><td class="nat_header" ><img src="../../ithf/ranking/flags/SWE.gif"></td><td class="nat_header" colspan="8">Sweden</td></tr>
<tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">1</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1829&x=300">Oscar Henriksson</a>&nbsp;</td><td class="plby">&nbsp;1999&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=656663">15</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_2.aspx">J2</a></td><td class="bgr">3.</td><td class="bgp">29 pts</td><td class="bgs">101:37</td><td class="fg"><a href="Juniors_umisteni.aspx">p-o</a></td></tr><tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">19</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1824&x=300">Uno Österman</a>&nbsp;</td><td class="plby">&nbsp;2005&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=659773">288</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_1.aspx">J1</a></td><td class="bgr">10.</td><td class="bgp">19 pts</td><td class="bgs">52:45</td><td class="fg">&nbsp;</td></tr><tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">23</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1825&x=300">Niklas Blomberg</a>&nbsp;</td><td class="plby">&nbsp;2004&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=664291">537</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_1.aspx">J1</a></td><td class="bgr">12.</td><td class="bgp">13 pts</td><td class="bgs">38:62</td><td class="fg">&nbsp;</td></tr><tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">28</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1826&x=300">Olof Blume</a>&nbsp;</td><td class="plby">&nbsp;2002&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=667180">1774</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_1.aspx">J1</a></td><td class="bgr">14.</td><td class="bgp">8 pts</td><td class="bgs">39:95</td><td class="fg">&nbsp;</td></tr><tr class="nat_sum"><td class="nat_sum" colspan="9">86:&nbsp;&nbsp;&nbsp;39+&nbsp;&nbsp;&nbsp;12=&nbsp;&nbsp;&nbsp;35-</td></tr></table></td></tr>
<tr class="nil"><td class="nil" colspan="9">&nbsp;</td></tr>
<tr><td><table class="part" width="100%">
<tr class="nat_head"><td class="nat_header" ><img src="../../ithf/ranking/flags/UKR.gif"></td><td class="nat_header" colspan="8">Ukraine</td></tr>
<tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">3</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1847&x=300">Dmytro Litvinyuk</a>&nbsp;</td><td class="plby">&nbsp;2000&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=659672">21</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_2.aspx">J2</a></td><td class="bgr">1.</td><td class="bgp">29 pts</td><td class="bgs">80:33</td><td class="fg"><a href="Juniors_umisteni.aspx">p-o</a></td></tr><tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">7</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1838&x=300">Evgeniy Matantsev</a>&nbsp;</td><td class="plby">&nbsp;2006&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=659673">39</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_2.aspx">J2</a></td><td class="bgr">4.</td><td class="bgp">26 pts</td><td class="bgs">122:38</td><td class="fg"><a href="Juniors_umisteni.aspx">p-o</a></td></tr><tr class="pl"><td class="fg"><a href="Juniors_ranking.aspx">6</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1518&x=300">Oleksii Korabel</a>&nbsp;</td><td class="plby">&nbsp;2003&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=653748">87</a>&nbsp;</td>
<td class="bg"><a href="Juniors_cross_1.aspx">J1</a></td><td class="bgr">3.</td><td class="bgp">28 pts</td><td class="bgs">72:35</td><td class="fg"><a href="Juniors_umisteni.aspx">p-o</a></td></tr><tr class="nat_sum"><td class="nat_sum" colspan="9">79:&nbsp;&nbsp;&nbsp;49+&nbsp;&nbsp;&nbsp;11=&nbsp;&nbsp;&nbsp;19-</td></tr></table></td></tr>
</table></div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
