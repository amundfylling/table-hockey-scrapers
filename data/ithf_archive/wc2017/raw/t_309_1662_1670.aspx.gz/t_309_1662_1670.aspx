<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Team Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Team Open : Sweden &nbsp;&nbsp;vs.&nbsp;&nbsp;Hungary &nbsp;&nbsp;21:3</span></h2></div></div></div></div><h3 align="right">Round: 6&nbsp;&nbsp;</h3>
<p><div align="center">
<table border=1 cellpadding="0" cellspacing="0" ><tr>
<table border="0" cellpadding="1" cellspacing="0" width="95%"><tr><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Oscar Henriksson<br>3-0-0 (21:4)</td></tr>
<tr><td class="k">Markus Nilsson<br>4-0-0 (19:7)</td></tr>
<tr><td class="k">Joakim Lundin<br>4-0-1 (25:8)</td></tr>
<tr><td class="k">Rickard Sjöstedt<br>2-1-0 (10:4)</td></tr>
<tr><td class="k">Fidde Hansson<br>4-0-1 (24:8)</td></tr>
<tr><td class="k">Fredric Axelsson<br>2-0-0 (7:2)</td></tr>
<tr><td class="k">Anders Ekestubbe<br>1-0-1 (6:5)</td></tr>
<tr><td class="k">Martin Lunden<br>1-0-0 (6:0)</td></tr>
</table></td>
<td valign="top"><table border="0" cellspacing="0" cellpadding="0" width="100%"><tr><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 1</td></tr>
<tr><td class="hrac_sk_v">Oscar Henriksson</td><td class="vysledek" width="60">&nbsp; 6 : 1 &nbsp;</td><td class="hrac_sk">Viktor Magyari</td></tr>
<tr><td class="hrac_sk_v">Markus Nilsson</td><td class="vysledek" width="60">&nbsp; 4 : 2 &nbsp;</td><td class="hrac_sk">Gergely Regula</td></tr>
<tr><td class="hrac_sk_v">Joakim Lundin</td><td class="vysledek" width="60">&nbsp; 6 : 1 &nbsp;</td><td class="hrac_sk">András Naszádi</td></tr>
<tr><td class="hrac_sk_v">Rickard Sjöstedt</td><td class="vysledek" width="60">&nbsp; 2 : 1 &nbsp;</td><td class="hrac_sk">Peter Borsanyi</td></tr>
<tr><td class="hrac_sk_v">Fidde Hansson</td><td class="vysledek" width="60">&nbsp; 6 : 0 &nbsp;</td><td class="hrac_sk">Mátyás Papp</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;5:0</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 2</td></tr>
<tr><td class="hrac_sk_v">Fidde Hansson</td><td class="vysledek" width="60">&nbsp; 5 : 1 &nbsp;</td><td class="hrac_sk">Gergely Regula</td></tr>
<tr><td class="hrac_sk_v">Oscar Henriksson</td><td class="vysledek" width="60">&nbsp; 7 : 1 &nbsp;</td><td class="hrac_sk">András Naszádi</td></tr>
<tr><td class="hrac_sk_v">Markus Nilsson</td><td class="vysledek" width="60">&nbsp; 6 : 2 &nbsp;</td><td class="hrac_sk">Peter Borsanyi</td></tr>
<tr><td class="hrac_sk_v">Joakim Lundin</td><td class="vysledek" width="60">&nbsp; 6 : 1 &nbsp;</td><td class="hrac_sk">Mátyás Papp</td></tr>
<tr><td class="hrac_sk">Rickard Sjöstedt</td><td class="vysledek" width="60">&nbsp; 3 : 3 &nbsp;</td><td class="hrac_sk">Viktor Magyari</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;9:0</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td>
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 3</td></tr>
<tr><td class="hrac_sk_v">Rickard Sjöstedt</td><td class="vysledek" width="60">&nbsp; 5 : 0 &nbsp;</td><td class="hrac_sk">András Naszádi</td></tr>
<tr><td class="hrac_sk_v">Fidde Hansson</td><td class="vysledek" width="60">&nbsp; 6 : 1 &nbsp;</td><td class="hrac_sk">Peter Borsanyi</td></tr>
<tr><td class="hrac_sk_v">Oscar Henriksson</td><td class="vysledek" width="60">&nbsp; 8 : 2 &nbsp;</td><td class="hrac_sk">Mátyás Papp</td></tr>
<tr><td class="hrac_sk_v">Markus Nilsson</td><td class="vysledek" width="60">&nbsp; 5 : 1 &nbsp;</td><td class="hrac_sk">Viktor Magyari</td></tr>
<tr><td class="hrac_sk">Joakim Lundin</td><td class="vysledek" width="60">&nbsp; 3 : 4 &nbsp;</td><td class="hrac_sk_v">Gergely Regula</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;13:1</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 4</td></tr>
<tr><td class="hrac_sk_v">Joakim Lundin</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">Peter Borsanyi</td></tr>
<tr><td class="hrac_sk_v">Fredric Axelsson</td><td class="vysledek" width="60">&nbsp; 4 : 2 &nbsp;</td><td class="hrac_sk">Mátyás Papp</td></tr>
<tr><td class="hrac_sk">Fidde Hansson</td><td class="vysledek" width="60">&nbsp; 1 : 2 &nbsp;</td><td class="hrac_sk_v">Viktor Magyari</td></tr>
<tr><td class="hrac_sk">Anders Ekestubbe</td><td class="vysledek" width="60">&nbsp; 3 : 5 &nbsp;</td><td class="hrac_sk_v">Gergely Regula</td></tr>
<tr><td class="hrac_sk_v">Markus Nilsson</td><td class="vysledek" width="60">&nbsp; 4 : 2 &nbsp;</td><td class="hrac_sk">András Naszádi</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;16:3</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td align="center" colspan="3">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 5</td></tr>
<tr><td class="hrac_sk_v">Martin Lunden</td><td class="vysledek" width="60">&nbsp; 6 : 0 &nbsp;</td><td class="hrac_sk">Mátyás Papp</td></tr>
<tr><td class="hrac_sk_v">Joakim Lundin</td><td class="vysledek" width="60">&nbsp; 6 : 1 &nbsp;</td><td class="hrac_sk">Viktor Magyari</td></tr>
<tr><td class="hrac_sk_v">Fredric Axelsson</td><td class="vysledek" width="60">&nbsp; 3 : 0 &nbsp;</td><td class="hrac_sk">Gergely Regula</td></tr>
<tr><td class="hrac_sk_v">Fidde Hansson</td><td class="vysledek" width="60">&nbsp; 6 : 4 &nbsp;</td><td class="hrac_sk">András Naszádi</td></tr>
<tr><td class="hrac_sk_v">Anders Ekestubbe</td><td class="vysledek" width="60">&nbsp; 3 : 0 &nbsp;</td><td class="hrac_sk">Peter Borsanyi</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;21:3</td></tr></table>
</td></tr></table></td><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Viktor Magyari<br>1-1-3 (8:21)</td></tr>
<tr><td class="k">Gergely Regula<br>2-0-3 (12:18)</td></tr>
<tr><td class="k">András Naszádi<br>0-0-5 (8:28)</td></tr>
<tr><td class="k">Peter Borsanyi<br>0-0-5 (5:21)</td></tr>
<tr><td class="k">Mátyás Papp<br>0-0-5 (5:30)</td></tr>
</table></td></tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
