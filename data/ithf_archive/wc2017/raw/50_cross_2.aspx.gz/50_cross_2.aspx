<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>50+</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>50+ </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 50+ 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>An Ekestubbe</td><td class=ic>SWE</td><td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>7:1</td>
<td class=br>44:19</td><td class=br>+25</td>
<td class=bc>8 - 1 - 1</td>
<td class=br><strong>17</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Mi Borgh</td><td class=ic>SWE</td><td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kW>5:0</td>
<td class=br>33:24</td><td class=br>+9</td>
<td class=bc>7 - 1 - 2</td>
<td class=br><strong>15</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ar Vitols</td><td class=ic>LAT</td><td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>9:2</td>
<td class=kW>4:1</td>
<td class=br>33:20</td><td class=br>+13</td>
<td class=bc>7 - 0 - 3</td>
<td class=br><strong>14</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Je Wikström</td><td class=ic>SWE</td><td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>5:4</td>
<td class=kW>8:0</td>
<td class=br>36:21</td><td class=br>+15</td>
<td class=bc>5 - 2 - 3</td>
<td class=br><strong>12</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt>An Šrajer</td><td class=ic>CZE</td><td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=br>25:24</td><td class=br>+1</td>
<td class=bc>5 - 1 - 4</td>
<td class=br><strong>11</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt>Fr Marek</td><td class=ic>CZE</td><td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=br>24:26</td><td class=br>-2</td>
<td class=bc>4 - 1 - 5</td>
<td class=br><strong>9</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Vá Pikl</td><td class=ic>CZE</td><td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>13:1</td>
<td class=kL>1:2</td>
<td class=br>38:23</td><td class=br>+15</td>
<td class=bc>4 - 1 - 5</td>
<td class=br><strong>9</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Sa Skarainis</td><td class=ic>LAT</td><td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=br>25:31</td><td class=br>-6</td>
<td class=bc>3 - 2 - 5</td>
<td class=br><strong>8</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>C</td><td class=d>9.</td><td class=kt>Si Wikström</td><td class=ic>SWE</td><td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>1:7</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=br>23:34</td><td class=br>-11</td>
<td class=bc>3 - 1 - 6</td>
<td class=br><strong>7</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>C</td><td class=d>10.</td><td class=kt>He Petuch</td><td class=ic>GER</td><td class=kL>2:7</td>
<td class=kW>6:2</td>
<td class=kL>2:9</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kW>5:3</td>
<td class=kL>1:13</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=br>27:52</td><td class=br>-25</td>
<td class=bc>3 - 0 - 7</td>
<td class=br><strong>6</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>Pe Sládek</td><td class=ic>CZE</td><td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:8</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=br>10:44</td><td class=br>-34</td>
<td class=bc>1 - 0 - 9</td>
<td class=br><strong>2</strong></td><td class=d>11.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Mi Borgh</td><td class=bc>-</td><td class=blW>Je Wikström</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Si Wikström</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>Ar Vitols</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>An Šrajer</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Pe Sládek</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Je Wikström</td><td class=bc>-</td><td class=bl>Si Wikström</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>Ar Vitols</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>An Šrajer</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Pe Sládek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Si Wikström</td><td class=bc>-</td><td class=blW>Ar Vitols</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Je Wikström</td><td class=bc>-</td><td class=blW>An Šrajer</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>Pe Sládek</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ar Vitols</td><td class=bc>-</td><td class=bl>An Šrajer</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Si Wikström</td><td class=bc>-</td><td class=bl>Pe Sládek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Je Wikström</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>Vá Pikl</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>An Šrajer</td><td class=bc>-</td><td class=bl>Pe Sládek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ar Vitols</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Si Wikström</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Je Wikström</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Mi Borgh</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>An Šrajer</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ar Vitols</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Si Wikström</td><td class=bc>-</td><td class=blW>Fr Marek</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Je Wikström</td><td class=bc>-</td><td class=bl>An Ekestubbe</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Vá Pikl</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>An Šrajer</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ar Vitols</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Si Wikström</td><td class=bc>-</td><td class=bl>Mi Borgh</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Vá Pikl</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>13 : 1</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>An Šrajer</td><td class=bc>-</td><td class=blW>Mi Borgh</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ar Vitols</td><td class=bc>-</td><td class=bl>Je Wikström</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Fr Marek</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Mi Borgh</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=blW>Je Wikström</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>An Šrajer</td><td class=bc>-</td><td class=bl>Si Wikström</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Fr Marek</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Mi Borgh</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=bl>Je Wikström</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Si Wikström</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=blW>Ar Vitols</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>An Ekestubbe</td><td class=bc>-</td><td class=blW>Mi Borgh</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Fr Marek</td><td class=bc>-</td><td class=bl>Je Wikström</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Si Wikström</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vá Pikl</td><td class=bc>-</td><td class=blW>Ar Vitols</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>An Šrajer</td><td class=bc>2 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
