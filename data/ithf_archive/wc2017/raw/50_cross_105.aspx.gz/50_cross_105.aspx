<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>50+</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>50+ </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 50+ C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Gi Remeika</td><td class=ic>LTU</td><td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kW>4:2 K</td>
<td class=kW>5:0 K</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>5:0 K</td>
<td class=kW>5:0 K</td>
<td class=kW>5:0 K</td>
<td class=br>31:9</td><td class=br>+22</td>
<td class=bc>7 - 1 - 1</td>
<td class=br><strong>15</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Mi Mareš st.</td><td class=ic>CZE</td><td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kL>2:8 K</td>
<td class=kW>4:0</td>
<td class=kW>3:0 K</td>
<td class=kW>5:0 K</td>
<td class=kW>5:0 K</td>
<td class=kW>5:0 K</td>
<td class=br>29:11</td><td class=br>+18</td>
<td class=bc>7 - 0 - 2</td>
<td class=br><strong>14</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>He Petuch</td><td class=ic>GER</td><td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kW>5:0</td>
<td class=kW>5:1 K</td>
<td class=kW>5:0</td>
<td class=kW>5:0 K</td>
<td class=kW>5:0 K</td>
<td class=kW>5:0 K</td>
<td class=br>39:9</td><td class=br>+30</td>
<td class=bc>7 - 0 - 2</td>
<td class=br><strong>14</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Su Pössl</td><td class=ic>SWE</td><td class=kL>2:4 K</td>
<td class=kL>0:2</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kW>5:0 K</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>5:0 K</td>
<td class=kW>5:0 K</td>
<td class=kW>5:0 K</td>
<td class=br>33:11</td><td class=br>+22</td>
<td class=bc>6 - 1 - 2</td>
<td class=br><strong>13</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>An Kniaziuk</td><td class=ic>BLR</td><td class=kL>0:5 K</td>
<td class=kW>8:2 K</td>
<td class=kL>0:5</td>
<td class=kL>0:5 K</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>4:1 K</td>
<td class=kW>5:0 K</td>
<td class=kW>5:0 K</td>
<td class=kW>5:0 K</td>
<td class=br>32:18</td><td class=br>+14</td>
<td class=bc>6 - 0 - 3</td>
<td class=br><strong>12</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Pe Sládek</td><td class=ic>CZE</td><td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kL>1:5 K</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>5:0 K</td>
<td class=kW>5:0 K</td>
<td class=kW>5:0 K</td>
<td class=br>21:17</td><td class=br>+4</td>
<td class=bc>4 - 2 - 3</td>
<td class=br><strong>10</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Gy Regula</td><td class=ic>HUN</td><td class=kL>0:3</td>
<td class=kL>0:3 K</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>1:4 K</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>5:0 K</td>
<td class=kW>5:0 K</td>
<td class=kW>5:0 K</td>
<td class=br>16:21</td><td class=br>-5</td>
<td class=bc>3 - 0 - 6</td>
<td class=br><strong>6</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Si Wikström</td><td class=ic>SWE</td><td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kx>*</td>
<td class=kW>5:0 K</td>
<td class=kW>5:0 K</td>
<td class=br>10:35</td><td class=br>-25</td>
<td class=bc>2 - 0 - 7</td>
<td class=br><strong>4</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Be Kunzler</td><td class=ic>CAN</td><td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kx>*</td>
<td class=kW>5:0 K</td>
<td class=br>5:40</td><td class=br>-35</td>
<td class=bc>1 - 0 - 8</td>
<td class=br><strong>2</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ro Milovanovič</td><td class=ic>SRB</td><td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kx>*</td>
<td class=br>0:45</td><td class=br>-45</td>
<td class=bc>0 - 0 - 9</td>
<td class=br><strong>0</strong></td><td class=d>10.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Gi Remeika</td><td class=bc>-</td><td class=bl>Si Wikström</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Su Pössl</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Pe Sládek</td><td class=bc>-</td><td class=bl>Gy Regula</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ro Milovanovič</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Gy Regula</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Gi Remeika</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Su Pössl</td><td class=bc>-</td><td class=bl>Si Wikström</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Pe Sládek</td><td class=bc>-</td><td class=bl>Ro Milovanovič</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>Mi Mareš st.</td><td class=bc>0 : 5 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ro Milovanovič</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Mi Mareš st.</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Su Pössl</td><td class=bc>-</td><td class=bl>Gy Regula</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>Si Wikström</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=blW>An Kniaziuk</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Si Wikström</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=blW>Mi Mareš st.</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Gi Remeika</td><td class=bc>-</td><td class=bl>Gy Regula</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Su Pössl</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Be Kunzler</td><td class=bc>-</td><td class=bl>Ro Milovanovič</td><td class=bc>5 : 0 K</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Su Pössl</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>An Kniaziuk</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Gy Regula</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Milovanovič</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Mi Mareš st.</td><td class=bc>-</td><td class=bl>Si Wikström</td><td class=bc>5 : 0 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Mi Mareš st.</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ro Milovanovič</td><td class=bc>-</td><td class=blW>Si Wikström</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=bl>Su Pössl</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Gy Regula</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Pe Sládek</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Si Wikström</td><td class=bc>-</td><td class=blW>An Kniaziuk</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Gy Regula</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mi Mareš st.</td><td class=bc>-</td><td class=blW>Gi Remeika</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Milovanovič</td><td class=bc>-</td><td class=blW>Su Pössl</td><td class=bc>0 : 5 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ro Milovanovič</td><td class=bc>-</td><td class=blW>Gi Remeika</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Mi Mareš st.</td><td class=bc>-</td><td class=bl>Su Pössl</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Pe Sládek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Si Wikström</td><td class=bc>-</td><td class=blW>Gy Regula</td><td class=bc>0 : 5 K</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
