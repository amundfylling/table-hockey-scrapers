<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Team Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Team Open : Czech Republic &nbsp;&nbsp;vs.&nbsp;&nbsp;Estonia &nbsp;&nbsp;18:4</span></h2></div></div></div></div><h3 align="right">Round: 6&nbsp;&nbsp;</h3>
<p><div align="center">
<table border=1 cellpadding="0" cellspacing="0" ><tr>
<table border="0" cellpadding="1" cellspacing="0" width="95%"><tr><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Patrik Petr<br>2-0-0 (7:2)</td></tr>
<tr><td class="k">Zdeněk Matoušek ml.<br>3-0-2 (12:11)</td></tr>
<tr><td class="k">Leoš Hvižď ml.<br>1-0-0 (5:1)</td></tr>
<tr><td class="k">Lukáš Turoň<br>3-0-0 (20:3)</td></tr>
<tr><td class="k">Michal Hvižď<br>2-0-0 (12:1)</td></tr>
<tr><td class="k">Jan Dryák<br>2-1-1 (16:9)</td></tr>
<tr><td class="k">Kryštof Lebl<br>1-1-1 (6:4)</td></tr>
<tr><td class="k">Michal Kobrle<br>2-1-0 (15:7)</td></tr>
<tr><td class="k">Filip Hamáček<br>2-0-0 (7:3)</td></tr>
</table></td>
<td valign="top"><table border="0" cellspacing="0" cellpadding="0" width="100%"><tr><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 1</td></tr>
<tr><td class="hrac_sk_v">Patrik Petr</td><td class="vysledek" width="60">&nbsp; 3 : 1 &nbsp;</td><td class="hrac_sk">Daniil Moshnin</td></tr>
<tr><td class="hrac_sk_v">Zdeněk Matoušek ml.</td><td class="vysledek" width="60">&nbsp; 2 : 1 &nbsp;</td><td class="hrac_sk">Mark-Julius Pikat</td></tr>
<tr><td class="hrac_sk_v">Leoš Hvižď ml.</td><td class="vysledek" width="60">&nbsp; 5 : 1 &nbsp;</td><td class="hrac_sk">Aleksandr Metelitsa</td></tr>
<tr><td class="hrac_sk_v">Lukáš Turoň</td><td class="vysledek" width="60">&nbsp; 3 : 2 &nbsp;</td><td class="hrac_sk">Yuri Artamonov</td></tr>
<tr><td class="hrac_sk_v">Michal Hvižď</td><td class="vysledek" width="60">&nbsp; 6 : 0 &nbsp;</td><td class="hrac_sk">Vafa Hamdamov</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;5:0</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 2</td></tr>
<tr><td class="hrac_sk_v">Michal Hvižď</td><td class="vysledek" width="60">&nbsp; 6 : 1 &nbsp;</td><td class="hrac_sk">Mark-Julius Pikat</td></tr>
<tr><td class="hrac_sk_v">Patrik Petr</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">Aleksandr Metelitsa</td></tr>
<tr><td class="hrac_sk_v">Zdeněk Matoušek ml.</td><td class="vysledek" width="60">&nbsp; 3 : 1 &nbsp;</td><td class="hrac_sk">Yuri Artamonov</td></tr>
<tr><td class="hrac_sk_v">Jan Dryák</td><td class="vysledek" width="60">&nbsp; 5 : 2 &nbsp;</td><td class="hrac_sk">Vafa Hamdamov</td></tr>
<tr><td class="hrac_sk_v">Lukáš Turoň</td><td class="vysledek" width="60">&nbsp; 5 : 1 &nbsp;</td><td class="hrac_sk">Daniil Moshnin</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;10:0</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td>
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 3</td></tr>
<tr><td class="hrac_sk_v">Lukáš Turoň</td><td class="vysledek" width="60">&nbsp; 12 : 0 &nbsp;</td><td class="hrac_sk">Aleksandr Metelitsa</td></tr>
<tr><td class="hrac_sk">Kryštof Lebl</td><td class="vysledek" width="60">&nbsp; 0 : 1 &nbsp;</td><td class="hrac_sk_v">Yuri Artamonov</td></tr>
<tr><td class="hrac_sk_v">Michal Kobrle</td><td class="vysledek" width="60">&nbsp; 7 : 0 &nbsp;</td><td class="hrac_sk">Vafa Hamdamov</td></tr>
<tr><td class="hrac_sk_v">Zdeněk Matoušek ml.</td><td class="vysledek" width="60">&nbsp; 3 : 1 &nbsp;</td><td class="hrac_sk">Daniil Moshnin</td></tr>
<tr><td class="hrac_sk_v">Jan Dryák</td><td class="vysledek" width="60">&nbsp; 7 : 1 &nbsp;</td><td class="hrac_sk">Mark-Julius Pikat</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;14:1</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 4</td></tr>
<tr><td class="hrac_sk">Jan Dryák</td><td class="vysledek" width="60">&nbsp; 1 : 3 &nbsp;</td><td class="hrac_sk_v">Yuri Artamonov</td></tr>
<tr><td class="hrac_sk_v">Filip Hamáček</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">Jevgeni Lvov</td></tr>
<tr><td class="hrac_sk">Kryštof Lebl</td><td class="vysledek" width="60">&nbsp; 2 : 2 &nbsp;</td><td class="hrac_sk">Maria Saveljeva</td></tr>
<tr><td class="hrac_sk_v">Michal Kobrle</td><td class="vysledek" width="60">&nbsp; 4 : 3 &nbsp;</td><td class="hrac_sk">Alen Shekarev</td></tr>
<tr><td class="hrac_sk">Zdeněk Matoušek ml.</td><td class="vysledek" width="60">&nbsp; 1 : 3 &nbsp;</td><td class="hrac_sk_v">Igor Saveljev</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;16:3</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td align="center" colspan="3">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 5</td></tr>
<tr><td class="hrac_sk">Zdeněk Matoušek ml.</td><td class="vysledek" width="60">&nbsp; 3 : 5 &nbsp;</td><td class="hrac_sk_v">Jevgeni Lvov</td></tr>
<tr><td class="hrac_sk">Jan Dryák</td><td class="vysledek" width="60">&nbsp; 3 : 3 &nbsp;</td><td class="hrac_sk">Maria Saveljeva</td></tr>
<tr><td class="hrac_sk_v">Filip Hamáček</td><td class="vysledek" width="60">&nbsp; 3 : 2 &nbsp;</td><td class="hrac_sk">Alen Shekarev</td></tr>
<tr><td class="hrac_sk_v">Kryštof Lebl</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">Igor Saveljev</td></tr>
<tr><td class="hrac_sk">Michal Kobrle</td><td class="vysledek" width="60">&nbsp; 4 : 4 &nbsp;</td><td class="hrac_sk">Yuri Artamonov</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;18:4</td></tr></table>
</td></tr></table></td><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Daniil Moshnin<br>0-0-3 (3:11)</td></tr>
<tr><td class="k">Mark-Julius Pikat<br>0-0-3 (3:15)</td></tr>
<tr><td class="k">Aleksandr Metelitsa<br>0-0-3 (2:21)</td></tr>
<tr><td class="k">Yuri Artamonov<br>2-1-2 (11:11)</td></tr>
<tr><td class="k">Vafa Hamdamov<br>0-0-3 (2:18)</td></tr>
<tr><td class="k">Jevgeni Lvov<br>1-0-1 (6:7)</td></tr>
<tr><td class="k">Maria Saveljeva<br>0-2-0 (5:5)</td></tr>
<tr><td class="k">Alen Shekarev<br>0-0-2 (5:7)</td></tr>
<tr><td class="k">Igor Saveljev<br>1-0-1 (4:5)</td></tr>
</table></td></tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
