<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Veterans</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Veterans </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group VA1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Bj Axelsen</td><td class=ic>DEN</td><td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>6:1 K</td>
<td class=kL>0:2</td>
<td class=kW>5:0</td>
<td class=kW>3:2 K</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kL>2:5 K</td>
<td class=kW>5:2 K</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1</td>
<td class=br>36:18</td><td class=br>+18</td>
<td class=bc>7 - 2 - 2</td>
<td class=br><strong>16</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>St Lutay</td><td class=ic>RUS</td><td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:3 K</td>
<td class=kW>2:1 K</td>
<td class=kW>5:3</td>
<td class=kT>1:1 K</td>
<td class=kT>1:1 K</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1 K</td>
<td class=br>29:23</td><td class=br>+6</td>
<td class=bc>6 - 3 - 2</td>
<td class=br><strong>15</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Yn Aasheim</td><td class=ic>NOR</td><td class=kL>1:6 K</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kW>5:2</td>
<td class=kT>3:3 K</td>
<td class=kW>2:1</td>
<td class=kL>2:6</td>
<td class=kW>3:2 K</td>
<td class=kW>4:3 K</td>
<td class=kL>2:6 K</td>
<td class=kW>5:2</td>
<td class=br>35:33</td><td class=br>+2</td>
<td class=bc>6 - 2 - 3</td>
<td class=br><strong>14</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Al Titov</td><td class=ic>RUS</td><td class=kW>2:0</td>
<td class=kL>3:4 K</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>4:1 K</td>
<td class=kL>0:2</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1 K</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1 K</td>
<td class=br>23:24</td><td class=br>-1</td>
<td class=bc>5 - 3 - 3</td>
<td class=br><strong>13</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ki Eriksson</td><td class=ic>FIN</td><td class=kL>0:5</td>
<td class=kL>1:2 K</td>
<td class=kL>2:5</td>
<td class=kL>1:4 K</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1 K</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>3:2 K</td>
<td class=br>27:28</td><td class=br>-1</td>
<td class=bc>6 - 1 - 4</td>
<td class=br><strong>13</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Da Matýsek</td><td class=ic>CZE</td><td class=kL>2:3 K</td>
<td class=kL>3:5</td>
<td class=kT>3:3 K</td>
<td class=kW>2:0</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kT>1:1 K</td>
<td class=kL>2:3 K</td>
<td class=kL>0:3 K</td>
<td class=kW>5:1</td>
<td class=br>23:24</td><td class=br>-1</td>
<td class=bc>4 - 2 - 5</td>
<td class=br><strong>10</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Al Chernov</td><td class=ic>RUS</td><td class=kL>1:6</td>
<td class=kT>1:1 K</td>
<td class=kL>1:2</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2 K</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kT>2:2 K</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kT>1:1 K</td>
<td class=br>22:22</td><td class=br>0</td>
<td class=bc>2 - 6 - 3</td>
<td class=br><strong>10</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ig Masloboev</td><td class=ic>RUS</td><td class=kT>1:1</td>
<td class=kT>1:1 K</td>
<td class=kW>6:2</td>
<td class=kL>1:2 K</td>
<td class=kL>1:2 K</td>
<td class=kL>1:3</td>
<td class=kT>2:2 K</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kL>1:5</td>
<td class=kW>5:1 K</td>
<td class=br>23:21</td><td class=br>+2</td>
<td class=bc>3 - 4 - 4</td>
<td class=br><strong>10</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Es Moe</td><td class=ic>NOR</td><td class=kW>5:2 K</td>
<td class=kW>4:3</td>
<td class=kL>2:3 K</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1 K</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>0:4 K</td>
<td class=kW>3:0 K</td>
<td class=kW>1:0</td>
<td class=br>22:26</td><td class=br>-4</td>
<td class=bc>4 - 2 - 5</td>
<td class=br><strong>10</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Pe Ostlund</td><td class=ic>SWE</td><td class=kL>2:5 K</td>
<td class=kL>2:5</td>
<td class=kL>3:4 K</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>3:2 K</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>4:0 K</td>
<td class=kx>*</td>
<td class=kW>6:4 K</td>
<td class=kW>5:2</td>
<td class=br>34:35</td><td class=br>-1</td>
<td class=bc>4 - 1 - 6</td>
<td class=br><strong>9</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Vi Sapozhnikov</td><td class=ic>UKR</td><td class=kT>2:2 K</td>
<td class=kL>1:3</td>
<td class=kW>6:2 K</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kW>3:0 K</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kL>0:3 K</td>
<td class=kL>4:6 K</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=br>30:32</td><td class=br>-2</td>
<td class=bc>3 - 3 - 5</td>
<td class=br><strong>9</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Si Thomas</td><td class=ic>IRL</td><td class=kL>1:2</td>
<td class=kL>1:2 K</td>
<td class=kL>2:5</td>
<td class=kT>1:1 K</td>
<td class=kL>2:3 K</td>
<td class=kL>1:5</td>
<td class=kT>1:1 K</td>
<td class=kL>1:5 K</td>
<td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=br>16:34</td><td class=br>-18</td>
<td class=bc>0 - 3 - 8</td>
<td class=br><strong>3</strong></td><td class=d>12.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>St Lutay</td><td class=bc>-</td><td class=bl>Vi Sapozhnikov</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ki Eriksson</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pe Ostlund</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ig Masloboev</td><td class=bc>-</td><td class=bl>Yn Aasheim</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Es Moe</td><td class=bc>-</td><td class=blW>Al Chernov</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Vi Sapozhnikov</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>St Lutay</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ki Eriksson</td><td class=bc>-</td><td class=blW>Yn Aasheim</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pe Ostlund</td><td class=bc>-</td><td class=bl>Al Chernov</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ig Masloboev</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vi Sapozhnikov</td><td class=bc>-</td><td class=bl>Al Titov</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>St Lutay</td><td class=bc>-</td><td class=bl>Yn Aasheim</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Al Chernov</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ki Eriksson</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pe Ostlund</td><td class=bc>-</td><td class=blW>Ig Masloboev</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Al Titov</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Yn Aasheim</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vi Sapozhnikov</td><td class=bc>-</td><td class=blW>Al Chernov</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>St Lutay</td><td class=bc>-</td><td class=blW>Es Moe</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=bl>Ig Masloboev</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ki Eriksson</td><td class=bc>-</td><td class=bl>Pe Ostlund</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Al Titov</td><td class=bc>-</td><td class=blW>Yn Aasheim</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Al Chernov</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Es Moe</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Vi Sapozhnikov</td><td class=bc>-</td><td class=bl>Ig Masloboev</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>St Lutay</td><td class=bc>-</td><td class=bl>Pe Ostlund</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Ki Eriksson</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Yn Aasheim</td><td class=bc>-</td><td class=bl>Al Chernov</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Al Titov</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ig Masloboev</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Pe Ostlund</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vi Sapozhnikov</td><td class=bc>-</td><td class=blW>Ki Eriksson</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>St Lutay</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>1 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
