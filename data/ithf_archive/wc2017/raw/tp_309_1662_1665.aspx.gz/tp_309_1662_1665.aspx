<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Team Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Team Open : Ukraine &nbsp;&nbsp;vs.&nbsp;&nbsp;Sweden &nbsp;&nbsp;12:6</span></h2></div></div></div></div><h3 align="right">Round: 1/4&nbsp;&nbsp;</h3>
<p><div align="center">
<table border=1 cellpadding="0" cellspacing="0" ><tr>
<table border="0" cellpadding="1" cellspacing="0" width="95%"><tr><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Dmytro Litvinyuk<br>2-3-0 (15:10)</td></tr>
<tr><td class="k">Yevhen Levdansky<br>4-0-1 (16:7)</td></tr>
<tr><td class="k">Evgeniy Matantsev<br>2-2-1 (15:11)</td></tr>
<tr><td class="k">Oleksii Korabel<br>2-0-3 (16:12)</td></tr>
<tr><td class="k">Mykhaylo Spivakovskyy<br>2-2-1 (9:9)</td></tr>
</table></td>
<td valign="top"><table border="0" cellspacing="0" cellpadding="0" width="100%"><tr><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 1</td></tr>
<tr><td class="hrac_sk">Dmytro Litvinyuk</td><td class="vysledek" width="60">&nbsp; 2 : 2 &nbsp;</td><td class="hrac_sk">Markus Nilsson</td></tr>
<tr><td class="hrac_sk">Yevhen Levdansky</td><td class="vysledek" width="60">&nbsp; 1 : 2 &nbsp;</td><td class="hrac_sk_v">Oscar Henriksson</td></tr>
<tr><td class="hrac_sk">Evgeniy Matantsev</td><td class="vysledek" width="60">&nbsp; 3 : 3 &nbsp;</td><td class="hrac_sk">Hans Österman</td></tr>
<tr><td class="hrac_sk_v">Oleksii Korabel</td><td class="vysledek" width="60">&nbsp; 5 : 0 &nbsp;</td><td class="hrac_sk">Peter Ostlund</td></tr>
<tr><td class="hrac_sk">Mykhaylo Spivakovskyy</td><td class="vysledek" width="60">&nbsp; 1 : 1 &nbsp;</td><td class="hrac_sk">Fredric Axelsson</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;1:1</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 2</td></tr>
<tr><td class="hrac_sk">Mykhaylo Spivakovskyy</td><td class="vysledek" width="60">&nbsp; 1 : 1 &nbsp;</td><td class="hrac_sk">Oscar Henriksson</td></tr>
<tr><td class="hrac_sk_v">Dmytro Litvinyuk</td><td class="vysledek" width="60">&nbsp; 5 : 3 &nbsp;</td><td class="hrac_sk">Hans Österman</td></tr>
<tr><td class="hrac_sk_v">Yevhen Levdansky</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">Peter Ostlund</td></tr>
<tr><td class="hrac_sk">Evgeniy Matantsev</td><td class="vysledek" width="60">&nbsp; 2 : 2 &nbsp;</td><td class="hrac_sk">Joakim Lundin</td></tr>
<tr><td class="hrac_sk_v">Oleksii Korabel</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">Markus Nilsson</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;4:1</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td>
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 3</td></tr>
<tr><td class="hrac_sk">Oleksii Korabel</td><td class="vysledek" width="60">&nbsp; 3 : 4 &nbsp;</td><td class="hrac_sk_v">Hans Österman</td></tr>
<tr><td class="hrac_sk_v">Mykhaylo Spivakovskyy</td><td class="vysledek" width="60">&nbsp; 3 : 2 &nbsp;</td><td class="hrac_sk">Anders Ekestubbe</td></tr>
<tr><td class="hrac_sk">Dmytro Litvinyuk</td><td class="vysledek" width="60">&nbsp; 2 : 2 &nbsp;</td><td class="hrac_sk">Joakim Lundin</td></tr>
<tr><td class="hrac_sk_v">Yevhen Levdansky</td><td class="vysledek" width="60">&nbsp; 3 : 2 &nbsp;</td><td class="hrac_sk">Markus Nilsson</td></tr>
<tr><td class="hrac_sk">Evgeniy Matantsev</td><td class="vysledek" width="60">&nbsp; 0 : 2 &nbsp;</td><td class="hrac_sk_v">Oscar Henriksson</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;6:3</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 4</td></tr>
<tr><td class="hrac_sk_v">Evgeniy Matantsev</td><td class="vysledek" width="60">&nbsp; 7 : 4 &nbsp;</td><td class="hrac_sk">Anders Ekestubbe</td></tr>
<tr><td class="hrac_sk">Oleksii Korabel</td><td class="vysledek" width="60">&nbsp; 2 : 4 &nbsp;</td><td class="hrac_sk_v">Joakim Lundin</td></tr>
<tr><td class="hrac_sk_v">Mykhaylo Spivakovskyy</td><td class="vysledek" width="60">&nbsp; 2 : 1 &nbsp;</td><td class="hrac_sk">Markus Nilsson</td></tr>
<tr><td class="hrac_sk">Dmytro Litvinyuk</td><td class="vysledek" width="60">&nbsp; 3 : 3 &nbsp;</td><td class="hrac_sk">Oscar Henriksson</td></tr>
<tr><td class="hrac_sk_v">Yevhen Levdansky</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">Hans Österman</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;9:4</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td align="center" colspan="3">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 5</td></tr>
<tr><td class="hrac_sk_v">Yevhen Levdansky</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">Joakim Lundin</td></tr>
<tr><td class="hrac_sk_v">Evgeniy Matantsev</td><td class="vysledek" width="60">&nbsp; 3 : 0 &nbsp;</td><td class="hrac_sk">Markus Nilsson</td></tr>
<tr><td class="hrac_sk">Oleksii Korabel</td><td class="vysledek" width="60">&nbsp; 2 : 3 &nbsp;</td><td class="hrac_sk_v">Oscar Henriksson</td></tr>
<tr><td class="hrac_sk">Mykhaylo Spivakovskyy</td><td class="vysledek" width="60">&nbsp; 2 : 4 &nbsp;</td><td class="hrac_sk_v">Hans Österman</td></tr>
<tr><td class="hrac_sk_v">Dmytro Litvinyuk</td><td class="vysledek" width="60">&nbsp; 3 : 0 &nbsp;</td><td class="hrac_sk">Rickard Sjöstedt</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;12:6</td></tr></table>
</td></tr></table></td><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Markus Nilsson<br>0-1-4 (6:14)</td></tr>
<tr><td class="k">Oscar Henriksson<br>3-2-0 (11:7)</td></tr>
<tr><td class="k">Hans Österman<br>2-1-2 (15:17)</td></tr>
<tr><td class="k">Peter Ostlund<br>0-0-2 (1:9)</td></tr>
<tr><td class="k">Fredric Axelsson<br>0-1-0 (1:1)</td></tr>
<tr><td class="k">Joakim Lundin<br>1-2-1 (9:10)</td></tr>
<tr><td class="k">Anders Ekestubbe<br>0-0-2 (6:10)</td></tr>
<tr><td class="k">Rickard Sjöstedt<br>0-0-1 (0:3)</td></tr>
</table></td></tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
