<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Open </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 3</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>At Silis</td><td class=ic>LAT</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>10:2</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=kW>8:2</td>
<td class=kW>8:3</td>
<td class=kW>9:1</td>
<td class=kW>10:0</td>
<td class=br>95:30</td><td class=br>+65</td>
<td class=bc>13 - 3 - 2</td>
<td class=br><strong>29</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>An Ekestubbe</td><td class=ic>SWE</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kW>8:1</td>
<td class=kW>7:1</td>
<td class=br>76:31</td><td class=br>+45</td>
<td class=bc>12 - 4 - 2</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Va Smagars</td><td class=ic>LAT</td><td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>7:3</td>
<td class=kW>8:1</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>6:4</td>
<td class=kW>11:0</td>
<td class=br>74:40</td><td class=br>+34</td>
<td class=bc>12 - 3 - 3</td>
<td class=br><strong>27</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ri Sjöstedt</td><td class=ic>SWE</td><td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>7:0</td>
<td class=kW>8:1</td>
<td class=kW>10:2</td>
<td class=br>62:28</td><td class=br>+34</td>
<td class=bc>12 - 3 - 3</td>
<td class=br><strong>27</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Yn Aasheim</td><td class=ic>NOR</td><td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kL>3:7</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kW>12:1</td>
<td class=kW>9:0</td>
<td class=br>81:45</td><td class=br>+36</td>
<td class=bc>12 - 2 - 4</td>
<td class=br><strong>26</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Mi Hvižď</td><td class=ic>CZE</td><td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>6:3</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=kW>5:4</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>9:0</td>
<td class=kW>9:1</td>
<td class=kW>7:0</td>
<td class=br>78:38</td><td class=br>+40</td>
<td class=bc>12 - 1 - 5</td>
<td class=br><strong>25</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Pa Plešák</td><td class=ic>CZE</td><td class=kL>0:5</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>7:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>8:0</td>
<td class=kW>4:1</td>
<td class=kW>7:3</td>
<td class=kW>14:0</td>
<td class=br>69:35</td><td class=br>+34</td>
<td class=bc>11 - 3 - 4</td>
<td class=br><strong>25</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Jo Lundin</td><td class=ic>SWE</td><td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>9:0</td>
<td class=kW>10:0</td>
<td class=kW>5:1</td>
<td class=kW>8:0</td>
<td class=kW>9:3</td>
<td class=kW>16:0</td>
<td class=br>86:29</td><td class=br>+57</td>
<td class=bc>10 - 4 - 4</td>
<td class=br><strong>24</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Im Blaško</td><td class=ic>SVK</td><td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>8:0</td>
<td class=kL>1:3</td>
<td class=kW>6:0</td>
<td class=kW>9:0</td>
<td class=kW>9:0</td>
<td class=kW>6:0</td>
<td class=br>71:30</td><td class=br>+41</td>
<td class=bc>9 - 3 - 6</td>
<td class=br><strong>21</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Da Mitro</td><td class=ic>SVK</td><td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=kW>5:4</td>
<td class=kW>7:0</td>
<td class=kW>6:1</td>
<td class=br>66:53</td><td class=br>+13</td>
<td class=bc>10 - 0 - 8</td>
<td class=br><strong>20</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ve Klippen</td><td class=ic>NOR</td><td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kW>7:4</td>
<td class=kW>5:0</td>
<td class=br>55:53</td><td class=br>+2</td>
<td class=bc>10 - 0 - 8</td>
<td class=br><strong>20</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>To Hudec</td><td class=ic>SVK</td><td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>4:3</td>
<td class=kW>6:5</td>
<td class=kW>5:0</td>
<td class=br>53:62</td><td class=br>-9</td>
<td class=bc>7 - 1 - 10</td>
<td class=br><strong>15</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Be Kunzler</td><td class=ic>CAN</td><td class=kL>2:10</td>
<td class=kL>1:6</td>
<td class=kL>3:7</td>
<td class=kL>2:4</td>
<td class=kL>2:7</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>8:0</td>
<td class=kW>6:1</td>
<td class=br>50:67</td><td class=br>-17</td>
<td class=bc>7 - 1 - 10</td>
<td class=br><strong>15</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ro Skrlep</td><td class=ic>SLO</td><td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>1:8</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>0:9</td>
<td class=kL>0:8</td>
<td class=kW>5:4</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>0:5</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=br>43:70</td><td class=br>-27</td>
<td class=bc>6 - 2 - 10</td>
<td class=br><strong>14</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Al Bartosh</td><td class=ic>BLR</td><td class=kL>0:8</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>0:10</td>
<td class=kW>3:1</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=br>33:68</td><td class=br>-35</td>
<td class=bc>3 - 2 - 13</td>
<td class=br><strong>8</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Th Haussknecht</td><td class=ic>GER</td><td class=kL>2:8</td>
<td class=kL>2:5</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>2:6</td>
<td class=kW>5:1</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kW>9:1</td>
<td class=br>41:80</td><td class=br>-39</td>
<td class=bc>3 - 1 - 14</td>
<td class=br><strong>7</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Ed Kuratnik</td><td class=ic>BLR</td><td class=kL>3:8</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>0:9</td>
<td class=kL>1:4</td>
<td class=kL>0:8</td>
<td class=kL>0:9</td>
<td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kW>4:0</td>
<td class=br>30:94</td><td class=br>-64</td>
<td class=bc>1 - 3 - 14</td>
<td class=br><strong>5</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>E</td><td class=d>18.</td><td class=kt>Se Rafferty</td><td class=ic>USA</td><td class=kL>1:9</td>
<td class=kL>1:8</td>
<td class=kL>4:6</td>
<td class=kL>1:8</td>
<td class=kL>1:12</td>
<td class=kL>1:9</td>
<td class=kL>3:7</td>
<td class=kL>3:9</td>
<td class=kL>0:9</td>
<td class=kL>0:7</td>
<td class=kL>4:7</td>
<td class=kL>5:6</td>
<td class=kL>0:8</td>
<td class=kL>1:7</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=br>43:125</td><td class=br>-82</td>
<td class=bc>2 - 1 - 15</td>
<td class=br><strong>5</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>E</td><td class=d>19.</td><td class=kt>Dz Kalinouski</td><td class=ic>BLR</td><td class=kL>0:10</td>
<td class=kL>1:7</td>
<td class=kL>0:11</td>
<td class=kL>2:10</td>
<td class=kL>0:9</td>
<td class=kL>0:7</td>
<td class=kL>0:14</td>
<td class=kL>0:16</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>1:9</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=br>8:136</td><td class=br>-128</td>
<td class=bc>0 - 1 - 17</td>
<td class=br><strong>1</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Yn Aasheim</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Al Bartosh</td><td class=bc>-</td><td class=bl>Ro Skrlep</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=bl>Ri Sjöstedt</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>At Silis</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Se Rafferty</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=blW>Jo Lundin</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Dz Kalinouski</td><td class=bc>-</td><td class=blW>Be Kunzler</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ro Skrlep</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Yn Aasheim</td><td class=bc>-</td><td class=blW>Ri Sjöstedt</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Al Bartosh</td><td class=bc>-</td><td class=blW>At Silis</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Se Rafferty</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Jo Lundin</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=blW>Ve Klippen</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ro Skrlep</td><td class=bc>-</td><td class=blW>Ri Sjöstedt</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>At Silis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Yn Aasheim</td><td class=bc>-</td><td class=bl>Se Rafferty</td><td class=bc>12 : 1</tr></td>
<tr><td class=br>Al Bartosh</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Jo Lundin</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Th Haussknecht</td><td class=bc>-</td><td class=bl>Ve Klippen</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Dz Kalinouski</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>At Silis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ro Skrlep</td><td class=bc>-</td><td class=bl>Se Rafferty</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Yn Aasheim</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Al Bartosh</td><td class=bc>-</td><td class=blW>Jo Lundin</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Ve Klippen</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Dz Kalinouski</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>At Silis</td><td class=bc>-</td><td class=bl>Se Rafferty</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Ri Sjöstedt</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ro Skrlep</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Jo Lundin</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Yn Aasheim</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Al Bartosh</td><td class=bc>-</td><td class=blW>Ve Klippen</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Dz Kalinouski</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Se Rafferty</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>At Silis</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Jo Lundin</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Skrlep</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ve Klippen</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Yn Aasheim</td><td class=bc>-</td><td class=bl>Dz Kalinouski</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Al Bartosh</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Se Rafferty</td><td class=bc>-</td><td class=blW>Jo Lundin</td><td class=bc>3 : 9</tr></td>
<tr><td class=brW>At Silis</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>10 : 2</tr></td>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Ve Klippen</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ro Skrlep</td><td class=bc>-</td><td class=bl>Dz Kalinouski</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Yn Aasheim</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Al Bartosh</td><td class=bc>-</td><td class=blW>Th Haussknecht</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Jo Lundin</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Be Kunzler</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Se Rafferty</td><td class=bc>-</td><td class=blW>Ve Klippen</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>At Silis</td><td class=bc>-</td><td class=bl>Dz Kalinouski</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Mi Hvižď</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ro Skrlep</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Yn Aasheim</td><td class=bc>-</td><td class=bl>An Ekestubbe</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Al Bartosh</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Jo Lundin</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Ve Klippen</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Dz Kalinouski</td><td class=bc>14 : 0</tr></td>
<tr><td class=br>Se Rafferty</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>At Silis</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ro Skrlep</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Yn Aasheim</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>Ve Klippen</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Jo Lundin</td><td class=bc>-</td><td class=bl>Dz Kalinouski</td><td class=bc>16 : 0</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Se Rafferty</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>At Silis</td><td class=bc>-</td><td class=bl>An Ekestubbe</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ro Skrlep</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Al Bartosh</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ve Klippen</td><td class=bc>-</td><td class=bl>Dz Kalinouski</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Jo Lundin</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>An Ekestubbe</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Se Rafferty</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>At Silis</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Al Bartosh</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ro Skrlep</td><td class=bc>-</td><td class=blW>Yn Aasheim</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Dz Kalinouski</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Ve Klippen</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Be Kunzler</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jo Lundin</td><td class=bc>-</td><td class=bl>An Ekestubbe</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Se Rafferty</td><td class=bc>-</td><td class=blW>Al Bartosh</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>At Silis</td><td class=bc>-</td><td class=bl>Yn Aasheim</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ri Sjöstedt</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Dz Kalinouski</td><td class=bc>-</td><td class=blW>Th Haussknecht</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Ve Klippen</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Be Kunzler</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Jo Lundin</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Al Bartosh</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Yn Aasheim</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Se Rafferty</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>At Silis</td><td class=bc>-</td><td class=bl>Ro Skrlep</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Dz Kalinouski</td><td class=bc>-</td><td class=blW>Ed Kuratnik</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ve Klippen</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Be Kunzler</td><td class=bc>-</td><td class=bl>Al Bartosh</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Jo Lundin</td><td class=bc>-</td><td class=bl>Yn Aasheim</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Ro Skrlep</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Se Rafferty</td><td class=bc>-</td><td class=blW>Ri Sjöstedt</td><td class=bc>1 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Dz Kalinouski</td><td class=bc>-</td><td class=bl>Al Bartosh</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ve Klippen</td><td class=bc>-</td><td class=blW>Yn Aasheim</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Jo Lundin</td><td class=bc>-</td><td class=bl>Ro Skrlep</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Ri Sjöstedt</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>At Silis</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Al Bartosh</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Yn Aasheim</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Dz Kalinouski</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>0 : 11</tr></td>
<tr><td class=brW>Ve Klippen</td><td class=bc>-</td><td class=bl>Ro Skrlep</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>Ri Sjöstedt</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jo Lundin</td><td class=bc>-</td><td class=blW>At Silis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Se Rafferty</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Al Bartosh</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Yn Aasheim</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>To Hudec</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Ro Skrlep</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Dz Kalinouski</td><td class=bc>-</td><td class=blW>Ri Sjöstedt</td><td class=bc>2 : 10</tr></td>
<tr><td class=br>Ve Klippen</td><td class=bc>-</td><td class=blW>At Silis</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Be Kunzler</td><td class=bc>-</td><td class=bl>Se Rafferty</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Jo Lundin</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>Al Bartosh</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Yn Aasheim</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>An Ekestubbe</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Ro Skrlep</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>To Hudec</td><td class=bc>-</td><td class=blW>Ri Sjöstedt</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=blW>At Silis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Dz Kalinouski</td><td class=bc>-</td><td class=blW>Se Rafferty</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ve Klippen</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Be Kunzler</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Al Bartosh</td><td class=bc>-</td><td class=blW>Yn Aasheim</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Ro Skrlep</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>An Ekestubbe</td><td class=bc>-</td><td class=bl>Ri Sjöstedt</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>At Silis</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Se Rafferty</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Dz Kalinouski</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ve Klippen</td><td class=bc>-</td><td class=bl>Jo Lundin</td><td class=bc>3 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
