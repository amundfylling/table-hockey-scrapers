<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Team Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Team Open : Estonia &nbsp;&nbsp;vs.&nbsp;&nbsp;Russia &nbsp;&nbsp;0:13</span></h2></div></div></div></div><h3 align="right">Round: 1/4&nbsp;&nbsp;</h3>
<p><div align="center">
<table border=1 cellpadding="0" cellspacing="0" ><tr>
<table border="0" cellpadding="1" cellspacing="0" width="95%"><tr><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Mark-Julius Pikat<br>0-0-3 (1:15)</td></tr>
<tr><td class="k">Daniil Moshnin<br>0-0-3 (3:20)</td></tr>
<tr><td class="k">Alen Shekarev<br>0-1-2 (5:13)</td></tr>
<tr><td class="k">Aleksandr Metelitsa<br>0-0-3 (5:19)</td></tr>
<tr><td class="k">Yuri Artamonov<br>0-1-2 (12:14)</td></tr>
</table></td>
<td valign="top"><table border="0" cellspacing="0" cellpadding="0" width="100%"><tr><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 1</td></tr>
<tr><td class="hrac_sk">Mark-Julius Pikat</td><td class="vysledek" width="60">&nbsp; 0 : 4 &nbsp;</td><td class="hrac_sk_v">Sergey Ivanov</td></tr>
<tr><td class="hrac_sk">Daniil Moshnin</td><td class="vysledek" width="60">&nbsp; 0 : 5 &nbsp;</td><td class="hrac_sk_v">Veniamin Gerasimov</td></tr>
<tr><td class="hrac_sk">Alen Shekarev</td><td class="vysledek" width="60">&nbsp; 2 : 6 &nbsp;</td><td class="hrac_sk_v">Nikita Zholobov</td></tr>
<tr><td class="hrac_sk">Aleksandr Metelitsa</td><td class="vysledek" width="60">&nbsp; 0 : 6 &nbsp;</td><td class="hrac_sk_v">Dmitriy Petrov</td></tr>
<tr><td class="hrac_sk">Yuri Artamonov</td><td class="vysledek" width="60">&nbsp; 4 : 5 &nbsp;</td><td class="hrac_sk_v">Arseniy Stolyarov</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;0:5</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 2</td></tr>
<tr><td class="hrac_sk">Yuri Artamonov</td><td class="vysledek" width="60">&nbsp; 3 : 3 &nbsp;</td><td class="hrac_sk">Veniamin Gerasimov</td></tr>
<tr><td class="hrac_sk">Mark-Julius Pikat</td><td class="vysledek" width="60">&nbsp; 0 : 4 &nbsp;</td><td class="hrac_sk_v">Nikita Zholobov</td></tr>
<tr><td class="hrac_sk">Daniil Moshnin</td><td class="vysledek" width="60">&nbsp; 2 : 6 &nbsp;</td><td class="hrac_sk_v">Dmitriy Petrov</td></tr>
<tr><td class="hrac_sk">Alen Shekarev</td><td class="vysledek" width="60">&nbsp; 0 : 4 &nbsp;</td><td class="hrac_sk_v">Arseniy Stolyarov</td></tr>
<tr><td class="hrac_sk">Aleksandr Metelitsa</td><td class="vysledek" width="60">&nbsp; 2 : 5 &nbsp;</td><td class="hrac_sk_v">Sergey Ivanov</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;0:9</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td>
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 3</td></tr>
<tr><td class="hrac_sk">Aleksandr Metelitsa</td><td class="vysledek" width="60">&nbsp; 3 : 8 &nbsp;</td><td class="hrac_sk_v">Nikita Zholobov</td></tr>
<tr><td class="hrac_sk">Yuri Artamonov</td><td class="vysledek" width="60">&nbsp; 5 : 6 &nbsp;</td><td class="hrac_sk_v">Dmitriy Petrov</td></tr>
<tr><td class="hrac_sk">Mark-Julius Pikat</td><td class="vysledek" width="60">&nbsp; 1 : 7 &nbsp;</td><td class="hrac_sk_v">Arseniy Stolyarov</td></tr>
<tr><td class="hrac_sk">Daniil Moshnin</td><td class="vysledek" width="60">&nbsp; 1 : 9 &nbsp;</td><td class="hrac_sk_v">Sergey Ivanov</td></tr>
<tr><td class="hrac_sk">Alen Shekarev</td><td class="vysledek" width="60">&nbsp; 3 : 3 &nbsp;</td><td class="hrac_sk">Veniamin Gerasimov</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;0:13</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 4</td></tr>
<tr><td class="hrac_sk">Alen Shekarev</td><td class="vysledek" width="60">&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;</td><td class="hrac_sk">Dmitriy Petrov</td></tr>
<tr><td class="hrac_sk">Aleksandr Metelitsa</td><td class="vysledek" width="60">&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;</td><td class="hrac_sk">Arseniy Stolyarov</td></tr>
<tr><td class="hrac_sk">Yuri Artamonov</td><td class="vysledek" width="60">&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;</td><td class="hrac_sk">Sergey Ivanov</td></tr>
<tr><td class="hrac_sk">Mark-Julius Pikat</td><td class="vysledek" width="60">&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;</td><td class="hrac_sk">Veniamin Gerasimov</td></tr>
<tr><td class="hrac_sk">Daniil Moshnin</td><td class="vysledek" width="60">&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;</td><td class="hrac_sk">Nikita Zholobov</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;0:13</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td align="center" colspan="3">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 5</td></tr>
<tr><td class="hrac_sk">Daniil Moshnin</td><td class="vysledek" width="60">&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;</td><td class="hrac_sk">Arseniy Stolyarov</td></tr>
<tr><td class="hrac_sk">Alen Shekarev</td><td class="vysledek" width="60">&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;</td><td class="hrac_sk">Sergey Ivanov</td></tr>
<tr><td class="hrac_sk">Aleksandr Metelitsa</td><td class="vysledek" width="60">&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;</td><td class="hrac_sk">Veniamin Gerasimov</td></tr>
<tr><td class="hrac_sk">Yuri Artamonov</td><td class="vysledek" width="60">&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;</td><td class="hrac_sk">Nikita Zholobov</td></tr>
<tr><td class="hrac_sk">Mark-Julius Pikat</td><td class="vysledek" width="60">&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;</td><td class="hrac_sk">Dmitriy Petrov</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;0:13</td></tr></table>
</td></tr></table></td><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Sergey Ivanov<br>3-0-0 (18:3)</td></tr>
<tr><td class="k">Veniamin Gerasimov<br>1-2-0 (11:6)</td></tr>
<tr><td class="k">Nikita Zholobov<br>3-0-0 (18:5)</td></tr>
<tr><td class="k">Dmitriy Petrov<br>3-0-0 (18:7)</td></tr>
<tr><td class="k">Arseniy Stolyarov<br>3-0-0 (16:5)</td></tr>
</table></td></tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
