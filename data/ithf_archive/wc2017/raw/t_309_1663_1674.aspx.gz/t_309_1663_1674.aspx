<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Team Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Team Open : Finland &nbsp;&nbsp;vs.&nbsp;&nbsp;Norway &nbsp;&nbsp;14:6</span></h2></div></div></div></div><h3 align="right">Round: 6&nbsp;&nbsp;</h3>
<p><div align="center">
<table border=1 cellpadding="0" cellspacing="0" ><tr>
<table border="0" cellpadding="1" cellspacing="0" width="95%"><tr><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Jan Pelkonen<br>4-0-1 (24:12)</td></tr>
<tr><td class="k">Kevin Eriksson<br>2-0-0 (9:4)</td></tr>
<tr><td class="k">Santtu Sainio<br>2-0-2 (18:12)</td></tr>
<tr><td class="k">Kristian Iso-Tryykari<br>1-2-2 (14:14)</td></tr>
<tr><td class="k">Vesa Huotelin<br>3-0-0 (14:4)</td></tr>
<tr><td class="k">Benjamin Suominen<br>1-2-0 (10:5)</td></tr>
<tr><td class="k">Juho Rautio<br>1-1-0 (7:6)</td></tr>
<tr><td class="k">Antti Vuononsola<br>0-0-1 (4:5)</td></tr>
</table></td>
<td valign="top"><table border="0" cellspacing="0" cellpadding="0" width="100%"><tr><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 1</td></tr>
<tr><td class="hrac_sk_v">Jan Pelkonen</td><td class="vysledek" width="60">&nbsp; 6 : 4 &nbsp;</td><td class="hrac_sk">Yngve Aasheim</td></tr>
<tr><td class="hrac_sk_v">Kevin Eriksson</td><td class="vysledek" width="60">&nbsp; 5 : 3 &nbsp;</td><td class="hrac_sk">Magnus Klippen</td></tr>
<tr><td class="hrac_sk_v">Santtu Sainio</td><td class="vysledek" width="60">&nbsp; 7 : 2 &nbsp;</td><td class="hrac_sk">Espen Moe</td></tr>
<tr><td class="hrac_sk_v">Kristian Iso-Tryykari</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">Amund Risa Fylling</td></tr>
<tr><td class="hrac_sk_v">Vesa Huotelin</td><td class="vysledek" width="60">&nbsp; 3 : 1 &nbsp;</td><td class="hrac_sk">Vegard Klippen</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;5:0</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 2</td></tr>
<tr><td class="hrac_sk_v">Vesa Huotelin</td><td class="vysledek" width="60">&nbsp; 7 : 2 &nbsp;</td><td class="hrac_sk">Magnus Klippen</td></tr>
<tr><td class="hrac_sk_v">Jan Pelkonen</td><td class="vysledek" width="60">&nbsp; 6 : 2 &nbsp;</td><td class="hrac_sk">Espen Moe</td></tr>
<tr><td class="hrac_sk_v">Kevin Eriksson</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">Amund Risa Fylling</td></tr>
<tr><td class="hrac_sk_v">Santtu Sainio</td><td class="vysledek" width="60">&nbsp; 6 : 2 &nbsp;</td><td class="hrac_sk">Vegard Klippen</td></tr>
<tr><td class="hrac_sk">Kristian Iso-Tryykari</td><td class="vysledek" width="60">&nbsp; 5 : 5 &nbsp;</td><td class="hrac_sk">Yngve Aasheim</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;9:0</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td>
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 3</td></tr>
<tr><td class="hrac_sk">Kristian Iso-Tryykari</td><td class="vysledek" width="60">&nbsp; 3 : 3 &nbsp;</td><td class="hrac_sk">Espen Moe</td></tr>
<tr><td class="hrac_sk_v">Vesa Huotelin</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">Espen Eidsnes</td></tr>
<tr><td class="hrac_sk_v">Jan Pelkonen</td><td class="vysledek" width="60">&nbsp; 5 : 3 &nbsp;</td><td class="hrac_sk">Oystein Klippen</td></tr>
<tr><td class="hrac_sk">Benjamin Suominen</td><td class="vysledek" width="60">&nbsp; 2 : 2 &nbsp;</td><td class="hrac_sk">Yngve Aasheim</td></tr>
<tr><td class="hrac_sk">Santtu Sainio</td><td class="vysledek" width="60">&nbsp; 1 : 3 &nbsp;</td><td class="hrac_sk_v">Magnus Klippen</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;11:1</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 4</td></tr>
<tr><td class="hrac_sk">Santtu Sainio</td><td class="vysledek" width="60">&nbsp; 4 : 5 &nbsp;</td><td class="hrac_sk_v">Espen Eidsnes</td></tr>
<tr><td class="hrac_sk">Kristian Iso-Tryykari</td><td class="vysledek" width="60">&nbsp; 1 : 2 &nbsp;</td><td class="hrac_sk_v">Oystein Klippen</td></tr>
<tr><td class="hrac_sk">Juho Rautio</td><td class="vysledek" width="60">&nbsp; 3 : 3 &nbsp;</td><td class="hrac_sk">Yngve Aasheim</td></tr>
<tr><td class="hrac_sk">Jan Pelkonen</td><td class="vysledek" width="60">&nbsp; 1 : 2 &nbsp;</td><td class="hrac_sk_v">Magnus Klippen</td></tr>
<tr><td class="hrac_sk_v">Benjamin Suominen</td><td class="vysledek" width="60">&nbsp; 5 : 0 &nbsp;</td><td class="hrac_sk">Espen Moe</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;12:4</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td align="center" colspan="3">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 5</td></tr>
<tr><td class="hrac_sk">Benjamin Suominen</td><td class="vysledek" width="60">&nbsp; 3 : 3 &nbsp;</td><td class="hrac_sk">Oystein Klippen</td></tr>
<tr><td class="hrac_sk">Antti Vuononsola</td><td class="vysledek" width="60">&nbsp; 4 : 5 &nbsp;</td><td class="hrac_sk_v">Yngve Aasheim</td></tr>
<tr><td class="hrac_sk">Kristian Iso-Tryykari</td><td class="vysledek" width="60">&nbsp; 1 : 3 &nbsp;</td><td class="hrac_sk_v">Magnus Klippen</td></tr>
<tr><td class="hrac_sk_v">Juho Rautio</td><td class="vysledek" width="60">&nbsp; 4 : 3 &nbsp;</td><td class="hrac_sk">Espen Moe</td></tr>
<tr><td class="hrac_sk_v">Jan Pelkonen</td><td class="vysledek" width="60">&nbsp; 6 : 1 &nbsp;</td><td class="hrac_sk">Espen Eidsnes</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;14:6</td></tr></table>
</td></tr></table></td><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Yngve Aasheim<br>1-3-1 (19:20)</td></tr>
<tr><td class="k">Magnus Klippen<br>3-0-2 (13:15)</td></tr>
<tr><td class="k">Espen Moe<br>0-1-4 (10:25)</td></tr>
<tr><td class="k">Amund Risa Fylling<br>0-0-2 (2:8)</td></tr>
<tr><td class="k">Vegard Klippen<br>0-0-2 (3:9)</td></tr>
<tr><td class="k">Espen Eidsnes<br>1-0-2 (7:14)</td></tr>
<tr><td class="k">Oystein Klippen<br>1-1-1 (8:9)</td></tr>
</table></td></tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
