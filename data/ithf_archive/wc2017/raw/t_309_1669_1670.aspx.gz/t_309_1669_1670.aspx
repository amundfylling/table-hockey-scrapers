<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Team Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Team Open : Hungary &nbsp;&nbsp;vs.&nbsp;&nbsp;Germany &nbsp;&nbsp;14:8</span></h2></div></div></div></div><h3 align="right">Round: 3&nbsp;&nbsp;</h3>
<p><div align="center">
<table border=1 cellpadding="0" cellspacing="0" ><tr>
<table border="0" cellpadding="1" cellspacing="0" width="95%"><tr><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Peter Borsanyi<br>2-2-1 (14:11)</td></tr>
<tr><td class="k">Viktor Magyari<br>5-0-0 (22:11)</td></tr>
<tr><td class="k">Magor Papp<br>3-0-2 (15:16)</td></tr>
<tr><td class="k">Gergely Regula<br>4-0-1 (27:10)</td></tr>
<tr><td class="k">Mátyás Papp<br>0-1-4 (8:23)</td></tr>
</table></td>
<td valign="top"><table border="0" cellspacing="0" cellpadding="0" width="100%"><tr><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 1</td></tr>
<tr><td class="hrac_sk">Peter Borsanyi</td><td class="vysledek" width="60">&nbsp; 2 : 3 &nbsp;</td><td class="hrac_sk_v">Leon Haussknecht</td></tr>
<tr><td class="hrac_sk_v">Viktor Magyari</td><td class="vysledek" width="60">&nbsp; 4 : 3 &nbsp;</td><td class="hrac_sk">Linus Restel</td></tr>
<tr><td class="hrac_sk_v">Magor Papp</td><td class="vysledek" width="60">&nbsp; 7 : 4 &nbsp;</td><td class="hrac_sk">Valentin Dietze</td></tr>
<tr><td class="hrac_sk_v">Gergely Regula</td><td class="vysledek" width="60">&nbsp; 9 : 4 &nbsp;</td><td class="hrac_sk">Frank Bruneske</td></tr>
<tr><td class="hrac_sk">Mátyás Papp</td><td class="vysledek" width="60">&nbsp; 1 : 5 &nbsp;</td><td class="hrac_sk_v">Ralph Pommerenke</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;3:2</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 2</td></tr>
<tr><td class="hrac_sk">Mátyás Papp</td><td class="vysledek" width="60">&nbsp; 3 : 3 &nbsp;</td><td class="hrac_sk">Linus Restel</td></tr>
<tr><td class="hrac_sk">Peter Borsanyi</td><td class="vysledek" width="60">&nbsp; 1 : 1 &nbsp;</td><td class="hrac_sk">Valentin Dietze</td></tr>
<tr><td class="hrac_sk_v">Viktor Magyari</td><td class="vysledek" width="60">&nbsp; 5 : 1 &nbsp;</td><td class="hrac_sk">Frank Bruneske</td></tr>
<tr><td class="hrac_sk_v">Magor Papp</td><td class="vysledek" width="60">&nbsp; 5 : 3 &nbsp;</td><td class="hrac_sk">Ralph Pommerenke</td></tr>
<tr><td class="hrac_sk_v">Gergely Regula</td><td class="vysledek" width="60">&nbsp; 3 : 2 &nbsp;</td><td class="hrac_sk">Leon Haussknecht</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;6:2</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td>
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 3</td></tr>
<tr><td class="hrac_sk">Gergely Regula</td><td class="vysledek" width="60">&nbsp; 0 : 2 &nbsp;</td><td class="hrac_sk_v">Valentin Dietze</td></tr>
<tr><td class="hrac_sk">Mátyás Papp</td><td class="vysledek" width="60">&nbsp; 0 : 4 &nbsp;</td><td class="hrac_sk_v">Frank Bruneske</td></tr>
<tr><td class="hrac_sk">Peter Borsanyi</td><td class="vysledek" width="60">&nbsp; 3 : 3 &nbsp;</td><td class="hrac_sk">Ralph Pommerenke</td></tr>
<tr><td class="hrac_sk_v">Viktor Magyari</td><td class="vysledek" width="60">&nbsp; 3 : 2 &nbsp;</td><td class="hrac_sk">Leon Haussknecht</td></tr>
<tr><td class="hrac_sk">Magor Papp</td><td class="vysledek" width="60">&nbsp; 0 : 5 &nbsp;</td><td class="hrac_sk_v">Linus Restel</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;7:5</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 4</td></tr>
<tr><td class="hrac_sk">Magor Papp</td><td class="vysledek" width="60">&nbsp; 1 : 4 &nbsp;</td><td class="hrac_sk_v">Frank Bruneske</td></tr>
<tr><td class="hrac_sk_v">Gergely Regula</td><td class="vysledek" width="60">&nbsp; 7 : 1 &nbsp;</td><td class="hrac_sk">Ralph Pommerenke</td></tr>
<tr><td class="hrac_sk">Mátyás Papp</td><td class="vysledek" width="60">&nbsp; 3 : 8 &nbsp;</td><td class="hrac_sk_v">Leon Haussknecht</td></tr>
<tr><td class="hrac_sk_v">Peter Borsanyi</td><td class="vysledek" width="60">&nbsp; 3 : 2 &nbsp;</td><td class="hrac_sk">Linus Restel</td></tr>
<tr><td class="hrac_sk_v">Viktor Magyari</td><td class="vysledek" width="60">&nbsp; 5 : 3 &nbsp;</td><td class="hrac_sk">Valentin Dietze</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;10:7</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td align="center" colspan="3">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 5</td></tr>
<tr><td class="hrac_sk_v">Viktor Magyari</td><td class="vysledek" width="60">&nbsp; 5 : 2 &nbsp;</td><td class="hrac_sk">Ralph Pommerenke</td></tr>
<tr><td class="hrac_sk_v">Magor Papp</td><td class="vysledek" width="60">&nbsp; 2 : 0 &nbsp;</td><td class="hrac_sk">Leon Haussknecht</td></tr>
<tr><td class="hrac_sk_v">Gergely Regula</td><td class="vysledek" width="60">&nbsp; 8 : 1 &nbsp;</td><td class="hrac_sk">Eike Rompa</td></tr>
<tr><td class="hrac_sk">Mátyás Papp</td><td class="vysledek" width="60">&nbsp; 1 : 3 &nbsp;</td><td class="hrac_sk_v">Valentin Dietze</td></tr>
<tr><td class="hrac_sk_v">Peter Borsanyi</td><td class="vysledek" width="60">&nbsp; 5 : 2 &nbsp;</td><td class="hrac_sk">Frank Bruneske</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;14:8</td></tr></table>
</td></tr></table></td><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Leon Haussknecht<br>2-0-3 (15:13)</td></tr>
<tr><td class="k">Linus Restel<br>1-1-2 (13:10)</td></tr>
<tr><td class="k">Valentin Dietze<br>2-1-2 (13:14)</td></tr>
<tr><td class="k">Frank Bruneske<br>2-0-3 (15:20)</td></tr>
<tr><td class="k">Ralph Pommerenke<br>1-1-3 (14:21)</td></tr>
<tr><td class="k">Eike Rompa<br>0-0-1 (1:8)</td></tr>
</table></td></tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
