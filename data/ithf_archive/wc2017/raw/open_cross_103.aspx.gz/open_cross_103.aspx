<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Open </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt>Mi Kobrle</td><td class=ic>CZE</td><td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kL>4:5</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>7:1</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>6:5</td>
<td class=kW>7:0</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kW>5:0 K</td>
<td class=br>109:50</td><td class=br>+59</td>
<td class=bc>19 - 1 - 3</td>
<td class=br><strong>39</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt>Ig Saveljev</td><td class=ic>EST</td><td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>4:6</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>6:0</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>5:0 K</td>
<td class=br>69:39</td><td class=br>+30</td>
<td class=bc>15 - 4 - 4</td>
<td class=br><strong>34</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt>Ve Klippen</td><td class=ic>NOR</td><td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>6:3</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>5:0 K</td>
<td class=br>68:39</td><td class=br>+29</td>
<td class=bc>14 - 5 - 4</td>
<td class=br><strong>33</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt>Oy Klippen</td><td class=ic>NOR</td><td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kT>5:5</td>
<td class=kW>3:0</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kW>7:2</td>
<td class=kW>7:1</td>
<td class=kL>0:6</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0 K</td>
<td class=br>68:45</td><td class=br>+23</td>
<td class=bc>13 - 4 - 6</td>
<td class=br><strong>30</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Fr Axelsson</td><td class=ic>SWE</td><td class=kW>5:4</td>
<td class=kW>6:4</td>
<td class=kL>3:6</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>7:4</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kW>7:5</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>7:4</td>
<td class=kW>5:3</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>5:0 K</td>
<td class=br>92:72</td><td class=br>+20</td>
<td class=bc>13 - 4 - 6</td>
<td class=br><strong>30</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Be Suominen</td><td class=ic>FIN</td><td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0 K</td>
<td class=br>74:44</td><td class=br>+30</td>
<td class=bc>13 - 4 - 6</td>
<td class=br><strong>30</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Da Šmíd</td><td class=ic>CZE</td><td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kL>0:6</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>8:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0 K</td>
<td class=br>77:59</td><td class=br>+18</td>
<td class=bc>14 - 2 - 7</td>
<td class=br><strong>30</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ju Rautio</td><td class=ic>FIN</td><td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kL>0:3</td>
<td class=kW>1:0</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>5:6</td>
<td class=kL>2:4</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>5:0 K</td>
<td class=br>67:48</td><td class=br>+19</td>
<td class=bc>12 - 2 - 9</td>
<td class=br><strong>26</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Da Mitro</td><td class=ic>SVK</td><td class=kL>1:7</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>4:5</td>
<td class=kW>8:2</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>5:0 K</td>
<td class=br>76:51</td><td class=br>+25</td>
<td class=bc>12 - 2 - 9</td>
<td class=br><strong>26</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Vi Sapozhnikov</td><td class=ic>UKR</td><td class=kL>3:6</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kT>5:5</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>6:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>6:4</td>
<td class=kL>0:1</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0 K</td>
<td class=br>74:65</td><td class=br>+9</td>
<td class=bc>11 - 3 - 9</td>
<td class=br><strong>25</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Li Restel</td><td class=ic>GER</td><td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>4:7</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kW>5:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kT>0:0</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>8:2</td>
<td class=kW>5:0 K</td>
<td class=br>69:64</td><td class=br>+5</td>
<td class=bc>9 - 6 - 8</td>
<td class=br><strong>24</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>An Engel</td><td class=ic>DEN</td><td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kL>1:6</td>
<td class=kL>2:8</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kW>5:0 K</td>
<td class=br>60:66</td><td class=br>-6</td>
<td class=bc>9 - 5 - 9</td>
<td class=br><strong>23</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Es Moe</td><td class=ic>NOR</td><td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>6:0</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>5:0 K</td>
<td class=br>62:60</td><td class=br>+2</td>
<td class=bc>10 - 2 - 11</td>
<td class=br><strong>22</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Am Fylling</td><td class=ic>NOR</td><td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kL>5:7</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kT>0:0</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=kW>2:1</td>
<td class=kW>5:0 K</td>
<td class=br>62:54</td><td class=br>+8</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Fi Hansson</td><td class=ic>SWE</td><td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kL>2:7</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>5:0 K</td>
<td class=br>51:61</td><td class=br>-10</td>
<td class=bc>8 - 5 - 10</td>
<td class=br><strong>21</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Yu Artamonov</td><td class=ic>EST</td><td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kL>0:2</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kL>4:6</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kW>5:0 K</td>
<td class=br>58:64</td><td class=br>-6</td>
<td class=bc>9 - 2 - 12</td>
<td class=br><strong>20</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ti Weisseisen</td><td class=ic>SLO</td><td class=kL>3:4</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kW>6:0</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0 K</td>
<td class=br>60:66</td><td class=br>-6</td>
<td class=bc>9 - 2 - 12</td>
<td class=br><strong>20</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Ja Sahlgren</td><td class=ic>FIN</td><td class=kL>5:6</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kL>0:6</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kL>2:6</td>
<td class=kW>4:1</td>
<td class=kL>2:6</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>5:0 K</td>
<td class=br>50:70</td><td class=br>-20</td>
<td class=bc>7 - 5 - 11</td>
<td class=br><strong>19</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Pe Borsanyi</td><td class=ic>HUN</td><td class=kL>0:7</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kL>0:3</td>
<td class=kL>4:7</td>
<td class=kL>1:4</td>
<td class=kW>6:0</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kW>5:0 K</td>
<td class=br>49:64</td><td class=br>-15</td>
<td class=bc>7 - 4 - 12</td>
<td class=br><strong>18</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Es Eidsnes</td><td class=ic>NOR</td><td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0 K</td>
<td class=br>57:66</td><td class=br>-9</td>
<td class=bc>8 - 2 - 13</td>
<td class=br><strong>18</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Si Thomas</td><td class=ic>IRL</td><td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>0:6</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>5:0 K</td>
<td class=br>47:73</td><td class=br>-26</td>
<td class=bc>5 - 7 - 11</td>
<td class=br><strong>17</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Al Shekarev</td><td class=ic>EST</td><td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kL>2:8</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kW>5:0 K</td>
<td class=br>51:74</td><td class=br>-23</td>
<td class=bc>7 - 3 - 13</td>
<td class=br><strong>17</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Si Pleikys</td><td class=ic>LTU</td><td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>2:8</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kW>5:1</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kW>5:0 K</td>
<td class=br>42:83</td><td class=br>-41</td>
<td class=bc>3 - 3 - 17</td>
<td class=br><strong>9</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Im Blaško</td><td class=ic>SVK</td><td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kx>*</td>
<td class=br>0:115</td><td class=br>-115</td>
<td class=bc>0 - 0 - 23</td>
<td class=br><strong>0</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Yu Artamonov</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Oy Klippen</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>An Engel</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Vi Sapozhnikov</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=blW>Ve Klippen</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Al Shekarev</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Fr Axelsson</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ti Weisseisen</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Fi Hansson</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Es Eidsnes</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Yu Artamonov</td><td class=bc>-</td><td class=blW>Li Restel</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>An Engel</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Oy Klippen</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Vi Sapozhnikov</td><td class=bc>-</td><td class=blW>Ve Klippen</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Al Shekarev</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Fr Axelsson</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Fi Hansson</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ti Weisseisen</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Es Eidsnes</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=bl>An Engel</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Yu Artamonov</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Oy Klippen</td><td class=bc>-</td><td class=bl>Ve Klippen</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Vi Sapozhnikov</td><td class=bc>-</td><td class=bl>Al Shekarev</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=blW>Fr Axelsson</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=blW>Es Moe</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Fi Hansson</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ja Sahlgren</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Es Eidsnes</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ti Weisseisen</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>An Engel</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Yu Artamonov</td><td class=bc>-</td><td class=blW>Ve Klippen</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Oy Klippen</td><td class=bc>-</td><td class=bl>Al Shekarev</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>Fr Axelsson</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Vi Sapozhnikov</td><td class=bc>-</td><td class=blW>Es Moe</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=bl>Fi Hansson</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Es Eidsnes</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ja Sahlgren</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=bl>Ti Weisseisen</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>An Engel</td><td class=bc>-</td><td class=bl>Ve Klippen</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Li Restel</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Yu Artamonov</td><td class=bc>-</td><td class=blW>Al Shekarev</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>Fr Axelsson</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Oy Klippen</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>Fi Hansson</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Vi Sapozhnikov</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Es Eidsnes</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ti Weisseisen</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ve Klippen</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>An Engel</td><td class=bc>-</td><td class=blW>Al Shekarev</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=blW>Fr Axelsson</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Yu Artamonov</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Fi Hansson</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Oy Klippen</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>Es Eidsnes</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Vi Sapozhnikov</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=blW>Ti Weisseisen</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ja Sahlgren</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ve Klippen</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Al Shekarev</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=blW>Fr Axelsson</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>An Engel</td><td class=bc>-</td><td class=blW>Es Moe</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=bl>Fi Hansson</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Yu Artamonov</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Es Eidsnes</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Oy Klippen</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>Ti Weisseisen</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Vi Sapozhnikov</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Ja Sahlgren</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=bl>Al Shekarev</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ve Klippen</td><td class=bc>-</td><td class=bl>Fr Axelsson</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Fi Hansson</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>An Engel</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Li Restel</td><td class=bc>-</td><td class=bl>Es Eidsnes</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Yu Artamonov</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ti Weisseisen</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Oy Klippen</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>Ja Sahlgren</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Vi Sapozhnikov</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=blW>Ju Rautio</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Al Shekarev</td><td class=bc>-</td><td class=bl>Fr Axelsson</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Es Moe</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ve Klippen</td><td class=bc>-</td><td class=blW>Fi Hansson</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Es Eidsnes</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>An Engel</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Li Restel</td><td class=bc>-</td><td class=bl>Ti Weisseisen</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Yu Artamonov</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ja Sahlgren</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Oy Klippen</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>Ju Rautio</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Vi Sapozhnikov</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Fr Axelsson</td><td class=bc>-</td><td class=blW>Es Moe</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>Fi Hansson</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ve Klippen</td><td class=bc>-</td><td class=bl>Es Eidsnes</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Ti Weisseisen</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>An Engel</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Li Restel</td><td class=bc>-</td><td class=bl>Ja Sahlgren</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Yu Artamonov</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Oy Klippen</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>Vi Sapozhnikov</td><td class=bc>0 : 5 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Es Moe</td><td class=bc>-</td><td class=bl>Fi Hansson</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Fr Axelsson</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>7 : 5</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>Es Eidsnes</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ve Klippen</td><td class=bc>-</td><td class=bl>Ti Weisseisen</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Ja Sahlgren</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>An Engel</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Li Restel</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Yu Artamonov</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>Vi Sapozhnikov</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Oy Klippen</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>5 : 0 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Fi Hansson</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Es Moe</td><td class=bc>-</td><td class=bl>Es Eidsnes</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Fr Axelsson</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>Ti Weisseisen</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ve Klippen</td><td class=bc>-</td><td class=bl>Ja Sahlgren</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>An Engel</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=blW>Vi Sapozhnikov</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Yu Artamonov</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Oy Klippen</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fi Hansson</td><td class=bc>-</td><td class=blW>Ti Weisseisen</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Es Moe</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Fr Axelsson</td><td class=bc>-</td><td class=bl>Ja Sahlgren</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Ju Rautio</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ve Klippen</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Vi Sapozhnikov</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>An Engel</td><td class=bc>-</td><td class=bl>Oy Klippen</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Yu Artamonov</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Es Eidsnes</td><td class=bc>-</td><td class=blW>Ti Weisseisen</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Fi Hansson</td><td class=bc>-</td><td class=blW>Ja Sahlgren</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Es Moe</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Fr Axelsson</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Vi Sapozhnikov</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ve Klippen</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Oy Klippen</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>An Engel</td><td class=bc>-</td><td class=bl>Yu Artamonov</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Es Eidsnes</td><td class=bc>-</td><td class=bl>Ja Sahlgren</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Fi Hansson</td><td class=bc>-</td><td class=blW>Ju Rautio</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Es Moe</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fr Axelsson</td><td class=bc>-</td><td class=bl>Vi Sapozhnikov</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Al Shekarev</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Oy Klippen</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ve Klippen</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Yu Artamonov</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Engel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ti Weisseisen</td><td class=bc>-</td><td class=blW>Ja Sahlgren</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Es Eidsnes</td><td class=bc>-</td><td class=blW>Ju Rautio</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Fi Hansson</td><td class=bc>-</td><td class=bl>Vi Sapozhnikov</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Es Moe</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Fr Axelsson</td><td class=bc>-</td><td class=blW>Oy Klippen</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Yu Artamonov</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ve Klippen</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>An Engel</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ti Weisseisen</td><td class=bc>-</td><td class=blW>Ju Rautio</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Es Eidsnes</td><td class=bc>-</td><td class=blW>Vi Sapozhnikov</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Fi Hansson</td><td class=bc>-</td><td class=blW>Oy Klippen</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Es Moe</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Fr Axelsson</td><td class=bc>-</td><td class=bl>Yu Artamonov</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Al Shekarev</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>An Engel</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ve Klippen</td><td class=bc>-</td><td class=blW>Pe Borsanyi</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ti Weisseisen</td><td class=bc>-</td><td class=bl>Vi Sapozhnikov</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Es Eidsnes</td><td class=bc>-</td><td class=bl>Oy Klippen</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fi Hansson</td><td class=bc>-</td><td class=blW>Yu Artamonov</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Es Moe</td><td class=bc>-</td><td class=blW>Li Restel</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Fr Axelsson</td><td class=bc>-</td><td class=bl>An Engel</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Al Shekarev</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ve Klippen</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ja Sahlgren</td><td class=bc>-</td><td class=blW>Vi Sapozhnikov</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Ti Weisseisen</td><td class=bc>-</td><td class=bl>Oy Klippen</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Es Eidsnes</td><td class=bc>-</td><td class=bl>Yu Artamonov</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Fi Hansson</td><td class=bc>-</td><td class=bl>An Engel</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Es Moe</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Fr Axelsson</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>Ve Klippen</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=blW>Vi Sapozhnikov</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Ja Sahlgren</td><td class=bc>-</td><td class=blW>Oy Klippen</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ti Weisseisen</td><td class=bc>-</td><td class=blW>Yu Artamonov</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Li Restel</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Es Eidsnes</td><td class=bc>-</td><td class=bl>An Engel</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Pe Borsanyi</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fi Hansson</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Es Moe</td><td class=bc>-</td><td class=blW>Ve Klippen</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Fr Axelsson</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Oy Klippen</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ja Sahlgren</td><td class=bc>-</td><td class=blW>Yu Artamonov</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ti Weisseisen</td><td class=bc>-</td><td class=blW>An Engel</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Es Eidsnes</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Ve Klippen</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Fi Hansson</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Es Moe</td><td class=bc>-</td><td class=bl>Al Shekarev</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Fr Axelsson</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Vi Sapozhnikov</td><td class=bc>-</td><td class=bl>Oy Klippen</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Yu Artamonov</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ja Sahlgren</td><td class=bc>-</td><td class=bl>An Engel</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Pe Borsanyi</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ti Weisseisen</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Ve Klippen</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Es Eidsnes</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Al Shekarev</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Fi Hansson</td><td class=bc>-</td><td class=bl>Fr Axelsson</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Es Moe</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Vi Sapozhnikov</td><td class=bc>-</td><td class=bl>Yu Artamonov</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>An Engel</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ja Sahlgren</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Ve Klippen</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ti Weisseisen</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Al Shekarev</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Es Eidsnes</td><td class=bc>-</td><td class=blW>Fr Axelsson</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Fi Hansson</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=brW>Oy Klippen</td><td class=bc>-</td><td class=bl>Yu Artamonov</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>Li Restel</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Vi Sapozhnikov</td><td class=bc>-</td><td class=bl>An Engel</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ve Klippen</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Al Shekarev</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ti Weisseisen</td><td class=bc>-</td><td class=blW>Fr Axelsson</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Es Eidsnes</td><td class=bc>-</td><td class=blW>Fi Hansson</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
