<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Open Results</span></h2></div></div></div></div><h3 align="right">Basic Groups&nbsp;&nbsp;</h3>
<p><div align="center">
<a href="Open_krizF.aspx#final">Final Groups</a><br>
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ma Borisov</td><td class=ic>RUS</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>6:4</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=br>79:27</td><td class=br>+52</td>
<td class=bc>16 - 1 - 1</td>
<td class=br><strong>33</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>My Spivakovskyy</td><td class=ic>UKR</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kW>9:1</td>
<td class=kW>8:1</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=br>76:28</td><td class=br>+48</td>
<td class=bc>11 - 7 - 0</td>
<td class=br><strong>29</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ro Ignatenko</td><td class=ic>UKR</td><td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>7:3</td>
<td class=kW>12:3</td>
<td class=kW>5:4</td>
<td class=kW>9:0</td>
<td class=kW>11:0</td>
<td class=br>86:37</td><td class=br>+49</td>
<td class=bc>12 - 3 - 3</td>
<td class=br><strong>27</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Dm Litvinyuk</td><td class=ic>UKR</td><td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>7:4</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>7:3</td>
<td class=kW>8:2</td>
<td class=kW>7:2</td>
<td class=kW>3:0</td>
<td class=kW>9:1</td>
<td class=br>75:40</td><td class=br>+35</td>
<td class=bc>11 - 4 - 3</td>
<td class=br><strong>26</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Kr Iso-Tryykari</td><td class=ic>FIN</td><td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>7:3</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=br>64:34</td><td class=br>+30</td>
<td class=bc>11 - 4 - 3</td>
<td class=br><strong>26</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>El Silinš</td><td class=ic>LAT</td><td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>8:0</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>8:0</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>63:37</td><td class=br>+26</td>
<td class=bc>12 - 1 - 5</td>
<td class=br><strong>25</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ar Zaharovs</td><td class=ic>LAT</td><td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>6:0</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>8:1</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=br>58:27</td><td class=br>+31</td>
<td class=bc>11 - 2 - 5</td>
<td class=br><strong>24</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Zd Matoušek ml.</td><td class=ic>CZE</td><td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>12:1</td>
<td class=br>66:35</td><td class=br>+31</td>
<td class=bc>11 - 2 - 5</td>
<td class=br><strong>24</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Da Šmíd</td><td class=ic>CZE</td><td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>6:3</td>
<td class=kL>4:6</td>
<td class=kW>4:3</td>
<td class=kT>0:0</td>
<td class=kW>7:0</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=kW>11:0</td>
<td class=kW>5:1</td>
<td class=br>65:37</td><td class=br>+28</td>
<td class=bc>10 - 3 - 5</td>
<td class=br><strong>23</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Si Thomas</td><td class=ic>IRL</td><td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>4:7</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>7:3</td>
<td class=kW>3:1</td>
<td class=kW>9:1</td>
<td class=kW>11:0</td>
<td class=br>58:38</td><td class=br>+20</td>
<td class=bc>10 - 2 - 6</td>
<td class=br><strong>22</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Al Shekarev</td><td class=ic>EST</td><td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>1:7</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>4:3</td>
<td class=kW>9:0</td>
<td class=kW>4:2</td>
<td class=br>58:54</td><td class=br>+4</td>
<td class=bc>8 - 1 - 9</td>
<td class=br><strong>17</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>An Bozic</td><td class=ic>SLO</td><td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kW>6:4</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=br>55:50</td><td class=br>+5</td>
<td class=bc>8 - 1 - 9</td>
<td class=br><strong>17</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ma Lunden</td><td class=ic>SWE</td><td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>0:1</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>12:0</td>
<td class=br>52:54</td><td class=br>-2</td>
<td class=bc>7 - 1 - 10</td>
<td class=br><strong>15</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ka Hudec</td><td class=ic>SVK</td><td class=kL>0:3</td>
<td class=kL>2:6</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>0:8</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kT>0:0</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>7:4</td>
<td class=kW>8:5</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>11:2</td>
<td class=br>53:61</td><td class=br>-8</td>
<td class=bc>6 - 2 - 10</td>
<td class=br><strong>14</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>An Naszádi</td><td class=ic>HUN</td><td class=kL>0:4</td>
<td class=kL>1:9</td>
<td class=kL>3:7</td>
<td class=kL>3:7</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>1:8</td>
<td class=kL>2:5</td>
<td class=kL>0:7</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>4:7</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>9:0</td>
<td class=kW>4:0</td>
<td class=kW>9:0</td>
<td class=br>46:79</td><td class=br>-33</td>
<td class=bc>4 - 0 - 14</td>
<td class=br><strong>8</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>An Kniaziuk</td><td class=ic>BLR</td><td class=kL>4:6</td>
<td class=kL>1:8</td>
<td class=kL>3:12</td>
<td class=kL>2:8</td>
<td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>2:7</td>
<td class=kL>3:7</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>5:8</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>8:3</td>
<td class=kW>5:1</td>
<td class=kW>12:0</td>
<td class=br>54:96</td><td class=br>-42</td>
<td class=bc>3 - 0 - 15</td>
<td class=br><strong>6</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Th Cornelius</td><td class=ic>CHI</td><td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>4:5</td>
<td class=kL>2:7</td>
<td class=kL>0:6</td>
<td class=kL>0:8</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>2:7</td>
<td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kL>0:9</td>
<td class=kL>3:8</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=br>38:94</td><td class=br>-56</td>
<td class=bc>2 - 0 - 16</td>
<td class=br><strong>4</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>E</td><td class=d>18.</td><td class=kt>Má Papp</td><td class=ic>HUN</td><td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>0:9</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kL>0:11</td>
<td class=kL>1:9</td>
<td class=kL>0:9</td>
<td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>16:103</td><td class=br>-87</td>
<td class=bc>1 - 0 - 17</td>
<td class=br><strong>2</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>E</td><td class=d>19.</td><td class=kt>Si Culic</td><td class=ic>SRB</td><td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>0:11</td>
<td class=kL>1:9</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:12</td>
<td class=kL>1:5</td>
<td class=kL>0:11</td>
<td class=kL>2:4</td>
<td class=kL>0:6</td>
<td class=kL>0:12</td>
<td class=kL>2:11</td>
<td class=kL>0:9</td>
<td class=kL>0:12</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>10:141</td><td class=br>-131</td>
<td class=bc>0 - 0 - 18</td>
<td class=br><strong>0</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>My Spivakovskyy</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ro Ignatenko</td><td class=bc>-</td><td class=blW>Al Shekarev</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Kr Iso-Tryykari</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>An Naszádi</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Zd Matoušek ml.</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>My Spivakovskyy</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Al Shekarev</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ro Ignatenko</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Kr Iso-Tryykari</td><td class=bc>-</td><td class=bl>Zd Matoušek ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>Ma Lunden</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>My Spivakovskyy</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>Al Shekarev</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Th Cornelius</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>An Naszádi</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ro Ignatenko</td><td class=bc>-</td><td class=bl>Ma Lunden</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kr Iso-Tryykari</td><td class=bc>-</td><td class=bl>Dm Litvinyuk</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>My Spivakovskyy</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Al Shekarev</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Ma Lunden</td><td class=bc>0 : 12</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ro Ignatenko</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>12 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>My Spivakovskyy</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Al Shekarev</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Zd Matoušek ml.</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>Ma Lunden</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>An Kniaziuk</td><td class=bc>0 : 12</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>Kr Iso-Tryykari</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Al Shekarev</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Ma Lunden</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Dm Litvinyuk</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>Kr Iso-Tryykari</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Ro Ignatenko</td><td class=bc>0 : 11</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Al Shekarev</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Zd Matoušek ml.</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ma Lunden</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Kr Iso-Tryykari</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>Ro Ignatenko</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=blW>An Naszádi</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Ma Lunden</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Dm Litvinyuk</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Kr Iso-Tryykari</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>Ro Ignatenko</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=blW>Ma Lunden</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Kr Iso-Tryykari</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ro Ignatenko</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Th Cornelius</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ma Lunden</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=blW>An Kniaziuk</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>Kr Iso-Tryykari</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=blW>Ro Ignatenko</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Th Cornelius</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ma Lunden</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Kr Iso-Tryykari</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=blW>Ro Ignatenko</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Th Cornelius</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ma Borisov</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ma Lunden</td><td class=bc>-</td><td class=blW>Kr Iso-Tryykari</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ro Ignatenko</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Má Papp</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Al Shekarev</td><td class=bc>-</td><td class=bl>Th Cornelius</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Ma Borisov</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>Kr Iso-Tryykari</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Ro Ignatenko</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Lunden</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>12 : 1</tr></td>
<tr><td class=brW>An Naszádi</td><td class=bc>-</td><td class=bl>Th Cornelius</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>Ma Borisov</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Kr Iso-Tryykari</td><td class=bc>-</td><td class=blW>Ro Ignatenko</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>5 : 8</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Ma Lunden</td><td class=bc>-</td><td class=bl>Th Cornelius</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Ma Borisov</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ro Ignatenko</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Kr Iso-Tryykari</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>An Kniaziuk</td><td class=bc>-</td><td class=bl>Th Cornelius</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Lunden</td><td class=bc>-</td><td class=blW>Ma Borisov</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=bl>My Spivakovskyy</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>11 : 2</tr></td>
<tr><td class=brW>Ro Ignatenko</td><td class=bc>-</td><td class=bl>Th Cornelius</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Kr Iso-Tryykari</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>Ma Borisov</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Lunden</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>My Spivakovskyy</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Th Cornelius</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro Ignatenko</td><td class=bc>-</td><td class=blW>Ma Borisov</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Kr Iso-Tryykari</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Dm Litvinyuk</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Lunden</td><td class=bc>-</td><td class=bl>My Spivakovskyy</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Al Shekarev</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Ma Borisov</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ro Ignatenko</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kr Iso-Tryykari</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>My Spivakovskyy</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Dm Litvinyuk</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Lunden</td><td class=bc>-</td><td class=blW>Al Shekarev</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>Ma Borisov</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ro Ignatenko</td><td class=bc>-</td><td class=bl>My Spivakovskyy</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Iso-Tryykari</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>Al Shekarev</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Lunden</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>3 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Pa Petr</td><td class=ic>CZE</td><td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kW>5:3</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=br>81:30</td><td class=br>+51</td>
<td class=bc>15 - 2 - 1</td>
<td class=br><strong>32</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ed Caics</td><td class=ic>LAT</td><td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>7:5</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kW>6:0</td>
<td class=kW>7:1</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>8:4</td>
<td class=kW>7:4</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=br>91:38</td><td class=br>+53</td>
<td class=bc>16 - 0 - 2</td>
<td class=br><strong>32</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ke Eriksson</td><td class=ic>FIN</td><td class=kW>5:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=kW>9:1</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kW>13:0</td>
<td class=kW>9:0</td>
<td class=br>90:41</td><td class=br>+49</td>
<td class=bc>14 - 1 - 3</td>
<td class=br><strong>29</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Pe Tměj</td><td class=ic>CZE</td><td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>8:0</td>
<td class=kW>6:1</td>
<td class=br>66:28</td><td class=br>+38</td>
<td class=bc>12 - 4 - 2</td>
<td class=br><strong>28</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ma Klippen</td><td class=ic>NOR</td><td class=kL>2:5</td>
<td class=kL>5:7</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=br>71:37</td><td class=br>+34</td>
<td class=bc>13 - 1 - 4</td>
<td class=br><strong>27</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Kr Lebl</td><td class=ic>CZE</td><td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=br>64:29</td><td class=br>+35</td>
<td class=bc>12 - 3 - 3</td>
<td class=br><strong>27</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Sa Sainio</td><td class=ic>FIN</td><td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>7:0</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kT>3:3</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>4:3</td>
<td class=br>72:46</td><td class=br>+26</td>
<td class=bc>10 - 5 - 3</td>
<td class=br><strong>25</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Dm Petrov</td><td class=ic>RUS</td><td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>8:2</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>9:0</td>
<td class=kW>8:1</td>
<td class=br>64:33</td><td class=br>+31</td>
<td class=bc>10 - 2 - 6</td>
<td class=br><strong>22</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Oy Klippen</td><td class=ic>NOR</td><td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=br>43:42</td><td class=br>+1</td>
<td class=bc>9 - 1 - 8</td>
<td class=br><strong>19</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ti Weisseisen</td><td class=ic>SLO</td><td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>11:3</td>
<td class=kW>3:0</td>
<td class=br>50:52</td><td class=br>-2</td>
<td class=bc>8 - 2 - 8</td>
<td class=br><strong>18</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Si Pleikys</td><td class=ic>LTU</td><td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>0:7</td>
<td class=kW>3:2</td>
<td class=kL>0:6</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>9:1</td>
<td class=kW>6:0</td>
<td class=br>55:57</td><td class=br>-2</td>
<td class=bc>8 - 1 - 9</td>
<td class=br><strong>17</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ma Papp</td><td class=ic>HUN</td><td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:9</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kL>2:5</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=kW>6:3</td>
<td class=br>55:67</td><td class=br>-12</td>
<td class=bc>7 - 1 - 10</td>
<td class=br><strong>15</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ki Eriksson</td><td class=ic>FIN</td><td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>5:6</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>8:0</td>
<td class=br>51:66</td><td class=br>-15</td>
<td class=bc>6 - 0 - 12</td>
<td class=br><strong>12</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Au Pleikys</td><td class=ic>LTU</td><td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=br>36:56</td><td class=br>-20</td>
<td class=bc>5 - 2 - 11</td>
<td class=br><strong>12</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Fr Bruneske</td><td class=ic>GER</td><td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>2:8</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kW>6:5</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=br>44:67</td><td class=br>-23</td>
<td class=bc>5 - 1 - 12</td>
<td class=br><strong>11</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Th Restel</td><td class=ic>GER</td><td class=kL>3:5</td>
<td class=kL>4:8</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=br>42:75</td><td class=br>-33</td>
<td class=bc>4 - 2 - 12</td>
<td class=br><strong>10</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Ke Rafferty</td><td class=ic>USA</td><td class=kL>2:5</td>
<td class=kL>4:7</td>
<td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=br>35:79</td><td class=br>-44</td>
<td class=bc>2 - 0 - 16</td>
<td class=br><strong>4</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>E</td><td class=d>18.</td><td class=kt>An Petrik</td><td class=ic>LTU</td><td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>0:13</td>
<td class=kL>0:8</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>0:9</td>
<td class=kL>2:5</td>
<td class=kL>3:11</td>
<td class=kL>1:9</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>17:105</td><td class=br>-88</td>
<td class=bc>1 - 0 - 17</td>
<td class=br><strong>2</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>E</td><td class=d>19.</td><td class=kt>Fi Kalinouski</td><td class=ic>BLR</td><td class=kL>1:2</td>
<td class=kL>0:8</td>
<td class=kL>0:9</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>1:8</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>3:6</td>
<td class=kL>0:8</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>15:94</td><td class=br>-79</td>
<td class=bc>0 - 0 - 18</td>
<td class=br><strong>0</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Fr Bruneske</td><td class=bc>-</td><td class=blW>Ti Weisseisen</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Pe Tměj</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ke Eriksson</td><td class=bc>-</td><td class=bl>Sa Sainio</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ki Eriksson</td><td class=bc>-</td><td class=bl>Th Restel</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Ke Rafferty</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Oy Klippen</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>An Petrik</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ti Weisseisen</td><td class=bc>-</td><td class=blW>Pe Tměj</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fr Bruneske</td><td class=bc>-</td><td class=bl>Sa Sainio</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Th Restel</td><td class=bc>8 : 4</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ki Eriksson</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Oy Klippen</td><td class=bc>-</td><td class=bl>An Petrik</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Pe Tměj</td><td class=bc>-</td><td class=bl>Sa Sainio</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ti Weisseisen</td><td class=bc>-</td><td class=bl>Th Restel</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Fr Bruneske</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ki Eriksson</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>An Petrik</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Klippen</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Oy Klippen</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Sa Sainio</td><td class=bc>-</td><td class=bl>Th Restel</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Pe Tměj</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ti Weisseisen</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Fr Bruneske</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>An Petrik</td><td class=bc>13 : 0</tr></td>
<tr><td class=br>Ki Eriksson</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Ma Papp</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Th Restel</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Sa Sainio</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Pe Tměj</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ti Weisseisen</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Fr Bruneske</td><td class=bc>-</td><td class=bl>An Petrik</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Ki Eriksson</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Oy Klippen</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Th Restel</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Sa Sainio</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pe Tměj</td><td class=bc>-</td><td class=bl>An Petrik</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ti Weisseisen</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Fr Bruneske</td><td class=bc>-</td><td class=blW>Ma Papp</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>Oy Klippen</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ki Eriksson</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Th Restel</td><td class=bc>-</td><td class=bl>An Petrik</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Sa Sainio</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Pe Tměj</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ti Weisseisen</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Fr Bruneske</td><td class=bc>-</td><td class=blW>Oy Klippen</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>7 : 5</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>9 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>An Petrik</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Th Restel</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Sa Sainio</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pe Tměj</td><td class=bc>-</td><td class=bl>Oy Klippen</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ti Weisseisen</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Fr Bruneske</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Ki Eriksson</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>An Petrik</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Th Restel</td><td class=bc>-</td><td class=blW>Oy Klippen</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Sa Sainio</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pe Tměj</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ti Weisseisen</td><td class=bc>-</td><td class=blW>Ki Eriksson</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Fr Bruneske</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>An Petrik</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Oy Klippen</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Th Restel</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Sa Sainio</td><td class=bc>-</td><td class=bl>Ki Eriksson</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pe Tměj</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ti Weisseisen</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Petrik</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>Oy Klippen</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Ki Eriksson</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Th Restel</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Sa Sainio</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Pe Tměj</td><td class=bc>-</td><td class=bl>Fr Bruneske</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Oy Klippen</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>An Petrik</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Ki Eriksson</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Th Restel</td><td class=bc>-</td><td class=blW>Fr Bruneske</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Sa Sainio</td><td class=bc>-</td><td class=bl>Ti Weisseisen</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Oy Klippen</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Petrik</td><td class=bc>-</td><td class=blW>Ki Eriksson</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Ke Eriksson</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Fr Bruneske</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Ti Weisseisen</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Th Restel</td><td class=bc>-</td><td class=blW>Pe Tměj</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Oy Klippen</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Ki Eriksson</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>An Petrik</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Fr Bruneske</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Ti Weisseisen</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Pe Tměj</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Sa Sainio</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Oy Klippen</td><td class=bc>-</td><td class=bl>Ki Eriksson</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Fr Bruneske</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>An Petrik</td><td class=bc>-</td><td class=blW>Ti Weisseisen</td><td class=bc>3 : 11</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>Pe Tměj</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Sa Sainio</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=bl>Th Restel</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Ki Eriksson</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ma Klippen</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Oy Klippen</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Fr Bruneske</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Ti Weisseisen</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Pe Tměj</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Petrik</td><td class=bc>-</td><td class=blW>Sa Sainio</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Th Restel</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Ki Eriksson</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Fr Bruneske</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Oy Klippen</td><td class=bc>-</td><td class=blW>Ti Weisseisen</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Pe Tměj</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>Sa Sainio</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Th Restel</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>An Petrik</td><td class=bc>-</td><td class=blW>Ke Rafferty</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ke Eriksson</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ki Eriksson</td><td class=bc>-</td><td class=blW>Fr Bruneske</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Ti Weisseisen</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ma Klippen</td><td class=bc>-</td><td class=blW>Pe Tměj</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Oy Klippen</td><td class=bc>-</td><td class=blW>Sa Sainio</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Th Restel</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>An Petrik</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Fr Bruneske</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ke Eriksson</td><td class=bc>-</td><td class=blW>Ti Weisseisen</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ki Eriksson</td><td class=bc>-</td><td class=blW>Pe Tměj</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Sa Sainio</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Th Restel</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Oy Klippen</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>3 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 3</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>At Silis</td><td class=ic>LAT</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>10:2</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=kW>8:2</td>
<td class=kW>8:3</td>
<td class=kW>9:1</td>
<td class=kW>10:0</td>
<td class=br>95:30</td><td class=br>+65</td>
<td class=bc>13 - 3 - 2</td>
<td class=br><strong>29</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>An Ekestubbe</td><td class=ic>SWE</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kW>8:1</td>
<td class=kW>7:1</td>
<td class=br>76:31</td><td class=br>+45</td>
<td class=bc>12 - 4 - 2</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Va Smagars</td><td class=ic>LAT</td><td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>7:3</td>
<td class=kW>8:1</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>6:4</td>
<td class=kW>11:0</td>
<td class=br>74:40</td><td class=br>+34</td>
<td class=bc>12 - 3 - 3</td>
<td class=br><strong>27</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ri Sjöstedt</td><td class=ic>SWE</td><td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>7:0</td>
<td class=kW>8:1</td>
<td class=kW>10:2</td>
<td class=br>62:28</td><td class=br>+34</td>
<td class=bc>12 - 3 - 3</td>
<td class=br><strong>27</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Yn Aasheim</td><td class=ic>NOR</td><td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kL>3:7</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kW>12:1</td>
<td class=kW>9:0</td>
<td class=br>81:45</td><td class=br>+36</td>
<td class=bc>12 - 2 - 4</td>
<td class=br><strong>26</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Mi Hvižď</td><td class=ic>CZE</td><td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>6:3</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=kW>5:4</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>9:0</td>
<td class=kW>9:1</td>
<td class=kW>7:0</td>
<td class=br>78:38</td><td class=br>+40</td>
<td class=bc>12 - 1 - 5</td>
<td class=br><strong>25</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Pa Plešák</td><td class=ic>CZE</td><td class=kL>0:5</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>7:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>8:0</td>
<td class=kW>4:1</td>
<td class=kW>7:3</td>
<td class=kW>14:0</td>
<td class=br>69:35</td><td class=br>+34</td>
<td class=bc>11 - 3 - 4</td>
<td class=br><strong>25</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Jo Lundin</td><td class=ic>SWE</td><td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>9:0</td>
<td class=kW>10:0</td>
<td class=kW>5:1</td>
<td class=kW>8:0</td>
<td class=kW>9:3</td>
<td class=kW>16:0</td>
<td class=br>86:29</td><td class=br>+57</td>
<td class=bc>10 - 4 - 4</td>
<td class=br><strong>24</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Im Blaško</td><td class=ic>SVK</td><td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>8:0</td>
<td class=kL>1:3</td>
<td class=kW>6:0</td>
<td class=kW>9:0</td>
<td class=kW>9:0</td>
<td class=kW>6:0</td>
<td class=br>71:30</td><td class=br>+41</td>
<td class=bc>9 - 3 - 6</td>
<td class=br><strong>21</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Da Mitro</td><td class=ic>SVK</td><td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=kW>5:4</td>
<td class=kW>7:0</td>
<td class=kW>6:1</td>
<td class=br>66:53</td><td class=br>+13</td>
<td class=bc>10 - 0 - 8</td>
<td class=br><strong>20</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ve Klippen</td><td class=ic>NOR</td><td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kW>7:4</td>
<td class=kW>5:0</td>
<td class=br>55:53</td><td class=br>+2</td>
<td class=bc>10 - 0 - 8</td>
<td class=br><strong>20</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>To Hudec</td><td class=ic>SVK</td><td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>4:3</td>
<td class=kW>6:5</td>
<td class=kW>5:0</td>
<td class=br>53:62</td><td class=br>-9</td>
<td class=bc>7 - 1 - 10</td>
<td class=br><strong>15</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Be Kunzler</td><td class=ic>CAN</td><td class=kL>2:10</td>
<td class=kL>1:6</td>
<td class=kL>3:7</td>
<td class=kL>2:4</td>
<td class=kL>2:7</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>8:0</td>
<td class=kW>6:1</td>
<td class=br>50:67</td><td class=br>-17</td>
<td class=bc>7 - 1 - 10</td>
<td class=br><strong>15</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ro Skrlep</td><td class=ic>SLO</td><td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>1:8</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>0:9</td>
<td class=kL>0:8</td>
<td class=kW>5:4</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>0:5</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=br>43:70</td><td class=br>-27</td>
<td class=bc>6 - 2 - 10</td>
<td class=br><strong>14</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Al Bartosh</td><td class=ic>BLR</td><td class=kL>0:8</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>0:10</td>
<td class=kW>3:1</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=br>33:68</td><td class=br>-35</td>
<td class=bc>3 - 2 - 13</td>
<td class=br><strong>8</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Th Haussknecht</td><td class=ic>GER</td><td class=kL>2:8</td>
<td class=kL>2:5</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>2:6</td>
<td class=kW>5:1</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kW>9:1</td>
<td class=br>41:80</td><td class=br>-39</td>
<td class=bc>3 - 1 - 14</td>
<td class=br><strong>7</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Ed Kuratnik</td><td class=ic>BLR</td><td class=kL>3:8</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>0:9</td>
<td class=kL>1:4</td>
<td class=kL>0:8</td>
<td class=kL>0:9</td>
<td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kW>4:0</td>
<td class=br>30:94</td><td class=br>-64</td>
<td class=bc>1 - 3 - 14</td>
<td class=br><strong>5</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>E</td><td class=d>18.</td><td class=kt>Se Rafferty</td><td class=ic>USA</td><td class=kL>1:9</td>
<td class=kL>1:8</td>
<td class=kL>4:6</td>
<td class=kL>1:8</td>
<td class=kL>1:12</td>
<td class=kL>1:9</td>
<td class=kL>3:7</td>
<td class=kL>3:9</td>
<td class=kL>0:9</td>
<td class=kL>0:7</td>
<td class=kL>4:7</td>
<td class=kL>5:6</td>
<td class=kL>0:8</td>
<td class=kL>1:7</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=br>43:125</td><td class=br>-82</td>
<td class=bc>2 - 1 - 15</td>
<td class=br><strong>5</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>E</td><td class=d>19.</td><td class=kt>Dz Kalinouski</td><td class=ic>BLR</td><td class=kL>0:10</td>
<td class=kL>1:7</td>
<td class=kL>0:11</td>
<td class=kL>2:10</td>
<td class=kL>0:9</td>
<td class=kL>0:7</td>
<td class=kL>0:14</td>
<td class=kL>0:16</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>1:9</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=br>8:136</td><td class=br>-128</td>
<td class=bc>0 - 1 - 17</td>
<td class=br><strong>1</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Yn Aasheim</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Al Bartosh</td><td class=bc>-</td><td class=bl>Ro Skrlep</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=bl>Ri Sjöstedt</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>At Silis</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Se Rafferty</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=blW>Jo Lundin</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Dz Kalinouski</td><td class=bc>-</td><td class=blW>Be Kunzler</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ro Skrlep</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Yn Aasheim</td><td class=bc>-</td><td class=blW>Ri Sjöstedt</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Al Bartosh</td><td class=bc>-</td><td class=blW>At Silis</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Se Rafferty</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Jo Lundin</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=blW>Ve Klippen</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ro Skrlep</td><td class=bc>-</td><td class=blW>Ri Sjöstedt</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>At Silis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Yn Aasheim</td><td class=bc>-</td><td class=bl>Se Rafferty</td><td class=bc>12 : 1</tr></td>
<tr><td class=br>Al Bartosh</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Jo Lundin</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Th Haussknecht</td><td class=bc>-</td><td class=bl>Ve Klippen</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Dz Kalinouski</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>At Silis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ro Skrlep</td><td class=bc>-</td><td class=bl>Se Rafferty</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Yn Aasheim</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Al Bartosh</td><td class=bc>-</td><td class=blW>Jo Lundin</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Ve Klippen</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Dz Kalinouski</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>At Silis</td><td class=bc>-</td><td class=bl>Se Rafferty</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Ri Sjöstedt</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ro Skrlep</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Jo Lundin</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Yn Aasheim</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Al Bartosh</td><td class=bc>-</td><td class=blW>Ve Klippen</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Im Blaško</td><td class=bc>-</td><td class=bl>Dz Kalinouski</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Se Rafferty</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>At Silis</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Jo Lundin</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Skrlep</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ve Klippen</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Yn Aasheim</td><td class=bc>-</td><td class=bl>Dz Kalinouski</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Al Bartosh</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Se Rafferty</td><td class=bc>-</td><td class=blW>Jo Lundin</td><td class=bc>3 : 9</tr></td>
<tr><td class=brW>At Silis</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>10 : 2</tr></td>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Ve Klippen</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ro Skrlep</td><td class=bc>-</td><td class=bl>Dz Kalinouski</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Yn Aasheim</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Al Bartosh</td><td class=bc>-</td><td class=blW>Th Haussknecht</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Jo Lundin</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Be Kunzler</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Se Rafferty</td><td class=bc>-</td><td class=blW>Ve Klippen</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>At Silis</td><td class=bc>-</td><td class=bl>Dz Kalinouski</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Mi Hvižď</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ro Skrlep</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Yn Aasheim</td><td class=bc>-</td><td class=bl>An Ekestubbe</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Al Bartosh</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Jo Lundin</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Ve Klippen</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Dz Kalinouski</td><td class=bc>14 : 0</tr></td>
<tr><td class=br>Se Rafferty</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>At Silis</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ro Skrlep</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Yn Aasheim</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>Ve Klippen</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Jo Lundin</td><td class=bc>-</td><td class=bl>Dz Kalinouski</td><td class=bc>16 : 0</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Se Rafferty</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>At Silis</td><td class=bc>-</td><td class=bl>An Ekestubbe</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ro Skrlep</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Al Bartosh</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ve Klippen</td><td class=bc>-</td><td class=bl>Dz Kalinouski</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Jo Lundin</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>An Ekestubbe</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Se Rafferty</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>At Silis</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Al Bartosh</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ro Skrlep</td><td class=bc>-</td><td class=blW>Yn Aasheim</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Dz Kalinouski</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Ve Klippen</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Be Kunzler</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jo Lundin</td><td class=bc>-</td><td class=bl>An Ekestubbe</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Se Rafferty</td><td class=bc>-</td><td class=blW>Al Bartosh</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>At Silis</td><td class=bc>-</td><td class=bl>Yn Aasheim</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ri Sjöstedt</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Dz Kalinouski</td><td class=bc>-</td><td class=blW>Th Haussknecht</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Ve Klippen</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Be Kunzler</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Jo Lundin</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Al Bartosh</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Yn Aasheim</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Se Rafferty</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>At Silis</td><td class=bc>-</td><td class=bl>Ro Skrlep</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Dz Kalinouski</td><td class=bc>-</td><td class=blW>Ed Kuratnik</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ve Klippen</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Be Kunzler</td><td class=bc>-</td><td class=bl>Al Bartosh</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Jo Lundin</td><td class=bc>-</td><td class=bl>Yn Aasheim</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Da Mitro</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Ro Skrlep</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Se Rafferty</td><td class=bc>-</td><td class=blW>Ri Sjöstedt</td><td class=bc>1 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Im Blaško</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Dz Kalinouski</td><td class=bc>-</td><td class=bl>Al Bartosh</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ve Klippen</td><td class=bc>-</td><td class=blW>Yn Aasheim</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Jo Lundin</td><td class=bc>-</td><td class=bl>Ro Skrlep</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Ri Sjöstedt</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>At Silis</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Al Bartosh</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Yn Aasheim</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Dz Kalinouski</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>0 : 11</tr></td>
<tr><td class=brW>Ve Klippen</td><td class=bc>-</td><td class=bl>Ro Skrlep</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>Ri Sjöstedt</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jo Lundin</td><td class=bc>-</td><td class=blW>At Silis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Da Mitro</td><td class=bc>-</td><td class=bl>Se Rafferty</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Im Blaško</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Al Bartosh</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Yn Aasheim</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>To Hudec</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Ro Skrlep</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Dz Kalinouski</td><td class=bc>-</td><td class=blW>Ri Sjöstedt</td><td class=bc>2 : 10</tr></td>
<tr><td class=br>Ve Klippen</td><td class=bc>-</td><td class=blW>At Silis</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Be Kunzler</td><td class=bc>-</td><td class=bl>Se Rafferty</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Jo Lundin</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=blW>Al Bartosh</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Yn Aasheim</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>An Ekestubbe</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Ro Skrlep</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>To Hudec</td><td class=bc>-</td><td class=blW>Ri Sjöstedt</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=blW>At Silis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Dz Kalinouski</td><td class=bc>-</td><td class=blW>Se Rafferty</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ve Klippen</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Be Kunzler</td><td class=bc>-</td><td class=bl>Da Mitro</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Al Bartosh</td><td class=bc>-</td><td class=blW>Yn Aasheim</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Im Blaško</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Ro Skrlep</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>An Ekestubbe</td><td class=bc>-</td><td class=bl>Ri Sjöstedt</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>At Silis</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Se Rafferty</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Dz Kalinouski</td><td class=bc>-</td><td class=blW>Da Mitro</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ve Klippen</td><td class=bc>-</td><td class=bl>Jo Lundin</td><td class=bc>3 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 4</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ya Galuzo</td><td class=ic>RUS</td><td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kW>8:5</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>9:2</td>
<td class=kW>7:3</td>
<td class=kW>9:3</td>
<td class=kW>7:2</td>
<td class=kW>6:2</td>
<td class=kW>7:1</td>
<td class=br>107:39</td><td class=br>+68</td>
<td class=bc>17 - 0 - 1</td>
<td class=br><strong>34</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Al Miloradov</td><td class=ic>RUS</td><td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>10:1</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>9:1</td>
<td class=kW>4:3</td>
<td class=kW>10:1</td>
<td class=kW>6:1</td>
<td class=kW>8:0</td>
<td class=br>89:29</td><td class=br>+60</td>
<td class=bc>15 - 2 - 1</td>
<td class=br><strong>32</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ma Nilsson</td><td class=ic>SWE</td><td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>9:1</td>
<td class=kW>5:3</td>
<td class=br>81:38</td><td class=br>+43</td>
<td class=bc>13 - 2 - 3</td>
<td class=br><strong>28</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Pe Ostlund</td><td class=ic>SWE</td><td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>8:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>8:2</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>9:0</td>
<td class=kW>7:1</td>
<td class=br>73:31</td><td class=br>+42</td>
<td class=bc>13 - 2 - 3</td>
<td class=br><strong>28</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Kr Curkovic</td><td class=ic>CRO</td><td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>6:4</td>
<td class=kW>4:3</td>
<td class=kL>5:6</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>7:2</td>
<td class=kW>7:1</td>
<td class=kW>6:2</td>
<td class=kW>6:5</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=br>79:52</td><td class=br>+27</td>
<td class=bc>13 - 0 - 5</td>
<td class=br><strong>26</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ra Miglinieks</td><td class=ic>LAT</td><td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kT>5:5</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>9:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>7:3</td>
<td class=kW>11:2</td>
<td class=kW>6:0</td>
<td class=br>74:41</td><td class=br>+33</td>
<td class=bc>11 - 4 - 3</td>
<td class=br><strong>26</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ma Saveljeva</td><td class=ic>EST</td><td class=kL>4:5</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kL>4:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>10:5</td>
<td class=kW>8:2</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>6:3</td>
<td class=kW>7:0</td>
<td class=kW>7:0</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kW>5:4</td>
<td class=kW>7:0</td>
<td class=br>87:44</td><td class=br>+43</td>
<td class=bc>11 - 3 - 4</td>
<td class=br><strong>25</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ge Regula</td><td class=ic>HUN</td><td class=kL>1:7</td>
<td class=kT>4:4</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>5:10</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kW>9:2</td>
<td class=kW>11:0</td>
<td class=br>76:60</td><td class=br>+16</td>
<td class=bc>8 - 4 - 6</td>
<td class=br><strong>20</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Vi Sapozhnikov</td><td class=ic>UKR</td><td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kW>6:5</td>
<td class=kL>3:4</td>
<td class=kL>2:8</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kW>7:0</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=br>75:50</td><td class=br>+25</td>
<td class=bc>10 - 0 - 8</td>
<td class=br><strong>20</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Es Eidsnes</td><td class=ic>NOR</td><td class=kL>5:8</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>3:8</td>
<td class=kL>2:4</td>
<td class=kT>5:5</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kW>9:3</td>
<td class=kW>7:2</td>
<td class=kW>7:0</td>
<td class=br>78:62</td><td class=br>+16</td>
<td class=bc>8 - 2 - 8</td>
<td class=br><strong>18</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Mi Kobrle</td><td class=ic>CZE</td><td class=kL>3:7</td>
<td class=kL>1:3</td>
<td class=kL>4:5</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kW>5:2</td>
<td class=kL>1:8</td>
<td class=kW>11:4</td>
<td class=kW>7:1</td>
<td class=kW>7:3</td>
<td class=kW>5:2</td>
<td class=kW>9:0</td>
<td class=br>73:59</td><td class=br>+14</td>
<td class=bc>8 - 1 - 9</td>
<td class=br><strong>17</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ma Curkovic</td><td class=ic>CRO</td><td class=kL>2:3</td>
<td class=kL>1:10</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kL>0:7</td>
<td class=kW>4:2</td>
<td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>9:0</td>
<td class=kW>5:0</td>
<td class=br>54:58</td><td class=br>-4</td>
<td class=bc>8 - 1 - 9</td>
<td class=br><strong>17</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Va Dietze</td><td class=ic>GER</td><td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>10:1</td>
<td class=kW>8:0</td>
<td class=br>59:59</td><td class=br>0</td>
<td class=bc>8 - 0 - 10</td>
<td class=br><strong>16</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Si Vazhnik</td><td class=ic>BLR</td><td class=kL>2:9</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>2:8</td>
<td class=kL>2:7</td>
<td class=kL>1:9</td>
<td class=kL>0:7</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kW>8:1</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=br>43:81</td><td class=br>-38</td>
<td class=bc>4 - 1 - 13</td>
<td class=br><strong>9</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ei Rompa</td><td class=ic>GER</td><td class=kL>3:7</td>
<td class=kL>1:9</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>4:11</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>32:83</td><td class=br>-51</td>
<td class=bc>3 - 3 - 12</td>
<td class=br><strong>9</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Al Tarakanov</td><td class=ic>KAZ</td><td class=kL>3:9</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=br>32:83</td><td class=br>-51</td>
<td class=bc>3 - 2 - 13</td>
<td class=br><strong>8</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Mi Toft Nielsen</td><td class=ic>DEN</td><td class=kL>2:7</td>
<td class=kL>1:10</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>5:6</td>
<td class=kL>3:7</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kL>3:9</td>
<td class=kL>3:7</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kW>8:0</td>
<td class=kW>5:0</td>
<td class=br>44:82</td><td class=br>-38</td>
<td class=bc>3 - 1 - 14</td>
<td class=br><strong>7</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>E</td><td class=d>18.</td><td class=kt>Ad Sowa</td><td class=ic>POL</td><td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>1:9</td>
<td class=kL>0:9</td>
<td class=kL>0:5</td>
<td class=kL>2:11</td>
<td class=kL>4:5</td>
<td class=kL>2:9</td>
<td class=kL>1:7</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kL>0:9</td>
<td class=kL>1:10</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>0:8</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=br>28:124</td><td class=br>-96</td>
<td class=bc>1 - 0 - 17</td>
<td class=br><strong>2</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>E</td><td class=d>19.</td><td class=kt>Ni Cornelius</td><td class=ic>CHI</td><td class=kL>1:7</td>
<td class=kL>0:8</td>
<td class=kL>3:5</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>0:11</td>
<td class=kL>0:7</td>
<td class=kL>0:7</td>
<td class=kL>0:9</td>
<td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=br>9:118</td><td class=br>-109</td>
<td class=bc>0 - 0 - 18</td>
<td class=br><strong>0</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Si Vazhnik</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Kr Curkovic</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Ma Curkovic</td><td class=bc>-</td><td class=bl>Al Tarakanov</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Ad Sowa</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Es Eidsnes</td><td class=bc>-</td><td class=blW>Ma Saveljeva</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ya Galuzo</td><td class=bc>-</td><td class=bl>Vi Sapozhnikov</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ei Rompa</td><td class=bc>11 : 4</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Al Miloradov</td><td class=bc>-</td><td class=bl>Pe Ostlund</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Si Vazhnik</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Al Tarakanov</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Kr Curkovic</td><td class=bc>-</td><td class=bl>Ad Sowa</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ma Curkovic</td><td class=bc>-</td><td class=bl>Ma Saveljeva</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Vi Sapozhnikov</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Es Eidsnes</td><td class=bc>-</td><td class=bl>Ei Rompa</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ya Galuzo</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Pe Ostlund</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ma Nilsson</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Mi Toft Nielsen</td><td class=bc>-</td><td class=bl>Al Tarakanov</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Si Vazhnik</td><td class=bc>-</td><td class=bl>Ad Sowa</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Ma Saveljeva</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Kr Curkovic</td><td class=bc>-</td><td class=blW>Vi Sapozhnikov</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Ma Curkovic</td><td class=bc>-</td><td class=bl>Ei Rompa</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Ge Regula</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Es Eidsnes</td><td class=bc>-</td><td class=blW>Pe Ostlund</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Ya Galuzo</td><td class=bc>-</td><td class=bl>Ma Nilsson</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Al Miloradov</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Al Tarakanov</td><td class=bc>-</td><td class=bl>Ad Sowa</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Ma Saveljeva</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Vi Sapozhnikov</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Ei Rompa</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Kr Curkovic</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ma Curkovic</td><td class=bc>-</td><td class=blW>Pe Ostlund</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Ma Nilsson</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Es Eidsnes</td><td class=bc>-</td><td class=blW>Al Miloradov</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ya Galuzo</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ad Sowa</td><td class=bc>-</td><td class=blW>Ma Saveljeva</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Al Tarakanov</td><td class=bc>-</td><td class=blW>Vi Sapozhnikov</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Ei Rompa</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Ge Regula</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Pe Ostlund</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Kr Curkovic</td><td class=bc>-</td><td class=blW>Ma Nilsson</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ma Curkovic</td><td class=bc>-</td><td class=blW>Al Miloradov</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Es Eidsnes</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ma Saveljeva</td><td class=bc>-</td><td class=bl>Vi Sapozhnikov</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ad Sowa</td><td class=bc>-</td><td class=blW>Ei Rompa</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Al Tarakanov</td><td class=bc>-</td><td class=blW>Ge Regula</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Pe Ostlund</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Ma Nilsson</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Al Miloradov</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Kr Curkovic</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ma Curkovic</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Ya Galuzo</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Vi Sapozhnikov</td><td class=bc>-</td><td class=bl>Ei Rompa</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ma Saveljeva</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>10 : 5</tr></td>
<tr><td class=br>Ad Sowa</td><td class=bc>-</td><td class=blW>Pe Ostlund</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Al Tarakanov</td><td class=bc>-</td><td class=blW>Ma Nilsson</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Al Miloradov</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Kr Curkovic</td><td class=bc>-</td><td class=blW>Ya Galuzo</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ma Curkovic</td><td class=bc>-</td><td class=bl>Es Eidsnes</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ei Rompa</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vi Sapozhnikov</td><td class=bc>-</td><td class=blW>Pe Ostlund</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ma Saveljeva</td><td class=bc>-</td><td class=bl>Ma Nilsson</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ad Sowa</td><td class=bc>-</td><td class=blW>Al Miloradov</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Al Tarakanov</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Ya Galuzo</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Es Eidsnes</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Kr Curkovic</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Pe Ostlund</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ei Rompa</td><td class=bc>-</td><td class=blW>Ma Nilsson</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vi Sapozhnikov</td><td class=bc>-</td><td class=blW>Al Miloradov</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Saveljeva</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ad Sowa</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Tarakanov</td><td class=bc>-</td><td class=blW>Ya Galuzo</td><td class=bc>3 : 9</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Es Eidsnes</td><td class=bc>3 : 9</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Ma Curkovic</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Pe Ostlund</td><td class=bc>-</td><td class=blW>Ma Nilsson</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=bl>Al Miloradov</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ei Rompa</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vi Sapozhnikov</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ma Saveljeva</td><td class=bc>-</td><td class=blW>Ya Galuzo</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ad Sowa</td><td class=bc>-</td><td class=blW>Es Eidsnes</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Al Tarakanov</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Ma Curkovic</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Kr Curkovic</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ma Nilsson</td><td class=bc>-</td><td class=bl>Al Miloradov</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Pe Ostlund</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ei Rompa</td><td class=bc>-</td><td class=blW>Ya Galuzo</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Vi Sapozhnikov</td><td class=bc>-</td><td class=blW>Es Eidsnes</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ma Saveljeva</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ad Sowa</td><td class=bc>-</td><td class=blW>Ma Curkovic</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Al Tarakanov</td><td class=bc>-</td><td class=blW>Kr Curkovic</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Mi Toft Nielsen</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Al Miloradov</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Nilsson</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Pe Ostlund</td><td class=bc>-</td><td class=blW>Ya Galuzo</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=bl>Es Eidsnes</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ei Rompa</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Vi Sapozhnikov</td><td class=bc>-</td><td class=bl>Ma Curkovic</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ma Saveljeva</td><td class=bc>-</td><td class=blW>Kr Curkovic</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Ad Sowa</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Al Tarakanov</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Al Miloradov</td><td class=bc>-</td><td class=blW>Ya Galuzo</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Nilsson</td><td class=bc>-</td><td class=blW>Es Eidsnes</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pe Ostlund</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>Ma Curkovic</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ei Rompa</td><td class=bc>-</td><td class=blW>Kr Curkovic</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Vi Sapozhnikov</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ma Saveljeva</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ad Sowa</td><td class=bc>-</td><td class=blW>Mi Toft Nielsen</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ya Galuzo</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Es Eidsnes</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Al Miloradov</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ma Nilsson</td><td class=bc>-</td><td class=bl>Ma Curkovic</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pe Ostlund</td><td class=bc>-</td><td class=bl>Kr Curkovic</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>11 : 0</tr></td>
<tr><td class=br>Ei Rompa</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Vi Sapozhnikov</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Saveljeva</td><td class=bc>-</td><td class=bl>Al Tarakanov</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ya Galuzo</td><td class=bc>-</td><td class=bl>Es Eidsnes</td><td class=bc>8 : 5</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Ma Curkovic</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Al Miloradov</td><td class=bc>-</td><td class=bl>Kr Curkovic</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Nilsson</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Pe Ostlund</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ei Rompa</td><td class=bc>-</td><td class=bl>Al Tarakanov</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vi Sapozhnikov</td><td class=bc>-</td><td class=bl>Ad Sowa</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Es Eidsnes</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ya Galuzo</td><td class=bc>-</td><td class=bl>Ma Curkovic</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Kr Curkovic</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Al Miloradov</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ma Nilsson</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Pe Ostlund</td><td class=bc>-</td><td class=bl>Al Tarakanov</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>Ad Sowa</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Ei Rompa</td><td class=bc>-</td><td class=blW>Ma Saveljeva</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Ma Curkovic</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Es Eidsnes</td><td class=bc>-</td><td class=blW>Kr Curkovic</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ya Galuzo</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Si Vazhnik</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Al Miloradov</td><td class=bc>-</td><td class=bl>Al Tarakanov</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ma Nilsson</td><td class=bc>-</td><td class=bl>Ad Sowa</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Pe Ostlund</td><td class=bc>-</td><td class=bl>Ma Saveljeva</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>Vi Sapozhnikov</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ma Curkovic</td><td class=bc>-</td><td class=blW>Kr Curkovic</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Es Eidsnes</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ya Galuzo</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Al Tarakanov</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ad Sowa</td><td class=bc>11 : 2</tr></td>
<tr><td class=brW>Al Miloradov</td><td class=bc>-</td><td class=bl>Ma Saveljeva</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Nilsson</td><td class=bc>-</td><td class=bl>Vi Sapozhnikov</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pe Ostlund</td><td class=bc>-</td><td class=bl>Ei Rompa</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Kr Curkovic</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ma Curkovic</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Es Eidsnes</td><td class=bc>-</td><td class=bl>Al Tarakanov</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ya Galuzo</td><td class=bc>-</td><td class=bl>Ad Sowa</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Saveljeva</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Vi Sapozhnikov</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Al Miloradov</td><td class=bc>-</td><td class=bl>Ei Rompa</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Ma Nilsson</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>6 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 5</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Se Ivanov</td><td class=ic>RUS</td><td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kL>1:7</td>
<td class=kW>2:1</td>
<td class=kW>11:1</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kW>8:1</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=br>74:29</td><td class=br>+45</td>
<td class=bc>13 - 3 - 1</td>
<td class=br><strong>29</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ja Dryák</td><td class=ic>CZE</td><td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>1:5</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=br>61:29</td><td class=br>+32</td>
<td class=bc>13 - 2 - 2</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Fi Hamáček</td><td class=ic>CZE</td><td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=br>66:36</td><td class=br>+30</td>
<td class=bc>12 - 4 - 1</td>
<td class=br><strong>28</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ve Gerasimov</td><td class=ic>RUS</td><td class=kW>7:1</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>8:4</td>
<td class=kW>4:3</td>
<td class=kL>4:5</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>8:1</td>
<td class=kW>3:1</td>
<td class=kW>8:0</td>
<td class=kW>6:2</td>
<td class=kW>8:5</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=br>81:40</td><td class=br>+41</td>
<td class=bc>11 - 3 - 3</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Os Henriksson</td><td class=ic>SWE</td><td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>7:1</td>
<td class=kW>5:4</td>
<td class=kW>9:0</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>10:2</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=br>74:31</td><td class=br>+43</td>
<td class=bc>11 - 2 - 4</td>
<td class=br><strong>24</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Gi Lasmanis</td><td class=ic>LAT</td><td class=kL>1:11</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>4:8</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>4:5</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kW>4:3</td>
<td class=kW>7:1</td>
<td class=kW>4:2</td>
<td class=kW>8:2</td>
<td class=kW>5:0</td>
<td class=br>64:54</td><td class=br>+10</td>
<td class=bc>11 - 1 - 5</td>
<td class=br><strong>23</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Be Rjavec</td><td class=ic>SLO</td><td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kL>0:5</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=br>50:32</td><td class=br>+18</td>
<td class=bc>10 - 2 - 5</td>
<td class=br><strong>22</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Bj Axelsen</td><td class=ic>DEN</td><td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kW>5:4</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>9:3</td>
<td class=kL>1:4</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=br>58:45</td><td class=br>+13</td>
<td class=bc>10 - 1 - 6</td>
<td class=br><strong>21</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Be Suominen</td><td class=ic>FIN</td><td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>10:2</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=br>58:34</td><td class=br>+24</td>
<td class=bc>9 - 1 - 7</td>
<td class=br><strong>19</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Am Fylling</td><td class=ic>NOR</td><td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>8:0</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=br>55:45</td><td class=br>+10</td>
<td class=bc>7 - 4 - 6</td>
<td class=br><strong>18</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Pe Borsanyi</td><td class=ic>HUN</td><td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:8</td>
<td class=kL>0:9</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=br>42:52</td><td class=br>-10</td>
<td class=bc>7 - 2 - 8</td>
<td class=br><strong>16</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Mi Černoch</td><td class=ic>CZE</td><td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>39:37</td><td class=br>+2</td>
<td class=bc>6 - 2 - 9</td>
<td class=br><strong>14</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Le Haussknecht</td><td class=ic>GER</td><td class=kL>1:8</td>
<td class=kL>3:5</td>
<td class=kL>4:5</td>
<td class=kL>0:8</td>
<td class=kL>2:6</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kL>3:9</td>
<td class=kL>2:7</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=kW>5:0</td>
<td class=br>48:70</td><td class=br>-22</td>
<td class=bc>5 - 0 - 12</td>
<td class=br><strong>10</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Sa Komaraite</td><td class=ic>LTU</td><td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>2:10</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kW>4:1</td>
<td class=kL>1:6</td>
<td class=kL>0:8</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=br>31:70</td><td class=br>-39</td>
<td class=bc>4 - 1 - 12</td>
<td class=br><strong>9</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ra Klaus</td><td class=ic>SUI</td><td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kL>2:6</td>
<td class=kL>5:8</td>
<td class=kL>2:5</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=br>37:65</td><td class=br>-28</td>
<td class=bc>4 - 1 - 12</td>
<td class=br><strong>9</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Va Hamdamov</td><td class=ic>EST</td><td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>2:10</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=br>32:57</td><td class=br>-25</td>
<td class=bc>2 - 3 - 12</td>
<td class=br><strong>7</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Mi Zeman</td><td class=ic>CZE</td><td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kL>2:8</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>0:7</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=br>30:89</td><td class=br>-59</td>
<td class=bc>1 - 2 - 14</td>
<td class=br><strong>4</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>E</td><td class=d>18.</td><td class=kt>Vj Kufrin</td><td class=ic>CRO</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=br>0:85</td><td class=br>-85</td>
<td class=bc>0 - 0 - 17</td>
<td class=br><strong>0</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Vj Kufrin</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ve Gerasimov</td><td class=bc>-</td><td class=bl>Sa Komaraite</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Ra Klaus</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=blW>Se Ivanov</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Vj Kufrin</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Sa Komaraite</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Ra Klaus</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ve Gerasimov</td><td class=bc>-</td><td class=bl>Se Ivanov</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Fi Hamáček</td><td class=bc>-</td><td class=bl>Os Henriksson</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=blW>Le Haussknecht</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Vj Kufrin</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Sa Komaraite</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ra Klaus</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ja Dryák</td><td class=bc>-</td><td class=blW>Se Ivanov</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ve Gerasimov</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Vj Kufrin</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=bl>Sa Komaraite</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Ra Klaus</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Se Ivanov</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ve Gerasimov</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Vj Kufrin</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Sa Komaraite</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Ra Klaus</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Se Ivanov</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Os Henriksson</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ja Dryák</td><td class=bc>-</td><td class=bl>Fi Hamáček</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Ve Gerasimov</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=blW>Sa Komaraite</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Ra Klaus</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=blW>Se Ivanov</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Le Haussknecht</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Fi Hamáček</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ve Gerasimov</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Dryák</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Sa Komaraite</td><td class=bc>-</td><td class=bl>Ra Klaus</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=blW>Se Ivanov</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Os Henriksson</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>10 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Ve Gerasimov</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ra Klaus</td><td class=bc>-</td><td class=blW>Se Ivanov</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Sa Komaraite</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>2 : 10</tr></td>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=blW>Le Haussknecht</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=bl>Fi Hamáček</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=blW>Ve Gerasimov</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Se Ivanov</td><td class=bc>-</td><td class=bl>Os Henriksson</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ra Klaus</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Sa Komaraite</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=blW>Ve Gerasimov</td><td class=bc>4 : 8</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Se Ivanov</td><td class=bc>-</td><td class=bl>Fi Hamáček</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ra Klaus</td><td class=bc>-</td><td class=blW>Ve Gerasimov</td><td class=bc>5 : 8</tr></td>
<tr><td class=br>Sa Komaraite</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Os Henriksson</td><td class=bc>-</td><td class=bl>Ve Gerasimov</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Se Ivanov</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ra Klaus</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Sa Komaraite</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=blW>Pe Borsanyi</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=bl>Ve Gerasimov</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Le Haussknecht</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Se Ivanov</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ra Klaus</td><td class=bc>-</td><td class=blW>Pe Borsanyi</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Sa Komaraite</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=blW>Mi Zeman</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Se Ivanov</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ra Klaus</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Sa Komaraite</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ve Gerasimov</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=blW>Pe Borsanyi</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>3 : 9</tr></td>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Se Ivanov</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Klaus</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Sa Komaraite</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ve Gerasimov</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Va Hamdamov</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Os Henriksson</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Se Ivanov</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>11 : 1</tr></td>
<tr><td class=brW>Ra Klaus</td><td class=bc>-</td><td class=bl>Vj Kufrin</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Sa Komaraite</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ve Gerasimov</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Vj Kufrin</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Se Ivanov</td><td class=bc>-</td><td class=bl>Sa Komaraite</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ra Klaus</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ve Gerasimov</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Va Hamdamov</td><td class=bc>-</td><td class=bl>Vj Kufrin</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Le Haussknecht</td><td class=bc>-</td><td class=bl>Sa Komaraite</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Ra Klaus</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Se Ivanov</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ve Gerasimov</td><td class=bc>-</td><td class=bl>Vj Kufrin</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Sa Komaraite</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=blW>Ra Klaus</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=blW>Se Ivanov</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Os Henriksson</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 6</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Al Zaharov</td><td class=ic>RUS</td><td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=kW>8:2</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=br>80:29</td><td class=br>+51</td>
<td class=bc>15 - 0 - 2</td>
<td class=br><strong>30</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ev Matantsev</td><td class=ic>UKR</td><td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>5:0</td>
<td class=kW>5:4</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kW>9:1</td>
<td class=kW>7:2</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>8:1</td>
<td class=kW>7:1</td>
<td class=kW>7:2</td>
<td class=kW>9:3</td>
<td class=kW>12:1</td>
<td class=br>92:32</td><td class=br>+60</td>
<td class=bc>13 - 1 - 3</td>
<td class=br><strong>27</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Je Zaharovs</td><td class=ic>LAT</td><td class=kW>5:3</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>11:1</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>8:3</td>
<td class=kW>10:0</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=br>75:38</td><td class=br>+37</td>
<td class=bc>12 - 3 - 2</td>
<td class=br><strong>27</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Lu Turoň</td><td class=ic>CZE</td><td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=kL>3:5</td>
<td class=kW>6:1</td>
<td class=kW>8:2</td>
<td class=kT>3:3</td>
<td class=kW>8:0</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kW>8:3</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>10:2</td>
<td class=br>84:31</td><td class=br>+53</td>
<td class=bc>12 - 1 - 4</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ed Mucenieks</td><td class=ic>LAT</td><td class=kL>3:6</td>
<td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kL>0:7</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>5:7</td>
<td class=kW>6:1</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>7:3</td>
<td class=kW>7:3</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>9:4</td>
<td class=kW>7:1</td>
<td class=kW>11:2</td>
<td class=br>86:51</td><td class=br>+35</td>
<td class=bc>12 - 1 - 4</td>
<td class=br><strong>25</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ar Stolyarov</td><td class=ic>RUS</td><td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>7:4</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=kW>6:4</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>8:0</td>
<td class=br>71:46</td><td class=br>+25</td>
<td class=bc>12 - 1 - 4</td>
<td class=br><strong>25</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ti Valachovič</td><td class=ic>SVK</td><td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=kW>7:5</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>5:7</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kT>5:5</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>10:1</td>
<td class=br>79:53</td><td class=br>+26</td>
<td class=bc>11 - 2 - 4</td>
<td class=br><strong>24</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>My Shalomayev</td><td class=ic>UKR</td><td class=kL>3:4</td>
<td class=kL>1:9</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=br>54:54</td><td class=br>0</td>
<td class=bc>8 - 3 - 6</td>
<td class=br><strong>19</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ju Rautio</td><td class=ic>FIN</td><td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kL>2:8</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>7:5</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=br>55:56</td><td class=br>-1</td>
<td class=bc>8 - 2 - 7</td>
<td class=br><strong>18</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Fi Hansson</td><td class=ic>SWE</td><td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kW>2:0</td>
<td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=br>39:45</td><td class=br>-6</td>
<td class=bc>8 - 2 - 7</td>
<td class=br><strong>18</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>An Engel</td><td class=ic>DEN</td><td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>1:11</td>
<td class=kL>0:8</td>
<td class=kL>3:7</td>
<td class=kL>4:7</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kL>3:6</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kL>3:6</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=br>55:71</td><td class=br>-16</td>
<td class=bc>8 - 1 - 8</td>
<td class=br><strong>17</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ev Tsyupko</td><td class=ic>ISR</td><td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kT>5:5</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>8:1</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kL>3:5</td>
<td class=kW>6:0</td>
<td class=kW>5:3</td>
<td class=br>55:51</td><td class=br>+4</td>
<td class=bc>5 - 2 - 10</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>An Fjermestad</td><td class=ic>NOR</td><td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kL>4:5</td>
<td class=kL>1:8</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=br>46:62</td><td class=br>-16</td>
<td class=bc>6 - 0 - 11</td>
<td class=br><strong>12</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Al Lorand st.</td><td class=ic>SVK</td><td class=kL>1:7</td>
<td class=kL>1:8</td>
<td class=kL>3:8</td>
<td class=kL>3:8</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kW>6:3</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=br>42:77</td><td class=br>-35</td>
<td class=bc>4 - 1 - 12</td>
<td class=br><strong>9</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Be Skrlep</td><td class=ic>SLO</td><td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>0:10</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>4:6</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>9:2</td>
<td class=kW>4:3</td>
<td class=br>32:80</td><td class=br>-48</td>
<td class=bc>2 - 2 - 13</td>
<td class=br><strong>6</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Vl Voronov</td><td class=ic>LTU</td><td class=kL>2:8</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>4:9</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>0:2</td>
<td class=br>38:75</td><td class=br>-37</td>
<td class=bc>2 - 1 - 14</td>
<td class=br><strong>5</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Pa Petrik</td><td class=ic>LTU</td><td class=kL>0:7</td>
<td class=kL>3:9</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>0:7</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kL>2:9</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=br>25:91</td><td class=br>-66</td>
<td class=bc>2 - 0 - 15</td>
<td class=br><strong>4</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>E</td><td class=d>18.</td><td class=kt>Zy Remeika</td><td class=ic>LTU</td><td class=kL>1:5</td>
<td class=kL>1:12</td>
<td class=kL>1:2</td>
<td class=kL>2:10</td>
<td class=kL>2:11</td>
<td class=kL>0:8</td>
<td class=kL>1:10</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=br>28:94</td><td class=br>-66</td>
<td class=bc>1 - 1 - 15</td>
<td class=br><strong>3</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>An Engel</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>1 : 11</tr></td>
<tr><td class=br>Ev Tsyupko</td><td class=bc>-</td><td class=blW>Al Zaharov</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Fi Hansson</td><td class=bc>-</td><td class=blW>Ti Valachovič</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ed Mucenieks</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Pa Petrik</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Al Zaharov</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>An Engel</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ev Tsyupko</td><td class=bc>-</td><td class=bl>Ti Valachovič</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Fi Hansson</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Ed Mucenieks</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>11 : 2</tr></td>
<tr><td class=br>Pa Petrik</td><td class=bc>-</td><td class=blW>Ju Rautio</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Al Zaharov</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=blW>Ti Valachovič</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>An Engel</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ev Tsyupko</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Fi Hansson</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ed Mucenieks</td><td class=bc>-</td><td class=bl>Pa Petrik</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Ti Valachovič</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Al Zaharov</td><td class=bc>-</td><td class=bl>Lu Turoň</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Ar Stolyarov</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>An Engel</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ev Tsyupko</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Fi Hansson</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Pa Petrik</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ed Mucenieks</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ti Valachovič</td><td class=bc>-</td><td class=bl>Lu Turoň</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Al Zaharov</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>An Engel</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ev Tsyupko</td><td class=bc>-</td><td class=blW>Ju Rautio</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Pa Petrik</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Fi Hansson</td><td class=bc>-</td><td class=blW>Ed Mucenieks</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Ar Stolyarov</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ti Valachovič</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Al Zaharov</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>An Engel</td><td class=bc>-</td><td class=bl>Pa Petrik</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ev Tsyupko</td><td class=bc>-</td><td class=blW>Ed Mucenieks</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Fi Hansson</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ar Stolyarov</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ti Valachovič</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Ju Rautio</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Al Zaharov</td><td class=bc>-</td><td class=bl>Pa Petrik</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=bl>Ed Mucenieks</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>An Engel</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ev Tsyupko</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Fi Hansson</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ar Stolyarov</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Ju Rautio</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Ti Valachovič</td><td class=bc>-</td><td class=bl>Pa Petrik</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Ed Mucenieks</td><td class=bc>4 : 9</tr></td>
<tr><td class=brW>Al Zaharov</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>An Engel</td><td class=bc>-</td><td class=bl>Fi Hansson</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ev Tsyupko</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>8 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=blW>Ju Rautio</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ar Stolyarov</td><td class=bc>-</td><td class=bl>Pa Petrik</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Ed Mucenieks</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ti Valachovič</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Al Lorand st.</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Al Zaharov</td><td class=bc>-</td><td class=bl>Fi Hansson</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Je Zaharovs</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>An Engel</td><td class=bc>-</td><td class=bl>Ev Tsyupko</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Pa Petrik</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ed Mucenieks</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ar Stolyarov</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Lu Turoň</td><td class=bc>-</td><td class=bl>Fi Hansson</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ti Valachovič</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Vl Voronov</td><td class=bc>-</td><td class=bl>Ev Tsyupko</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Al Zaharov</td><td class=bc>-</td><td class=bl>An Engel</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Je Zaharovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=blW>Ed Mucenieks</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 12</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=blW>Fi Hansson</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ar Stolyarov</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Ev Tsyupko</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ti Valachovič</td><td class=bc>-</td><td class=blW>An Engel</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Zaharov</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Pa Petrik</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>3 : 9</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Fi Hansson</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=blW>Ev Tsyupko</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ar Stolyarov</td><td class=bc>-</td><td class=bl>An Engel</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Lu Turoň</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ti Valachovič</td><td class=bc>-</td><td class=blW>Al Zaharov</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ed Mucenieks</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pa Petrik</td><td class=bc>-</td><td class=blW>Fi Hansson</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Ev Tsyupko</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>An Engel</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Ar Stolyarov</td><td class=bc>-</td><td class=bl>Al Zaharov</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Lu Turoň</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ti Valachovič</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=blW>Fi Hansson</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ed Mucenieks</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pa Petrik</td><td class=bc>-</td><td class=blW>Ev Tsyupko</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>An Engel</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Al Zaharov</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ar Stolyarov</td><td class=bc>-</td><td class=bl>Ti Valachovič</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Lu Turoň</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ev Tsyupko</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ed Mucenieks</td><td class=bc>-</td><td class=bl>An Engel</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Pa Petrik</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=blW>Al Zaharov</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ti Valachovič</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ar Stolyarov</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Fi Hansson</td><td class=bc>-</td><td class=bl>Ev Tsyupko</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>An Engel</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ed Mucenieks</td><td class=bc>-</td><td class=blW>Al Zaharov</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Pa Petrik</td><td class=bc>-</td><td class=blW>Vl Voronov</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ju Rautio</td><td class=bc>-</td><td class=bl>Ti Valachovič</td><td class=bc>7 : 5</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>2 : 10</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Ar Stolyarov</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>An Engel</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Fi Hansson</td><td class=bc>-</td><td class=bl>Je Zaharovs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Al Zaharov</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ed Mucenieks</td><td class=bc>-</td><td class=blW>Ti Valachovič</td><td class=bc>5 : 7</tr></td>
<tr><td class=br>Pa Petrik</td><td class=bc>-</td><td class=blW>Lu Turoň</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=blW>Ar Stolyarov</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Be Skrlep</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ev Tsyupko</td><td class=bc>-</td><td class=blW>Je Zaharovs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Al Zaharov</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Fi Hansson</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Ti Valachovič</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Lu Turoň</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ed Mucenieks</td><td class=bc>-</td><td class=bl>Ar Stolyarov</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pa Petrik</td><td class=bc>-</td><td class=blW>Be Skrlep</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Ju Rautio</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 7</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ha Österman</td><td class=ic>SWE</td><td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>9:1</td>
<td class=kW>5:0</td>
<td class=br>66:18</td><td class=br>+48</td>
<td class=bc>15 - 2 - 0</td>
<td class=br><strong>32</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ed Saulitis</td><td class=ic>LAT</td><td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kW>5:4</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=br>53:27</td><td class=br>+26</td>
<td class=bc>13 - 1 - 3</td>
<td class=br><strong>27</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ye Levdansky</td><td class=ic>UKR</td><td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=br>64:24</td><td class=br>+40</td>
<td class=bc>13 - 1 - 3</td>
<td class=br><strong>27</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>An Vuononsola</td><td class=ic>FIN</td><td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>8:1</td>
<td class=kW>9:3</td>
<td class=kW>4:0</td>
<td class=kW>8:1</td>
<td class=kW>10:0</td>
<td class=br>74:33</td><td class=br>+41</td>
<td class=bc>11 - 2 - 4</td>
<td class=br><strong>24</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ni Zholobov</td><td class=ic>RUS</td><td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=kW>10:2</td>
<td class=kW>5:0</td>
<td class=br>77:36</td><td class=br>+41</td>
<td class=bc>11 - 1 - 5</td>
<td class=br><strong>23</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Je Lvov</td><td class=ic>EST</td><td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>7:5</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>53:37</td><td class=br>+16</td>
<td class=bc>11 - 1 - 5</td>
<td class=br><strong>23</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ve Huotelin</td><td class=ic>FIN</td><td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kL>5:7</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>7:4</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>8:2</td>
<td class=kW>8:1</td>
<td class=kW>6:1</td>
<td class=kW>10:0</td>
<td class=br>80:44</td><td class=br>+36</td>
<td class=bc>10 - 2 - 5</td>
<td class=br><strong>22</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Da Matýsek</td><td class=ic>CZE</td><td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kL>1:6</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>5:0</td>
<td class=br>48:46</td><td class=br>+2</td>
<td class=bc>8 - 4 - 5</td>
<td class=br><strong>20</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ig Saveljev</td><td class=ic>EST</td><td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kW>2:0</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kW>7:0</td>
<td class=kW>13:3</td>
<td class=kW>5:0</td>
<td class=br>52:41</td><td class=br>+11</td>
<td class=bc>8 - 2 - 7</td>
<td class=br><strong>18</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Es Moe</td><td class=ic>NOR</td><td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kL>0:6</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>9:0</td>
<td class=kW>5:0</td>
<td class=br>49:42</td><td class=br>+7</td>
<td class=bc>7 - 4 - 6</td>
<td class=br><strong>18</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Li Restel</td><td class=ic>GER</td><td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>4:7</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kW>7:3</td>
<td class=kW>5:0</td>
<td class=br>44:42</td><td class=br>+2</td>
<td class=bc>6 - 3 - 8</td>
<td class=br><strong>15</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>I  Vépy</td><td class=ic>SVK</td><td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>39:49</td><td class=br>-10</td>
<td class=bc>6 - 1 - 10</td>
<td class=br><strong>13</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Mi Margolis</td><td class=ic>ISR</td><td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>0:7</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>38:53</td><td class=br>-15</td>
<td class=bc>6 - 1 - 10</td>
<td class=br><strong>13</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Al Metelitsa</td><td class=ic>EST</td><td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>0:4</td>
<td class=kL>1:8</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>30:48</td><td class=br>-18</td>
<td class=bc>5 - 2 - 10</td>
<td class=br><strong>12</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Je Klaus</td><td class=ic>SUI</td><td class=kL>0:4</td>
<td class=kL>4:5</td>
<td class=kL>2:7</td>
<td class=kL>3:9</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kL>2:8</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kW>5:0</td>
<td class=br>43:70</td><td class=br>-27</td>
<td class=bc>4 - 1 - 12</td>
<td class=br><strong>9</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Ra Pommerenke</td><td class=ic>GER</td><td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kL>0:7</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=br>19:54</td><td class=br>-35</td>
<td class=bc>3 - 1 - 13</td>
<td class=br><strong>7</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Ol Majaniemi</td><td class=ic>SUI</td><td class=kL>1:9</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>1:8</td>
<td class=kL>2:10</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kT>4:4</td>
<td class=kL>3:13</td>
<td class=kL>0:9</td>
<td class=kL>3:7</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=br>32:102</td><td class=br>-70</td>
<td class=bc>1 - 1 - 15</td>
<td class=br><strong>3</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>E</td><td class=d>18.</td><td class=kt>Ro Locher</td><td class=ic>SUI</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:10</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:10</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=br>0:95</td><td class=br>-95</td>
<td class=bc>0 - 0 - 17</td>
<td class=br><strong>0</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ni Zholobov</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Je Klaus</td><td class=bc>-</td><td class=blW>An Vuononsola</td><td class=bc>3 : 9</tr></td>
<tr><td class=brW>Ye Levdansky</td><td class=bc>-</td><td class=bl>I  Vépy</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Je Lvov</td><td class=bc>-</td><td class=blW>Ed Saulitis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>Li Restel</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Mi Margolis</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Ha Österman</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ni Zholobov</td><td class=bc>-</td><td class=blW>An Vuononsola</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>I  Vépy</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Je Klaus</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ye Levdansky</td><td class=bc>-</td><td class=blW>Ed Saulitis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>Li Restel</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Je Lvov</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>Ha Österman</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Es Moe</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>An Vuononsola</td><td class=bc>-</td><td class=bl>I  Vépy</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ni Zholobov</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ed Saulitis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Je Klaus</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ye Levdansky</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>Ha Österman</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Je Lvov</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>Al Metelitsa</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Vuononsola</td><td class=bc>-</td><td class=blW>Ed Saulitis</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ni Zholobov</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Je Klaus</td><td class=bc>-</td><td class=blW>Ha Österman</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ye Levdansky</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>Al Metelitsa</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Je Lvov</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>Mi Margolis</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ed Saulitis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=blW>Li Restel</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>An Vuononsola</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ni Zholobov</td><td class=bc>-</td><td class=blW>Ha Österman</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Je Klaus</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ye Levdansky</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>Mi Margolis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Je Lvov</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ed Saulitis</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=blW>Ha Österman</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>An Vuononsola</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ni Zholobov</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Je Klaus</td><td class=bc>-</td><td class=blW>Mi Margolis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ye Levdansky</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>Je Lvov</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Li Restel</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ed Saulitis</td><td class=bc>-</td><td class=blW>Ha Österman</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Vuononsola</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ni Zholobov</td><td class=bc>-</td><td class=blW>Mi Margolis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Je Klaus</td><td class=bc>-</td><td class=blW>Je Lvov</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ye Levdansky</td><td class=bc>-</td><td class=bl>Ro Locher</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Ha Österman</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ed Saulitis</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>I  Vépy</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>An Vuononsola</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ni Zholobov</td><td class=bc>-</td><td class=bl>Je Lvov</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ro Locher</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Je Klaus</td><td class=bc>-</td><td class=blW>Ye Levdansky</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ha Österman</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Al Metelitsa</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Li Restel</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ed Saulitis</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>13 : 3</tr></td>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=blW>Je Lvov</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>An Vuononsola</td><td class=bc>-</td><td class=bl>Ro Locher</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Ni Zholobov</td><td class=bc>-</td><td class=bl>Ye Levdansky</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Je Klaus</td><td class=bc>8 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Es Moe</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ha Österman</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=blW>Je Lvov</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ed Saulitis</td><td class=bc>-</td><td class=bl>Ro Locher</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Ye Levdansky</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>I  Vépy</td><td class=bc>-</td><td class=bl>Je Klaus</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>An Vuononsola</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ni Zholobov</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Al Metelitsa</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Es Moe</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Ha Österman</td><td class=bc>-</td><td class=bl>Je Lvov</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Ro Locher</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=blW>Ye Levdansky</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ed Saulitis</td><td class=bc>-</td><td class=bl>Je Klaus</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>An Vuononsola</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=blW>Je Lvov</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Es Moe</td><td class=bc>-</td><td class=bl>Ro Locher</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ha Österman</td><td class=bc>-</td><td class=bl>Ye Levdansky</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Je Klaus</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Ed Saulitis</td><td class=bc>-</td><td class=bl>Ni Zholobov</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>An Vuononsola</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Mi Margolis</td><td class=bc>-</td><td class=bl>Je Lvov</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ro Locher</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=blW>Ye Levdansky</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Es Moe</td><td class=bc>-</td><td class=bl>Je Klaus</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ha Österman</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=blW>An Vuononsola</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ed Saulitis</td><td class=bc>-</td><td class=bl>I  Vépy</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ol Majaniemi</td><td class=bc>-</td><td class=bl>Ro Locher</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Ye Levdansky</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Je Klaus</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Es Moe</td><td class=bc>-</td><td class=bl>Ni Zholobov</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ha Österman</td><td class=bc>-</td><td class=bl>An Vuononsola</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>I  Vépy</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ed Saulitis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Je Lvov</td><td class=bc>-</td><td class=blW>Ye Levdansky</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>Je Klaus</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=blW>An Vuononsola</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Es Moe</td><td class=bc>-</td><td class=bl>I  Vépy</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ha Österman</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Ed Saulitis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>Je Klaus</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Je Lvov</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>7 : 5</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>2 : 10</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>An Vuononsola</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>I  Vépy</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Al Metelitsa</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Es Moe</td><td class=bc>-</td><td class=bl>Ed Saulitis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ha Österman</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ye Levdansky</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Je Lvov</td><td class=bc>-</td><td class=bl>An Vuononsola</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>I  Vépy</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ed Saulitis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=blW>Li Restel</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Es Moe</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ha Österman</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Je Klaus</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ye Levdansky</td><td class=bc>-</td><td class=bl>An Vuononsola</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>I  Vépy</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Je Lvov</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>Ed Saulitis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=blW>Ha Österman</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Es Moe</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group 8</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ol Korabel</td><td class=ic>UKR</td><td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=br>59:24</td><td class=br>+35</td>
<td class=bc>12 - 4 - 1</td>
<td class=br><strong>28</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Al Titov</td><td class=ic>RUS</td><td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>9:0</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=br>62:25</td><td class=br>+37</td>
<td class=bc>13 - 2 - 2</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Le Hvižď ml.</td><td class=ic>CZE</td><td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>3:6</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=kW>3:1</td>
<td class=kW>8:1</td>
<td class=kW>4:1</td>
<td class=kW>11:1</td>
<td class=kW>8:0</td>
<td class=kW>4:2</td>
<td class=br>72:26</td><td class=br>+46</td>
<td class=bc>11 - 4 - 2</td>
<td class=br><strong>26</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ja Pelkonen</td><td class=ic>FIN</td><td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>8:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>9:2</td>
<td class=kW>7:1</td>
<td class=br>72:30</td><td class=br>+42</td>
<td class=bc>11 - 4 - 2</td>
<td class=br><strong>26</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Gr Dubinin</td><td class=ic>RUS</td><td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>7:0</td>
<td class=kW>10:0</td>
<td class=br>65:23</td><td class=br>+42</td>
<td class=bc>11 - 4 - 2</td>
<td class=br><strong>26</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Em Larsson</td><td class=ic>SWE</td><td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>8:3</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=br>65:36</td><td class=br>+29</td>
<td class=bc>10 - 4 - 3</td>
<td class=br><strong>24</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Dm Malygin</td><td class=ic>RUS</td><td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=kW>4:3</td>
<td class=kW>8:0</td>
<td class=kW>7:1</td>
<td class=br>62:32</td><td class=br>+30</td>
<td class=bc>10 - 2 - 5</td>
<td class=br><strong>22</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>ml Chylík</td><td class=ic>CZE</td><td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=br>48:33</td><td class=br>+15</td>
<td class=bc>10 - 2 - 5</td>
<td class=br><strong>22</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ja Sahlgren</td><td class=ic>FIN</td><td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>3:6</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=br>46:39</td><td class=br>+7</td>
<td class=bc>9 - 1 - 7</td>
<td class=br><strong>19</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Fr Axelsson</td><td class=ic>SWE</td><td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>1:0</td>
<td class=kW>6:2</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>9:1</td>
<td class=br>52:47</td><td class=br>+5</td>
<td class=bc>8 - 1 - 8</td>
<td class=br><strong>17</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Yu Artamonov</td><td class=ic>EST</td><td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kW>6:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=br>38:55</td><td class=br>-17</td>
<td class=bc>6 - 1 - 10</td>
<td class=br><strong>13</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Al Dalgou</td><td class=ic>BLR</td><td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kL>1:4</td>
<td class=br>28:55</td><td class=br>-27</td>
<td class=bc>5 - 1 - 11</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Fr Suma</td><td class=ic>SVK</td><td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=br>32:46</td><td class=br>-14</td>
<td class=bc>5 - 1 - 11</td>
<td class=br><strong>11</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ma Satkus</td><td class=ic>LTU</td><td class=kL>1:5</td>
<td class=kL>0:9</td>
<td class=kL>1:8</td>
<td class=kL>2:8</td>
<td class=kL>1:6</td>
<td class=kL>3:8</td>
<td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=br>40:73</td><td class=br>-33</td>
<td class=bc>4 - 2 - 11</td>
<td class=br><strong>10</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ig Zaporojets</td><td class=ic>UKR</td><td class=kL>2:7</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=br>34:55</td><td class=br>-21</td>
<td class=bc>4 - 0 - 13</td>
<td class=br><strong>8</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Vi Magyari</td><td class=ic>HUN</td><td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>1:11</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=br>27:64</td><td class=br>-37</td>
<td class=bc>3 - 2 - 12</td>
<td class=br><strong>8</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Mi Skrlep</td><td class=ic>SLO</td><td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>0:8</td>
<td class=kL>2:9</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>0:7</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>14:87</td><td class=br>-73</td>
<td class=bc>2 - 0 - 15</td>
<td class=br><strong>4</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>E</td><td class=d>18.</td><td class=kt>Ma Pikat</td><td class=ic>EST</td><td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>0:10</td>
<td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:9</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>17:83</td><td class=br>-66</td>
<td class=bc>1 - 1 - 15</td>
<td class=br><strong>3</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Yu Artamonov</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Fr Axelsson</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Al Dalgou</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Gr Dubinin</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Ja Sahlgren</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Em Larsson</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=blW>Dm Malygin</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Yu Artamonov</td><td class=bc>-</td><td class=blW>Fr Suma</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Fr Axelsson</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Al Dalgou</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Gr Dubinin</td><td class=bc>-</td><td class=bl>Ja Sahlgren</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=bl>Dm Malygin</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Vi Magyari</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Al Titov</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=blW>Mi Skrlep</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Yu Artamonov</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Fr Axelsson</td><td class=bc>-</td><td class=blW>Ja Sahlgren</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al Dalgou</td><td class=bc>-</td><td class=blW>Ma Pikat</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Gr Dubinin</td><td class=bc>-</td><td class=bl>Ja Pelkonen</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Dm Malygin</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Vi Magyari</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Fr Suma</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Al Titov</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=blW>Ja Sahlgren</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Yu Artamonov</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fr Axelsson</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Al Dalgou</td><td class=bc>-</td><td class=blW>Dm Malygin</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Gr Dubinin</td><td class=bc>-</td><td class=bl>Vi Magyari</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=blW>Ja Sahlgren</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Al Titov</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Yu Artamonov</td><td class=bc>-</td><td class=bl>Dm Malygin</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Fr Axelsson</td><td class=bc>-</td><td class=blW>Vi Magyari</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al Dalgou</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Gr Dubinin</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Ja Sahlgren</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Skrlep</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Al Titov</td><td class=bc>-</td><td class=bl>Dm Malygin</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ig Zaporojets</td><td class=bc>-</td><td class=bl>Vi Magyari</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Yu Artamonov</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fr Axelsson</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Dalgou</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gr Dubinin</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Dm Malygin</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Fr Suma</td><td class=bc>-</td><td class=bl>Vi Magyari</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Al Titov</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Yu Artamonov</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Fr Axelsson</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Dalgou</td><td class=bc>-</td><td class=blW>Gr Dubinin</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Dm Malygin</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=bl>Vi Magyari</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Al Titov</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Yu Artamonov</td><td class=bc>-</td><td class=blW>Gr Dubinin</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Fr Axelsson</td><td class=bc>-</td><td class=bl>Al Dalgou</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ja Pelkonen</td><td class=bc>-</td><td class=blW>Dm Malygin</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>Vi Magyari</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ja Sahlgren</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Al Titov</td><td class=bc>-</td><td class=blW>Gr Dubinin</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=blW>Al Dalgou</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Yu Artamonov</td><td class=bc>-</td><td class=blW>Fr Axelsson</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Dm Malygin</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Sahlgren</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Gr Dubinin</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Al Dalgou</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=blW>Fr Axelsson</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Al Titov</td><td class=bc>-</td><td class=bl>Yu Artamonov</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Dm Malygin</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>Gr Dubinin</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Al Dalgou</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Fr Axelsson</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Yu Artamonov</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Fr Suma</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Al Titov</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 11</tr></td>
<tr><td class=br>Dm Malygin</td><td class=bc>-</td><td class=bl>Gr Dubinin</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Al Dalgou</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>Fr Axelsson</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Ja Sahlgren</td><td class=bc>-</td><td class=blW>Yu Artamonov</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Em Larsson</td><td class=bc>-</td><td class=bl>Gr Dubinin</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=blW>Al Dalgou</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Dm Malygin</td><td class=bc>-</td><td class=bl>Fr Axelsson</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Yu Artamonov</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>Ig Zaporojets</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ja Sahlgren</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=bl>Gr Dubinin</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Al Dalgou</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Em Larsson</td><td class=bc>-</td><td class=blW>Fr Axelsson</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=blW>Yu Artamonov</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Dm Malygin</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ja Pelkonen</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>Fr Suma</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Al Dalgou</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Fr Axelsson</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Yu Artamonov</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Em Larsson</td><td class=bc>-</td><td class=blW>Ig Zaporojets</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Dm Malygin</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ja Sahlgren</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Gr Dubinin</td><td class=bc>-</td><td class=bl>Fr Axelsson</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Yu Artamonov</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Al Titov</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Vi Magyari</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Dm Malygin</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Ja Sahlgren</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Al Dalgou</td><td class=bc>-</td><td class=blW>Yu Artamonov</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Gr Dubinin</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Al Titov</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=blW>Ja Sahlgren</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Dm Malygin</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ja Pelkonen</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Fr Axelsson</td><td class=bc>-</td><td class=blW>Ig Zaporojets</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Al Dalgou</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Gr Dubinin</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Ja Sahlgren</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=bl>Ja Pelkonen</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Dm Malygin</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</table></div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
