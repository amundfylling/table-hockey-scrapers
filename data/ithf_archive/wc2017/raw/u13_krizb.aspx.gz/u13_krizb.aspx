<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>U13</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>U13 Results</span></h2></div></div></div></div><h3 align="right">Basic Groups&nbsp;&nbsp;</h3>
<p><div align="center">
<p class=v>Group U13</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Ev Matantsev</td><td class=ic>UKR</td><td class=kx>*</td>
<td class=kW>8:3</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>5:2</td>
<td class=kW>13:1</td>
<td class=kW>10:0</td>
<td class=kW>9:1</td>
<td class=kW>3:1</td>
<td class=kW>13:1</td>
<td class=kW>13:0</td>
<td class=kW>9:1</td>
<td class=kW>14:0</td>
<td class=br>132:17</td><td class=br>+115</td>
<td class=bc>18 - 1 - 0</td>
<td class=br><strong>37</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Un Österman</td><td class=ic>SWE</td><td class=kL>3:8</td>
<td class=kx>*</td>
<td class=kW>8:3</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>8:3</td>
<td class=kW>7:0</td>
<td class=kW>6:0</td>
<td class=kW>8:3</td>
<td class=kW>10:0</td>
<td class=kW>9:0</td>
<td class=br>99:33</td><td class=br>+66</td>
<td class=bc>17 - 1 - 1</td>
<td class=br><strong>35</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Ja Matýsek</td><td class=ic>CZE</td><td class=kT>2:2</td>
<td class=kL>3:8</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>4:5</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=kW>10:1</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=br>74:31</td><td class=br>+43</td>
<td class=bc>13 - 2 - 4</td>
<td class=br><strong>28</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Ni Blomberg</td><td class=ic>SWE</td><td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=br>54:35</td><td class=br>+19</td>
<td class=bc>13 - 2 - 4</td>
<td class=br><strong>28</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=d>5.</td><td class=kt>Kr Riekstinš</td><td class=ic>LAT</td><td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=br>52:22</td><td class=br>+30</td>
<td class=bc>12 - 4 - 3</td>
<td class=br><strong>28</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=d>6.</td><td class=kt>Ha Ivantsova</td><td class=ic>UKR</td><td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>9:0</td>
<td class=kW>7:0</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=br>60:25</td><td class=br>+35</td>
<td class=bc>10 - 5 - 4</td>
<td class=br><strong>25</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/4</td><td class=d>7.</td><td class=kt>Iv Smirnov</td><td class=ic>RUS</td><td class=kL>1:7</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>7:0</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>10:0</td>
<td class=kW>2:0</td>
<td class=kW>6:0</td>
<td class=br>68:31</td><td class=br>+37</td>
<td class=bc>11 - 2 - 6</td>
<td class=br><strong>24</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/4</td><td class=d>8.</td><td class=kt>Re Liepinš</td><td class=ic>LAT</td><td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kW>5:3</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kL>0:2</td>
<td class=kL>0:7</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kL>0:3</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kW>8:2</td>
<td class=kW>11:1</td>
<td class=kW>6:0</td>
<td class=kW>10:0</td>
<td class=br>72:48</td><td class=br>+24</td>
<td class=bc>11 - 1 - 7</td>
<td class=br><strong>23</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Ri Sinicins</td><td class=ic>LAT</td><td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>7:0</td>
<td class=kW>4:2</td>
<td class=kW>7:0</td>
<td class=br>51:31</td><td class=br>+20</td>
<td class=bc>9 - 5 - 5</td>
<td class=br><strong>23</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ar Matantsev</td><td class=ic>UKR</td><td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>11:0</td>
<td class=kW>6:0</td>
<td class=kW>10:0</td>
<td class=br>68:41</td><td class=br>+27</td>
<td class=bc>10 - 2 - 7</td>
<td class=br><strong>22</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>De Andrijashkin</td><td class=ic>EST</td><td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kW>5:4</td>
<td class=kW>4:3</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kW>6:0</td>
<td class=kW>8:0</td>
<td class=kW>6:0</td>
<td class=br>56:41</td><td class=br>+15</td>
<td class=bc>10 - 2 - 7</td>
<td class=br><strong>22</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ti Roholm</td><td class=ic>FIN</td><td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>10:0</td>
<td class=br>55:45</td><td class=br>+10</td>
<td class=bc>7 - 3 - 9</td>
<td class=br><strong>17</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Jo Roholm</td><td class=ic>FIN</td><td class=kL>1:13</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>8:1</td>
<td class=kW>3:0</td>
<td class=kW>7:0</td>
<td class=br>48:52</td><td class=br>-4</td>
<td class=bc>6 - 4 - 9</td>
<td class=br><strong>16</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Mi Skrlep</td><td class=ic>SLO</td><td class=kL>0:10</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=kW>5:2</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=br>40:54</td><td class=br>-14</td>
<td class=bc>6 - 2 - 11</td>
<td class=br><strong>14</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Li Österman</td><td class=ic>SWE</td><td class=kL>1:9</td>
<td class=kL>3:8</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kW>4:0</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=br>34:60</td><td class=br>-26</td>
<td class=bc>4 - 4 - 11</td>
<td class=br><strong>12</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Fi Kalinouski</td><td class=ic>BLR</td><td class=kL>1:3</td>
<td class=kL>0:7</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=br>32:59</td><td class=br>-27</td>
<td class=bc>4 - 2 - 13</td>
<td class=br><strong>10</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ví Perkner</td><td class=ic>CZE</td><td class=kL>1:13</td>
<td class=kL>0:6</td>
<td class=kL>0:8</td>
<td class=kL>3:5</td>
<td class=kL>0:3</td>
<td class=kL>0:9</td>
<td class=kL>1:7</td>
<td class=kL>2:8</td>
<td class=kL>2:7</td>
<td class=kL>1:7</td>
<td class=kW>4:3</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>0:8</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=br>26:101</td><td class=br>-75</td>
<td class=bc>3 - 2 - 14</td>
<td class=br><strong>8</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Jo Perkner</td><td class=ic>CZE</td><td class=kL>0:13</td>
<td class=kL>3:8</td>
<td class=kL>1:10</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>0:7</td>
<td class=kL>0:10</td>
<td class=kL>1:11</td>
<td class=kL>0:7</td>
<td class=kL>0:11</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>1:8</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=br>19:123</td><td class=br>-104</td>
<td class=bc>2 - 0 - 17</td>
<td class=br><strong>4</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Mo Skrlep</td><td class=ic>SLO</td><td class=kL>1:9</td>
<td class=kL>0:10</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>0:6</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=br>7:85</td><td class=br>-78</td>
<td class=bc>1 - 0 - 18</td>
<td class=br><strong>2</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Ni Cornelius</td><td class=ic>CHI</td><td class=kL>0:14</td>
<td class=kL>0:9</td>
<td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>0:10</td>
<td class=kL>0:7</td>
<td class=kL>0:10</td>
<td class=kL>0:6</td>
<td class=kL>0:10</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=br>6:119</td><td class=br>-113</td>
<td class=bc>0 - 2 - 17</td>
<td class=br><strong>2</strong></td><td class=d>20.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>De Andrijashkin</td><td class=bc>-</td><td class=blW>Iv Smirnov</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ni Blomberg</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Mi Skrlep</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Ri Sinicins</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Ti Roholm</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Re Liepinš</td><td class=bc>-</td><td class=bl>Jo Roholm</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Kr Riekstinš</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Li Österman</td><td class=bc>-</td><td class=blW>Un Österman</td><td class=bc>3 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Iv Smirnov</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>De Andrijashkin</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ni Blomberg</td><td class=bc>-</td><td class=bl>Ri Sinicins</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Ti Roholm</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Jo Roholm</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Kr Riekstinš</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Re Liepinš</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>13 : 0</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Un Österman</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Li Österman</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=blW>Mi Skrlep</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Iv Smirnov</td><td class=bc>-</td><td class=bl>Ri Sinicins</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>De Andrijashkin</td><td class=bc>-</td><td class=bl>Ti Roholm</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ni Blomberg</td><td class=bc>-</td><td class=bl>Jo Roholm</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Kr Riekstinš</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Fi Kalinouski</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Re Liepinš</td><td class=bc>-</td><td class=blW>Un Österman</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Li Österman</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=bl>Ri Sinicins</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=blW>Ti Roholm</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Iv Smirnov</td><td class=bc>-</td><td class=bl>Jo Roholm</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>De Andrijashkin</td><td class=bc>-</td><td class=blW>Kr Riekstinš</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ni Blomberg</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=blW>Un Österman</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Li Österman</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Re Liepinš</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ri Sinicins</td><td class=bc>-</td><td class=bl>Ti Roholm</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Jo Roholm</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=blW>Kr Riekstinš</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Iv Smirnov</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>De Andrijashkin</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ni Blomberg</td><td class=bc>-</td><td class=blW>Un Österman</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=bl>Li Österman</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Re Liepinš</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ti Roholm</td><td class=bc>-</td><td class=bl>Jo Roholm</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ri Sinicins</td><td class=bc>-</td><td class=bl>Kr Riekstinš</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Mi Skrlep</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=blW>Jo Perkner</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Iv Smirnov</td><td class=bc>-</td><td class=blW>Un Österman</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>De Andrijashkin</td><td class=bc>-</td><td class=bl>Li Österman</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ni Blomberg</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=bl>Re Liepinš</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Jo Roholm</td><td class=bc>-</td><td class=bl>Kr Riekstinš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ti Roholm</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ri Sinicins</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Un Österman</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=blW>Li Österman</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Iv Smirnov</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>De Andrijashkin</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ni Blomberg</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Re Liepinš</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Kr Riekstinš</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Jo Roholm</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Ti Roholm</td><td class=bc>-</td><td class=blW>Un Österman</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ri Sinicins</td><td class=bc>-</td><td class=blW>Li Österman</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Iv Smirnov</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>De Andrijashkin</td><td class=bc>-</td><td class=bl>Re Liepinš</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ni Blomberg</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kr Riekstinš</td><td class=bc>-</td><td class=blW>Un Österman</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Jo Roholm</td><td class=bc>-</td><td class=bl>Li Österman</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ti Roholm</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ri Sinicins</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=blW>Re Liepinš</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Iv Smirnov</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>De Andrijashkin</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ni Blomberg</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Un Österman</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=bl>Li Österman</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kr Riekstinš</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Jo Roholm</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ti Roholm</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ri Sinicins</td><td class=bc>-</td><td class=blW>Re Liepinš</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Mi Skrlep</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Iv Smirnov</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>De Andrijashkin</td><td class=bc>-</td><td class=bl>Ni Blomberg</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Un Österman</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 13</tr></td>
<tr><td class=brW>Kr Riekstinš</td><td class=bc>-</td><td class=bl>Re Liepinš</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Jo Roholm</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ti Roholm</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ri Sinicins</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Ni Blomberg</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=blW>De Andrijashkin</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Iv Smirnov</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Li Österman</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Un Österman</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Re Liepinš</td><td class=bc>1 : 11</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Fi Kalinouski</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kr Riekstinš</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Jo Roholm</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ti Roholm</td><td class=bc>-</td><td class=blW>Ni Blomberg</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ri Sinicins</td><td class=bc>-</td><td class=bl>De Andrijashkin</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Iv Smirnov</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Li Österman</td><td class=bc>-</td><td class=blW>Re Liepinš</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Un Österman</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Riekstinš</td><td class=bc>-</td><td class=blW>Ni Blomberg</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jo Roholm</td><td class=bc>-</td><td class=blW>De Andrijashkin</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ti Roholm</td><td class=bc>-</td><td class=bl>Iv Smirnov</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ri Sinicins</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Re Liepinš</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Li Österman</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Un Österman</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ni Blomberg</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>De Andrijashkin</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kr Riekstinš</td><td class=bc>-</td><td class=bl>Iv Smirnov</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Jo Roholm</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ti Roholm</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ri Sinicins</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ha Ivantsova</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Li Österman</td><td class=bc>-</td><td class=blW>Ni Blomberg</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Un Österman</td><td class=bc>-</td><td class=bl>De Andrijashkin</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Iv Smirnov</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Ví Perkner</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kr Riekstinš</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Jo Roholm</td><td class=bc>-</td><td class=blW>Ri Sinicins</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ti Roholm</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Re Liepinš</td><td class=bc>-</td><td class=blW>Ha Ivantsova</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>14 : 0</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Ni Blomberg</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>De Andrijashkin</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Li Österman</td><td class=bc>-</td><td class=blW>Iv Smirnov</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Un Österman</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Mi Skrlep</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Ri Sinicins</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Kr Riekstinš</td><td class=bc>-</td><td class=bl>Ti Roholm</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Jo Roholm</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Fi Kalinouski</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Re Liepinš</td><td class=bc>-</td><td class=blW>Ni Blomberg</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>De Andrijashkin</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=bl>Iv Smirnov</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Li Österman</td><td class=bc>-</td><td class=blW>Mi Skrlep</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Un Österman</td><td class=bc>-</td><td class=bl>Ri Sinicins</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Ti Roholm</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=blW>Jo Roholm</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kr Riekstinš</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Ni Blomberg</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>De Andrijashkin</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Re Liepinš</td><td class=bc>-</td><td class=blW>Iv Smirnov</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Ri Sinicins</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Li Österman</td><td class=bc>-</td><td class=blW>Ti Roholm</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Un Österman</td><td class=bc>-</td><td class=bl>Jo Roholm</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=blW>Kr Riekstinš</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ví Perkner</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>De Andrijashkin</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Iv Smirnov</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Fi Kalinouski</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Re Liepinš</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ri Sinicins</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ti Roholm</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Jo Roholm</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Li Österman</td><td class=bc>-</td><td class=blW>Kr Riekstinš</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Un Österman</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Jo Perkner</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Ni Blomberg</td><td class=bc>-</td><td class=bl>Iv Smirnov</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Mo Skrlep</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ha Ivantsova</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Ri Sinicins</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Re Liepinš</td><td class=bc>-</td><td class=bl>Ti Roholm</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Jo Roholm</td><td class=bc>13 : 1</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Kr Riekstinš</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ví Perkner</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Li Österman</td><td class=bc>-</td><td class=bl>Jo Perkner</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Un Österman</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</table></div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
