<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Team Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Team Open : Czech Republic &nbsp;&nbsp;vs.&nbsp;&nbsp;Switzerland &nbsp;&nbsp;25:0</span></h2></div></div></div></div><h3 align="right">Round: 2&nbsp;&nbsp;</h3>
<p><div align="center">
<table border=1 cellpadding="0" cellspacing="0" ><tr>
<table border="0" cellpadding="1" cellspacing="0" width="95%"><tr><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Patrik Petr<br>5-0-0 (29:7)</td></tr>
<tr><td class="k">Michal Hvižď<br>5-0-0 (31:7)</td></tr>
<tr><td class="k">Zdeněk Matoušek ml.<br>5-0-0 (29:8)</td></tr>
<tr><td class="k">Michal Kobrle<br>2-0-0 (12:3)</td></tr>
<tr><td class="k">ml. Jiří Chylík<br>2-0-0 (12:2)</td></tr>
<tr><td class="k">Leoš Hvižď ml.<br>3-0-0 (17:5)</td></tr>
<tr><td class="k">Lukáš Turoň<br>3-0-0 (18:1)</td></tr>
</table></td>
<td valign="top"><table border="0" cellspacing="0" cellpadding="0" width="100%"><tr><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 1</td></tr>
<tr><td class="hrac_sk_v">Patrik Petr</td><td class="vysledek" width="60">&nbsp; 5 : 3 &nbsp;</td><td class="hrac_sk">Jean-Claude Klaus</td></tr>
<tr><td class="hrac_sk_v">Michal Hvižď</td><td class="vysledek" width="60">&nbsp; 4 : 3 &nbsp;</td><td class="hrac_sk">Rolf Locher</td></tr>
<tr><td class="hrac_sk_v">Zdeněk Matoušek ml.</td><td class="vysledek" width="60">&nbsp; 8 : 2 &nbsp;</td><td class="hrac_sk">Ramon Klaus</td></tr>
<tr><td class="hrac_sk_v">Michal Kobrle</td><td class="vysledek" width="60">&nbsp; 8 : 1 &nbsp;</td><td class="hrac_sk">Olli Majaniemi</td></tr>
<tr><td class="hrac_sk_v">ml. Jiří Chylík</td><td class="vysledek" width="60">&nbsp; 5 : 0 &nbsp;</td><td class="hrac_sk">Beat Luginbühl</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;5:0</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 2</td></tr>
<tr><td class="hrac_sk_v">ml. Jiří Chylík</td><td class="vysledek" width="60">&nbsp; 7 : 2 &nbsp;</td><td class="hrac_sk">Rolf Locher</td></tr>
<tr><td class="hrac_sk_v">Patrik Petr</td><td class="vysledek" width="60">&nbsp; 6 : 3 &nbsp;</td><td class="hrac_sk">Ramon Klaus</td></tr>
<tr><td class="hrac_sk_v">Michal Hvižď</td><td class="vysledek" width="60">&nbsp; 9 : 1 &nbsp;</td><td class="hrac_sk">Olli Majaniemi</td></tr>
<tr><td class="hrac_sk_v">Zdeněk Matoušek ml.</td><td class="vysledek" width="60">&nbsp; 5 : 0 &nbsp;</td><td class="hrac_sk">Beat Luginbühl</td></tr>
<tr><td class="hrac_sk_v">Michal Kobrle</td><td class="vysledek" width="60">&nbsp; 4 : 2 &nbsp;</td><td class="hrac_sk">Jean-Claude Klaus</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;10:0</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td>
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 3</td></tr>
<tr><td class="hrac_sk_v">Leoš Hvižď ml.</td><td class="vysledek" width="60">&nbsp; 6 : 2 &nbsp;</td><td class="hrac_sk">Ramon Klaus</td></tr>
<tr><td class="hrac_sk_v">Lukáš Turoň</td><td class="vysledek" width="60">&nbsp; 6 : 1 &nbsp;</td><td class="hrac_sk">Olli Majaniemi</td></tr>
<tr><td class="hrac_sk_v">Patrik Petr</td><td class="vysledek" width="60">&nbsp; 5 : 0 &nbsp;</td><td class="hrac_sk">Beat Luginbühl</td></tr>
<tr><td class="hrac_sk_v">Michal Hvižď</td><td class="vysledek" width="60">&nbsp; 7 : 2 &nbsp;</td><td class="hrac_sk">Jean-Claude Klaus</td></tr>
<tr><td class="hrac_sk_v">Zdeněk Matoušek ml.</td><td class="vysledek" width="60">&nbsp; 5 : 2 &nbsp;</td><td class="hrac_sk">Rolf Locher</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;15:0</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 4</td></tr>
<tr><td class="hrac_sk_v">Zdeněk Matoušek ml.</td><td class="vysledek" width="60">&nbsp; 5 : 2 &nbsp;</td><td class="hrac_sk">Olli Majaniemi</td></tr>
<tr><td class="hrac_sk_v">Leoš Hvižď ml.</td><td class="vysledek" width="60">&nbsp; 5 : 0 &nbsp;</td><td class="hrac_sk">Beat Luginbühl</td></tr>
<tr><td class="hrac_sk_v">Lukáš Turoň</td><td class="vysledek" width="60">&nbsp; 5 : 0 &nbsp;</td><td class="hrac_sk">Jean-Claude Klaus</td></tr>
<tr><td class="hrac_sk_v">Patrik Petr</td><td class="vysledek" width="60">&nbsp; 7 : 1 &nbsp;</td><td class="hrac_sk">Rolf Locher</td></tr>
<tr><td class="hrac_sk_v">Michal Hvižď</td><td class="vysledek" width="60">&nbsp; 6 : 1 &nbsp;</td><td class="hrac_sk">Ramon Klaus</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;20:0</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td align="center" colspan="3">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 5</td></tr>
<tr><td class="hrac_sk_v">Michal Hvižď</td><td class="vysledek" width="60">&nbsp; 5 : 0 &nbsp;</td><td class="hrac_sk">Beat Luginbühl</td></tr>
<tr><td class="hrac_sk_v">Zdeněk Matoušek ml.</td><td class="vysledek" width="60">&nbsp; 6 : 2 &nbsp;</td><td class="hrac_sk">Jean-Claude Klaus</td></tr>
<tr><td class="hrac_sk_v">Leoš Hvižď ml.</td><td class="vysledek" width="60">&nbsp; 6 : 3 &nbsp;</td><td class="hrac_sk">Rolf Locher</td></tr>
<tr><td class="hrac_sk_v">Lukáš Turoň</td><td class="vysledek" width="60">&nbsp; 7 : 0 &nbsp;</td><td class="hrac_sk">Ramon Klaus</td></tr>
<tr><td class="hrac_sk_v">Patrik Petr</td><td class="vysledek" width="60">&nbsp; 6 : 0 &nbsp;</td><td class="hrac_sk">Olli Majaniemi</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;25:0</td></tr></table>
</td></tr></table></td><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Jean-Claude Klaus<br>0-0-5 (9:27)</td></tr>
<tr><td class="k">Rolf Locher<br>0-0-5 (11:29)</td></tr>
<tr><td class="k">Ramon Klaus<br>0-0-5 (8:33)</td></tr>
<tr><td class="k">Olli Majaniemi<br>0-0-5 (5:34)</td></tr>
<tr><td class="k">Beat Luginbühl<br>0-0-5 (0:25)</td></tr>
</table></td></tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
