<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Team Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Team Open </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group T1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Russia</td><td class=kx>*</td>
<td class=kW><a href="t_309_1664_1665.aspx">12:9</a></td>
<td class=kW><a href="t_309_1663_1664.aspx">15:8</a></td>
<td class=kW><a href="t_309_341_1664.aspx">18:3</a></td>
<td class=kW><a href="t_309_1664_1674.aspx">19:2</a></td>
<td class=kW><a href="t_309_1664_1673.aspx">24:1</a></td>
<td class=kW><a href="t_309_1664_1852.aspx">20:4</a></td>
<td class=br>108:27</td><td class=br>+81</td>
<td class=bc>6 - 0 - 0</td>
<td class=br><strong>12</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Ukraine</td><td class=kL><a href="t_309_1664_1665.aspx">9:12</a></td>
<td class=kx>*</td>
<td class=kW><a href="t_309_1663_1665.aspx">13:10</a></td>
<td class=kW><a href="t_309_341_1665.aspx">14:9</a></td>
<td class=kW><a href="t_309_1665_1674.aspx">15:7</a></td>
<td class=kW><a href="t_309_1665_1673.aspx">16:7</a></td>
<td class=kW><a href="t_309_1665_1852.aspx">22:1</a></td>
<td class=br>89:46</td><td class=br>+43</td>
<td class=bc>5 - 0 - 1</td>
<td class=br><strong>10</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Finland</td><td class=kL><a href="t_309_1663_1664.aspx">8:15</a></td>
<td class=kL><a href="t_309_1663_1665.aspx">10:13</a></td>
<td class=kx>*</td>
<td class=kW><a href="t_309_341_1663.aspx">17:4</a></td>
<td class=kW><a href="t_309_1663_1674.aspx">14:6</a></td>
<td class=kW><a href="t_309_1663_1673.aspx">21:1</a></td>
<td class=kW><a href="t_309_1663_1852.aspx">24:1</a></td>
<td class=br>94:40</td><td class=br>+54</td>
<td class=bc>4 - 0 - 2</td>
<td class=br><strong>8</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Slovakia</td><td class=kL><a href="t_309_341_1664.aspx">3:18</a></td>
<td class=kL><a href="t_309_341_1665.aspx">9:14</a></td>
<td class=kL><a href="t_309_341_1663.aspx">4:17</a></td>
<td class=kx>*</td>
<td class=kW><a href="t_309_341_1674.aspx">11:10</a></td>
<td class=kW><a href="t_309_341_1673.aspx">19:2</a></td>
<td class=kW><a href="t_309_341_1852.aspx">24:0</a></td>
<td class=br>70:61</td><td class=br>+9</td>
<td class=bc>3 - 0 - 3</td>
<td class=br><strong>6</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Norway</td><td class=kL><a href="t_309_1664_1674.aspx">2:19</a></td>
<td class=kL><a href="t_309_1665_1674.aspx">7:15</a></td>
<td class=kL><a href="t_309_1663_1674.aspx">6:14</a></td>
<td class=kL><a href="t_309_341_1674.aspx">10:11</a></td>
<td class=kx>*</td>
<td class=kW><a href="t_309_1673_1674.aspx">24:0</a></td>
<td class=kW><a href="t_309_1674_1852.aspx">19:3</a></td>
<td class=br>68:62</td><td class=br>+6</td>
<td class=bc>2 - 0 - 4</td>
<td class=br><strong>4</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Lithuania</td><td class=kL><a href="t_309_1664_1673.aspx">1:24</a></td>
<td class=kL><a href="t_309_1665_1673.aspx">7:16</a></td>
<td class=kL><a href="t_309_1663_1673.aspx">1:21</a></td>
<td class=kL><a href="t_309_341_1673.aspx">2:19</a></td>
<td class=kL><a href="t_309_1673_1674.aspx">0:24</a></td>
<td class=kx>*</td>
<td class=kT><a href="t_309_1673_1852.aspx">10:10</a></td>
<td class=br>21:114</td><td class=br>-93</td>
<td class=bc>0 - 1 - 5</td>
<td class=br><strong>1</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Belarus</td><td class=kL><a href="t_309_1664_1852.aspx">4:20</a></td>
<td class=kL><a href="t_309_1665_1852.aspx">1:22</a></td>
<td class=kL><a href="t_309_1663_1852.aspx">1:24</a></td>
<td class=kL><a href="t_309_341_1852.aspx">0:24</a></td>
<td class=kL><a href="t_309_1674_1852.aspx">3:19</a></td>
<td class=kT><a href="t_309_1673_1852.aspx">10:10</a></td>
<td class=kx>*</td>
<td class=br>19:119</td><td class=br>-100</td>
<td class=bc>0 - 1 - 5</td>
<td class=br><strong>1</strong></td><td class=d>7.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ukraine</td><td class=bc>-</td><td class=bl>Belarus</td><td class=bc><a href="t_309_1665_1852.aspx">22 : 1</a></tr></td>
<tr><td class=brW>Finland</td><td class=bc>-</td><td class=bl>Lithuania</td><td class=bc><a href="t_309_1663_1673.aspx">21 : 1</a></tr></td>
<tr><td class=br>Norway</td><td class=bc>-</td><td class=blW>Slovakia</td><td class=bc><a href="t_309_341_1674.aspx">10 : 11</a></tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Russia</td><td class=bc>-</td><td class=bl>Ukraine</td><td class=bc><a href="t_309_1664_1665.aspx">12 : 9</a></tr></td>
<tr><td class=brW>Finland</td><td class=bc>-</td><td class=bl>Belarus</td><td class=bc><a href="t_309_1663_1852.aspx">24 : 1</a></tr></td>
<tr><td class=brW>Norway</td><td class=bc>-</td><td class=bl>Lithuania</td><td class=bc><a href="t_309_1673_1674.aspx">24 : 0</a></tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Russia</td><td class=bc>-</td><td class=bl>Finland</td><td class=bc><a href="t_309_1663_1664.aspx">15 : 8</a></tr></td>
<tr><td class=brW>Norway</td><td class=bc>-</td><td class=bl>Belarus</td><td class=bc><a href="t_309_1674_1852.aspx">19 : 3</a></tr></td>
<tr><td class=brW>Slovakia</td><td class=bc>-</td><td class=bl>Lithuania</td><td class=bc><a href="t_309_341_1673.aspx">19 : 2</a></tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ukraine</td><td class=bc>-</td><td class=bl>Finland</td><td class=bc><a href="t_309_1663_1665.aspx">13 : 10</a></tr></td>
<tr><td class=brW>Russia</td><td class=bc>-</td><td class=bl>Norway</td><td class=bc><a href="t_309_1664_1674.aspx">19 : 2</a></tr></td>
<tr><td class=brW>Slovakia</td><td class=bc>-</td><td class=bl>Belarus</td><td class=bc><a href="t_309_341_1852.aspx">24 : 0</a></tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ukraine</td><td class=bc>-</td><td class=bl>Norway</td><td class=bc><a href="t_309_1665_1674.aspx">15 : 7</a></tr></td>
<tr><td class=brW>Russia</td><td class=bc>-</td><td class=bl>Slovakia</td><td class=bc><a href="t_309_341_1664.aspx">18 : 3</a></tr></td>
<tr><td class=br>Lithuania</td><td class=bc>-</td><td class=bl>Belarus</td><td class=bc><a href="t_309_1673_1852.aspx">10 : 10</a></tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Finland</td><td class=bc>-</td><td class=bl>Norway</td><td class=bc><a href="t_309_1663_1674.aspx">14 : 6</a></tr></td>
<tr><td class=brW>Ukraine</td><td class=bc>-</td><td class=bl>Slovakia</td><td class=bc><a href="t_309_341_1665.aspx">14 : 9</a></tr></td>
<tr><td class=brW>Russia</td><td class=bc>-</td><td class=bl>Lithuania</td><td class=bc><a href="t_309_1664_1673.aspx">24 : 1</a></tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Finland</td><td class=bc>-</td><td class=bl>Slovakia</td><td class=bc><a href="t_309_341_1663.aspx">17 : 4</a></tr></td>
<tr><td class=brW>Ukraine</td><td class=bc>-</td><td class=bl>Lithuania</td><td class=bc><a href="t_309_1665_1673.aspx">16 : 7</a></tr></td>
<tr><td class=brW>Russia</td><td class=bc>-</td><td class=bl>Belarus</td><td class=bc><a href="t_309_1664_1852.aspx">20 : 4</a></tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
