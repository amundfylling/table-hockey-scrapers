<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Team Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Team Open : Norway &nbsp;&nbsp;vs.&nbsp;&nbsp;Hungary &nbsp;&nbsp;15:4</span></h2></div></div></div></div><h3 align="right">Round: 9th&nbsp;&nbsp;</h3>
<p><div align="center">
<table border=1 cellpadding="0" cellspacing="0" ><tr>
<table border="0" cellpadding="1" cellspacing="0" width="95%"><tr><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Amund Risa Fylling<br>3-0-1 (11:5)</td></tr>
<tr><td class="k">Espen Eidsnes<br>3-0-1 (15:10)</td></tr>
<tr><td class="k">Yngve Aasheim<br>3-0-1 (21:7)</td></tr>
<tr><td class="k">Magnus Klippen<br>3-1-0 (21:10)</td></tr>
<tr><td class="k">Espen Moe<br>3-0-1 (17:9)</td></tr>
</table></td>
<td valign="top"><table border="0" cellspacing="0" cellpadding="0" width="100%"><tr><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 1</td></tr>
<tr><td class="hrac_sk_v">Amund Risa Fylling</td><td class="vysledek" width="60">&nbsp; 3 : 1 &nbsp;</td><td class="hrac_sk">Gergely Regula</td></tr>
<tr><td class="hrac_sk_v">Espen Eidsnes</td><td class="vysledek" width="60">&nbsp; 3 : 0 &nbsp;</td><td class="hrac_sk">Peter Borsanyi</td></tr>
<tr><td class="hrac_sk_v">Yngve Aasheim</td><td class="vysledek" width="60">&nbsp; 8 : 1 &nbsp;</td><td class="hrac_sk">Magor Papp</td></tr>
<tr><td class="hrac_sk_v">Magnus Klippen</td><td class="vysledek" width="60">&nbsp; 3 : 2 &nbsp;</td><td class="hrac_sk">Viktor Magyari</td></tr>
<tr><td class="hrac_sk_v">Espen Moe</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">András Naszádi</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;5:0</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 2</td></tr>
<tr><td class="hrac_sk">Espen Moe</td><td class="vysledek" width="60">&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;</td><td class="hrac_sk">Peter Borsanyi</td></tr>
<tr><td class="hrac_sk">Amund Risa Fylling</td><td class="vysledek" width="60">&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;</td><td class="hrac_sk">Magor Papp</td></tr>
<tr><td class="hrac_sk">Espen Eidsnes</td><td class="vysledek" width="60">&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;</td><td class="hrac_sk">Viktor Magyari</td></tr>
<tr><td class="hrac_sk">Yngve Aasheim</td><td class="vysledek" width="60">&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;</td><td class="hrac_sk">András Naszádi</td></tr>
<tr><td class="hrac_sk">Magnus Klippen</td><td class="vysledek" width="60">&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;</td><td class="hrac_sk">Gergely Regula</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;5:0</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td>
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 3</td></tr>
<tr><td class="hrac_sk">Magnus Klippen</td><td class="vysledek" width="60">&nbsp; 3 : 3 &nbsp;</td><td class="hrac_sk">Magor Papp</td></tr>
<tr><td class="hrac_sk">Espen Moe</td><td class="vysledek" width="60">&nbsp; 4 : 5 &nbsp;</td><td class="hrac_sk_v">Viktor Magyari</td></tr>
<tr><td class="hrac_sk_v">Amund Risa Fylling</td><td class="vysledek" width="60">&nbsp; 3 : 1 &nbsp;</td><td class="hrac_sk">András Naszádi</td></tr>
<tr><td class="hrac_sk_v">Espen Eidsnes</td><td class="vysledek" width="60">&nbsp; 3 : 2 &nbsp;</td><td class="hrac_sk">Gergely Regula</td></tr>
<tr><td class="hrac_sk_v">Yngve Aasheim</td><td class="vysledek" width="60">&nbsp; 7 : 1 &nbsp;</td><td class="hrac_sk">Peter Borsanyi</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;8:1</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 4</td></tr>
<tr><td class="hrac_sk_v">Yngve Aasheim</td><td class="vysledek" width="60">&nbsp; 4 : 2 &nbsp;</td><td class="hrac_sk">Viktor Magyari</td></tr>
<tr><td class="hrac_sk_v">Magnus Klippen</td><td class="vysledek" width="60">&nbsp; 10 : 4 &nbsp;</td><td class="hrac_sk">András Naszádi</td></tr>
<tr><td class="hrac_sk_v">Espen Moe</td><td class="vysledek" width="60">&nbsp; 5 : 2 &nbsp;</td><td class="hrac_sk">Gergely Regula</td></tr>
<tr><td class="hrac_sk">Amund Risa Fylling</td><td class="vysledek" width="60">&nbsp; 1 : 2 &nbsp;</td><td class="hrac_sk_v">Peter Borsanyi</td></tr>
<tr><td class="hrac_sk">Espen Eidsnes</td><td class="vysledek" width="60">&nbsp; 3 : 4 &nbsp;</td><td class="hrac_sk_v">Magor Papp</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;11:3</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td align="center" colspan="3">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 5</td></tr>
<tr><td class="hrac_sk_v">Espen Eidsnes</td><td class="vysledek" width="60">&nbsp; 6 : 4 &nbsp;</td><td class="hrac_sk">András Naszádi</td></tr>
<tr><td class="hrac_sk">Yngve Aasheim</td><td class="vysledek" width="60">&nbsp; 2 : 3 &nbsp;</td><td class="hrac_sk_v">Gergely Regula</td></tr>
<tr><td class="hrac_sk_v">Magnus Klippen</td><td class="vysledek" width="60">&nbsp; 5 : 1 &nbsp;</td><td class="hrac_sk">Peter Borsanyi</td></tr>
<tr><td class="hrac_sk_v">Espen Moe</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">Magor Papp</td></tr>
<tr><td class="hrac_sk_v">Amund Risa Fylling</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">Viktor Magyari</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;15:4</td></tr></table>
</td></tr></table></td><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Gergely Regula<br>1-0-3 (8:13)</td></tr>
<tr><td class="k">Peter Borsanyi<br>1-0-3 (4:16)</td></tr>
<tr><td class="k">Magor Papp<br>1-1-2 (9:18)</td></tr>
<tr><td class="k">Viktor Magyari<br>1-0-3 (10:15)</td></tr>
<tr><td class="k">András Naszádi<br>0-0-4 (10:23)</td></tr>
</table></td></tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
