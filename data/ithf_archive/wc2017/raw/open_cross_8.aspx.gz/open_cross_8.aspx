<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Open </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 8</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ol Korabel</td><td class=ic>UKR</td><td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=br>59:24</td><td class=br>+35</td>
<td class=bc>12 - 4 - 1</td>
<td class=br><strong>28</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Al Titov</td><td class=ic>RUS</td><td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>9:0</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=br>62:25</td><td class=br>+37</td>
<td class=bc>13 - 2 - 2</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Le Hvižď ml.</td><td class=ic>CZE</td><td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>3:6</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=kW>3:1</td>
<td class=kW>8:1</td>
<td class=kW>4:1</td>
<td class=kW>11:1</td>
<td class=kW>8:0</td>
<td class=kW>4:2</td>
<td class=br>72:26</td><td class=br>+46</td>
<td class=bc>11 - 4 - 2</td>
<td class=br><strong>26</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ja Pelkonen</td><td class=ic>FIN</td><td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>8:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>9:2</td>
<td class=kW>7:1</td>
<td class=br>72:30</td><td class=br>+42</td>
<td class=bc>11 - 4 - 2</td>
<td class=br><strong>26</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Gr Dubinin</td><td class=ic>RUS</td><td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>7:0</td>
<td class=kW>10:0</td>
<td class=br>65:23</td><td class=br>+42</td>
<td class=bc>11 - 4 - 2</td>
<td class=br><strong>26</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Em Larsson</td><td class=ic>SWE</td><td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>8:3</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=br>65:36</td><td class=br>+29</td>
<td class=bc>10 - 4 - 3</td>
<td class=br><strong>24</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Dm Malygin</td><td class=ic>RUS</td><td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=kW>4:3</td>
<td class=kW>8:0</td>
<td class=kW>7:1</td>
<td class=br>62:32</td><td class=br>+30</td>
<td class=bc>10 - 2 - 5</td>
<td class=br><strong>22</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>ml Chylík</td><td class=ic>CZE</td><td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=br>48:33</td><td class=br>+15</td>
<td class=bc>10 - 2 - 5</td>
<td class=br><strong>22</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ja Sahlgren</td><td class=ic>FIN</td><td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>3:6</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=br>46:39</td><td class=br>+7</td>
<td class=bc>9 - 1 - 7</td>
<td class=br><strong>19</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Fr Axelsson</td><td class=ic>SWE</td><td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>1:0</td>
<td class=kW>6:2</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>9:1</td>
<td class=br>52:47</td><td class=br>+5</td>
<td class=bc>8 - 1 - 8</td>
<td class=br><strong>17</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Yu Artamonov</td><td class=ic>EST</td><td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kW>6:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=br>38:55</td><td class=br>-17</td>
<td class=bc>6 - 1 - 10</td>
<td class=br><strong>13</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Al Dalgou</td><td class=ic>BLR</td><td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kL>1:4</td>
<td class=br>28:55</td><td class=br>-27</td>
<td class=bc>5 - 1 - 11</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Fr Suma</td><td class=ic>SVK</td><td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=br>32:46</td><td class=br>-14</td>
<td class=bc>5 - 1 - 11</td>
<td class=br><strong>11</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ma Satkus</td><td class=ic>LTU</td><td class=kL>1:5</td>
<td class=kL>0:9</td>
<td class=kL>1:8</td>
<td class=kL>2:8</td>
<td class=kL>1:6</td>
<td class=kL>3:8</td>
<td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=br>40:73</td><td class=br>-33</td>
<td class=bc>4 - 2 - 11</td>
<td class=br><strong>10</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ig Zaporojets</td><td class=ic>UKR</td><td class=kL>2:7</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=br>34:55</td><td class=br>-21</td>
<td class=bc>4 - 0 - 13</td>
<td class=br><strong>8</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Vi Magyari</td><td class=ic>HUN</td><td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>1:11</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=br>27:64</td><td class=br>-37</td>
<td class=bc>3 - 2 - 12</td>
<td class=br><strong>8</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Mi Skrlep</td><td class=ic>SLO</td><td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>0:8</td>
<td class=kL>2:9</td>
<td class=kL>0:7</td>
<td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>0:7</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>14:87</td><td class=br>-73</td>
<td class=bc>2 - 0 - 15</td>
<td class=br><strong>4</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>E</td><td class=d>18.</td><td class=kt>Ma Pikat</td><td class=ic>EST</td><td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>0:10</td>
<td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:9</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>17:83</td><td class=br>-66</td>
<td class=bc>1 - 1 - 15</td>
<td class=br><strong>3</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Yu Artamonov</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Fr Axelsson</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Al Dalgou</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Gr Dubinin</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Ja Sahlgren</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Em Larsson</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=blW>Dm Malygin</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Yu Artamonov</td><td class=bc>-</td><td class=blW>Fr Suma</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Fr Axelsson</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Al Dalgou</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Gr Dubinin</td><td class=bc>-</td><td class=bl>Ja Sahlgren</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=bl>Dm Malygin</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Vi Magyari</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Al Titov</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=blW>Mi Skrlep</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Yu Artamonov</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Fr Axelsson</td><td class=bc>-</td><td class=blW>Ja Sahlgren</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al Dalgou</td><td class=bc>-</td><td class=blW>Ma Pikat</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Gr Dubinin</td><td class=bc>-</td><td class=bl>Ja Pelkonen</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Dm Malygin</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Vi Magyari</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Fr Suma</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Al Titov</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=blW>Ja Sahlgren</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Yu Artamonov</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fr Axelsson</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Al Dalgou</td><td class=bc>-</td><td class=blW>Dm Malygin</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Gr Dubinin</td><td class=bc>-</td><td class=bl>Vi Magyari</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=blW>Ja Sahlgren</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Al Titov</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Yu Artamonov</td><td class=bc>-</td><td class=bl>Dm Malygin</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Fr Axelsson</td><td class=bc>-</td><td class=blW>Vi Magyari</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al Dalgou</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Gr Dubinin</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Ja Sahlgren</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Skrlep</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Al Titov</td><td class=bc>-</td><td class=bl>Dm Malygin</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ig Zaporojets</td><td class=bc>-</td><td class=bl>Vi Magyari</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Yu Artamonov</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fr Axelsson</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Dalgou</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gr Dubinin</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Dm Malygin</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Fr Suma</td><td class=bc>-</td><td class=bl>Vi Magyari</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Al Titov</td><td class=bc>-</td><td class=bl>Em Larsson</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Yu Artamonov</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Fr Axelsson</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Dalgou</td><td class=bc>-</td><td class=blW>Gr Dubinin</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>Ja Pelkonen</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Dm Malygin</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=bl>Vi Magyari</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Al Titov</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Yu Artamonov</td><td class=bc>-</td><td class=blW>Gr Dubinin</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Fr Axelsson</td><td class=bc>-</td><td class=bl>Al Dalgou</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ja Pelkonen</td><td class=bc>-</td><td class=blW>Dm Malygin</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>Vi Magyari</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ja Sahlgren</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Al Titov</td><td class=bc>-</td><td class=blW>Gr Dubinin</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=blW>Al Dalgou</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Yu Artamonov</td><td class=bc>-</td><td class=blW>Fr Axelsson</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Dm Malygin</td><td class=bc>-</td><td class=blW>Em Larsson</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>ml Chylík</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Sahlgren</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Gr Dubinin</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Al Dalgou</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=blW>Fr Axelsson</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Al Titov</td><td class=bc>-</td><td class=bl>Yu Artamonov</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Dm Malygin</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>Gr Dubinin</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Al Dalgou</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Fr Axelsson</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Yu Artamonov</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Fr Suma</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Al Titov</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>ml Chylík</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=blW>Le Hvižď ml.</td><td class=bc>1 : 11</tr></td>
<tr><td class=br>Dm Malygin</td><td class=bc>-</td><td class=bl>Gr Dubinin</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Al Dalgou</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>Fr Axelsson</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Ja Sahlgren</td><td class=bc>-</td><td class=blW>Yu Artamonov</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=bl>Le Hvižď ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Em Larsson</td><td class=bc>-</td><td class=bl>Gr Dubinin</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=blW>Al Dalgou</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Dm Malygin</td><td class=bc>-</td><td class=bl>Fr Axelsson</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Yu Artamonov</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>Ig Zaporojets</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ja Sahlgren</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>ml Chylík</td><td class=bc>-</td><td class=bl>Gr Dubinin</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Al Dalgou</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Em Larsson</td><td class=bc>-</td><td class=blW>Fr Axelsson</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=blW>Yu Artamonov</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Dm Malygin</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ja Pelkonen</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>Fr Suma</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Al Dalgou</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Fr Axelsson</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Yu Artamonov</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Em Larsson</td><td class=bc>-</td><td class=blW>Ig Zaporojets</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Dm Malygin</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ja Sahlgren</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Gr Dubinin</td><td class=bc>-</td><td class=bl>Fr Axelsson</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Yu Artamonov</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Al Titov</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Vi Magyari</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Dm Malygin</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ja Pelkonen</td><td class=bc>-</td><td class=bl>Ja Sahlgren</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Al Dalgou</td><td class=bc>-</td><td class=blW>Yu Artamonov</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Gr Dubinin</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Al Titov</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=blW>Ja Sahlgren</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Dm Malygin</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ja Pelkonen</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Fr Axelsson</td><td class=bc>-</td><td class=blW>Ig Zaporojets</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Al Dalgou</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Gr Dubinin</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Le Hvižď ml.</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>ml Chylík</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Ja Sahlgren</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Em Larsson</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=bl>Ja Pelkonen</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Dm Malygin</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
