<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Team Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Team Open : Latvia &nbsp;&nbsp;vs.&nbsp;&nbsp;Czech Republic &nbsp;&nbsp;10:11</span></h2></div></div></div></div><h3 align="right">Round: 3&nbsp;&nbsp;</h3>
<p><div align="center">
<table border=1 cellpadding="0" cellspacing="0" ><tr>
<table border="0" cellpadding="1" cellspacing="0" width="95%"><tr><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Atis Silis<br>2-2-1 (21:16)</td></tr>
<tr><td class="k">Edgars Caics<br>3-1-1 (23:10)</td></tr>
<tr><td class="k">Raivis Miglinieks<br>2-1-2 (10:11)</td></tr>
<tr><td class="k">Edgars Saulitis<br>1-0-4 (10:22)</td></tr>
<tr><td class="k">Valts Smagars<br>2-0-3 (13:16)</td></tr>
</table></td>
<td valign="top"><table border="0" cellspacing="0" cellpadding="0" width="100%"><tr><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 1</td></tr>
<tr><td class="hrac_sk">Atis Silis</td><td class="vysledek" width="60">&nbsp; 2 : 2 &nbsp;</td><td class="hrac_sk">Zdeněk Matoušek ml.</td></tr>
<tr><td class="hrac_sk">Edgars Caics</td><td class="vysledek" width="60">&nbsp; 3 : 3 &nbsp;</td><td class="hrac_sk">Michal Hvižď</td></tr>
<tr><td class="hrac_sk">Raivis Miglinieks</td><td class="vysledek" width="60">&nbsp; 2 : 2 &nbsp;</td><td class="hrac_sk">Patrik Petr</td></tr>
<tr><td class="hrac_sk">Edgars Saulitis</td><td class="vysledek" width="60">&nbsp; 2 : 5 &nbsp;</td><td class="hrac_sk_v">Leoš Hvižď ml.</td></tr>
<tr><td class="hrac_sk">Valts Smagars</td><td class="vysledek" width="60">&nbsp; 1 : 3 &nbsp;</td><td class="hrac_sk_v">Lukáš Turoň</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;0:2</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 2</td></tr>
<tr><td class="hrac_sk">Valts Smagars</td><td class="vysledek" width="60">&nbsp; 1 : 4 &nbsp;</td><td class="hrac_sk_v">Michal Hvižď</td></tr>
<tr><td class="hrac_sk_v">Atis Silis</td><td class="vysledek" width="60">&nbsp; 4 : 3 &nbsp;</td><td class="hrac_sk">Patrik Petr</td></tr>
<tr><td class="hrac_sk">Edgars Caics</td><td class="vysledek" width="60">&nbsp; 3 : 4 &nbsp;</td><td class="hrac_sk_v">Leoš Hvižď ml.</td></tr>
<tr><td class="hrac_sk">Raivis Miglinieks</td><td class="vysledek" width="60">&nbsp; 3 : 4 &nbsp;</td><td class="hrac_sk_v">Lukáš Turoň</td></tr>
<tr><td class="hrac_sk">Edgars Saulitis</td><td class="vysledek" width="60">&nbsp; 2 : 6 &nbsp;</td><td class="hrac_sk_v">Zdeněk Matoušek ml.</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;1:6</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td>
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 3</td></tr>
<tr><td class="hrac_sk_v">Edgars Saulitis</td><td class="vysledek" width="60">&nbsp; 3 : 2 &nbsp;</td><td class="hrac_sk">Patrik Petr</td></tr>
<tr><td class="hrac_sk_v">Valts Smagars</td><td class="vysledek" width="60">&nbsp; 2 : 0 &nbsp;</td><td class="hrac_sk">Leoš Hvižď ml.</td></tr>
<tr><td class="hrac_sk">Atis Silis</td><td class="vysledek" width="60">&nbsp; 3 : 3 &nbsp;</td><td class="hrac_sk">Lukáš Turoň</td></tr>
<tr><td class="hrac_sk_v">Edgars Caics</td><td class="vysledek" width="60">&nbsp; 8 : 1 &nbsp;</td><td class="hrac_sk">Zdeněk Matoušek ml.</td></tr>
<tr><td class="hrac_sk_v">Raivis Miglinieks</td><td class="vysledek" width="60">&nbsp; 2 : 1 &nbsp;</td><td class="hrac_sk">Michal Hvižď</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;5:6</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 4</td></tr>
<tr><td class="hrac_sk">Raivis Miglinieks</td><td class="vysledek" width="60">&nbsp; 1 : 3 &nbsp;</td><td class="hrac_sk_v">Leoš Hvižď ml.</td></tr>
<tr><td class="hrac_sk">Edgars Saulitis</td><td class="vysledek" width="60">&nbsp; 1 : 6 &nbsp;</td><td class="hrac_sk_v">Lukáš Turoň</td></tr>
<tr><td class="hrac_sk">Valts Smagars</td><td class="vysledek" width="60">&nbsp; 2 : 8 &nbsp;</td><td class="hrac_sk_v">Zdeněk Matoušek ml.</td></tr>
<tr><td class="hrac_sk">Atis Silis</td><td class="vysledek" width="60">&nbsp; 4 : 5 &nbsp;</td><td class="hrac_sk_v">Michal Hvižď</td></tr>
<tr><td class="hrac_sk_v">Edgars Caics</td><td class="vysledek" width="60">&nbsp; 4 : 2 &nbsp;</td><td class="hrac_sk">Patrik Petr</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;6:10</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td align="center" colspan="3">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 5</td></tr>
<tr><td class="hrac_sk_v">Edgars Caics</td><td class="vysledek" width="60">&nbsp; 5 : 0 &nbsp;</td><td class="hrac_sk">Lukáš Turoň</td></tr>
<tr><td class="hrac_sk_v">Raivis Miglinieks</td><td class="vysledek" width="60">&nbsp; 2 : 1 &nbsp;</td><td class="hrac_sk">Zdeněk Matoušek ml.</td></tr>
<tr><td class="hrac_sk">Edgars Saulitis</td><td class="vysledek" width="60">&nbsp; 2 : 3 &nbsp;</td><td class="hrac_sk_v">Michal Hvižď</td></tr>
<tr><td class="hrac_sk_v">Valts Smagars</td><td class="vysledek" width="60">&nbsp; 7 : 1 &nbsp;</td><td class="hrac_sk">Patrik Petr</td></tr>
<tr><td class="hrac_sk_v">Atis Silis</td><td class="vysledek" width="60">&nbsp; 8 : 3 &nbsp;</td><td class="hrac_sk">Leoš Hvižď ml.</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;10:11</td></tr></table>
</td></tr></table></td><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Zdeněk Matoušek ml.<br>2-1-2 (18:16)</td></tr>
<tr><td class="k">Michal Hvižď<br>3-1-1 (16:12)</td></tr>
<tr><td class="k">Patrik Petr<br>0-1-4 (10:20)</td></tr>
<tr><td class="k">Leoš Hvižď ml.<br>3-0-2 (15:16)</td></tr>
<tr><td class="k">Lukáš Turoň<br>3-1-1 (16:13)</td></tr>
</table></td></tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
