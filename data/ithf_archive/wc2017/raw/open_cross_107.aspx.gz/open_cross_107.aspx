<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Open </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group D</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt>Vi Magyari</td><td class=ic>HUN</td><td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>4:5</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=br>76:39</td><td class=br>+37</td>
<td class=bc>16 - 5 - 2</td>
<td class=br><strong>37</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt>Ke Rafferty</td><td class=ic>USA</td><td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=br>73:56</td><td class=br>+17</td>
<td class=bc>16 - 2 - 5</td>
<td class=br><strong>34</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt>Je Klaus</td><td class=ic>SUI</td><td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>2:8</td>
<td class=kW>4:1</td>
<td class=kW>5:4</td>
<td class=kW>7:2</td>
<td class=kL>4:5</td>
<td class=kT>3:3</td>
<td class=kW>8:1</td>
<td class=kW>4:2</td>
<td class=kW>7:3</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>7:0</td>
<td class=kW>3:1</td>
<td class=kW>11:2</td>
<td class=kW>8:1</td>
<td class=kW>5:3</td>
<td class=kL>1:4</td>
<td class=kW>8:2</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=br>106:58</td><td class=br>+48</td>
<td class=bc>16 - 1 - 6</td>
<td class=br><strong>33</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt>Va Hamdamov</td><td class=ic>EST</td><td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kW>8:2</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kW>7:2</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kW>6:4</td>
<td class=kL>1:5</td>
<td class=kW>6:2</td>
<td class=kW>8:1</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=br>85:47</td><td class=br>+38</td>
<td class=bc>13 - 4 - 6</td>
<td class=br><strong>30</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Al Bartosh</td><td class=ic>BLR</td><td class=kT>4:4</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=kW>4:1</td>
<td class=kW>9:4</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>7:0</td>
<td class=kL>0:1</td>
<td class=kL>2:7</td>
<td class=kW>3:1</td>
<td class=kT>0:0</td>
<td class=kW>2:1</td>
<td class=kW>8:1</td>
<td class=br>77:53</td><td class=br>+24</td>
<td class=bc>13 - 3 - 7</td>
<td class=br><strong>29</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Ig Zaporojets</td><td class=ic>UKR</td><td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>4:5</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>8:1</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=br>72:54</td><td class=br>+18</td>
<td class=bc>12 - 5 - 6</td>
<td class=br><strong>29</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>An Kniaziuk</td><td class=ic>BLR</td><td class=kL>2:3</td>
<td class=kW>7:1</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>4:8</td>
<td class=kW>8:1</td>
<td class=kW>4:2</td>
<td class=kW>6:4</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>7:3</td>
<td class=br>80:67</td><td class=br>+13</td>
<td class=bc>13 - 3 - 7</td>
<td class=br><strong>29</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Al Tarakanov</td><td class=ic>KAZ</td><td class=kW>5:4</td>
<td class=kL>1:4</td>
<td class=kW>5:4</td>
<td class=kL>2:7</td>
<td class=kL>4:9</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kL>4:5</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>5:4</td>
<td class=kW>6:0</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=br>82:65</td><td class=br>+17</td>
<td class=bc>13 - 3 - 7</td>
<td class=br><strong>29</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Th Restel</td><td class=ic>GER</td><td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=br>68:57</td><td class=br>+11</td>
<td class=bc>11 - 5 - 7</td>
<td class=br><strong>27</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ra Pommerenke</td><td class=ic>GER</td><td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>1:8</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kW>6:2</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>9:2</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=br>59:51</td><td class=br>+8</td>
<td class=bc>11 - 4 - 8</td>
<td class=br><strong>26</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Th Cornelius</td><td class=ic>CHI</td><td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>4:6</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kW>8:4</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>6:5</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=br>72:62</td><td class=br>+10</td>
<td class=bc>11 - 3 - 9</td>
<td class=br><strong>25</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ei Rompa</td><td class=ic>GER</td><td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>3:7</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>1:8</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>7:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=br>70:69</td><td class=br>+1</td>
<td class=bc>11 - 2 - 10</td>
<td class=br><strong>24</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Mi Toft Nielsen</td><td class=ic>DEN</td><td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>3:7</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kL>1:4</td>
<td class=br>68:69</td><td class=br>-1</td>
<td class=bc>9 - 5 - 9</td>
<td class=br><strong>23</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Ol Majaniemi</td><td class=ic>SUI</td><td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>1:8</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>4:6</td>
<td class=kW>5:4</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>7:3</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kL>2:6</td>
<td class=kW>6:5</td>
<td class=kL>5:6</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=br>77:85</td><td class=br>-8</td>
<td class=bc>10 - 2 - 11</td>
<td class=br><strong>22</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Fr Bruneske</td><td class=ic>GER</td><td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kW>5:4</td>
<td class=kL>2:7</td>
<td class=kW>6:3</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=br>64:72</td><td class=br>-8</td>
<td class=bc>10 - 2 - 11</td>
<td class=br><strong>22</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Th Haussknecht</td><td class=ic>GER</td><td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>0:7</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kW>5:4</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=br>58:66</td><td class=br>-8</td>
<td class=bc>8 - 5 - 10</td>
<td class=br><strong>21</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Vl Voronov</td><td class=ic>LTU</td><td class=kL>0:4</td>
<td class=kL>4:5</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>4:5</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kW>7:3</td>
<td class=br>56:62</td><td class=br>-6</td>
<td class=bc>8 - 4 - 11</td>
<td class=br><strong>20</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Pa Petrik</td><td class=ic>LTU</td><td class=kL>4:5</td>
<td class=kL>2:5</td>
<td class=kL>2:11</td>
<td class=kL>2:4</td>
<td class=kL>0:7</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=br>51:77</td><td class=br>-26</td>
<td class=bc>9 - 1 - 13</td>
<td class=br><strong>19</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Ed Kuratnik</td><td class=ic>BLR</td><td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kW>7:2</td>
<td class=kL>4:5</td>
<td class=kL>4:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>0:1</td>
<td class=kW>4:1</td>
<td class=br>57:68</td><td class=br>-11</td>
<td class=bc>7 - 3 - 13</td>
<td class=br><strong>17</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Ra Klaus</td><td class=ic>SUI</td><td class=kL>2:7</td>
<td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kW>7:2</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>2:9</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>2:7</td>
<td class=kL>5:6</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>0:5</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=br>66:81</td><td class=br>-15</td>
<td class=bc>7 - 3 - 13</td>
<td class=br><strong>17</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Be Skrlep</td><td class=ic>SLO</td><td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kL>5:6</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kW>6:5</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kW>7:3</td>
<td class=br>62:65</td><td class=br>-3</td>
<td class=bc>6 - 4 - 13</td>
<td class=br><strong>16</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>An Naszádi</td><td class=ic>HUN</td><td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>2:8</td>
<td class=kL>0:6</td>
<td class=kT>0:0</td>
<td class=kL>1:8</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>1:6</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>7:3</td>
<td class=br>41:86</td><td class=br>-45</td>
<td class=bc>6 - 1 - 16</td>
<td class=br><strong>13</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Mi Skrlep</td><td class=ic>SLO</td><td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>1:0</td>
<td class=kL>1:6</td>
<td class=kT>4:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=br>35:71</td><td class=br>-36</td>
<td class=bc>2 - 4 - 17</td>
<td class=br><strong>8</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Mi Zeman</td><td class=ic>CZE</td><td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kW>4:1</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>3:7</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>3:7</td>
<td class=kL>3:7</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=br>35:110</td><td class=br>-75</td>
<td class=bc>1 - 0 - 22</td>
<td class=br><strong>2</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>An Naszádi</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Fr Bruneske</td><td class=bc>-</td><td class=blW>Ol Majaniemi</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Al Bartosh</td><td class=bc>-</td><td class=bl>Pa Petrik</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ei Rompa</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ra Klaus</td><td class=bc>-</td><td class=blW>Mi Toft Nielsen</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Je Klaus</td><td class=bc>-</td><td class=blW>Ke Rafferty</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ig Zaporojets</td><td class=bc>-</td><td class=bl>Th Cornelius</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>Vi Magyari</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Th Restel</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Vl Voronov</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Al Tarakanov</td><td class=bc>-</td><td class=blW>Va Hamdamov</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Ol Majaniemi</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Pa Petrik</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Fr Bruneske</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Al Bartosh</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ei Rompa</td><td class=bc>-</td><td class=blW>Ed Kuratnik</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ra Klaus</td><td class=bc>-</td><td class=blW>Ke Rafferty</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=blW>Th Cornelius</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Je Klaus</td><td class=bc>-</td><td class=blW>Vi Magyari</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>An Kniaziuk</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Th Restel</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Al Tarakanov</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ol Majaniemi</td><td class=bc>-</td><td class=bl>Pa Petrik</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Mi Skrlep</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Mi Toft Nielsen</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Fr Bruneske</td><td class=bc>-</td><td class=blW>Ed Kuratnik</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Al Bartosh</td><td class=bc>-</td><td class=blW>Ke Rafferty</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ei Rompa</td><td class=bc>-</td><td class=bl>Th Cornelius</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ra Klaus</td><td class=bc>-</td><td class=blW>Vi Magyari</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Je Klaus</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ig Zaporojets</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>An Kniaziuk</td><td class=bc>-</td><td class=bl>Al Tarakanov</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Th Restel</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Pa Petrik</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ol Majaniemi</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Mi Skrlep</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Ke Rafferty</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fr Bruneske</td><td class=bc>-</td><td class=blW>Th Cornelius</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Al Bartosh</td><td class=bc>-</td><td class=bl>Vi Magyari</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ei Rompa</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ra Klaus</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=blW>Va Hamdamov</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Je Klaus</td><td class=bc>-</td><td class=blW>Al Tarakanov</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=blW>Th Haussknecht</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>An Kniaziuk</td><td class=bc>-</td><td class=bl>Th Restel</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Mi Zeman</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pa Petrik</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>Ke Rafferty</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Th Cornelius</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Vi Magyari</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Fr Bruneske</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Al Bartosh</td><td class=bc>-</td><td class=blW>Vl Voronov</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ei Rompa</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ra Klaus</td><td class=bc>-</td><td class=blW>Al Tarakanov</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Je Klaus</td><td class=bc>-</td><td class=bl>Th Restel</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ke Rafferty</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pa Petrik</td><td class=bc>-</td><td class=bl>Th Cornelius</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ol Majaniemi</td><td class=bc>-</td><td class=bl>Vi Magyari</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Vl Voronov</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Fr Bruneske</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Al Bartosh</td><td class=bc>-</td><td class=bl>Al Tarakanov</td><td class=bc>9 : 4</tr></td>
<tr><td class=brW>Ei Rompa</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ra Klaus</td><td class=bc>-</td><td class=blW>Th Restel</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=blW>An Kniaziuk</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Je Klaus</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Ke Rafferty</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=bl>Th Cornelius</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Vi Magyari</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Pa Petrik</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Va Hamdamov</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Al Tarakanov</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Fr Bruneske</td><td class=bc>-</td><td class=blW>Th Haussknecht</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al Bartosh</td><td class=bc>-</td><td class=bl>Th Restel</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ei Rompa</td><td class=bc>-</td><td class=blW>An Kniaziuk</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ra Klaus</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Be Skrlep</td><td class=bc>-</td><td class=bl>Je Klaus</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=bl>Th Cornelius</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Vi Magyari</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Toft Nielsen</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Vl Voronov</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Pa Petrik</td><td class=bc>-</td><td class=blW>Va Hamdamov</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ol Majaniemi</td><td class=bc>-</td><td class=bl>Al Tarakanov</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Th Haussknecht</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>An Naszádi</td><td class=bc>-</td><td class=bl>Th Restel</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Fr Bruneske</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Bartosh</td><td class=bc>-</td><td class=blW>Ig Zaporojets</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ei Rompa</td><td class=bc>-</td><td class=blW>Je Klaus</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ra Klaus</td><td class=bc>-</td><td class=blW>Be Skrlep</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>Vi Magyari</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Vl Voronov</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Va Hamdamov</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Al Tarakanov</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pa Petrik</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>Th Restel</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Ig Zaporojets</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Fr Bruneske</td><td class=bc>-</td><td class=bl>Je Klaus</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Al Bartosh</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ei Rompa</td><td class=bc>-</td><td class=blW>Ra Klaus</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Vi Magyari</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Th Cornelius</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ke Rafferty</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ed Kuratnik</td><td class=bc>-</td><td class=bl>Al Tarakanov</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Toft Nielsen</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Th Restel</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Pa Petrik</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>Ig Zaporojets</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Je Klaus</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>An Naszádi</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Fr Bruneske</td><td class=bc>-</td><td class=bl>Ra Klaus</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Al Bartosh</td><td class=bc>-</td><td class=blW>Ei Rompa</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=bl>Al Tarakanov</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ke Rafferty</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Th Restel</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>An Kniaziuk</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ig Zaporojets</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pa Petrik</td><td class=bc>-</td><td class=blW>Je Klaus</td><td class=bc>2 : 11</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>Be Skrlep</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Ra Klaus</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Ei Rompa</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fr Bruneske</td><td class=bc>-</td><td class=blW>Al Bartosh</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Va Hamdamov</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Al Tarakanov</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>Th Restel</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>An Kniaziuk</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Ig Zaporojets</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Je Klaus</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Be Skrlep</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Pa Petrik</td><td class=bc>-</td><td class=blW>Ra Klaus</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ol Majaniemi</td><td class=bc>-</td><td class=bl>Ei Rompa</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Al Bartosh</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Fr Bruneske</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Th Restel</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>An Kniaziuk</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Vi Magyari</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>Je Klaus</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ke Rafferty</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=bl>Ra Klaus</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=bl>Ei Rompa</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Al Bartosh</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Pa Petrik</td><td class=bc>-</td><td class=blW>Fr Bruneske</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ol Majaniemi</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Al Tarakanov</td><td class=bc>-</td><td class=bl>Th Restel</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Va Hamdamov</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Je Klaus</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Vi Magyari</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Th Cornelius</td><td class=bc>-</td><td class=bl>Ra Klaus</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ke Rafferty</td><td class=bc>-</td><td class=bl>Ei Rompa</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ed Kuratnik</td><td class=bc>-</td><td class=bl>Al Bartosh</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Mi Toft Nielsen</td><td class=bc>-</td><td class=bl>Fr Bruneske</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>An Naszádi</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Pa Petrik</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Th Haussknecht</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Al Tarakanov</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Va Hamdamov</td><td class=bc>-</td><td class=bl>Je Klaus</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Vl Voronov</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Ra Klaus</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Vi Magyari</td><td class=bc>-</td><td class=bl>Ei Rompa</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>Al Bartosh</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Fr Bruneske</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>An Naszádi</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Mi Toft Nielsen</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Ol Majaniemi</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Pa Petrik</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Th Restel</td><td class=bc>-</td><td class=blW>Ig Zaporojets</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Je Klaus</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Al Tarakanov</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=bl>Ra Klaus</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Ei Rompa</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Al Bartosh</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Vi Magyari</td><td class=bc>-</td><td class=bl>Fr Bruneske</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Th Cornelius</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ke Rafferty</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ed Kuratnik</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Pa Petrik</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>Je Klaus</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Th Restel</td><td class=bc>-</td><td class=blW>Be Skrlep</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Th Haussknecht</td><td class=bc>-</td><td class=bl>Ra Klaus</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Tarakanov</td><td class=bc>-</td><td class=blW>Ei Rompa</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=blW>Al Bartosh</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Vl Voronov</td><td class=bc>-</td><td class=bl>Fr Bruneske</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>An Naszádi</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Vi Magyari</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Th Cornelius</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ke Rafferty</td><td class=bc>-</td><td class=bl>Pa Petrik</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ed Kuratnik</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Ig Zaporojets</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>An Kniaziuk</td><td class=bc>-</td><td class=bl>Ra Klaus</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Th Restel</td><td class=bc>-</td><td class=bl>Ei Rompa</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Al Bartosh</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Al Tarakanov</td><td class=bc>-</td><td class=bl>Fr Bruneske</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Va Hamdamov</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Vi Magyari</td><td class=bc>-</td><td class=bl>Pa Petrik</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Th Cornelius</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Mi Toft Nielsen</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Je Klaus</td><td class=bc>-</td><td class=bl>Ra Klaus</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=blW>Ei Rompa</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>Al Bartosh</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Th Restel</td><td class=bc>-</td><td class=bl>Fr Bruneske</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Th Haussknecht</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Al Tarakanov</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Va Hamdamov</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Vl Voronov</td><td class=bc>-</td><td class=bl>Pa Petrik</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>Ed Kuratnik</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=bl>Ei Rompa</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Je Klaus</td><td class=bc>-</td><td class=bl>Al Bartosh</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=bl>Fr Bruneske</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>An Kniaziuk</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Th Restel</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Al Tarakanov</td><td class=bc>-</td><td class=bl>Pa Petrik</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Va Hamdamov</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vi Magyari</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>Ra Klaus</td><td class=bc>-</td><td class=bl>Al Bartosh</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=blW>Fr Bruneske</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Je Klaus</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Ig Zaporojets</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>An Kniaziuk</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Th Restel</td><td class=bc>-</td><td class=bl>Pa Petrik</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Th Haussknecht</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Al Tarakanov</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Va Hamdamov</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Ke Rafferty</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Th Cornelius</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vi Magyari</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Ei Rompa</td><td class=bc>-</td><td class=blW>Fr Bruneske</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ra Klaus</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Je Klaus</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=blW>Pa Petrik</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>An Kniaziuk</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Th Restel</td><td class=bc>-</td><td class=blW>Mi Toft Nielsen</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Th Haussknecht</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Al Tarakanov</td><td class=bc>-</td><td class=blW>Ke Rafferty</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Va Hamdamov</td><td class=bc>-</td><td class=bl>Th Cornelius</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Vi Magyari</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Al Bartosh</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Ei Rompa</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ra Klaus</td><td class=bc>-</td><td class=blW>Ol Majaniemi</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Be Skrlep</td><td class=bc>-</td><td class=bl>Pa Petrik</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Je Klaus</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ig Zaporojets</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>An Kniaziuk</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Th Restel</td><td class=bc>-</td><td class=blW>Ke Rafferty</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Th Cornelius</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Al Tarakanov</td><td class=bc>-</td><td class=bl>Vi Magyari</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=brW>Fr Bruneske</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Al Bartosh</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ei Rompa</td><td class=bc>-</td><td class=bl>Pa Petrik</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ra Klaus</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=blW>Mi Toft Nielsen</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Je Klaus</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ig Zaporojets</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>Th Cornelius</td><td class=bc>4 : 8</tr></td>
<tr><td class=br>Th Restel</td><td class=bc>-</td><td class=bl>Vi Magyari</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Al Tarakanov</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
