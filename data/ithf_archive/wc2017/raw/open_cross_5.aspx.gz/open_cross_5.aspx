<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Open </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 5</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Se Ivanov</td><td class=ic>RUS</td><td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kL>1:7</td>
<td class=kW>2:1</td>
<td class=kW>11:1</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kW>8:1</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=br>74:29</td><td class=br>+45</td>
<td class=bc>13 - 3 - 1</td>
<td class=br><strong>29</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ja Dryák</td><td class=ic>CZE</td><td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>1:5</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=br>61:29</td><td class=br>+32</td>
<td class=bc>13 - 2 - 2</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Fi Hamáček</td><td class=ic>CZE</td><td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=br>66:36</td><td class=br>+30</td>
<td class=bc>12 - 4 - 1</td>
<td class=br><strong>28</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ve Gerasimov</td><td class=ic>RUS</td><td class=kW>7:1</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>8:4</td>
<td class=kW>4:3</td>
<td class=kL>4:5</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>8:1</td>
<td class=kW>3:1</td>
<td class=kW>8:0</td>
<td class=kW>6:2</td>
<td class=kW>8:5</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=br>81:40</td><td class=br>+41</td>
<td class=bc>11 - 3 - 3</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Os Henriksson</td><td class=ic>SWE</td><td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>7:1</td>
<td class=kW>5:4</td>
<td class=kW>9:0</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>10:2</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=br>74:31</td><td class=br>+43</td>
<td class=bc>11 - 2 - 4</td>
<td class=br><strong>24</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Gi Lasmanis</td><td class=ic>LAT</td><td class=kL>1:11</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>4:8</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>4:5</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kW>4:3</td>
<td class=kW>7:1</td>
<td class=kW>4:2</td>
<td class=kW>8:2</td>
<td class=kW>5:0</td>
<td class=br>64:54</td><td class=br>+10</td>
<td class=bc>11 - 1 - 5</td>
<td class=br><strong>23</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Be Rjavec</td><td class=ic>SLO</td><td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kL>0:5</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=br>50:32</td><td class=br>+18</td>
<td class=bc>10 - 2 - 5</td>
<td class=br><strong>22</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Bj Axelsen</td><td class=ic>DEN</td><td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kW>5:4</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>9:3</td>
<td class=kL>1:4</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=br>58:45</td><td class=br>+13</td>
<td class=bc>10 - 1 - 6</td>
<td class=br><strong>21</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Be Suominen</td><td class=ic>FIN</td><td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>10:2</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=br>58:34</td><td class=br>+24</td>
<td class=bc>9 - 1 - 7</td>
<td class=br><strong>19</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Am Fylling</td><td class=ic>NOR</td><td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>8:0</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=br>55:45</td><td class=br>+10</td>
<td class=bc>7 - 4 - 6</td>
<td class=br><strong>18</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Pe Borsanyi</td><td class=ic>HUN</td><td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:8</td>
<td class=kL>0:9</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=br>42:52</td><td class=br>-10</td>
<td class=bc>7 - 2 - 8</td>
<td class=br><strong>16</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Mi Černoch</td><td class=ic>CZE</td><td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>39:37</td><td class=br>+2</td>
<td class=bc>6 - 2 - 9</td>
<td class=br><strong>14</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Le Haussknecht</td><td class=ic>GER</td><td class=kL>1:8</td>
<td class=kL>3:5</td>
<td class=kL>4:5</td>
<td class=kL>0:8</td>
<td class=kL>2:6</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kL>3:9</td>
<td class=kL>2:7</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=kW>5:0</td>
<td class=br>48:70</td><td class=br>-22</td>
<td class=bc>5 - 0 - 12</td>
<td class=br><strong>10</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Sa Komaraite</td><td class=ic>LTU</td><td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>2:10</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kW>4:1</td>
<td class=kL>1:6</td>
<td class=kL>0:8</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=br>31:70</td><td class=br>-39</td>
<td class=bc>4 - 1 - 12</td>
<td class=br><strong>9</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ra Klaus</td><td class=ic>SUI</td><td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kL>2:6</td>
<td class=kL>5:8</td>
<td class=kL>2:5</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=br>37:65</td><td class=br>-28</td>
<td class=bc>4 - 1 - 12</td>
<td class=br><strong>9</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Va Hamdamov</td><td class=ic>EST</td><td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>2:10</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=br>32:57</td><td class=br>-25</td>
<td class=bc>2 - 3 - 12</td>
<td class=br><strong>7</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Mi Zeman</td><td class=ic>CZE</td><td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kL>2:8</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>0:7</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=br>30:89</td><td class=br>-59</td>
<td class=bc>1 - 2 - 14</td>
<td class=br><strong>4</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>E</td><td class=d>18.</td><td class=kt>Vj Kufrin</td><td class=ic>CRO</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=br>0:85</td><td class=br>-85</td>
<td class=bc>0 - 0 - 17</td>
<td class=br><strong>0</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Vj Kufrin</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ve Gerasimov</td><td class=bc>-</td><td class=bl>Sa Komaraite</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Ra Klaus</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=blW>Se Ivanov</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Vj Kufrin</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Sa Komaraite</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Ra Klaus</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ve Gerasimov</td><td class=bc>-</td><td class=bl>Se Ivanov</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Fi Hamáček</td><td class=bc>-</td><td class=bl>Os Henriksson</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=blW>Le Haussknecht</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Vj Kufrin</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Sa Komaraite</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ra Klaus</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ja Dryák</td><td class=bc>-</td><td class=blW>Se Ivanov</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ve Gerasimov</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Vj Kufrin</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=bl>Sa Komaraite</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Ra Klaus</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Se Ivanov</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ve Gerasimov</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Vj Kufrin</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Sa Komaraite</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Ra Klaus</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Se Ivanov</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Os Henriksson</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ja Dryák</td><td class=bc>-</td><td class=bl>Fi Hamáček</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Ve Gerasimov</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=blW>Sa Komaraite</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Ra Klaus</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=blW>Se Ivanov</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Le Haussknecht</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Fi Hamáček</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ve Gerasimov</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Dryák</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Sa Komaraite</td><td class=bc>-</td><td class=bl>Ra Klaus</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=blW>Se Ivanov</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Os Henriksson</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>10 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Ve Gerasimov</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Pe Borsanyi</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ra Klaus</td><td class=bc>-</td><td class=blW>Se Ivanov</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Sa Komaraite</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>2 : 10</tr></td>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=blW>Le Haussknecht</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=bl>Fi Hamáček</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=blW>Ve Gerasimov</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Se Ivanov</td><td class=bc>-</td><td class=bl>Os Henriksson</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ra Klaus</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Sa Komaraite</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=blW>Ve Gerasimov</td><td class=bc>4 : 8</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Se Ivanov</td><td class=bc>-</td><td class=bl>Fi Hamáček</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ra Klaus</td><td class=bc>-</td><td class=blW>Ve Gerasimov</td><td class=bc>5 : 8</tr></td>
<tr><td class=br>Sa Komaraite</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Mi Zeman</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Os Henriksson</td><td class=bc>-</td><td class=bl>Ve Gerasimov</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Se Ivanov</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ra Klaus</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Sa Komaraite</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=blW>Pe Borsanyi</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=bl>Ve Gerasimov</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Le Haussknecht</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Se Ivanov</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ra Klaus</td><td class=bc>-</td><td class=blW>Pe Borsanyi</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Sa Komaraite</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=blW>Mi Zeman</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Se Ivanov</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ra Klaus</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Sa Komaraite</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ve Gerasimov</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=blW>Pe Borsanyi</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>3 : 9</tr></td>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Se Ivanov</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Klaus</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Sa Komaraite</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ve Gerasimov</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Va Hamdamov</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Os Henriksson</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Se Ivanov</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>11 : 1</tr></td>
<tr><td class=brW>Ra Klaus</td><td class=bc>-</td><td class=bl>Vj Kufrin</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Sa Komaraite</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Pe Borsanyi</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ve Gerasimov</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Vj Kufrin</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Se Ivanov</td><td class=bc>-</td><td class=bl>Sa Komaraite</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ra Klaus</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ve Gerasimov</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Va Hamdamov</td><td class=bc>-</td><td class=bl>Vj Kufrin</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Le Haussknecht</td><td class=bc>-</td><td class=bl>Sa Komaraite</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Ra Klaus</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Se Ivanov</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Pe Borsanyi</td><td class=bc>-</td><td class=bl>Mi Zeman</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ve Gerasimov</td><td class=bc>-</td><td class=bl>Vj Kufrin</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Sa Komaraite</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=blW>Ra Klaus</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=blW>Se Ivanov</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Os Henriksson</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
