<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Team Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Team Open Play-Off</span></h2></div></div></div></div><p><div align="center">
<table border=0 cellpadding=2 cellspacing=0>
<tr><th colspan=11 class="hh"><font size="+1"><strong>Finals</strong></font></th></tr>
<tr><td class=br><b>Russia </b>&nbsp;&nbsp;</td>
<td class=bl>- Czech Republic &nbsp;&nbsp;</td>
<td class=bl><strong><a href="tp_309_1661_1664.aspx">det</a></strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>13:7&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>1/2</strong></font></th></tr>
<tr><td class=ar><b>Russia </b>&nbsp;&nbsp;</td>
<td class=al>- Latvia &nbsp;&nbsp;</td>
<td class=al><strong><a href="tp_309_1664_1672.aspx">det</a></strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>13:10&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br>Ukraine &nbsp;&nbsp;</td>
<td class=bl><b>- Czech Republic </b>&nbsp;&nbsp;</td>
<td class=bl><strong><a href="tp_309_1661_1665.aspx">det</a></strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>8:12&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>3rd</strong></font></th></tr>
<tr><td class=ar>Latvia &nbsp;&nbsp;</td>
<td class=al><b>- Ukraine </b>&nbsp;&nbsp;</td>
<td class=al><strong><a href="tp_309_1665_1672.aspx">det</a></strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>6:14&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>1/4</strong></font></th></tr>
<tr><td class=br><b>Russia  (1)</b>&nbsp;&nbsp;</td>
<td class=bl>- Estonia  (4)&nbsp;&nbsp;</td>
<td class=bl><strong><a href="tp_309_1664_1668.aspx">det</a></strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>13:0&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar>Finland  (3)&nbsp;&nbsp;</td>
<td class=al><b>- Latvia  (2)</b>&nbsp;&nbsp;</td>
<td class=al><strong><a href="tp_309_1663_1672.aspx">det</a></strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>9:13&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><b>Ukraine  (2)</b>&nbsp;&nbsp;</td>
<td class=bl>- Sweden  (3)&nbsp;&nbsp;</td>
<td class=bl><strong><a href="tp_309_1662_1665.aspx">det</a></strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>12:6&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar>Slovakia  (4)&nbsp;&nbsp;</td>
<td class=al><b>- Czech Republic  (1)</b>&nbsp;&nbsp;</td>
<td class=al><strong><a href="tp_309_341_1661.aspx">det</a></strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:13&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>5th</strong></font></th></tr>
<tr><td class=br><b>Finland </b>&nbsp;&nbsp;</td>
<td class=bl>- Sweden &nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>5th-8th</strong></font></th></tr>
<tr><td class=ar>Estonia &nbsp;&nbsp;</td>
<td class=al><b>- Finland </b>&nbsp;&nbsp;</td>
<td class=al><strong><a href="tp_309_1663_1668.aspx">det</a></strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>4:14&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><b>Sweden </b>&nbsp;&nbsp;</td>
<td class=bl>- Slovakia &nbsp;&nbsp;</td>
<td class=bl><strong><a href="tp_309_341_1662.aspx">det</a></strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>11:5&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>7th</strong></font></th></tr>
<tr><td class=ar>Estonia &nbsp;&nbsp;</td>
<td class=al><b>- Slovakia </b>&nbsp;&nbsp;</td>
<td class=al><strong><a href="tp_309_341_1668.aspx">det</a></strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>8:11&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>9th</strong></font></th></tr>
<tr><td class=br><b>Norway </b>&nbsp;&nbsp;</td>
<td class=bl>- Hungary &nbsp;&nbsp;</td>
<td class=bl><strong><a href="tp_309_1670_1674.aspx">det</a></strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>15:4&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>11th</strong></font></th></tr>
<tr><td class=ar>Lithuania &nbsp;&nbsp;</td>
<td class=al><b>- Germany </b>&nbsp;&nbsp;</td>
<td class=al><strong><a href="tp_309_1669_1673.aspx">det</a></strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>6:12&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>13th</strong></font></th></tr>
<tr><td class=br>Belarus &nbsp;&nbsp;</td>
<td class=bl><b>- Slovenia </b>&nbsp;&nbsp;</td>
<td class=bl><strong><a href="tp_309_1676_1852.aspx">det</a></strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>5:16&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
