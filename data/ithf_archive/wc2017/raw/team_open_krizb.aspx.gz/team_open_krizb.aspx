<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Team Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Team Open Results</span></h2></div></div></div></div><h3 align="right">Basic Groups&nbsp;&nbsp;</h3>
<p><div align="center">
<a href="Team_Open_umisteni.aspx">Play-Off</a><br>
<p class=v>Group T1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Russia</td><td class=kx>*</td>
<td class=kW><a href="t_309_1664_1665.aspx">12:9</a></td>
<td class=kW><a href="t_309_1663_1664.aspx">15:8</a></td>
<td class=kW><a href="t_309_341_1664.aspx">18:3</a></td>
<td class=kW><a href="t_309_1664_1674.aspx">19:2</a></td>
<td class=kW><a href="t_309_1664_1673.aspx">24:1</a></td>
<td class=kW><a href="t_309_1664_1852.aspx">20:4</a></td>
<td class=br>108:27</td><td class=br>+81</td>
<td class=bc>6 - 0 - 0</td>
<td class=br><strong>12</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Ukraine</td><td class=kL><a href="t_309_1664_1665.aspx">9:12</a></td>
<td class=kx>*</td>
<td class=kW><a href="t_309_1663_1665.aspx">13:10</a></td>
<td class=kW><a href="t_309_341_1665.aspx">14:9</a></td>
<td class=kW><a href="t_309_1665_1674.aspx">15:7</a></td>
<td class=kW><a href="t_309_1665_1673.aspx">16:7</a></td>
<td class=kW><a href="t_309_1665_1852.aspx">22:1</a></td>
<td class=br>89:46</td><td class=br>+43</td>
<td class=bc>5 - 0 - 1</td>
<td class=br><strong>10</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Finland</td><td class=kL><a href="t_309_1663_1664.aspx">8:15</a></td>
<td class=kL><a href="t_309_1663_1665.aspx">10:13</a></td>
<td class=kx>*</td>
<td class=kW><a href="t_309_341_1663.aspx">17:4</a></td>
<td class=kW><a href="t_309_1663_1674.aspx">14:6</a></td>
<td class=kW><a href="t_309_1663_1673.aspx">21:1</a></td>
<td class=kW><a href="t_309_1663_1852.aspx">24:1</a></td>
<td class=br>94:40</td><td class=br>+54</td>
<td class=bc>4 - 0 - 2</td>
<td class=br><strong>8</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Slovakia</td><td class=kL><a href="t_309_341_1664.aspx">3:18</a></td>
<td class=kL><a href="t_309_341_1665.aspx">9:14</a></td>
<td class=kL><a href="t_309_341_1663.aspx">4:17</a></td>
<td class=kx>*</td>
<td class=kW><a href="t_309_341_1674.aspx">11:10</a></td>
<td class=kW><a href="t_309_341_1673.aspx">19:2</a></td>
<td class=kW><a href="t_309_341_1852.aspx">24:0</a></td>
<td class=br>70:61</td><td class=br>+9</td>
<td class=bc>3 - 0 - 3</td>
<td class=br><strong>6</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Norway</td><td class=kL><a href="t_309_1664_1674.aspx">2:19</a></td>
<td class=kL><a href="t_309_1665_1674.aspx">7:15</a></td>
<td class=kL><a href="t_309_1663_1674.aspx">6:14</a></td>
<td class=kL><a href="t_309_341_1674.aspx">10:11</a></td>
<td class=kx>*</td>
<td class=kW><a href="t_309_1673_1674.aspx">24:0</a></td>
<td class=kW><a href="t_309_1674_1852.aspx">19:3</a></td>
<td class=br>68:62</td><td class=br>+6</td>
<td class=bc>2 - 0 - 4</td>
<td class=br><strong>4</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Lithuania</td><td class=kL><a href="t_309_1664_1673.aspx">1:24</a></td>
<td class=kL><a href="t_309_1665_1673.aspx">7:16</a></td>
<td class=kL><a href="t_309_1663_1673.aspx">1:21</a></td>
<td class=kL><a href="t_309_341_1673.aspx">2:19</a></td>
<td class=kL><a href="t_309_1673_1674.aspx">0:24</a></td>
<td class=kx>*</td>
<td class=kT><a href="t_309_1673_1852.aspx">10:10</a></td>
<td class=br>21:114</td><td class=br>-93</td>
<td class=bc>0 - 1 - 5</td>
<td class=br><strong>1</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Belarus</td><td class=kL><a href="t_309_1664_1852.aspx">4:20</a></td>
<td class=kL><a href="t_309_1665_1852.aspx">1:22</a></td>
<td class=kL><a href="t_309_1663_1852.aspx">1:24</a></td>
<td class=kL><a href="t_309_341_1852.aspx">0:24</a></td>
<td class=kL><a href="t_309_1674_1852.aspx">3:19</a></td>
<td class=kT><a href="t_309_1673_1852.aspx">10:10</a></td>
<td class=kx>*</td>
<td class=br>19:119</td><td class=br>-100</td>
<td class=bc>0 - 1 - 5</td>
<td class=br><strong>1</strong></td><td class=d>7.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ukraine</td><td class=bc>-</td><td class=bl>Belarus</td><td class=bc><a href="t_309_1665_1852.aspx">22 : 1</a></tr></td>
<tr><td class=brW>Finland</td><td class=bc>-</td><td class=bl>Lithuania</td><td class=bc><a href="t_309_1663_1673.aspx">21 : 1</a></tr></td>
<tr><td class=br>Norway</td><td class=bc>-</td><td class=blW>Slovakia</td><td class=bc><a href="t_309_341_1674.aspx">10 : 11</a></tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Russia</td><td class=bc>-</td><td class=bl>Ukraine</td><td class=bc><a href="t_309_1664_1665.aspx">12 : 9</a></tr></td>
<tr><td class=brW>Finland</td><td class=bc>-</td><td class=bl>Belarus</td><td class=bc><a href="t_309_1663_1852.aspx">24 : 1</a></tr></td>
<tr><td class=brW>Norway</td><td class=bc>-</td><td class=bl>Lithuania</td><td class=bc><a href="t_309_1673_1674.aspx">24 : 0</a></tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Russia</td><td class=bc>-</td><td class=bl>Finland</td><td class=bc><a href="t_309_1663_1664.aspx">15 : 8</a></tr></td>
<tr><td class=brW>Norway</td><td class=bc>-</td><td class=bl>Belarus</td><td class=bc><a href="t_309_1674_1852.aspx">19 : 3</a></tr></td>
<tr><td class=brW>Slovakia</td><td class=bc>-</td><td class=bl>Lithuania</td><td class=bc><a href="t_309_341_1673.aspx">19 : 2</a></tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ukraine</td><td class=bc>-</td><td class=bl>Finland</td><td class=bc><a href="t_309_1663_1665.aspx">13 : 10</a></tr></td>
<tr><td class=brW>Russia</td><td class=bc>-</td><td class=bl>Norway</td><td class=bc><a href="t_309_1664_1674.aspx">19 : 2</a></tr></td>
<tr><td class=brW>Slovakia</td><td class=bc>-</td><td class=bl>Belarus</td><td class=bc><a href="t_309_341_1852.aspx">24 : 0</a></tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ukraine</td><td class=bc>-</td><td class=bl>Norway</td><td class=bc><a href="t_309_1665_1674.aspx">15 : 7</a></tr></td>
<tr><td class=brW>Russia</td><td class=bc>-</td><td class=bl>Slovakia</td><td class=bc><a href="t_309_341_1664.aspx">18 : 3</a></tr></td>
<tr><td class=br>Lithuania</td><td class=bc>-</td><td class=bl>Belarus</td><td class=bc><a href="t_309_1673_1852.aspx">10 : 10</a></tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Finland</td><td class=bc>-</td><td class=bl>Norway</td><td class=bc><a href="t_309_1663_1674.aspx">14 : 6</a></tr></td>
<tr><td class=brW>Ukraine</td><td class=bc>-</td><td class=bl>Slovakia</td><td class=bc><a href="t_309_341_1665.aspx">14 : 9</a></tr></td>
<tr><td class=brW>Russia</td><td class=bc>-</td><td class=bl>Lithuania</td><td class=bc><a href="t_309_1664_1673.aspx">24 : 1</a></tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Finland</td><td class=bc>-</td><td class=bl>Slovakia</td><td class=bc><a href="t_309_341_1663.aspx">17 : 4</a></tr></td>
<tr><td class=brW>Ukraine</td><td class=bc>-</td><td class=bl>Lithuania</td><td class=bc><a href="t_309_1665_1673.aspx">16 : 7</a></tr></td>
<tr><td class=brW>Russia</td><td class=bc>-</td><td class=bl>Belarus</td><td class=bc><a href="t_309_1664_1852.aspx">20 : 4</a></tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group T2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Czech Republic</td><td class=kx>*</td>
<td class=kW><a href="t_309_1661_1672.aspx">11:10</a></td>
<td class=kW><a href="t_309_1661_1662.aspx">13:11</a></td>
<td class=kW><a href="t_309_1661_1668.aspx">18:4</a></td>
<td class=kW><a href="t_309_1661_1670.aspx">20:0</a></td>
<td class=kW><a href="t_309_1661_1669.aspx">20:1</a></td>
<td class=kW><a href="t_309_1661_1676.aspx">22:3</a></td>
<td class=kW><a href="t_309_1661_1677.aspx">25:0</a></td>
<td class=br>129:29</td><td class=br>+100</td>
<td class=bc>7 - 0 - 0</td>
<td class=br><strong>14</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Latvia</td><td class=kL><a href="t_309_1661_1672.aspx">10:11</a></td>
<td class=kx>*</td>
<td class=kW><a href="t_309_1662_1672.aspx">11:10</a></td>
<td class=kW><a href="t_309_1668_1672.aspx">14:7</a></td>
<td class=kW><a href="t_309_1670_1672.aspx">20:3</a></td>
<td class=kW><a href="t_309_1669_1672.aspx">21:1</a></td>
<td class=kW><a href="t_309_1672_1676.aspx">20:3</a></td>
<td class=kW><a href="t_309_1672_1677.aspx">23:1</a></td>
<td class=br>119:36</td><td class=br>+83</td>
<td class=bc>6 - 0 - 1</td>
<td class=br><strong>12</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Sweden</td><td class=kL><a href="t_309_1661_1662.aspx">11:13</a></td>
<td class=kL><a href="t_309_1662_1672.aspx">10:11</a></td>
<td class=kx>*</td>
<td class=kW><a href="t_309_1662_1668.aspx">17:1</a></td>
<td class=kW><a href="t_309_1662_1670.aspx">21:3</a></td>
<td class=kW><a href="t_309_1662_1669.aspx">22:1</a></td>
<td class=kW><a href="t_309_1662_1676.aspx">19:4</a></td>
<td class=kW><a href="t_309_1662_1677.aspx">25:0</a></td>
<td class=br>125:33</td><td class=br>+92</td>
<td class=bc>5 - 0 - 2</td>
<td class=br><strong>10</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Estonia</td><td class=kL><a href="t_309_1661_1668.aspx">4:18</a></td>
<td class=kL><a href="t_309_1668_1672.aspx">7:14</a></td>
<td class=kL><a href="t_309_1662_1668.aspx">1:17</a></td>
<td class=kx>*</td>
<td class=kW><a href="t_309_1668_1670.aspx">17:5</a></td>
<td class=kW><a href="t_309_1668_1669.aspx">17:4</a></td>
<td class=kW><a href="t_309_1668_1676.aspx">15:6</a></td>
<td class=kW><a href="t_309_1668_1677.aspx">19:3</a></td>
<td class=br>80:67</td><td class=br>+13</td>
<td class=bc>4 - 0 - 3</td>
<td class=br><strong>8</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Hungary</td><td class=kL><a href="t_309_1661_1670.aspx">0:20</a></td>
<td class=kL><a href="t_309_1670_1672.aspx">3:20</a></td>
<td class=kL><a href="t_309_1662_1670.aspx">3:21</a></td>
<td class=kL><a href="t_309_1668_1670.aspx">5:17</a></td>
<td class=kx>*</td>
<td class=kW><a href="t_309_1669_1670.aspx">14:8</a></td>
<td class=kL><a href="t_309_1670_1676.aspx">9:14</a></td>
<td class=kW><a href="t_309_1670_1677.aspx">14:9</a></td>
<td class=br>48:109</td><td class=br>-61</td>
<td class=bc>2 - 0 - 5</td>
<td class=br><strong>4</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Germany</td><td class=kL><a href="t_309_1661_1669.aspx">1:20</a></td>
<td class=kL><a href="t_309_1669_1672.aspx">1:21</a></td>
<td class=kL><a href="t_309_1662_1669.aspx">1:22</a></td>
<td class=kL><a href="t_309_1668_1669.aspx">4:17</a></td>
<td class=kL><a href="t_309_1669_1670.aspx">8:14</a></td>
<td class=kx>*</td>
<td class=kW><a href="t_309_1669_1676.aspx">13:7</a></td>
<td class=kW><a href="t_309_1669_1677.aspx">20:3</a></td>
<td class=br>48:104</td><td class=br>-56</td>
<td class=bc>2 - 0 - 5</td>
<td class=br><strong>4</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Slovenia</td><td class=kL><a href="t_309_1661_1676.aspx">3:22</a></td>
<td class=kL><a href="t_309_1672_1676.aspx">3:20</a></td>
<td class=kL><a href="t_309_1662_1676.aspx">4:19</a></td>
<td class=kL><a href="t_309_1668_1676.aspx">6:15</a></td>
<td class=kW><a href="t_309_1670_1676.aspx">14:9</a></td>
<td class=kL><a href="t_309_1669_1676.aspx">7:13</a></td>
<td class=kx>*</td>
<td class=kW><a href="t_309_1676_1677.aspx">17:7</a></td>
<td class=br>54:105</td><td class=br>-51</td>
<td class=bc>2 - 0 - 5</td>
<td class=br><strong>4</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Switzerland</td><td class=kL><a href="t_309_1661_1677.aspx">0:25</a></td>
<td class=kL><a href="t_309_1672_1677.aspx">1:23</a></td>
<td class=kL><a href="t_309_1662_1677.aspx">0:25</a></td>
<td class=kL><a href="t_309_1668_1677.aspx">3:19</a></td>
<td class=kL><a href="t_309_1670_1677.aspx">9:14</a></td>
<td class=kL><a href="t_309_1669_1677.aspx">3:20</a></td>
<td class=kL><a href="t_309_1676_1677.aspx">7:17</a></td>
<td class=kx>*</td>
<td class=br>23:143</td><td class=br>-120</td>
<td class=bc>0 - 0 - 7</td>
<td class=br><strong>0</strong></td><td class=d>8.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Latvia</td><td class=bc>-</td><td class=bl>Slovenia</td><td class=bc><a href="t_309_1672_1676.aspx">20 : 3</a></tr></td>
<tr><td class=brW>Sweden</td><td class=bc>-</td><td class=bl>Switzerland</td><td class=bc><a href="t_309_1662_1677.aspx">25 : 0</a></tr></td>
<tr><td class=brW>Czech Republic</td><td class=bc>-</td><td class=bl>Germany</td><td class=bc><a href="t_309_1661_1669.aspx">20 : 1</a></tr></td>
<tr><td class=brW>Estonia</td><td class=bc>-</td><td class=bl>Hungary</td><td class=bc><a href="t_309_1668_1670.aspx">17 : 5</a></tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Latvia</td><td class=bc>-</td><td class=bl>Sweden</td><td class=bc><a href="t_309_1662_1672.aspx">11 : 10</a></tr></td>
<tr><td class=brW>Czech Republic</td><td class=bc>-</td><td class=bl>Switzerland</td><td class=bc><a href="t_309_1661_1677.aspx">25 : 0</a></tr></td>
<tr><td class=brW>Estonia</td><td class=bc>-</td><td class=bl>Germany</td><td class=bc><a href="t_309_1668_1669.aspx">17 : 4</a></tr></td>
<tr><td class=br>Hungary</td><td class=bc>-</td><td class=blW>Slovenia</td><td class=bc><a href="t_309_1670_1676.aspx">9 : 14</a></tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Sweden</td><td class=bc>-</td><td class=bl>Slovenia</td><td class=bc><a href="t_309_1662_1676.aspx">19 : 4</a></tr></td>
<tr><td class=br>Latvia</td><td class=bc>-</td><td class=blW>Czech Republic</td><td class=bc><a href="t_309_1661_1672.aspx">10 : 11</a></tr></td>
<tr><td class=brW>Estonia</td><td class=bc>-</td><td class=bl>Switzerland</td><td class=bc><a href="t_309_1668_1677.aspx">19 : 3</a></tr></td>
<tr><td class=brW>Hungary</td><td class=bc>-</td><td class=bl>Germany</td><td class=bc><a href="t_309_1669_1670.aspx">14 : 8</a></tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Sweden</td><td class=bc>-</td><td class=blW>Czech Republic</td><td class=bc><a href="t_309_1661_1662.aspx">11 : 13</a></tr></td>
<tr><td class=brW>Latvia</td><td class=bc>-</td><td class=bl>Estonia</td><td class=bc><a href="t_309_1668_1672.aspx">14 : 7</a></tr></td>
<tr><td class=brW>Hungary</td><td class=bc>-</td><td class=bl>Switzerland</td><td class=bc><a href="t_309_1670_1677.aspx">14 : 9</a></tr></td>
<tr><td class=brW>Germany</td><td class=bc>-</td><td class=bl>Slovenia</td><td class=bc><a href="t_309_1669_1676.aspx">13 : 7</a></tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Czech Republic</td><td class=bc>-</td><td class=bl>Slovenia</td><td class=bc><a href="t_309_1661_1676.aspx">22 : 3</a></tr></td>
<tr><td class=brW>Sweden</td><td class=bc>-</td><td class=bl>Estonia</td><td class=bc><a href="t_309_1662_1668.aspx">17 : 1</a></tr></td>
<tr><td class=brW>Latvia</td><td class=bc>-</td><td class=bl>Hungary</td><td class=bc><a href="t_309_1670_1672.aspx">20 : 3</a></tr></td>
<tr><td class=brW>Germany</td><td class=bc>-</td><td class=bl>Switzerland</td><td class=bc><a href="t_309_1669_1677.aspx">20 : 3</a></tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Czech Republic</td><td class=bc>-</td><td class=bl>Estonia</td><td class=bc><a href="t_309_1661_1668.aspx">18 : 4</a></tr></td>
<tr><td class=brW>Sweden</td><td class=bc>-</td><td class=bl>Hungary</td><td class=bc><a href="t_309_1662_1670.aspx">21 : 3</a></tr></td>
<tr><td class=brW>Latvia</td><td class=bc>-</td><td class=bl>Germany</td><td class=bc><a href="t_309_1669_1672.aspx">21 : 1</a></tr></td>
<tr><td class=br>Switzerland</td><td class=bc>-</td><td class=blW>Slovenia</td><td class=bc><a href="t_309_1676_1677.aspx">7 : 17</a></tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Estonia</td><td class=bc>-</td><td class=bl>Slovenia</td><td class=bc><a href="t_309_1668_1676.aspx">15 : 6</a></tr></td>
<tr><td class=brW>Czech Republic</td><td class=bc>-</td><td class=bl>Hungary</td><td class=bc><a href="t_309_1661_1670.aspx">20 : 0</a></tr></td>
<tr><td class=brW>Sweden</td><td class=bc>-</td><td class=bl>Germany</td><td class=bc><a href="t_309_1662_1669.aspx">22 : 1</a></tr></td>
<tr><td class=brW>Latvia</td><td class=bc>-</td><td class=bl>Switzerland</td><td class=bc><a href="t_309_1672_1677.aspx">23 : 1</a></tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</table></div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
