<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Team Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Team Open : Russia &nbsp;&nbsp;vs.&nbsp;&nbsp;Finland &nbsp;&nbsp;15:8</span></h2></div></div></div></div><h3 align="right">Round: 3&nbsp;&nbsp;</h3>
<p><div align="center">
<table border=1 cellpadding="0" cellspacing="0" ><tr>
<table border="0" cellpadding="1" cellspacing="0" width="95%"><tr><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Alexander Miloradov<br>2-0-2 (13:12)</td></tr>
<tr><td class="k">Arseniy Stolyarov<br>3-0-2 (12:11)</td></tr>
<tr><td class="k">Yanis Galuzo<br>0-0-2 (3:9)</td></tr>
<tr><td class="k">Maxim Borisov<br>2-0-2 (18:17)</td></tr>
<tr><td class="k">Alexey Zaharov<br>3-2-0 (25:15)</td></tr>
<tr><td class="k">Nikita Zholobov<br>3-0-0 (13:6)</td></tr>
<tr><td class="k">Veniamin Gerasimov<br>1-0-0 (1:0)</td></tr>
<tr><td class="k">Sergey Ivanov<br>1-0-0 (5:3)</td></tr>
</table></td>
<td valign="top"><table border="0" cellspacing="0" cellpadding="0" width="100%"><tr><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 1</td></tr>
<tr><td class="hrac_sk_v">Alexander Miloradov</td><td class="vysledek" width="60">&nbsp; 3 : 2 &nbsp;</td><td class="hrac_sk">Jan Pelkonen</td></tr>
<tr><td class="hrac_sk">Arseniy Stolyarov</td><td class="vysledek" width="60">&nbsp; 1 : 2 &nbsp;</td><td class="hrac_sk_v">Santtu Sainio</td></tr>
<tr><td class="hrac_sk">Yanis Galuzo</td><td class="vysledek" width="60">&nbsp; 1 : 6 &nbsp;</td><td class="hrac_sk_v">Vesa Huotelin</td></tr>
<tr><td class="hrac_sk_v">Maxim Borisov</td><td class="vysledek" width="60">&nbsp; 5 : 2 &nbsp;</td><td class="hrac_sk">Antti Vuononsola</td></tr>
<tr><td class="hrac_sk_v">Alexey Zaharov</td><td class="vysledek" width="60">&nbsp; 6 : 2 &nbsp;</td><td class="hrac_sk">Kevin Eriksson</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;3:2</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 2</td></tr>
<tr><td class="hrac_sk">Alexey Zaharov</td><td class="vysledek" width="60">&nbsp; 4 : 4 &nbsp;</td><td class="hrac_sk">Santtu Sainio</td></tr>
<tr><td class="hrac_sk_v">Alexander Miloradov</td><td class="vysledek" width="60">&nbsp; 7 : 2 &nbsp;</td><td class="hrac_sk">Vesa Huotelin</td></tr>
<tr><td class="hrac_sk_v">Arseniy Stolyarov</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">Antti Vuononsola</td></tr>
<tr><td class="hrac_sk">Yanis Galuzo</td><td class="vysledek" width="60">&nbsp; 2 : 3 &nbsp;</td><td class="hrac_sk_v">Kevin Eriksson</td></tr>
<tr><td class="hrac_sk">Maxim Borisov</td><td class="vysledek" width="60">&nbsp; 3 : 5 &nbsp;</td><td class="hrac_sk_v">Jan Pelkonen</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;5:4</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td>
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 3</td></tr>
<tr><td class="hrac_sk_v">Maxim Borisov</td><td class="vysledek" width="60">&nbsp; 5 : 3 &nbsp;</td><td class="hrac_sk">Vesa Huotelin</td></tr>
<tr><td class="hrac_sk_v">Alexey Zaharov</td><td class="vysledek" width="60">&nbsp; 6 : 3 &nbsp;</td><td class="hrac_sk">Antti Vuononsola</td></tr>
<tr><td class="hrac_sk">Alexander Miloradov</td><td class="vysledek" width="60">&nbsp; 0 : 4 &nbsp;</td><td class="hrac_sk_v">Kevin Eriksson</td></tr>
<tr><td class="hrac_sk_v">Arseniy Stolyarov</td><td class="vysledek" width="60">&nbsp; 3 : 2 &nbsp;</td><td class="hrac_sk">Jan Pelkonen</td></tr>
<tr><td class="hrac_sk_v">Nikita Zholobov</td><td class="vysledek" width="60">&nbsp; 4 : 2 &nbsp;</td><td class="hrac_sk">Santtu Sainio</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;9:5</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 4</td></tr>
<tr><td class="hrac_sk_v">Nikita Zholobov</td><td class="vysledek" width="60">&nbsp; 7 : 3 &nbsp;</td><td class="hrac_sk">Antti Vuononsola</td></tr>
<tr><td class="hrac_sk">Maxim Borisov</td><td class="vysledek" width="60">&nbsp; 5 : 7 &nbsp;</td><td class="hrac_sk_v">Kevin Eriksson</td></tr>
<tr><td class="hrac_sk_v">Alexey Zaharov</td><td class="vysledek" width="60">&nbsp; 5 : 2 &nbsp;</td><td class="hrac_sk">Jan Pelkonen</td></tr>
<tr><td class="hrac_sk">Alexander Miloradov</td><td class="vysledek" width="60">&nbsp; 3 : 4 &nbsp;</td><td class="hrac_sk_v">Santtu Sainio</td></tr>
<tr><td class="hrac_sk">Arseniy Stolyarov</td><td class="vysledek" width="60">&nbsp; 2 : 5 &nbsp;</td><td class="hrac_sk_v">Vesa Huotelin</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;11:8</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td align="center" colspan="3">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 5</td></tr>
<tr><td class="hrac_sk_v">Arseniy Stolyarov</td><td class="vysledek" width="60">&nbsp; 2 : 1 &nbsp;</td><td class="hrac_sk">Kevin Eriksson</td></tr>
<tr><td class="hrac_sk_v">Nikita Zholobov</td><td class="vysledek" width="60">&nbsp; 2 : 1 &nbsp;</td><td class="hrac_sk">Jan Pelkonen</td></tr>
<tr><td class="hrac_sk_v">Veniamin Gerasimov</td><td class="vysledek" width="60">&nbsp; 1 : 0 &nbsp;</td><td class="hrac_sk">Santtu Sainio</td></tr>
<tr><td class="hrac_sk">Alexey Zaharov</td><td class="vysledek" width="60">&nbsp; 4 : 4 &nbsp;</td><td class="hrac_sk">Vesa Huotelin</td></tr>
<tr><td class="hrac_sk_v">Sergey Ivanov</td><td class="vysledek" width="60">&nbsp; 5 : 3 &nbsp;</td><td class="hrac_sk">Antti Vuononsola</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;15:8</td></tr></table>
</td></tr></table></td><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Jan Pelkonen<br>1-0-4 (12:16)</td></tr>
<tr><td class="k">Santtu Sainio<br>2-1-2 (12:13)</td></tr>
<tr><td class="k">Vesa Huotelin<br>2-1-2 (20:19)</td></tr>
<tr><td class="k">Antti Vuononsola<br>0-0-5 (12:27)</td></tr>
<tr><td class="k">Kevin Eriksson<br>3-0-2 (17:15)</td></tr>
</table></td></tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
