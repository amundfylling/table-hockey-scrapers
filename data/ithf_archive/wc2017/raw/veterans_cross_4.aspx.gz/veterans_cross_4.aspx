<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Veterans</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Veterans </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group V4</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>An Ekestubbe</td><td class=ic>SWE</td><td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=br>53:23</td><td class=br>+30</td>
<td class=bc>9 - 3 - 0</td>
<td class=br><strong>21</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>My Shalomayev</td><td class=ic>UKR</td><td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=br>47:27</td><td class=br>+20</td>
<td class=bc>10 - 0 - 2</td>
<td class=br><strong>20</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ig Saveljev</td><td class=ic>EST</td><td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=br>35:20</td><td class=br>+15</td>
<td class=bc>7 - 2 - 3</td>
<td class=br><strong>16</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Sa Kalninš</td><td class=ic>LAT</td><td class=kL>1:2</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kL>2:4</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=br>35:23</td><td class=br>+12</td>
<td class=bc>7 - 2 - 3</td>
<td class=br><strong>16</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Dm Petrov</td><td class=ic>RUS</td><td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kL>4:5</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>7:2</td>
<td class=kW>10:1</td>
<td class=br>50:26</td><td class=br>+24</td>
<td class=bc>6 - 3 - 3</td>
<td class=br><strong>15</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ja Sahlgren</td><td class=ic>FIN</td><td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>7:0</td>
<td class=br>27:15</td><td class=br>+12</td>
<td class=bc>6 - 2 - 4</td>
<td class=br><strong>14</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Ig Zaporojets</td><td class=ic>UKR</td><td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=br>30:30</td><td class=br>0</td>
<td class=bc>5 - 2 - 5</td>
<td class=br><strong>12</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Va Hamdamov</td><td class=ic>EST</td><td class=kT>1:1</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kW>5:4</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=br>29:32</td><td class=br>-3</td>
<td class=bc>4 - 3 - 5</td>
<td class=br><strong>11</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Mi Toft Nielsen</td><td class=ic>DEN</td><td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>4:5</td>
<td class=kL>0:6</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=br>26:39</td><td class=br>-13</td>
<td class=bc>4 - 0 - 8</td>
<td class=br><strong>8</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Jo Estmo</td><td class=ic>SWE</td><td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kW>5:3</td>
<td class=br>23:40</td><td class=br>-17</td>
<td class=bc>3 - 1 - 8</td>
<td class=br><strong>7</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>Fr Suma</td><td class=ic>SVK</td><td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kW>4:2</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kL>2:6</td>
<td class=br>23:44</td><td class=br>-21</td>
<td class=bc>3 - 1 - 8</td>
<td class=br><strong>7</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Vl Voronov</td><td class=ic>LTU</td><td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>2:7</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=br>23:50</td><td class=br>-27</td>
<td class=bc>3 - 0 - 9</td>
<td class=br><strong>6</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ro Locher</td><td class=ic>SUI</td><td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>1:10</td>
<td class=kL>0:7</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kW>6:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=br>25:57</td><td class=br>-32</td>
<td class=bc>1 - 1 - 10</td>
<td class=br><strong>3</strong></td><td class=d>13.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Jo Estmo</td><td class=bc>-</td><td class=blW>Vl Voronov</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Va Hamdamov</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=blW>Fr Suma</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ig Zaporojets</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Jo Estmo</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>Ja Sahlgren</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Mi Toft Nielsen</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ig Zaporojets</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Jo Estmo</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=blW>Ja Sahlgren</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Mi Toft Nielsen</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ig Zaporojets</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Ja Sahlgren</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Jo Estmo</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=bl>Ro Locher</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Vl Voronov</td><td class=bc>-</td><td class=bl>Ja Sahlgren</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Ro Locher</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Jo Estmo</td><td class=bc>-</td><td class=blW>Sa Kalninš</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=bl>Ja Sahlgren</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Vl Voronov</td><td class=bc>-</td><td class=bl>Ro Locher</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=blW>Sa Kalninš</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Ekestubbe</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ja Sahlgren</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=blW>Ro Locher</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Sa Kalninš</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Va Hamdamov</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ig Zaporojets</td><td class=bc>-</td><td class=bl>Jo Estmo</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ro Locher</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Sa Kalninš</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Fr Suma</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Jo Estmo</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Ro Locher</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Jo Estmo</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Mi Toft Nielsen</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>Sa Kalninš</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>Va Hamdamov</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Jo Estmo</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=bl>An Ekestubbe</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Fr Suma</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Sa Kalninš</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>Jo Estmo</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=bl>An Ekestubbe</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Va Hamdamov</td><td class=bc>-</td><td class=bl>Jo Estmo</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>Ig Zaporojets</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Jo Estmo</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Sa Kalninš</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>Mi Toft Nielsen</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ja Sahlgren</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>0 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
