<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Team Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Team Open : Sweden &nbsp;&nbsp;vs.&nbsp;&nbsp;Slovenia &nbsp;&nbsp;19:4</span></h2></div></div></div></div><h3 align="right">Round: 3&nbsp;&nbsp;</h3>
<p><div align="center">
<table border=1 cellpadding="0" cellspacing="0" ><tr>
<table border="0" cellpadding="1" cellspacing="0" width="95%"><tr><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Joakim Lundin<br>3-0-2 (15:11)</td></tr>
<tr><td class="k">Markus Nilsson<br>5-0-0 (28:8)</td></tr>
<tr><td class="k">Anders Ekestubbe<br>5-0-0 (21:6)</td></tr>
<tr><td class="k">Rickard Sjöstedt<br>3-0-2 (19:11)</td></tr>
<tr><td class="k">Martin Lunden<br>3-2-0 (12:5)</td></tr>
</table></td>
<td valign="top"><table border="0" cellspacing="0" cellpadding="0" width="100%"><tr><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 1</td></tr>
<tr><td class="hrac_sk_v">Joakim Lundin</td><td class="vysledek" width="60">&nbsp; 2 : 0 &nbsp;</td><td class="hrac_sk">Anze Bozic</td></tr>
<tr><td class="hrac_sk_v">Markus Nilsson</td><td class="vysledek" width="60">&nbsp; 5 : 4 &nbsp;</td><td class="hrac_sk">Bernard Rjavec</td></tr>
<tr><td class="hrac_sk_v">Anders Ekestubbe</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">Tim Weisseisen</td></tr>
<tr><td class="hrac_sk">Rickard Sjöstedt</td><td class="vysledek" width="60">&nbsp; 1 : 2 &nbsp;</td><td class="hrac_sk_v">Rok Skrlep</td></tr>
<tr><td class="hrac_sk_v">Martin Lunden</td><td class="vysledek" width="60">&nbsp; 3 : 1 &nbsp;</td><td class="hrac_sk">Miha Skrlep</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;4:1</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 2</td></tr>
<tr><td class="hrac_sk">Martin Lunden</td><td class="vysledek" width="60">&nbsp; 2 : 2 &nbsp;</td><td class="hrac_sk">Bernard Rjavec</td></tr>
<tr><td class="hrac_sk_v">Joakim Lundin</td><td class="vysledek" width="60">&nbsp; 6 : 1 &nbsp;</td><td class="hrac_sk">Tim Weisseisen</td></tr>
<tr><td class="hrac_sk_v">Markus Nilsson</td><td class="vysledek" width="60">&nbsp; 6 : 1 &nbsp;</td><td class="hrac_sk">Rok Skrlep</td></tr>
<tr><td class="hrac_sk_v">Anders Ekestubbe</td><td class="vysledek" width="60">&nbsp; 3 : 2 &nbsp;</td><td class="hrac_sk">Miha Skrlep</td></tr>
<tr><td class="hrac_sk_v">Rickard Sjöstedt</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">Anze Bozic</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;8:1</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td>
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 3</td></tr>
<tr><td class="hrac_sk">Rickard Sjöstedt</td><td class="vysledek" width="60">&nbsp; 2 : 4 &nbsp;</td><td class="hrac_sk_v">Tim Weisseisen</td></tr>
<tr><td class="hrac_sk">Martin Lunden</td><td class="vysledek" width="60">&nbsp; 1 : 1 &nbsp;</td><td class="hrac_sk">Rok Skrlep</td></tr>
<tr><td class="hrac_sk">Joakim Lundin</td><td class="vysledek" width="60">&nbsp; 2 : 3 &nbsp;</td><td class="hrac_sk_v">Miha Skrlep</td></tr>
<tr><td class="hrac_sk_v">Markus Nilsson</td><td class="vysledek" width="60">&nbsp; 7 : 0 &nbsp;</td><td class="hrac_sk">Anze Bozic</td></tr>
<tr><td class="hrac_sk_v">Anders Ekestubbe</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">Bernard Rjavec</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;10:3</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 4</td></tr>
<tr><td class="hrac_sk_v">Anders Ekestubbe</td><td class="vysledek" width="60">&nbsp; 5 : 0 &nbsp;</td><td class="hrac_sk">Rok Skrlep</td></tr>
<tr><td class="hrac_sk_v">Rickard Sjöstedt</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">Miha Skrlep</td></tr>
<tr><td class="hrac_sk_v">Martin Lunden</td><td class="vysledek" width="60">&nbsp; 3 : 0 &nbsp;</td><td class="hrac_sk">Anze Bozic</td></tr>
<tr><td class="hrac_sk">Joakim Lundin</td><td class="vysledek" width="60">&nbsp; 2 : 5 &nbsp;</td><td class="hrac_sk_v">Bernard Rjavec</td></tr>
<tr><td class="hrac_sk_v">Markus Nilsson</td><td class="vysledek" width="60">&nbsp; 4 : 3 &nbsp;</td><td class="hrac_sk">Tim Weisseisen</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;14:4</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td align="center" colspan="3">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 5</td></tr>
<tr><td class="hrac_sk_v">Markus Nilsson</td><td class="vysledek" width="60">&nbsp; 6 : 0 &nbsp;</td><td class="hrac_sk">Miha Skrlep</td></tr>
<tr><td class="hrac_sk_v">Anders Ekestubbe</td><td class="vysledek" width="60">&nbsp; 5 : 2 &nbsp;</td><td class="hrac_sk">Anze Bozic</td></tr>
<tr><td class="hrac_sk_v">Rickard Sjöstedt</td><td class="vysledek" width="60">&nbsp; 8 : 3 &nbsp;</td><td class="hrac_sk">Bernard Rjavec</td></tr>
<tr><td class="hrac_sk_v">Martin Lunden</td><td class="vysledek" width="60">&nbsp; 3 : 1 &nbsp;</td><td class="hrac_sk">Tim Weisseisen</td></tr>
<tr><td class="hrac_sk_v">Joakim Lundin</td><td class="vysledek" width="60">&nbsp; 3 : 2 &nbsp;</td><td class="hrac_sk">Rok Skrlep</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;19:4</td></tr></table>
</td></tr></table></td><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Anze Bozic<br>0-0-5 (3:21)</td></tr>
<tr><td class="k">Bernard Rjavec<br>1-1-3 (15:21)</td></tr>
<tr><td class="k">Tim Weisseisen<br>1-0-4 (10:19)</td></tr>
<tr><td class="k">Rok Skrlep<br>1-1-3 (6:16)</td></tr>
<tr><td class="k">Miha Skrlep<br>1-0-4 (7:18)</td></tr>
</table></td></tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
