<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Open </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 4</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ya Galuzo</td><td class=ic>RUS</td><td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kW>8:5</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>9:2</td>
<td class=kW>7:3</td>
<td class=kW>9:3</td>
<td class=kW>7:2</td>
<td class=kW>6:2</td>
<td class=kW>7:1</td>
<td class=br>107:39</td><td class=br>+68</td>
<td class=bc>17 - 0 - 1</td>
<td class=br><strong>34</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Al Miloradov</td><td class=ic>RUS</td><td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>10:1</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>9:1</td>
<td class=kW>4:3</td>
<td class=kW>10:1</td>
<td class=kW>6:1</td>
<td class=kW>8:0</td>
<td class=br>89:29</td><td class=br>+60</td>
<td class=bc>15 - 2 - 1</td>
<td class=br><strong>32</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ma Nilsson</td><td class=ic>SWE</td><td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>9:1</td>
<td class=kW>5:3</td>
<td class=br>81:38</td><td class=br>+43</td>
<td class=bc>13 - 2 - 3</td>
<td class=br><strong>28</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Pe Ostlund</td><td class=ic>SWE</td><td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kW>8:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>8:2</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>9:0</td>
<td class=kW>7:1</td>
<td class=br>73:31</td><td class=br>+42</td>
<td class=bc>13 - 2 - 3</td>
<td class=br><strong>28</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Kr Curkovic</td><td class=ic>CRO</td><td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>6:4</td>
<td class=kW>4:3</td>
<td class=kL>5:6</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>7:2</td>
<td class=kW>7:1</td>
<td class=kW>6:2</td>
<td class=kW>6:5</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=br>79:52</td><td class=br>+27</td>
<td class=bc>13 - 0 - 5</td>
<td class=br><strong>26</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ra Miglinieks</td><td class=ic>LAT</td><td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kT>5:5</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>9:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>7:3</td>
<td class=kW>11:2</td>
<td class=kW>6:0</td>
<td class=br>74:41</td><td class=br>+33</td>
<td class=bc>11 - 4 - 3</td>
<td class=br><strong>26</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ma Saveljeva</td><td class=ic>EST</td><td class=kL>4:5</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kL>4:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>10:5</td>
<td class=kW>8:2</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>6:3</td>
<td class=kW>7:0</td>
<td class=kW>7:0</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kW>5:4</td>
<td class=kW>7:0</td>
<td class=br>87:44</td><td class=br>+43</td>
<td class=bc>11 - 3 - 4</td>
<td class=br><strong>25</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ge Regula</td><td class=ic>HUN</td><td class=kL>1:7</td>
<td class=kT>4:4</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>5:10</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kW>9:2</td>
<td class=kW>11:0</td>
<td class=br>76:60</td><td class=br>+16</td>
<td class=bc>8 - 4 - 6</td>
<td class=br><strong>20</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Vi Sapozhnikov</td><td class=ic>UKR</td><td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kW>6:5</td>
<td class=kL>3:4</td>
<td class=kL>2:8</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kW>7:0</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=br>75:50</td><td class=br>+25</td>
<td class=bc>10 - 0 - 8</td>
<td class=br><strong>20</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Es Eidsnes</td><td class=ic>NOR</td><td class=kL>5:8</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>3:8</td>
<td class=kL>2:4</td>
<td class=kT>5:5</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kW>9:3</td>
<td class=kW>7:2</td>
<td class=kW>7:0</td>
<td class=br>78:62</td><td class=br>+16</td>
<td class=bc>8 - 2 - 8</td>
<td class=br><strong>18</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Mi Kobrle</td><td class=ic>CZE</td><td class=kL>3:7</td>
<td class=kL>1:3</td>
<td class=kL>4:5</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kW>5:2</td>
<td class=kL>1:8</td>
<td class=kW>11:4</td>
<td class=kW>7:1</td>
<td class=kW>7:3</td>
<td class=kW>5:2</td>
<td class=kW>9:0</td>
<td class=br>73:59</td><td class=br>+14</td>
<td class=bc>8 - 1 - 9</td>
<td class=br><strong>17</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ma Curkovic</td><td class=ic>CRO</td><td class=kL>2:3</td>
<td class=kL>1:10</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kL>0:7</td>
<td class=kW>4:2</td>
<td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>9:0</td>
<td class=kW>5:0</td>
<td class=br>54:58</td><td class=br>-4</td>
<td class=bc>8 - 1 - 9</td>
<td class=br><strong>17</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Va Dietze</td><td class=ic>GER</td><td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>10:1</td>
<td class=kW>8:0</td>
<td class=br>59:59</td><td class=br>0</td>
<td class=bc>8 - 0 - 10</td>
<td class=br><strong>16</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Si Vazhnik</td><td class=ic>BLR</td><td class=kL>2:9</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>2:8</td>
<td class=kL>2:7</td>
<td class=kL>1:9</td>
<td class=kL>0:7</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kW>8:1</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=br>43:81</td><td class=br>-38</td>
<td class=bc>4 - 1 - 13</td>
<td class=br><strong>9</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Ei Rompa</td><td class=ic>GER</td><td class=kL>3:7</td>
<td class=kL>1:9</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>4:11</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>32:83</td><td class=br>-51</td>
<td class=bc>3 - 3 - 12</td>
<td class=br><strong>9</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Al Tarakanov</td><td class=ic>KAZ</td><td class=kL>3:9</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=br>32:83</td><td class=br>-51</td>
<td class=bc>3 - 2 - 13</td>
<td class=br><strong>8</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Mi Toft Nielsen</td><td class=ic>DEN</td><td class=kL>2:7</td>
<td class=kL>1:10</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>5:6</td>
<td class=kL>3:7</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kL>3:9</td>
<td class=kL>3:7</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kW>8:0</td>
<td class=kW>5:0</td>
<td class=br>44:82</td><td class=br>-38</td>
<td class=bc>3 - 1 - 14</td>
<td class=br><strong>7</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>E</td><td class=d>18.</td><td class=kt>Ad Sowa</td><td class=ic>POL</td><td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>1:9</td>
<td class=kL>0:9</td>
<td class=kL>0:5</td>
<td class=kL>2:11</td>
<td class=kL>4:5</td>
<td class=kL>2:9</td>
<td class=kL>1:7</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kL>0:9</td>
<td class=kL>1:10</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>0:8</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=br>28:124</td><td class=br>-96</td>
<td class=bc>1 - 0 - 17</td>
<td class=br><strong>2</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>E</td><td class=d>19.</td><td class=kt>Ni Cornelius</td><td class=ic>CHI</td><td class=kL>1:7</td>
<td class=kL>0:8</td>
<td class=kL>3:5</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>0:11</td>
<td class=kL>0:7</td>
<td class=kL>0:7</td>
<td class=kL>0:9</td>
<td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=br>9:118</td><td class=br>-109</td>
<td class=bc>0 - 0 - 18</td>
<td class=br><strong>0</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Si Vazhnik</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Kr Curkovic</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Ma Curkovic</td><td class=bc>-</td><td class=bl>Al Tarakanov</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Ad Sowa</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Es Eidsnes</td><td class=bc>-</td><td class=blW>Ma Saveljeva</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ya Galuzo</td><td class=bc>-</td><td class=bl>Vi Sapozhnikov</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ei Rompa</td><td class=bc>11 : 4</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Al Miloradov</td><td class=bc>-</td><td class=bl>Pe Ostlund</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Si Vazhnik</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Al Tarakanov</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Kr Curkovic</td><td class=bc>-</td><td class=bl>Ad Sowa</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ma Curkovic</td><td class=bc>-</td><td class=bl>Ma Saveljeva</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Vi Sapozhnikov</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Es Eidsnes</td><td class=bc>-</td><td class=bl>Ei Rompa</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ya Galuzo</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Pe Ostlund</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ma Nilsson</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Mi Toft Nielsen</td><td class=bc>-</td><td class=bl>Al Tarakanov</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Si Vazhnik</td><td class=bc>-</td><td class=bl>Ad Sowa</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Ma Saveljeva</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Kr Curkovic</td><td class=bc>-</td><td class=blW>Vi Sapozhnikov</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Ma Curkovic</td><td class=bc>-</td><td class=bl>Ei Rompa</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Ge Regula</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Es Eidsnes</td><td class=bc>-</td><td class=blW>Pe Ostlund</td><td class=bc>3 : 8</tr></td>
<tr><td class=brW>Ya Galuzo</td><td class=bc>-</td><td class=bl>Ma Nilsson</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Al Miloradov</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Al Tarakanov</td><td class=bc>-</td><td class=bl>Ad Sowa</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Ma Saveljeva</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Vi Sapozhnikov</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Ei Rompa</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Kr Curkovic</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ma Curkovic</td><td class=bc>-</td><td class=blW>Pe Ostlund</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Ma Nilsson</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Es Eidsnes</td><td class=bc>-</td><td class=blW>Al Miloradov</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ya Galuzo</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ad Sowa</td><td class=bc>-</td><td class=blW>Ma Saveljeva</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Al Tarakanov</td><td class=bc>-</td><td class=blW>Vi Sapozhnikov</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Ei Rompa</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Ge Regula</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Pe Ostlund</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Kr Curkovic</td><td class=bc>-</td><td class=blW>Ma Nilsson</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ma Curkovic</td><td class=bc>-</td><td class=blW>Al Miloradov</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Es Eidsnes</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ma Saveljeva</td><td class=bc>-</td><td class=bl>Vi Sapozhnikov</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ad Sowa</td><td class=bc>-</td><td class=blW>Ei Rompa</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Al Tarakanov</td><td class=bc>-</td><td class=blW>Ge Regula</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Pe Ostlund</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Ma Nilsson</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Al Miloradov</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Kr Curkovic</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ma Curkovic</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Ya Galuzo</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Vi Sapozhnikov</td><td class=bc>-</td><td class=bl>Ei Rompa</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ma Saveljeva</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>10 : 5</tr></td>
<tr><td class=br>Ad Sowa</td><td class=bc>-</td><td class=blW>Pe Ostlund</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Al Tarakanov</td><td class=bc>-</td><td class=blW>Ma Nilsson</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Al Miloradov</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Kr Curkovic</td><td class=bc>-</td><td class=blW>Ya Galuzo</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ma Curkovic</td><td class=bc>-</td><td class=bl>Es Eidsnes</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ei Rompa</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vi Sapozhnikov</td><td class=bc>-</td><td class=blW>Pe Ostlund</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ma Saveljeva</td><td class=bc>-</td><td class=bl>Ma Nilsson</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ad Sowa</td><td class=bc>-</td><td class=blW>Al Miloradov</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Al Tarakanov</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Ya Galuzo</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Es Eidsnes</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Kr Curkovic</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=blW>Pe Ostlund</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ei Rompa</td><td class=bc>-</td><td class=blW>Ma Nilsson</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vi Sapozhnikov</td><td class=bc>-</td><td class=blW>Al Miloradov</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Saveljeva</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ad Sowa</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Tarakanov</td><td class=bc>-</td><td class=blW>Ya Galuzo</td><td class=bc>3 : 9</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Es Eidsnes</td><td class=bc>3 : 9</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Ma Curkovic</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Pe Ostlund</td><td class=bc>-</td><td class=blW>Ma Nilsson</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=bl>Al Miloradov</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ei Rompa</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vi Sapozhnikov</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ma Saveljeva</td><td class=bc>-</td><td class=blW>Ya Galuzo</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ad Sowa</td><td class=bc>-</td><td class=blW>Es Eidsnes</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Al Tarakanov</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Ma Curkovic</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Kr Curkovic</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ma Nilsson</td><td class=bc>-</td><td class=bl>Al Miloradov</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Pe Ostlund</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ei Rompa</td><td class=bc>-</td><td class=blW>Ya Galuzo</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Vi Sapozhnikov</td><td class=bc>-</td><td class=blW>Es Eidsnes</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ma Saveljeva</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ad Sowa</td><td class=bc>-</td><td class=blW>Ma Curkovic</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Al Tarakanov</td><td class=bc>-</td><td class=blW>Kr Curkovic</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Mi Toft Nielsen</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Al Miloradov</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Nilsson</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Pe Ostlund</td><td class=bc>-</td><td class=blW>Ya Galuzo</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=bl>Es Eidsnes</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ei Rompa</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Vi Sapozhnikov</td><td class=bc>-</td><td class=bl>Ma Curkovic</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ma Saveljeva</td><td class=bc>-</td><td class=blW>Kr Curkovic</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Ad Sowa</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Al Tarakanov</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Al Miloradov</td><td class=bc>-</td><td class=blW>Ya Galuzo</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Nilsson</td><td class=bc>-</td><td class=blW>Es Eidsnes</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Pe Ostlund</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>Ma Curkovic</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ei Rompa</td><td class=bc>-</td><td class=blW>Kr Curkovic</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Vi Sapozhnikov</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ma Saveljeva</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ad Sowa</td><td class=bc>-</td><td class=blW>Mi Toft Nielsen</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Ya Galuzo</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Es Eidsnes</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Al Miloradov</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ma Nilsson</td><td class=bc>-</td><td class=bl>Ma Curkovic</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pe Ostlund</td><td class=bc>-</td><td class=bl>Kr Curkovic</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>11 : 0</tr></td>
<tr><td class=br>Ei Rompa</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Vi Sapozhnikov</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Saveljeva</td><td class=bc>-</td><td class=bl>Al Tarakanov</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ya Galuzo</td><td class=bc>-</td><td class=bl>Es Eidsnes</td><td class=bc>8 : 5</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Ma Curkovic</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Al Miloradov</td><td class=bc>-</td><td class=bl>Kr Curkovic</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Nilsson</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Pe Ostlund</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ge Regula</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ei Rompa</td><td class=bc>-</td><td class=bl>Al Tarakanov</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vi Sapozhnikov</td><td class=bc>-</td><td class=bl>Ad Sowa</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Es Eidsnes</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ya Galuzo</td><td class=bc>-</td><td class=bl>Ma Curkovic</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Kr Curkovic</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Al Miloradov</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ma Nilsson</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Pe Ostlund</td><td class=bc>-</td><td class=bl>Al Tarakanov</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>Ad Sowa</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Ei Rompa</td><td class=bc>-</td><td class=blW>Ma Saveljeva</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Ma Curkovic</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Es Eidsnes</td><td class=bc>-</td><td class=blW>Kr Curkovic</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ya Galuzo</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Si Vazhnik</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Al Miloradov</td><td class=bc>-</td><td class=bl>Al Tarakanov</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ma Nilsson</td><td class=bc>-</td><td class=bl>Ad Sowa</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Pe Ostlund</td><td class=bc>-</td><td class=bl>Ma Saveljeva</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ge Regula</td><td class=bc>-</td><td class=bl>Vi Sapozhnikov</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ma Curkovic</td><td class=bc>-</td><td class=blW>Kr Curkovic</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Es Eidsnes</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ya Galuzo</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Al Tarakanov</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ad Sowa</td><td class=bc>11 : 2</tr></td>
<tr><td class=brW>Al Miloradov</td><td class=bc>-</td><td class=bl>Ma Saveljeva</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Nilsson</td><td class=bc>-</td><td class=bl>Vi Sapozhnikov</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pe Ostlund</td><td class=bc>-</td><td class=bl>Ei Rompa</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Kr Curkovic</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ma Curkovic</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Es Eidsnes</td><td class=bc>-</td><td class=bl>Al Tarakanov</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ya Galuzo</td><td class=bc>-</td><td class=bl>Ad Sowa</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Saveljeva</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Vi Sapozhnikov</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Al Miloradov</td><td class=bc>-</td><td class=bl>Ei Rompa</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Ma Nilsson</td><td class=bc>-</td><td class=bl>Ge Regula</td><td class=bc>6 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
