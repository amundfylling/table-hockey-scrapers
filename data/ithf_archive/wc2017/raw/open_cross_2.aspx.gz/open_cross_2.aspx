<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Open </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Pa Petr</td><td class=ic>CZE</td><td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kW>5:3</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=br>81:30</td><td class=br>+51</td>
<td class=bc>15 - 2 - 1</td>
<td class=br><strong>32</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ed Caics</td><td class=ic>LAT</td><td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>7:5</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kW>6:0</td>
<td class=kW>7:1</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>8:4</td>
<td class=kW>7:4</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=br>91:38</td><td class=br>+53</td>
<td class=bc>16 - 0 - 2</td>
<td class=br><strong>32</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ke Eriksson</td><td class=ic>FIN</td><td class=kW>5:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=kW>9:1</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kW>13:0</td>
<td class=kW>9:0</td>
<td class=br>90:41</td><td class=br>+49</td>
<td class=bc>14 - 1 - 3</td>
<td class=br><strong>29</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Pe Tměj</td><td class=ic>CZE</td><td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>8:0</td>
<td class=kW>6:1</td>
<td class=br>66:28</td><td class=br>+38</td>
<td class=bc>12 - 4 - 2</td>
<td class=br><strong>28</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ma Klippen</td><td class=ic>NOR</td><td class=kL>2:5</td>
<td class=kL>5:7</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=br>71:37</td><td class=br>+34</td>
<td class=bc>13 - 1 - 4</td>
<td class=br><strong>27</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Kr Lebl</td><td class=ic>CZE</td><td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=br>64:29</td><td class=br>+35</td>
<td class=bc>12 - 3 - 3</td>
<td class=br><strong>27</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Sa Sainio</td><td class=ic>FIN</td><td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>7:0</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kT>3:3</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=kW>4:3</td>
<td class=br>72:46</td><td class=br>+26</td>
<td class=bc>10 - 5 - 3</td>
<td class=br><strong>25</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Dm Petrov</td><td class=ic>RUS</td><td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>8:2</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>9:0</td>
<td class=kW>8:1</td>
<td class=br>64:33</td><td class=br>+31</td>
<td class=bc>10 - 2 - 6</td>
<td class=br><strong>22</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Oy Klippen</td><td class=ic>NOR</td><td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=br>43:42</td><td class=br>+1</td>
<td class=bc>9 - 1 - 8</td>
<td class=br><strong>19</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ti Weisseisen</td><td class=ic>SLO</td><td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>11:3</td>
<td class=kW>3:0</td>
<td class=br>50:52</td><td class=br>-2</td>
<td class=bc>8 - 2 - 8</td>
<td class=br><strong>18</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Si Pleikys</td><td class=ic>LTU</td><td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>0:7</td>
<td class=kW>3:2</td>
<td class=kL>0:6</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>9:1</td>
<td class=kW>6:0</td>
<td class=br>55:57</td><td class=br>-2</td>
<td class=bc>8 - 1 - 9</td>
<td class=br><strong>17</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ma Papp</td><td class=ic>HUN</td><td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>1:9</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kL>2:5</td>
<td class=kW>6:2</td>
<td class=kW>6:0</td>
<td class=kW>6:3</td>
<td class=br>55:67</td><td class=br>-12</td>
<td class=bc>7 - 1 - 10</td>
<td class=br><strong>15</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ki Eriksson</td><td class=ic>FIN</td><td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>5:6</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>8:0</td>
<td class=br>51:66</td><td class=br>-15</td>
<td class=bc>6 - 0 - 12</td>
<td class=br><strong>12</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Au Pleikys</td><td class=ic>LTU</td><td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>7:0</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=br>36:56</td><td class=br>-20</td>
<td class=bc>5 - 2 - 11</td>
<td class=br><strong>12</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Fr Bruneske</td><td class=ic>GER</td><td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>2:8</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kW>6:5</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=br>44:67</td><td class=br>-23</td>
<td class=bc>5 - 1 - 12</td>
<td class=br><strong>11</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Th Restel</td><td class=ic>GER</td><td class=kL>3:5</td>
<td class=kL>4:8</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=br>42:75</td><td class=br>-33</td>
<td class=bc>4 - 2 - 12</td>
<td class=br><strong>10</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Ke Rafferty</td><td class=ic>USA</td><td class=kL>2:5</td>
<td class=kL>4:7</td>
<td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=br>35:79</td><td class=br>-44</td>
<td class=bc>2 - 0 - 16</td>
<td class=br><strong>4</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>E</td><td class=d>18.</td><td class=kt>An Petrik</td><td class=ic>LTU</td><td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>0:13</td>
<td class=kL>0:8</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>0:9</td>
<td class=kL>2:5</td>
<td class=kL>3:11</td>
<td class=kL>1:9</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>17:105</td><td class=br>-88</td>
<td class=bc>1 - 0 - 17</td>
<td class=br><strong>2</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>E</td><td class=d>19.</td><td class=kt>Fi Kalinouski</td><td class=ic>BLR</td><td class=kL>1:2</td>
<td class=kL>0:8</td>
<td class=kL>0:9</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>1:8</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>3:6</td>
<td class=kL>0:8</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>15:94</td><td class=br>-79</td>
<td class=bc>0 - 0 - 18</td>
<td class=br><strong>0</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Fr Bruneske</td><td class=bc>-</td><td class=blW>Ti Weisseisen</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Pe Tměj</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ke Eriksson</td><td class=bc>-</td><td class=bl>Sa Sainio</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ki Eriksson</td><td class=bc>-</td><td class=bl>Th Restel</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Ke Rafferty</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Oy Klippen</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>An Petrik</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ti Weisseisen</td><td class=bc>-</td><td class=blW>Pe Tměj</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fr Bruneske</td><td class=bc>-</td><td class=bl>Sa Sainio</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Th Restel</td><td class=bc>8 : 4</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ki Eriksson</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Oy Klippen</td><td class=bc>-</td><td class=bl>An Petrik</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Pe Tměj</td><td class=bc>-</td><td class=bl>Sa Sainio</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ti Weisseisen</td><td class=bc>-</td><td class=bl>Th Restel</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Fr Bruneske</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ki Eriksson</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>An Petrik</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Klippen</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Oy Klippen</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Sa Sainio</td><td class=bc>-</td><td class=bl>Th Restel</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Pe Tměj</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ti Weisseisen</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Fr Bruneske</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>An Petrik</td><td class=bc>13 : 0</tr></td>
<tr><td class=br>Ki Eriksson</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Ma Papp</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Th Restel</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Sa Sainio</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Pe Tměj</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ti Weisseisen</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Fr Bruneske</td><td class=bc>-</td><td class=bl>An Petrik</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Ki Eriksson</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Oy Klippen</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Th Restel</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Sa Sainio</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pe Tměj</td><td class=bc>-</td><td class=bl>An Petrik</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ti Weisseisen</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Fr Bruneske</td><td class=bc>-</td><td class=blW>Ma Papp</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>Oy Klippen</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ki Eriksson</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Th Restel</td><td class=bc>-</td><td class=bl>An Petrik</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Sa Sainio</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Pe Tměj</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ti Weisseisen</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Fr Bruneske</td><td class=bc>-</td><td class=blW>Oy Klippen</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>7 : 5</tr></td>
<tr><td class=brW>Ke Eriksson</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>9 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>An Petrik</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Th Restel</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Sa Sainio</td><td class=bc>-</td><td class=bl>Kr Lebl</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pe Tměj</td><td class=bc>-</td><td class=bl>Oy Klippen</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ti Weisseisen</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Fr Bruneske</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Ki Eriksson</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>An Petrik</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Th Restel</td><td class=bc>-</td><td class=blW>Oy Klippen</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Sa Sainio</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pe Tměj</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ti Weisseisen</td><td class=bc>-</td><td class=blW>Ki Eriksson</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Fr Bruneske</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>An Petrik</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Oy Klippen</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Th Restel</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Sa Sainio</td><td class=bc>-</td><td class=bl>Ki Eriksson</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pe Tměj</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ti Weisseisen</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Petrik</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>Oy Klippen</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Ki Eriksson</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Th Restel</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Sa Sainio</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Pe Tměj</td><td class=bc>-</td><td class=bl>Fr Bruneske</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>Kr Lebl</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Oy Klippen</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>An Petrik</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Ki Eriksson</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Th Restel</td><td class=bc>-</td><td class=blW>Fr Bruneske</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Sa Sainio</td><td class=bc>-</td><td class=bl>Ti Weisseisen</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Oy Klippen</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Petrik</td><td class=bc>-</td><td class=blW>Ki Eriksson</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Ke Eriksson</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Fr Bruneske</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Ti Weisseisen</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Th Restel</td><td class=bc>-</td><td class=blW>Pe Tměj</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Oy Klippen</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Ki Eriksson</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>An Petrik</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Fr Bruneske</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Ti Weisseisen</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Pe Tměj</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Sa Sainio</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Oy Klippen</td><td class=bc>-</td><td class=bl>Ki Eriksson</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Fr Bruneske</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>An Petrik</td><td class=bc>-</td><td class=blW>Ti Weisseisen</td><td class=bc>3 : 11</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>Pe Tměj</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Sa Sainio</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=bl>Th Restel</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Ki Eriksson</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ma Klippen</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Oy Klippen</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Fr Bruneske</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Ti Weisseisen</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Pe Tměj</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Petrik</td><td class=bc>-</td><td class=blW>Sa Sainio</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Th Restel</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Ki Eriksson</td><td class=bc>-</td><td class=blW>Ke Eriksson</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Fr Bruneske</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Oy Klippen</td><td class=bc>-</td><td class=blW>Ti Weisseisen</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Kr Lebl</td><td class=bc>-</td><td class=bl>Pe Tměj</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>Sa Sainio</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Th Restel</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>An Petrik</td><td class=bc>-</td><td class=blW>Ke Rafferty</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ke Eriksson</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ki Eriksson</td><td class=bc>-</td><td class=blW>Fr Bruneske</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Ti Weisseisen</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ma Klippen</td><td class=bc>-</td><td class=blW>Pe Tměj</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Oy Klippen</td><td class=bc>-</td><td class=blW>Sa Sainio</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Th Restel</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>An Petrik</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Fr Bruneske</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ke Eriksson</td><td class=bc>-</td><td class=blW>Ti Weisseisen</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ki Eriksson</td><td class=bc>-</td><td class=blW>Pe Tměj</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Sa Sainio</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Th Restel</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Oy Klippen</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Lebl</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>3 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
