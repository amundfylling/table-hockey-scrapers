<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Veterans</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Veterans </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group VB</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Ri Sjöstedt</td><td class=ic>SWE</td><td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kW>8:2 K</td>
<td class=kW>2:0</td>
<td class=kW>8:1 K</td>
<td class=kW>4:0 K</td>
<td class=kW>5:3</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=br>61:30</td><td class=br>+31</td>
<td class=bc>13 - 1 - 1</td>
<td class=br><strong>27</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Da Šmíd</td><td class=ic>CZE</td><td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>6:5</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>5:2 K</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>4:1 K</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kL>2:5 K</td>
<td class=br>59:34</td><td class=br>+25</td>
<td class=bc>12 - 2 - 1</td>
<td class=br><strong>26</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Vi Henttonen</td><td class=ic>FIN</td><td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:2 K</td>
<td class=kW>3:1</td>
<td class=kW>4:1 K</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>8:0 K</td>
<td class=kW>5:0</td>
<td class=br>53:22</td><td class=br>+31</td>
<td class=bc>11 - 1 - 3</td>
<td class=br><strong>23</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Je Klaus</td><td class=ic>SUI</td><td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>2:4 K</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kL>4:5 K</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>5:3</td>
<td class=kL>4:6</td>
<td class=kW>8:3</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>6:1 K</td>
<td class=kT>4:4</td>
<td class=br>69:48</td><td class=br>+21</td>
<td class=bc>9 - 2 - 4</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ka Hudec</td><td class=ic>SVK</td><td class=kL>2:8 K</td>
<td class=kL>5:6</td>
<td class=kL>1:3</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>7:1 K</td>
<td class=kW>4:0 K</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=br>56:40</td><td class=br>+16</td>
<td class=bc>8 - 3 - 4</td>
<td class=br><strong>19</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Au Pleikys</td><td class=ic>LTU</td><td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>1:4 K</td>
<td class=kW>5:4 K</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>4:0 K</td>
<td class=kW>2:1</td>
<td class=br>39:36</td><td class=br>+3</td>
<td class=bc>7 - 4 - 4</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Ke Rafferty</td><td class=ic>USA</td><td class=kL>1:8 K</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>1:7 K</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:1 K</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kW>3:0</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=br>30:47</td><td class=br>-17</td>
<td class=bc>5 - 2 - 8</td>
<td class=br><strong>12</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Th Haussknecht</td><td class=ic>GER</td><td class=kL>0:4 K</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>0:4 K</td>
<td class=kL>2:3</td>
<td class=kL>1:3 K</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>5:4</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kL>2:6</td>
<td class=br>36:49</td><td class=br>-13</td>
<td class=bc>6 - 0 - 9</td>
<td class=br><strong>12</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Al Lorand st.</td><td class=ic>SVK</td><td class=kL>3:5</td>
<td class=kL>2:5 K</td>
<td class=kL>1:4</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>3:2 K</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=kW>1:0 K</td>
<td class=br>35:43</td><td class=br>-8</td>
<td class=bc>5 - 2 - 8</td>
<td class=br><strong>12</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Va Hamdamov</td><td class=ic>EST</td><td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>3:3 K</td>
<td class=kW>3:1 K</td>
<td class=kW>7:1</td>
<td class=kW>4:3 K</td>
<td class=kW>6:2</td>
<td class=kL>0:4</td>
<td class=br>46:49</td><td class=br>-3</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Ig Zaporojets</td><td class=ic>UKR</td><td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kW>6:4</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kT>3:3 K</td>
<td class=kx>*</td>
<td class=kL>1:2 K</td>
<td class=kW>3:1</td>
<td class=kW>5:2 K</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=br>34:47</td><td class=br>-13</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Mi Toft Nielsen</td><td class=ic>DEN</td><td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kL>3:8</td>
<td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3 K</td>
<td class=kW>2:1 K</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:3 K</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=br>35:47</td><td class=br>-12</td>
<td class=bc>4 - 3 - 8</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Vj Kufrin</td><td class=ic>CRO</td><td class=kL>2:3</td>
<td class=kL>1:4 K</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kL>2:3 K</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kW>3:1 K</td>
<td class=br>31:41</td><td class=br>-10</td>
<td class=bc>4 - 3 - 8</td>
<td class=br><strong>11</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Jo Estmo</td><td class=ic>SWE</td><td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>3:4 K</td>
<td class=kL>2:5 K</td>
<td class=kW>3:2 K</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=br>32:45</td><td class=br>-13</td>
<td class=bc>3 - 3 - 9</td>
<td class=br><strong>9</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Be Skrlep</td><td class=ic>SLO</td><td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>0:8 K</td>
<td class=kL>1:6 K</td>
<td class=kL>1:5</td>
<td class=kL>0:4 K</td>
<td class=kW>5:3</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>2:6</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=br>30:58</td><td class=br>-28</td>
<td class=bc>4 - 1 - 10</td>
<td class=br><strong>9</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Al Shekarev</td><td class=ic>EST</td><td class=kT>4:4</td>
<td class=kW>5:2 K</td>
<td class=kL>0:5</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kL>0:1 K</td>
<td class=kW>4:0</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>1:3 K</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=br>35:45</td><td class=br>-10</td>
<td class=bc>3 - 3 - 9</td>
<td class=br><strong>9</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Jo Estmo</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Va Hamdamov</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Th Haussknecht</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=bl>Je Klaus</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ke Rafferty</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Th Haussknecht</td><td class=bc>-</td><td class=bl>Jo Estmo</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Je Klaus</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=blW>Be Skrlep</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ke Rafferty</td><td class=bc>-</td><td class=bl>Jo Estmo</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Th Haussknecht</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>Je Klaus</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>Be Skrlep</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=bl>Jo Estmo</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Mi Toft Nielsen</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Th Haussknecht</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=blW>Je Klaus</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Jo Estmo</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=blW>Al Shekarev</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ig Zaporojets</td><td class=bc>-</td><td class=bl>Vj Kufrin</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=blW>Ri Sjöstedt</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Je Klaus</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Jo Estmo</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mi Toft Nielsen</td><td class=bc>-</td><td class=bl>Al Shekarev</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Va Hamdamov</td><td class=bc>-</td><td class=bl>Vj Kufrin</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Je Klaus</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Ri Sjöstedt</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Jo Estmo</td><td class=bc>-</td><td class=bl>Al Shekarev</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=bl>Vj Kufrin</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=blW>Al Lorand st.</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Be Skrlep</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Je Klaus</td><td class=bc>-</td><td class=blW>Ri Sjöstedt</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Jo Estmo</td><td class=bc>-</td><td class=blW>Vj Kufrin</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=blW>Al Lorand st.</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ig Zaporojets</td><td class=bc>-</td><td class=bl>Al Shekarev</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=blW>Th Haussknecht</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Ri Sjöstedt</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Je Klaus</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Ke Rafferty</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ri Sjöstedt</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Vj Kufrin</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Jo Estmo</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=blW>Je Klaus</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Ke Rafferty</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Al Shekarev</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=blW>Ri Sjöstedt</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Jo Estmo</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Je Klaus</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=blW>Be Skrlep</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Th Haussknecht</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=bl>Ri Sjöstedt</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jo Estmo</td><td class=bc>-</td><td class=blW>Je Klaus</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Mi Toft Nielsen</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Va Hamdamov</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ig Zaporojets</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Ri Sjöstedt</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Vj Kufrin</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Jo Estmo</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ig Zaporojets</td><td class=bc>-</td><td class=bl>Je Klaus</td><td class=bc>6 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
