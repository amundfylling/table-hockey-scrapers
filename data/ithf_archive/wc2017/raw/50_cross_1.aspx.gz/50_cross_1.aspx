<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>50+</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>50+ </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 50+ 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Al Danilov</td><td class=ic>RUS</td><td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=br>31:6</td><td class=br>+25</td>
<td class=bc>10 - 0 - 0</td>
<td class=br><strong>20</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Tr Mansson</td><td class=ic>SWE</td><td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=kL>1:4</td>
<td class=kW>6:2</td>
<td class=kW>5:4</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=br>45:15</td><td class=br>+30</td>
<td class=bc>8 - 0 - 2</td>
<td class=br><strong>16</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Va Hamdamov</td><td class=ic>EST</td><td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=br>29:16</td><td class=br>+13</td>
<td class=bc>6 - 2 - 2</td>
<td class=br><strong>14</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Th Haussknecht</td><td class=ic>GER</td><td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kL>4:6</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>27:26</td><td class=br>+1</td>
<td class=bc>5 - 2 - 3</td>
<td class=br><strong>12</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt>Mi Toft Nielsen</td><td class=ic>DEN</td><td class=kL>0:1</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>8:3</td>
<td class=kW>6:3</td>
<td class=kW>8:2</td>
<td class=kW>4:0</td>
<td class=br>36:19</td><td class=br>+17</td>
<td class=bc>6 - 0 - 4</td>
<td class=br><strong>12</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt>Th Restel</td><td class=ic>GER</td><td class=kL>2:6</td>
<td class=kW>4:1</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>6:5</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>5:0</td>
<td class=br>32:28</td><td class=br>+4</td>
<td class=bc>5 - 1 - 4</td>
<td class=br><strong>11</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Al Makushkin</td><td class=ic>RUS</td><td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=br>20:28</td><td class=br>-8</td>
<td class=bc>4 - 0 - 6</td>
<td class=br><strong>8</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Dm Petrov</td><td class=ic>RUS</td><td class=kL>1:2</td>
<td class=kL>4:5</td>
<td class=kL>1:5</td>
<td class=kW>6:4</td>
<td class=kL>3:8</td>
<td class=kL>5:6</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=br>38:37</td><td class=br>+1</td>
<td class=bc>4 - 0 - 6</td>
<td class=br><strong>8</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>C</td><td class=d>9.</td><td class=kt>Gi Remeika</td><td class=ic>LTU</td><td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kW>3:0</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=br>17:37</td><td class=br>-20</td>
<td class=bc>3 - 0 - 7</td>
<td class=br><strong>6</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>C</td><td class=d>10.</td><td class=kt>Su Pössl</td><td class=ic>SWE</td><td class=kL>0:1</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>2:8</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=br>12:44</td><td class=br>-32</td>
<td class=bc>1 - 0 - 9</td>
<td class=br><strong>2</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>Be Kunzler</td><td class=ic>CAN</td><td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=br>9:40</td><td class=br>-31</td>
<td class=bc>0 - 1 - 9</td>
<td class=br><strong>1</strong></td><td class=d>11.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Al Danilov</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Va Hamdamov</td><td class=bc>-</td><td class=bl>Th Restel</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Th Haussknecht</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>Su Pössl</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Al Makushkin</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Mi Toft Nielsen</td><td class=bc>-</td><td class=bl>Th Restel</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Al Danilov</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Va Hamdamov</td><td class=bc>-</td><td class=bl>Su Pössl</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Th Restel</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Mi Toft Nielsen</td><td class=bc>-</td><td class=bl>Su Pössl</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Al Danilov</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Th Haussknecht</td><td class=bc>-</td><td class=bl>Al Makushkin</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Gi Remeika</td><td class=bc>-</td><td class=bl>Su Pössl</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Th Restel</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Al Danilov</td><td class=bc>-</td><td class=bl>Al Makushkin</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Su Pössl</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Th Restel</td><td class=bc>-</td><td class=blW>Al Makushkin</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Mi Toft Nielsen</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Al Danilov</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>Tr Mansson</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Su Pössl</td><td class=bc>-</td><td class=blW>Al Makushkin</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Gi Remeika</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Th Restel</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Va Hamdamov</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>Al Makushkin</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Su Pössl</td><td class=bc>-</td><td class=blW>Th Haussknecht</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Va Hamdamov</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Th Restel</td><td class=bc>-</td><td class=blW>Al Danilov</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Al Makushkin</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>Va Hamdamov</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Su Pössl</td><td class=bc>-</td><td class=blW>Al Danilov</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Mi Toft Nielsen</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>Th Haussknecht</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Al Makushkin</td><td class=bc>-</td><td class=blW>Va Hamdamov</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=blW>Al Danilov</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>Mi Toft Nielsen</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Su Pössl</td><td class=bc>-</td><td class=blW>Th Restel</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>Al Danilov</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Al Makushkin</td><td class=bc>-</td><td class=blW>Mi Toft Nielsen</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Tr Mansson</td><td class=bc>-</td><td class=blW>Th Restel</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=blW>Al Danilov</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Th Haussknecht</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>Th Restel</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Al Makushkin</td><td class=bc>-</td><td class=blW>Gi Remeika</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Tr Mansson</td><td class=bc>-</td><td class=bl>Su Pössl</td><td class=bc>6 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
