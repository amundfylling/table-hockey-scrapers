<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>U13</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>U13 Participants</span></h2></div></div></div></div><h3 align="right">20 Participants&nbsp;&nbsp;</h3>
<p><div align="center">
<a href="U13_ranking.aspx">Final Rank.</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="U13_wr.aspx">WR Order</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="U13_krizB.aspx">Basic Groups</a>&nbsp;&nbsp;
<a href="U13_cross_1.aspx">U13</a>&nbsp;&nbsp;<a href="U13_umisteni.aspx">Play-Off</a>&nbsp;&nbsp;&nbsp;<a href="U13_inter.aspx">International</a>&nbsp;&nbsp;&nbsp;

<a href="U13_off.aspx">Off.</a>&nbsp;&nbsp;&nbsp;
<a href="U13_def.aspx">Def.</a>


<br><br><table class="part_bck" align="center">
<tr><td><table class="part" width="100%">
<tr class="nat_head"><td class="nat_header" ><img src="../../ithf/ranking/flags/BLR.gif"></td><td class="nat_header" colspan="8">Belarus</td></tr>
<tr class="pl"><td class="fg"><a href="U13_ranking.aspx">16</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1727&x=307">Fiodar Kalinouski</a>&nbsp;</td><td class="plby">&nbsp;2005&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=666752">2738</a>&nbsp;</td>
<td class="bg"><a href="U13_cross_1.aspx">U13</a></td><td class="bgr">16.</td><td class="bgp">10 pts</td><td class="bgs">32:59</td><td class="fg">&nbsp;</td></tr><tr class="nat_sum"><td class="nat_sum" colspan="9">19:&nbsp;&nbsp;&nbsp;4+&nbsp;&nbsp;&nbsp;2=&nbsp;&nbsp;&nbsp;13-</td></tr></table></td></tr>
<tr class="nil"><td class="nil" colspan="9">&nbsp;</td></tr>
<tr><td><table class="part" width="100%">
<tr class="nat_head"><td class="nat_header" ><img src="../../ithf/ranking/flags/CHI.gif"></td><td class="nat_header" colspan="8">Chile</td></tr>
<tr class="pl"><td class="fg"><a href="U13_ranking.aspx">20</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1732&x=307">Nicolas Cornelius</a>&nbsp;</td><td class="plby">&nbsp;2006&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=660701">4742</a>&nbsp;</td>
<td class="bg"><a href="U13_cross_1.aspx">U13</a></td><td class="bgr">20.</td><td class="bgp">2 pts</td><td class="bgs">6:119</td><td class="fg">&nbsp;</td></tr><tr class="nat_sum"><td class="nat_sum" colspan="9">19:&nbsp;&nbsp;&nbsp;0+&nbsp;&nbsp;&nbsp;2=&nbsp;&nbsp;&nbsp;17-</td></tr></table></td></tr>
<tr class="nil"><td class="nil" colspan="9">&nbsp;</td></tr>
<tr><td><table class="part" width="100%">
<tr class="nat_head"><td class="nat_header" ><img src="../../ithf/ranking/flags/CZE.gif"></td><td class="nat_header" colspan="8">Czech Republic</td></tr>
<tr class="pl"><td class="fg"><a href="U13_ranking.aspx">5</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1406&x=307">Jakub Matýsek</a>&nbsp;</td><td class="plby">&nbsp;2005&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=659537">285</a>&nbsp;</td>
<td class="bg"><a href="U13_cross_1.aspx">U13</a></td><td class="bgr">3.</td><td class="bgp">28 pts</td><td class="bgs">74:31</td><td class="fg"><a href="U13_umisteni.aspx">p-o</a></td></tr><tr class="pl"><td class="fg"><a href="U13_ranking.aspx">17</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1658&x=307">Vít Perkner</a>&nbsp;</td><td class="plby">&nbsp;2006&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=667718">2897</a>&nbsp;</td>
<td class="bg"><a href="U13_cross_1.aspx">U13</a></td><td class="bgr">17.</td><td class="bgp">8 pts</td><td class="bgs">26:101</td><td class="fg">&nbsp;</td></tr><tr class="pl"><td class="fg"><a href="U13_ranking.aspx">18</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1657&x=307">Jonáš Perkner</a>&nbsp;</td><td class="plby">&nbsp;2008&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=667720">6094</a>&nbsp;</td>
<td class="bg"><a href="U13_cross_1.aspx">U13</a></td><td class="bgr">18.</td><td class="bgp">4 pts</td><td class="bgs">19:123</td><td class="fg">&nbsp;</td></tr><tr class="nat_sum"><td class="nat_sum" colspan="9">62:&nbsp;&nbsp;&nbsp;20+&nbsp;&nbsp;&nbsp;5=&nbsp;&nbsp;&nbsp;37-</td></tr></table></td></tr>
<tr class="nil"><td class="nil" colspan="9">&nbsp;</td></tr>
<tr><td><table class="part" width="100%">
<tr class="nat_head"><td class="nat_header" ><img src="../../ithf/ranking/flags/EST.gif"></td><td class="nat_header" colspan="8">Estonia</td></tr>
<tr class="pl"><td class="fg"><a href="U13_ranking.aspx">11</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1736&x=307">Denis Andrijashkin</a>&nbsp;</td><td class="plby">&nbsp;2005&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=665760">1010</a>&nbsp;</td>
<td class="bg"><a href="U13_cross_1.aspx">U13</a></td><td class="bgr">11.</td><td class="bgp">22 pts</td><td class="bgs">56:41</td><td class="fg">&nbsp;</td></tr><tr class="nat_sum"><td class="nat_sum" colspan="9">19:&nbsp;&nbsp;&nbsp;10+&nbsp;&nbsp;&nbsp;2=&nbsp;&nbsp;&nbsp;7-</td></tr></table></td></tr>
<tr class="nil"><td class="nil" colspan="9">&nbsp;</td></tr>
<tr><td><table class="part" width="100%">
<tr class="nat_head"><td class="nat_header" ><img src="../../ithf/ranking/flags/FIN.gif"></td><td class="nat_header" colspan="8">Finland</td></tr>
<tr class="pl"><td class="fg"><a href="U13_ranking.aspx">12</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1745&x=307">Tiitus Roholm</a>&nbsp;</td><td class="plby">&nbsp;2006&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=664770">709</a>&nbsp;</td>
<td class="bg"><a href="U13_cross_1.aspx">U13</a></td><td class="bgr">12.</td><td class="bgp">17 pts</td><td class="bgs">55:45</td><td class="fg">&nbsp;</td></tr><tr class="pl"><td class="fg"><a href="U13_ranking.aspx">13</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1744&x=307">Joonatan Roholm</a>&nbsp;</td><td class="plby">&nbsp;2005&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=664769">773</a>&nbsp;</td>
<td class="bg"><a href="U13_cross_1.aspx">U13</a></td><td class="bgr">13.</td><td class="bgp">16 pts</td><td class="bgs">48:52</td><td class="fg">&nbsp;</td></tr><tr class="nat_sum"><td class="nat_sum" colspan="9">38:&nbsp;&nbsp;&nbsp;13+&nbsp;&nbsp;&nbsp;7=&nbsp;&nbsp;&nbsp;18-</td></tr></table></td></tr>
<tr class="nil"><td class="nil" colspan="9">&nbsp;</td></tr>
<tr><td><table class="part" width="100%">
<tr class="nat_head"><td class="nat_header" ><img src="../../ithf/ranking/flags/LAT.gif"></td><td class="nat_header" colspan="8">Latvia</td></tr>
<tr class="pl"><td class="fg"><a href="U13_ranking.aspx">8</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1769&x=307">Reinis Rihards Liepinš</a>&nbsp;</td><td class="plby">&nbsp;2005&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=662835">540</a>&nbsp;</td>
<td class="bg"><a href="U13_cross_1.aspx">U13</a></td><td class="bgr">8.</td><td class="bgp">23 pts</td><td class="bgs">72:48</td><td class="fg"><a href="U13_umisteni.aspx">p-o</a></td></tr><tr class="pl"><td class="fg"><a href="U13_ranking.aspx">6</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1773&x=307">Kristaps Riekstinš</a>&nbsp;</td><td class="plby">&nbsp;2004&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=665457">616</a>&nbsp;</td>
<td class="bg"><a href="U13_cross_1.aspx">U13</a></td><td class="bgr">5.</td><td class="bgp">28 pts</td><td class="bgs">52:22</td><td class="fg"><a href="U13_umisteni.aspx">p-o</a></td></tr><tr class="pl"><td class="fg"><a href="U13_ranking.aspx">9</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1771&x=307">Rinalds Sinicins</a>&nbsp;</td><td class="plby">&nbsp;2004&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=664787">635</a>&nbsp;</td>
<td class="bg"><a href="U13_cross_1.aspx">U13</a></td><td class="bgr">9.</td><td class="bgp">23 pts</td><td class="bgs">51:31</td><td class="fg">&nbsp;</td></tr><tr class="nat_sum"><td class="nat_sum" colspan="9">63:&nbsp;&nbsp;&nbsp;32+&nbsp;&nbsp;&nbsp;11=&nbsp;&nbsp;&nbsp;20-</td></tr></table></td></tr>
<tr class="nil"><td class="nil" colspan="9">&nbsp;</td></tr>
<tr><td><table class="part" width="100%">
<tr class="nat_head"><td class="nat_header" ><img src="../../ithf/ranking/flags/RUS.gif"></td><td class="nat_header" colspan="8">Russia</td></tr>
<tr class="pl"><td class="fg"><a href="U13_ranking.aspx">7</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1798&x=307">Ivan Smirnov</a>&nbsp;</td><td class="plby">&nbsp;2005&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=664305">506</a>&nbsp;</td>
<td class="bg"><a href="U13_cross_1.aspx">U13</a></td><td class="bgr">7.</td><td class="bgp">24 pts</td><td class="bgs">68:31</td><td class="fg"><a href="U13_umisteni.aspx">p-o</a></td></tr><tr class="nat_sum"><td class="nat_sum" colspan="9">22:&nbsp;&nbsp;&nbsp;11+&nbsp;&nbsp;&nbsp;2=&nbsp;&nbsp;&nbsp;9-</td></tr></table></td></tr>
<tr class="nil"><td class="nil" colspan="9">&nbsp;</td></tr>
<tr><td><table class="part" width="100%">
<tr class="nat_head"><td class="nat_header" ><img src="../../ithf/ranking/flags/SLO.gif"></td><td class="nat_header" colspan="8">Slovenia</td></tr>
<tr class="pl"><td class="fg"><a href="U13_ranking.aspx">14</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1813&x=307">Miha Skrlep</a>&nbsp;</td><td class="plby">&nbsp;2004&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=654663">991</a>&nbsp;</td>
<td class="bg"><a href="U13_cross_1.aspx">U13</a></td><td class="bgr">14.</td><td class="bgp">14 pts</td><td class="bgs">40:54</td><td class="fg">&nbsp;</td></tr><tr class="pl"><td class="fg"><a href="U13_ranking.aspx">19</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1814&x=307">Mojca Skrlep</a>&nbsp;</td><td class="plby">&nbsp;2007&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=659599">2129</a>&nbsp;</td>
<td class="bg"><a href="U13_cross_1.aspx">U13</a></td><td class="bgr">19.</td><td class="bgp">2 pts</td><td class="bgs">7:85</td><td class="fg">&nbsp;</td></tr><tr class="nat_sum"><td class="nat_sum" colspan="9">38:&nbsp;&nbsp;&nbsp;7+&nbsp;&nbsp;&nbsp;2=&nbsp;&nbsp;&nbsp;29-</td></tr></table></td></tr>
<tr class="nil"><td class="nil" colspan="9">&nbsp;</td></tr>
<tr><td><table class="part" width="100%">
<tr class="nat_head"><td class="nat_header" ><img src="../../ithf/ranking/flags/SWE.gif"></td><td class="nat_header" colspan="8">Sweden</td></tr>
<tr class="pl"><td class="fg"><a href="U13_ranking.aspx">2</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1824&x=307">Uno Österman</a>&nbsp;</td><td class="plby">&nbsp;2005&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=659773">288</a>&nbsp;</td>
<td class="bg"><a href="U13_cross_1.aspx">U13</a></td><td class="bgr">2.</td><td class="bgp">35 pts</td><td class="bgs">99:33</td><td class="fg"><a href="U13_umisteni.aspx">p-o</a></td></tr><tr class="pl"><td class="fg"><a href="U13_ranking.aspx">4</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1825&x=307">Niklas Blomberg</a>&nbsp;</td><td class="plby">&nbsp;2004&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=664291">537</a>&nbsp;</td>
<td class="bg"><a href="U13_cross_1.aspx">U13</a></td><td class="bgr">4.</td><td class="bgp">28 pts</td><td class="bgs">54:35</td><td class="fg"><a href="U13_umisteni.aspx">p-o</a></td></tr><tr class="pl"><td class="fg"><a href="U13_ranking.aspx">15</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1819&x=307">Liv Österman</a>&nbsp;</td><td class="plby">&nbsp;2006&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=663414">1787</a>&nbsp;</td>
<td class="bg"><a href="U13_cross_1.aspx">U13</a></td><td class="bgr">15.</td><td class="bgp">12 pts</td><td class="bgs">34:60</td><td class="fg">&nbsp;</td></tr><tr class="nat_sum"><td class="nat_sum" colspan="9">78:&nbsp;&nbsp;&nbsp;43+&nbsp;&nbsp;&nbsp;12=&nbsp;&nbsp;&nbsp;23-</td></tr></table></td></tr>
<tr class="nil"><td class="nil" colspan="9">&nbsp;</td></tr>
<tr><td><table class="part" width="100%">
<tr class="nat_head"><td class="nat_header" ><img src="../../ithf/ranking/flags/UKR.gif"></td><td class="nat_header" colspan="8">Ukraine</td></tr>
<tr class="pl"><td class="fg"><a href="U13_ranking.aspx">1</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1838&x=307">Evgeniy Matantsev</a>&nbsp;</td><td class="plby">&nbsp;2006&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=659673">39</a>&nbsp;</td>
<td class="bg"><a href="U13_cross_1.aspx">U13</a></td><td class="bgr">1.</td><td class="bgp">37 pts</td><td class="bgs">132:17</td><td class="fg"><a href="U13_umisteni.aspx">p-o</a></td></tr><tr class="pl"><td class="fg"><a href="U13_ranking.aspx">10</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1846&x=307">Artem Matantsev</a>&nbsp;</td><td class="plby">&nbsp;2008&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=659909">746</a>&nbsp;</td>
<td class="bg"><a href="U13_cross_1.aspx">U13</a></td><td class="bgr">10.</td><td class="bgp">22 pts</td><td class="bgs">68:41</td><td class="fg">&nbsp;</td></tr><tr class="pl"><td class="fg"><a href="U13_ranking.aspx">3</a></td><td class="name">&nbsp;<a href="https://stiga.trefik.cz/thstats/overview.aspx?idpl=1844&x=307">Hanna Ivantsova</a>&nbsp;</td><td class="plby">&nbsp;2006&nbsp;</td>
<td class="plwr">&nbsp;<a href="https://stiga.trefik.cz/ithf/ranking/player.aspx?ID=664934">807</a>&nbsp;</td>
<td class="bg"><a href="U13_cross_1.aspx">U13</a></td><td class="bgr">6.</td><td class="bgp">25 pts</td><td class="bgs">60:25</td><td class="fg"><a href="U13_umisteni.aspx">p-o</a></td></tr><tr class="nat_sum"><td class="nat_sum" colspan="9">80:&nbsp;&nbsp;&nbsp;50+&nbsp;&nbsp;&nbsp;13=&nbsp;&nbsp;&nbsp;17-</td></tr></table></td></tr>
</table></div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
