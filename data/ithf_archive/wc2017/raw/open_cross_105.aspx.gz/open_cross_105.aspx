<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Open </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt>Ma Lunden</td><td class=ic>SWE</td><td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>0:0</td>
<td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kW>1:0</td>
<td class=kL>0:4</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>66:35</td><td class=br>+31</td>
<td class=bc>15 - 5 - 3</td>
<td class=br><strong>35</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt>Mi Černoch</td><td class=ic>CZE</td><td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=kW>6:0</td>
<td class=br>72:26</td><td class=br>+46</td>
<td class=bc>17 - 1 - 5</td>
<td class=br><strong>35</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt>Ki Eriksson</td><td class=ic>FIN</td><td class=kT>0:0</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>8:2</td>
<td class=kW>3:1</td>
<td class=kW>6:4</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kL>3:4</td>
<td class=br>78:41</td><td class=br>+37</td>
<td class=bc>16 - 2 - 5</td>
<td class=br><strong>34</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt>Ev Tsyupko</td><td class=ic>ISR</td><td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kL>0:7</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>6:5</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>7:3</td>
<td class=kW>8:3</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=br>87:69</td><td class=br>+18</td>
<td class=bc>15 - 2 - 6</td>
<td class=br><strong>32</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>An Bozic</td><td class=ic>SLO</td><td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=br>62:44</td><td class=br>+18</td>
<td class=bc>14 - 4 - 5</td>
<td class=br><strong>32</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>An Fjermestad</td><td class=ic>NOR</td><td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kL>2:4</td>
<td class=kW>8:2</td>
<td class=kW>3:2</td>
<td class=br>71:52</td><td class=br>+19</td>
<td class=bc>15 - 1 - 7</td>
<td class=br><strong>31</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Va Dietze</td><td class=ic>GER</td><td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=br>79:60</td><td class=br>+19</td>
<td class=bc>12 - 5 - 6</td>
<td class=br><strong>29</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Le Haussknecht</td><td class=ic>GER</td><td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>7:0</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>6:0</td>
<td class=kL>2:3</td>
<td class=kL>4:6</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>6:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=br>75:50</td><td class=br>+25</td>
<td class=bc>14 - 1 - 8</td>
<td class=br><strong>29</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Ma Papp</td><td class=ic>HUN</td><td class=kT>4:4</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=br>71:60</td><td class=br>+11</td>
<td class=bc>12 - 3 - 8</td>
<td class=br><strong>27</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>I  Vépy</td><td class=ic>SVK</td><td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kW>6:2</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=br>65:59</td><td class=br>+6</td>
<td class=bc>11 - 4 - 8</td>
<td class=br><strong>26</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>To Hudec</td><td class=ic>SVK</td><td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kL>4:6</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=br>65:61</td><td class=br>+4</td>
<td class=bc>10 - 4 - 9</td>
<td class=br><strong>24</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ma Curkovic</td><td class=ic>CRO</td><td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kW>4:2</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>0:6</td>
<td class=kL>2:6</td>
<td class=kL>3:7</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=br>50:58</td><td class=br>-8</td>
<td class=bc>11 - 1 - 11</td>
<td class=br><strong>23</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Sa Komaraite</td><td class=ic>LTU</td><td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=br>60:62</td><td class=br>-2</td>
<td class=bc>10 - 3 - 10</td>
<td class=br><strong>23</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Ro Skrlep</td><td class=ic>SLO</td><td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=br>59:60</td><td class=br>-1</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Au Pleikys</td><td class=ic>LTU</td><td class=kL>0:1</td>
<td class=kL>0:6</td>
<td class=kL>2:8</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kW>6:2</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=br>48:57</td><td class=br>-9</td>
<td class=bc>7 - 6 - 10</td>
<td class=br><strong>20</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Ka Hudec</td><td class=ic>SVK</td><td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>5:6</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kW>7:3</td>
<td class=kL>0:1</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kT>5:5</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=br>62:64</td><td class=br>-2</td>
<td class=bc>8 - 3 - 12</td>
<td class=br><strong>19</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ma Satkus</td><td class=ic>LTU</td><td class=kW>4:0</td>
<td class=kL>0:1</td>
<td class=kL>4:6</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>6:4</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>6:4</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>7:1</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=br>62:72</td><td class=br>-10</td>
<td class=bc>5 - 6 - 12</td>
<td class=br><strong>16</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Fr Suma</td><td class=ic>SVK</td><td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=br>42:67</td><td class=br>-25</td>
<td class=bc>4 - 8 - 11</td>
<td class=br><strong>16</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Mi Margolis</td><td class=ic>ISR</td><td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=br>51:71</td><td class=br>-20</td>
<td class=bc>6 - 3 - 14</td>
<td class=br><strong>15</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Al Dalgou</td><td class=ic>BLR</td><td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=br>41:64</td><td class=br>-23</td>
<td class=bc>6 - 3 - 14</td>
<td class=br><strong>15</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Al Lorand st.</td><td class=ic>SVK</td><td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kL>3:7</td>
<td class=kL>2:5</td>
<td class=kL>0:7</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kT>5:5</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kW>4:1</td>
<td class=kT>5:5</td>
<td class=br>50:87</td><td class=br>-37</td>
<td class=bc>3 - 7 - 13</td>
<td class=br><strong>13</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Al Metelitsa</td><td class=ic>EST</td><td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>3:8</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kL>0:6</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=br>39:71</td><td class=br>-32</td>
<td class=bc>5 - 3 - 15</td>
<td class=br><strong>13</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Si Vazhnik</td><td class=ic>BLR</td><td class=kL>0:4</td>
<td class=kL>0:1</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kL>2:8</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=br>35:70</td><td class=br>-35</td>
<td class=bc>5 - 3 - 15</td>
<td class=br><strong>13</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Be Kunzler</td><td class=ic>CAN</td><td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kT>5:5</td>
<td class=kL>0:5</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=br>48:78</td><td class=br>-30</td>
<td class=bc>4 - 3 - 16</td>
<td class=br><strong>11</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ma Curkovic</td><td class=bc>-</td><td class=bl>Sa Komaraite</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ev Tsyupko</td><td class=bc>-</td><td class=bl>Ro Skrlep</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Dalgou</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ma Lunden</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ki Eriksson</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Sa Komaraite</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Curkovic</td><td class=bc>-</td><td class=blW>Ro Skrlep</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ev Tsyupko</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>I  Vépy</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Al Dalgou</td><td class=bc>-</td><td class=blW>Mi Margolis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Lunden</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ki Eriksson</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Sa Komaraite</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>Si Vazhnik</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Ro Skrlep</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ma Curkovic</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Fr Suma</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ev Tsyupko</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>I  Vépy</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Dalgou</td><td class=bc>-</td><td class=blW>Le Haussknecht</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ma Lunden</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ki Eriksson</td><td class=bc>-</td><td class=blW>Be Kunzler</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Sa Komaraite</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Al Metelitsa</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Ro Skrlep</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Curkovic</td><td class=bc>-</td><td class=blW>Mi Margolis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ev Tsyupko</td><td class=bc>-</td><td class=blW>Le Haussknecht</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Dalgou</td><td class=bc>-</td><td class=blW>Be Kunzler</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Lunden</td><td class=bc>-</td><td class=bl>Ki Eriksson</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Sa Komaraite</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Ro Skrlep</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>To Hudec</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Curkovic</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ev Tsyupko</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=bl>Ki Eriksson</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Dalgou</td><td class=bc>-</td><td class=blW>Ma Lunden</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=bl>Ro Skrlep</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Sa Komaraite</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=blW>Fr Suma</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>To Hudec</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ma Curkovic</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Černoch</td><td class=bc>-</td><td class=blW>Ki Eriksson</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ev Tsyupko</td><td class=bc>-</td><td class=blW>Ma Lunden</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>I  Vépy</td><td class=bc>-</td><td class=bl>Al Dalgou</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ro Skrlep</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Sa Komaraite</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Mi Margolis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Al Metelitsa</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>Be Kunzler</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Ki Eriksson</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Curkovic</td><td class=bc>-</td><td class=blW>Ma Lunden</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Al Dalgou</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ev Tsyupko</td><td class=bc>-</td><td class=bl>I  Vépy</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ro Skrlep</td><td class=bc>-</td><td class=blW>Fr Suma</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Mi Margolis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Sa Komaraite</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Le Haussknecht</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Ki Eriksson</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=bl>Ma Lunden</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>To Hudec</td><td class=bc>-</td><td class=bl>Al Dalgou</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Curkovic</td><td class=bc>-</td><td class=bl>I  Vépy</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Ev Tsyupko</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Skrlep</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Le Haussknecht</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Sa Komaraite</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=blW>Ki Eriksson</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Ma Lunden</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>Al Dalgou</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>I  Vépy</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Ev Tsyupko</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ma Curkovic</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Fr Suma</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Le Haussknecht</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ro Skrlep</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Be Kunzler</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Sa Komaraite</td><td class=bc>-</td><td class=blW>Ki Eriksson</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=bl>Ma Lunden</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=blW>Al Dalgou</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>I  Vépy</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=bl>Ev Tsyupko</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Ma Curkovic</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>An Fjermestad</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ro Skrlep</td><td class=bc>-</td><td class=blW>Ki Eriksson</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Ma Lunden</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Sa Komaraite</td><td class=bc>-</td><td class=bl>Al Dalgou</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>I  Vépy</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=blW>Ev Tsyupko</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Ma Curkovic</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Papp</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>Ki Eriksson</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Ma Lunden</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ro Skrlep</td><td class=bc>-</td><td class=bl>Al Dalgou</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Si Vazhnik</td><td class=bc>-</td><td class=bl>I  Vépy</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sa Komaraite</td><td class=bc>-</td><td class=blW>Ev Tsyupko</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=blW>Ma Curkovic</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Le Haussknecht</td><td class=bc>-</td><td class=bl>Be Kunzler</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Ki Eriksson</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=bl>Ma Lunden</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=bl>Al Dalgou</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>I  Vépy</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Ev Tsyupko</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ro Skrlep</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Si Vazhnik</td><td class=bc>-</td><td class=bl>Ma Curkovic</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Sa Komaraite</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Ma Papp</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Ki Eriksson</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Le Haussknecht</td><td class=bc>-</td><td class=bl>Ma Lunden</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Al Dalgou</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>I  Vépy</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=blW>Ev Tsyupko</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>Ma Curkovic</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ro Skrlep</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Ma Papp</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Sa Komaraite</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>Ma Lunden</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Al Dalgou</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Le Haussknecht</td><td class=bc>-</td><td class=bl>I  Vépy</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=blW>Ev Tsyupko</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=blW>Ma Curkovic</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>To Hudec</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Ma Papp</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ro Skrlep</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Si Vazhnik</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Sa Komaraite</td><td class=bc>-</td><td class=blW>Al Metelitsa</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ki Eriksson</td><td class=bc>-</td><td class=blW>Al Dalgou</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>I  Vépy</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Ev Tsyupko</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Le Haussknecht</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Ma Curkovic</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>To Hudec</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ro Skrlep</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Al Lorand st.</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Sa Komaraite</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ma Lunden</td><td class=bc>-</td><td class=bl>I  Vépy</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ki Eriksson</td><td class=bc>-</td><td class=bl>Ev Tsyupko</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Ma Curkovic</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Le Haussknecht</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ro Skrlep</td><td class=bc>-</td><td class=blW>Sa Komaraite</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Al Dalgou</td><td class=bc>-</td><td class=blW>Ev Tsyupko</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ma Lunden</td><td class=bc>-</td><td class=bl>Mi Černoch</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ki Eriksson</td><td class=bc>-</td><td class=bl>Ma Curkovic</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Ma Papp</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Al Metelitsa</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>Sa Komaraite</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ro Skrlep</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=blW>Mi Černoch</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al Dalgou</td><td class=bc>-</td><td class=blW>Ma Curkovic</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ma Lunden</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ki Eriksson</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Le Haussknecht</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Sa Komaraite</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=blW>Si Vazhnik</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=bl>Ro Skrlep</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Ev Tsyupko</td><td class=bc>-</td><td class=blW>Ma Curkovic</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>I  Vépy</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Al Dalgou</td><td class=bc>-</td><td class=blW>Ma Papp</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ma Lunden</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ki Eriksson</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>Al Metelitsa</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Le Haussknecht</td><td class=bc>-</td><td class=bl>Sa Komaraite</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Ro Skrlep</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>To Hudec</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ev Tsyupko</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Dalgou</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Lunden</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ki Eriksson</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>Sa Komaraite</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Le Haussknecht</td><td class=bc>-</td><td class=bl>Ro Skrlep</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Margolis</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=brW>Ma Curkovic</td><td class=bc>-</td><td class=bl>Ma Papp</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ev Tsyupko</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>I  Vépy</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Al Dalgou</td><td class=bc>-</td><td class=blW>Al Lorand st.</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ma Lunden</td><td class=bc>-</td><td class=bl>Sa Komaraite</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ki Eriksson</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>Ro Skrlep</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>An Fjermestad</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>To Hudec</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma Curkovic</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ev Tsyupko</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>I  Vépy</td><td class=bc>-</td><td class=bl>Sa Komaraite</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Dalgou</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Lunden</td><td class=bc>-</td><td class=blW>Ro Skrlep</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ki Eriksson</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Le Haussknecht</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>An Fjermestad</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Ma Papp</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>To Hudec</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ma Curkovic</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Černoch</td><td class=bc>-</td><td class=bl>Sa Komaraite</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ev Tsyupko</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>I  Vépy</td><td class=bc>-</td><td class=bl>Ro Skrlep</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Al Dalgou</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ma Lunden</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ki Eriksson</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Be Kunzler</td><td class=bc>-</td><td class=blW>Mi Margolis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>An Fjermestad</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
