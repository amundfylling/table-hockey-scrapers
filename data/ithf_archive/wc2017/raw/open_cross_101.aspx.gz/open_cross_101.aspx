<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Open </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group A1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>25</td>
<td class=ic>26</td>
<td class=ic>27</td>
<td class=ic>28</td>
<td class=ic>29</td>
<td class=ic>30</td>
<td class=ic>31</td>
<td class=ic>32</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt>Ma Borisov</td><td class=ic>RUS</td><td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>6:3</td>
<td class=kW>4:3 K</td>
<td class=kW>5:0</td>
<td class=kW>5:3 K</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>9:2</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kL>1:6</td>
<td class=kT>2:2 K</td>
<td class=kL>4:5</td>
<td class=kW>4:1 K</td>
<td class=kW>6:1 K</td>
<td class=kW>5:3</td>
<td class=kW>4:2 K</td>
<td class=kL>1:4</td>
<td class=kW>5:3</td>
<td class=kW>7:2</td>
<td class=kW>3:1 K</td>
<td class=kW>5:0</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>5:0 K</td>
<td class=br>146:59</td><td class=br>+87</td>
<td class=bc>26 - 1 - 4</td>
<td class=br><strong>53</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt>Ha Österman</td><td class=ic>SWE</td><td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kW>6:1 K</td>
<td class=kL>4:6</td>
<td class=kW>4:1 K</td>
<td class=kL>1:4</td>
<td class=kW>3:1 K</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kW>6:5</td>
<td class=kW>6:4</td>
<td class=kW>5:3</td>
<td class=kW>3:2 K</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>4:3 K</td>
<td class=kT>3:3 K</td>
<td class=kW>3:1</td>
<td class=kW>5:0 K</td>
<td class=br>117:78</td><td class=br>+39</td>
<td class=bc>21 - 5 - 5</td>
<td class=br><strong>47</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt>Ve Gerasimov</td><td class=ic>RUS</td><td class=kL>0:5</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>4:5</td>
<td class=kW>7:1 K</td>
<td class=kL>3:4 K</td>
<td class=kT>4:4</td>
<td class=kT>1:1 K</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kL>3:4 K</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>8:4 K</td>
<td class=kL>4:5 K</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>4:3 K</td>
<td class=kW>5:0 K</td>
<td class=br>126:78</td><td class=br>+48</td>
<td class=bc>19 - 4 - 8</td>
<td class=br><strong>42</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt>At Silis</td><td class=ic>LAT</td><td class=kL>3:6</td>
<td class=kW>3:0</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kW>2:1 K</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kT>2:2 K</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kW>4:2 K</td>
<td class=kW>5:0</td>
<td class=kL>2:3 K</td>
<td class=kT>4:4 K</td>
<td class=kW>6:0</td>
<td class=kW>7:2</td>
<td class=kW>5:0 K</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=kL>1:4</td>
<td class=kW>2:0</td>
<td class=kW>5:0 K</td>
<td class=br>98:58</td><td class=br>+40</td>
<td class=bc>18 - 5 - 8</td>
<td class=br><strong>41</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>Dm Litvinyuk</td><td class=ic>UKR</td><td class=kL>3:4 K</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>2:2 K</td>
<td class=kW>2:0</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kT>3:3 K</td>
<td class=kW>3:1</td>
<td class=kW>2:0 K</td>
<td class=kL>2:3 K</td>
<td class=kW>4:1</td>
<td class=kT>2:2 K</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kT>2:2 K</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>5:0 K</td>
<td class=br>91:57</td><td class=br>+34</td>
<td class=bc>16 - 8 - 7</td>
<td class=br><strong>40</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>An Vuononsola</td><td class=ic>FIN</td><td class=kL>0:5</td>
<td class=kL>1:6 K</td>
<td class=kL>4:5</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>4:2 K</td>
<td class=kW>6:2</td>
<td class=kL>3:6 K</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kW>6:1</td>
<td class=kT>4:4</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>4:3</td>
<td class=kT>3:3 K</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>4:2 K</td>
<td class=kT>1:1 K</td>
<td class=kL>1:3</td>
<td class=kW>5:0 K</td>
<td class=br>118:90</td><td class=br>+28</td>
<td class=bc>17 - 5 - 9</td>
<td class=br><strong>39</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Ro Ignatenko</td><td class=ic>UKR</td><td class=kL>3:5 K</td>
<td class=kW>6:4</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kT>2:2 K</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kL>0:6</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2 K</td>
<td class=kL>2:3</td>
<td class=kT>1:1 K</td>
<td class=kW>4:1 K</td>
<td class=kW>3:2</td>
<td class=kW>4:0 K</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>2:1 K</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>4:6</td>
<td class=kW>6:3</td>
<td class=kW>7:2</td>
<td class=kW>5:0 K</td>
<td class=br>102:75</td><td class=br>+27</td>
<td class=bc>15 - 9 - 7</td>
<td class=br><strong>39</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>Ni Zholobov</td><td class=ic>RUS</td><td class=kL>1:5</td>
<td class=kL>1:4 K</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>2:4 K</td>
<td class=kW>6:0</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kL>2:4 K</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>8:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>3:0 K</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kT>4:4 K</td>
<td class=kW>6:1 K</td>
<td class=kL>0:1</td>
<td class=kW>5:0 K</td>
<td class=br>100:64</td><td class=br>+36</td>
<td class=bc>17 - 5 - 9</td>
<td class=br><strong>39</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>Va Smagars</td><td class=ic>LAT</td><td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kT>2:2 K</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>3:2 K</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kT>2:2 K</td>
<td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=kL>3:6 K</td>
<td class=kW>5:0</td>
<td class=kW>3:0 K</td>
<td class=kL>2:3 K</td>
<td class=kT>0:0</td>
<td class=kT>1:1</td>
<td class=kL>0:4 K</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>5:0 K</td>
<td class=br>85:68</td><td class=br>+17</td>
<td class=bc>17 - 5 - 9</td>
<td class=br><strong>39</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Ed Saulitis</td><td class=ic>LAT</td><td class=kL>2:9</td>
<td class=kL>1:3 K</td>
<td class=kW>5:4</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kW>6:3 K</td>
<td class=kT>2:2</td>
<td class=kW>4:2 K</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>3:0 K</td>
<td class=kL>0:2</td>
<td class=kT>4:4</td>
<td class=kT>3:3 K</td>
<td class=kW>6:1 K</td>
<td class=kW>6:2</td>
<td class=kW>5:0 K</td>
<td class=br>94:71</td><td class=br>+23</td>
<td class=bc>15 - 7 - 9</td>
<td class=br><strong>37</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>Se Ivanov</td><td class=ic>RUS</td><td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kL>1:7 K</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>6:1 K</td>
<td class=kT>2:2</td>
<td class=kW>2:1 K</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>3:2 K</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kW>11:1 K</td>
<td class=kW>6:3 K</td>
<td class=kW>6:3</td>
<td class=kT>1:1</td>
<td class=kW>2:1 K</td>
<td class=kW>5:0 K</td>
<td class=br>96:74</td><td class=br>+22</td>
<td class=bc>15 - 6 - 10</td>
<td class=br><strong>36</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>Fi Hamáček</td><td class=ic>CZE</td><td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kW>4:3 K</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kL>1:6 K</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kT>2:2 K</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kT>3:3 K</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>3:2 K</td>
<td class=kW>7:2 K</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kT>2:2 K</td>
<td class=kW>5:0 K</td>
<td class=br>74:68</td><td class=br>+6</td>
<td class=bc>14 - 7 - 10</td>
<td class=br><strong>35</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt>Jo Lundin</td><td class=ic>SWE</td><td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kL>1:2 K</td>
<td class=kT>1:1</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kL>2:3 K</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kT>1:1 K</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kW>6:1 K</td>
<td class=kT>3:3</td>
<td class=kT>2:2 K</td>
<td class=kT>4:4 K</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0 K</td>
<td class=br>79:70</td><td class=br>+9</td>
<td class=bc>11 - 12 - 8</td>
<td class=br><strong>34</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt>Os Henriksson</td><td class=ic>SWE</td><td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kT>1:1 K</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>1:8</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>1:2 K</td>
<td class=kT>2:2 K</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kW>5:1 K</td>
<td class=kL>2:3</td>
<td class=kW>6:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3 K</td>
<td class=kL>2:3 K</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kL>1:2 K</td>
<td class=kW>5:0 K</td>
<td class=br>97:80</td><td class=br>+17</td>
<td class=bc>13 - 7 - 11</td>
<td class=br><strong>33</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt>My Spivakovskyy</td><td class=ic>UKR</td><td class=kT>2:2 K</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>3:3 K</td>
<td class=kT>4:4</td>
<td class=kT>2:2 K</td>
<td class=kL>1:2</td>
<td class=kW>6:1</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>0:5</td>
<td class=kW>4:2 K</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2</td>
<td class=kT>1:1 K</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kW>4:0 K</td>
<td class=kT>2:2</td>
<td class=kW>6:4</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>5:0 K</td>
<td class=br>81:74</td><td class=br>+7</td>
<td class=bc>11 - 11 - 9</td>
<td class=br><strong>33</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt>An Ekestubbe</td><td class=ic>SWE</td><td class=kW>5:4</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2 K</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kT>2:2 K</td>
<td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kT>1:1 K</td>
<td class=kL>2:6</td>
<td class=kW>5:0</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kW>4:2 K</td>
<td class=kW>2:1</td>
<td class=kT>2:2 K</td>
<td class=kL>2:4 K</td>
<td class=kW>5:4</td>
<td class=kW>2:0</td>
<td class=kL>0:1 K</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kL>2:5</td>
<td class=kW>5:0 K</td>
<td class=br>79:81</td><td class=br>-2</td>
<td class=bc>12 - 8 - 11</td>
<td class=br><strong>32</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Zd Matoušek ml.</td><td class=ic>CZE</td><td class=kL>1:4 K</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>0:1</td>
<td class=kL>0:2 K</td>
<td class=kL>2:4</td>
<td class=kT>1:1 K</td>
<td class=kT>4:4</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kL>2:7</td>
<td class=kL>2:4 K</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>7:2 K</td>
<td class=kL>2:3</td>
<td class=kT>3:3 K</td>
<td class=kW>4:3</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kL>1:2 K</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>5:0 K</td>
<td class=br>81:79</td><td class=br>+2</td>
<td class=bc>14 - 3 - 14</td>
<td class=br><strong>31</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>El Silinš</td><td class=ic>LAT</td><td class=kL>1:6 K</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kW>3:2 K</td>
<td class=kL>3:4</td>
<td class=kL>1:4 K</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2 K</td>
<td class=kL>1:2</td>
<td class=kL>2:7 K</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:2 K</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>1:3 K</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0 K</td>
<td class=br>81:84</td><td class=br>-3</td>
<td class=bc>13 - 4 - 14</td>
<td class=br><strong>30</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Mi Hvižď</td><td class=ic>CZE</td><td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>2:4 K</td>
<td class=kL>1:4</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>6:3 K</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>1:6 K</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>2:4 K</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kL>1:2 K</td>
<td class=kW>5:2 K</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kT>2:2 K</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kW>5:0 K</td>
<td class=br>91:85</td><td class=br>+6</td>
<td class=bc>12 - 6 - 13</td>
<td class=br><strong>30</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Kr Iso-Tryykari</td><td class=ic>FIN</td><td class=kL>2:4 K</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kT>2:2 K</td>
<td class=kL>3:6</td>
<td class=kL>0:4 K</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kT>1:1 K</td>
<td class=kL>1:2</td>
<td class=kT>3:3 K</td>
<td class=kL>2:4 K</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>2:0 K</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>6:5</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>5:0 K</td>
<td class=br>74:94</td><td class=br>-20</td>
<td class=bc>11 - 7 - 13</td>
<td class=br><strong>29</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Ri Sjöstedt</td><td class=ic>SWE</td><td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>3:2 K</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>0:3 K</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2 K</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kT>2:2 K</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kW>2:1 K</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>1:0 K</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3 K</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>5:0 K</td>
<td class=br>67:71</td><td class=br>-4</td>
<td class=bc>12 - 5 - 14</td>
<td class=br><strong>29</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Yn Aasheim</td><td class=ic>NOR</td><td class=kL>3:5</td>
<td class=kL>4:5</td>
<td class=kL>4:5</td>
<td class=kT>4:4 K</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2 K</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kW>2:0</td>
<td class=kT>4:4 K</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kW>4:2 K</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kL>2:5 K</td>
<td class=kT>3:3</td>
<td class=kL>0:1 K</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>1:0</td>
<td class=kL>3:7 K</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0 K</td>
<td class=br>93:94</td><td class=br>-1</td>
<td class=bc>11 - 6 - 14</td>
<td class=br><strong>28</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Ja Dryák</td><td class=ic>CZE</td><td class=kL>2:7</td>
<td class=kL>5:6</td>
<td class=kW>4:3 K</td>
<td class=kL>0:6</td>
<td class=kT>1:1</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kW>5:3</td>
<td class=kL>2:3 K</td>
<td class=kT>3:3 K</td>
<td class=kW>2:1</td>
<td class=kL>1:5 K</td>
<td class=kW>4:1</td>
<td class=kL>4:5</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>6:1 K</td>
<td class=kW>3:1 K</td>
<td class=kL>5:6</td>
<td class=kW>4:0</td>
<td class=kW>4:1 K</td>
<td class=kW>5:0 K</td>
<td class=br>82:97</td><td class=br>-15</td>
<td class=bc>11 - 5 - 15</td>
<td class=br><strong>27</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Ar Zaharovs</td><td class=ic>LAT</td><td class=kL>1:3 K</td>
<td class=kL>4:6</td>
<td class=kL>2:4</td>
<td class=kL>2:7</td>
<td class=kT>2:2 K</td>
<td class=kL>1:7</td>
<td class=kL>1:2 K</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>0:4 K</td>
<td class=kL>0:2</td>
<td class=kW>2:1 K</td>
<td class=kW>3:1 K</td>
<td class=kL>1:6</td>
<td class=kL>0:2 K</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kL>2:5</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kW>5:0 K</td>
<td class=br>63:79</td><td class=br>-16</td>
<td class=bc>10 - 5 - 16</td>
<td class=br><strong>25</strong></td><td class=d>24.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>25.</td><td class=kt>Pa Plešák</td><td class=ic>CZE</td><td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kL>0:3</td>
<td class=kL>0:5 K</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kW>4:0 K</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>0:3</td>
<td class=kT>2:2 K</td>
<td class=kL>4:6</td>
<td class=kT>2:2</td>
<td class=kW>1:0 K</td>
<td class=kL>2:5</td>
<td class=kW>5:3</td>
<td class=kT>2:2 K</td>
<td class=kL>2:3</td>
<td class=kW>3:2 K</td>
<td class=kW>7:3 K</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>8:7</td>
<td class=kL>2:5</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0 K</td>
<td class=br>80:99</td><td class=br>-19</td>
<td class=bc>10 - 5 - 16</td>
<td class=br><strong>25</strong></td><td class=d>25.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>26.</td><td class=kt>Ye Levdansky</td><td class=ic>UKR</td><td class=kL>3:4</td>
<td class=kL>2:3 K</td>
<td class=kL>1:7</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kT>3:3 K</td>
<td class=kT>3:3</td>
<td class=kL>0:3 K</td>
<td class=kL>2:3</td>
<td class=kL>0:3 K</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kL>4:6</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1 K</td>
<td class=kW>6:1 K</td>
<td class=kW>7:1</td>
<td class=kW>5:0 K</td>
<td class=br>83:83</td><td class=br>0</td>
<td class=bc>10 - 4 - 17</td>
<td class=br><strong>24</strong></td><td class=d>26.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>27.</td><td class=kt>Gi Lasmanis</td><td class=ic>LAT</td><td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>4:8 K</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kL>1:11 K</td>
<td class=kL>2:3 K</td>
<td class=kL>2:6</td>
<td class=kW>3:2 K</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>1:6 K</td>
<td class=kL>1:4</td>
<td class=kL>7:8</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>4:5 K</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>3:0 K</td>
<td class=kW>5:0 K</td>
<td class=br>74:105</td><td class=br>-31</td>
<td class=bc>10 - 3 - 18</td>
<td class=br><strong>23</strong></td><td class=d>27.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>28.</td><td class=kt>Bj Axelsen</td><td class=ic>DEN</td><td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kW>5:4 K</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kL>3:6 K</td>
<td class=kL>2:7 K</td>
<td class=kL>0:2</td>
<td class=kW>3:2 K</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kL>2:6</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kL>1:3 K</td>
<td class=kL>1:6</td>
<td class=kW>5:2</td>
<td class=kL>1:4</td>
<td class=kW>5:4 K</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kL>1:4 K</td>
<td class=kW>5:0 K</td>
<td class=br>75:117</td><td class=br>-42</td>
<td class=bc>9 - 4 - 18</td>
<td class=br><strong>22</strong></td><td class=d>28.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>29.</td><td class=kt>Ve Huotelin</td><td class=ic>FIN</td><td class=kL>1:7</td>
<td class=kL>3:4 K</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kW>4:1</td>
<td class=kL>2:4 K</td>
<td class=kW>6:4</td>
<td class=kT>4:4 K</td>
<td class=kL>1:5</td>
<td class=kT>3:3 K</td>
<td class=kL>3:6</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kW>5:4</td>
<td class=kT>4:4</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>5:6</td>
<td class=kW>5:4</td>
<td class=kL>1:6</td>
<td class=kW>6:5</td>
<td class=kW>5:2</td>
<td class=kL>1:6</td>
<td class=kL>1:3 K</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>2:4 K</td>
<td class=kW>3:1</td>
<td class=kW>5:0 K</td>
<td class=br>79:119</td><td class=br>-40</td>
<td class=bc>8 - 3 - 20</td>
<td class=br><strong>19</strong></td><td class=d>29.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>30.</td><td class=kt>Da Matýsek</td><td class=ic>CZE</td><td class=kL>0:6</td>
<td class=kT>3:3 K</td>
<td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kL>0:4</td>
<td class=kT>1:1 K</td>
<td class=kL>3:6</td>
<td class=kL>1:6 K</td>
<td class=kL>3:4</td>
<td class=kL>1:6 K</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kL>1:6 K</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>4:2 K</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>5:0 K</td>
<td class=br>52:105</td><td class=br>-53</td>
<td class=bc>5 - 6 - 20</td>
<td class=br><strong>16</strong></td><td class=d>30.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>31.</td><td class=kt>Be Rjavec</td><td class=ic>SLO</td><td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>3:4 K</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kL>2:7</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kL>1:2 K</td>
<td class=kT>2:2 K</td>
<td class=kL>1:4</td>
<td class=kW>2:1 K</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>1:4 K</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>1:7</td>
<td class=kL>0:3 K</td>
<td class=kW>4:1 K</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>5:0 K</td>
<td class=br>44:91</td><td class=br>-47</td>
<td class=bc>6 - 3 - 22</td>
<td class=br><strong>15</strong></td><td class=d>31.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>32.</td><td class=kt>Je Lvov</td><td class=ic>EST</td><td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kx>*</td>
<td class=br>0:155</td><td class=br>-155</td>
<td class=bc>0 - 0 - 31</td>
<td class=br><strong>0</strong></td><td class=d>32.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Jo Lundin</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Se Ivanov</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ja Dryák</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Ro Ignatenko</td><td class=bc>-</td><td class=bl>Mi Hvižď</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Je Lvov</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Yn Aasheim</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ve Gerasimov</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kr Iso-Tryykari</td><td class=bc>-</td><td class=bl>Ri Sjöstedt</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Os Henriksson</td><td class=bc>-</td><td class=bl>An Vuononsola</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=blW>Ye Levdansky</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=blW>Ed Saulitis</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=blW>At Silis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=blW>Ha Österman</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Mi Hvižď</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Se Ivanov</td><td class=bc>-</td><td class=bl>Je Lvov</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Yn Aasheim</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ja Dryák</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ro Ignatenko</td><td class=bc>-</td><td class=bl>Ri Sjöstedt</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>An Vuononsola</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Dm Litvinyuk</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ve Gerasimov</td><td class=bc>-</td><td class=bl>Ye Levdansky</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Kr Iso-Tryykari</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Os Henriksson</td><td class=bc>-</td><td class=blW>Ed Saulitis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=blW>At Silis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=blW>Ha Österman</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Jo Lundin</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Je Lvov</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=blW>Yn Aasheim</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Borisov</td><td class=bc>-</td><td class=blW>Ri Sjöstedt</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Se Ivanov</td><td class=bc>-</td><td class=blW>An Vuononsola</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ja Dryák</td><td class=bc>-</td><td class=bl>Ye Levdansky</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Ignatenko</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fi Hamáček</td><td class=bc>-</td><td class=bl>Ed Saulitis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>At Silis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ve Gerasimov</td><td class=bc>-</td><td class=blW>Ha Österman</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Kr Iso-Tryykari</td><td class=bc>-</td><td class=bl>Jo Lundin</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=blW>Yn Aasheim</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Ni Zholobov</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Ri Sjöstedt</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>An Vuononsola</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=blW>Ye Levdansky</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma Borisov</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Se Ivanov</td><td class=bc>-</td><td class=bl>Ed Saulitis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>My Spivakovskyy</td><td class=bc>-</td><td class=blW>At Silis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Dryák</td><td class=bc>-</td><td class=blW>Ha Österman</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Ro Ignatenko</td><td class=bc>-</td><td class=blW>Jo Lundin</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ve Gerasimov</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kr Iso-Tryykari</td><td class=bc>-</td><td class=bl>Mi Hvižď</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Je Lvov</td><td class=bc>5 : 0 K</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Kr Iso-Tryykari</td><td class=bc>-</td><td class=bl>Yn Aasheim</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Os Henriksson</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=blW>Ri Sjöstedt</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=blW>An Vuononsola</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=blW>Ye Levdansky</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>An Ekestubbe</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=bl>Ed Saulitis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>At Silis</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Se Ivanov</td><td class=bc>-</td><td class=blW>Ha Österman</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Jo Lundin</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ro Ignatenko</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Mi Hvižď</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ve Gerasimov</td><td class=bc>-</td><td class=bl>Je Lvov</td><td class=bc>5 : 0 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Ri Sjöstedt</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Je Lvov</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Kr Iso-Tryykari</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Ni Zholobov</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=blW>An Vuononsola</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>At Silis</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Se Ivanov</td><td class=bc>-</td><td class=bl>Ye Levdansky</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Jo Lundin</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Ed Saulitis</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Fi Hamáček</td><td class=bc>-</td><td class=blW>Ha Österman</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Mi Hvižď</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ve Gerasimov</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ro Ignatenko</td><td class=bc>-</td><td class=bl>Yn Aasheim</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ro Ignatenko</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Fi Hamáček</td><td class=bc>-</td><td class=bl>Ni Zholobov</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>An Ekestubbe</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ve Gerasimov</td><td class=bc>-</td><td class=bl>An Vuononsola</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Kr Iso-Tryykari</td><td class=bc>-</td><td class=blW>At Silis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Os Henriksson</td><td class=bc>-</td><td class=blW>Ye Levdansky</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=bl>Jo Lundin</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Ed Saulitis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=blW>Ha Österman</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=blW>Mi Hvižď</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Yn Aasheim</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Se Ivanov</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Ri Sjöstedt</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Je Lvov</td><td class=bc>5 : 0 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>My Spivakovskyy</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ja Dryák</td><td class=bc>-</td><td class=blW>An Vuononsola</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ro Ignatenko</td><td class=bc>-</td><td class=bl>At Silis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Fi Hamáček</td><td class=bc>-</td><td class=bl>Ye Levdansky</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Jo Lundin</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ve Gerasimov</td><td class=bc>-</td><td class=blW>Ed Saulitis</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Kr Iso-Tryykari</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Os Henriksson</td><td class=bc>-</td><td class=bl>Ha Österman</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Mi Hvižď</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Gi Lasmanis</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>Yn Aasheim</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ri Sjöstedt</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Je Lvov</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Se Ivanov</td><td class=bc>-</td><td class=bl>Ni Zholobov</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>At Silis</td><td class=bc>-</td><td class=bl>Ha Österman</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>An Ekestubbe</td><td class=bc>-</td><td class=blW>Ed Saulitis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ye Levdansky</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ri Sjöstedt</td><td class=bc>-</td><td class=blW>An Vuononsola</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Yn Aasheim</td><td class=bc>-</td><td class=bl>Ni Zholobov</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Je Lvov</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Jo Lundin</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Borisov</td><td class=bc>-</td><td class=blW>Se Ivanov</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>My Spivakovskyy</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ro Ignatenko</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Ve Gerasimov</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Iso-Tryykari</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Jo Lundin</td><td class=bc>-</td><td class=bl>Ed Saulitis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>At Silis</td><td class=bc>-</td><td class=bl>Ye Levdansky</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>An Vuononsola</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ni Zholobov</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Je Lvov</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Yn Aasheim</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ha Österman</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Fi Hamáček</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>My Spivakovskyy</td><td class=bc>-</td><td class=blW>Ve Gerasimov</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ro Ignatenko</td><td class=bc>-</td><td class=bl>Os Henriksson</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kr Iso-Tryykari</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Se Ivanov</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Ye Levdansky</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Jo Lundin</td><td class=bc>-</td><td class=blW>An Vuononsola</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>At Silis</td><td class=bc>-</td><td class=bl>Ni Zholobov</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Je Lvov</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Yn Aasheim</td><td class=bc>-</td><td class=blW>Ha Österman</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=bl>Ed Saulitis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=blW>Ve Gerasimov</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Borisov</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ro Ignatenko</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Dm Litvinyuk</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kr Iso-Tryykari</td><td class=bc>-</td><td class=bl>Se Ivanov</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>An Vuononsola</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Jo Lundin</td><td class=bc>-</td><td class=bl>Je Lvov</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>At Silis</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ha Österman</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Ed Saulitis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Yn Aasheim</td><td class=bc>-</td><td class=blW>Ye Levdansky</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=blW>Ve Gerasimov</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Os Henriksson</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ro Ignatenko</td><td class=bc>-</td><td class=bl>Se Ivanov</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr Iso-Tryykari</td><td class=bc>-</td><td class=bl>Fi Hamáček</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Yn Aasheim</td><td class=bc>-</td><td class=blW>An Vuononsola</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Je Lvov</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Jo Lundin</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>At Silis</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>An Ekestubbe</td><td class=bc>-</td><td class=blW>Ha Österman</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Ed Saulitis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Ye Levdansky</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Iso-Tryykari</td><td class=bc>-</td><td class=blW>Ve Gerasimov</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Se Ivanov</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ro Ignatenko</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Dm Litvinyuk</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ri Sjöstedt</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Yn Aasheim</td><td class=bc>-</td><td class=bl>Je Lvov</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Jo Lundin</td><td class=bc>-</td><td class=bl>Ha Österman</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>At Silis</td><td class=bc>-</td><td class=bl>Ed Saulitis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Ye Levdansky</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>An Vuononsola</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Os Henriksson</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kr Iso-Tryykari</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=blW>Se Ivanov</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Fi Hamáček</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ro Ignatenko</td><td class=bc>-</td><td class=blW>Ve Gerasimov</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Je Lvov</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>Ri Sjöstedt</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Yn Aasheim</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=bl>Ha Österman</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ed Saulitis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Jo Lundin</td><td class=bc>-</td><td class=bl>Ye Levdansky</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>At Silis</td><td class=bc>-</td><td class=blW>An Vuononsola</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>An Ekestubbe</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ro Ignatenko</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kr Iso-Tryykari</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Se Ivanov</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Fi Hamáček</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Ve Gerasimov</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>My Spivakovskyy</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Ha Österman</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Yn Aasheim</td><td class=bc>-</td><td class=blW>Ed Saulitis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=blW>Ye Levdansky</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>An Vuononsola</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Jo Lundin</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>At Silis</td><td class=bc>-</td><td class=bl>Je Lvov</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>An Ekestubbe</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Se Ivanov</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kr Iso-Tryykari</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Fi Hamáček</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>Ve Gerasimov</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ro Ignatenko</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>At Silis</td><td class=bc>-</td><td class=bl>Se Ivanov</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ha Österman</td><td class=bc>-</td><td class=blW>Ma Borisov</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ed Saulitis</td><td class=bc>-</td><td class=bl>My Spivakovskyy</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Fi Hamáček</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ye Levdansky</td><td class=bc>-</td><td class=bl>Ro Ignatenko</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Ve Gerasimov</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>An Vuononsola</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Yn Aasheim</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ni Zholobov</td><td class=bc>-</td><td class=bl>Kr Iso-Tryykari</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Je Lvov</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Jo Lundin</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Jo Lundin</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>My Spivakovskyy</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>At Silis</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ha Österman</td><td class=bc>-</td><td class=blW>Ro Ignatenko</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>An Ekestubbe</td><td class=bc>-</td><td class=blW>Ve Gerasimov</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ed Saulitis</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Os Henriksson</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ye Levdansky</td><td class=bc>-</td><td class=blW>Kr Iso-Tryykari</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>An Vuononsola</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Yn Aasheim</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ni Zholobov</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Je Lvov</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Se Ivanov</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>Ma Borisov</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ro Ignatenko</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Jo Lundin</td><td class=bc>-</td><td class=bl>Ve Gerasimov</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>At Silis</td><td class=bc>-</td><td class=bl>Os Henriksson</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ha Österman</td><td class=bc>-</td><td class=bl>Kr Iso-Tryykari</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>An Ekestubbe</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ed Saulitis</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ye Levdansky</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ri Sjöstedt</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>An Vuononsola</td><td class=bc>-</td><td class=bl>Zd Matoušek ml.</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Yn Aasheim</td><td class=bc>-</td><td class=blW>Se Ivanov</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ni Zholobov</td><td class=bc>-</td><td class=blW>Ma Borisov</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Je Lvov</td><td class=bc>-</td><td class=blW>My Spivakovskyy</td><td class=bc>0 : 5 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=blW>Ve Gerasimov</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Je Lvov</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>Kr Iso-Tryykari</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Jo Lundin</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>At Silis</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ha Österman</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>An Ekestubbe</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ed Saulitis</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Se Ivanov</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ye Levdansky</td><td class=bc>-</td><td class=blW>Ma Borisov</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>An Vuononsola</td><td class=bc>-</td><td class=bl>My Spivakovskyy</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Yn Aasheim</td><td class=bc>-</td><td class=bl>Fi Hamáček</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ni Zholobov</td><td class=bc>-</td><td class=bl>Ro Ignatenko</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Yn Aasheim</td><td class=bc>-</td><td class=blW>Ve Gerasimov</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ni Zholobov</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=bl>Os Henriksson</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Je Lvov</td><td class=bc>-</td><td class=blW>Kr Iso-Tryykari</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>8 : 7</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Jo Lundin</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>At Silis</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ha Österman</td><td class=bc>-</td><td class=bl>Zd Matoušek ml.</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>An Ekestubbe</td><td class=bc>-</td><td class=blW>Se Ivanov</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ed Saulitis</td><td class=bc>-</td><td class=blW>Ma Borisov</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ye Levdansky</td><td class=bc>-</td><td class=blW>My Spivakovskyy</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ri Sjöstedt</td><td class=bc>-</td><td class=blW>Fi Hamáček</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Vuononsola</td><td class=bc>-</td><td class=bl>Ro Ignatenko</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Ri Sjöstedt</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>An Vuononsola</td><td class=bc>-</td><td class=bl>Kr Iso-Tryykari</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Yn Aasheim</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ni Zholobov</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Je Lvov</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Jo Lundin</td><td class=bc>-</td><td class=bl>Se Ivanov</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ma Borisov</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>At Silis</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ha Österman</td><td class=bc>-</td><td class=bl>My Spivakovskyy</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>An Ekestubbe</td><td class=bc>-</td><td class=bl>Fi Hamáček</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ed Saulitis</td><td class=bc>-</td><td class=bl>Ro Ignatenko</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>Ve Gerasimov</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ye Levdansky</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Gi Lasmanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ye Levdansky</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>An Vuononsola</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Yn Aasheim</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ni Zholobov</td><td class=bc>-</td><td class=bl>Zd Matoušek ml.</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Mi Hvižď</td><td class=bc>-</td><td class=bl>Se Ivanov</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Je Lvov</td><td class=bc>-</td><td class=blW>Ma Borisov</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>My Spivakovskyy</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Jo Lundin</td><td class=bc>-</td><td class=bl>Fi Hamáček</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ro Ignatenko</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>At Silis</td><td class=bc>-</td><td class=blW>Ve Gerasimov</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ha Österman</td><td class=bc>-</td><td class=bl>Dm Litvinyuk</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>An Ekestubbe</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ed Saulitis</td><td class=bc>-</td><td class=bl>Kr Iso-Tryykari</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>An Ekestubbe</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ed Saulitis</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ye Levdansky</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ri Sjöstedt</td><td class=bc>-</td><td class=blW>Se Ivanov</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>An Vuononsola</td><td class=bc>-</td><td class=blW>Ma Borisov</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Yn Aasheim</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ni Zholobov</td><td class=bc>-</td><td class=bl>My Spivakovskyy</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Hvižď</td><td class=bc>-</td><td class=bl>Fi Hamáček</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Je Lvov</td><td class=bc>-</td><td class=blW>Ro Ignatenko</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ve Gerasimov</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Dm Litvinyuk</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Jo Lundin</td><td class=bc>-</td><td class=bl>Os Henriksson</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Kr Iso-Tryykari</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>At Silis</td><td class=bc>-</td><td class=blW>Gi Lasmanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ha Österman</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>3 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
