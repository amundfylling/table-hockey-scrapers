<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Open </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group E</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt>Zy Remeika</td><td class=ic>LTU</td><td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>8:1</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>8:1</td>
<td class=kW>10:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0 K</td>
<td class=br>49:10</td><td class=br>+39</td>
<td class=bc>8 - 1 - 0</td>
<td class=br><strong>17</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt>An Petrik</td><td class=ic>LTU</td><td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kL>1:5</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>5:0 K</td>
<td class=br>29:12</td><td class=br>+17</td>
<td class=bc>7 - 1 - 1</td>
<td class=br><strong>15</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt>Fi Kalinouski</td><td class=ic>BLR</td><td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>5:0 K</td>
<td class=br>32:11</td><td class=br>+21</td>
<td class=bc>7 - 0 - 2</td>
<td class=br><strong>14</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/2</td><td class=d>4.</td><td class=kt>Se Rafferty</td><td class=ic>USA</td><td class=kL>1:8</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0 K</td>
<td class=br>22:21</td><td class=br>+1</td>
<td class=bc>5 - 0 - 4</td>
<td class=br><strong>10</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Má Papp</td><td class=ic>HUN</td><td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kL>1:4</td>
<td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kW>5:0 K</td>
<td class=br>24:21</td><td class=br>+3</td>
<td class=bc>5 - 0 - 4</td>
<td class=br><strong>10</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Ma Pikat</td><td class=ic>EST</td><td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0 K</td>
<td class=br>14:17</td><td class=br>-3</td>
<td class=bc>4 - 0 - 5</td>
<td class=br><strong>8</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Si Culic</td><td class=ic>SRB</td><td class=kL>1:8</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>5:0 K</td>
<td class=br>18:24</td><td class=br>-6</td>
<td class=bc>3 - 1 - 5</td>
<td class=br><strong>7</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ni Cornelius</td><td class=ic>CHI</td><td class=kL>1:10</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:0 K</td>
<td class=br>17:29</td><td class=br>-12</td>
<td class=bc>2 - 1 - 6</td>
<td class=br><strong>5</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Dz Kalinouski</td><td class=ic>BLR</td><td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:0 K</td>
<td class=br>13:28</td><td class=br>-15</td>
<td class=bc>2 - 0 - 7</td>
<td class=br><strong>4</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ad Sowa</td><td class=ic>POL</td><td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kL>0:5 K</td>
<td class=kx>*</td>
<td class=br>0:45</td><td class=br>-45</td>
<td class=bc>0 - 0 - 9</td>
<td class=br><strong>0</strong></td><td class=d>10.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=blW>Fi Kalinouski</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>An Petrik</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Se Rafferty</td><td class=bc>-</td><td class=blW>Ma Pikat</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ad Sowa</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Fi Kalinouski</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Má Papp</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>An Petrik</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Se Rafferty</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ad Sowa</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Si Culic</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>An Petrik</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Se Rafferty</td><td class=bc>-</td><td class=bl>Ad Sowa</td><td class=bc>5 : 0 K</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Má Papp</td><td class=bc>-</td><td class=bl>Ad Sowa</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>An Petrik</td><td class=bc>-</td><td class=bl>Se Rafferty</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Si Culic</td><td class=bc>-</td><td class=bl>Ad Sowa</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=brW>Fi Kalinouski</td><td class=bc>-</td><td class=bl>Se Rafferty</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Má Papp</td><td class=bc>-</td><td class=bl>An Petrik</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Ad Sowa</td><td class=bc>5 : 0 K</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Se Rafferty</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>An Petrik</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Má Papp</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Se Rafferty</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=bl>An Petrik</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=blW>Fi Kalinouski</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ad Sowa</td><td class=bc>-</td><td class=blW>An Petrik</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Pikat</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Se Rafferty</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ad Sowa</td><td class=bc>-</td><td class=blW>Fi Kalinouski</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Ma Pikat</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>An Petrik</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Se Rafferty</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ad Sowa</td><td class=bc>-</td><td class=blW>Ma Pikat</td><td class=bc>0 : 5 K</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
