<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Team Veterans</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Team Veterans </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group VT3</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Czech Republic V</td><td class=kx>*</td>
<td class=kW><a href="t_312_1690_1692.aspx">7:1</a></td>
<td class=kW><a href="t_312_1690_1701.aspx">8:1</a></td>
<td class=kW><a href="t_312_1690_1696.aspx">8:1</a></td>
<td class=br>23:3</td><td class=br>+20</td>
<td class=bc>3 - 0 - 0</td>
<td class=br><strong>6</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Finland V</td><td class=kL><a href="t_312_1690_1692.aspx">1:7</a></td>
<td class=kx>*</td>
<td class=kW><a href="t_312_1692_1701.aspx">7:1</a></td>
<td class=kW><a href="t_312_1692_1696.aspx">6:3</a></td>
<td class=br>14:11</td><td class=br>+3</td>
<td class=bc>2 - 0 - 1</td>
<td class=br><strong>4</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>B</td><td class=d>3.</td><td class=kt>Switzerland V</td><td class=kL><a href="t_312_1690_1701.aspx">1:8</a></td>
<td class=kL><a href="t_312_1692_1701.aspx">1:7</a></td>
<td class=kx>*</td>
<td class=kW><a href="t_312_1696_1701.aspx">2:0</a></td>
<td class=br>4:15</td><td class=br>-11</td>
<td class=bc>1 - 0 - 2</td>
<td class=br><strong>2</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>B</td><td class=d>4.</td><td class=kt>Lithuania V</td><td class=kL><a href="t_312_1690_1696.aspx">1:8</a></td>
<td class=kL><a href="t_312_1692_1696.aspx">3:6</a></td>
<td class=kL><a href="t_312_1696_1701.aspx">0:2</a></td>
<td class=kx>*</td>
<td class=br>4:16</td><td class=br>-12</td>
<td class=bc>0 - 0 - 3</td>
<td class=br><strong>0</strong></td><td class=d>4.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Czech Republic V</td><td class=bc>-</td><td class=bl>Lithuania V</td><td class=bc><a href="t_312_1690_1696.aspx">8 : 1</a></tr></td>
<tr><td class=brW>Finland V</td><td class=bc>-</td><td class=bl>Switzerland V</td><td class=bc><a href="t_312_1692_1701.aspx">7 : 1</a></tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Czech Republic V</td><td class=bc>-</td><td class=bl>Finland V</td><td class=bc><a href="t_312_1690_1692.aspx">7 : 1</a></tr></td>
<tr><td class=brW>Switzerland V</td><td class=bc>-</td><td class=bl>Lithuania V</td><td class=bc><a href="t_312_1696_1701.aspx">2 : 0</a></tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Finland V</td><td class=bc>-</td><td class=bl>Lithuania V</td><td class=bc><a href="t_312_1692_1696.aspx">6 : 3</a></tr></td>
<tr><td class=brW>Czech Republic V</td><td class=bc>-</td><td class=bl>Switzerland V</td><td class=bc><a href="t_312_1690_1701.aspx">8 : 1</a></tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
