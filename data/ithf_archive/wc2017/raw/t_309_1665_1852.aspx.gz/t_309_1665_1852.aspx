<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Team Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Team Open : Ukraine &nbsp;&nbsp;vs.&nbsp;&nbsp;Belarus &nbsp;&nbsp;22:1</span></h2></div></div></div></div><h3 align="right">Round: 1&nbsp;&nbsp;</h3>
<p><div align="center">
<table border=1 cellpadding="0" cellspacing="0" ><tr>
<table border="0" cellpadding="1" cellspacing="0" width="95%"><tr><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Oleksii Korabel<br>4-1-0 (24:10)</td></tr>
<tr><td class="k">Mykhaylo Spivakovskyy<br>3-0-0 (16:3)</td></tr>
<tr><td class="k">Yevhen Levdansky<br>4-1-0 (26:6)</td></tr>
<tr><td class="k">Vitaliy Sapozhnikov<br>3-0-0 (11:5)</td></tr>
<tr><td class="k">Mykhaylo Shalomayev<br>5-0-0 (24:7)</td></tr>
<tr><td class="k">Igor Zaporojets<br>1-0-1 (7:5)</td></tr>
<tr><td class="k">Roman Ignatenko<br>2-0-0 (13:1)</td></tr>
</table></td>
<td valign="top"><table border="0" cellspacing="0" cellpadding="0" width="100%"><tr><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 1</td></tr>
<tr><td class="hrac_sk_v">Oleksii Korabel</td><td class="vysledek" width="60">&nbsp; 7 : 3 &nbsp;</td><td class="hrac_sk">Andrei Kniaziuk</td></tr>
<tr><td class="hrac_sk_v">Mykhaylo Spivakovskyy</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">Aliaksandr Bartosh</td></tr>
<tr><td class="hrac_sk_v">Yevhen Levdansky</td><td class="vysledek" width="60">&nbsp; 3 : 0 &nbsp;</td><td class="hrac_sk">Aliaksandr Dalgou</td></tr>
<tr><td class="hrac_sk_v">Vitaliy Sapozhnikov</td><td class="vysledek" width="60">&nbsp; 3 : 1 &nbsp;</td><td class="hrac_sk">Siarhei Vazhnik</td></tr>
<tr><td class="hrac_sk_v">Mykhaylo Shalomayev</td><td class="vysledek" width="60">&nbsp; 4 : 2 &nbsp;</td><td class="hrac_sk">Eduard Kuratnik</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;5:0</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 2</td></tr>
<tr><td class="hrac_sk_v">Mykhaylo Shalomayev</td><td class="vysledek" width="60">&nbsp; 5 : 2 &nbsp;</td><td class="hrac_sk">Aliaksandr Bartosh</td></tr>
<tr><td class="hrac_sk">Oleksii Korabel</td><td class="vysledek" width="60">&nbsp; 2 : 2 &nbsp;</td><td class="hrac_sk">Aliaksandr Dalgou</td></tr>
<tr><td class="hrac_sk_v">Mykhaylo Spivakovskyy</td><td class="vysledek" width="60">&nbsp; 6 : 0 &nbsp;</td><td class="hrac_sk">Siarhei Vazhnik</td></tr>
<tr><td class="hrac_sk_v">Yevhen Levdansky</td><td class="vysledek" width="60">&nbsp; 5 : 0 &nbsp;</td><td class="hrac_sk">Eduard Kuratnik</td></tr>
<tr><td class="hrac_sk_v">Vitaliy Sapozhnikov</td><td class="vysledek" width="60">&nbsp; 4 : 3 &nbsp;</td><td class="hrac_sk">Andrei Kniaziuk</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;9:0</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td>
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 3</td></tr>
<tr><td class="hrac_sk_v">Vitaliy Sapozhnikov</td><td class="vysledek" width="60">&nbsp; 4 : 1 &nbsp;</td><td class="hrac_sk">Aliaksandr Dalgou</td></tr>
<tr><td class="hrac_sk_v">Mykhaylo Shalomayev</td><td class="vysledek" width="60">&nbsp; 8 : 2 &nbsp;</td><td class="hrac_sk">Siarhei Vazhnik</td></tr>
<tr><td class="hrac_sk_v">Oleksii Korabel</td><td class="vysledek" width="60">&nbsp; 5 : 1 &nbsp;</td><td class="hrac_sk">Eduard Kuratnik</td></tr>
<tr><td class="hrac_sk_v">Mykhaylo Spivakovskyy</td><td class="vysledek" width="60">&nbsp; 6 : 2 &nbsp;</td><td class="hrac_sk">Andrei Kniaziuk</td></tr>
<tr><td class="hrac_sk">Yevhen Levdansky</td><td class="vysledek" width="60">&nbsp; 3 : 3 &nbsp;</td><td class="hrac_sk">Aliaksandr Bartosh</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;13:0</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 4</td></tr>
<tr><td class="hrac_sk_v">Yevhen Levdansky</td><td class="vysledek" width="60">&nbsp; 10 : 1 &nbsp;</td><td class="hrac_sk">Siarhei Vazhnik</td></tr>
<tr><td class="hrac_sk_v">Igor Zaporojets</td><td class="vysledek" width="60">&nbsp; 5 : 2 &nbsp;</td><td class="hrac_sk">Eduard Kuratnik</td></tr>
<tr><td class="hrac_sk_v">Mykhaylo Shalomayev</td><td class="vysledek" width="60">&nbsp; 3 : 1 &nbsp;</td><td class="hrac_sk">Andrei Kniaziuk</td></tr>
<tr><td class="hrac_sk_v">Oleksii Korabel</td><td class="vysledek" width="60">&nbsp; 5 : 3 &nbsp;</td><td class="hrac_sk">Aliaksandr Bartosh</td></tr>
<tr><td class="hrac_sk_v">Roman Ignatenko</td><td class="vysledek" width="60">&nbsp; 8 : 0 &nbsp;</td><td class="hrac_sk">Aliaksandr Dalgou</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;18:0</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td align="center" colspan="3">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 5</td></tr>
<tr><td class="hrac_sk_v">Roman Ignatenko</td><td class="vysledek" width="60">&nbsp; 5 : 1 &nbsp;</td><td class="hrac_sk">Eduard Kuratnik</td></tr>
<tr><td class="hrac_sk_v">Yevhen Levdansky</td><td class="vysledek" width="60">&nbsp; 5 : 2 &nbsp;</td><td class="hrac_sk">Andrei Kniaziuk</td></tr>
<tr><td class="hrac_sk">Igor Zaporojets</td><td class="vysledek" width="60">&nbsp; 2 : 3 &nbsp;</td><td class="hrac_sk_v">Aliaksandr Bartosh</td></tr>
<tr><td class="hrac_sk_v">Mykhaylo Shalomayev</td><td class="vysledek" width="60">&nbsp; 4 : 0 &nbsp;</td><td class="hrac_sk">Aliaksandr Dalgou</td></tr>
<tr><td class="hrac_sk_v">Oleksii Korabel</td><td class="vysledek" width="60">&nbsp; 5 : 1 &nbsp;</td><td class="hrac_sk">Siarhei Vazhnik</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;22:1</td></tr></table>
</td></tr></table></td><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Andrei Kniaziuk<br>0-0-5 (11:25)</td></tr>
<tr><td class="k">Aliaksandr Bartosh<br>1-1-3 (12:19)</td></tr>
<tr><td class="k">Aliaksandr Dalgou<br>0-1-4 (3:21)</td></tr>
<tr><td class="k">Siarhei Vazhnik<br>0-0-5 (5:32)</td></tr>
<tr><td class="k">Eduard Kuratnik<br>0-0-5 (6:24)</td></tr>
</table></td></tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
