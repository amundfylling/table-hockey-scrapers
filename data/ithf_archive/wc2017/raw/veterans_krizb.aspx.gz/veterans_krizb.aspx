<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Veterans</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Veterans Results</span></h2></div></div></div></div><h3 align="right">Basic Groups&nbsp;&nbsp;</h3>
<p><div align="center">
<a href="Veterans_krizF.aspx#final">Final Groups</a><br>
<p class=v>Group V1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>St Lutay</td><td class=ic>RUS</td><td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>8:2</td>
<td class=kW>9:2</td>
<td class=kW>8:2</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=br>56:20</td><td class=br>+36</td>
<td class=bc>10 - 2 - 0</td>
<td class=br><strong>22</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ki Eriksson</td><td class=ic>FIN</td><td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>9:2</td>
<td class=br>41:22</td><td class=br>+19</td>
<td class=bc>7 - 3 - 2</td>
<td class=br><strong>17</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ig Masloboev</td><td class=ic>RUS</td><td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>8:0</td>
<td class=kW>8:2</td>
<td class=br>42:16</td><td class=br>+26</td>
<td class=bc>7 - 3 - 2</td>
<td class=br><strong>17</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Al Chernov</td><td class=ic>RUS</td><td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=br>33:17</td><td class=br>+16</td>
<td class=bc>4 - 8 - 0</td>
<td class=br><strong>16</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Al Titov</td><td class=ic>RUS</td><td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=br>35:26</td><td class=br>+9</td>
<td class=bc>6 - 3 - 3</td>
<td class=br><strong>15</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Si Thomas</td><td class=ic>IRL</td><td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=br>31:26</td><td class=br>+5</td>
<td class=bc>5 - 3 - 4</td>
<td class=br><strong>13</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Ri Sjöstedt</td><td class=ic>SWE</td><td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>8:2</td>
<td class=kW>8:1</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kL>4:5</td>
<td class=kW>5:0</td>
<td class=br>44:30</td><td class=br>+14</td>
<td class=bc>6 - 1 - 5</td>
<td class=br><strong>13</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Ka Hudec</td><td class=ic>SVK</td><td class=kL>2:8</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kL>2:8</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>9:1</td>
<td class=br>38:37</td><td class=br>+1</td>
<td class=bc>6 - 1 - 5</td>
<td class=br><strong>13</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ke Rafferty</td><td class=ic>USA</td><td class=kL>2:9</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>1:8</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kW>4:0</td>
<td class=kT>5:5</td>
<td class=br>28:50</td><td class=br>-22</td>
<td class=bc>2 - 4 - 6</td>
<td class=br><strong>8</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Th Haussknecht</td><td class=ic>GER</td><td class=kL>2:8</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=br>26:42</td><td class=br>-16</td>
<td class=bc>3 - 1 - 8</td>
<td class=br><strong>7</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>Ed Kuratnik</td><td class=ic>BLR</td><td class=kL>1:7</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>0:1</td>
<td class=br>21:40</td><td class=br>-19</td>
<td class=bc>2 - 2 - 8</td>
<td class=br><strong>6</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Ma Curkovic</td><td class=ic>CRO</td><td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>0:8</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kW>5:2</td>
<td class=kW>5:4</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=br>27:56</td><td class=br>-29</td>
<td class=bc>2 - 1 - 9</td>
<td class=br><strong>5</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Si Vazhnik</td><td class=ic>BLR</td><td class=kL>2:5</td>
<td class=kL>2:9</td>
<td class=kL>2:8</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>1:9</td>
<td class=kT>5:5</td>
<td class=kL>1:6</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=br>24:64</td><td class=br>-40</td>
<td class=bc>1 - 2 - 9</td>
<td class=br><strong>4</strong></td><td class=d>13.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ma Curkovic</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ki Eriksson</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Ri Sjöstedt</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Al Chernov</td><td class=bc>-</td><td class=bl>Ig Masloboev</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Curkovic</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Ri Sjöstedt</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ki Eriksson</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Ig Masloboev</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>St Lutay</td><td class=bc>2 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Al Titov</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Ri Sjöstedt</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ma Curkovic</td><td class=bc>-</td><td class=blW>Ke Rafferty</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Ig Masloboev</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ki Eriksson</td><td class=bc>-</td><td class=blW>St Lutay</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Al Chernov</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ri Sjöstedt</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Titov</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Ig Masloboev</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Ma Curkovic</td><td class=bc>-</td><td class=blW>St Lutay</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=bl>Al Chernov</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ki Eriksson</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Ig Masloboev</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Al Titov</td><td class=bc>-</td><td class=blW>St Lutay</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Al Chernov</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ma Curkovic</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ed Kuratnik</td><td class=bc>-</td><td class=blW>Th Haussknecht</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Ig Masloboev</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ri Sjöstedt</td><td class=bc>-</td><td class=blW>St Lutay</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=bl>Al Chernov</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al Titov</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Si Vazhnik</td><td class=bc>-</td><td class=blW>Th Haussknecht</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ma Curkovic</td><td class=bc>-</td><td class=blW>Ki Eriksson</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ig Masloboev</td><td class=bc>-</td><td class=bl>St Lutay</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=bl>Al Chernov</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Al Titov</td><td class=bc>-</td><td class=bl>Ki Eriksson</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Si Vazhnik</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>St Lutay</td><td class=bc>-</td><td class=bl>Al Chernov</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ig Masloboev</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ke Rafferty</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ri Sjöstedt</td><td class=bc>-</td><td class=blW>Ki Eriksson</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Al Titov</td><td class=bc>-</td><td class=bl>Ma Curkovic</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Al Chernov</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>St Lutay</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ig Masloboev</td><td class=bc>-</td><td class=blW>Ki Eriksson</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=blW>Ed Kuratnik</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ri Sjöstedt</td><td class=bc>-</td><td class=blW>Ma Curkovic</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Th Haussknecht</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Al Chernov</td><td class=bc>-</td><td class=bl>Ki Eriksson</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>St Lutay</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ig Masloboev</td><td class=bc>-</td><td class=bl>Ma Curkovic</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ri Sjöstedt</td><td class=bc>-</td><td class=bl>Al Titov</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=bl>Ki Eriksson</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Al Chernov</td><td class=bc>-</td><td class=bl>Ma Curkovic</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>St Lutay</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ig Masloboev</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ke Rafferty</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ki Eriksson</td><td class=bc>-</td><td class=bl>Ed Kuratnik</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Th Haussknecht</td><td class=bc>-</td><td class=bl>Ma Curkovic</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Al Chernov</td><td class=bc>-</td><td class=bl>Al Titov</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>St Lutay</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ig Masloboev</td><td class=bc>-</td><td class=bl>Ri Sjöstedt</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ed Kuratnik</td><td class=bc>-</td><td class=bl>Ma Curkovic</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ki Eriksson</td><td class=bc>-</td><td class=bl>Si Vazhnik</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Th Haussknecht</td><td class=bc>-</td><td class=blW>Al Titov</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Al Chernov</td><td class=bc>-</td><td class=bl>Ri Sjöstedt</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>St Lutay</td><td class=bc>-</td><td class=bl>Ke Rafferty</td><td class=bc>9 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group V2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ja Dryák</td><td class=ic>CZE</td><td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>8:0</td>
<td class=kW>7:3</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=kW>7:1</td>
<td class=kW>7:1</td>
<td class=br>66:20</td><td class=br>+46</td>
<td class=bc>11 - 0 - 1</td>
<td class=br><strong>22</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Jo Lundin</td><td class=ic>SWE</td><td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=br>45:25</td><td class=br>+20</td>
<td class=bc>9 - 1 - 2</td>
<td class=br><strong>19</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Al Žernovojs</td><td class=ic>LAT</td><td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>5:4</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=br>38:27</td><td class=br>+11</td>
<td class=bc>8 - 2 - 2</td>
<td class=br><strong>18</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Kr Curkovic</td><td class=ic>CRO</td><td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>6:3</td>
<td class=kW>10:3</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kW>10:1</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=br>62:29</td><td class=br>+33</td>
<td class=bc>9 - 0 - 3</td>
<td class=br><strong>18</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Se Mihejevs</td><td class=ic>LAT</td><td class=kL>3:7</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>10:0</td>
<td class=kW>5:3</td>
<td class=br>47:37</td><td class=br>+10</td>
<td class=bc>8 - 0 - 4</td>
<td class=br><strong>16</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Pa Plešák</td><td class=ic>CZE</td><td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>8:3</td>
<td class=kW>7:2</td>
<td class=br>43:33</td><td class=br>+10</td>
<td class=bc>6 - 1 - 5</td>
<td class=br><strong>13</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Da Šmíd</td><td class=ic>CZE</td><td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>3:6</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>2:5</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>10:2</td>
<td class=kW>6:5</td>
<td class=br>49:42</td><td class=br>+7</td>
<td class=bc>6 - 0 - 6</td>
<td class=br><strong>12</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Al Lorand st.</td><td class=ic>SVK</td><td class=kL>0:8</td>
<td class=kW>3:2</td>
<td class=kL>4:5</td>
<td class=kL>3:10</td>
<td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=br>33:42</td><td class=br>-9</td>
<td class=bc>6 - 0 - 6</td>
<td class=br><strong>12</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Al Shekarev</td><td class=ic>EST</td><td class=kL>3:7</td>
<td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kL>2:5</td>
<td class=kW>6:2</td>
<td class=br>28:38</td><td class=br>-10</td>
<td class=bc>3 - 1 - 8</td>
<td class=br><strong>7</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Vj Kufrin</td><td class=ic>CRO</td><td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=br>17:34</td><td class=br>-17</td>
<td class=bc>2 - 2 - 8</td>
<td class=br><strong>6</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>Ra Pommerenke</td><td class=ic>GER</td><td class=kL>1:7</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>1:10</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=br>22:51</td><td class=br>-29</td>
<td class=bc>1 - 3 - 8</td>
<td class=br><strong>5</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>An Naszádi</td><td class=ic>HUN</td><td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>0:10</td>
<td class=kL>3:8</td>
<td class=kL>2:10</td>
<td class=kL>1:5</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=br>23:62</td><td class=br>-39</td>
<td class=bc>2 - 1 - 9</td>
<td class=br><strong>5</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>An Kniaziuk</td><td class=ic>BLR</td><td class=kL>1:7</td>
<td class=kL>2:7</td>
<td class=kT>2:2</td>
<td class=kL>2:7</td>
<td class=kL>3:5</td>
<td class=kL>2:7</td>
<td class=kL>5:6</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=br>29:62</td><td class=br>-33</td>
<td class=bc>0 - 3 - 9</td>
<td class=br><strong>3</strong></td><td class=d>13.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Kr Curkovic</td><td class=bc>-</td><td class=blW>Al Žernovojs</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>Al Shekarev</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Jo Lundin</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Al Žernovojs</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kr Curkovic</td><td class=bc>-</td><td class=bl>Al Shekarev</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Vj Kufrin</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Al Shekarev</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Al Žernovojs</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Curkovic</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=blW>Jo Lundin</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Al Shekarev</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Žernovojs</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Curkovic</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Jo Lundin</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>Al Lorand st.</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Pa Plešák</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>An Naszádi</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Al Žernovojs</td><td class=bc>-</td><td class=blW>Jo Lundin</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kr Curkovic</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>10 : 3</tr></td>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Vj Kufrin</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>Jo Lundin</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Al Lorand st.</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Al Žernovojs</td><td class=bc>-</td><td class=bl>Vj Kufrin</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kr Curkovic</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Jo Lundin</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Al Lorand st.</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>Vj Kufrin</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Al Žernovojs</td><td class=bc>-</td><td class=bl>Ja Dryák</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Jo Lundin</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Al Lorand st.</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Pa Plešák</td><td class=bc>-</td><td class=bl>Vj Kufrin</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Kr Curkovic</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Jo Lundin</td><td class=bc>-</td><td class=blW>Al Lorand st.</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Vj Kufrin</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>An Naszádi</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Kr Curkovic</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>Al Žernovojs</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>Vj Kufrin</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Jo Lundin</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Kr Curkovic</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=blW>Al Žernovojs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Jo Lundin</td><td class=bc>-</td><td class=bl>Kr Curkovic</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Al Žernovojs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 10</tr></td>
<tr><td class=br>Pa Plešák</td><td class=bc>-</td><td class=bl>Al Shekarev</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>Ja Dryák</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=blW>Kr Curkovic</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Al Lorand st.</td><td class=bc>-</td><td class=blW>Al Žernovojs</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Jo Lundin</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Al Shekarev</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Ra Pommerenke</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ja Dryák</td><td class=bc>-</td><td class=bl>Kr Curkovic</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=bl>Al Žernovojs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vj Kufrin</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Al Lorand st.</td><td class=bc>-</td><td class=bl>Al Shekarev</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Jo Lundin</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Pa Plešák</td><td class=bc>4 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group V3</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Bj Axelsen</td><td class=ic>DEN</td><td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>2:5</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>7:3</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=br>51:29</td><td class=br>+22</td>
<td class=bc>9 - 2 - 1</td>
<td class=br><strong>20</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Pe Ostlund</td><td class=ic>SWE</td><td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>6:4</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=br>44:25</td><td class=br>+19</td>
<td class=bc>9 - 1 - 2</td>
<td class=br><strong>19</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Es Moe</td><td class=ic>NOR</td><td class=kW>5:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kL>3:5</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kW>8:3</td>
<td class=kW>3:0</td>
<td class=kW>9:0</td>
<td class=br>43:20</td><td class=br>+23</td>
<td class=bc>8 - 1 - 3</td>
<td class=br><strong>17</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Yn Aasheim</td><td class=ic>NOR</td><td class=kL>1:6</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>8:4</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=br>46:32</td><td class=br>+14</td>
<td class=bc>7 - 2 - 3</td>
<td class=br><strong>16</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Da Matýsek</td><td class=ic>CZE</td><td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=br>33:20</td><td class=br>+13</td>
<td class=bc>7 - 2 - 3</td>
<td class=br><strong>16</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Vi Sapozhnikov</td><td class=ic>UKR</td><td class=kT>2:2</td>
<td class=kL>4:6</td>
<td class=kL>0:3</td>
<td class=kW>6:2</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>7:7</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>8:4</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=br>44:31</td><td class=br>+13</td>
<td class=bc>5 - 4 - 3</td>
<td class=br><strong>14</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Vi Henttonen</td><td class=ic>FIN</td><td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=br>35:34</td><td class=br>+1</td>
<td class=bc>6 - 0 - 6</td>
<td class=br><strong>12</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Je Klaus</td><td class=ic>SUI</td><td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kW>5:3</td>
<td class=kL>0:7</td>
<td class=kL>2:4</td>
<td class=kT>7:7</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=br>41:43</td><td class=br>-2</td>
<td class=bc>5 - 1 - 6</td>
<td class=br><strong>11</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Au Pleikys</td><td class=ic>LTU</td><td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=br>24:35</td><td class=br>-11</td>
<td class=bc>3 - 2 - 7</td>
<td class=br><strong>8</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Be Skrlep</td><td class=ic>SLO</td><td class=kL>3:7</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>0:8</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=br>20:44</td><td class=br>-24</td>
<td class=bc>2 - 3 - 7</td>
<td class=br><strong>7</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>Th Cornelius</td><td class=ic>CHI</td><td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>3:8</td>
<td class=kL>4:8</td>
<td class=kL>1:5</td>
<td class=kL>4:8</td>
<td class=kW>4:3</td>
<td class=kL>0:4</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=br>32:57</td><td class=br>-25</td>
<td class=bc>3 - 0 - 9</td>
<td class=br><strong>6</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Fr Bruneske</td><td class=ic>GER</td><td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=br>24:40</td><td class=br>-16</td>
<td class=bc>2 - 1 - 9</td>
<td class=br><strong>5</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Mi Margolis</td><td class=ic>ISR</td><td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>0:9</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=br>18:45</td><td class=br>-27</td>
<td class=bc>1 - 3 - 8</td>
<td class=br><strong>5</strong></td><td class=d>13.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Yn Aasheim</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Bj Axelsen</td><td class=bc>-</td><td class=bl>Vi Sapozhnikov</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fr Bruneske</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>Pe Ostlund</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Es Moe</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Je Klaus</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=bl>Vi Sapozhnikov</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Yn Aasheim</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Pe Ostlund</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Fr Bruneske</td><td class=bc>-</td><td class=blW>Es Moe</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Mi Margolis</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Vi Sapozhnikov</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=blW>Pe Ostlund</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Yn Aasheim</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Fr Bruneske</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>Je Klaus</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=bl>Pe Ostlund</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Vi Sapozhnikov</td><td class=bc>-</td><td class=blW>Es Moe</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Yn Aasheim</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Je Klaus</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Fr Bruneske</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Pe Ostlund</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vi Sapozhnikov</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=blW>Je Klaus</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Yn Aasheim</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Th Cornelius</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Es Moe</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Pe Ostlund</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>Je Klaus</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Vi Sapozhnikov</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Be Skrlep</td><td class=bc>-</td><td class=bl>Th Cornelius</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Yn Aasheim</td><td class=bc>-</td><td class=bl>Fr Bruneske</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Es Moe</td><td class=bc>-</td><td class=blW>Je Klaus</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Pe Ostlund</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Th Cornelius</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Vi Sapozhnikov</td><td class=bc>-</td><td class=bl>Fr Bruneske</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Be Skrlep</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>3 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Je Klaus</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Es Moe</td><td class=bc>-</td><td class=bl>Th Cornelius</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Pe Ostlund</td><td class=bc>-</td><td class=bl>Fr Bruneske</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Au Pleikys</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Vi Sapozhnikov</td><td class=bc>-</td><td class=bl>Yn Aasheim</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Je Klaus</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Th Cornelius</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Fr Bruneske</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Es Moe</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pe Ostlund</td><td class=bc>-</td><td class=blW>Yn Aasheim</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Au Pleikys</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Th Cornelius</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Je Klaus</td><td class=bc>-</td><td class=bl>Fr Bruneske</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=bl>Bj Axelsen</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Yn Aasheim</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Es Moe</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Pe Ostlund</td><td class=bc>-</td><td class=bl>Vi Sapozhnikov</td><td class=bc>6 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>Fr Bruneske</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Je Klaus</td><td class=bc>-</td><td class=blW>Yn Aasheim</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Vi Sapozhnikov</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Es Moe</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Fr Bruneske</td><td class=bc>-</td><td class=blW>Bj Axelsen</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>Yn Aasheim</td><td class=bc>4 : 8</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Be Skrlep</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Je Klaus</td><td class=bc>-</td><td class=bl>Vi Sapozhnikov</td><td class=bc>7 : 7</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Au Pleikys</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Pe Ostlund</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Bj Axelsen</td><td class=bc>-</td><td class=bl>Yn Aasheim</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Fr Bruneske</td><td class=bc>-</td><td class=blW>Be Skrlep</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>Vi Sapozhnikov</td><td class=bc>4 : 8</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Au Pleikys</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Je Klaus</td><td class=bc>-</td><td class=blW>Pe Ostlund</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Es Moe</td><td class=bc>0 : 9</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group V4</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>An Ekestubbe</td><td class=ic>SWE</td><td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=br>53:23</td><td class=br>+30</td>
<td class=bc>9 - 3 - 0</td>
<td class=br><strong>21</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>My Shalomayev</td><td class=ic>UKR</td><td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=br>47:27</td><td class=br>+20</td>
<td class=bc>10 - 0 - 2</td>
<td class=br><strong>20</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ig Saveljev</td><td class=ic>EST</td><td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=br>35:20</td><td class=br>+15</td>
<td class=bc>7 - 2 - 3</td>
<td class=br><strong>16</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Sa Kalninš</td><td class=ic>LAT</td><td class=kL>1:2</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kL>2:4</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=br>35:23</td><td class=br>+12</td>
<td class=bc>7 - 2 - 3</td>
<td class=br><strong>16</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Dm Petrov</td><td class=ic>RUS</td><td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=kL>4:5</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>7:2</td>
<td class=kW>10:1</td>
<td class=br>50:26</td><td class=br>+24</td>
<td class=bc>6 - 3 - 3</td>
<td class=br><strong>15</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ja Sahlgren</td><td class=ic>FIN</td><td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>7:0</td>
<td class=br>27:15</td><td class=br>+12</td>
<td class=bc>6 - 2 - 4</td>
<td class=br><strong>14</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>Ig Zaporojets</td><td class=ic>UKR</td><td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=br>30:30</td><td class=br>0</td>
<td class=bc>5 - 2 - 5</td>
<td class=br><strong>12</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Va Hamdamov</td><td class=ic>EST</td><td class=kT>1:1</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kW>5:4</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=br>29:32</td><td class=br>-3</td>
<td class=bc>4 - 3 - 5</td>
<td class=br><strong>11</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Mi Toft Nielsen</td><td class=ic>DEN</td><td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>4:5</td>
<td class=kL>0:6</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=br>26:39</td><td class=br>-13</td>
<td class=bc>4 - 0 - 8</td>
<td class=br><strong>8</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Jo Estmo</td><td class=ic>SWE</td><td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kW>5:3</td>
<td class=br>23:40</td><td class=br>-17</td>
<td class=bc>3 - 1 - 8</td>
<td class=br><strong>7</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>C</td><td class=d>11.</td><td class=kt>Fr Suma</td><td class=ic>SVK</td><td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>0:2</td>
<td class=kW>4:2</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kL>2:6</td>
<td class=br>23:44</td><td class=br>-21</td>
<td class=bc>3 - 1 - 8</td>
<td class=br><strong>7</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>Vl Voronov</td><td class=ic>LTU</td><td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>2:7</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=br>23:50</td><td class=br>-27</td>
<td class=bc>3 - 0 - 9</td>
<td class=br><strong>6</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ro Locher</td><td class=ic>SUI</td><td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>1:10</td>
<td class=kL>0:7</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kW>6:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=br>25:57</td><td class=br>-32</td>
<td class=bc>1 - 1 - 10</td>
<td class=br><strong>3</strong></td><td class=d>13.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Jo Estmo</td><td class=bc>-</td><td class=blW>Vl Voronov</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Va Hamdamov</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=blW>Fr Suma</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ig Zaporojets</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Jo Estmo</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>Ja Sahlgren</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Mi Toft Nielsen</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ig Zaporojets</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Jo Estmo</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=blW>Ja Sahlgren</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Mi Toft Nielsen</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ig Zaporojets</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Ja Sahlgren</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Jo Estmo</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=bl>Ro Locher</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Vl Voronov</td><td class=bc>-</td><td class=bl>Ja Sahlgren</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>An Ekestubbe</td><td class=bc>-</td><td class=bl>Ro Locher</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Jo Estmo</td><td class=bc>-</td><td class=blW>Sa Kalninš</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=bl>Ja Sahlgren</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Dm Petrov</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Vl Voronov</td><td class=bc>-</td><td class=bl>Ro Locher</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ig Zaporojets</td><td class=bc>-</td><td class=blW>Sa Kalninš</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Ekestubbe</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ja Sahlgren</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=blW>Ro Locher</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Sa Kalninš</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>Va Hamdamov</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ig Zaporojets</td><td class=bc>-</td><td class=bl>Jo Estmo</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Dm Petrov</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ro Locher</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Sa Kalninš</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Fr Suma</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Mi Toft Nielsen</td><td class=bc>-</td><td class=blW>Jo Estmo</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vl Voronov</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Ro Locher</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Sa Kalninš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Jo Estmo</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Fr Suma</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Mi Toft Nielsen</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>Sa Kalninš</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=blW>Va Hamdamov</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Jo Estmo</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=bl>An Ekestubbe</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Fr Suma</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Sa Kalninš</td><td class=bc>-</td><td class=bl>Va Hamdamov</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>Jo Estmo</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Dm Petrov</td><td class=bc>-</td><td class=bl>An Ekestubbe</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Va Hamdamov</td><td class=bc>-</td><td class=bl>Jo Estmo</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Sa Kalninš</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>Ig Zaporojets</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ja Sahlgren</td><td class=bc>-</td><td class=bl>Mi Toft Nielsen</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Jo Estmo</td><td class=bc>-</td><td class=blW>An Ekestubbe</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Va Hamdamov</td><td class=bc>-</td><td class=bl>Ig Zaporojets</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Sa Kalninš</td><td class=bc>-</td><td class=bl>Vl Voronov</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>Mi Toft Nielsen</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Dm Petrov</td><td class=bc>-</td><td class=bl>Fr Suma</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ja Sahlgren</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>0 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</table></div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
