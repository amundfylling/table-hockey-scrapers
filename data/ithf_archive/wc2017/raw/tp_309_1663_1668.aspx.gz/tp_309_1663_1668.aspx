<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Team Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Team Open : Estonia &nbsp;&nbsp;vs.&nbsp;&nbsp;Finland &nbsp;&nbsp;4:14</span></h2></div></div></div></div><h3 align="right">Round: 5th-8th&nbsp;&nbsp;</h3>
<p><div align="center">
<table border=1 cellpadding="0" cellspacing="0" ><tr>
<table border="0" cellpadding="1" cellspacing="0" width="95%"><tr><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Jevgeni Lvov<br>1-0-3 (7:12)</td></tr>
<tr><td class="k">Maria Saveljeva<br>3-1-0 (18:12)</td></tr>
<tr><td class="k">Daniil Moshnin<br>0-0-4 (7:26)</td></tr>
<tr><td class="k">Mark-Julius Pikat<br>0-0-4 (5:18)</td></tr>
<tr><td class="k">Alen Shekarev<br>0-1-3 (6:15)</td></tr>
</table></td>
<td valign="top"><table border="0" cellspacing="0" cellpadding="0" width="100%"><tr><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 1</td></tr>
<tr><td class="hrac_sk">Jevgeni Lvov</td><td class="vysledek" width="60">&nbsp; 2 : 3 &nbsp;</td><td class="hrac_sk_v">Vesa Huotelin</td></tr>
<tr><td class="hrac_sk">Maria Saveljeva</td><td class="vysledek" width="60">&nbsp; 4 : 4 &nbsp;</td><td class="hrac_sk">Antti Vuononsola</td></tr>
<tr><td class="hrac_sk">Daniil Moshnin</td><td class="vysledek" width="60">&nbsp; 2 : 6 &nbsp;</td><td class="hrac_sk_v">Benjamin Suominen</td></tr>
<tr><td class="hrac_sk">Mark-Julius Pikat</td><td class="vysledek" width="60">&nbsp; 2 : 5 &nbsp;</td><td class="hrac_sk_v">Jan Pelkonen</td></tr>
<tr><td class="hrac_sk">Alen Shekarev</td><td class="vysledek" width="60">&nbsp; 1 : 5 &nbsp;</td><td class="hrac_sk_v">Kevin Eriksson</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;0:4</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 2</td></tr>
<tr><td class="hrac_sk">Alen Shekarev</td><td class="vysledek" width="60">&nbsp; 2 : 2 &nbsp;</td><td class="hrac_sk">Antti Vuononsola</td></tr>
<tr><td class="hrac_sk">Jevgeni Lvov</td><td class="vysledek" width="60">&nbsp; 0 : 3 &nbsp;</td><td class="hrac_sk_v">Benjamin Suominen</td></tr>
<tr><td class="hrac_sk_v">Maria Saveljeva</td><td class="vysledek" width="60">&nbsp; 3 : 2 &nbsp;</td><td class="hrac_sk">Jan Pelkonen</td></tr>
<tr><td class="hrac_sk">Daniil Moshnin</td><td class="vysledek" width="60">&nbsp; 2 : 8 &nbsp;</td><td class="hrac_sk_v">Kevin Eriksson</td></tr>
<tr><td class="hrac_sk">Mark-Julius Pikat</td><td class="vysledek" width="60">&nbsp; 0 : 4 &nbsp;</td><td class="hrac_sk_v">Vesa Huotelin</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;1:7</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td>
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 3</td></tr>
<tr><td class="hrac_sk">Mark-Julius Pikat</td><td class="vysledek" width="60">&nbsp; 1 : 3 &nbsp;</td><td class="hrac_sk_v">Benjamin Suominen</td></tr>
<tr><td class="hrac_sk">Alen Shekarev</td><td class="vysledek" width="60">&nbsp; 1 : 4 &nbsp;</td><td class="hrac_sk_v">Jan Pelkonen</td></tr>
<tr><td class="hrac_sk_v">Jevgeni Lvov</td><td class="vysledek" width="60">&nbsp; 4 : 3 &nbsp;</td><td class="hrac_sk">Kevin Eriksson</td></tr>
<tr><td class="hrac_sk_v">Maria Saveljeva</td><td class="vysledek" width="60">&nbsp; 4 : 3 &nbsp;</td><td class="hrac_sk">Vesa Huotelin</td></tr>
<tr><td class="hrac_sk">Daniil Moshnin</td><td class="vysledek" width="60">&nbsp; 2 : 9 &nbsp;</td><td class="hrac_sk_v">Antti Vuononsola</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;3:10</td></tr></table>
</td><td>&nbsp;</td><td width="49%">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 4</td></tr>
<tr><td class="hrac_sk">Daniil Moshnin</td><td class="vysledek" width="60">&nbsp; 1 : 3 &nbsp;</td><td class="hrac_sk_v">Jari Sahlgren</td></tr>
<tr><td class="hrac_sk">Mark-Julius Pikat</td><td class="vysledek" width="60">&nbsp; 2 : 6 &nbsp;</td><td class="hrac_sk_v">Kimmo Eriksson</td></tr>
<tr><td class="hrac_sk">Alen Shekarev</td><td class="vysledek" width="60">&nbsp; 2 : 4 &nbsp;</td><td class="hrac_sk_v">Vesa Huotelin</td></tr>
<tr><td class="hrac_sk">Jevgeni Lvov</td><td class="vysledek" width="60">&nbsp; 1 : 3 &nbsp;</td><td class="hrac_sk_v">Antti Vuononsola</td></tr>
<tr><td class="hrac_sk_v">Maria Saveljeva</td><td class="vysledek" width="60">&nbsp; 7 : 3 &nbsp;</td><td class="hrac_sk">Benjamin Suominen</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;4:14</td></tr></table>
</td></tr><tr><td colspan="3">&nbsp;</td></tr><tr><td align="center" colspan="3">
<table border="1" cellpadding="1" cellspacing="0" width="100%"><tr><td class="c1" colspan="3">Round 5</td></tr>
<tr><td class="hrac_sk">Maria Saveljeva</td><td class="vysledek" width="60">&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;</td><td class="hrac_sk">Kimmo Eriksson</td></tr>
<tr><td class="hrac_sk">Daniil Moshnin</td><td class="vysledek" width="60">&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;</td><td class="hrac_sk">Vesa Huotelin</td></tr>
<tr><td class="hrac_sk">Mark-Julius Pikat</td><td class="vysledek" width="60">&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;</td><td class="hrac_sk">Antti Vuononsola</td></tr>
<tr><td class="hrac_sk">Alen Shekarev</td><td class="vysledek" width="60">&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;</td><td class="hrac_sk">Benjamin Suominen</td></tr>
<tr><td class="hrac_sk">Jevgeni Lvov</td><td class="vysledek" width="60">&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;</td><td class="hrac_sk">Jari Sahlgren</td></tr>
<tr><td class="vysledek" colspan="3">&nbsp;4:14</td></tr></table>
</td></tr></table></td><td valign="top" width="90">
<table border="1" width="100%" cellspacing="0" cellpadding="1">
<tr><td class="k">Vesa Huotelin<br>3-0-1 (14:8)</td></tr>
<tr><td class="k">Antti Vuononsola<br>2-2-0 (18:9)</td></tr>
<tr><td class="k">Benjamin Suominen<br>3-0-1 (15:10)</td></tr>
<tr><td class="k">Jan Pelkonen<br>2-0-1 (11:6)</td></tr>
<tr><td class="k">Kevin Eriksson<br>2-0-1 (16:7)</td></tr>
<tr><td class="k">Jari Sahlgren<br>1-0-0 (3:1)</td></tr>
<tr><td class="k">Kimmo Eriksson<br>1-0-0 (6:2)</td></tr>
</table></td></tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
