<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Open </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 7</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ha Österman</td><td class=ic>SWE</td><td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>9:1</td>
<td class=kW>5:0</td>
<td class=br>66:18</td><td class=br>+48</td>
<td class=bc>15 - 2 - 0</td>
<td class=br><strong>32</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ed Saulitis</td><td class=ic>LAT</td><td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kW>5:4</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=br>53:27</td><td class=br>+26</td>
<td class=bc>13 - 1 - 3</td>
<td class=br><strong>27</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ye Levdansky</td><td class=ic>UKR</td><td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=br>64:24</td><td class=br>+40</td>
<td class=bc>13 - 1 - 3</td>
<td class=br><strong>27</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>An Vuononsola</td><td class=ic>FIN</td><td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>8:1</td>
<td class=kW>9:3</td>
<td class=kW>4:0</td>
<td class=kW>8:1</td>
<td class=kW>10:0</td>
<td class=br>74:33</td><td class=br>+41</td>
<td class=bc>11 - 2 - 4</td>
<td class=br><strong>24</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ni Zholobov</td><td class=ic>RUS</td><td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kT>4:4</td>
<td class=kW>6:1</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=kW>10:2</td>
<td class=kW>5:0</td>
<td class=br>77:36</td><td class=br>+41</td>
<td class=bc>11 - 1 - 5</td>
<td class=br><strong>23</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Je Lvov</td><td class=ic>EST</td><td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>7:5</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>53:37</td><td class=br>+16</td>
<td class=bc>11 - 1 - 5</td>
<td class=br><strong>23</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ve Huotelin</td><td class=ic>FIN</td><td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kL>5:7</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>7:4</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>8:2</td>
<td class=kW>8:1</td>
<td class=kW>6:1</td>
<td class=kW>10:0</td>
<td class=br>80:44</td><td class=br>+36</td>
<td class=bc>10 - 2 - 5</td>
<td class=br><strong>22</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Da Matýsek</td><td class=ic>CZE</td><td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kL>1:6</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>5:0</td>
<td class=br>48:46</td><td class=br>+2</td>
<td class=bc>8 - 4 - 5</td>
<td class=br><strong>20</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ig Saveljev</td><td class=ic>EST</td><td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kW>2:0</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kW>7:0</td>
<td class=kW>13:3</td>
<td class=kW>5:0</td>
<td class=br>52:41</td><td class=br>+11</td>
<td class=bc>8 - 2 - 7</td>
<td class=br><strong>18</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Es Moe</td><td class=ic>NOR</td><td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kL>0:6</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>9:0</td>
<td class=kW>5:0</td>
<td class=br>49:42</td><td class=br>+7</td>
<td class=bc>7 - 4 - 6</td>
<td class=br><strong>18</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Li Restel</td><td class=ic>GER</td><td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>4:7</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kW>7:3</td>
<td class=kW>5:0</td>
<td class=br>44:42</td><td class=br>+2</td>
<td class=bc>6 - 3 - 8</td>
<td class=br><strong>15</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>I  Vépy</td><td class=ic>SVK</td><td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>39:49</td><td class=br>-10</td>
<td class=bc>6 - 1 - 10</td>
<td class=br><strong>13</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Mi Margolis</td><td class=ic>ISR</td><td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>0:7</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>38:53</td><td class=br>-15</td>
<td class=bc>6 - 1 - 10</td>
<td class=br><strong>13</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Al Metelitsa</td><td class=ic>EST</td><td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>0:4</td>
<td class=kL>1:8</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>30:48</td><td class=br>-18</td>
<td class=bc>5 - 2 - 10</td>
<td class=br><strong>12</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>Je Klaus</td><td class=ic>SUI</td><td class=kL>0:4</td>
<td class=kL>4:5</td>
<td class=kL>2:7</td>
<td class=kL>3:9</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kL>2:8</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kW>5:0</td>
<td class=br>43:70</td><td class=br>-27</td>
<td class=bc>4 - 1 - 12</td>
<td class=br><strong>9</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Ra Pommerenke</td><td class=ic>GER</td><td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>1:8</td>
<td class=kL>2:4</td>
<td class=kL>0:7</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=br>19:54</td><td class=br>-35</td>
<td class=bc>3 - 1 - 13</td>
<td class=br><strong>7</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Ol Majaniemi</td><td class=ic>SUI</td><td class=kL>1:9</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>1:8</td>
<td class=kL>2:10</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kT>4:4</td>
<td class=kL>3:13</td>
<td class=kL>0:9</td>
<td class=kL>3:7</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>4:5</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=br>32:102</td><td class=br>-70</td>
<td class=bc>1 - 1 - 15</td>
<td class=br><strong>3</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>E</td><td class=d>18.</td><td class=kt>Ro Locher</td><td class=ic>SUI</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:10</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:10</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=br>0:95</td><td class=br>-95</td>
<td class=bc>0 - 0 - 17</td>
<td class=br><strong>0</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ni Zholobov</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Je Klaus</td><td class=bc>-</td><td class=blW>An Vuononsola</td><td class=bc>3 : 9</tr></td>
<tr><td class=brW>Ye Levdansky</td><td class=bc>-</td><td class=bl>I  Vépy</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Je Lvov</td><td class=bc>-</td><td class=blW>Ed Saulitis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>Li Restel</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Mi Margolis</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Ha Österman</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ni Zholobov</td><td class=bc>-</td><td class=blW>An Vuononsola</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>I  Vépy</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Je Klaus</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ye Levdansky</td><td class=bc>-</td><td class=blW>Ed Saulitis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>Li Restel</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Je Lvov</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>Ha Österman</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Es Moe</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>An Vuononsola</td><td class=bc>-</td><td class=bl>I  Vépy</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ni Zholobov</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ed Saulitis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Je Klaus</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ye Levdansky</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>Ha Österman</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Je Lvov</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>Al Metelitsa</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Vuononsola</td><td class=bc>-</td><td class=blW>Ed Saulitis</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ni Zholobov</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Je Klaus</td><td class=bc>-</td><td class=blW>Ha Österman</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ye Levdansky</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>Al Metelitsa</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Je Lvov</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>Mi Margolis</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ed Saulitis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=blW>Li Restel</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>An Vuononsola</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ni Zholobov</td><td class=bc>-</td><td class=blW>Ha Österman</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Je Klaus</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ye Levdansky</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>Mi Margolis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Je Lvov</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ed Saulitis</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=blW>Ha Österman</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>An Vuononsola</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ni Zholobov</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ve Huotelin</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Je Klaus</td><td class=bc>-</td><td class=blW>Mi Margolis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ye Levdansky</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>Je Lvov</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Li Restel</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ed Saulitis</td><td class=bc>-</td><td class=blW>Ha Österman</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Vuononsola</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ni Zholobov</td><td class=bc>-</td><td class=blW>Mi Margolis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Je Klaus</td><td class=bc>-</td><td class=blW>Je Lvov</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ye Levdansky</td><td class=bc>-</td><td class=bl>Ro Locher</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Ha Österman</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ed Saulitis</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Da Matýsek</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>I  Vépy</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>An Vuononsola</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ni Zholobov</td><td class=bc>-</td><td class=bl>Je Lvov</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Ro Locher</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Je Klaus</td><td class=bc>-</td><td class=blW>Ye Levdansky</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ha Österman</td><td class=bc>-</td><td class=bl>Es Moe</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Al Metelitsa</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Li Restel</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ed Saulitis</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>13 : 3</tr></td>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=blW>Je Lvov</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>An Vuononsola</td><td class=bc>-</td><td class=bl>Ro Locher</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Ni Zholobov</td><td class=bc>-</td><td class=bl>Ye Levdansky</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ve Huotelin</td><td class=bc>-</td><td class=bl>Je Klaus</td><td class=bc>8 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Es Moe</td><td class=bc>-</td><td class=bl>Da Matýsek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ha Österman</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=blW>Je Lvov</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ed Saulitis</td><td class=bc>-</td><td class=bl>Ro Locher</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Ye Levdansky</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>I  Vépy</td><td class=bc>-</td><td class=bl>Je Klaus</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>An Vuononsola</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ni Zholobov</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Al Metelitsa</td><td class=bc>-</td><td class=bl>Mi Margolis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Es Moe</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Ha Österman</td><td class=bc>-</td><td class=bl>Je Lvov</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Ro Locher</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=blW>Ye Levdansky</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ed Saulitis</td><td class=bc>-</td><td class=bl>Je Klaus</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>An Vuononsola</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=bl>Ol Majaniemi</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=blW>Je Lvov</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Es Moe</td><td class=bc>-</td><td class=bl>Ro Locher</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ha Österman</td><td class=bc>-</td><td class=bl>Ye Levdansky</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ra Pommerenke</td><td class=bc>-</td><td class=bl>Je Klaus</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Ed Saulitis</td><td class=bc>-</td><td class=bl>Ni Zholobov</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>An Vuononsola</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>I  Vépy</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Mi Margolis</td><td class=bc>-</td><td class=bl>Je Lvov</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ro Locher</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=blW>Ye Levdansky</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Es Moe</td><td class=bc>-</td><td class=bl>Je Klaus</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ha Österman</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=blW>An Vuononsola</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ed Saulitis</td><td class=bc>-</td><td class=bl>I  Vépy</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ol Majaniemi</td><td class=bc>-</td><td class=bl>Ro Locher</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Ye Levdansky</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Je Klaus</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Es Moe</td><td class=bc>-</td><td class=bl>Ni Zholobov</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ha Österman</td><td class=bc>-</td><td class=bl>An Vuononsola</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>I  Vépy</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ed Saulitis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Je Lvov</td><td class=bc>-</td><td class=blW>Ye Levdansky</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>Je Klaus</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Ve Huotelin</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=blW>An Vuononsola</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Es Moe</td><td class=bc>-</td><td class=bl>I  Vépy</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ha Österman</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=blW>Ed Saulitis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>Je Klaus</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Je Lvov</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>7 : 5</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>2 : 10</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>An Vuononsola</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>I  Vépy</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Al Metelitsa</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Es Moe</td><td class=bc>-</td><td class=bl>Ed Saulitis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ha Österman</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ra Pommerenke</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ye Levdansky</td><td class=bc>-</td><td class=bl>Ve Huotelin</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Je Lvov</td><td class=bc>-</td><td class=bl>An Vuononsola</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>I  Vépy</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Da Matýsek</td><td class=bc>-</td><td class=blW>Ed Saulitis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=blW>Li Restel</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Es Moe</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ha Österman</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Je Klaus</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ye Levdansky</td><td class=bc>-</td><td class=bl>An Vuononsola</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Locher</td><td class=bc>-</td><td class=blW>I  Vépy</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Je Lvov</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ol Majaniemi</td><td class=bc>-</td><td class=blW>Ed Saulitis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Margolis</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Da Matýsek</td><td class=bc>-</td><td class=bl>Ra Pommerenke</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=blW>Ha Österman</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Es Moe</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
