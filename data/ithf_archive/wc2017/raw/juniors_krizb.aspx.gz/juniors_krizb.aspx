<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Juniors</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Juniors Results</span></h2></div></div></div></div><h3 align="right">Basic Groups&nbsp;&nbsp;</h3>
<p><div align="center">
<a href="Juniors_umisteni.aspx">Play-Off</a><br>
<p class=v>Group J1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>J</td><td class=d>1.</td><td class=kt>Ni Zholobov</td><td class=ic>RUS</td><td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kW>6:1</td>
<td class=kW>7:3</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=kW>8:0</td>
<td class=kW>12:1</td>
<td class=kW>5:0</td>
<td class=kW>7:2</td>
<td class=kW>6:3</td>
<td class=kW>9:0</td>
<td class=br>102:19</td><td class=br>+83</td>
<td class=bc>17 - 0 - 0</td>
<td class=br><strong>34</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>J</td><td class=d>2.</td><td class=kt>Mi Kobrle</td><td class=ic>CZE</td><td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kL>2:4</td>
<td class=kW>5:4</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>8:0</td>
<td class=kW>5:2</td>
<td class=kW>7:0</td>
<td class=kW>3:1</td>
<td class=br>75:32</td><td class=br>+43</td>
<td class=bc>14 - 1 - 2</td>
<td class=br><strong>29</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>J</td><td class=d>3.</td><td class=kt>Ol Korabel</td><td class=ic>UKR</td><td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>8:1</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>8:0</td>
<td class=br>72:35</td><td class=br>+37</td>
<td class=bc>14 - 0 - 3</td>
<td class=br><strong>28</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>J</td><td class=d>4.</td><td class=kt>Se Ivanov</td><td class=ic>RUS</td><td class=kL>3:7</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kL>3:6</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kW>3:2</td>
<td class=kW>8:5</td>
<td class=kW>8:1</td>
<td class=kW>5:2</td>
<td class=kW>10:0</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>10:0</td>
<td class=br>86:46</td><td class=br>+40</td>
<td class=bc>11 - 1 - 5</td>
<td class=br><strong>23</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>J</td><td class=d>5.</td><td class=kt>De Matveev</td><td class=ic>RUS</td><td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=kW>13:0</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>9:0</td>
<td class=br>82:33</td><td class=br>+49</td>
<td class=bc>11 - 1 - 5</td>
<td class=br><strong>23</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>J</td><td class=d>6.</td><td class=kt>Ma Klippen</td><td class=ic>NOR</td><td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:8</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>6:0</td>
<td class=kW>9:1</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>1:0</td>
<td class=br>64:31</td><td class=br>+33</td>
<td class=bc>11 - 1 - 5</td>
<td class=br><strong>23</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>J</td><td class=d>7.</td><td class=kt>Dm Malygin</td><td class=ic>RUS</td><td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=br>64:42</td><td class=br>+22</td>
<td class=bc>10 - 2 - 5</td>
<td class=br><strong>22</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>J</td><td class=d>8.</td><td class=kt>Ra Kalninš</td><td class=ic>LAT</td><td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>7:5</td>
<td class=kL>1:5</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>5:3</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>8:1</td>
<td class=br>60:52</td><td class=br>+8</td>
<td class=bc>9 - 3 - 5</td>
<td class=br><strong>21</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>J</td><td class=d>9.</td><td class=kt>Oy Klippen</td><td class=ic>NOR</td><td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kL>2:7</td>
<td class=kW>2:0</td>
<td class=kL>5:7</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kL>0:3</td>
<td class=kW>8:0</td>
<td class=br>61:43</td><td class=br>+18</td>
<td class=bc>10 - 0 - 7</td>
<td class=br><strong>20</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>J</td><td class=d>10.</td><td class=kt>Un Österman</td><td class=ic>SWE</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>6:2</td>
<td class=kW>5:4</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>10:1</td>
<td class=br>52:45</td><td class=br>+7</td>
<td class=bc>8 - 3 - 6</td>
<td class=br><strong>19</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>J</td><td class=d>11.</td><td class=kt>Ja Matýsek</td><td class=ic>CZE</td><td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>5:8</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kL>3:6</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=br>52:55</td><td class=br>-3</td>
<td class=bc>6 - 3 - 8</td>
<td class=br><strong>15</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>J</td><td class=d>12.</td><td class=kt>Ni Blomberg</td><td class=ic>SWE</td><td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>1:8</td>
<td class=kL>2:7</td>
<td class=kL>3:4</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=br>38:62</td><td class=br>-24</td>
<td class=bc>5 - 3 - 9</td>
<td class=br><strong>13</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>J</td><td class=d>13.</td><td class=kt>Ti Roholm</td><td class=ic>FIN</td><td class=kL>0:8</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kL>2:7</td>
<td class=kL>2:6</td>
<td class=kL>2:7</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>8:3</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=br>40:74</td><td class=br>-34</td>
<td class=bc>3 - 3 - 11</td>
<td class=br><strong>9</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>J</td><td class=d>14.</td><td class=kt>Ol Blume</td><td class=ic>SWE</td><td class=kL>1:12</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>0:10</td>
<td class=kL>0:13</td>
<td class=kL>1:9</td>
<td class=kL>2:6</td>
<td class=kL>3:5</td>
<td class=kL>0:5</td>
<td class=kL>4:5</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kL>3:8</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=br>39:95</td><td class=br>-56</td>
<td class=bc>3 - 2 - 12</td>
<td class=br><strong>8</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>J</td><td class=d>15.</td><td class=kt>Al Metelitsa</td><td class=ic>EST</td><td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>12:0</td>
<td class=br>39:70</td><td class=br>-31</td>
<td class=bc>3 - 1 - 13</td>
<td class=br><strong>7</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>J</td><td class=d>16.</td><td class=kt>De Andrijashkin</td><td class=ic>EST</td><td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=br>29:70</td><td class=br>-41</td>
<td class=bc>2 - 2 - 13</td>
<td class=br><strong>6</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>J</td><td class=d>17.</td><td class=kt>Má Papp</td><td class=ic>HUN</td><td class=kL>3:6</td>
<td class=kL>0:7</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kW>3:0</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=br>29:74</td><td class=br>-45</td>
<td class=bc>3 - 0 - 14</td>
<td class=br><strong>6</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>J</td><td class=d>18.</td><td class=kt>Ni Cornelius</td><td class=ic>CHI</td><td class=kL>0:9</td>
<td class=kL>1:3</td>
<td class=kL>0:8</td>
<td class=kL>0:10</td>
<td class=kL>0:9</td>
<td class=kL>0:1</td>
<td class=kL>2:7</td>
<td class=kL>1:8</td>
<td class=kL>0:8</td>
<td class=kL>1:10</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>2:6</td>
<td class=kL>0:12</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=br>7:113</td><td class=br>-106</td>
<td class=bc>0 - 0 - 17</td>
<td class=br><strong>0</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>De Andrijashkin</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ni Blomberg</td><td class=bc>-</td><td class=bl>Ti Roholm</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ol Blume</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Un Österman</td><td class=bc>1 : 10</tr></td>
<tr><td class=brW>Se Ivanov</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ma Klippen</td><td class=bc>-</td><td class=blW>De Matveev</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Oy Klippen</td><td class=bc>-</td><td class=bl>Dm Malygin</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ni Zholobov</td><td class=bc>-</td><td class=bl>Ti Roholm</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>De Andrijashkin</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ni Blomberg</td><td class=bc>-</td><td class=bl>Un Österman</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ol Blume</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Se Ivanov</td><td class=bc>-</td><td class=bl>De Matveev</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ra Kalninš</td><td class=bc>-</td><td class=bl>Dm Malygin</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Klippen</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Oy Klippen</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ti Roholm</td><td class=bc>-</td><td class=blW>Má Papp</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ni Zholobov</td><td class=bc>-</td><td class=bl>Un Österman</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>De Andrijashkin</td><td class=bc>-</td><td class=blW>Al Metelitsa</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ni Blomberg</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ol Blume</td><td class=bc>-</td><td class=blW>De Matveev</td><td class=bc>0 : 13</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Dm Malygin</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Se Ivanov</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ra Kalninš</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Oy Klippen</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=blW>Un Österman</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ti Roholm</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ni Zholobov</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>De Andrijashkin</td><td class=bc>-</td><td class=blW>De Matveev</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ni Blomberg</td><td class=bc>-</td><td class=blW>Dm Malygin</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ol Blume</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Se Ivanov</td><td class=bc>-</td><td class=blW>Oy Klippen</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ra Kalninš</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Un Österman</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ti Roholm</td><td class=bc>-</td><td class=blW>De Matveev</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ni Zholobov</td><td class=bc>-</td><td class=bl>Dm Malygin</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>De Andrijashkin</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ni Blomberg</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ol Blume</td><td class=bc>-</td><td class=blW>Oy Klippen</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Se Ivanov</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Un Österman</td><td class=bc>-</td><td class=blW>De Matveev</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=blW>Dm Malygin</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ti Roholm</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ni Zholobov</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>De Andrijashkin</td><td class=bc>-</td><td class=blW>Oy Klippen</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ni Blomberg</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ol Blume</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Se Ivanov</td><td class=bc>0 : 10</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>De Matveev</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=blW>Dm Malygin</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Un Österman</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ti Roholm</td><td class=bc>-</td><td class=blW>Oy Klippen</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Ni Zholobov</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>De Andrijashkin</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ni Blomberg</td><td class=bc>-</td><td class=blW>Se Ivanov</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Ol Blume</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>De Matveev</td><td class=bc>-</td><td class=bl>Dm Malygin</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Ol Korabel</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 8</tr></td>
<tr><td class=brW>Un Österman</td><td class=bc>-</td><td class=bl>Oy Klippen</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ti Roholm</td><td class=bc>-</td><td class=bl>Ra Kalninš</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ni Zholobov</td><td class=bc>-</td><td class=bl>Se Ivanov</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>De Andrijashkin</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ni Blomberg</td><td class=bc>-</td><td class=bl>Ol Blume</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Dm Malygin</td><td class=bc>-</td><td class=bl>Ol Korabel</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>De Matveev</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Oy Klippen</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Un Österman</td><td class=bc>-</td><td class=bl>Ra Kalninš</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=blW>Se Ivanov</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ti Roholm</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ni Zholobov</td><td class=bc>-</td><td class=bl>Ol Blume</td><td class=bc>12 : 1</tr></td>
<tr><td class=br>De Andrijashkin</td><td class=bc>-</td><td class=blW>Ni Blomberg</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Oy Klippen</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Dm Malygin</td><td class=bc>-</td><td class=blW>Ma Klippen</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>De Matveev</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=blW>Se Ivanov</td><td class=bc>5 : 8</tr></td>
<tr><td class=brW>Al Metelitsa</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>12 : 0</tr></td>
<tr><td class=brW>Un Österman</td><td class=bc>-</td><td class=bl>Ol Blume</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=blW>Ni Blomberg</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ti Roholm</td><td class=bc>-</td><td class=bl>De Andrijashkin</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ni Zholobov</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Klippen</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Ra Kalninš</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Dm Malygin</td><td class=bc>-</td><td class=bl>Se Ivanov</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>De Matveev</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ol Blume</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=blW>Ni Blomberg</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Un Österman</td><td class=bc>-</td><td class=bl>De Andrijashkin</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ti Roholm</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Oy Klippen</td><td class=bc>-</td><td class=blW>Ra Kalninš</td><td class=bc>5 : 7</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Se Ivanov</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Dm Malygin</td><td class=bc>-</td><td class=bl>Ol Blume</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>De Matveev</td><td class=bc>-</td><td class=bl>Ni Blomberg</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>De Andrijashkin</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Un Österman</td><td class=bc>-</td><td class=bl>Ti Roholm</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ma Klippen</td><td class=bc>-</td><td class=blW>Se Ivanov</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Oy Klippen</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ol Blume</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Ni Blomberg</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Dm Malygin</td><td class=bc>-</td><td class=bl>De Andrijashkin</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>De Matveev</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ja Matýsek</td><td class=bc>-</td><td class=bl>Ti Roholm</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Al Metelitsa</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Un Österman</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Ni Cornelius</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Ol Blume</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Oy Klippen</td><td class=bc>-</td><td class=bl>Ni Blomberg</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>De Andrijashkin</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Dm Malygin</td><td class=bc>-</td><td class=bl>Ti Roholm</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>De Matveev</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>Un Österman</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Metelitsa</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Se Ivanov</td><td class=bc>-</td><td class=bl>Ol Blume</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Ra Kalninš</td><td class=bc>-</td><td class=bl>Ni Blomberg</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>De Andrijashkin</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Oy Klippen</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ti Roholm</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Dm Malygin</td><td class=bc>-</td><td class=bl>Un Österman</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>De Matveev</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ja Matýsek</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Ni Blomberg</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Se Ivanov</td><td class=bc>-</td><td class=bl>De Andrijashkin</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ra Kalninš</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Ti Roholm</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Oy Klippen</td><td class=bc>-</td><td class=blW>Má Papp</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Un Österman</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Dm Malygin</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>De Matveev</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Ol Blume</td><td class=bc>-</td><td class=bl>De Andrijashkin</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>0 : 9</tr></td>
<tr><td class=brW>Se Ivanov</td><td class=bc>-</td><td class=bl>Ti Roholm</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ma Klippen</td><td class=bc>-</td><td class=bl>Un Österman</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Oy Klippen</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ja Matýsek</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ol Korabel</td><td class=bc>-</td><td class=bl>De Matveev</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Dm Malygin</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ni Blomberg</td><td class=bc>-</td><td class=blW>Ni Zholobov</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ol Blume</td><td class=bc>-</td><td class=blW>Ti Roholm</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Ni Cornelius</td><td class=bc>-</td><td class=blW>Má Papp</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Se Ivanov</td><td class=bc>-</td><td class=bl>Un Österman</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ra Kalninš</td><td class=bc>-</td><td class=bl>Al Metelitsa</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ma Klippen</td><td class=bc>-</td><td class=blW>Ja Matýsek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Oy Klippen</td><td class=bc>-</td><td class=bl>De Matveev</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Dm Malygin</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ol Korabel</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

<p class=v>Group J2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>J</td><td class=d>1.</td><td class=kt>Dm Litvinyuk</td><td class=ic>UKR</td><td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>7:4</td>
<td class=kW>5:3</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>7:2</td>
<td class=kW>9:3</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=br>80:33</td><td class=br>+47</td>
<td class=bc>13 - 3 - 1</td>
<td class=br><strong>29</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>J</td><td class=d>2.</td><td class=kt>Ra Miglinieks</td><td class=ic>LAT</td><td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>0:0</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>6:4</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>7:3</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>9:2</td>
<td class=kW>6:0</td>
<td class=br>66:25</td><td class=br>+41</td>
<td class=bc>13 - 3 - 1</td>
<td class=br><strong>29</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>J</td><td class=d>3.</td><td class=kt>Os Henriksson</td><td class=ic>SWE</td><td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kL>4:6</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>9:4</td>
<td class=kW>7:1</td>
<td class=kW>7:2</td>
<td class=kW>4:3</td>
<td class=kW>7:0</td>
<td class=kW>7:2</td>
<td class=kW>6:3</td>
<td class=kW>10:1</td>
<td class=kW>10:2</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=br>101:37</td><td class=br>+64</td>
<td class=bc>14 - 1 - 2</td>
<td class=br><strong>29</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>J</td><td class=d>4.</td><td class=kt>Ev Matantsev</td><td class=ic>UKR</td><td class=kT>4:4</td>
<td class=kT>0:0</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>8:1</td>
<td class=kW>16:2</td>
<td class=kW>13:0</td>
<td class=kW>7:3</td>
<td class=kW>9:6</td>
<td class=kW>16:0</td>
<td class=kW>9:2</td>
<td class=kW>16:0</td>
<td class=br>122:38</td><td class=br>+84</td>
<td class=bc>11 - 4 - 2</td>
<td class=br><strong>26</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>J</td><td class=d>5.</td><td class=kt>Am Fylling</td><td class=ic>NOR</td><td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kW>6:4</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>10:1</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=br>64:32</td><td class=br>+32</td>
<td class=bc>11 - 3 - 3</td>
<td class=br><strong>25</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>J</td><td class=d>6.</td><td class=kt>Be Suominen</td><td class=ic>FIN</td><td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>9:0</td>
<td class=kW>4:3</td>
<td class=kW>10:4</td>
<td class=kW>8:2</td>
<td class=kW>8:0</td>
<td class=br>70:29</td><td class=br>+41</td>
<td class=bc>11 - 3 - 3</td>
<td class=br><strong>25</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>J</td><td class=d>7.</td><td class=kt>Li Restel</td><td class=ic>GER</td><td class=kL>4:5</td>
<td class=kL>4:6</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>8:0</td>
<td class=kW>5:0</td>
<td class=kW>7:0</td>
<td class=kW>3:0</td>
<td class=kW>9:1</td>
<td class=br>71:35</td><td class=br>+36</td>
<td class=bc>10 - 3 - 4</td>
<td class=br><strong>23</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>J</td><td class=d>8.</td><td class=kt>El Edelis</td><td class=ic>LAT</td><td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kL>4:9</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=kW>10:1</td>
<td class=kW>10:0</td>
<td class=kW>4:1</td>
<td class=br>69:34</td><td class=br>+35</td>
<td class=bc>9 - 3 - 5</td>
<td class=br><strong>21</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>J</td><td class=d>9.</td><td class=kt>Va Dietze</td><td class=ic>GER</td><td class=kT>4:4</td>
<td class=kL>2:6</td>
<td class=kL>1:7</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kW>7:1</td>
<td class=kW>6:2</td>
<td class=kW>11:5</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>5:3</td>
<td class=kW>10:0</td>
<td class=br>70:53</td><td class=br>+17</td>
<td class=bc>9 - 2 - 6</td>
<td class=br><strong>20</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>J</td><td class=d>10.</td><td class=kt>Ho Sládek</td><td class=ic>CZE</td><td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>2:7</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kW>5:1</td>
<td class=kW>8:1</td>
<td class=kW>7:2</td>
<td class=kW>9:1</td>
<td class=br>57:45</td><td class=br>+12</td>
<td class=bc>6 - 3 - 8</td>
<td class=br><strong>15</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>J</td><td class=d>11.</td><td class=kt>Le Haussknecht</td><td class=ic>GER</td><td class=kL>4:7</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>1:8</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kL>3:7</td>
<td class=kL>2:3</td>
<td class=kW>8:1</td>
<td class=kW>8:2</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=br>61:55</td><td class=br>+6</td>
<td class=bc>6 - 3 - 8</td>
<td class=br><strong>15</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>J</td><td class=d>12.</td><td class=kt>Lu Kahoun</td><td class=ic>CZE</td><td class=kL>3:5</td>
<td class=kL>3:7</td>
<td class=kL>0:7</td>
<td class=kL>2:16</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>8:0</td>
<td class=br>40:82</td><td class=br>-42</td>
<td class=bc>6 - 0 - 11</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>J</td><td class=d>13.</td><td class=kt>Jo Roholm</td><td class=ic>FIN</td><td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>2:7</td>
<td class=kL>0:13</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kW>7:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=br>33:67</td><td class=br>-34</td>
<td class=bc>5 - 2 - 10</td>
<td class=br><strong>12</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>J</td><td class=d>14.</td><td class=kt>Mi Skrlep</td><td class=ic>SLO</td><td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kL>3:6</td>
<td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kL>0:9</td>
<td class=kL>0:8</td>
<td class=kL>1:4</td>
<td class=kL>5:11</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kW>6:0</td>
<td class=kW>2:0</td>
<td class=br>36:73</td><td class=br>-37</td>
<td class=bc>4 - 1 - 12</td>
<td class=br><strong>9</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>J</td><td class=d>15.</td><td class=kt>Da Moshnin</td><td class=ic>EST</td><td class=kL>2:7</td>
<td class=kL>0:4</td>
<td class=kL>1:10</td>
<td class=kL>6:9</td>
<td class=kL>1:10</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>1:8</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=br>35:87</td><td class=br>-52</td>
<td class=bc>4 - 0 - 13</td>
<td class=br><strong>8</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>J</td><td class=d>16.</td><td class=kt>Vo Bernát</td><td class=ic>CZE</td><td class=kL>3:9</td>
<td class=kL>0:2</td>
<td class=kL>2:10</td>
<td class=kL>0:16</td>
<td class=kL>1:5</td>
<td class=kL>4:10</td>
<td class=kL>0:7</td>
<td class=kL>1:10</td>
<td class=kL>0:5</td>
<td class=kL>1:8</td>
<td class=kL>2:8</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>8:0</td>
<td class=br>33:108</td><td class=br>-75</td>
<td class=bc>2 - 1 - 14</td>
<td class=br><strong>5</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>J</td><td class=d>17.</td><td class=kt>Fi Kalinouski</td><td class=ic>BLR</td><td class=kL>0:6</td>
<td class=kL>2:9</td>
<td class=kL>0:6</td>
<td class=kL>2:9</td>
<td class=kL>0:4</td>
<td class=kL>2:8</td>
<td class=kL>0:3</td>
<td class=kL>0:10</td>
<td class=kL>3:5</td>
<td class=kL>2:7</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=br>19:89</td><td class=br>-70</td>
<td class=bc>1 - 0 - 16</td>
<td class=br><strong>2</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>J</td><td class=d>18.</td><td class=kt>Mo Skrlep</td><td class=ic>SLO</td><td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>0:16</td>
<td class=kL>1:7</td>
<td class=kL>0:8</td>
<td class=kL>1:9</td>
<td class=kL>1:4</td>
<td class=kL>0:10</td>
<td class=kL>1:9</td>
<td class=kL>1:6</td>
<td class=kL>0:8</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kL>2:6</td>
<td class=kL>0:8</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=br>9:114</td><td class=br>-105</td>
<td class=bc>0 - 1 - 16</td>
<td class=br><strong>1</strong></td><td class=d>18.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>4 : 10</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>El Edelis</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=blW>Jo Roholm</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Da Moshnin</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 9</tr></td>
<tr><td class=br>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>11 : 5</tr></td>
<tr><td class=brW>El Edelis</td><td class=bc>-</td><td class=bl>Jo Roholm</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Le Haussknecht</td><td class=bc>-</td><td class=bl>Da Moshnin</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Os Henriksson</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 16</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Jo Roholm</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Li Restel</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>El Edelis</td><td class=bc>-</td><td class=bl>Da Moshnin</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Os Henriksson</td><td class=bc>-</td><td class=bl>Dm Litvinyuk</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=blW>Mi Skrlep</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=bl>Jo Roholm</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Da Moshnin</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>El Edelis</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Le Haussknecht</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Jo Roholm</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=blW>Li Restel</td><td class=bc>1 : 9</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Da Moshnin</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>0 : 16</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=bl>Dm Litvinyuk</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>El Edelis</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Jo Roholm</td><td class=bc>-</td><td class=blW>Li Restel</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Da Moshnin</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Vo Bernát</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>El Edelis</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>4 : 9</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Li Restel</td><td class=bc>-</td><td class=bl>Da Moshnin</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Jo Roholm</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>2 : 10</tr></td>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>El Edelis</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Da Moshnin</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jo Roholm</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Mi Skrlep</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Va Dietze</td><td class=bc>-</td><td class=bl>El Edelis</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Da Moshnin</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Li Restel</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Jo Roholm</td><td class=bc>-</td><td class=blW>Lu Kahoun</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=blW>Le Haussknecht</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Be Suominen</td><td class=bc>-</td><td class=bl>El Edelis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Vo Bernát</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Fi Kalinouski</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Da Moshnin</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=blW>Le Haussknecht</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jo Roholm</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=blW>El Edelis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Ho Sládek</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Be Suominen</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Lu Kahoun</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Moshnin</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 10</tr></td>
<tr><td class=brW>Li Restel</td><td class=bc>-</td><td class=bl>El Edelis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Jo Roholm</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ho Sládek</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Os Henriksson</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Le Haussknecht</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>El Edelis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Da Moshnin</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Li Restel</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Jo Roholm</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Mi Skrlep</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Mo Skrlep</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Le Haussknecht</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Dm Litvinyuk</td><td class=bc>-</td><td class=blW>El Edelis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Da Moshnin</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Li Restel</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Jo Roholm</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Mi Skrlep</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Os Henriksson</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>El Edelis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Va Dietze</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>9 : 3</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Moshnin</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Li Restel</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Jo Roholm</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=bl>El Edelis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>16 : 0</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Da Moshnin</td><td class=bc>-</td><td class=blW>Jo Roholm</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Li Restel</td><td class=bc>-</td><td class=blW>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Va Dietze</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Le Haussknecht</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Fi Kalinouski</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Jo Roholm</td><td class=bc>13 : 0</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Da Moshnin</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>El Edelis</td><td class=bc>-</td><td class=bl>Vo Bernát</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Be Suominen</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=blW>Ho Sládek</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Lu Kahoun</td><td class=bc>-</td><td class=bl>Mi Skrlep</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Jo Roholm</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Li Restel</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Da Moshnin</td><td class=bc>9 : 6</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Va Dietze</td><td class=bc>-</td><td class=blW>Be Suominen</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>El Edelis</td><td class=bc>-</td><td class=bl>Ho Sládek</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Mo Skrlep</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Le Haussknecht</td><td class=bc>-</td><td class=blW>Mi Skrlep</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Os Henriksson</td><td class=bc>-</td><td class=bl>Jo Roholm</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Lu Kahoun</td><td class=bc>-</td><td class=blW>Li Restel</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Fi Kalinouski</td><td class=bc>-</td><td class=blW>Da Moshnin</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</table></div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
