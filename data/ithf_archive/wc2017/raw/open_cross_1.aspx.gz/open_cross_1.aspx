<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01  Transitional//EN"><html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1250"><title>Open</title><link rel="StyleSheet" href="css.css" type="text/css"><link rel="StyleSheet" href="xcss.css" type="text/css"></head><body><header><nav class="navbar navbar-default"><div class="container" align="center"><ul class="nav navbar-nav" id="main-menu"><br><li><a href="http://www.wch-liberec2017.eu/">Home</a>

&nbsp;&nbsp;&nbsp;<a href="open_list.aspx">Open</a>&nbsp;&nbsp;&nbsp;<a href="ladies_list.aspx">Ladies</a>&nbsp;&nbsp;&nbsp;<a href="juniors_list.aspx">Juniors</a>&nbsp;&nbsp;&nbsp;<a href="veterans_list.aspx">Veterans</a>&nbsp;&nbsp;&nbsp;<a href="team_open_list.aspx">Teams</a>&nbsp;&nbsp;&nbsp;<a href="team_ladies_list.aspx">Teams L</a>&nbsp;&nbsp;&nbsp;<a href="team_juniors_list.aspx">Teams J</a>&nbsp;&nbsp;&nbsp;<a href="team_veterans_list.aspx">Teams V</a>&nbsp;&nbsp;&nbsp;<a href="50_list.aspx">50+</a>&nbsp;&nbsp;&nbsp;<a href="u13_list.aspx">U13</a></li></ul></div></nav></header><div id="highlighted"><div id="header"><div class="container"><div class=""><h2 class="page-title"><span>Open </span></h2></div></div></div></div><p><div align="center">
<p class=v>Group 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ma Borisov</td><td class=ic>RUS</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>6:4</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=br>79:27</td><td class=br>+52</td>
<td class=bc>16 - 1 - 1</td>
<td class=br><strong>33</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>My Spivakovskyy</td><td class=ic>UKR</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kW>9:1</td>
<td class=kW>8:1</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>7:0</td>
<td class=br>76:28</td><td class=br>+48</td>
<td class=bc>11 - 7 - 0</td>
<td class=br><strong>29</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ro Ignatenko</td><td class=ic>UKR</td><td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>7:3</td>
<td class=kW>12:3</td>
<td class=kW>5:4</td>
<td class=kW>9:0</td>
<td class=kW>11:0</td>
<td class=br>86:37</td><td class=br>+49</td>
<td class=bc>12 - 3 - 3</td>
<td class=br><strong>27</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Dm Litvinyuk</td><td class=ic>UKR</td><td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>7:4</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>7:3</td>
<td class=kW>8:2</td>
<td class=kW>7:2</td>
<td class=kW>3:0</td>
<td class=kW>9:1</td>
<td class=br>75:40</td><td class=br>+35</td>
<td class=bc>11 - 4 - 3</td>
<td class=br><strong>26</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Kr Iso-Tryykari</td><td class=ic>FIN</td><td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>7:3</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=br>64:34</td><td class=br>+30</td>
<td class=bc>11 - 4 - 3</td>
<td class=br><strong>26</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>El Silinš</td><td class=ic>LAT</td><td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>8:0</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>8:0</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>63:37</td><td class=br>+26</td>
<td class=bc>12 - 1 - 5</td>
<td class=br><strong>25</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ar Zaharovs</td><td class=ic>LAT</td><td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>6:0</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>8:1</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=br>58:27</td><td class=br>+31</td>
<td class=bc>11 - 2 - 5</td>
<td class=br><strong>24</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Zd Matoušek ml.</td><td class=ic>CZE</td><td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>12:1</td>
<td class=br>66:35</td><td class=br>+31</td>
<td class=bc>11 - 2 - 5</td>
<td class=br><strong>24</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Da Šmíd</td><td class=ic>CZE</td><td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>6:3</td>
<td class=kL>4:6</td>
<td class=kW>4:3</td>
<td class=kT>0:0</td>
<td class=kW>7:0</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=kW>11:0</td>
<td class=kW>5:1</td>
<td class=br>65:37</td><td class=br>+28</td>
<td class=bc>10 - 3 - 5</td>
<td class=br><strong>23</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Si Thomas</td><td class=ic>IRL</td><td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>4:7</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>7:3</td>
<td class=kW>3:1</td>
<td class=kW>9:1</td>
<td class=kW>11:0</td>
<td class=br>58:38</td><td class=br>+20</td>
<td class=bc>10 - 2 - 6</td>
<td class=br><strong>22</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Al Shekarev</td><td class=ic>EST</td><td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>1:7</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>4:3</td>
<td class=kW>9:0</td>
<td class=kW>4:2</td>
<td class=br>58:54</td><td class=br>+4</td>
<td class=bc>8 - 1 - 9</td>
<td class=br><strong>17</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>C</td><td class=d>12.</td><td class=kt>An Bozic</td><td class=ic>SLO</td><td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kW>6:4</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=br>55:50</td><td class=br>+5</td>
<td class=bc>8 - 1 - 9</td>
<td class=br><strong>17</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ma Lunden</td><td class=ic>SWE</td><td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>0:1</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>12:0</td>
<td class=br>52:54</td><td class=br>-2</td>
<td class=bc>7 - 1 - 10</td>
<td class=br><strong>15</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ka Hudec</td><td class=ic>SVK</td><td class=kL>0:3</td>
<td class=kL>2:6</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>0:8</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kT>0:0</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>7:4</td>
<td class=kW>8:5</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kW>11:2</td>
<td class=br>53:61</td><td class=br>-8</td>
<td class=bc>6 - 2 - 10</td>
<td class=br><strong>14</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>D</td><td class=d>15.</td><td class=kt>An Naszádi</td><td class=ic>HUN</td><td class=kL>0:4</td>
<td class=kL>1:9</td>
<td class=kL>3:7</td>
<td class=kL>3:7</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>1:8</td>
<td class=kL>2:5</td>
<td class=kL>0:7</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>4:7</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>9:0</td>
<td class=kW>4:0</td>
<td class=kW>9:0</td>
<td class=br>46:79</td><td class=br>-33</td>
<td class=bc>4 - 0 - 14</td>
<td class=br><strong>8</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>An Kniaziuk</td><td class=ic>BLR</td><td class=kL>4:6</td>
<td class=kL>1:8</td>
<td class=kL>3:12</td>
<td class=kL>2:8</td>
<td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>2:7</td>
<td class=kL>2:7</td>
<td class=kL>3:7</td>
<td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>5:8</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>8:3</td>
<td class=kW>5:1</td>
<td class=kW>12:0</td>
<td class=br>54:96</td><td class=br>-42</td>
<td class=bc>3 - 0 - 15</td>
<td class=br><strong>6</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Th Cornelius</td><td class=ic>CHI</td><td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>4:5</td>
<td class=kL>2:7</td>
<td class=kL>0:6</td>
<td class=kL>0:8</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>2:7</td>
<td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kL>0:9</td>
<td class=kL>3:8</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=br>38:94</td><td class=br>-56</td>
<td class=bc>2 - 0 - 16</td>
<td class=br><strong>4</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>E</td><td class=d>18.</td><td class=kt>Má Papp</td><td class=ic>HUN</td><td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>0:9</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kL>0:11</td>
<td class=kL>1:9</td>
<td class=kL>0:9</td>
<td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>16:103</td><td class=br>-87</td>
<td class=bc>1 - 0 - 17</td>
<td class=br><strong>2</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>E</td><td class=d>19.</td><td class=kt>Si Culic</td><td class=ic>SRB</td><td class=kL>0:6</td>
<td class=kL>0:7</td>
<td class=kL>0:11</td>
<td class=kL>1:9</td>
<td class=kL>1:7</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:12</td>
<td class=kL>1:5</td>
<td class=kL>0:11</td>
<td class=kL>2:4</td>
<td class=kL>0:6</td>
<td class=kL>0:12</td>
<td class=kL>2:11</td>
<td class=kL>0:9</td>
<td class=kL>0:12</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>10:141</td><td class=br>-131</td>
<td class=bc>0 - 0 - 18</td>
<td class=br><strong>0</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>My Spivakovskyy</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ro Ignatenko</td><td class=bc>-</td><td class=blW>Al Shekarev</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Kr Iso-Tryykari</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>An Naszádi</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Zd Matoušek ml.</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>My Spivakovskyy</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Al Shekarev</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ro Ignatenko</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Kr Iso-Tryykari</td><td class=bc>-</td><td class=bl>Zd Matoušek ml.</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>Ma Lunden</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>My Spivakovskyy</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>Al Shekarev</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Th Cornelius</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>An Naszádi</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ro Ignatenko</td><td class=bc>-</td><td class=bl>Ma Lunden</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kr Iso-Tryykari</td><td class=bc>-</td><td class=bl>Dm Litvinyuk</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>My Spivakovskyy</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Al Shekarev</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Ma Lunden</td><td class=bc>0 : 12</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ro Ignatenko</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>12 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>My Spivakovskyy</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Al Shekarev</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Zd Matoušek ml.</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>Ma Lunden</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>An Kniaziuk</td><td class=bc>0 : 12</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>Kr Iso-Tryykari</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Al Shekarev</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Ma Lunden</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Dm Litvinyuk</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>Kr Iso-Tryykari</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Ro Ignatenko</td><td class=bc>0 : 11</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Al Shekarev</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Zd Matoušek ml.</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Ma Lunden</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Kr Iso-Tryykari</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>Ro Ignatenko</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=blW>An Naszádi</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Ma Lunden</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Dm Litvinyuk</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Kr Iso-Tryykari</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>Ro Ignatenko</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Zd Matoušek ml.</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=blW>Ma Lunden</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Kr Iso-Tryykari</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ro Ignatenko</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ar Zaharovs</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ma Borisov</td><td class=bc>-</td><td class=bl>Th Cornelius</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ma Lunden</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=blW>An Kniaziuk</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>Kr Iso-Tryykari</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=blW>Ro Ignatenko</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Da Šmíd</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Th Cornelius</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ar Zaharovs</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ma Lunden</td><td class=bc>-</td><td class=blW>Dm Litvinyuk</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Kr Iso-Tryykari</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=blW>Ro Ignatenko</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Th Cornelius</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ma Borisov</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>An Kniaziuk</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Ma Lunden</td><td class=bc>-</td><td class=blW>Kr Iso-Tryykari</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Ro Ignatenko</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Má Papp</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Al Shekarev</td><td class=bc>-</td><td class=bl>Th Cornelius</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>El Silinš</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Ma Borisov</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Šmíd</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>Kr Iso-Tryykari</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Ro Ignatenko</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Lunden</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>12 : 1</tr></td>
<tr><td class=brW>An Naszádi</td><td class=bc>-</td><td class=bl>Th Cornelius</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>Ma Borisov</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>My Spivakovskyy</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Kr Iso-Tryykari</td><td class=bc>-</td><td class=blW>Ro Ignatenko</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>Ka Hudec</td><td class=bc>5 : 8</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Ma Lunden</td><td class=bc>-</td><td class=bl>Th Cornelius</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Ma Borisov</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>El Silinš</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ro Ignatenko</td><td class=bc>-</td><td class=bl>Ka Hudec</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Kr Iso-Tryykari</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>An Kniaziuk</td><td class=bc>-</td><td class=bl>Th Cornelius</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ma Lunden</td><td class=bc>-</td><td class=blW>Ma Borisov</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>Al Shekarev</td><td class=bc>-</td><td class=bl>My Spivakovskyy</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Ka Hudec</td><td class=bc>-</td><td class=bl>Si Culic</td><td class=bc>11 : 2</tr></td>
<tr><td class=brW>Ro Ignatenko</td><td class=bc>-</td><td class=bl>Th Cornelius</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Kr Iso-Tryykari</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>Ma Borisov</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Lunden</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Zd Matoušek ml.</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>My Spivakovskyy</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Má Papp</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Th Cornelius</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro Ignatenko</td><td class=bc>-</td><td class=blW>Ma Borisov</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Kr Iso-Tryykari</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Dm Litvinyuk</td><td class=bc>-</td><td class=blW>Da Šmíd</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Lunden</td><td class=bc>-</td><td class=bl>My Spivakovskyy</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>El Silinš</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>An Naszádi</td><td class=bc>-</td><td class=blW>Al Shekarev</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Ma Borisov</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=bl>Ar Zaharovs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ro Ignatenko</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kr Iso-Tryykari</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>My Spivakovskyy</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Dm Litvinyuk</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Lunden</td><td class=bc>-</td><td class=blW>Al Shekarev</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Zd Matoušek ml.</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>Ma Borisov</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Th Cornelius</td><td class=bc>-</td><td class=blW>Ar Zaharovs</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Si Culic</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>Ka Hudec</td><td class=bc>-</td><td class=bl>Da Šmíd</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ro Ignatenko</td><td class=bc>-</td><td class=bl>My Spivakovskyy</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Iso-Tryykari</td><td class=bc>-</td><td class=blW>El Silinš</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Kniaziuk</td><td class=bc>-</td><td class=blW>Al Shekarev</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Dm Litvinyuk</td><td class=bc>-</td><td class=bl>Má Papp</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Lunden</td><td class=bc>-</td><td class=bl>An Naszádi</td><td class=bc>3 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>

</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</span></body></html>
