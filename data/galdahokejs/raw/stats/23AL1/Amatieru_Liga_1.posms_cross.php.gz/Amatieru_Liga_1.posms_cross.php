<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Amatieru Liga 1.posms</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../23AL1/Amatieru_Liga_1.posms_index.php">Amatieru Liga 1.posms, 9. September 2023</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group AL </br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ra Martu�ans</td><td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>6:3</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=br>54:28</td><td class=br>+26</td>
<td class=bc>12 - 1 - 3</td>
<td class=br><strong>25</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Iv Kirsis</td><td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=br>56:33</td><td class=br>+23</td>
<td class=bc>10 - 4 - 2</td>
<td class=br><strong>24</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ra Ladusans</td><td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>8:1</td>
<td class=kL>0:4</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>7:0</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=br>42:27</td><td class=br>+15</td>
<td class=bc>9 - 4 - 3</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Da Baumanis</td><td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>10:0</td>
<td class=kW>2:1</td>
<td class=br>44:24</td><td class=br>+20</td>
<td class=bc>10 - 2 - 4</td>
<td class=br><strong>22</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ei Guze</td><td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=br>35:17</td><td class=br>+18</td>
<td class=bc>8 - 4 - 4</td>
<td class=br><strong>20</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Re Stacevics</td><td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=br>41:25</td><td class=br>+16</td>
<td class=bc>9 - 2 - 5</td>
<td class=br><strong>20</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ja Zemnickis</td><td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>1:8</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=br>31:33</td><td class=br>-2</td>
<td class=bc>8 - 3 - 5</td>
<td class=br><strong>19</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Il Kirse</td><td class=kL>1:4</td>
<td class=kW>6:3</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=br>40:33</td><td class=br>+7</td>
<td class=bc>9 - 1 - 6</td>
<td class=br><strong>19</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Gi Vazolin�</td><td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>7:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=br>36:29</td><td class=br>+7</td>
<td class=bc>8 - 2 - 6</td>
<td class=br><strong>18</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ro Aserin�</td><td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kT>0:0</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=br>23:21</td><td class=br>+2</td>
<td class=bc>6 - 4 - 6</td>
<td class=br><strong>16</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Ro Purmalis</td><td class=kL>2:6</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=k>&nbsp;</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=br>35:33</td><td class=br>+2</td>
<td class=bc>6 - 1 - 8</td>
<td class=br><strong>13</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>An Zilicka</td><td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=br>26:46</td><td class=br>-20</td>
<td class=bc>4 - 3 - 9</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Kr Gutmanis</td><td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kW>2:0</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kT>0:0</td>
<td class=k>&nbsp;</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=br>19:34</td><td class=br>-15</td>
<td class=bc>4 - 2 - 9</td>
<td class=br><strong>10</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Da Vesele</td><td class=kL>3:6</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kL>2:7</td>
<td class=kT>0:0</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=br>26:47</td><td class=br>-21</td>
<td class=bc>3 - 4 - 9</td>
<td class=br><strong>10</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Uv Vikmanis</td><td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kT>4:4</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=br>25:51</td><td class=br>-26</td>
<td class=bc>2 - 5 - 9</td>
<td class=br><strong>9</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Ar Pavlovs</td><td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>0:10</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=br>27:53</td><td class=br>-26</td>
<td class=bc>2 - 2 - 12</td>
<td class=br><strong>6</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ar Verbics</td><td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>0:5</td>
<td class=kT>4:4</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=br>17:43</td><td class=br>-26</td>
<td class=bc>0 - 6 - 10</td>
<td class=br><strong>6</strong></td><td class=d>17.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ro Aserin�</td><td class=bc>-</td><td class=blW>An Zilicka</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Ja Zemnickis</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Kr Gutmanis</td><td class=bc>-</td><td class=bl>Uv Vikmanis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ei Guze</td><td class=bc>-</td><td class=bl>Da Vesele</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Il Kirse</td><td class=bc>-</td><td class=bl>Ar Verbics</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Iv Kirsis</td><td class=bc>-</td><td class=blW>Gi Vazolin�</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ra Ladusans</td><td class=bc>-</td><td class=blW>Re Stacevics</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ra Martu�ans</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>An Zilicka</td><td class=bc>-</td><td class=blW>Ja Zemnickis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ro Aserin�</td><td class=bc>-</td><td class=bl>Uv Vikmanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>Da Vesele</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr Gutmanis</td><td class=bc>-</td><td class=bl>Ar Verbics</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ei Guze</td><td class=bc>-</td><td class=blW>Gi Vazolin�</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Il Kirse</td><td class=bc>-</td><td class=blW>Re Stacevics</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Iv Kirsis</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ra Ladusans</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ja Zemnickis</td><td class=bc>-</td><td class=bl>Uv Vikmanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>An Zilicka</td><td class=bc>-</td><td class=bl>Da Vesele</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ro Aserin�</td><td class=bc>-</td><td class=bl>Ar Verbics</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Gi Vazolin�</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kr Gutmanis</td><td class=bc>-</td><td class=bl>Re Stacevics</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ei Guze</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Il Kirse</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Iv Kirsis</td><td class=bc>-</td><td class=bl>Ra Martu�ans</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Uv Vikmanis</td><td class=bc>-</td><td class=blW>Da Vesele</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Zemnickis</td><td class=bc>-</td><td class=bl>Ar Verbics</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>An Zilicka</td><td class=bc>-</td><td class=blW>Gi Vazolin�</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro Aserin�</td><td class=bc>-</td><td class=blW>Re Stacevics</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Gutmanis</td><td class=bc>-</td><td class=blW>Ar Pavlovs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ei Guze</td><td class=bc>-</td><td class=bl>Ra Martu�ans</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Il Kirse</td><td class=bc>-</td><td class=bl>Ra Ladusans</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Da Vesele</td><td class=bc>-</td><td class=bl>Ar Verbics</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Uv Vikmanis</td><td class=bc>-</td><td class=bl>Gi Vazolin�</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ja Zemnickis</td><td class=bc>-</td><td class=bl>Re Stacevics</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>An Zilicka</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ro Aserin�</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Ra Martu�ans</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Gutmanis</td><td class=bc>-</td><td class=blW>Ra Ladusans</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ei Guze</td><td class=bc>-</td><td class=bl>Iv Kirsis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ar Verbics</td><td class=bc>-</td><td class=blW>Gi Vazolin�</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Vesele</td><td class=bc>-</td><td class=blW>Re Stacevics</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Uv Vikmanis</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ja Zemnickis</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>An Zilicka</td><td class=bc>-</td><td class=blW>Ra Martu�ans</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Aserin�</td><td class=bc>-</td><td class=blW>Ra Ladusans</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Iv Kirsis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Kr Gutmanis</td><td class=bc>-</td><td class=blW>Il Kirse</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Gi Vazolin�</td><td class=bc>-</td><td class=blW>Re Stacevics</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ar Verbics</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Da Vesele</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Uv Vikmanis</td><td class=bc>-</td><td class=blW>Ra Martu�ans</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ja Zemnickis</td><td class=bc>-</td><td class=blW>Ra Ladusans</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>An Zilicka</td><td class=bc>-</td><td class=blW>Iv Kirsis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ro Aserin�</td><td class=bc>-</td><td class=blW>Il Kirse</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Ei Guze</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Re Stacevics</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Gi Vazolin�</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ar Verbics</td><td class=bc>-</td><td class=blW>Ra Martu�ans</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Vesele</td><td class=bc>-</td><td class=blW>Ra Ladusans</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Uv Vikmanis</td><td class=bc>-</td><td class=blW>Iv Kirsis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ja Zemnickis</td><td class=bc>-</td><td class=bl>Il Kirse</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Zilicka</td><td class=bc>-</td><td class=blW>Ei Guze</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ro Aserin�</td><td class=bc>-</td><td class=bl>Kr Gutmanis</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ro Purmalis</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Re Stacevics</td><td class=bc>-</td><td class=blW>Ra Martu�ans</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Gi Vazolin�</td><td class=bc>-</td><td class=blW>Ra Ladusans</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ar Verbics</td><td class=bc>-</td><td class=blW>Iv Kirsis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Da Vesele</td><td class=bc>-</td><td class=blW>Il Kirse</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Uv Vikmanis</td><td class=bc>-</td><td class=blW>Ei Guze</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ja Zemnickis</td><td class=bc>-</td><td class=bl>Kr Gutmanis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>An Zilicka</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ar Pavlovs</td><td class=bc>-</td><td class=blW>Ra Martu�ans</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Ra Ladusans</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Re Stacevics</td><td class=bc>-</td><td class=bl>Iv Kirsis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Gi Vazolin�</td><td class=bc>-</td><td class=bl>Il Kirse</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ar Verbics</td><td class=bc>-</td><td class=blW>Ei Guze</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Da Vesele</td><td class=bc>-</td><td class=bl>Kr Gutmanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Uv Vikmanis</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ja Zemnickis</td><td class=bc>-</td><td class=bl>Ro Aserin�</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Ra Martu�ans</td><td class=bc>-</td><td class=bl>Ra Ladusans</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ar Pavlovs</td><td class=bc>-</td><td class=blW>Iv Kirsis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ro Purmalis</td><td class=bc>-</td><td class=bl>Il Kirse</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Re Stacevics</td><td class=bc>-</td><td class=blW>Ei Guze</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Gi Vazolin�</td><td class=bc>-</td><td class=bl>Kr Gutmanis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ar Verbics</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Vesele</td><td class=bc>-</td><td class=bl>Ro Aserin�</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Uv Vikmanis</td><td class=bc>-</td><td class=bl>An Zilicka</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ra Ladusans</td><td class=bc>-</td><td class=bl>Iv Kirsis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ra Martu�ans</td><td class=bc>-</td><td class=bl>Il Kirse</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ar Pavlovs</td><td class=bc>-</td><td class=blW>Ei Guze</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=bl>Kr Gutmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Re Stacevics</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Gi Vazolin�</td><td class=bc>-</td><td class=blW>Ro Aserin�</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ar Verbics</td><td class=bc>-</td><td class=bl>An Zilicka</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Da Vesele</td><td class=bc>-</td><td class=bl>Ja Zemnickis</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Iv Kirsis</td><td class=bc>-</td><td class=blW>Il Kirse</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ra Ladusans</td><td class=bc>-</td><td class=bl>Ei Guze</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ra Martu�ans</td><td class=bc>-</td><td class=bl>Kr Gutmanis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ar Pavlovs</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=bl>Ro Aserin�</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Re Stacevics</td><td class=bc>-</td><td class=bl>An Zilicka</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Gi Vazolin�</td><td class=bc>-</td><td class=bl>Ja Zemnickis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ar Verbics</td><td class=bc>-</td><td class=bl>Uv Vikmanis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Il Kirse</td><td class=bc>-</td><td class=bl>Ei Guze</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Iv Kirsis</td><td class=bc>-</td><td class=bl>Kr Gutmanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ra Ladusans</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ra Martu�ans</td><td class=bc>-</td><td class=blW>Ro Aserin�</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ar Pavlovs</td><td class=bc>-</td><td class=bl>An Zilicka</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Ja Zemnickis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Re Stacevics</td><td class=bc>-</td><td class=bl>Uv Vikmanis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Gi Vazolin�</td><td class=bc>-</td><td class=bl>Da Vesele</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ei Guze</td><td class=bc>-</td><td class=bl>Kr Gutmanis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Il Kirse</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Iv Kirsis</td><td class=bc>-</td><td class=bl>Ro Aserin�</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Ladusans</td><td class=bc>-</td><td class=bl>An Zilicka</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ra Martu�ans</td><td class=bc>-</td><td class=bl>Ja Zemnickis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ar Pavlovs</td><td class=bc>-</td><td class=blW>Uv Vikmanis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ro Purmalis</td><td class=bc>-</td><td class=bl>Da Vesele</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Re Stacevics</td><td class=bc>-</td><td class=bl>Ar Verbics</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Kr Gutmanis</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ei Guze</td><td class=bc>-</td><td class=blW>Ro Aserin�</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Il Kirse</td><td class=bc>-</td><td class=bl>An Zilicka</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Iv Kirsis</td><td class=bc>-</td><td class=bl>Ja Zemnickis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ra Ladusans</td><td class=bc>-</td><td class=bl>Uv Vikmanis</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ra Martu�ans</td><td class=bc>-</td><td class=bl>Da Vesele</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ar Pavlovs</td><td class=bc>-</td><td class=bl>Ar Verbics</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ro Purmalis</td><td class=bc>-</td><td class=bl>Gi Vazolin�</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Ro Aserin�</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr Gutmanis</td><td class=bc>-</td><td class=blW>An Zilicka</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ei Guze</td><td class=bc>-</td><td class=bl>Ja Zemnickis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Il Kirse</td><td class=bc>-</td><td class=blW>Uv Vikmanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Iv Kirsis</td><td class=bc>-</td><td class=bl>Da Vesele</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ra Ladusans</td><td class=bc>-</td><td class=bl>Ar Verbics</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ra Martu�ans</td><td class=bc>-</td><td class=bl>Gi Vazolin�</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ar Pavlovs</td><td class=bc>-</td><td class=blW>Re Stacevics</td><td class=bc>2 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
