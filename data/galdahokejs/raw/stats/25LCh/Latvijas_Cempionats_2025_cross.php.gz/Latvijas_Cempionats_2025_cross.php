<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Latvijas Cempionats 2025</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../25LCh/Latvijas_Cempionats_2025_index.php">Latvijas Cempionats 2025, 8. March 2025</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group LC A grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ra Kalni��</td><td class=kx>*</td>
<td class=kW>8:2</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>11:3</td>
<td class=kW>7:4</td>
<td class=kW>10:1</td>
<td class=kW>9:2</td>
<td class=kW>5:0</td>
<td class=kW>9:1</td>
<td class=kW>12:3</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=br>98:25</td><td class=br>+73</td>
<td class=bc>13 - 0 - 0</td>
<td class=br><strong>26</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>El Sili��</td><td class=kL>2:8</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=br>53:25</td><td class=br>+28</td>
<td class=bc>12 - 0 - 1</td>
<td class=br><strong>24</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Mi Saul�tis</td><td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>5:6</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kT>0:0</td>
<td class=kW>5:2</td>
<td class=br>49:37</td><td class=br>+12</td>
<td class=bc>8 - 1 - 4</td>
<td class=br><strong>17</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Je Zaharovs</td><td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=br>45:29</td><td class=br>+16</td>
<td class=bc>7 - 2 - 4</td>
<td class=br><strong>16</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>In Garan�s</td><td class=kL>3:11</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=br>37:44</td><td class=br>-7</td>
<td class=bc>6 - 2 - 5</td>
<td class=br><strong>14</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ni Sviklis</td><td class=kL>4:7</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=br>45:41</td><td class=br>+4</td>
<td class=bc>6 - 1 - 6</td>
<td class=br><strong>13</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ri Kalni��</td><td class=kL>1:10</td>
<td class=kL>1:2</td>
<td class=kW>6:5</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>2:6</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=br>41:41</td><td class=br>0</td>
<td class=bc>6 - 1 - 6</td>
<td class=br><strong>13</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>An Kuz�ecovs</td><td class=kL>2:9</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kW>5:0</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>10:0</td>
<td class=kW>6:2</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=br>45:47</td><td class=br>-2</td>
<td class=bc>6 - 0 - 7</td>
<td class=br><strong>12</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Sa Skarainis</td><td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kL>2:4</td>
<td class=kW>5:4</td>
<td class=kT>1:1</td>
<td class=br>40:40</td><td class=br>0</td>
<td class=bc>5 - 2 - 6</td>
<td class=br><strong>12</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ro Meijers</td><td class=kL>1:9</td>
<td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=br>26:39</td><td class=br>-13</td>
<td class=bc>5 - 0 - 8</td>
<td class=br><strong>10</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Kr Zarinieks</td><td class=kL>3:12</td>
<td class=kL>0:3</td>
<td class=kL>2:7</td>
<td class=kL>1:7</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>0:10</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>10:0</td>
<td class=kW>6:4</td>
<td class=br>34:67</td><td class=br>-33</td>
<td class=bc>4 - 0 - 9</td>
<td class=br><strong>8</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>Ai Romals</td><td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=br>31:50</td><td class=br>-19</td>
<td class=bc>3 - 2 - 8</td>
<td class=br><strong>8</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Kr Naglis</td><td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kT>0:0</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kW>4:3</td>
<td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kL>0:10</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=br>23:52</td><td class=br>-29</td>
<td class=bc>2 - 1 - 10</td>
<td class=br><strong>5</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Re Stac�vi�s</td><td class=kL>1:7</td>
<td class=kL>2:7</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kL>4:6</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=br>25:55</td><td class=br>-30</td>
<td class=bc>1 - 2 - 10</td>
<td class=br><strong>4</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>12 : 3</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Zaharovs Jevg�nijs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Sviklis Nikl�vs P�teris</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Meijers Roberts</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Zaharovs Jevg�nijs</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Meijers Roberts</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=blW>Zaharovs Jevg�nijs</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Meijers Roberts</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Zaharovs Jevg�nijs</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Romals Aigars</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Zaharovs Jevg�nijs</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Meijers Roberts</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Zaharovs Jevg�nijs</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Garan�s Intars</td><td class=bc>-</td><td class=bl>Meijers Roberts</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>9 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Zaharovs Jevg�nijs</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=blW>Meijers Roberts</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Romals Aigars</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=blW>Naglis Kristaps</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Meijers Roberts</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Zaharovs Jevg�nijs</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kalni�� Rainers</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Meijers Roberts</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=blW>Kuz�ecovs Andrejs</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Zaharovs Jevg�nijs</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=blW>Garan�s Intars</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Romals Aigars</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Meijers Roberts</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Garan�s Intars</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Zaharovs Jevg�nijs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Meijers Roberts</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Kuz�ecovs Andrejs</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Garan�s Intars</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Meijers Roberts</td><td class=bc>-</td><td class=blW>Kuz�ecovs Andrejs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Garan�s Intars</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=blW>Zaharovs Jevg�nijs</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Meijers Roberts</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Garan�s Intars</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Zaharovs Jevg�nijs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>1 : 10</tr></td>
<tr><td class=brW>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Meijers Roberts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Zarinieks Kristaps</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=bl>Zaharovs Jevg�nijs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>11 : 3</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Meijers Roberts</td><td class=bc>-</td><td class=blW>Zaharovs Jevg�nijs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Sviklis Nikl�vs P�teris</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Stac�vi�s Reinis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>4 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group LC B grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>An Liepi��</td><td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=br>45:20</td><td class=br>+25</td>
<td class=bc>11 - 0 - 2</td>
<td class=br><strong>22</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ra Miglinieks</td><td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=kL>3:6</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=kW>8:1</td>
<td class=kW>4:0</td>
<td class=br>53:24</td><td class=br>+29</td>
<td class=bc>9 - 1 - 3</td>
<td class=br><strong>19</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Sa Krasts</td><td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=br>35:18</td><td class=br>+17</td>
<td class=bc>9 - 1 - 3</td>
<td class=br><strong>19</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ro Rieksti��</td><td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=br>47:26</td><td class=br>+21</td>
<td class=bc>8 - 1 - 4</td>
<td class=br><strong>17</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ed Ka�eps</td><td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=br>39:34</td><td class=br>+5</td>
<td class=bc>7 - 2 - 4</td>
<td class=br><strong>16</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Sa Kalni��</td><td class=kW>5:2</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>7:3</td>
<td class=kW>7:2</td>
<td class=br>40:30</td><td class=br>+10</td>
<td class=bc>7 - 2 - 4</td>
<td class=br><strong>16</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>He Prokuratovs</td><td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>6:0</td>
<td class=kW>5:4</td>
<td class=kW>8:2</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=br>44:30</td><td class=br>+14</td>
<td class=bc>8 - 0 - 5</td>
<td class=br><strong>16</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>El R�cen�ja</td><td class=kL>1:3</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>7:4</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kL>1:4</td>
<td class=kW>1:0</td>
<td class=br>33:42</td><td class=br>-9</td>
<td class=bc>6 - 1 - 6</td>
<td class=br><strong>13</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ra Stern�ts</td><td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kW>3:0</td>
<td class=br>22:35</td><td class=br>-13</td>
<td class=bc>5 - 1 - 7</td>
<td class=br><strong>11</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Iv �irsis</td><td class=kL>1:4</td>
<td class=kW>6:3</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>4:5</td>
<td class=kL>4:7</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=br>37:39</td><td class=br>-2</td>
<td class=bc>4 - 1 - 8</td>
<td class=br><strong>9</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ra Martu��ns</td><td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>2:7</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kW>2:1</td>
<td class=kL>2:8</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kL>1:7</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=br>23:55</td><td class=br>-32</td>
<td class=bc>3 - 2 - 8</td>
<td class=br><strong>8</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>J� Z�l�te</td><td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=br>33:43</td><td class=br>-10</td>
<td class=bc>3 - 1 - 9</td>
<td class=br><strong>7</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Ed Ern�teins</td><td class=kL>1:3</td>
<td class=kL>1:8</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kL>3:7</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=br>28:52</td><td class=br>-24</td>
<td class=bc>3 - 0 - 10</td>
<td class=br><strong>6</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>J� Zem�ickis</td><td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>2:7</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=br>12:43</td><td class=br>-31</td>
<td class=bc>1 - 1 - 11</td>
<td class=br><strong>3</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ern�teins Edgars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Z�l�te J�nis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Stern�ts Raivis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>2 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ern�teins Edgars</td><td class=bc>-</td><td class=blW>Z�l�te J�nis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Stern�ts Raivis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>4 : 7</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Liepi�� Andris</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Zem�ickis J�nis</td><td class=bc>-</td><td class=bl>Z�l�te J�nis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Stern�ts Raivis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ern�teins Edgars</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Miglinieks Raivis</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Z�l�te J�nis</td><td class=bc>-</td><td class=blW>Stern�ts Raivis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ern�teins Edgars</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Stern�ts Raivis</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Z�l�te J�nis</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Miglinieks Raivis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ern�teins Edgars</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Stern�ts Raivis</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Z�l�te J�nis</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ern�teins Edgars</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Miglinieks Raivis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Stern�ts Raivis</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Z�l�te J�nis</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ern�teins Edgars</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Miglinieks Raivis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Stern�ts Raivis</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Z�l�te J�nis</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Stern�ts Raivis</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Z�l�te J�nis</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Ern�teins Edgars</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Stern�ts Raivis</td><td class=bc>-</td><td class=blW>Ern�teins Edgars</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Z�l�te J�nis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Ern�teins Edgars</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Stern�ts Raivis</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Ern�teins Edgars</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Z�l�te J�nis</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Ern�teins Edgars</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Z�l�te J�nis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Stern�ts Raivis</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Ern�teins Edgars</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Z�l�te J�nis</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Stern�ts Raivis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Ern�teins Edgars</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Z�l�te J�nis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Stern�ts Raivis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>7 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group LC C grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Sa Lagzdi��</td><td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kW>6:1</td>
<td class=kW>4:3</td>
<td class=kW>7:3</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=br>56:28</td><td class=br>+28</td>
<td class=bc>10 - 3 - 0</td>
<td class=br><strong>23</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Al Sili��</td><td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>6:5</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>7:0</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=br>51:26</td><td class=br>+25</td>
<td class=bc>9 - 2 - 2</td>
<td class=br><strong>20</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ma Jakseboga</td><td class=kL>3:6</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>5:5</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=br>44:32</td><td class=br>+12</td>
<td class=bc>7 - 4 - 2</td>
<td class=br><strong>18</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Kr Lagzdi�a</td><td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kL>2:5</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>9:1</td>
<td class=br>34:23</td><td class=br>+11</td>
<td class=bc>7 - 3 - 3</td>
<td class=br><strong>17</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>J� Bitmanis</td><td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=br>27:22</td><td class=br>+5</td>
<td class=bc>6 - 3 - 4</td>
<td class=br><strong>15</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Se Mihejevs</td><td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>8:1</td>
<td class=br>33:25</td><td class=br>+8</td>
<td class=bc>5 - 4 - 4</td>
<td class=br><strong>14</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Al Skudr�tis</td><td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kL>0:3</td>
<td class=kW>7:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>9:3</td>
<td class=br>43:32</td><td class=br>+11</td>
<td class=bc>6 - 2 - 5</td>
<td class=br><strong>14</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ro Fa�ken�teins</td><td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=br>27:27</td><td class=br>0</td>
<td class=bc>6 - 1 - 6</td>
<td class=br><strong>13</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Gu Ern�teins</td><td class=kL>4:5</td>
<td class=kL>5:6</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=br>32:34</td><td class=br>-2</td>
<td class=bc>5 - 3 - 5</td>
<td class=br><strong>13</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>To Jakseboga</td><td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kT>5:5</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=br>31:36</td><td class=br>-5</td>
<td class=bc>4 - 3 - 6</td>
<td class=br><strong>11</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ka Vi�ums</td><td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>2:7</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kW>1:0</td>
<td class=kW>5:2</td>
<td class=br>23:35</td><td class=br>-12</td>
<td class=bc>4 - 2 - 7</td>
<td class=br><strong>10</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>Ro Aseri��</td><td class=kL>3:7</td>
<td class=kL>0:7</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=br>14:38</td><td class=br>-24</td>
<td class=bc>0 - 6 - 7</td>
<td class=br><strong>6</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Fr Platons</td><td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=br>15:31</td><td class=br>-16</td>
<td class=bc>1 - 3 - 9</td>
<td class=br><strong>5</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>J� Rekti��</td><td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>1:9</td>
<td class=kL>2:5</td>
<td class=kL>1:8</td>
<td class=kL>3:9</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=br>23:64</td><td class=br>-41</td>
<td class=bc>1 - 1 - 11</td>
<td class=br><strong>3</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ern�teins Guntis</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ern�teins Guntis</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ern�teins Guntis</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ern�teins Guntis</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ern�teins Guntis</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Rekti�� J�nis</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Ern�teins Guntis</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Ern�teins Guntis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Ern�teins Guntis</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Bitmanis J�nis Mi�elis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Ern�teins Guntis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Bitmanis J�nis Mi�elis</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Ern�teins Guntis</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Ern�teins Guntis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Vi�ums Kaspars</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>3 : 9</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Ern�teins Guntis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ern�teins Guntis</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Vi�ums Kaspars</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>8 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ern�teins Guntis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>3 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group LC D grupa</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Al �ernovojs</td><td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=br>45:29</td><td class=br>+16</td>
<td class=bc>8 - 2 - 3</td>
<td class=br><strong>18</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Da Baumanis</td><td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>0:5</td>
<td class=kL>3:6</td>
<td class=kW>6:4</td>
<td class=kL>0:1</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=br>37:33</td><td class=br>+4</td>
<td class=bc>8 - 1 - 4</td>
<td class=br><strong>17</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Re Vazoli��</td><td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>6:2</td>
<td class=kT>1:1</td>
<td class=br>47:24</td><td class=br>+23</td>
<td class=bc>7 - 3 - 3</td>
<td class=br><strong>17</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ar Zasurcevs</td><td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kW>6:3</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=br>45:36</td><td class=br>+9</td>
<td class=bc>6 - 4 - 3</td>
<td class=br><strong>16</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ed Naglis</td><td class=kW>5:2</td>
<td class=kL>3:5</td>
<td class=kL>0:5</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kT>5:5</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=br>45:42</td><td class=br>+3</td>
<td class=bc>5 - 6 - 2</td>
<td class=br><strong>16</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ra Kuha�skis</td><td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>8:1</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kL>4:5</td>
<td class=kW>9:3</td>
<td class=kW>3:1</td>
<td class=br>46:35</td><td class=br>+11</td>
<td class=bc>6 - 3 - 4</td>
<td class=br><strong>15</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Kr Zem�ickis</td><td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=br>32:28</td><td class=br>+4</td>
<td class=bc>7 - 1 - 5</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>J� Re�is</td><td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>7:1</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=br>41:32</td><td class=br>+9</td>
<td class=bc>6 - 3 - 4</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Em Liepi��</td><td class=kL>3:4</td>
<td class=kW>6:3</td>
<td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kT>5:5</td>
<td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kL>0:1</td>
<td class=br>41:39</td><td class=br>+2</td>
<td class=bc>5 - 3 - 5</td>
<td class=br><strong>13</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ra Neija</td><td class=kL>2:5</td>
<td class=kL>4:6</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>1:7</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=br>31:37</td><td class=br>-6</td>
<td class=bc>4 - 3 - 6</td>
<td class=br><strong>11</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Marg �bele</td><td class=kL>1:6</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=br>21:37</td><td class=br>-16</td>
<td class=bc>2 - 5 - 6</td>
<td class=br><strong>9</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>Il �irse</td><td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kW>5:4</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=br>27:44</td><td class=br>-17</td>
<td class=bc>3 - 2 - 8</td>
<td class=br><strong>8</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>�v Vikmanis</td><td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>3:9</td>
<td class=kL>0:1</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=br>23:51</td><td class=br>-28</td>
<td class=bc>2 - 2 - 9</td>
<td class=br><strong>6</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>K� Puri��</td><td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=br>16:30</td><td class=br>-14</td>
<td class=bc>1 - 4 - 8</td>
<td class=br><strong>6</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Neija Rainers</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>�irse Ilze</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Puri�� K�rlis</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Vikmanis �ve</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>�irse Ilze</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Puri�� K�rlis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Neija Rainers</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Puri�� K�rlis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Neija Rainers</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Puri�� K�rlis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=bl>Neija Rainers</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Puri�� K�rlis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Neija Rainers</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Puri�� K�rlis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>Neija Rainers</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Puri�� K�rlis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Neija Rainers</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Puri�� K�rlis</td><td class=bc>-</td><td class=blW>Neija Rainers</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>3 : 9</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>6 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Neija Rainers</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Puri�� K�rlis</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Neija Rainers</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Puri�� K�rlis</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Neija Rainers</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Puri�� K�rlis</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Neija Rainers</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Puri�� K�rlis</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Neija Rainers</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Puri�� K�rlis</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Neija Rainers</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Puri�� K�rlis</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>1 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
<p class=v>Group 1.l�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>25</td>
<td class=ic>26</td>
<td class=ic>27</td>
<td class=ic>28</td>
<td class=ic>29</td>
<td class=ic>30</td>
<td class=ic>31</td>
<td class=ic>32</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt>Ra Kalni��</td><td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>6:1</td>
<td class=kW>4:3</td>
<td class=kW>8:1</td>
<td class=kW>8:2 K</td>
<td class=kW>11:3</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>6:5</td>
<td class=kW>5:4</td>
<td class=kW>7:4</td>
<td class=kW>4:0</td>
<td class=kW>7:3</td>
<td class=kW>6:3</td>
<td class=kW>8:0</td>
<td class=kW>6:2</td>
<td class=kW>4:2 K</td>
<td class=kW>6:2 K</td>
<td class=kW>14:3</td>
<td class=kW>5:3</td>
<td class=kW>7:2</td>
<td class=kW>10:3</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>7:2</td>
<td class=kW>7:2</td>
<td class=kW>10:1 K</td>
<td class=kW>9:2 K</td>
<td class=kW>11:3 K</td>
<td class=kW>7:4 K</td>
<td class=br>211:72</td><td class=br>+139</td>
<td class=bc>30 - 0 - 1</td>
<td class=br><strong>60</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt>Ra Miglinieks</td><td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:2 K</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kT>3:3 K</td>
<td class=kL>3:4 K</td>
<td class=kL>3:4 K</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kW>3:2 K</td>
<td class=kW>4:1 K</td>
<td class=kT>5:5</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>8:3</td>
<td class=kW>7:0 K</td>
<td class=kW>8:4</td>
<td class=kL>2:4</td>
<td class=kW>9:2</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=br>121:62</td><td class=br>+59</td>
<td class=bc>22 - 4 - 5</td>
<td class=br><strong>48</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt>J� Re�is</td><td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>7:2</td>
<td class=kT>4:4 K</td>
<td class=kW>4:1</td>
<td class=kW>3:1 K</td>
<td class=kW>3:2 K</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kT>3:3 K</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kL>1:2 K</td>
<td class=kL>2:4</td>
<td class=kW>5:0 K</td>
<td class=kW>3:0</td>
<td class=kL>1:6 K</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>101:54</td><td class=br>+47</td>
<td class=bc>20 - 5 - 6</td>
<td class=br><strong>45</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt>An Liepi��</td><td class=kL>3:4</td>
<td class=kL>2:3 K</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>4:2 K</td>
<td class=kW>2:1 K</td>
<td class=kW>4:1 K</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kW>3:2 K</td>
<td class=kL>2:5 K</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1 K</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=br>106:64</td><td class=br>+42</td>
<td class=bc>22 - 1 - 8</td>
<td class=br><strong>45</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>Al Sili��</td><td class=kL>1:8</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kT>3:3 K</td>
<td class=kW>1:0</td>
<td class=kL>2:3 K</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kT>4:4 K</td>
<td class=kW>3:1 K</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>6:3</td>
<td class=kW>6:3</td>
<td class=kL>1:3 K</td>
<td class=kW>3:2 K</td>
<td class=kL>2:6</td>
<td class=kW>2:0 K</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>8:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>98:74</td><td class=br>+24</td>
<td class=bc>17 - 6 - 8</td>
<td class=br><strong>40</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>El Sili��</td><td class=kL>2:8 K</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kW>8:4</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kW>3:2 K</td>
<td class=kW>4:2 K</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>2:1 K</td>
<td class=kW>4:1 K</td>
<td class=kW>5:2 K</td>
<td class=kW>6:2 K</td>
<td class=br>87:74</td><td class=br>+13</td>
<td class=bc>16 - 6 - 9</td>
<td class=br><strong>38</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Ed Ka�eps</td><td class=kL>3:11</td>
<td class=kT>3:3 K</td>
<td class=kT>1:1</td>
<td class=kL>2:4 K</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:1 K</td>
<td class=kL>1:6 K</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kL>1:3 K</td>
<td class=kW>4:1 K</td>
<td class=kL>1:5</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kL>2:5</td>
<td class=kW>8:3</td>
<td class=kW>7:3</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>4:2 K</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kL>3:10</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=br>104:94</td><td class=br>+10</td>
<td class=bc>16 - 6 - 9</td>
<td class=br><strong>38</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>He Prokuratovs</td><td class=kL>0:5</td>
<td class=kW>4:3 K</td>
<td class=kL>0:5</td>
<td class=kL>1:2 K</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kL>1:4 K</td>
<td class=kx>*</td>
<td class=kW>3:1 K</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kL>0:2 K</td>
<td class=kL>2:4 K</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>7:4</td>
<td class=kW>4:1</td>
<td class=kW>9:2</td>
<td class=kL>3:4 K</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>6:4</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=br>93:80</td><td class=br>+13</td>
<td class=bc>18 - 1 - 12</td>
<td class=br><strong>37</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>Ro Rieksti��</td><td class=kL>2:4</td>
<td class=kW>4:3 K</td>
<td class=kL>1:2</td>
<td class=kL>1:4 K</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>6:1 K</td>
<td class=kL>1:3 K</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>0:2 K</td>
<td class=kT>2:2 K</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kW>5:4</td>
<td class=kT>3:3</td>
<td class=kW>8:0</td>
<td class=kW>5:2 K</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=br>100:68</td><td class=br>+32</td>
<td class=bc>15 - 6 - 10</td>
<td class=br><strong>36</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Sa Lagzdi��</td><td class=kL>2:7</td>
<td class=kW>4:2</td>
<td class=kL>2:7</td>
<td class=kW>4:2</td>
<td class=kT>3:3 K</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>5:2 K</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>6:3 K</td>
<td class=kT>3:3 K</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1 K</td>
<td class=kL>2:3</td>
<td class=kW>5:1 K</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=br>101:83</td><td class=br>+18</td>
<td class=bc>14 - 8 - 9</td>
<td class=br><strong>36</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>Ed Naglis</td><td class=kL>5:6</td>
<td class=kT>2:2</td>
<td class=kT>4:4 K</td>
<td class=kL>0:4</td>
<td class=kL>0:1</td>
<td class=kW>3:0</td>
<td class=kL>2:5</td>
<td class=kW>5:2</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kL>0:5 K</td>
<td class=kW>5:2 K</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kL>2:5</td>
<td class=kT>4:4 K</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kT>3:3 K</td>
<td class=kT>3:3</td>
<td class=kL>3:5 K</td>
<td class=kW>6:1</td>
<td class=kT>2:2 K</td>
<td class=kW>9:2</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>107:87</td><td class=br>+20</td>
<td class=bc>14 - 7 - 10</td>
<td class=br><strong>35</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>Al Skudr�tis</td><td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>3:2 K</td>
<td class=kL>4:8</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>2:5 K</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kT>2:2 K</td>
<td class=kL>1:2 K</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>5:4</td>
<td class=kW>2:0</td>
<td class=kW>5:2 K</td>
<td class=kW>5:2 K</td>
<td class=kT>3:3</td>
<td class=kL>0:3 K</td>
<td class=kW>4:3</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kL>4:5</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=br>96:91</td><td class=br>+5</td>
<td class=bc>15 - 5 - 11</td>
<td class=br><strong>35</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt>Re Vazoli��</td><td class=kL>4:7</td>
<td class=kL>1:3</td>
<td class=kL>1:3 K</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>5:0 K</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>2:3 K</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kW>4:2 K</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>6:1 K</td>
<td class=kW>5:2</td>
<td class=kL>2:4 K</td>
<td class=kW>3:2</td>
<td class=kW>6:0 K</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>89:67</td><td class=br>+22</td>
<td class=bc>14 - 6 - 11</td>
<td class=br><strong>34</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt>Al �ernovojs</td><td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>2:3 K</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>2:5 K</td>
<td class=kL>2:5</td>
<td class=kW>3:2 K</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>3:2 K</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kT>3:3 K</td>
<td class=kW>4:1</td>
<td class=kL>1:2 K</td>
<td class=kT>3:3</td>
<td class=kW>4:1 K</td>
<td class=kW>1:0</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>80:76</td><td class=br>+4</td>
<td class=bc>12 - 8 - 11</td>
<td class=br><strong>32</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt>Ma Jakseboga</td><td class=kL>3:7</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kT>4:4 K</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kL>3:6 K</td>
<td class=kL>3:4</td>
<td class=kT>2:2 K</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:2 K</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kL>4:6</td>
<td class=kW>6:3</td>
<td class=kW>5:3</td>
<td class=kW>4:0 K</td>
<td class=kW>3:2 K</td>
<td class=kL>1:5</td>
<td class=kW>4:1 K</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>91:82</td><td class=br>+9</td>
<td class=bc>15 - 2 - 14</td>
<td class=br><strong>32</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt>Se Mihejevs</td><td class=kL>3:6</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kW>1:0</td>
<td class=kL>1:3 K</td>
<td class=kW>3:1</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3 K</td>
<td class=kL>2:3</td>
<td class=kW>2:1 K</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>2:5 K</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>1:0 K</td>
<td class=kL>0:1 K</td>
<td class=kW>2:1</td>
<td class=kT>2:2 K</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kL>0:1</td>
<td class=kW>1:0</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=br>56:58</td><td class=br>-2</td>
<td class=bc>13 - 6 - 12</td>
<td class=br><strong>32</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Sa Krasts</td><td class=kL>0:8</td>
<td class=kL>2:3 K</td>
<td class=kL>0:6</td>
<td class=kL>2:3 K</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kW>3:1 K</td>
<td class=kW>2:0 K</td>
<td class=kW>2:0 K</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kL>1:2 K</td>
<td class=kT>1:1</td>
<td class=kW>5:4</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1 K</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=br>61:75</td><td class=br>-14</td>
<td class=bc>13 - 5 - 13</td>
<td class=br><strong>31</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Sa Kalni��</td><td class=kL>2:6</td>
<td class=kL>1:4 K</td>
<td class=kL>2:4</td>
<td class=kW>5:2 K</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>1:4 K</td>
<td class=kW>4:2 K</td>
<td class=kT>2:2 K</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kW>2:1 K</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>2:3 K</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=br>80:80</td><td class=br>0</td>
<td class=bc>11 - 8 - 12</td>
<td class=br><strong>30</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Je Zaharovs</td><td class=kL>2:4 K</td>
<td class=kT>5:5</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>2:3 K</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kW>6:4</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kL>1:3 K</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kW>7:1</td>
<td class=kW>2:0</td>
<td class=kT>2:2 K</td>
<td class=kW>6:2 K</td>
<td class=kW>4:0 K</td>
<td class=kW>3:0 K</td>
<td class=br>84:84</td><td class=br>0</td>
<td class=bc>10 - 8 - 13</td>
<td class=br><strong>28</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Mi Saul�tis</td><td class=kL>2:6 K</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kL>3:6</td>
<td class=kL>2:4 K</td>
<td class=kL>0:5</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kL>4:5</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=kL>4:5</td>
<td class=kL>3:5</td>
<td class=kW>3:1 K</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=kL>2:3</td>
<td class=kW>7:2</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kL>5:6 K</td>
<td class=kW>5:3 K</td>
<td class=kL>2:3 K</td>
<td class=kW>4:3 K</td>
<td class=br>105:110</td><td class=br>-5</td>
<td class=bc>12 - 3 - 16</td>
<td class=br><strong>27</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Ar Zasurcevs</td><td class=kL>3:14</td>
<td class=kL>2:6</td>
<td class=kT>3:3 K</td>
<td class=kL>1:5</td>
<td class=kL>3:6</td>
<td class=kL>4:5</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kT>4:4 K</td>
<td class=kL>0:2</td>
<td class=kL>2:4 K</td>
<td class=kL>2:3 K</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kL>2:3</td>
<td class=kW>4:1 K</td>
<td class=kT>4:4</td>
<td class=kW>4:1 K</td>
<td class=kL>0:2</td>
<td class=kW>4:2 K</td>
<td class=kW>3:0</td>
<td class=kL>3:7</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>87:102</td><td class=br>-15</td>
<td class=bc>11 - 5 - 15</td>
<td class=br><strong>27</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Kr Lagzdi�a</td><td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>2:6</td>
<td class=kW>3:1 K</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kT>2:2 K</td>
<td class=kW>3:2</td>
<td class=kL>2:5 K</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>0:4 K</td>
<td class=kL>0:1 K</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kL>3:6</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>2:0 K</td>
<td class=kW>4:2</td>
<td class=kW>2:1 K</td>
<td class=kW>1:0</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=br>70:78</td><td class=br>-8</td>
<td class=bc>11 - 5 - 15</td>
<td class=br><strong>27</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Ro Fa�ken�teins</td><td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>1:6</td>
<td class=kL>2:3 K</td>
<td class=kW>3:0</td>
<td class=kL>3:8</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kL>1:2 K</td>
<td class=kL>2:4</td>
<td class=kL>2:5 K</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>2:3 K</td>
<td class=kW>1:0 K</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kL>0:2 K</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kT>2:2 K</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>61:81</td><td class=br>-20</td>
<td class=bc>11 - 5 - 15</td>
<td class=br><strong>27</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Ra Kuha�skis</td><td class=kL>3:10</td>
<td class=kL>3:4</td>
<td class=kW>2:1 K</td>
<td class=kL>1:5</td>
<td class=kW>6:2</td>
<td class=kL>1:5</td>
<td class=kL>3:7</td>
<td class=kL>4:7</td>
<td class=kL>4:5</td>
<td class=kW>3:2</td>
<td class=kT>3:3 K</td>
<td class=kT>3:3</td>
<td class=kL>1:6 K</td>
<td class=kT>3:3 K</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kL>1:7</td>
<td class=kL>1:4 K</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:4 K</td>
<td class=kL>2:3</td>
<td class=kW>4:2 K</td>
<td class=kL>5:7</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>92:106</td><td class=br>-14</td>
<td class=bc>11 - 4 - 16</td>
<td class=br><strong>26</strong></td><td class=d>24.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>25.</td><td class=kt>J� Bitmanis</td><td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>0:2 K</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>1:5 K</td>
<td class=kT>3:3</td>
<td class=kW>3:0 K</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:4 K</td>
<td class=kT>2:2 K</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kL>1:2 K</td>
<td class=kT>2:2 K</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kT>5:5</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>69:81</td><td class=br>-12</td>
<td class=bc>8 - 10 - 13</td>
<td class=br><strong>26</strong></td><td class=d>25.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>26.</td><td class=kt>Da Baumanis</td><td class=kL>2:6</td>
<td class=kL>3:8</td>
<td class=kL>0:5 K</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>2:9</td>
<td class=kL>0:8</td>
<td class=kL>1:4</td>
<td class=kW>5:3 K</td>
<td class=kL>3:4</td>
<td class=kW>4:2 K</td>
<td class=kW>2:1 K</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kL>2:7</td>
<td class=kL>1:4 K</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kW>4:2 K</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kT>5:5</td>
<td class=kW>3:2 K</td>
<td class=kL>1:3</td>
<td class=kT>6:6</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>75:105</td><td class=br>-30</td>
<td class=bc>10 - 5 - 16</td>
<td class=br><strong>25</strong></td><td class=d>26.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>27.</td><td class=kt>El R�cen�ja</td><td class=kL>2:7</td>
<td class=kL>0:7 K</td>
<td class=kL>0:3</td>
<td class=kL>1:3 K</td>
<td class=kL>2:7</td>
<td class=kL>3:4</td>
<td class=kL>2:4 K</td>
<td class=kW>4:3 K</td>
<td class=kL>2:5 K</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3 K</td>
<td class=kW>3:2 K</td>
<td class=kL>1:7</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kT>5:5</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kW>6:5</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>76:110</td><td class=br>-34</td>
<td class=bc>10 - 4 - 17</td>
<td class=br><strong>24</strong></td><td class=d>27.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>28.</td><td class=kt>Kr Zem�ickis</td><td class=kL>2:7</td>
<td class=kL>4:8</td>
<td class=kW>6:1 K</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kT>2:2 K</td>
<td class=kW>4:1</td>
<td class=kL>0:6 K</td>
<td class=kL>1:4 K</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kL>3:5</td>
<td class=kL>2:4 K</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>2:4 K</td>
<td class=kL>2:4</td>
<td class=kL>2:3 K</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>76:98</td><td class=br>-22</td>
<td class=bc>10 - 3 - 18</td>
<td class=br><strong>23</strong></td><td class=d>28.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>29.</td><td class=kt>Ri Kalni��</td><td class=kL>1:10 K</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>1:2 K</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>2:9</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kW>1:0</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2 K</td>
<td class=kW>6:5 K</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kW>7:5</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>5:1 K</td>
<td class=kW>3:2 K</td>
<td class=kL>3:4 K</td>
<td class=br>66:104</td><td class=br>-38</td>
<td class=bc>8 - 2 - 21</td>
<td class=br><strong>18</strong></td><td class=d>29.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>30.</td><td class=kt>An Kuz�ecovs</td><td class=kL>2:9 K</td>
<td class=kL>2:9</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kL>2:8</td>
<td class=kL>1:4 K</td>
<td class=kW>10:3</td>
<td class=kL>4:6</td>
<td class=kL>1:6</td>
<td class=kW>5:3</td>
<td class=kL>3:5</td>
<td class=kW>5:4</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kL>2:6 K</td>
<td class=kL>3:5 K</td>
<td class=kW>7:3</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kT>5:5</td>
<td class=kT>6:6</td>
<td class=kL>5:6</td>
<td class=kL>2:5</td>
<td class=kL>1:5 K</td>
<td class=kx>*</td>
<td class=kW>5:0 K</td>
<td class=kL>2:5 K</td>
<td class=br>92:144</td><td class=br>-52</td>
<td class=bc>7 - 2 - 22</td>
<td class=br><strong>16</strong></td><td class=d>30.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>31.</td><td class=kt>In Garan�s</td><td class=kL>3:11 K</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>2:5 K</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:4 K</td>
<td class=kW>3:2 K</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>2:3 K</td>
<td class=kL>0:5 K</td>
<td class=kx>*</td>
<td class=kW>4:3 K</td>
<td class=br>40:130</td><td class=br>-90</td>
<td class=bc>4 - 0 - 27</td>
<td class=br><strong>8</strong></td><td class=d>31.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>32.</td><td class=kt>Ni Sviklis</td><td class=kL>4:7 K</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>2:6 K</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>0:3 K</td>
<td class=kL>3:4 K</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kW>4:3 K</td>
<td class=kW>5:2 K</td>
<td class=kL>3:4 K</td>
<td class=kx>*</td>
<td class=br>34:135</td><td class=br>-101</td>
<td class=bc>2 - 2 - 27</td>
<td class=br><strong>6</strong></td><td class=d>32.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Zaharovs Jevg�nijs</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Miglinieks Raivis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Kalni�� Sandis</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Zaharovs Jevg�nijs</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>10 : 3</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Zaharovs Jevg�nijs</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kalni�� Rainers</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Zaharovs Jevg�nijs</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>2 : 9</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Liepi�� Andris</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Zaharovs Jevg�nijs</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Zaharovs Jevg�nijs</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>5 : 6</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Krasts Sandis</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Jakseboga Mat�ss</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Zaharovs Jevg�nijs</td><td class=bc>-</td><td class=bl>Miglinieks Raivis</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>R�cen�ja El�na</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Mihejevs Sergejs</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Prokuratovs Henrijs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Ka�eps Ed�us</td><td class=bc>11 : 3</tr></td>
<tr><td class=brW>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Rieksti�� Rolands</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Sili�� Alvis</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=blW>Miglinieks Raivis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Sili�� Alvis</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Liepi�� Andris</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Jakseboga Mat�ss</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Zaharovs Jevg�nijs</td><td class=bc>-</td><td class=bl>R�cen�ja El�na</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Garan�s Intars</td><td class=bc>-</td><td class=bl>Prokuratovs Henrijs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Bitmanis J�nis Mi�elis</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Kalni�� Sandis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Mihejevs Sergejs</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Ka�eps Ed�us</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Rieksti�� Rolands</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Fa�ken�teins Rom�ns</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Krasts Sandis</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Lagzdi�� Sandis Kristaps</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Zaharovs Jevg�nijs</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Bitmanis J�nis Mi�elis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Liepi�� Andris</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Bitmanis J�nis Mi�elis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Zaharovs Jevg�nijs</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=blW>Baumanis Danilo</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Zaharovs Jevg�nijs</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Liepi�� Andris</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>�ernovojs Aleksandrs</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Zaharovs Jevg�nijs</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Bitmanis J�nis Mi�elis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Kalni�� Ri�ards</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Saul�tis Mikus</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Zaharovs Jevg�nijs</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>6 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=blW>Zem�ickis Kri�j�nis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Zaharovs Jevg�nijs</td><td class=bc>-</td><td class=blW>Bitmanis J�nis Mi�elis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Garan�s Intars</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Kuha�skis Railends</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Zasurcevs Art�rs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Zaharovs Jevg�nijs</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>�ernovojs Aleksandrs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Baumanis Danilo</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>Zasurcevs Art�rs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Kuha�skis Railends</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Zem�ickis Kri�j�nis</td><td class=bc>8 : 4</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Zaharovs Jevg�nijs</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Garan�s Intars</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Sviklis Nikl�vs P�teris</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Kalni�� Ri�ards</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kuz�ecovs Andrejs</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Kalni�� Rainers</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Sili�� Elvijs</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>8 : 4</tr></td>
<tr><td class=brW>Saul�tis Mikus</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Liepi�� Andris</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Zaharovs Jevg�nijs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Prokuratovs Henrijs</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Zaharovs Jevg�nijs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Zaharovs Jevg�nijs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Miglinieks Raivis</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>Kuz�ecovs Andrejs</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Zaharovs Jevg�nijs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>6 : 6</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Zaharovs Jevg�nijs</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kuha�skis Railends</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Miglinieks Raivis</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Sili�� Alvis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>5 : 7</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Lagzdi�� Sandis Kristaps</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=blW>Sili�� Elvijs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Krasts Sandis</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Zaharovs Jevg�nijs</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=bl>Mihejevs Sergejs</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Rieksti�� Rolands</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Zasurcevs Art�rs</td><td class=bc>-</td><td class=bl>Kalni�� Ri�ards</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Fa�ken�teins Rom�ns</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>3 : 10</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>R�cen�ja El�na</td><td class=bc>-</td><td class=bl>Jakseboga Mat�ss</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Saul�tis Mikus</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Liepi�� Andris</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Zaharovs Jevg�nijs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Bitmanis J�nis Mi�elis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Baumanis Danilo</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=brW>Miglinieks Raivis</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Baumanis Danilo</td><td class=bc>-</td><td class=blW>Kalni�� Ri�ards</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Krasts Sandis</td><td class=bc>-</td><td class=blW>Fa�ken�teins Rom�ns</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Kuz�ecovs Andrejs</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Rieksti�� Rolands</td><td class=bc>-</td><td class=bl>Lagzdi�� Sandis Kristaps</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Zasurcevs Art�rs</td><td class=bc>-</td><td class=blW>Kalni�� Rainers</td><td class=bc>3 : 14</tr></td>
<tr><td class=br>Ka�eps Ed�us</td><td class=bc>-</td><td class=bl>Sili�� Alvis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Sili�� Elvijs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kalni�� Sandis</td><td class=bc>-</td><td class=blW>Jakseboga Mat�ss</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Kuha�skis Railends</td><td class=bc>-</td><td class=blW>Saul�tis Mikus</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Prokuratovs Henrijs</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Zem�ickis Kri�j�nis</td><td class=bc>-</td><td class=blW>Zaharovs Jevg�nijs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>R�cen�ja El�na</td><td class=bc>-</td><td class=blW>Bitmanis J�nis Mi�elis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Garan�s Intars</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Liepi�� Andris</td><td class=bc>-</td><td class=blW>Mihejevs Sergejs</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>�ernovojs Aleksandrs</td><td class=bc>-</td><td class=bl>Sviklis Nikl�vs P�teris</td><td class=bc>5 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 2.l�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>33</td>
<td class=ic>34</td>
<td class=ic>35</td>
<td class=ic>36</td>
<td class=ic>37</td>
<td class=ic>38</td>
<td class=ic>39</td>
<td class=ic>40</td>
<td class=ic>41</td>
<td class=ic>42</td>
<td class=ic>43</td>
<td class=ic>44</td>
<td class=ic>45</td>
<td class=ic>46</td>
<td class=ic>47</td>
<td class=ic>48</td>
<td class=ic>49</td>
<td class=ic>50</td>
<td class=ic>51</td>
<td class=ic>52</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>33.</td><td class=kt>Em Liepi��</td><td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>6:3</td>
<td class=kL>3:7</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>7:4</td>
<td class=kW>6:1</td>
<td class=kW>7:0</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>5:4</td>
<td class=kW>8:2</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=br>98:40</td><td class=br>+58</td>
<td class=bc>16 - 0 - 3</td>
<td class=br><strong>32</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>34.</td><td class=kt>Sa Skarainis</td><td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=br>63:30</td><td class=br>+33</td>
<td class=bc>15 - 1 - 3</td>
<td class=br><strong>31</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>35.</td><td class=kt>Ra Neija</td><td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>1:0</td>
<td class=kL>3:7</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kW>7:3</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>7:3</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>71:40</td><td class=br>+31</td>
<td class=bc>13 - 2 - 4</td>
<td class=br><strong>28</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>36.</td><td class=kt>J� Z�l�te</td><td class=kW>7:3</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>4:5</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>66:47</td><td class=br>+19</td>
<td class=bc>12 - 0 - 7</td>
<td class=br><strong>24</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=d>37.</td><td class=kt>Ra Martu��ns</td><td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>7:0</td>
<td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>56:43</td><td class=br>+13</td>
<td class=bc>11 - 2 - 6</td>
<td class=br><strong>24</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=d>38.</td><td class=kt>Gu Ern�teins</td><td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kW>7:3</td>
<td class=kW>5:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=br>64:52</td><td class=br>+12</td>
<td class=bc>11 - 1 - 7</td>
<td class=br><strong>23</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/4</td><td class=d>39.</td><td class=kt>Il �irse</td><td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kW>5:2</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>63:51</td><td class=br>+12</td>
<td class=bc>10 - 3 - 6</td>
<td class=br><strong>23</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/4</td><td class=d>40.</td><td class=kt>Iv �irsis</td><td class=kL>4:7</td>
<td class=kL>3:5</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>6:3</td>
<td class=kW>5:0</td>
<td class=kW>6:5</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kW>3:0</td>
<td class=kL>0:1</td>
<td class=kW>5:0</td>
<td class=br>64:50</td><td class=br>+14</td>
<td class=bc>10 - 2 - 7</td>
<td class=br><strong>22</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>41.</td><td class=kt>Marg �bele</td><td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kL>3:7</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>49:50</td><td class=br>-1</td>
<td class=bc>8 - 4 - 7</td>
<td class=br><strong>20</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>42.</td><td class=kt>Ka Vi�ums</td><td class=kL>0:7</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>7:3</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>54:47</td><td class=br>+7</td>
<td class=bc>9 - 2 - 8</td>
<td class=br><strong>20</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>43.</td><td class=kt>Ai Romals</td><td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>52:48</td><td class=br>+4</td>
<td class=bc>7 - 4 - 8</td>
<td class=br><strong>18</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>44.</td><td class=kt>Ro Meijers</td><td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kL>2:7</td>
<td class=kW>6:2</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>57:61</td><td class=br>-4</td>
<td class=bc>9 - 0 - 10</td>
<td class=br><strong>18</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>45.</td><td class=kt>Ra Stern�ts</td><td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>4:5</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kW>7:3</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=br>51:59</td><td class=br>-8</td>
<td class=bc>7 - 3 - 9</td>
<td class=br><strong>17</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>46.</td><td class=kt>Ed Ern�teins</td><td class=kL>1:6</td>
<td class=kW>4:2</td>
<td class=kL>3:7</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>2:6</td>
<td class=kL>5:6</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kT>6:6</td>
<td class=kL>1:4</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=br>57:63</td><td class=br>-6</td>
<td class=bc>7 - 3 - 9</td>
<td class=br><strong>17</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>47.</td><td class=kt>To Jakseboga</td><td class=kL>2:6</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>2:6</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>42:40</td><td class=br>+2</td>
<td class=bc>5 - 7 - 7</td>
<td class=br><strong>17</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>48.</td><td class=kt>�v Vikmanis</td><td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>41:50</td><td class=br>-9</td>
<td class=bc>7 - 2 - 10</td>
<td class=br><strong>16</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>49.</td><td class=kt>Kr Zarinieks</td><td class=kL>2:8</td>
<td class=kW>3:0</td>
<td class=kL>3:7</td>
<td class=kL>2:5</td>
<td class=kL>0:7</td>
<td class=kL>1:4</td>
<td class=kL>3:6</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kL>3:7</td>
<td class=kW>2:1</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kT>6:6</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>52:75</td><td class=br>-23</td>
<td class=bc>5 - 4 - 10</td>
<td class=br><strong>14</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>50.</td><td class=kt>Fr Platons</td><td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=br>27:58</td><td class=br>-31</td>
<td class=bc>4 - 1 - 14</td>
<td class=br><strong>9</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>51.</td><td class=kt>Ro Aseri��</td><td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kW>1:0</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=br>19:47</td><td class=br>-28</td>
<td class=bc>3 - 1 - 15</td>
<td class=br><strong>7</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>52.</td><td class=kt>Kr Naglis</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=br>0:95</td><td class=br>-95</td>
<td class=bc>0 - 0 - 19</td>
<td class=br><strong>0</strong></td><td class=d>20.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Stern�ts Raivis</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ern�teins Guntis</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Ern�teins Edgars</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Meijers Roberts</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Neija Rainers</td><td class=bc>-</td><td class=bl>Z�l�te J�nis</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Stern�ts Raivis</td><td class=bc>-</td><td class=bl>Ern�teins Edgars</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ern�teins Guntis</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Meijers Roberts</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Z�l�te J�nis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Neija Rainers</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=blW>Vi�ums Kaspars</td><td class=bc>3 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ern�teins Edgars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Stern�ts Raivis</td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ern�teins Guntis</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=blW>Z�l�te J�nis</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Meijers Roberts</td><td class=bc>-</td><td class=blW>Romals Aigars</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Neija Rainers</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Platons Fredijs</td><td class=bc>-</td><td class=bl>Ern�teins Edgars</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Stern�ts Raivis</td><td class=bc>-</td><td class=blW>Z�l�te J�nis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ern�teins Guntis</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Meijers Roberts</td><td class=bc>-</td><td class=blW>Vi�ums Kaspars</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ern�teins Edgars</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Z�l�te J�nis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Stern�ts Raivis</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ern�teins Guntis</td><td class=bc>-</td><td class=blW>Vi�ums Kaspars</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Meijers Roberts</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Neija Rainers</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ern�teins Edgars</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Z�l�te J�nis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Romals Aigars</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Stern�ts Raivis</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ern�teins Guntis</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Neija Rainers</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Meijers Roberts</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>�irse Ilze</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Z�l�te J�nis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ern�teins Edgars</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Platons Fredijs</td><td class=bc>-</td><td class=bl>�bele Margarita</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Vi�ums Kaspars</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Martu��ns Rainers</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Zarinieks Kristaps</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Stern�ts Raivis</td><td class=bc>-</td><td class=blW>Neija Rainers</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ern�teins Guntis</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>7 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Z�l�te J�nis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>�irse Ilze</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ern�teins Edgars</td><td class=bc>-</td><td class=blW>Vi�ums Kaspars</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Neija Rainers</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Skarainis Salvis</td><td class=bc>-</td><td class=blW>Jakseboga Toms</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Stern�ts Raivis</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ern�teins Guntis</td><td class=bc>-</td><td class=bl>Meijers Roberts</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Z�l�te J�nis</td><td class=bc>-</td><td class=blW>Romals Aigars</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>�irse Ilze</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ern�teins Edgars</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>6 : 6</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=bl>Neija Rainers</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Meijers Roberts</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Stern�ts Raivis</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>�bele Margarita</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Z�l�te J�nis</td><td class=bc>-</td><td class=blW>Vi�ums Kaspars</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>�irse Ilze</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Neija Rainers</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ern�teins Edgars</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Vikmanis �ve</td><td class=bc>-</td><td class=bl>Meijers Roberts</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Skarainis Salvis</td><td class=bc>-</td><td class=bl>Ern�teins Guntis</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Vi�ums Kaspars</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Z�l�te J�nis</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Neija Rainers</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ern�teins Edgars</td><td class=bc>-</td><td class=bl>Meijers Roberts</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Ern�teins Guntis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Stern�ts Raivis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=blW>Martu��ns Rainers</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Neija Rainers</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Z�l�te J�nis</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>�irse Ilze</td><td class=bc>-</td><td class=bl>Meijers Roberts</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ern�teins Edgars</td><td class=bc>-</td><td class=bl>Ern�teins Guntis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Platons Fredijs</td><td class=bc>-</td><td class=bl>Stern�ts Raivis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vikmanis �ve</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Zarinieks Kristaps</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=blW>Neija Rainers</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Romals Aigars</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Z�l�te J�nis</td><td class=bc>-</td><td class=blW>Meijers Roberts</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Ern�teins Guntis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Stern�ts Raivis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ern�teins Edgars</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Platons Fredijs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=blW>Neija Rainers</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Meijers Roberts</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Z�l�te J�nis</td><td class=bc>-</td><td class=blW>Ern�teins Guntis</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>Stern�ts Raivis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ern�teins Edgars</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Neija Rainers</td><td class=bc>-</td><td class=bl>Jakseboga Toms</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>�irsis Ivars</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Meijers Roberts</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Ern�teins Guntis</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=bl>Stern�ts Raivis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Z�l�te J�nis</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�irse Ilze</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Naglis Kristaps</td><td class=bc>-</td><td class=blW>Platons Fredijs</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>�irsis Ivars</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Neija Rainers</td><td class=bc>-</td><td class=blW>Meijers Roberts</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Ern�teins Guntis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=blW>Stern�ts Raivis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Romals Aigars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Z�l�te J�nis</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>�irse Ilze</td><td class=bc>-</td><td class=bl>Ern�teins Edgars</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Meijers Roberts</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Liepi�� Em�ls</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Neija Rainers</td><td class=bc>-</td><td class=blW>Ern�teins Guntis</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=blW>Stern�ts Raivis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Skarainis Salvis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Vikmanis �ve</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Romals Aigars</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Z�l�te J�nis</td><td class=bc>-</td><td class=bl>Ern�teins Edgars</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Aseri�� Roberts</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Meijers Roberts</td><td class=bc>-</td><td class=bl>Liepi�� Em�ls</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Ern�teins Guntis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=blW>Stern�ts Raivis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Neija Rainers</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=blW>Ern�teins Edgars</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Romals Aigars</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Z�l�te J�nis</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Ern�teins Guntis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Meijers Roberts</td><td class=bc>-</td><td class=bl>Stern�ts Raivis</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>�irsis Ivars</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Jakseboga Toms</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Neija Rainers</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Martu��ns Rainers</td><td class=bc>-</td><td class=bl>Ern�teins Edgars</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>�bele Margarita</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Romals Aigars</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Ern�teins Guntis</td><td class=bc>-</td><td class=bl>Stern�ts Raivis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Liepi�� Em�ls</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Meijers Roberts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Neija Rainers</td><td class=bc>-</td><td class=bl>Ern�teins Edgars</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>�irse Ilze</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>�bele Margarita</td><td class=bc>-</td><td class=bl>Z�l�te J�nis</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Stern�ts Raivis</td><td class=bc>-</td><td class=blW>Skarainis Salvis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ern�teins Guntis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Liepi�� Em�ls</td><td class=bc>-</td><td class=bl>Vikmanis �ve</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Meijers Roberts</td><td class=bc>-</td><td class=bl>Platons Fredijs</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>�irsis Ivars</td><td class=bc>-</td><td class=bl>Ern�teins Edgars</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Jakseboga Toms</td><td class=bc>-</td><td class=bl>Naglis Kristaps</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Neija Rainers</td><td class=bc>-</td><td class=bl>�irse Ilze</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Zarinieks Kristaps</td><td class=bc>-</td><td class=bl>Aseri�� Roberts</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Martu��ns Rainers</td><td class=bc>-</td><td class=blW>Z�l�te J�nis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vi�ums Kaspars</td><td class=bc>-</td><td class=bl>Romals Aigars</td><td class=bc>2 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 3.l�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>53</td>
<td class=ic>54</td>
<td class=ic>55</td>
<td class=ic>56</td>
<td class=ic>57</td>
<td class=ic>58</td>
<td class=ic>59</td>
<td class=ic>60</td>
<td class=ic>61</td>
<td class=ic>62</td>
<td class=ic>63</td>
<td class=ic>64</td>
<td class=ic>65</td>
<td class=ic>66</td>
<td class=ic>67</td>
<td class=ic>68</td>
<td class=ic>69</td>
<td class=ic>70</td>
<td class=ic>71</td>
<td class=ic>72</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>53.</td><td class=kt>K� Puri��</td><td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=br>59:25</td><td class=br>+34</td>
<td class=bc>15 - 1 - 3</td>
<td class=br><strong>31</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>54.</td><td class=kt>Re Stac�vi�s</td><td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>62:31</td><td class=br>+31</td>
<td class=bc>13 - 3 - 3</td>
<td class=br><strong>29</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>55.</td><td class=kt>M� �irsis</td><td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kL>3:5</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=br>57:33</td><td class=br>+24</td>
<td class=bc>14 - 0 - 5</td>
<td class=br><strong>28</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>56.</td><td class=kt>Ma Krauze</td><td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>52:34</td><td class=br>+18</td>
<td class=bc>11 - 4 - 4</td>
<td class=br><strong>26</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=d>57.</td><td class=kt>Ag Pav�rs</td><td class=kL>0:3</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kW>5:3</td>
<td class=kW>2:0</td>
<td class=kW>6:2</td>
<td class=kT>0:0</td>
<td class=kL>1:2</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>56:33</td><td class=br>+23</td>
<td class=bc>11 - 3 - 5</td>
<td class=br><strong>25</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=d>58.</td><td class=kt>D� Vesele</td><td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kW>5:3</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=br>58:43</td><td class=br>+15</td>
<td class=bc>11 - 3 - 5</td>
<td class=br><strong>25</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/4</td><td class=d>59.</td><td class=kt>Ma Kalni��</td><td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kL>1:3</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>6:3</td>
<td class=kW>5:0</td>
<td class=br>47:36</td><td class=br>+11</td>
<td class=bc>11 - 2 - 6</td>
<td class=br><strong>24</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/4</td><td class=d>60.</td><td class=kt>Er Kalni��</td><td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=kL>0:1</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kL>3:5</td>
<td class=kW>2:0</td>
<td class=kW>6:3</td>
<td class=kW>1:0</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kW>7:1</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=br>54:36</td><td class=br>+18</td>
<td class=bc>11 - 2 - 6</td>
<td class=br><strong>24</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>61.</td><td class=kt>Ar Vasks</td><td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>10:5</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=br>54:40</td><td class=br>+14</td>
<td class=bc>10 - 4 - 5</td>
<td class=br><strong>24</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>62.</td><td class=kt>Ge Jansons</td><td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kL>3:6</td>
<td class=kW>5:1</td>
<td class=kW>5:4</td>
<td class=kL>0:4</td>
<td class=kW>5:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=br>50:44</td><td class=br>+6</td>
<td class=bc>10 - 3 - 6</td>
<td class=br><strong>23</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>63.</td><td class=kt>�r Egl�tis</td><td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=br>36:42</td><td class=br>-6</td>
<td class=bc>7 - 3 - 9</td>
<td class=br><strong>17</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>64.</td><td class=kt>Ra St�lmanis</td><td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>47:47</td><td class=br>0</td>
<td class=bc>6 - 4 - 9</td>
<td class=br><strong>16</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>65.</td><td class=kt>J� Rekti��</td><td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>0:1</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>32:33</td><td class=br>-1</td>
<td class=bc>6 - 4 - 9</td>
<td class=br><strong>16</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>66.</td><td class=kt>Re Saul�tis</td><td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=br>47:47</td><td class=br>0</td>
<td class=bc>7 - 1 - 11</td>
<td class=br><strong>15</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>67.</td><td class=kt>M� Timbers</td><td class=kW>3:2</td>
<td class=kL>2:7</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kT>0:0</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>33:43</td><td class=br>-10</td>
<td class=bc>5 - 5 - 9</td>
<td class=br><strong>15</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>68.</td><td class=kt>El Reinfelds</td><td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>5:10</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>2:6</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kT>5:5</td>
<td class=kW>5:0</td>
<td class=br>46:66</td><td class=br>-20</td>
<td class=bc>6 - 1 - 12</td>
<td class=br><strong>13</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>69.</td><td class=kt>D� Vai�iul�ns</td><td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kW>5:2</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=br>38:51</td><td class=br>-13</td>
<td class=bc>5 - 1 - 13</td>
<td class=br><strong>11</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>70.</td><td class=kt>An Kova��uks</td><td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kW>5:0</td>
<td class=br>25:46</td><td class=br>-21</td>
<td class=bc>3 - 4 - 12</td>
<td class=br><strong>10</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>71.</td><td class=kt>Em Ka�s</td><td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kT>5:5</td>
<td class=kL>0:2</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=br>28:56</td><td class=br>-28</td>
<td class=bc>3 - 2 - 14</td>
<td class=br><strong>8</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>72.</td><td class=kt>J� Zem�ickis</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=br>0:95</td><td class=br>-95</td>
<td class=bc>0 - 0 - 19</td>
<td class=br><strong>0</strong></td><td class=d>20.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Kova��uks Andris</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Rekti�� J�nis</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Puri�� K�rlis</td><td class=bc>-</td><td class=blW>Vai�iul�ns D�vis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Vasks Artis</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Stac�vi�s Reinis</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Vai�iul�ns D�vis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Puri�� K�rlis</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Stac�vi�s Reinis</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Puri�� K�rlis</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>Vasks Artis</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Timbers M�rti��</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Stac�vi�s Reinis</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Puri�� K�rlis</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Vasks Artis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Stac�vi�s Reinis</td><td class=bc>-</td><td class=bl>�irsis M�ris</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Rekti�� J�nis</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Puri�� K�rlis</td><td class=bc>-</td><td class=bl>Vasks Artis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Stac�vi�s Reinis</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Vasks Artis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Puri�� K�rlis</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=blW>Ka�s Em�ls</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Vasks Artis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Stac�vi�s Reinis</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Rekti�� J�nis</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Puri�� K�rlis</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Pav�rs Agris</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Vasks Artis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Stac�vi�s Reinis</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Egl�tis �riks</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Vasks Artis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Stac�vi�s Reinis</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Puri�� K�rlis</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Egl�tis �riks</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Vasks Artis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Timbers M�rti��</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Puri�� K�rlis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Stac�vi�s Reinis</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Ka�s Em�ls</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Vasks Artis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>4 : 1</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Timbers M�rti��</td><td class=bc>-</td><td class=bl>Puri�� K�rlis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=blW>Rekti�� J�nis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Vasks Artis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Jansons Georgs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Krauze Marks Kristians</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Pav�rs Agris</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=blW>Vesele D�rta</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=blW>Puri�� K�rlis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Timbers M�rti��</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kova��uks Andris</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Vasks Artis</td><td class=bc>-</td><td class=bl>Jansons Georgs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Reinfelds Elvis Gustavs </td><td class=bc>1 : 3</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=blW>Puri�� K�rlis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Timbers M�rti��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Krauze Marks Kristians</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Vasks Artis</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>10 : 5</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=blW>Puri�� K�rlis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Vai�iul�ns D�vis</td><td class=bc>-</td><td class=blW>Kova��uks Andris</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Reinfelds Elvis Gustavs </td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Kalni�� Ernests</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Vasks Artis</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Puri�� K�rlis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>St�lmanis Raimonds</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Kalni�� Ernests</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=blW>Puri�� K�rlis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Vasks Artis</td><td class=bc>-</td><td class=blW>Rekti�� J�nis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Stac�vi�s Reinis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kalni�� Mariuss Toms</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Vesele D�rta</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>Puri�� K�rlis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Vasks Artis</td><td class=bc>-</td><td class=blW>Stac�vi�s Reinis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Saul�tis Ren�rs</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=blW>Puri�� K�rlis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Stac�vi�s Reinis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Vasks Artis</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>Timbers M�rti��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Vai�iul�ns D�vis</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>�irsis M�ris</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Pav�rs Agris</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Puri�� K�rlis</td><td class=bc>-</td><td class=bl>Rekti�� J�nis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kalni�� Ernests</td><td class=bc>-</td><td class=blW>Stac�vi�s Reinis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Krauze Marks Kristians</td><td class=bc>-</td><td class=blW>Kova��uks Andris</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Vasks Artis</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Egl�tis �riks</td><td class=bc>-</td><td class=blW>Kalni�� Mariuss Toms</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>�irsis M�ris</td><td class=bc>-</td><td class=blW>Saul�tis Ren�rs</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Rekti�� J�nis</td><td class=bc>-</td><td class=bl>Zem�ickis J�nis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Puri�� K�rlis</td><td class=bc>-</td><td class=blW>Stac�vi�s Reinis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Vesele D�rta</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Jansons Georgs</td><td class=bc>-</td><td class=bl>St�lmanis Raimonds</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vasks Artis</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ka�s Em�ls</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Egl�tis �riks</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Zem�ickis J�nis</td><td class=bc>-</td><td class=blW>Stac�vi�s Reinis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Rekti�� J�nis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Puri�� K�rlis</td><td class=bc>-</td><td class=bl>Kova��uks Andris</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Vesele D�rta</td><td class=bc>-</td><td class=bl>Timbers M�rti��</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kalni�� Ernests</td><td class=bc>-</td><td class=bl>Vai�iul�ns D�vis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Reinfelds Elvis Gustavs </td><td class=bc>-</td><td class=blW>St�lmanis Raimonds</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Krauze Marks Kristians</td><td class=bc>-</td><td class=bl>Kalni�� Mariuss Toms</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Jansons Georgs</td><td class=bc>-</td><td class=bl>Saul�tis Ren�rs</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Vasks Artis</td><td class=bc>-</td><td class=bl>Pav�rs Agris</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ka�s Em�ls</td><td class=bc>-</td><td class=blW>�irsis M�ris</td><td class=bc>0 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 4.l�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>73</td>
<td class=ic>74</td>
<td class=ic>75</td>
<td class=ic>76</td>
<td class=ic>77</td>
<td class=ic>78</td>
<td class=ic>79</td>
<td class=ic>80</td>
<td class=ic>81</td>
<td class=ic>82</td>
<td class=ic>83</td>
<td class=ic>84</td>
<td class=ic>85</td>
<td class=ic>86</td>
<td class=ic>87</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>73.</td><td class=kt>Da Belkovs</td><td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=br>58:19</td><td class=br>+39</td>
<td class=bc>13 - 0 - 1</td>
<td class=br><strong>26</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>74.</td><td class=kt>Al Sili��</td><td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kL>1:7</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=br>33:20</td><td class=br>+13</td>
<td class=bc>10 - 1 - 3</td>
<td class=br><strong>21</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>75.</td><td class=kt>Ed Liepi��</td><td class=kL>2:5</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>37:22</td><td class=br>+15</td>
<td class=bc>9 - 0 - 5</td>
<td class=br><strong>18</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>76.</td><td class=kt>Gu M�lnieks</td><td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kL>0:4</td>
<td class=kL>4:5</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kL>2:7</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=br>46:34</td><td class=br>+12</td>
<td class=bc>9 - 0 - 5</td>
<td class=br><strong>18</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/4</td><td class=d>77.</td><td class=kt>Kr Rudz�tis</td><td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>37:23</td><td class=br>+14</td>
<td class=bc>8 - 1 - 5</td>
<td class=br><strong>17</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/4</td><td class=d>78.</td><td class=kt>Da Vai�iul�ns</td><td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>34:26</td><td class=br>+8</td>
<td class=bc>7 - 3 - 4</td>
<td class=br><strong>17</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/4</td><td class=d>79.</td><td class=kt>Kr S�manis</td><td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>33:30</td><td class=br>+3</td>
<td class=bc>7 - 2 - 5</td>
<td class=br><strong>16</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/4</td><td class=d>80.</td><td class=kt>Al Biltaure</td><td class=kL>0:6</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=br>29:34</td><td class=br>-5</td>
<td class=bc>6 - 3 - 5</td>
<td class=br><strong>15</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>81.</td><td class=kt>Br Gor�anovs</td><td class=kL>3:4</td>
<td class=kW>7:1</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>6:3</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>46:33</td><td class=br>+13</td>
<td class=bc>6 - 1 - 7</td>
<td class=br><strong>13</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>82.</td><td class=kt>Ed Garan�s</td><td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>28:30</td><td class=br>-2</td>
<td class=bc>5 - 3 - 6</td>
<td class=br><strong>13</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>83.</td><td class=kt>Ro Garda</td><td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kW>5:0</td>
<td class=br>28:32</td><td class=br>-4</td>
<td class=bc>5 - 2 - 7</td>
<td class=br><strong>12</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>84.</td><td class=kt>T� Gor�anova</td><td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>5:0</td>
<td class=br>32:35</td><td class=br>-3</td>
<td class=bc>4 - 2 - 8</td>
<td class=br><strong>10</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>85.</td><td class=kt>�d Erenpreiss</td><td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=br>16:33</td><td class=br>-17</td>
<td class=bc>2 - 3 - 9</td>
<td class=br><strong>7</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>86.</td><td class=kt>Ma Zimba</td><td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=br>23:39</td><td class=br>-16</td>
<td class=bc>3 - 1 - 10</td>
<td class=br><strong>7</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>87.</td><td class=kt>As Kocere</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=br>0:70</td><td class=br>-70</td>
<td class=bc>0 - 0 - 14</td>
<td class=br><strong>0</strong></td><td class=d>15.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>M�lnieks Gustavs</td><td class=bc>-</td><td class=bl>Zimba Mat�ss</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>Garan�s Edgars</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Sili�� Alberts</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=blW>Biltaure Alma</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Erenpreiss �dams</td><td class=bc>-</td><td class=blW>Garda Roberts</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=blW>Rudz�tis Kristaps</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Zimba Mat�ss</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Garan�s Edgars</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>M�lnieks Gustavs</td><td class=bc>-</td><td class=blW>Gor�anova T�na</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>Biltaure Alma</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Sili�� Alberts</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=blW>Rudz�tis Kristaps</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Erenpreiss �dams</td><td class=bc>-</td><td class=blW>S�manis Kri�j�nis</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Zimba Mat�ss</td><td class=bc>-</td><td class=blW>Garan�s Edgars</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Biltaure Alma</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>M�lnieks Gustavs</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>Rudz�tis Kristaps</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Sili�� Alberts</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Liepi�� Edgars</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Garan�s Edgars</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Zimba Mat�ss</td><td class=bc>-</td><td class=bl>Biltaure Alma</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=blW>Garda Roberts</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>M�lnieks Gustavs</td><td class=bc>-</td><td class=blW>S�manis Kri�j�nis</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>Vai�iul�ns Daniels</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Sili�� Alberts</td><td class=bc>-</td><td class=bl>Erenpreiss �dams</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Biltaure Alma</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Garan�s Edgars</td><td class=bc>-</td><td class=blW>Garda Roberts</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Zimba Mat�ss</td><td class=bc>-</td><td class=blW>Rudz�tis Kristaps</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>M�lnieks Gustavs</td><td class=bc>-</td><td class=bl>Erenpreiss �dams</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>Liepi�� Edgars</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Biltaure Alma</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Gor�anova T�na</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Garan�s Edgars</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Zimba Mat�ss</td><td class=bc>-</td><td class=blW>Vai�iul�ns Daniels</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Erenpreiss �dams</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Liepi�� Edgars</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>M�lnieks Gustavs</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Garda Roberts</td><td class=bc>-</td><td class=bl>Rudz�tis Kristaps</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Biltaure Alma</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Vai�iul�ns Daniels</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Garan�s Edgars</td><td class=bc>-</td><td class=bl>Erenpreiss �dams</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Zimba Mat�ss</td><td class=bc>-</td><td class=blW>Liepi�� Edgars</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Gor�anovs Braiens</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Belkovs Daniels</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>S�manis Kri�j�nis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=bl>Vai�iul�ns Daniels</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Biltaure Alma</td><td class=bc>-</td><td class=bl>Erenpreiss �dams</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Liepi�� Edgars</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Garan�s Edgars</td><td class=bc>-</td><td class=blW>Sili�� Alberts</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Zimba Mat�ss</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Gor�anovs Braiens</td><td class=bc>-</td><td class=blW>M�lnieks Gustavs</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=blW>Vai�iul�ns Daniels</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Erenpreiss �dams</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Liepi�� Edgars</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Biltaure Alma</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Gor�anova T�na</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Garan�s Edgars</td><td class=bc>-</td><td class=blW>M�lnieks Gustavs</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Zimba Mat�ss</td><td class=bc>-</td><td class=blW>Belkovs Daniels</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Erenpreiss �dams</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>Liepi�� Edgars</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Sili�� Alberts</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Garda Roberts</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Biltaure Alma</td><td class=bc>-</td><td class=blW>M�lnieks Gustavs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Belkovs Daniels</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Garan�s Edgars</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Erenpreiss �dams</td><td class=bc>-</td><td class=blW>Liepi�� Edgars</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=blW>Sili�� Alberts</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>M�lnieks Gustavs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Belkovs Daniels</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Biltaure Alma</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Gor�anova T�na</td><td class=bc>-</td><td class=blW>Zimba Mat�ss</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Liepi�� Edgars</td><td class=bc>-</td><td class=blW>Sili�� Alberts</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Erenpreiss �dams</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>M�lnieks Gustavs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>S�manis Kri�j�nis</td><td class=bc>-</td><td class=blW>Belkovs Daniels</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Zimba Mat�ss</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Biltaure Alma</td><td class=bc>-</td><td class=blW>Garan�s Edgars</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Sili�� Alberts</td><td class=bc>-</td><td class=bl>Kocere Asnate</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Liepi�� Edgars</td><td class=bc>-</td><td class=bl>M�lnieks Gustavs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Erenpreiss �dams</td><td class=bc>-</td><td class=blW>Belkovs Daniels</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>Zimba Mat�ss</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Rudz�tis Kristaps</td><td class=bc>-</td><td class=blW>Garan�s Edgars</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Garda Roberts</td><td class=bc>-</td><td class=blW>Gor�anova T�na</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>M�lnieks Gustavs</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Sili�� Alberts</td><td class=bc>-</td><td class=bl>Belkovs Daniels</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Liepi�� Edgars</td><td class=bc>-</td><td class=bl>Gor�anovs Braiens</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Erenpreiss �dams</td><td class=bc>-</td><td class=bl>Zimba Mat�ss</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Garan�s Edgars</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Rudz�tis Kristaps</td><td class=bc>-</td><td class=bl>Biltaure Alma</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>M�lnieks Gustavs</td><td class=bc>-</td><td class=blW>Belkovs Daniels</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kocere Asnate</td><td class=bc>-</td><td class=blW>Gor�anovs Braiens</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Sili�� Alberts</td><td class=bc>-</td><td class=bl>Zimba Mat�ss</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Liepi�� Edgars</td><td class=bc>-</td><td class=bl>Garan�s Edgars</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Erenpreiss �dams</td><td class=bc>-</td><td class=bl>Gor�anova T�na</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Vai�iul�ns Daniels</td><td class=bc>-</td><td class=bl>Biltaure Alma</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>S�manis Kri�j�nis</td><td class=bc>-</td><td class=bl>Garda Roberts</td><td class=bc>3 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
