<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Latvijas Kauss 1.posms</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../23LK1/Latvijas_Kauss_1.posms_index.php">Latvijas Kauss 1.posms, 9. September 2023</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group LK A</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ra Kalnin�</td><td class=kx>*</td>
<td class=kW>7:4</td>
<td class=kW>4:2</td>
<td class=kW>7:4</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>9:0</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kW>7:2</td>
<td class=kW>6:5</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>8:2</td>
<td class=br>92:35</td><td class=br>+57</td>
<td class=bc>15 - 1 - 0</td>
<td class=br><strong>31</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>El Silin�</td><td class=kL>4:7</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kW>8:3</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kL>3:4</td>
<td class=kW>7:1</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=br>68:36</td><td class=br>+32</td>
<td class=bc>11 - 2 - 3</td>
<td class=br><strong>24</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Em Liepin�</td><td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>7:3</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kT>5:5</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=br>61:32</td><td class=br>+29</td>
<td class=bc>9 - 5 - 2</td>
<td class=br><strong>23</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ed Naglis</td><td class=kL>4:7</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kL>1:6</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=br>59:47</td><td class=br>+12</td>
<td class=bc>10 - 1 - 5</td>
<td class=br><strong>21</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Kr Lagzdina</td><td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>3:7</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=br>46:43</td><td class=br>+3</td>
<td class=bc>8 - 3 - 5</td>
<td class=br><strong>19</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Se Mihejevs</td><td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>4:5</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=br>48:37</td><td class=br>+11</td>
<td class=bc>7 - 4 - 5</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ed Kaneps</td><td class=kL>0:9</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kW>5:4</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=br>44:55</td><td class=br>-11</td>
<td class=bc>7 - 3 - 6</td>
<td class=br><strong>17</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Sa Skarainis</td><td class=kL>3:6</td>
<td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>6:3</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=br>48:42</td><td class=br>+6</td>
<td class=bc>7 - 3 - 6</td>
<td class=br><strong>17</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Ra Kuhalskis</td><td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>6:1</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kW>6:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>8:0</td>
<td class=kW>4:1</td>
<td class=br>52:41</td><td class=br>+11</td>
<td class=bc>7 - 2 - 7</td>
<td class=br><strong>16</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ra Neija</td><td class=kL>2:7</td>
<td class=kL>3:8</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kL>4:5</td>
<td class=kL>3:6</td>
<td class=kT>4:4</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=br>48:54</td><td class=br>-6</td>
<td class=bc>7 - 2 - 7</td>
<td class=br><strong>16</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ro Livmanis</td><td class=kL>5:6</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>44:41</td><td class=br>+3</td>
<td class=bc>6 - 3 - 7</td>
<td class=br><strong>15</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>El Racenaja</td><td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kT>5:5</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kW>5:4</td>
<td class=kW>5:3</td>
<td class=kL>3:6</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kL>2:5</td>
<td class=br>55:55</td><td class=br>0</td>
<td class=bc>5 - 5 - 6</td>
<td class=br><strong>15</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Ro Verbics</td><td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>3:6</td>
<td class=kL>3:4</td>
<td class=kL>0:1</td>
<td class=kW>4:2</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>39:46</td><td class=br>-7</td>
<td class=bc>6 - 1 - 9</td>
<td class=br><strong>13</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>B</td><td class=d>14.</td><td class=kt>Kr Zemnickis</td><td class=kL>2:7</td>
<td class=kW>4:3</td>
<td class=kL>0:6</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=br>32:54</td><td class=br>-22</td>
<td class=bc>4 - 1 - 11</td>
<td class=br><strong>9</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>Gu Buls</td><td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>1:7</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kT>1:1</td>
<td class=br>23:61</td><td class=br>-38</td>
<td class=bc>2 - 3 - 11</td>
<td class=br><strong>7</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>C</td><td class=d>16.</td><td class=kt>Ri Kalnin�</td><td class=kL>0:6</td>
<td class=kL>2:6</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>0:8</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=br>14:54</td><td class=br>-40</td>
<td class=bc>2 - 2 - 12</td>
<td class=br><strong>6</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>C</td><td class=d>17.</td><td class=kt>Ar Salmin�</td><td class=kL>2:8</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kW>5:2</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=br>21:61</td><td class=br>-40</td>
<td class=bc>1 - 3 - 12</td>
<td class=br><strong>5</strong></td><td class=d>17.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Kr Zemnickis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ra Kalnin�</td><td class=bc>-</td><td class=bl>Ro Verbics</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ri Kalnin�</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=blW>El Silin�</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ra Kuhalskis</td><td class=bc>-</td><td class=bl>Ar Salmin�</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=bl>El Racenaja</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Em Liepin�</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Kr Zemnickis</td><td class=bc>-</td><td class=blW>Ro Verbics</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ra Kalnin�</td><td class=bc>-</td><td class=bl>El Silin�</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Ri Kalnin�</td><td class=bc>-</td><td class=bl>Ar Salmin�</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=blW>El Racenaja</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ra Kuhalskis</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Em Liepin�</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ro Verbics</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Kr Zemnickis</td><td class=bc>-</td><td class=bl>El Silin�</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=bl>Ar Salmin�</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ra Kalnin�</td><td class=bc>-</td><td class=bl>El Racenaja</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ri Kalnin�</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ra Kuhalskis</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>El Silin�</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ro Verbics</td><td class=bc>-</td><td class=bl>Ar Salmin�</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Kr Zemnickis</td><td class=bc>-</td><td class=bl>El Racenaja</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ra Kalnin�</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Ri Kalnin�</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ed Kaneps</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ra Kuhalskis</td><td class=bc>-</td><td class=blW>Em Liepin�</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>El Silin�</td><td class=bc>-</td><td class=bl>Ar Salmin�</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>El Racenaja</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ro Verbics</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Kr Zemnickis</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ra Kalnin�</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Ri Kalnin�</td><td class=bc>-</td><td class=blW>Em Liepin�</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ed Kaneps</td><td class=bc>-</td><td class=bl>Kr Lagzdina</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ar Salmin�</td><td class=bc>-</td><td class=bl>El Racenaja</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>El Silin�</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Verbics</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Kr Zemnickis</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Em Liepin�</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ra Kalnin�</td><td class=bc>-</td><td class=bl>Kr Lagzdina</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ri Kalnin�</td><td class=bc>-</td><td class=blW>Ra Kuhalskis</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>El Racenaja</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ar Salmin�</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>El Silin�</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ro Verbics</td><td class=bc>-</td><td class=bl>Em Liepin�</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Zemnickis</td><td class=bc>-</td><td class=blW>Kr Lagzdina</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=bl>Ra Kuhalskis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ra Kalnin�</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>9 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>El Racenaja</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ar Salmin�</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>El Silin�</td><td class=bc>-</td><td class=bl>Em Liepin�</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Kr Lagzdina</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ro Verbics</td><td class=bc>-</td><td class=bl>Ra Kuhalskis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Zemnickis</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Ri Kalnin�</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>El Racenaja</td><td class=bc>-</td><td class=bl>Em Liepin�</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Ar Salmin�</td><td class=bc>-</td><td class=blW>Kr Lagzdina</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>El Silin�</td><td class=bc>-</td><td class=bl>Ra Kuhalskis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ro Verbics</td><td class=bc>-</td><td class=bl>Ri Kalnin�</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr Zemnickis</td><td class=bc>-</td><td class=blW>Ra Kalnin�</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Em Liepin�</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ra Neija</td><td class=bc>-</td><td class=bl>Kr Lagzdina</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>El Racenaja</td><td class=bc>-</td><td class=bl>Ra Kuhalskis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ar Salmin�</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>El Silin�</td><td class=bc>-</td><td class=bl>Ri Kalnin�</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Ra Kalnin�</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ro Verbics</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=blW>Em Liepin�</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Kr Lagzdina</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ra Kuhalskis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>El Racenaja</td><td class=bc>-</td><td class=bl>Ri Kalnin�</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ar Salmin�</td><td class=bc>-</td><td class=blW>Ra Kalnin�</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>El Silin�</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Kr Zemnickis</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Em Liepin�</td><td class=bc>-</td><td class=bl>Kr Lagzdina</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=blW>Ra Kuhalskis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ri Kalnin�</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=blW>Ra Kalnin�</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>El Racenaja</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ar Salmin�</td><td class=bc>-</td><td class=blW>Kr Zemnickis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>El Silin�</td><td class=bc>-</td><td class=bl>Ro Verbics</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Ra Kuhalskis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Em Liepin�</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ro Livmanis</td><td class=bc>-</td><td class=bl>Ri Kalnin�</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Ra Kalnin�</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ra Neija</td><td class=bc>-</td><td class=bl>Kr Zemnickis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>El Racenaja</td><td class=bc>-</td><td class=blW>Ro Verbics</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ar Salmin�</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ra Kuhalskis</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Ri Kalnin�</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Em Liepin�</td><td class=bc>-</td><td class=blW>Ra Kalnin�</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ro Livmanis</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Kr Zemnickis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ro Verbics</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>El Racenaja</td><td class=bc>-</td><td class=bl>El Silin�</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ed Kaneps</td><td class=bc>-</td><td class=bl>Ri Kalnin�</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ra Kuhalskis</td><td class=bc>-</td><td class=blW>Ra Kalnin�</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Em Liepin�</td><td class=bc>-</td><td class=bl>Kr Zemnickis</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=blW>Ro Verbics</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>El Silin�</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ra Neija</td><td class=bc>-</td><td class=bl>Ar Salmin�</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ri Kalnin�</td><td class=bc>-</td><td class=blW>Ra Kalnin�</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ra Kuhalskis</td><td class=bc>-</td><td class=bl>Kr Zemnickis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Ro Verbics</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Em Liepin�</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=blW>El Silin�</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Ar Salmin�</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>El Racenaja</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Ra Kalnin�</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ri Kalnin�</td><td class=bc>-</td><td class=blW>Kr Zemnickis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ed Kaneps</td><td class=bc>-</td><td class=bl>Ro Verbics</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ra Kuhalskis</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=bl>El Silin�</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Em Liepin�</td><td class=bc>-</td><td class=bl>Ar Salmin�</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=bl>El Racenaja</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>1 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group LK B</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ro Riekstin�</td><td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=br>58:17</td><td class=br>+41</td>
<td class=bc>12 - 2 - 1</td>
<td class=br><strong>26</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ra Miglinieks</td><td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>7:4</td>
<td class=kW>5:0</td>
<td class=kW>8:0</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=br>61:27</td><td class=br>+34</td>
<td class=bc>12 - 2 - 1</td>
<td class=br><strong>26</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Sa Kalnin�</td><td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kT>5:5</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>8:4</td>
<td class=kW>7:1</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=br>54:35</td><td class=br>+19</td>
<td class=bc>10 - 3 - 2</td>
<td class=br><strong>23</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Pa Strods</td><td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>6:5</td>
<td class=kW>6:4</td>
<td class=kL>1:2</td>
<td class=kW>11:1</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>6:0</td>
<td class=br>59:36</td><td class=br>+23</td>
<td class=bc>10 - 0 - 5</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Va Smagars</td><td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>3:5</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=br>49:33</td><td class=br>+16</td>
<td class=bc>7 - 5 - 3</td>
<td class=br><strong>19</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Di Ziemelis</td><td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>8:1</td>
<td class=kL>1:5</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>1:0</td>
<td class=kW>6:0</td>
<td class=br>51:34</td><td class=br>+17</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>To Baumanis</td><td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kL>1:2</td>
<td class=kW>6:2</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=br>45:28</td><td class=br>+17</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>In Garancs</td><td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kW>6:5</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=br>43:35</td><td class=br>+8</td>
<td class=bc>8 - 1 - 6</td>
<td class=br><strong>17</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Al Skudritis</td><td class=kL>0:3</td>
<td class=kL>2:6</td>
<td class=kT>5:5</td>
<td class=kL>5:6</td>
<td class=kW>5:3</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=br>43:47</td><td class=br>-4</td>
<td class=bc>7 - 2 - 6</td>
<td class=br><strong>16</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ed Putnin�</td><td class=kL>1:7</td>
<td class=kL>4:7</td>
<td class=kT>2:2</td>
<td class=kL>4:6</td>
<td class=kL>2:7</td>
<td class=kL>1:8</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>6:3</td>
<td class=br>39:63</td><td class=br>-24</td>
<td class=bc>6 - 1 - 8</td>
<td class=br><strong>13</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ja Bitmanis</td><td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=br>22:29</td><td class=br>-7</td>
<td class=bc>4 - 2 - 9</td>
<td class=br><strong>10</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>Kr Zarinieks</td><td class=kL>1:6</td>
<td class=kL>0:8</td>
<td class=kL>1:5</td>
<td class=kL>1:11</td>
<td class=kT>4:4</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=br>35:71</td><td class=br>-36</td>
<td class=bc>4 - 1 - 10</td>
<td class=br><strong>9</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Ni Sviklis</td><td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kL>4:8</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kL>5:6</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=br>41:61</td><td class=br>-20</td>
<td class=bc>3 - 2 - 10</td>
<td class=br><strong>8</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>B</td><td class=d>14.</td><td class=kt>Marg Abele</td><td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kW>5:2</td>
<td class=kL>3:4</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=br>27:50</td><td class=br>-23</td>
<td class=bc>4 - 0 - 11</td>
<td class=br><strong>8</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>Fr Platons</td><td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=br>18:37</td><td class=br>-19</td>
<td class=bc>3 - 1 - 11</td>
<td class=br><strong>7</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>C</td><td class=d>16.</td><td class=kt>Ka Purin�</td><td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=br>17:59</td><td class=br>-42</td>
<td class=bc>0 - 2 - 13</td>
<td class=br><strong>2</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Marg Abele</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Bitmanis</td><td class=bc>-</td><td class=blW>Kr Zarinieks</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>In Garancs</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Sa Kalnin�</td><td class=bc>-</td><td class=blW>Pa Strods</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Al Skudritis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ka Purin�</td><td class=bc>-</td><td class=blW>Ro Riekstin�</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Marg Abele</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ja Bitmanis</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>In Garancs</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Sa Kalnin�</td><td class=bc>-</td><td class=bl>Al Skudritis</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Ro Riekstin�</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Ed Putnin�</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Marg Abele</td><td class=bc>-</td><td class=blW>Pa Strods</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ja Bitmanis</td><td class=bc>-</td><td class=bl>Al Skudritis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>In Garancs</td><td class=bc>-</td><td class=blW>Ro Riekstin�</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Sa Kalnin�</td><td class=bc>-</td><td class=bl>Ed Putnin�</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ka Purin�</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Pa Strods</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Marg Abele</td><td class=bc>-</td><td class=bl>Al Skudritis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Ro Riekstin�</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Bitmanis</td><td class=bc>-</td><td class=blW>Ed Putnin�</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>In Garancs</td><td class=bc>-</td><td class=bl>Ka Purin�</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Sa Kalnin�</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Pa Strods</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Al Skudritis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ro Riekstin�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Marg Abele</td><td class=bc>-</td><td class=blW>Ed Putnin�</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Ka Purin�</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ja Bitmanis</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>In Garancs</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Al Skudritis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Ro Riekstin�</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ed Putnin�</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ka Purin�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Marg Abele</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ja Bitmanis</td><td class=bc>-</td><td class=blW>Sa Kalnin�</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Al Skudritis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=blW>Ro Riekstin�</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Ed Putnin�</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Ka Purin�</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Marg Abele</td><td class=bc>-</td><td class=blW>Sa Kalnin�</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>In Garancs</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Al Skudritis</td><td class=bc>-</td><td class=blW>Ro Riekstin�</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ed Putnin�</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Pa Strods</td><td class=bc>-</td><td class=bl>Ka Purin�</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Sa Kalnin�</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>In Garancs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Marg Abele</td><td class=bc>-</td><td class=bl>Ja Bitmanis</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ro Riekstin�</td><td class=bc>-</td><td class=bl>Ed Putnin�</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Al Skudritis</td><td class=bc>-</td><td class=bl>Ka Purin�</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Sa Kalnin�</td><td class=bc>4 : 8</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>In Garancs</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Ja Bitmanis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ed Putnin�</td><td class=bc>-</td><td class=bl>Ka Purin�</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ro Riekstin�</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Al Skudritis</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Sa Kalnin�</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Pa Strods</td><td class=bc>-</td><td class=bl>In Garancs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Ja Bitmanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Marg Abele</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ka Purin�</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ed Putnin�</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Ro Riekstin�</td><td class=bc>-</td><td class=blW>Sa Kalnin�</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Skudritis</td><td class=bc>-</td><td class=blW>In Garancs</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ja Bitmanis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Marg Abele</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ka Purin�</td><td class=bc>-</td><td class=blW>Sa Kalnin�</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ed Putnin�</td><td class=bc>-</td><td class=blW>In Garancs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Riekstin�</td><td class=bc>-</td><td class=bl>Ja Bitmanis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Al Skudritis</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Marg Abele</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Sa Kalnin�</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>In Garancs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ka Purin�</td><td class=bc>-</td><td class=blW>Ja Bitmanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ed Putnin�</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ro Riekstin�</td><td class=bc>-</td><td class=bl>Marg Abele</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Al Skudritis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Pa Strods</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>11 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Sa Kalnin�</td><td class=bc>-</td><td class=blW>In Garancs</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ja Bitmanis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ka Purin�</td><td class=bc>-</td><td class=blW>Marg Abele</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ed Putnin�</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ro Riekstin�</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Al Skudritis</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>In Garancs</td><td class=bc>-</td><td class=blW>Ja Bitmanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Sa Kalnin�</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Marg Abele</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka Purin�</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ed Putnin�</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ro Riekstin�</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Al Skudritis</td><td class=bc>-</td><td class=blW>Pa Strods</td><td class=bc>5 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ja Bitmanis</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>In Garancs</td><td class=bc>-</td><td class=bl>Marg Abele</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Sa Kalnin�</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Kr Zarinieks</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ka Purin�</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ed Putnin�</td><td class=bc>-</td><td class=blW>Pa Strods</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ro Riekstin�</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Marg Abele</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ja Bitmanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>In Garancs</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Sa Kalnin�</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Pa Strods</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ka Purin�</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ed Putnin�</td><td class=bc>-</td><td class=blW>Al Skudritis</td><td class=bc>0 : 6</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group LK C</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ru Kamzols</td><td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=br>0:0</td><td class=br>0</td>
<td class=bc>0 - 0 - 0</td>
<td class=br><strong>0</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Al Pimenovs</td><td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=br>0:0</td><td class=br>0</td>
<td class=bc>0 - 0 - 0</td>
<td class=br><strong>0</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Kr Kurzemnieks</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=br>0:0</td><td class=br>0</td>
<td class=bc>0 - 0 - 0</td>
<td class=br><strong>0</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>To Jakseboga</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=br>0:0</td><td class=br>0</td>
<td class=bc>0 - 0 - 0</td>
<td class=br><strong>0</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Al Silin�</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=br>0:0</td><td class=br>0</td>
<td class=bc>0 - 0 - 0</td>
<td class=br><strong>0</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Sa Krasts</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=br>0:0</td><td class=br>0</td>
<td class=bc>0 - 0 - 0</td>
<td class=br><strong>0</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ma Jakseboga</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=br>0:0</td><td class=br>0</td>
<td class=bc>0 - 0 - 0</td>
<td class=br><strong>0</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>B</td><td class=d>8.</td><td class=kt>Ka Lihacova</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=br>0:0</td><td class=br>0</td>
<td class=bc>0 - 0 - 0</td>
<td class=br><strong>0</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>B</td><td class=d>9.</td><td class=kt>Re Vazolin�</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=br>0:0</td><td class=br>0</td>
<td class=bc>0 - 0 - 0</td>
<td class=br><strong>0</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Al �ernovojs</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=br>0:0</td><td class=br>0</td>
<td class=bc>0 - 0 - 0</td>
<td class=br><strong>0</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Sa Lagzdin�</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=br>0:0</td><td class=br>0</td>
<td class=bc>0 - 0 - 0</td>
<td class=br><strong>0</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>Ru Logins</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=br>0:0</td><td class=br>0</td>
<td class=bc>0 - 0 - 0</td>
<td class=br><strong>0</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>B</td><td class=d>13.</td><td class=kt>Je Rekis</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=br>0:0</td><td class=br>0</td>
<td class=bc>0 - 0 - 0</td>
<td class=br><strong>0</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>B</td><td class=d>14.</td><td class=kt>Kr Naglis</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=br>0:0</td><td class=br>0</td>
<td class=bc>0 - 0 - 0</td>
<td class=br><strong>0</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>Ka Vilums</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=k>&nbsp;</td>
<td class=br>0:0</td><td class=br>0</td>
<td class=bc>0 - 0 - 0</td>
<td class=br><strong>0</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>C</td><td class=d>16.</td><td class=kt>Ro Falken�teins</td><td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=k>&nbsp;</td>
<td class=kx>*</td>
<td class=br>0:0</td><td class=br>0</td>
<td class=bc>0 - 0 - 0</td>
<td class=br><strong>0</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ro Falken�teins</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>Ka Vilums</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ru Kamzols</td><td class=bc>-</td><td class=bl>Re Vazolin�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>Al Silin�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Lagzdin�</td><td class=bc>-</td><td class=bl>Al Pimenovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka Lihacova</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Falken�teins</td><td class=bc>-</td><td class=bl>Ka Vilums</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Re Vazolin�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>Al Silin�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ru Kamzols</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>Al Pimenovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Lagzdin�</td><td class=bc>-</td><td class=bl>Ru Logins</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Ka Vilums</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Re Vazolin�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Falken�teins</td><td class=bc>-</td><td class=bl>Al Silin�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>Al Pimenovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ru Kamzols</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>Ru Logins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Ka Lihacova</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ka Vilums</td><td class=bc>-</td><td class=bl>Re Vazolin�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Al Silin�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Falken�teins</td><td class=bc>-</td><td class=bl>Al Pimenovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>Ru Logins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ru Kamzols</td><td class=bc>-</td><td class=bl>Ka Lihacova</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>Sa Lagzdin�</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Re Vazolin�</td><td class=bc>-</td><td class=bl>Al Silin�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka Vilums</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Al Pimenovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Falken�teins</td><td class=bc>-</td><td class=bl>Ru Logins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ka Lihacova</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>Sa Lagzdin�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ru Kamzols</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Al Silin�</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Re Vazolin�</td><td class=bc>-</td><td class=bl>Al Pimenovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka Vilums</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Ru Logins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ka Lihacova</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Falken�teins</td><td class=bc>-</td><td class=bl>Sa Lagzdin�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Je Rekis</td><td class=bc>-</td><td class=bl>Al Pimenovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Silin�</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Re Vazolin�</td><td class=bc>-</td><td class=bl>Ru Logins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka Vilums</td><td class=bc>-</td><td class=bl>Ka Lihacova</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Sa Lagzdin�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Falken�teins</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Je Rekis</td><td class=bc>-</td><td class=bl>Ru Logins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Silin�</td><td class=bc>-</td><td class=bl>Ka Lihacova</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Re Vazolin�</td><td class=bc>-</td><td class=bl>Sa Lagzdin�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka Vilums</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Falken�teins</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Ru Logins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=bl>Ka Lihacova</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Je Rekis</td><td class=bc>-</td><td class=bl>Sa Lagzdin�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Silin�</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Re Vazolin�</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka Vilums</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ru Logins</td><td class=bc>-</td><td class=bl>Ka Lihacova</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Sa Lagzdin�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Je Rekis</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Silin�</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Re Vazolin�</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka Vilums</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Ro Falken�teins</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ka Lihacova</td><td class=bc>-</td><td class=bl>Sa Lagzdin�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ru Logins</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Je Rekis</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Silin�</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Re Vazolin�</td><td class=bc>-</td><td class=bl>Ro Falken�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka Vilums</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Sa Lagzdin�</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka Lihacova</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ru Logins</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Je Rekis</td><td class=bc>-</td><td class=bl>Ro Falken�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Silin�</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Re Vazolin�</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Lagzdin�</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka Lihacova</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ru Logins</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Ro Falken�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Je Rekis</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Silin�</td><td class=bc>-</td><td class=bl>Ka Vilums</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Lagzdin�</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka Lihacova</td><td class=bc>-</td><td class=bl>Ro Falken�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ru Logins</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=bl>Ka Vilums</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Je Rekis</td><td class=bc>-</td><td class=bl>Re Vazolin�</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ru Kamzols</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Ro Falken�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Lagzdin�</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka Lihacova</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ru Logins</td><td class=bc>-</td><td class=bl>Ka Vilums</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Re Vazolin�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=bl>Al Silin�</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ru Kamzols</td><td class=bc>-</td><td class=bl>Ro Falken�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Lagzdin�</td><td class=bc>-</td><td class=bl>Ka Vilums</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka Lihacova</td><td class=bc>-</td><td class=bl>Re Vazolin�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ru Logins</td><td class=bc>-</td><td class=bl>Al Silin�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ro Falken�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ru Kamzols</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>Ka Vilums</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Re Vazolin�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Sa Lagzdin�</td><td class=bc>-</td><td class=bl>Al Silin�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka Lihacova</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ru Logins</td><td class=bc>-</td><td class=bl>Al Pimenovs</td><td class=bc>&nbsp;</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
<p class=v>Group 1.liga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/16</td><td class=d>1.</td><td class=kt>Ra Kalnin�</td><td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kL>1:2</td>
<td class=kW>9:4</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kL>4:8</td>
<td class=kW>9:1</td>
<td class=kW>4:2</td>
<td class=kW>6:4</td>
<td class=kW>6:3</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=br>92:52</td><td class=br>+40</td>
<td class=bc>14 - 1 - 5</td>
<td class=br><strong>29</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/16</td><td class=d>2.</td><td class=kt>Ma Jakseboga</td><td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:4</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=br>63:52</td><td class=br>+11</td>
<td class=bc>10 - 8 - 2</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/16</td><td class=d>3.</td><td class=kt>Sa Lagzdin�</td><td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kW>5:4</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kW>5:1</td>
<td class=br>59:47</td><td class=br>+12</td>
<td class=bc>12 - 4 - 4</td>
<td class=br><strong>28</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/16</td><td class=d>4.</td><td class=kt>Ra Miglinieks</td><td class=kL>4:9</td>
<td class=kL>4:6</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>7:1</td>
<td class=kW>6:1</td>
<td class=kW>6:4</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kL>3:5</td>
<td class=br>76:55</td><td class=br>+21</td>
<td class=bc>13 - 2 - 5</td>
<td class=br><strong>28</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>1/16</td><td class=d>5.</td><td class=kt>Di Ziemelis</td><td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kL>5:7</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kW>5:4</td>
<td class=br>70:59</td><td class=br>+11</td>
<td class=bc>12 - 2 - 6</td>
<td class=br><strong>26</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>1/16</td><td class=d>6.</td><td class=kt>Em Liepin�</td><td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>4:7</td>
<td class=kL>2:5</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=br>67:52</td><td class=br>+15</td>
<td class=bc>10 - 4 - 6</td>
<td class=br><strong>24</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>1/16</td><td class=d>7.</td><td class=kt>Kr Naglis</td><td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>6:5</td>
<td class=kW>2:0</td>
<td class=kL>2:7</td>
<td class=kT>5:5</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kL>0:4</td>
<td class=kW>5:4</td>
<td class=kW>5:2</td>
<td class=br>64:64</td><td class=br>0</td>
<td class=bc>10 - 3 - 7</td>
<td class=br><strong>23</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>1/16</td><td class=d>8.</td><td class=kt>Al Silin�</td><td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kW>7:4</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>4:6</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kT>4:4</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>8:1</td>
<td class=br>67:55</td><td class=br>+12</td>
<td class=bc>8 - 6 - 6</td>
<td class=br><strong>22</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>1/16</td><td class=d>9.</td><td class=kt>El Silin�</td><td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kW>7:5</td>
<td class=kW>5:2</td>
<td class=kL>5:6</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kL>2:6</td>
<td class=br>67:57</td><td class=br>+10</td>
<td class=bc>10 - 2 - 8</td>
<td class=br><strong>22</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>1/16</td><td class=d>10.</td><td class=kt>Re Vazolin�</td><td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>2:0</td>
<td class=br>49:42</td><td class=br>+7</td>
<td class=bc>7 - 7 - 6</td>
<td class=br><strong>21</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>1/16</td><td class=d>11.</td><td class=kt>Ed Naglis</td><td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kW>6:4</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>7:6</td>
<td class=kW>5:3</td>
<td class=kL>4:5</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=br>63:74</td><td class=br>-11</td>
<td class=bc>8 - 4 - 8</td>
<td class=br><strong>20</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>1/16</td><td class=d>12.</td><td class=kt>To Baumanis</td><td class=kW>8:4</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kT>5:5</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=br>61:61</td><td class=br>0</td>
<td class=bc>9 - 2 - 9</td>
<td class=br><strong>20</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>1/16</td><td class=d>13.</td><td class=kt>Al �ernovojs</td><td class=kL>1:9</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kT>5:5</td>
<td class=kW>1:0</td>
<td class=kW>4:2</td>
<td class=br>49:58</td><td class=br>-9</td>
<td class=bc>6 - 6 - 8</td>
<td class=br><strong>18</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>1/16</td><td class=d>14.</td><td class=kt>Se Mihejevs</td><td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>0:7</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=br>44:60</td><td class=br>-16</td>
<td class=bc>6 - 6 - 8</td>
<td class=br><strong>18</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>1/16</td><td class=d>15.</td><td class=kt>Ro Riekstin�</td><td class=kL>4:6</td>
<td class=kL>2:4</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>8:2</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=br>57:60</td><td class=br>-3</td>
<td class=bc>6 - 5 - 9</td>
<td class=br><strong>17</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>1/16</td><td class=d>16.</td><td class=kt>Pa Strods</td><td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kL>6:7</td>
<td class=kT>1:1</td>
<td class=kT>4:4</td>
<td class=kW>7:0</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>6:5</td>
<td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kW>6:2</td>
<td class=br>66:76</td><td class=br>-10</td>
<td class=bc>5 - 5 - 10</td>
<td class=br><strong>15</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>1/16</td><td class=d>17.</td><td class=kt>Va Smagars</td><td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kW>5:3</td>
<td class=kL>1:6</td>
<td class=kL>4:5</td>
<td class=kT>4:4</td>
<td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=br>58:69</td><td class=br>-11</td>
<td class=bc>5 - 5 - 10</td>
<td class=br><strong>15</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>18.</td><td class=kt>Ru Kamzols</td><td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>4:6</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kW>5:4</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>2:8</td>
<td class=kL>5:6</td>
<td class=kW>5:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=br>59:76</td><td class=br>-17</td>
<td class=bc>6 - 2 - 12</td>
<td class=br><strong>14</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>19.</td><td class=kt>Kr Lagzdina</td><td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kL>0:3</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kT>5:5</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=br>44:55</td><td class=br>-11</td>
<td class=bc>5 - 4 - 11</td>
<td class=br><strong>14</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>20.</td><td class=kt>Ed Kaneps</td><td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kL>2:6</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>4:5</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>5:4</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>51:74</td><td class=br>-23</td>
<td class=bc>4 - 2 - 14</td>
<td class=br><strong>10</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>21.</td><td class=kt>Sa Kalnin�</td><td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kW>5:3</td>
<td class=kL>4:5</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>1:8</td>
<td class=kW>6:2</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>48:76</td><td class=br>-28</td>
<td class=bc>3 - 2 - 15</td>
<td class=br><strong>8</strong></td><td class=d>21.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Al Silin�</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ro Riekstin�</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Sa Kalnin�</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ra Kalnin�</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>El Silin�</td><td class=bc>-</td><td class=blW>Sa Lagzdin�</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Em Liepin�</td><td class=bc>-</td><td class=bl>Re Vazolin�</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ra Kalnin�</td><td class=bc>-</td><td class=bl>Re Vazolin�</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>El Silin�</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Em Liepin�</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Al Silin�</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=blW>Ru Kamzols</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ro Riekstin�</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Sa Lagzdin�</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ed Kaneps</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ro Riekstin�</td><td class=bc>-</td><td class=bl>Sa Kalnin�</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Sa Lagzdin�</td><td class=bc>-</td><td class=bl>Re Vazolin�</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ra Kalnin�</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>El Silin�</td><td class=bc>-</td><td class=bl>Al Silin�</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Em Liepin�</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Em Liepin�</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Sa Kalnin�</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Re Vazolin�</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Sa Lagzdin�</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Al Silin�</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ra Kalnin�</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>El Silin�</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Sa Lagzdin�</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ra Kalnin�</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>El Silin�</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Em Liepin�</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Sa Kalnin�</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=bl>Ro Riekstin�</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Re Vazolin�</td><td class=bc>-</td><td class=bl>Al Silin�</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Al Silin�</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Re Vazolin�</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Sa Lagzdin�</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ra Kalnin�</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>El Silin�</td><td class=bc>-</td><td class=blW>Sa Kalnin�</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Em Liepin�</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Ro Riekstin�</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ra Kalnin�</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>9 : 4</tr></td>
<tr><td class=brW>El Silin�</td><td class=bc>-</td><td class=bl>Ro Riekstin�</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Em Liepin�</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Al Silin�</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>To Baumanis</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Re Vazolin�</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Sa Lagzdin�</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Sa Kalnin�</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Re Vazolin�</td><td class=bc>-</td><td class=bl>Sa Kalnin�</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Sa Lagzdin�</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Ro Riekstin�</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ra Kalnin�</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>El Silin�</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Em Liepin�</td><td class=bc>-</td><td class=bl>Kr Lagzdina</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ru Kamzols</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Al Silin�</td><td class=bc>-</td><td class=bl>Di Ziemelis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ru Kamzols</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Al Silin�</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Sa Kalnin�</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Re Vazolin�</td><td class=bc>-</td><td class=bl>Ro Riekstin�</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Sa Lagzdin�</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ra Kalnin�</td><td class=bc>-</td><td class=bl>Kr Lagzdina</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>El Silin�</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Sa Lagzdin�</td><td class=bc>-</td><td class=bl>Kr Lagzdina</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ra Kalnin�</td><td class=bc>-</td><td class=bl>Em Liepin�</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=bl>Pa Strods</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ru Kamzols</td><td class=bc>-</td><td class=bl>Sa Kalnin�</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Al Silin�</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Ro Riekstin�</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Re Vazolin�</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Al Silin�</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Kr Lagzdina</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Re Vazolin�</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Sa Lagzdin�</td><td class=bc>-</td><td class=blW>Em Liepin�</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=blW>El Silin�</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Pa Strods</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Sa Kalnin�</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ru Kamzols</td><td class=bc>-</td><td class=blW>Ro Riekstin�</td><td class=bc>2 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ro Riekstin�</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ru Kamzols</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Al Silin�</td><td class=bc>-</td><td class=bl>Kr Lagzdina</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Em Liepin�</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Re Vazolin�</td><td class=bc>-</td><td class=bl>El Silin�</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Sa Lagzdin�</td><td class=bc>-</td><td class=bl>Ra Kalnin�</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Pa Strods</td><td class=bc>-</td><td class=bl>Sa Kalnin�</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=blW>Ra Kalnin�</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Re Vazolin�</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Sa Kalnin�</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=blW>Ro Riekstin�</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Kr Lagzdina</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ru Kamzols</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Al Silin�</td><td class=bc>-</td><td class=bl>Em Liepin�</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>El Silin�</td><td class=bc>6 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Em Liepin�</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ru Kamzols</td><td class=bc>-</td><td class=blW>El Silin�</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Silin�</td><td class=bc>-</td><td class=blW>Ra Kalnin�</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ma Jakseboga</td><td class=bc>-</td><td class=bl>Sa Lagzdin�</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ro Riekstin�</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Sa Kalnin�</td><td class=bc>-</td><td class=blW>Ed Kaneps</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pa Strods</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>Kr Lagzdina</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Sa Kalnin�</td><td class=bc>-</td><td class=bl>Kr Lagzdina</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>6 : 7</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>Em Liepin�</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>El Silin�</td><td class=bc>5 : 7</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Ra Kalnin�</td><td class=bc>8 : 4</tr></td>
<tr><td class=brW>Ru Kamzols</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Al Silin�</td><td class=bc>-</td><td class=blW>Sa Lagzdin�</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Re Vazolin�</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ro Riekstin�</td><td class=bc>-</td><td class=bl>Ed Kaneps</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Se Mihejevs</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Al Silin�</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ro Riekstin�</td><td class=bc>-</td><td class=bl>Kr Lagzdina</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Sa Kalnin�</td><td class=bc>-</td><td class=blW>Em Liepin�</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Pa Strods</td><td class=bc>-</td><td class=bl>El Silin�</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>Ra Kalnin�</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Di Ziemelis</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Baumanis</td><td class=bc>-</td><td class=blW>Sa Lagzdin�</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ru Kamzols</td><td class=bc>-</td><td class=bl>Re Vazolin�</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Sa Lagzdin�</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Re Vazolin�</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ru Kamzols</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Kr Lagzdina</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ro Riekstin�</td><td class=bc>-</td><td class=bl>Em Liepin�</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>El Silin�</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Sa Kalnin�</td><td class=bc>-</td><td class=blW>Ra Kalnin�</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ro Riekstin�</td><td class=bc>-</td><td class=blW>Ra Kalnin�</td><td class=bc>4 : 6</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sa Kalnin�</td><td class=bc>-</td><td class=blW>Sa Lagzdin�</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=bl>Re Vazolin�</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>To Baumanis</td><td class=bc>-</td><td class=bl>Al Silin�</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Em Liepin�</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=blW>El Silin�</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Em Liepin�</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kr Lagzdina</td><td class=bc>-</td><td class=bl>El Silin�</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Ra Kalnin�</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ro Riekstin�</td><td class=bc>-</td><td class=blW>Sa Lagzdin�</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Re Vazolin�</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Sa Kalnin�</td><td class=bc>-</td><td class=bl>Ma Jakseboga</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>Al Silin�</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Di Ziemelis</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Sa Kalnin�</td><td class=bc>-</td><td class=blW>Al Silin�</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>Pa Strods</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>6 : 5</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Em Liepin�</td><td class=bc>-</td><td class=blW>El Silin�</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=blW>Ra Kalnin�</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Sa Lagzdin�</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=blW>Re Vazolin�</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ro Riekstin�</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Ma Jakseboga</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ed Kaneps</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ro Riekstin�</td><td class=bc>-</td><td class=blW>Al Silin�</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ru Kamzols</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Sa Kalnin�</td><td class=bc>-</td><td class=blW>To Baumanis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pa Strods</td><td class=bc>-</td><td class=blW>Di Ziemelis</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>El Silin�</td><td class=bc>-</td><td class=bl>Ra Kalnin�</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Em Liepin�</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ed Naglis</td><td class=bc>-</td><td class=bl>Sa Lagzdin�</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Lagzdina</td><td class=bc>-</td><td class=blW>Re Vazolin�</td><td class=bc>1 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 2.liga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Al Skudritis</td><td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kL>4:5</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>11:2</td>
<td class=kW>5:0</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=br>76:38</td><td class=br>+38</td>
<td class=bc>16 - 1 - 3</td>
<td class=br><strong>33</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Ro Falken�teins</td><td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kL>0:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kL>2:5</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=br>50:37</td><td class=br>+13</td>
<td class=bc>13 - 2 - 5</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>Ra Neija</td><td class=kL>0:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=br>50:45</td><td class=br>+5</td>
<td class=bc>11 - 4 - 5</td>
<td class=br><strong>26</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Ru Logins</td><td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kL>3:6</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=br>57:48</td><td class=br>+9</td>
<td class=bc>11 - 4 - 5</td>
<td class=br><strong>26</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ra Kuhalskis</td><td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>6:4</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kT>4:4</td>
<td class=kW>5:0</td>
<td class=br>61:49</td><td class=br>+12</td>
<td class=bc>10 - 6 - 4</td>
<td class=br><strong>26</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Sa Skarainis</td><td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kL>1:6</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kT>5:5</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>9:4</td>
<td class=br>69:48</td><td class=br>+21</td>
<td class=bc>12 - 2 - 6</td>
<td class=br><strong>26</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>In Garancs</td><td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kW>6:3</td>
<td class=kW>5:1</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>7:3</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kL>2:8</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=br>72:51</td><td class=br>+21</td>
<td class=bc>10 - 4 - 6</td>
<td class=br><strong>24</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Je Rekis</td><td class=kW>5:4</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=br>59:50</td><td class=br>+9</td>
<td class=bc>10 - 3 - 7</td>
<td class=br><strong>23</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Ed Putnin�</td><td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kW>6:1</td>
<td class=kL>3:7</td>
<td class=kW>6:3</td>
<td class=kx>*</td>
<td class=kW>7:2</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=k>&nbsp;</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kL>4:6</td>
<td class=kW>10:0</td>
<td class=kW>7:1</td>
<td class=kW>4:3</td>
<td class=kW>5:4</td>
<td class=br>74:56</td><td class=br>+18</td>
<td class=bc>10 - 2 - 7</td>
<td class=br><strong>22</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ni Sviklis</td><td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>2:7</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kL>3:5</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kL>0:3</td>
<td class=kW>5:4</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=br>49:53</td><td class=br>-4</td>
<td class=bc>9 - 4 - 7</td>
<td class=br><strong>22</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Ro Verbics</td><td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>10:0</td>
<td class=kW>5:3</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=br>57:51</td><td class=br>+6</td>
<td class=bc>9 - 2 - 9</td>
<td class=br><strong>20</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Kr Zarinieks</td><td class=kL>2:11</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kW>8:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>7:4</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>10:0</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=br>68:65</td><td class=br>+3</td>
<td class=bc>9 - 2 - 9</td>
<td class=br><strong>20</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ja Bitmanis</td><td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=k>&nbsp;</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kW>10:0</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kL>0:3</td>
<td class=br>47:40</td><td class=br>+7</td>
<td class=bc>7 - 3 - 9</td>
<td class=br><strong>17</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Marg Abele</td><td class=kL>3:4</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>4:7</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kL>3:7</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=br>40:58</td><td class=br>-18</td>
<td class=bc>6 - 4 - 10</td>
<td class=br><strong>16</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Ro Livmanis</td><td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kL>4:6</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kL>3:4</td>
<td class=kW>6:2</td>
<td class=kL>2:5</td>
<td class=kW>5:2</td>
<td class=br>47:53</td><td class=br>-6</td>
<td class=bc>6 - 4 - 10</td>
<td class=br><strong>16</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Sa Krasts</td><td class=kL>0:1</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>3:6</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kL>1:2</td>
<td class=br>42:43</td><td class=br>-1</td>
<td class=bc>7 - 2 - 11</td>
<td class=br><strong>16</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>El Racenaja</td><td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kT>5:5</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kW>6:4</td>
<td class=kL>4:5</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>7:3</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>4:7</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=br>55:68</td><td class=br>-13</td>
<td class=bc>5 - 3 - 12</td>
<td class=br><strong>13</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>18.</td><td class=kt>Kr Kurzemnieks</td><td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>0:10</td>
<td class=kW>3:2</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kW>6:3</td>
<td class=kW>7:4</td>
<td class=kx>*</td>
<td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=br>42:96</td><td class=br>-54</td>
<td class=bc>5 - 2 - 13</td>
<td class=br><strong>12</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>19.</td><td class=kt>Kr Zemnickis</td><td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>7:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=br>45:63</td><td class=br>-18</td>
<td class=bc>3 - 5 - 12</td>
<td class=br><strong>11</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>20.</td><td class=kt>Ka Vilums</td><td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>2:6</td>
<td class=kW>4:2</td>
<td class=kL>0:3</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=br>41:66</td><td class=br>-25</td>
<td class=bc>4 - 3 - 13</td>
<td class=br><strong>11</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>x 1/4</td><td class=d>21.</td><td class=kt>Ka Lihacova</td><td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kL>0:5</td>
<td class=kL>4:9</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kW>6:3</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=br>49:72</td><td class=br>-23</td>
<td class=bc>5 - 0 - 15</td>
<td class=br><strong>10</strong></td><td class=d>21.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ra Neija</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Al Skudritis</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ro Falken�teins</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ed Putnin�</td><td class=bc>-</td><td class=blW>Ro Verbics</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ro Livmanis</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ja Bitmanis</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ru Logins</td><td class=bc>-</td><td class=bl>Ka Vilums</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>In Garancs</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ka Lihacova</td><td class=bc>-</td><td class=blW>Marg Abele</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ra Kuhalskis</td><td class=bc>-</td><td class=bl>Kr Zemnickis</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ru Logins</td><td class=bc>-</td><td class=bl>Marg Abele</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>In Garancs</td><td class=bc>-</td><td class=bl>Kr Zemnickis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ka Lihacova</td><td class=bc>-</td><td class=blW>Je Rekis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ra Kuhalskis</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Skudritis</td><td class=bc>-</td><td class=blW>Ro Verbics</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro Falken�teins</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ed Putnin�</td><td class=bc>-</td><td class=blW>Kr Zarinieks</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ro Livmanis</td><td class=bc>-</td><td class=bl>El Racenaja</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ka Vilums</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ro Falken�teins</td><td class=bc>-</td><td class=bl>El Racenaja</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ed Putnin�</td><td class=bc>-</td><td class=bl>Ja Bitmanis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Marg Abele</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ka Vilums</td><td class=bc>-</td><td class=bl>Kr Zemnickis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ru Logins</td><td class=bc>-</td><td class=blW>Je Rekis</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>In Garancs</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ka Lihacova</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ra Kuhalskis</td><td class=bc>-</td><td class=bl>Ro Verbics</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Al Skudritis</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>11 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ka Lihacova</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ra Kuhalskis</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ra Neija</td><td class=bc>-</td><td class=bl>El Racenaja</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Al Skudritis</td><td class=bc>-</td><td class=bl>Ja Bitmanis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ro Falken�teins</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Marg Abele</td><td class=bc>-</td><td class=bl>Kr Zemnickis</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ka Vilums</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ru Logins</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>In Garancs</td><td class=bc>-</td><td class=bl>Ro Verbics</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ka Vilums</td><td class=bc>-</td><td class=blW>Ro Verbics</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ru Logins</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>In Garancs</td><td class=bc>-</td><td class=blW>Kr Zarinieks</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Ka Lihacova</td><td class=bc>-</td><td class=blW>El Racenaja</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ra Kuhalskis</td><td class=bc>-</td><td class=bl>Ja Bitmanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Al Skudritis</td><td class=bc>-</td><td class=bl>Ed Putnin�</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kr Zemnickis</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Marg Abele</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ra Neija</td><td class=bc>-</td><td class=bl>Ro Falken�teins</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Je Rekis</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kr Zemnickis</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Marg Abele</td><td class=bc>-</td><td class=blW>Ro Verbics</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ka Vilums</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ru Logins</td><td class=bc>-</td><td class=bl>El Racenaja</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>In Garancs</td><td class=bc>-</td><td class=blW>Ja Bitmanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ka Lihacova</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ra Kuhalskis</td><td class=bc>-</td><td class=bl>Ed Putnin�</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ru Logins</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>In Garancs</td><td class=bc>-</td><td class=bl>Ed Putnin�</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>Ka Lihacova</td><td class=bc>-</td><td class=blW>Ro Falken�teins</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ra Kuhalskis</td><td class=bc>-</td><td class=bl>Al Skudritis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Je Rekis</td><td class=bc>-</td><td class=bl>Ro Verbics</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Zemnickis</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Marg Abele</td><td class=bc>-</td><td class=blW>Kr Zarinieks</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>El Racenaja</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Ka Vilums</td><td class=bc>-</td><td class=blW>Ja Bitmanis</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Kr Zemnickis</td><td class=bc>-</td><td class=blW>El Racenaja</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Marg Abele</td><td class=bc>-</td><td class=bl>Ja Bitmanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ka Vilums</td><td class=bc>-</td><td class=blW>Ed Putnin�</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ru Logins</td><td class=bc>-</td><td class=blW>Ro Falken�teins</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>In Garancs</td><td class=bc>-</td><td class=blW>Al Skudritis</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ka Lihacova</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Ro Verbics</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Je Rekis</td><td class=bc>-</td><td class=blW>Kr Zarinieks</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Ro Verbics</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>El Racenaja</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Je Rekis</td><td class=bc>-</td><td class=bl>Ja Bitmanis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Zemnickis</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Marg Abele</td><td class=bc>-</td><td class=blW>Ed Putnin�</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ro Falken�teins</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka Vilums</td><td class=bc>-</td><td class=blW>Al Skudritis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ru Logins</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>In Garancs</td><td class=bc>-</td><td class=bl>Ra Kuhalskis</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ka Vilums</td><td class=bc>-</td><td class=bl>Ra Kuhalskis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ru Logins</td><td class=bc>-</td><td class=bl>Ka Lihacova</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Kr Zarinieks</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ro Verbics</td><td class=bc>-</td><td class=bl>El Racenaja</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Ja Bitmanis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Je Rekis</td><td class=bc>-</td><td class=blW>Ed Putnin�</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Kr Zemnickis</td><td class=bc>-</td><td class=blW>Ro Falken�teins</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Marg Abele</td><td class=bc>-</td><td class=blW>Al Skudritis</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>Ro Falken�teins</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Je Rekis</td><td class=bc>-</td><td class=bl>Al Skudritis</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Kr Zemnickis</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Marg Abele</td><td class=bc>-</td><td class=bl>Ra Kuhalskis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Ka Lihacova</td><td class=bc>9 : 4</tr></td>
<tr><td class=br>Ka Vilums</td><td class=bc>-</td><td class=blW>In Garancs</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>El Racenaja</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Ja Bitmanis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ro Verbics</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Ed Putnin�</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Ro Livmanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>Ed Putnin�</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ro Verbics</td><td class=bc>-</td><td class=blW>Ro Falken�teins</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Al Skudritis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Je Rekis</td><td class=bc>-</td><td class=bl>Ra Kuhalskis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr Zemnickis</td><td class=bc>-</td><td class=bl>Ka Lihacova</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Marg Abele</td><td class=bc>-</td><td class=bl>In Garancs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Ru Logins</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>El Racenaja</td><td class=bc>-</td><td class=bl>Ja Bitmanis</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Kr Zemnickis</td><td class=bc>-</td><td class=bl>Ru Logins</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Marg Abele</td><td class=bc>-</td><td class=blW>Ka Vilums</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ja Bitmanis</td><td class=bc>-</td><td class=bl>Ro Livmanis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>El Racenaja</td><td class=bc>-</td><td class=bl>Ed Putnin�</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Ro Falken�teins</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Al Skudritis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ro Verbics</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Ra Kuhalskis</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Kr Kurzemnieks</td><td class=bc>-</td><td class=bl>Ka Lihacova</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Je Rekis</td><td class=bc>-</td><td class=blW>In Garancs</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ro Verbics</td><td class=bc>-</td><td class=bl>Ka Lihacova</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>In Garancs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>Ru Logins</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Je Rekis</td><td class=bc>-</td><td class=bl>Ka Vilums</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr Zemnickis</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=blW>Ed Putnin�</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ja Bitmanis</td><td class=bc>-</td><td class=blW>Ro Falken�teins</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>El Racenaja</td><td class=bc>-</td><td class=blW>Al Skudritis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Ra Kuhalskis</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ja Bitmanis</td><td class=bc>-</td><td class=blW>Ra Neija</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>El Racenaja</td><td class=bc>-</td><td class=blW>Ra Kuhalskis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Ka Lihacova</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>In Garancs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ro Verbics</td><td class=bc>-</td><td class=blW>Ru Logins</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Ka Vilums</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Je Rekis</td><td class=bc>-</td><td class=blW>Marg Abele</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ed Putnin�</td><td class=bc>-</td><td class=blW>Ro Falken�teins</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=blW>Al Skudritis</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Kr Kurzemnieks</td><td class=bc>-</td><td class=blW>Kr Zemnickis</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ro Falken�teins</td><td class=bc>-</td><td class=blW>Al Skudritis</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ed Putnin�</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=blW>Ra Kuhalskis</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>Ja Bitmanis</td><td class=bc>-</td><td class=blW>Ka Lihacova</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>El Racenaja</td><td class=bc>-</td><td class=blW>In Garancs</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Ru Logins</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Ka Vilums</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ro Verbics</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Marg Abele</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Marg Abele</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ro Verbics</td><td class=bc>-</td><td class=bl>Kr Zemnickis</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>Je Rekis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Skudritis</td><td class=bc>-</td><td class=bl>Ra Neija</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ro Falken�teins</td><td class=bc>-</td><td class=bl>Ra Kuhalskis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ed Putnin�</td><td class=bc>-</td><td class=bl>Ka Lihacova</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=bl>In Garancs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ja Bitmanis</td><td class=bc>-</td><td class=blW>Ru Logins</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>El Racenaja</td><td class=bc>-</td><td class=bl>Ka Vilums</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ed Putnin�</td><td class=bc>-</td><td class=bl>Ru Logins</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=blW>Ka Vilums</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ja Bitmanis</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>El Racenaja</td><td class=bc>-</td><td class=bl>Marg Abele</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Kr Zemnickis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Je Rekis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ro Verbics</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=bl>Ra Kuhalskis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Al Skudritis</td><td class=bc>-</td><td class=bl>Ka Lihacova</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ro Falken�teins</td><td class=bc>-</td><td class=bl>In Garancs</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Ra Kuhalskis</td><td class=bc>-</td><td class=bl>Ka Lihacova</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ra Neija</td><td class=bc>-</td><td class=bl>In Garancs</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Al Skudritis</td><td class=bc>-</td><td class=blW>Ru Logins</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ro Falken�teins</td><td class=bc>-</td><td class=bl>Ka Vilums</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ed Putnin�</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=blW>Marg Abele</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ja Bitmanis</td><td class=bc>-</td><td class=bl>Kr Zemnickis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>El Racenaja</td><td class=bc>-</td><td class=blW>Je Rekis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Ja Bitmanis</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>El Racenaja</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Ro Verbics</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka Lihacova</td><td class=bc>-</td><td class=blW>In Garancs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ra Kuhalskis</td><td class=bc>-</td><td class=blW>Ru Logins</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ra Neija</td><td class=bc>-</td><td class=bl>Ka Vilums</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Al Skudritis</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ro Falken�teins</td><td class=bc>-</td><td class=bl>Marg Abele</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ed Putnin�</td><td class=bc>-</td><td class=bl>Kr Zemnickis</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=blW>Je Rekis</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=brW>Al Skudritis</td><td class=bc>-</td><td class=bl>Kr Zemnickis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ro Falken�teins</td><td class=bc>-</td><td class=blW>Je Rekis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ed Putnin�</td><td class=bc>-</td><td class=bl>Kr Kurzemnieks</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Ro Livmanis</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ja Bitmanis</td><td class=bc>-</td><td class=bl>Ro Verbics</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>El Racenaja</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>In Garancs</td><td class=bc>-</td><td class=bl>Ru Logins</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ka Lihacova</td><td class=bc>-</td><td class=bl>Ka Vilums</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ra Kuhalskis</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ra Neija</td><td class=bc>-</td><td class=bl>Marg Abele</td><td class=bc>2 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 3.liga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt>Ar Salmin�</td><td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>1:0</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kW>2:0</td>
<td class=kW>5:3</td>
<td class=kL>2:3</td>
<td class=kW>10:0</td>
<td class=kW>4:1</td>
<td class=br>76:36</td><td class=br>+40</td>
<td class=bc>18 - 3 - 2</td>
<td class=br><strong>39</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt>Da Baumanis</td><td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kW>4:1</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kW>10:0</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=kW>3:0</td>
<td class=kW>10:0</td>
<td class=kW>2:0</td>
<td class=br>74:25</td><td class=br>+49</td>
<td class=bc>17 - 1 - 5</td>
<td class=br><strong>35</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt>To Jakseboga</td><td class=kL>0:2</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kT>0:0</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=br>56:31</td><td class=br>+25</td>
<td class=bc>15 - 4 - 4</td>
<td class=br><strong>34</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt>Re Stacevics</td><td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kT>0:0</td>
<td class=kT>0:0</td>
<td class=kW>3:0</td>
<td class=kW>9:1</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=br>56:28</td><td class=br>+28</td>
<td class=bc>13 - 5 - 5</td>
<td class=br><strong>31</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ra Ladusans</td><td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kL>2:9</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>7:3</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=br>53:44</td><td class=br>+9</td>
<td class=bc>13 - 5 - 5</td>
<td class=br><strong>31</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Ri Kalnin�</td><td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>1:0</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kL>0:2</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kW>10:0</td>
<td class=kW>4:1</td>
<td class=br>70:40</td><td class=br>+30</td>
<td class=bc>15 - 1 - 7</td>
<td class=br><strong>31</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Gi Vazolin�</td><td class=kW>5:3</td>
<td class=kT>0:0</td>
<td class=kT>0:0</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kL>0:10</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=br>46:43</td><td class=br>+3</td>
<td class=bc>12 - 5 - 6</td>
<td class=br><strong>29</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Iv Kirsis</td><td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kL>0:1</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>10:0</td>
<td class=kW>2:0</td>
<td class=br>62:40</td><td class=br>+22</td>
<td class=bc>14 - 1 - 8</td>
<td class=br><strong>29</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Al Pimenovs</td><td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kW>3:0</td>
<td class=kL>0:1</td>
<td class=kL>3:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kW>1:0</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kT>1:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=br>58:44</td><td class=br>+14</td>
<td class=bc>12 - 4 - 7</td>
<td class=br><strong>28</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ra Martu�ans</td><td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>9:2</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kW>5:2</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=br>60:44</td><td class=br>+16</td>
<td class=bc>11 - 6 - 6</td>
<td class=br><strong>28</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Gu Buls</td><td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>6:5</td>
<td class=kT>2:2</td>
<td class=kW>10:0</td>
<td class=kW>5:0</td>
<td class=br>78:51</td><td class=br>+27</td>
<td class=bc>12 - 4 - 7</td>
<td class=br><strong>28</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ro Aserin�</td><td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kT>0:0</td>
<td class=kW>2:0</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kT>0:0</td>
<td class=kL>0:2</td>
<td class=kW>4:0</td>
<td class=kW>2:0</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=br>41:36</td><td class=br>+5</td>
<td class=bc>10 - 7 - 6</td>
<td class=br><strong>27</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Fr Platons</td><td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kW>1:0</td>
<td class=kL>0:1</td>
<td class=kL>0:1</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>9:2</td>
<td class=kT>0:0</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=br>48:28</td><td class=br>+20</td>
<td class=bc>11 - 3 - 9</td>
<td class=br><strong>25</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Il Kirse</td><td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kL>0:4</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kW>10:0</td>
<td class=kW>2:0</td>
<td class=br>52:51</td><td class=br>+1</td>
<td class=bc>11 - 2 - 10</td>
<td class=br><strong>24</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Ja Zemnickis</td><td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>1:9</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>6:0</td>
<td class=kT>4:4</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>1:0</td>
<td class=kL>1:2</td>
<td class=kW>10:0</td>
<td class=kW>2:0</td>
<td class=br>54:52</td><td class=br>+2</td>
<td class=bc>10 - 2 - 11</td>
<td class=br><strong>22</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>An Zilicka</td><td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kW>2:0</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kT>0:0</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kT>0:0</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>10:0</td>
<td class=kW>2:0</td>
<td class=br>31:44</td><td class=br>-13</td>
<td class=bc>5 - 5 - 13</td>
<td class=br><strong>15</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Ar Pavlovs</td><td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kW>10:0</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kT>4:4</td>
<td class=kW>2:0</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=br>38:48</td><td class=br>-10</td>
<td class=bc>4 - 6 - 13</td>
<td class=br><strong>14</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Ro Purmalis</td><td class=kL>3:5</td>
<td class=kL>0:10</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kW>4:1</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kT>0:0</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kW>10:0</td>
<td class=kW>2:1</td>
<td class=br>40:62</td><td class=br>-22</td>
<td class=bc>6 - 2 - 15</td>
<td class=br><strong>14</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Da Vesele</td><td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>2:9</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>10:0</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=br>38:53</td><td class=br>-15</td>
<td class=bc>4 - 5 - 14</td>
<td class=br><strong>13</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Ar Verbics</td><td class=kL>0:2</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kT>0:0</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kT>0:0</td>
<td class=kW>2:0</td>
<td class=kL>0:2</td>
<td class=kL>0:10</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kW>10:0</td>
<td class=kW>4:0</td>
<td class=br>32:53</td><td class=br>-21</td>
<td class=bc>4 - 4 - 15</td>
<td class=br><strong>12</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Uv Vikmanis</td><td class=kL>3:5</td>
<td class=kL>0:8</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>3:7</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kT>3:3</td>
<td class=kL>5:6</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>10:0</td>
<td class=kT>0:0</td>
<td class=br>40:66</td><td class=br>-26</td>
<td class=bc>4 - 4 - 15</td>
<td class=br><strong>12</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Kr Gutmanis</td><td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>0:1</td>
<td class=kL>1:6</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>10:0</td>
<td class=kL>1:2</td>
<td class=br>42:65</td><td class=br>-23</td>
<td class=bc>5 - 2 - 16</td>
<td class=br><strong>12</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Ka Purin�</td><td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>0:10</td>
<td class=kT>1:1</td>
<td class=kL>0:10</td>
<td class=kL>1:6</td>
<td class=kT>0:0</td>
<td class=kL>0:10</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kW>4:1</td>
<td class=kL>0:10</td>
<td class=kT>2:2</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=br>21:144</td><td class=br>-123</td>
<td class=bc>4 - 4 - 15</td>
<td class=br><strong>12</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Ei Guze</td><td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kL>0:4</td>
<td class=kT>0:0</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=br>18:56</td><td class=br>-38</td>
<td class=bc>2 - 3 - 18</td>
<td class=br><strong>7</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>An Zilicka</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ri Kalnin�</td><td class=bc>-</td><td class=blW>Ro Aserin�</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ka Purin�</td><td class=bc>-</td><td class=bl>Re Stacevics</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ar Salmin�</td><td class=bc>-</td><td class=bl>Ar Verbics</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ra Martu�ans</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Iv Kirsis</td><td class=bc>-</td><td class=bl>Uv Vikmanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ra Ladusans</td><td class=bc>-</td><td class=bl>Da Vesele</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Kr Gutmanis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ei Guze</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ja Zemnickis</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Gi Vazolin�</td><td class=bc>-</td><td class=bl>Al Pimenovs</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>An Zilicka</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>Ro Aserin�</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>Re Stacevics</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Ri Kalnin�</td><td class=bc>-</td><td class=bl>Ar Verbics</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ka Purin�</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ar Salmin�</td><td class=bc>-</td><td class=bl>Uv Vikmanis</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ra Martu�ans</td><td class=bc>-</td><td class=bl>Da Vesele</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Iv Kirsis</td><td class=bc>-</td><td class=bl>Kr Gutmanis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ra Ladusans</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Ei Guze</td><td class=bc>-</td><td class=blW>Al Pimenovs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Zemnickis</td><td class=bc>-</td><td class=blW>Il Kirse</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>An Zilicka</td><td class=bc>-</td><td class=bl>Ro Aserin�</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Re Stacevics</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>Ar Verbics</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ri Kalnin�</td><td class=bc>-</td><td class=bl>Uv Vikmanis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ka Purin�</td><td class=bc>-</td><td class=bl>Da Vesele</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ar Salmin�</td><td class=bc>-</td><td class=blW>Kr Gutmanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ra Martu�ans</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Iv Kirsis</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ra Ladusans</td><td class=bc>-</td><td class=blW>Al Pimenovs</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Il Kirse</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ei Guze</td><td class=bc>-</td><td class=blW>Gi Vazolin�</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Ro Aserin�</td><td class=bc>-</td><td class=bl>Re Stacevics</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>An Zilicka</td><td class=bc>-</td><td class=bl>Ar Verbics</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>Uv Vikmanis</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>Da Vesele</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Ri Kalnin�</td><td class=bc>-</td><td class=bl>Kr Gutmanis</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ka Purin�</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ar Salmin�</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ra Martu�ans</td><td class=bc>-</td><td class=blW>Al Pimenovs</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Iv Kirsis</td><td class=bc>-</td><td class=bl>Il Kirse</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ra Ladusans</td><td class=bc>-</td><td class=bl>Gi Vazolin�</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Ja Zemnickis</td><td class=bc>5 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Re Stacevics</td><td class=bc>-</td><td class=bl>Ar Verbics</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ro Aserin�</td><td class=bc>-</td><td class=blW>Ar Pavlovs</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>An Zilicka</td><td class=bc>-</td><td class=bl>Uv Vikmanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Da Vesele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=bl>Kr Gutmanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ri Kalnin�</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ka Purin�</td><td class=bc>-</td><td class=blW>Al Pimenovs</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ar Salmin�</td><td class=bc>-</td><td class=bl>Il Kirse</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ra Martu�ans</td><td class=bc>-</td><td class=blW>Gi Vazolin�</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Iv Kirsis</td><td class=bc>-</td><td class=blW>Ja Zemnickis</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ra Ladusans</td><td class=bc>-</td><td class=bl>Ei Guze</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ar Verbics</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Re Stacevics</td><td class=bc>-</td><td class=bl>Uv Vikmanis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ro Aserin�</td><td class=bc>-</td><td class=bl>Da Vesele</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>An Zilicka</td><td class=bc>-</td><td class=bl>Kr Gutmanis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Al Pimenovs</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ri Kalnin�</td><td class=bc>-</td><td class=bl>Il Kirse</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ka Purin�</td><td class=bc>-</td><td class=bl>Gi Vazolin�</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ar Salmin�</td><td class=bc>-</td><td class=bl>Ja Zemnickis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ra Martu�ans</td><td class=bc>-</td><td class=bl>Ei Guze</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Iv Kirsis</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ar Pavlovs</td><td class=bc>-</td><td class=blW>Uv Vikmanis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ar Verbics</td><td class=bc>-</td><td class=blW>Da Vesele</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Re Stacevics</td><td class=bc>-</td><td class=blW>Kr Gutmanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro Aserin�</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Zilicka</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Al Pimenovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=bl>Il Kirse</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>Gi Vazolin�</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ri Kalnin�</td><td class=bc>-</td><td class=bl>Ja Zemnickis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ka Purin�</td><td class=bc>-</td><td class=blW>Ei Guze</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ar Salmin�</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ra Martu�ans</td><td class=bc>-</td><td class=bl>Ra Ladusans</td><td class=bc>9 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Uv Vikmanis</td><td class=bc>-</td><td class=blW>Da Vesele</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ar Pavlovs</td><td class=bc>-</td><td class=bl>Kr Gutmanis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ar Verbics</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Re Stacevics</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ro Aserin�</td><td class=bc>-</td><td class=bl>Al Pimenovs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>An Zilicka</td><td class=bc>-</td><td class=blW>Il Kirse</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Gi Vazolin�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>Ja Zemnickis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>Ei Guze</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ri Kalnin�</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ka Purin�</td><td class=bc>-</td><td class=bl>Ra Ladusans</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ar Salmin�</td><td class=bc>-</td><td class=bl>Iv Kirsis</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Da Vesele</td><td class=bc>-</td><td class=bl>Kr Gutmanis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Uv Vikmanis</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ar Pavlovs</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ar Verbics</td><td class=bc>-</td><td class=blW>Al Pimenovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Re Stacevics</td><td class=bc>-</td><td class=bl>Il Kirse</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ro Aserin�</td><td class=bc>-</td><td class=blW>Gi Vazolin�</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Zilicka</td><td class=bc>-</td><td class=blW>Ja Zemnickis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ei Guze</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>Ra Ladusans</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ri Kalnin�</td><td class=bc>-</td><td class=bl>Iv Kirsis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ka Purin�</td><td class=bc>-</td><td class=bl>Ra Martu�ans</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Kr Gutmanis</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Da Vesele</td><td class=bc>-</td><td class=blW>Ro Purmalis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Uv Vikmanis</td><td class=bc>-</td><td class=blW>Al Pimenovs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ar Pavlovs</td><td class=bc>-</td><td class=blW>Il Kirse</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ar Verbics</td><td class=bc>-</td><td class=blW>Gi Vazolin�</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Re Stacevics</td><td class=bc>-</td><td class=bl>Ja Zemnickis</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>Ro Aserin�</td><td class=bc>-</td><td class=bl>Ei Guze</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>An Zilicka</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ra Ladusans</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Iv Kirsis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Ra Martu�ans</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ri Kalnin�</td><td class=bc>-</td><td class=blW>Ar Salmin�</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr Gutmanis</td><td class=bc>-</td><td class=blW>Al Pimenovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Da Vesele</td><td class=bc>-</td><td class=blW>Il Kirse</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Uv Vikmanis</td><td class=bc>-</td><td class=blW>Gi Vazolin�</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ar Pavlovs</td><td class=bc>-</td><td class=bl>Ja Zemnickis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ar Verbics</td><td class=bc>-</td><td class=bl>Ei Guze</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Re Stacevics</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Aserin�</td><td class=bc>-</td><td class=bl>Ra Ladusans</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>An Zilicka</td><td class=bc>-</td><td class=blW>Iv Kirsis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ra Martu�ans</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Ar Salmin�</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Ka Purin�</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Al Pimenovs</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Il Kirse</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kr Gutmanis</td><td class=bc>-</td><td class=bl>Gi Vazolin�</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Vesele</td><td class=bc>-</td><td class=blW>Ja Zemnickis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Uv Vikmanis</td><td class=bc>-</td><td class=bl>Ei Guze</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ar Pavlovs</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ar Verbics</td><td class=bc>-</td><td class=blW>Ra Ladusans</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Re Stacevics</td><td class=bc>-</td><td class=bl>Iv Kirsis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ro Aserin�</td><td class=bc>-</td><td class=bl>Ra Martu�ans</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>An Zilicka</td><td class=bc>-</td><td class=blW>Ar Salmin�</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ka Purin�</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Ri Kalnin�</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=blW>Il Kirse</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Gi Vazolin�</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Ja Zemnickis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kr Gutmanis</td><td class=bc>-</td><td class=blW>Ei Guze</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Vesele</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Uv Vikmanis</td><td class=bc>-</td><td class=blW>Ra Ladusans</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ar Pavlovs</td><td class=bc>-</td><td class=blW>Iv Kirsis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ar Verbics</td><td class=bc>-</td><td class=blW>Ra Martu�ans</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Re Stacevics</td><td class=bc>-</td><td class=blW>Ar Salmin�</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ro Aserin�</td><td class=bc>-</td><td class=bl>Ka Purin�</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>An Zilicka</td><td class=bc>-</td><td class=bl>Ri Kalnin�</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Il Kirse</td><td class=bc>-</td><td class=bl>Gi Vazolin�</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Al Pimenovs</td><td class=bc>-</td><td class=bl>Ja Zemnickis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ro Purmalis</td><td class=bc>-</td><td class=bl>Ei Guze</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kr Gutmanis</td><td class=bc>-</td><td class=blW>Ra Ladusans</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Da Vesele</td><td class=bc>-</td><td class=blW>Iv Kirsis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Uv Vikmanis</td><td class=bc>-</td><td class=bl>Ra Martu�ans</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ar Pavlovs</td><td class=bc>-</td><td class=blW>Ar Salmin�</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ar Verbics</td><td class=bc>-</td><td class=bl>Ka Purin�</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Re Stacevics</td><td class=bc>-</td><td class=bl>Ri Kalnin�</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ro Aserin�</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>An Zilicka</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Gi Vazolin�</td><td class=bc>-</td><td class=bl>Ja Zemnickis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Il Kirse</td><td class=bc>-</td><td class=bl>Ei Guze</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Al Pimenovs</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Ra Ladusans</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Iv Kirsis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kr Gutmanis</td><td class=bc>-</td><td class=blW>Ra Martu�ans</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Da Vesele</td><td class=bc>-</td><td class=bl>Ar Salmin�</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Uv Vikmanis</td><td class=bc>-</td><td class=bl>Ka Purin�</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Ar Pavlovs</td><td class=bc>-</td><td class=blW>Ri Kalnin�</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ar Verbics</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Re Stacevics</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ro Aserin�</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Ja Zemnickis</td><td class=bc>-</td><td class=bl>Ei Guze</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Gi Vazolin�</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Il Kirse</td><td class=bc>-</td><td class=bl>Ra Ladusans</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=bl>Iv Kirsis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Ra Martu�ans</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Ar Salmin�</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Kr Gutmanis</td><td class=bc>-</td><td class=bl>Ka Purin�</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Da Vesele</td><td class=bc>-</td><td class=blW>Ri Kalnin�</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Uv Vikmanis</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ar Pavlovs</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ar Verbics</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Re Stacevics</td><td class=bc>-</td><td class=bl>An Zilicka</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Ei Guze</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ja Zemnickis</td><td class=bc>-</td><td class=bl>Ra Ladusans</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Gi Vazolin�</td><td class=bc>-</td><td class=bl>Iv Kirsis</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Il Kirse</td><td class=bc>-</td><td class=blW>Ra Martu�ans</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=bl>Ar Salmin�</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ro Purmalis</td><td class=bc>-</td><td class=bl>Ka Purin�</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Ri Kalnin�</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Kr Gutmanis</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Da Vesele</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Uv Vikmanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ar Pavlovs</td><td class=bc>-</td><td class=bl>An Zilicka</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ar Verbics</td><td class=bc>-</td><td class=bl>Ro Aserin�</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Ra Ladusans</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ei Guze</td><td class=bc>-</td><td class=blW>Iv Kirsis</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ja Zemnickis</td><td class=bc>-</td><td class=bl>Ra Martu�ans</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Gi Vazolin�</td><td class=bc>-</td><td class=bl>Ar Salmin�</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Il Kirse</td><td class=bc>-</td><td class=bl>Ka Purin�</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=blW>Ri Kalnin�</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Kr Gutmanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Da Vesele</td><td class=bc>-</td><td class=bl>An Zilicka</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Uv Vikmanis</td><td class=bc>-</td><td class=bl>Ro Aserin�</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ar Pavlovs</td><td class=bc>-</td><td class=blW>Re Stacevics</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Ra Ladusans</td><td class=bc>-</td><td class=bl>Iv Kirsis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Ra Martu�ans</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ei Guze</td><td class=bc>-</td><td class=blW>Ar Salmin�</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ja Zemnickis</td><td class=bc>-</td><td class=bl>Ka Purin�</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Gi Vazolin�</td><td class=bc>-</td><td class=bl>Ri Kalnin�</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Il Kirse</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>An Zilicka</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Kr Gutmanis</td><td class=bc>-</td><td class=blW>Ro Aserin�</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Da Vesele</td><td class=bc>-</td><td class=blW>Re Stacevics</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Uv Vikmanis</td><td class=bc>-</td><td class=bl>Ar Verbics</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>Iv Kirsis</td><td class=bc>-</td><td class=blW>Ra Martu�ans</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ra Ladusans</td><td class=bc>-</td><td class=blW>Ar Salmin�</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Ka Purin�</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Ei Guze</td><td class=bc>-</td><td class=blW>Ri Kalnin�</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ja Zemnickis</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Gi Vazolin�</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Il Kirse</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Al Pimenovs</td><td class=bc>-</td><td class=bl>An Zilicka</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Ro Aserin�</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>Re Stacevics</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Gutmanis</td><td class=bc>-</td><td class=blW>Ar Verbics</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Da Vesele</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Ra Martu�ans</td><td class=bc>-</td><td class=blW>Ar Salmin�</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Iv Kirsis</td><td class=bc>-</td><td class=bl>Ka Purin�</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Ra Ladusans</td><td class=bc>-</td><td class=bl>Ri Kalnin�</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ei Guze</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ja Zemnickis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Gi Vazolin�</td><td class=bc>-</td><td class=bl>An Zilicka</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Il Kirse</td><td class=bc>-</td><td class=blW>Ro Aserin�</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=blW>Re Stacevics</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ro Purmalis</td><td class=bc>-</td><td class=bl>Ar Verbics</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr Gutmanis</td><td class=bc>-</td><td class=blW>Uv Vikmanis</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=brW>Ar Salmin�</td><td class=bc>-</td><td class=bl>Ka Purin�</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>Ra Martu�ans</td><td class=bc>-</td><td class=blW>Ri Kalnin�</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Iv Kirsis</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ra Ladusans</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ei Guze</td><td class=bc>-</td><td class=blW>An Zilicka</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ja Zemnickis</td><td class=bc>-</td><td class=bl>Ro Aserin�</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Gi Vazolin�</td><td class=bc>-</td><td class=blW>Re Stacevics</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Il Kirse</td><td class=bc>-</td><td class=bl>Ar Verbics</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ro Purmalis</td><td class=bc>-</td><td class=bl>Uv Vikmanis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Da Vesele</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=br>Ka Purin�</td><td class=bc>-</td><td class=blW>Ri Kalnin�</td><td class=bc>0 : 10</tr></td>
<tr><td class=brW>Ar Salmin�</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ra Martu�ans</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Iv Kirsis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ra Ladusans</td><td class=bc>-</td><td class=bl>An Zilicka</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Ro Aserin�</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ei Guze</td><td class=bc>-</td><td class=blW>Re Stacevics</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ja Zemnickis</td><td class=bc>-</td><td class=bl>Ar Verbics</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Gi Vazolin�</td><td class=bc>-</td><td class=blW>Ar Pavlovs</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Il Kirse</td><td class=bc>-</td><td class=blW>Uv Vikmanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=bl>Da Vesele</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Purmalis</td><td class=bc>-</td><td class=blW>Kr Gutmanis</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=brW>Ri Kalnin�</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ka Purin�</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Ar Salmin�</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ra Martu�ans</td><td class=bc>-</td><td class=bl>An Zilicka</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Iv Kirsis</td><td class=bc>-</td><td class=bl>Ro Aserin�</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ra Ladusans</td><td class=bc>-</td><td class=bl>Re Stacevics</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Ar Verbics</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ei Guze</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ja Zemnickis</td><td class=bc>-</td><td class=bl>Uv Vikmanis</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Gi Vazolin�</td><td class=bc>-</td><td class=bl>Da Vesele</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Il Kirse</td><td class=bc>-</td><td class=bl>Kr Gutmanis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Al Pimenovs</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ri Kalnin�</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ka Purin�</td><td class=bc>-</td><td class=blW>An Zilicka</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Ar Salmin�</td><td class=bc>-</td><td class=bl>Ro Aserin�</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ra Martu�ans</td><td class=bc>-</td><td class=bl>Re Stacevics</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Iv Kirsis</td><td class=bc>-</td><td class=bl>Ar Verbics</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ra Ladusans</td><td class=bc>-</td><td class=bl>Ar Pavlovs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Uv Vikmanis</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>Ei Guze</td><td class=bc>-</td><td class=blW>Da Vesele</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ja Zemnickis</td><td class=bc>-</td><td class=blW>Kr Gutmanis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Gi Vazolin�</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Il Kirse</td><td class=bc>-</td><td class=bl>Ro Purmalis</td><td class=bc>2 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
