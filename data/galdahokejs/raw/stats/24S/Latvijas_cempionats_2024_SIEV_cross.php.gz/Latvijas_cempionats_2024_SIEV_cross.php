<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Latvijas cempionats 2024 SIEV</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../24S/Latvijas_cempionats_2024_SIEV_index.php">Latvijas cempionats 2024 SIEV, 13. April 2024</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group SIEV A</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>El R�cen�ja</td><td class=kx>*</td>
<td class=kL>1:5 + 1:1</td>
<td class=kL>2:4 + 3:0</td>
<td class=kW>5:0 + 4:4</td>
<td class=kW>3:1 + 3:1</td>
<td class=kW>5:4 + 2:1</td>
<td class=kW>3:1 + 5:2</td>
<td class=br>37:24</td><td class=br>+13</td>
<td class=bc>8 - 2 - 2</td>
<td class=br><strong>18</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>La Kamzola</td><td class=kW>5:1 + 1:1</td>
<td class=kx>*</td>
<td class=kW>4:2 + 2:2</td>
<td class=kW>7:1 + 3:5</td>
<td class=kL>0:2 + 6:2</td>
<td class=kW>4:2 + 3:0</td>
<td class=kT>1:1 + 5:0</td>
<td class=br>41:19</td><td class=br>+22</td>
<td class=bc>7 - 3 - 2</td>
<td class=br><strong>17</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Marg �bele</td><td class=kW>4:2 + 0:3</td>
<td class=kL>2:4 + 2:2</td>
<td class=kx>*</td>
<td class=kL>4:5 + 3:0</td>
<td class=kW>6:1 + 3:0</td>
<td class=kW>4:0 + 2:1</td>
<td class=kW>5:1 + 6:2</td>
<td class=br>41:21</td><td class=br>+20</td>
<td class=bc>8 - 1 - 3</td>
<td class=br><strong>17</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Il �irse</td><td class=kL>0:5 + 4:4</td>
<td class=kL>1:7 + 5:3</td>
<td class=kW>5:4 + 0:3</td>
<td class=kx>*</td>
<td class=kW>3:2 + 0:1</td>
<td class=kW>5:2 + 2:1</td>
<td class=kW>5:2 + 2:0</td>
<td class=br>32:34</td><td class=br>-2</td>
<td class=bc>7 - 1 - 4</td>
<td class=br><strong>15</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>B</td><td class=d>5.</td><td class=kt>An Zi�icka</td><td class=kL>1:3 + 1:3</td>
<td class=kW>2:0 + 2:6</td>
<td class=kL>1:6 + 0:3</td>
<td class=kL>2:3 + 1:0</td>
<td class=kx>*</td>
<td class=kW>8:0 + 0:3</td>
<td class=kW>2:1 + 3:4</td>
<td class=br>23:32</td><td class=br>-9</td>
<td class=bc>4 - 0 - 8</td>
<td class=br><strong>8</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>B</td><td class=d>6.</td><td class=kt>D� Vesele</td><td class=kL>4:5 + 1:2</td>
<td class=kL>2:4 + 0:3</td>
<td class=kL>0:4 + 1:2</td>
<td class=kL>2:5 + 1:2</td>
<td class=kL>0:8 + 3:0</td>
<td class=kx>*</td>
<td class=kW>3:1 + 4:2</td>
<td class=br>21:38</td><td class=br>-17</td>
<td class=bc>3 - 0 - 9</td>
<td class=br><strong>6</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>B</td><td class=d>7.</td><td class=kt>As Kocere</td><td class=kL>1:3 + 2:5</td>
<td class=kT>1:1 + 0:5</td>
<td class=kL>1:5 + 2:6</td>
<td class=kL>2:5 + 0:2</td>
<td class=kL>1:2 + 4:3</td>
<td class=kL>1:3 + 2:4</td>
<td class=kx>*</td>
<td class=br>17:44</td><td class=br>-27</td>
<td class=bc>1 - 1 - 10</td>
<td class=br><strong>3</strong></td><td class=d>7.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>An Zi�icka</td><td class=bc>6 : 1 + 3 : 0</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>5 : 2 + 2 : 1</tr></td>
<tr><td class=brW>La Kamzola</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>5 : 1 + 1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>An Zi�icka</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>8 : 0 + 0 : 3</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>4 : 2 + 0 : 3</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>5 : 2 + 2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>4 : 5 + 1 : 2</tr></td>
<tr><td class=brW>An Zi�icka</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>2 : 1 + 3 : 4</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>La Kamzola</td><td class=bc>2 : 4 + 2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>3 : 1 + 5 : 2</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>La Kamzola</td><td class=bc>2 : 4 + 0 : 3</tr></td>
<tr><td class=br>An Zi�icka</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>2 : 3 + 1 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>La Kamzola</td><td class=bc>1 : 1 + 0 : 5</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>5 : 0 + 4 : 4</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>0 : 4 + 1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>La Kamzola</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>7 : 1 + 3 : 5</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>1 : 5 + 2 : 6</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>An Zi�icka</td><td class=bc>3 : 1 + 3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>5 : 4 + 0 : 3</tr></td>
<tr><td class=br>La Kamzola</td><td class=bc>-</td><td class=blW>An Zi�icka</td><td class=bc>0 : 2 + 6 : 2</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>1 : 3 + 2 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
<p class=v>Group 2.l�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/2</td><td class=d>1.</td><td class=kt>D� Vesele</td><td class=kx>*</td>
<td class=kT>1:1 + 2:2 + 2:1</td>
<td class=kW>6:1 + 10:0 + 10:0</td>
<td class=br>31:5</td><td class=br>+26</td>
<td class=bc>4 - 2 - 0</td>
<td class=br><strong>10</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/2</td><td class=d>2.</td><td class=kt>An Zi�icka</td><td class=kT>1:1 + 2:2 + 1:2</td>
<td class=kx>*</td>
<td class=kT>1:1 + 2:2 + 10:0</td>
<td class=br>17:8</td><td class=br>+9</td>
<td class=bc>1 - 4 - 1</td>
<td class=br><strong>6</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/2</td><td class=d>3.</td><td class=kt>As Kocere</td><td class=kL>1:6 + 0:10 + 0:10</td>
<td class=kT>1:1 + 2:2 + 0:10</td>
<td class=kx>*</td>
<td class=br>4:39</td><td class=br>-35</td>
<td class=bc>0 - 2 - 4</td>
<td class=br><strong>2</strong></td><td class=d>3.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>An Zi�icka</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>1 : 1 + 2 : 2 + 10 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>1 : 6 + 0 : 10 + 0 : 10</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>An Zi�icka</td><td class=bc>1 : 1 + 2 : 2 + 2 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
