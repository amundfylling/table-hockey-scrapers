<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Rigas Cempionats 2023</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../23RCh/Rigas_Cempionats_2023_index.php">Rigas Cempionats 2023 - play-off </a></span></h2></div></div></div></div><p><div align="center">
<table border=0 cellpadding=2 cellspacing=0>
<tr><th colspan=11 class="hh"><font size="+1"><strong>Finals</strong></font></th></tr>
<tr><td class=br><b>Miglinieks Raivis</b>&nbsp;&nbsp;</td>
<td class=bl>- Kalnin� Rainers&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>5:2&nbsp;&nbsp;</td>
<td class=bl>1:7&nbsp;&nbsp;</td>
<td class=bl>5:2&nbsp;&nbsp;</td>
<td class=bl>1:8&nbsp;&nbsp;</td>
<td class=bl>4:3&nbsp;&nbsp;</td>
<td class=bl>1:2 P&nbsp;&nbsp;</td>
<td class=bl>4:3 P&nbsp;&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>1/2</strong></font></th></tr>
<tr><td class=ar><b>Miglinieks Raivis</b>&nbsp;&nbsp;</td>
<td class=al>- Liepin� Emils&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>5:4&nbsp;&nbsp;</td>
<td class=al>4:3 P&nbsp;&nbsp;</td>
<td class=al>3:2 P&nbsp;&nbsp;</td>
<td class=al>2:1&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br>Kamzols Rudolfs&nbsp;&nbsp;</td>
<td class=bl><b>- Kalnin� Rainers</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;1 : 4&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:3 P&nbsp;&nbsp;</td>
<td class=bl>7:1&nbsp;&nbsp;</td>
<td class=bl>4:7&nbsp;&nbsp;</td>
<td class=bl>3:4&nbsp;&nbsp;</td>
<td class=bl>3:4 P&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>3rd</strong></font></th></tr>
<tr><td class=ar><b>Liepin� Emils</b>&nbsp;&nbsp;</td>
<td class=al>- Kamzols Rudolfs&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:4 P&nbsp;&nbsp;</td>
<td class=al>1:2&nbsp;&nbsp;</td>
<td class=al>6:2&nbsp;&nbsp;</td>
<td class=al>5:2&nbsp;&nbsp;</td>
<td class=al>7:3&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>1/4</strong></font></th></tr>
<tr><td class=br><b>Miglinieks Raivis</b>&nbsp;&nbsp;</td>
<td class=bl>- Riekstin� Rolands&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 0&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>5:2&nbsp;&nbsp;</td>
<td class=bl>3:2&nbsp;&nbsp;</td>
<td class=bl>4:3 P&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Liepin� Emils</b>&nbsp;&nbsp;</td>
<td class=al>- Smagars Valts&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;4 : 1&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:1&nbsp;&nbsp;</td>
<td class=al>6:2&nbsp;&nbsp;</td>
<td class=al>3:4&nbsp;&nbsp;</td>
<td class=al>4:3 P&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br><b>Kamzols Rudolfs</b>&nbsp;&nbsp;</td>
<td class=bl>- Jakseboga Matiss&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;4 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>3:0&nbsp;&nbsp;</td>
<td class=bl>5:2&nbsp;&nbsp;</td>
<td class=bl>4:5&nbsp;&nbsp;</td>
<td class=bl>6:1&nbsp;&nbsp;</td>
<td class=bl>2:5&nbsp;&nbsp;</td>
<td class=bl>2:5&nbsp;&nbsp;</td>
<td class=bl>5:3&nbsp;&nbsp;</td>
</tr><tr><td class=ar>Silin� Elvijs&nbsp;&nbsp;</td>
<td class=al><b>- Kalnin� Rainers</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;1 : 4&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:0&nbsp;&nbsp;</td>
<td class=al>2:5&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>1:2&nbsp;&nbsp;</td>
<td class=al>0:1 P&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><th colspan=11 class="hh"><font size="+1"><strong>1/8</strong></font></th></tr>
<tr><td class=br>Miglinieks Raivis (1)&nbsp;&nbsp;</td>
<td class=bl>- -&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar>Ziemelis Didzis (8)&nbsp;&nbsp;</td>
<td class=al><b>- Riekstin� Rolands (9)</b>&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;0 : 3&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>2:3&nbsp;&nbsp;</td>
<td class=al>1:2 P&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br>Silin� Alvis (5)&nbsp;&nbsp;</td>
<td class=bl><b>- Liepin� Emils (12)</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;2 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>5:1&nbsp;&nbsp;</td>
<td class=bl>5:1&nbsp;&nbsp;</td>
<td class=bl>2:3&nbsp;&nbsp;</td>
<td class=bl>2:5&nbsp;&nbsp;</td>
<td class=bl>1:2&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar>Smagars Valts (4)&nbsp;&nbsp;</td>
<td class=al>- -&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br>Kamzols Rudolfs (3)&nbsp;&nbsp;</td>
<td class=bl>- -&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar><b>Jakseboga Matiss (6)</b>&nbsp;&nbsp;</td>
<td class=al>- Garancs Intars (11)&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;&nbsp;3 : 1&nbsp;&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>3:0&nbsp;&nbsp;</td>
<td class=al>1:2&nbsp;&nbsp;</td>
<td class=al>4:1&nbsp;&nbsp;</td>
<td class=al>3:2&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr><tr><td class=br>Naglis Edgars (7)&nbsp;&nbsp;</td>
<td class=bl><b>- Silin� Elvijs (10)</b>&nbsp;&nbsp;</td>
<td class=bl><strong>&nbsp;&nbsp;0 : 3&nbsp;&nbsp;</strong></td><td class=bl>&nbsp;&nbsp;&nbsp;</td>
<td class=bl>2:3&nbsp;&nbsp;</td>
<td class=bl>1:2 P&nbsp;&nbsp;</td>
<td class=bl>1:6&nbsp;&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
<td class=bl>&nbsp;</td>
</tr><tr><td class=ar>Kalnin� Rainers (2)&nbsp;&nbsp;</td>
<td class=al>- -&nbsp;&nbsp;</td>
<td class=al><strong>&nbsp;</strong></td><td class=al>&nbsp;&nbsp;&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
<td class=al>&nbsp;</td>
</tr></table>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
