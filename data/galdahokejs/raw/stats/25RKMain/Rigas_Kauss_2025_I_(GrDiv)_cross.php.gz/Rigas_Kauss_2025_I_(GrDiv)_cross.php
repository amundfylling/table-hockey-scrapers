<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Rigas Kauss 2025 I (Gr+Div)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="../25RKMain/Rigas_Kauss_2025_I_(GrDiv)_index.php">Rigas Kauss 2025 I (Gr+Div), 6. December 2025</a></span></h2></div></div></div></div><p><div align="center">
<div align=center><p>
<a href="#basic">Basic groups</a><br>
<a href="#final">Final groups</a><br>
<a name="basic"><p class=vm>Basic groups</p></a>
<p class=v>Group RK A Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ed Nilsson</td><td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>6:5</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>9:1</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=br>80:36</td><td class=br>+44</td>
<td class=bc>14 - 3 - 1</td>
<td class=br><strong>31</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ne �krlep</td><td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>2:6</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kW>6:3</td>
<td class=kW>4:3</td>
<td class=kW>6:5</td>
<td class=kW>2:1</td>
<td class=kW>7:6</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=br>80:49</td><td class=br>+31</td>
<td class=bc>15 - 1 - 2</td>
<td class=br><strong>31</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ar Matantsev</td><td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>7:2</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>6:0</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>10:1</td>
<td class=kW>12:2</td>
<td class=kW>8:1</td>
<td class=br>90:33</td><td class=br>+57</td>
<td class=bc>13 - 3 - 2</td>
<td class=br><strong>29</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Al Sili��</td><td class=kL>0:4</td>
<td class=kW>6:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>11:0</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>8:0</td>
<td class=kW>5:2</td>
<td class=kW>9:0</td>
<td class=kW>6:1</td>
<td class=br>81:28</td><td class=br>+53</td>
<td class=bc>14 - 1 - 3</td>
<td class=br><strong>29</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Al �ernovojs</td><td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=br>56:27</td><td class=br>+29</td>
<td class=bc>13 - 3 - 2</td>
<td class=br><strong>29</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>An Liepi��</td><td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>5:4</td>
<td class=kL>4:5</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>6:4</td>
<td class=kW>6:1</td>
<td class=kW>7:0</td>
<td class=kW>8:2</td>
<td class=kW>9:0</td>
<td class=br>82:38</td><td class=br>+44</td>
<td class=bc>12 - 2 - 4</td>
<td class=br><strong>26</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Vi Henttonen</td><td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=kW>8:1</td>
<td class=kW>3:0</td>
<td class=kW>7:0</td>
<td class=kW>4:0</td>
<td class=kW>10:0</td>
<td class=br>74:37</td><td class=br>+37</td>
<td class=bc>11 - 2 - 5</td>
<td class=br><strong>24</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Go Lonnqvist</td><td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>10:0</td>
<td class=br>54:42</td><td class=br>+12</td>
<td class=bc>9 - 2 - 7</td>
<td class=br><strong>20</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Bi Karlsson</td><td class=kL>5:6</td>
<td class=kL>3:6</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>4:5</td>
<td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>7:2</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=br>65:51</td><td class=br>+14</td>
<td class=bc>9 - 1 - 8</td>
<td class=br><strong>19</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Il �irse</td><td class=kL>3:6</td>
<td class=kL>3:4</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kL>1:2</td>
<td class=kL>3:6</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=br>53:52</td><td class=br>+1</td>
<td class=bc>8 - 2 - 8</td>
<td class=br><strong>18</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ro Verbi�s</td><td class=kL>2:3</td>
<td class=kL>5:6</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>9:1</td>
<td class=br>64:49</td><td class=br>+15</td>
<td class=bc>9 - 0 - 9</td>
<td class=br><strong>18</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>Do Zupan�i�</td><td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>0:6</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=br>44:45</td><td class=br>-1</td>
<td class=bc>7 - 1 - 10</td>
<td class=br><strong>15</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ag Pav�rs</td><td class=kL>3:6</td>
<td class=kL>6:7</td>
<td class=kT>2:2</td>
<td class=kL>0:11</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>2:7</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kL>1:6</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kW>3:0</td>
<td class=kW>11:0</td>
<td class=br>48:62</td><td class=br>-14</td>
<td class=bc>5 - 3 - 10</td>
<td class=br><strong>13</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ma Krauze</td><td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>5:4</td>
<td class=br>38:61</td><td class=br>-23</td>
<td class=bc>6 - 0 - 12</td>
<td class=br><strong>12</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>As Kocere</td><td class=kL>1:9</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>4:6</td>
<td class=kL>1:8</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kW>6:3</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>5:5</td>
<td class=kW>2:1</td>
<td class=kW>8:1</td>
<td class=br>50:78</td><td class=br>-28</td>
<td class=bc>4 - 2 - 12</td>
<td class=br><strong>10</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Ri D�cis</td><td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>0:8</td>
<td class=kL>0:6</td>
<td class=kL>1:6</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=kL>1:3</td>
<td class=br>24:81</td><td class=br>-57</td>
<td class=bc>3 - 1 - 14</td>
<td class=br><strong>7</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Kr S�manis</td><td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kL>1:10</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>0:7</td>
<td class=kL>0:7</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kL>0:1</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kT>5:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>12:3</td>
<td class=br>40:88</td><td class=br>-48</td>
<td class=bc>2 - 1 - 15</td>
<td class=br><strong>5</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>E</td><td class=d>18.</td><td class=kt>To Ulis</td><td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kL>2:12</td>
<td class=kL>0:9</td>
<td class=kT>2:2</td>
<td class=kL>2:8</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=br>26:89</td><td class=br>-63</td>
<td class=bc>1 - 1 - 16</td>
<td class=br><strong>3</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>E</td><td class=d>19.</td><td class=kt>Ju Forsberg</td><td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kL>1:8</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kL>0:9</td>
<td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>1:9</td>
<td class=kL>1:7</td>
<td class=kL>0:11</td>
<td class=kL>4:5</td>
<td class=kL>1:8</td>
<td class=kW>3:1</td>
<td class=kL>3:12</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=br>24:127</td><td class=br>-103</td>
<td class=bc>1 - 1 - 16</td>
<td class=br><strong>3</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=blW>Ed Nilsson</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ju Forsberg</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>To Ulis</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>Ne �krlep</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Do Zupan�i�</td><td class=bc>-</td><td class=blW>Go Lonnqvist</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>Bi Karlsson</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ed Nilsson</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ju Forsberg</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>To Ulis</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Ne �krlep</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>Bi Karlsson</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Do Zupan�i�</td><td class=bc>-</td><td class=blW>Ro Verbi�s</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Al Sili��</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ed Nilsson</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ju Forsberg</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>Ne �krlep</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>To Ulis</td><td class=bc>-</td><td class=blW>Go Lonnqvist</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Bi Karlsson</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Ro Verbi�s</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ed Nilsson</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=blW>Ne �krlep</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ju Forsberg</td><td class=bc>-</td><td class=blW>Go Lonnqvist</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>Bi Karlsson</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>To Ulis</td><td class=bc>-</td><td class=blW>Ro Verbi�s</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>As Kocere</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Do Zupan�i�</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ar Matantsev</td><td class=bc>-</td><td class=blW>Ne �krlep</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ed Nilsson</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=blW>Bi Karlsson</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ju Forsberg</td><td class=bc>-</td><td class=blW>Ro Verbi�s</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>To Ulis</td><td class=bc>-</td><td class=blW>Do Zupan�i�</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>As Kocere</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Ne �krlep</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Bi Karlsson</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ed Nilsson</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ju Forsberg</td><td class=bc>-</td><td class=blW>Do Zupan�i�</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>To Ulis</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Ne �krlep</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Bi Karlsson</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ed Nilsson</td><td class=bc>-</td><td class=bl>Do Zupan�i�</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ju Forsberg</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>0 : 11</tr></td>
<tr><td class=brW>Ri D�cis</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ne �krlep</td><td class=bc>-</td><td class=bl>Go Lonnqvist</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Bi Karlsson</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Do Zupan�i�</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ed Nilsson</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>Ju Forsberg</td><td class=bc>-</td><td class=blW>To Ulis</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Go Lonnqvist</td><td class=bc>-</td><td class=bl>Bi Karlsson</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ne �krlep</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Do Zupan�i�</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>11 : 0</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ed Nilsson</td><td class=bc>-</td><td class=bl>To Ulis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=blW>Ri D�cis</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Bi Karlsson</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ne �krlep</td><td class=bc>-</td><td class=bl>Do Zupan�i�</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>To Ulis</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ed Nilsson</td><td class=bc>-</td><td class=bl>Ju Forsberg</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Bi Karlsson</td><td class=bc>-</td><td class=bl>Do Zupan�i�</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Go Lonnqvist</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ne �krlep</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>7 : 6</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=bl>To Ulis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Al Sili��</td><td class=bc>-</td><td class=bl>Ju Forsberg</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ar Matantsev</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>10 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>Do Zupan�i�</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Bi Karlsson</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Go Lonnqvist</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ne �krlep</td><td class=bc>-</td><td class=bl>To Ulis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Ju Forsberg</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>An Liepi��</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Al Sili��</td><td class=bc>-</td><td class=blW>Ed Nilsson</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Do Zupan�i�</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Bi Karlsson</td><td class=bc>-</td><td class=bl>To Ulis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Go Lonnqvist</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ne �krlep</td><td class=bc>-</td><td class=bl>Ju Forsberg</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Vi Henttonen</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Al �ernovojs</td><td class=bc>-</td><td class=bl>Ed Nilsson</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>An Liepi��</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Do Zupan�i�</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>To Ulis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Bi Karlsson</td><td class=bc>-</td><td class=bl>Ju Forsberg</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Go Lonnqvist</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ne �krlep</td><td class=bc>-</td><td class=bl>Ed Nilsson</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Al �ernovojs</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>To Ulis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Do Zupan�i�</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Ju Forsberg</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Bi Karlsson</td><td class=bc>-</td><td class=blW>Ed Nilsson</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ne �krlep</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Vi Henttonen</td><td class=bc>-</td><td class=bl>An Liepi��</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>As Kocere</td><td class=bc>-</td><td class=bl>To Ulis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>Ju Forsberg</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Do Zupan�i�</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Ed Nilsson</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Bi Karlsson</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ne �krlep</td><td class=bc>-</td><td class=bl>Al �ernovojs</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>To Ulis</td><td class=bc>-</td><td class=blW>Ri D�cis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>As Kocere</td><td class=bc>-</td><td class=bl>Ju Forsberg</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>Ed Nilsson</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Do Zupan�i�</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Bi Karlsson</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Go Lonnqvist</td><td class=bc>-</td><td class=blW>Vi Henttonen</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>Ju Forsberg</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>To Ulis</td><td class=bc>-</td><td class=blW>Kr S�manis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Ed Nilsson</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Ar Matantsev</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Do Zupan�i�</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Bi Karlsson</td><td class=bc>-</td><td class=blW>Ne �krlep</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Ju Forsberg</td><td class=bc>-</td><td class=blW>Kr S�manis</td><td class=bc>3 : 12</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>Ed Nilsson</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>To Ulis</td><td class=bc>-</td><td class=blW>Ar Matantsev</td><td class=bc>2 : 12</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Al Sili��</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>An Liepi��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>Al �ernovojs</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Do Zupan�i�</td><td class=bc>-</td><td class=bl>Vi Henttonen</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Ne �krlep</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>Go Lonnqvist</td><td class=bc>1 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group RK B Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ra Miglinieks</td><td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=k>&nbsp;</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>8:3</td>
<td class=kW>10:0</td>
<td class=kW>15:0</td>
<td class=br>84:29</td><td class=br>+55</td>
<td class=bc>14 - 1 - 2</td>
<td class=br><strong>29</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ed Ka�eps</td><td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>4:4</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>6:1</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>7:2</td>
<td class=kW>10:0</td>
<td class=kW>5:1</td>
<td class=br>70:29</td><td class=br>+41</td>
<td class=bc>13 - 3 - 2</td>
<td class=br><strong>29</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Lu Jurka</td><td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>3:0</td>
<td class=kW>9:0</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=br>61:26</td><td class=br>+35</td>
<td class=bc>12 - 3 - 3</td>
<td class=br><strong>27</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ed Caics</td><td class=kT>3:3</td>
<td class=kT>4:4</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>11:0</td>
<td class=kW>8:1</td>
<td class=br>71:26</td><td class=br>+45</td>
<td class=bc>11 - 4 - 3</td>
<td class=br><strong>26</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Sa Kalni��</td><td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kW>6:3</td>
<td class=kW>2:0</td>
<td class=kL>3:4</td>
<td class=kW>5:1</td>
<td class=kT>1:1</td>
<td class=kW>6:3</td>
<td class=kW>12:0</td>
<td class=kW>8:0</td>
<td class=br>62:34</td><td class=br>+28</td>
<td class=bc>11 - 2 - 5</td>
<td class=br><strong>24</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>J� Z�l�te</td><td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kT>0:0</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=kW>5:4</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>6:0</td>
<td class=kW>3:0</td>
<td class=br>61:31</td><td class=br>+30</td>
<td class=bc>11 - 2 - 5</td>
<td class=br><strong>24</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Si Pleikys</td><td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=k>&nbsp;</td>
<td class=kW>7:0</td>
<td class=kW>10:0</td>
<td class=kW>6:1</td>
<td class=br>54:33</td><td class=br>+21</td>
<td class=bc>11 - 1 - 5</td>
<td class=br><strong>23</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Sa Krasts</td><td class=k>&nbsp;</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=br>51:25</td><td class=br>+26</td>
<td class=bc>11 - 1 - 5</td>
<td class=br><strong>23</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Ma Zenisek</td><td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=kW>7:2</td>
<td class=br>59:37</td><td class=br>+22</td>
<td class=bc>10 - 3 - 5</td>
<td class=br><strong>23</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>D� Apfelbaums</td><td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kL>3:5</td>
<td class=kW>4:1</td>
<td class=kW>7:3</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>9:0</td>
<td class=kW>6:0</td>
<td class=br>63:30</td><td class=br>+33</td>
<td class=bc>11 - 0 - 7</td>
<td class=br><strong>22</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>M� �irsis</td><td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kL>4:5</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=br>45:41</td><td class=br>+4</td>
<td class=bc>9 - 2 - 7</td>
<td class=br><strong>20</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>Ka Vi�ums</td><td class=kL>0:1</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>3:6</td>
<td class=kT>0:0</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=br>30:37</td><td class=br>-7</td>
<td class=bc>7 - 2 - 9</td>
<td class=br><strong>16</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>On Gruncl</td><td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>5:2</td>
<td class=br>46:55</td><td class=br>-9</td>
<td class=bc>6 - 3 - 9</td>
<td class=br><strong>15</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ig Zamiatin</td><td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kW>4:3</td>
<td class=kL>0:7</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=br>38:64</td><td class=br>-26</td>
<td class=bc>6 - 1 - 11</td>
<td class=br><strong>13</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>An Kova��uks</td><td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>3:7</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kT>2:2</td>
<td class=kW>8:1</td>
<td class=br>40:69</td><td class=br>-29</td>
<td class=bc>3 - 2 - 13</td>
<td class=br><strong>8</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Ro Aseri��</td><td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=k>&nbsp;</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=br>24:37</td><td class=br>-13</td>
<td class=bc>3 - 2 - 12</td>
<td class=br><strong>8</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Br Gor�anovs</td><td class=kL>3:8</td>
<td class=kL>2:7</td>
<td class=kL>0:9</td>
<td class=kL>0:5</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kL>0:7</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>4:5</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>1:7</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>9:2</td>
<td class=kW>4:2</td>
<td class=br>34:89</td><td class=br>-55</td>
<td class=bc>2 - 1 - 15</td>
<td class=br><strong>5</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>E</td><td class=d>18.</td><td class=kt>An Israelsson</td><td class=kL>0:10</td>
<td class=kL>0:10</td>
<td class=kL>0:4</td>
<td class=kL>0:11</td>
<td class=kL>0:12</td>
<td class=kL>0:6</td>
<td class=kL>0:10</td>
<td class=kL>0:5</td>
<td class=kL>1:7</td>
<td class=kL>0:9</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>0:6</td>
<td class=kL>2:9</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>11:119</td><td class=br>-108</td>
<td class=bc>1 - 1 - 16</td>
<td class=br><strong>3</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>E</td><td class=d>19.</td><td class=kt>Em Vi��akovs</td><td class=kL>0:15</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>1:8</td>
<td class=kL>0:8</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>2:7</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>1:8</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>13:106</td><td class=br>-93</td>
<td class=bc>0 - 0 - 18</td>
<td class=br><strong>0</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>0 : 15</tr></td>
<tr><td class=br>An Israelsson</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Ig Zamiatin</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>An Israelsson</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>0 : 12</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ig Zamiatin</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>1 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>An Israelsson</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ig Zamiatin</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>An Israelsson</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ig Zamiatin</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>On Gruncl</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Caics</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>An Israelsson</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>On Gruncl</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ig Zamiatin</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>On Gruncl</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>An Israelsson</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Lu Jurka</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>An Israelsson</td><td class=bc>-</td><td class=blW>Ig Zamiatin</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Ma Zenisek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Si Pleikys</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Ig Zamiatin</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=bl>Si Pleikys</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>J� Z�l�te</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>Ig Zamiatin</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=bl>An Israelsson</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>J� Z�l�te</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ma Zenisek</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>Ig Zamiatin</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>An Israelsson</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Ed Caics</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>8 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Ig Zamiatin</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>An Israelsson</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ra Miglinieks</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ka Vi�ums</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>J� Z�l�te</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ma Zenisek</td><td class=bc>-</td><td class=bl>Ig Zamiatin</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>An Israelsson</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Ed Ka�eps</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Lu Jurka</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>On Gruncl</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ka Vi�ums</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>J� Z�l�te</td><td class=bc>-</td><td class=bl>Ig Zamiatin</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>7 : 0</tr></td>
<tr><td class=brW>Ma Zenisek</td><td class=bc>-</td><td class=bl>An Israelsson</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Sa Krasts</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Sa Kalni��</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ed Ka�eps</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=bl>Ig Zamiatin</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>J� Z�l�te</td><td class=bc>-</td><td class=bl>An Israelsson</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Zenisek</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Sa Kalni��</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>Ig Zamiatin</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>On Gruncl</td><td class=bc>-</td><td class=bl>An Israelsson</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ka Vi�ums</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>J� Z�l�te</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>D� Apfelbaums</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Ig Zamiatin</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>An Israelsson</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>J� Z�l�te</td><td class=bc>-</td><td class=bl>Ra Miglinieks</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Sa Krasts</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>An Israelsson</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Ig Zamiatin</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=bl>Ed Caics</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Si Pleikys</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma Zenisek</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>An Israelsson</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ig Zamiatin</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=bl>Lu Jurka</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=bl>Ed Ka�eps</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Sa Kalni��</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>D� Apfelbaums</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Si Pleikys</td><td class=bc>-</td><td class=bl>Sa Krasts</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>An Israelsson</td><td class=bc>-</td><td class=blW>Ed Caics</td><td class=bc>0 : 11</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Ra Miglinieks</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Ig Zamiatin</td><td class=bc>-</td><td class=blW>Lu Jurka</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>Ed Ka�eps</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Sa Kalni��</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>On Gruncl</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Sa Krasts</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>J� Z�l�te</td><td class=bc>-</td><td class=blW>Ma Zenisek</td><td class=bc>2 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group RK C Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Kr Naglis</td><td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kL>3:7</td>
<td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>8:1</td>
<td class=kW>9:0</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>11:1</td>
<td class=br>87:32</td><td class=br>+55</td>
<td class=bc>15 - 1 - 2</td>
<td class=br><strong>31</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ev Matantsev</td><td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kW>5:4</td>
<td class=kW>6:3</td>
<td class=kW>9:1</td>
<td class=kW>7:2</td>
<td class=kW>5:4</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>8:3</td>
<td class=kW>5:0</td>
<td class=br>97:45</td><td class=br>+52</td>
<td class=bc>15 - 0 - 3</td>
<td class=br><strong>30</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Pa Petr</td><td class=kL>3:4</td>
<td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>7:3</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>6:1</td>
<td class=kT>4:4</td>
<td class=kW>4:0</td>
<td class=kW>8:0</td>
<td class=kW>8:4</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>8:2</td>
<td class=kW>6:1</td>
<td class=kW>8:2</td>
<td class=kW>10:0</td>
<td class=br>97:39</td><td class=br>+58</td>
<td class=bc>13 - 3 - 2</td>
<td class=br><strong>29</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Ro Rieksti��</td><td class=kW>4:1</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>6:5</td>
<td class=kW>7:2</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=kW>9:4</td>
<td class=kW>5:1</td>
<td class=kW>11:2</td>
<td class=br>86:37</td><td class=br>+49</td>
<td class=bc>13 - 2 - 3</td>
<td class=br><strong>28</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Fi Buhtujevs</td><td class=kW>7:3</td>
<td class=kL>3:6</td>
<td class=kL>3:7</td>
<td class=kL>5:6</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kW>6:4</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>6:1</td>
<td class=kW>6:1</td>
<td class=kW>5:4</td>
<td class=kW>10:0</td>
<td class=br>82:50</td><td class=br>+32</td>
<td class=bc>13 - 0 - 5</td>
<td class=br><strong>26</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ar Zasurcevs</td><td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>10:4</td>
<td class=kW>6:0</td>
<td class=br>64:47</td><td class=br>+17</td>
<td class=bc>11 - 2 - 5</td>
<td class=br><strong>24</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Kr Zem�ickis</td><td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kW>9:0</td>
<td class=kW>6:4</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=br>66:37</td><td class=br>+29</td>
<td class=bc>10 - 3 - 5</td>
<td class=br><strong>23</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>My Shalomayev</td><td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>7:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>12:0</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=br>73:37</td><td class=br>+36</td>
<td class=bc>11 - 1 - 6</td>
<td class=br><strong>23</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Ja Forsberg</td><td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kW>7:2</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>2:0</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kW>7:2</td>
<td class=br>49:45</td><td class=br>+4</td>
<td class=bc>9 - 3 - 6</td>
<td class=br><strong>21</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Ed Putni��</td><td class=kL>1:6</td>
<td class=kL>1:9</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kW>4:1</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kL>1:7</td>
<td class=kW>6:1</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>15:1</td>
<td class=br>66:60</td><td class=br>+6</td>
<td class=bc>8 - 2 - 8</td>
<td class=br><strong>18</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ei G�ze</td><td class=kL>1:2</td>
<td class=kL>2:7</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>4:6</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=br>46:45</td><td class=br>+1</td>
<td class=bc>7 - 3 - 8</td>
<td class=br><strong>17</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>�v Vikmanis</td><td class=kL>1:8</td>
<td class=kL>4:5</td>
<td class=kL>0:8</td>
<td class=kL>2:7</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=kW>6:3</td>
<td class=br>41:60</td><td class=br>-19</td>
<td class=bc>7 - 2 - 9</td>
<td class=br><strong>16</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>La Karlsson</td><td class=kL>0:9</td>
<td class=kL>2:6</td>
<td class=kL>4:8</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kL>0:1</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=br>43:62</td><td class=br>-19</td>
<td class=bc>7 - 1 - 10</td>
<td class=br><strong>15</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Jo Pleikys</td><td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kW>1:0</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>8:2</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=br>38:51</td><td class=br>-13</td>
<td class=bc>5 - 3 - 10</td>
<td class=br><strong>13</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>J� Zem�ickis</td><td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kW>2:0</td>
<td class=kL>0:9</td>
<td class=kL>0:3</td>
<td class=kL>0:2</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=br>14:51</td><td class=br>-37</td>
<td class=bc>4 - 2 - 12</td>
<td class=br><strong>10</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>�r Egl�tis</td><td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>2:8</td>
<td class=kL>0:7</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>4:6</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=kL>2:6</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=br>33:75</td><td class=br>-42</td>
<td class=bc>3 - 1 - 14</td>
<td class=br><strong>7</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>El Reinfelds</td><td class=kL>1:7</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>4:9</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kL>0:12</td>
<td class=kL>0:1</td>
<td class=kL>3:6</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>2:8</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>12:1</td>
<td class=br>37:82</td><td class=br>-45</td>
<td class=bc>1 - 3 - 14</td>
<td class=br><strong>5</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>E</td><td class=d>18.</td><td class=kt>Gu Skapsts</td><td class=kL>0:4</td>
<td class=kL>3:8</td>
<td class=kL>2:8</td>
<td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kL>4:10</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>0:6</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=br>32:80</td><td class=br>-48</td>
<td class=bc>1 - 3 - 14</td>
<td class=br><strong>5</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>E</td><td class=d>19.</td><td class=kt>Ro Zygelis</td><td class=kL>1:11</td>
<td class=kL>0:5</td>
<td class=kL>0:10</td>
<td class=kL>2:11</td>
<td class=kL>0:10</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>2:5</td>
<td class=kL>2:7</td>
<td class=kL>1:15</td>
<td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kL>0:6</td>
<td class=kL>1:12</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=br>16:132</td><td class=br>-116</td>
<td class=bc>0 - 1 - 17</td>
<td class=br><strong>1</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>�r Egl�tis</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>La Karlsson</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>4 : 8</tr></td>
<tr><td class=br>Ro Zygelis</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>2 : 11</tr></td>
<tr><td class=br>Gu Skapsts</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Ja Forsberg</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>�r Egl�tis</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>La Karlsson</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Ro Zygelis</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Gu Skapsts</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Ja Forsberg</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Pa Petr</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>�r Egl�tis</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>La Karlsson</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ro Zygelis</td><td class=bc>-</td><td class=blW>Ja Forsberg</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Gu Skapsts</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Kr Naglis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>�r Egl�tis</td><td class=bc>-</td><td class=blW>Ja Forsberg</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>La Karlsson</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ro Zygelis</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Gu Skapsts</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Jo Pleikys</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>�v Vikmanis</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ja Forsberg</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ev Matantsev</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>�r Egl�tis</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>La Karlsson</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Zygelis</td><td class=bc>-</td><td class=blW>Jo Pleikys</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Gu Skapsts</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Ja Forsberg</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Fi Buhtujevs</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>�r Egl�tis</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>La Karlsson</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ro Zygelis</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Gu Skapsts</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>0 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Ja Forsberg</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Kr Naglis</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>3 : 7</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>�r Egl�tis</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>La Karlsson</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ro Zygelis</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>1 : 12</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Ja Forsberg</td><td class=bc>-</td><td class=bl>Kr Zem�ickis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>�r Egl�tis</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>La Karlsson</td><td class=bc>-</td><td class=bl>Gu Skapsts</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Fi Buhtujevs</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ja Forsberg</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>Gu Skapsts</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>�r Egl�tis</td><td class=bc>-</td><td class=bl>Ro Zygelis</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ja Forsberg</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>Gu Skapsts</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>Ro Zygelis</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Ev Matantsev</td><td class=bc>-</td><td class=bl>La Karlsson</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Jo Pleikys</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Ja Forsberg</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>12 : 0</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Gu Skapsts</td><td class=bc>10 : 4</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Ro Zygelis</td><td class=bc>11 : 1</tr></td>
<tr><td class=brW>Ro Rieksti��</td><td class=bc>-</td><td class=bl>La Karlsson</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Pa Petr</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>8 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ja Forsberg</td><td class=bc>-</td><td class=bl>Gu Skapsts</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>Ro Zygelis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>La Karlsson</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ro Rieksti��</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Gu Skapsts</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>Ro Zygelis</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ja Forsberg</td><td class=bc>-</td><td class=bl>La Karlsson</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>My Shalomayev</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ar Zasurcevs</td><td class=bc>-</td><td class=bl>Ev Matantsev</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Kr Naglis</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Jo Pleikys</td><td class=bc>-</td><td class=bl>Gu Skapsts</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>Ro Zygelis</td><td class=bc>15 : 1</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>La Karlsson</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Ja Forsberg</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ar Zasurcevs</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>�v Vikmanis</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Gu Skapsts</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>Ro Zygelis</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Jo Pleikys</td><td class=bc>-</td><td class=bl>La Karlsson</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Forsberg</td><td class=bc>-</td><td class=bl>Ro Rieksti��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>My Shalomayev</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>Gu Skapsts</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>�v Vikmanis</td><td class=bc>-</td><td class=bl>Ro Zygelis</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>La Karlsson</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>Pa Petr</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>5 : 6</tr></td>
<tr><td class=br>Kr Zem�ickis</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Forsberg</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>Gu Skapsts</td><td class=bc>-</td><td class=bl>Ro Zygelis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>La Karlsson</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>�v Vikmanis</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Fi Buhtujevs</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Kr Zem�ickis</td><td class=bc>-</td><td class=bl>My Shalomayev</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ro Zygelis</td><td class=bc>-</td><td class=blW>La Karlsson</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Gu Skapsts</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=blW>Ar Zasurcevs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Fi Buhtujevs</td><td class=bc>-</td><td class=bl>Ja Forsberg</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>La Karlsson</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ro Zygelis</td><td class=bc>-</td><td class=blW>Ev Matantsev</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Gu Skapsts</td><td class=bc>-</td><td class=blW>Pa Petr</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Ro Rieksti��</td><td class=bc>4 : 9</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Kr Naglis</td><td class=bc>1 : 8</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Ar Zasurcevs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>My Shalomayev</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=bl>Ja Forsberg</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Kr Zem�ickis</td><td class=bc>2 : 6</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group RK D Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ra Kalni��</td><td class=kx>*</td>
<td class=kW>8:2</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>6:3</td>
<td class=kW>5:3</td>
<td class=kW>6:2</td>
<td class=kT>4:4</td>
<td class=kW>6:0</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>8:2</td>
<td class=kW>9:3</td>
<td class=kW>8:0</td>
<td class=kW>6:2</td>
<td class=br>103:29</td><td class=br>+74</td>
<td class=bc>17 - 1 - 0</td>
<td class=br><strong>35</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Ed Naglis</td><td class=kL>2:8</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>3:5</td>
<td class=kW>5:2</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>6:4</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>9:1</td>
<td class=kW>4:2</td>
<td class=kW>10:0</td>
<td class=kW>4:0</td>
<td class=br>88:40</td><td class=br>+48</td>
<td class=bc>16 - 0 - 2</td>
<td class=br><strong>32</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ro Nuttunen</td><td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>5:4</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kW>8:2</td>
<td class=kW>4:0</td>
<td class=br>75:30</td><td class=br>+45</td>
<td class=bc>14 - 1 - 3</td>
<td class=br><strong>29</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Em Liepi��</td><td class=kL>0:4</td>
<td class=kW>5:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kW>4:3</td>
<td class=kW>8:2</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=br>69:42</td><td class=br>+27</td>
<td class=bc>13 - 0 - 5</td>
<td class=br><strong>26</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>R� Kamzols</td><td class=kL>3:6</td>
<td class=kL>2:5</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kL>4:5</td>
<td class=kW>6:3</td>
<td class=kW>5:3</td>
<td class=kW>7:1</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=br>75:46</td><td class=br>+29</td>
<td class=bc>12 - 1 - 5</td>
<td class=br><strong>25</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Tr M�nsson</td><td class=kL>3:5</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=br>41:35</td><td class=br>+6</td>
<td class=bc>11 - 2 - 5</td>
<td class=br><strong>24</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Gl Storozhenko</td><td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>3:5</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>8:0</td>
<td class=kW>5:1</td>
<td class=br>61:41</td><td class=br>+20</td>
<td class=bc>11 - 1 - 6</td>
<td class=br><strong>23</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ig Saveljev</td><td class=kT>4:4</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>6:2</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>8:0</td>
<td class=br>64:40</td><td class=br>+24</td>
<td class=bc>8 - 4 - 6</td>
<td class=br><strong>20</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Ol Pylypenko</td><td class=kL>0:6</td>
<td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>2:8</td>
<td class=kW>5:4</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kL>1:7</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>8:3</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=kW>8:0</td>
<td class=br>62:57</td><td class=br>+5</td>
<td class=bc>9 - 2 - 7</td>
<td class=br><strong>20</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Gu Ern�teins</td><td class=kL>1:7</td>
<td class=kL>4:6</td>
<td class=kL>0:5</td>
<td class=kW>4:3</td>
<td class=kL>3:6</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kW>7:1</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=br>55:49</td><td class=br>+6</td>
<td class=bc>8 - 2 - 8</td>
<td class=br><strong>18</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>To Bucek</td><td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>4:7</td>
<td class=kW>4:1</td>
<td class=kL>4:6</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>8:1</td>
<td class=br>50:57</td><td class=br>-7</td>
<td class=bc>8 - 0 - 10</td>
<td class=br><strong>16</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>Gi Remeika</td><td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kW>4:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=br>44:58</td><td class=br>-14</td>
<td class=bc>7 - 1 - 10</td>
<td class=br><strong>15</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Al Kalni��</td><td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kT>4:4</td>
<td class=kW>7:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=br>50:61</td><td class=br>-11</td>
<td class=bc>6 - 3 - 9</td>
<td class=br><strong>15</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ro Fa�ken�teins</td><td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=br>40:41</td><td class=br>-1</td>
<td class=bc>6 - 2 - 10</td>
<td class=br><strong>14</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>L� Bezdel�ga</td><td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>3:6</td>
<td class=kL>3:8</td>
<td class=kL>1:3</td>
<td class=kW>6:4</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kL>0:4</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=br>37:68</td><td class=br>-31</td>
<td class=bc>4 - 1 - 13</td>
<td class=br><strong>9</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Ro Forsberg</td><td class=kL>2:8</td>
<td class=kL>1:9</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=br>24:60</td><td class=br>-36</td>
<td class=bc>3 - 3 - 12</td>
<td class=br><strong>9</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Ro Garda</td><td class=kL>3:9</td>
<td class=kL>2:4</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=br>27:67</td><td class=br>-40</td>
<td class=bc>3 - 1 - 14</td>
<td class=br><strong>7</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>E</td><td class=d>18.</td><td class=kt>Mi Myren</td><td class=kL>0:8</td>
<td class=kL>0:10</td>
<td class=kL>2:8</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>0:8</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=br>23:88</td><td class=br>-65</td>
<td class=bc>2 - 0 - 16</td>
<td class=br><strong>4</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>E</td><td class=d>19.</td><td class=kt>An Garan�a</td><td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>0:8</td>
<td class=kL>0:8</td>
<td class=kL>0:6</td>
<td class=kL>1:8</td>
<td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=br>12:91</td><td class=br>-79</td>
<td class=bc>0 - 1 - 17</td>
<td class=br><strong>1</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ro Nuttunen</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Mi Myren</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=blW>Tr M�nsson</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Forsberg</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Gu Ern�teins</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=blW>Tr M�nsson</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Myren</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ro Forsberg</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Ol Pylypenko</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>Tr M�nsson</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Myren</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Al Kalni��</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Ro Forsberg</td><td class=bc>-</td><td class=bl>Ol Pylypenko</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Gu Ern�teins</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Em Liepi��</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Tr M�nsson</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ro Nuttunen</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Mi Myren</td><td class=bc>-</td><td class=blW>Ol Pylypenko</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ro Forsberg</td><td class=bc>-</td><td class=blW>Gi Remeika</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>Tr M�nsson</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>Ol Pylypenko</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=blW>Gu Ern�teins</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Mi Myren</td><td class=bc>-</td><td class=blW>Gi Remeika</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Al Kalni��</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Tr M�nsson</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ol Pylypenko</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>Gi Remeika</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ro Garda</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Myren</td><td class=bc>-</td><td class=bl>Ro Forsberg</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Tr M�nsson</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>Ol Pylypenko</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>Ro Forsberg</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=bl>Al Kalni��</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Tr M�nsson</td><td class=bc>-</td><td class=bl>Ol Pylypenko</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>Gu Ern�teins</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Ro Forsberg</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>Al Kalni��</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>Mi Myren</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>Ol Pylypenko</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Tr M�nsson</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Ro Forsberg</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Al Kalni��</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>Mi Myren</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Ro Nuttunen</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ol Pylypenko</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Tr M�nsson</td><td class=bc>-</td><td class=bl>Ro Forsberg</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Al Kalni��</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>Mi Myren</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ra Kalni��</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>6 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ol Pylypenko</td><td class=bc>-</td><td class=blW>Gu Ern�teins</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Ro Forsberg</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Al Kalni��</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Tr M�nsson</td><td class=bc>-</td><td class=bl>Mi Myren</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>R� Kamzols</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Ed Naglis</td><td class=bc>-</td><td class=bl>Ro Nuttunen</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=blW>Gi Remeika</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ol Pylypenko</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ro Forsberg</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Al Kalni��</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Mi Myren</td><td class=bc>8 : 0</tr></td>
<tr><td class=brW>Ig Saveljev</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Tr M�nsson</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Em Liepi��</td><td class=bc>-</td><td class=blW>Ro Nuttunen</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>R� Kamzols</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Gi Remeika</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Ro Forsberg</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ol Pylypenko</td><td class=bc>-</td><td class=bl>Al Kalni��</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Mi Myren</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Ro Nuttunen</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Tr M�nsson</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Em Liepi��</td><td class=bc>-</td><td class=bl>Ed Naglis</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Ro Forsberg</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Gi Remeika</td><td class=bc>-</td><td class=bl>Al Kalni��</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Mi Myren</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ol Pylypenko</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Ro Nuttunen</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Tr M�nsson</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ro Forsberg</td><td class=bc>-</td><td class=blW>Al Kalni��</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Mi Myren</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Gi Remeika</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Gu Ern�teins</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Ol Pylypenko</td><td class=bc>-</td><td class=blW>Ro Nuttunen</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Gl Storozhenko</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ig Saveljev</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Al Kalni��</td><td class=bc>-</td><td class=bl>Mi Myren</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ro Forsberg</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Ro Nuttunen</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ol Pylypenko</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Gl Storozhenko</td><td class=bc>-</td><td class=bl>Tr M�nsson</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Mi Myren</td><td class=bc>-</td><td class=blW>Ro Garda</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Al Kalni��</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ro Forsberg</td><td class=bc>-</td><td class=bl>Ro Nuttunen</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ol Pylypenko</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Tr M�nsson</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Ro Garda</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Mi Myren</td><td class=bc>-</td><td class=blW>Ro Nuttunen</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ro Forsberg</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>1 : 9</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>R� Kamzols</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=blW>Tr M�nsson</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ol Pylypenko</td><td class=bc>-</td><td class=bl>Ig Saveljev</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Gl Storozhenko</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>Ro Nuttunen</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=blW>Ra Kalni��</td><td class=bc>3 : 9</tr></td>
<tr><td class=br>Mi Myren</td><td class=bc>-</td><td class=blW>Ed Naglis</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=bl>R� Kamzols</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Forsberg</td><td class=bc>-</td><td class=blW>Em Liepi��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Tr M�nsson</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Ig Saveljev</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=blW>Gl Storozhenko</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ol Pylypenko</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>1 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group RK E Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Kr Lagzdi�a</td><td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>1:4</td>
<td class=kW>5:4</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kW>2:1</td>
<td class=kW>8:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>6:1</td>
<td class=br>71:27</td><td class=br>+44</td>
<td class=bc>15 - 1 - 2</td>
<td class=br><strong>31</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>El Sili��</td><td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>5:1</td>
<td class=br>67:24</td><td class=br>+43</td>
<td class=bc>15 - 0 - 3</td>
<td class=br><strong>30</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Am Fylling</td><td class=kW>4:1</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>7:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>2:5</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>8:3</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kL>1:2</td>
<td class=kW>10:1</td>
<td class=br>74:36</td><td class=br>+38</td>
<td class=bc>14 - 1 - 3</td>
<td class=br><strong>29</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>Pa Plesak</td><td class=kL>4:5</td>
<td class=kL>0:5</td>
<td class=kL>3:7</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kL>3:4</td>
<td class=kW>6:1</td>
<td class=kW>4:2</td>
<td class=kW>4:1</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>5:4</td>
<td class=kW>5:3</td>
<td class=kW>8:3</td>
<td class=kW>5:0</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=br>82:50</td><td class=br>+32</td>
<td class=bc>13 - 1 - 4</td>
<td class=br><strong>27</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>K� Balodis</td><td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kW>8:0</td>
<td class=kW>4:0</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=br>69:36</td><td class=br>+33</td>
<td class=bc>12 - 2 - 4</td>
<td class=br><strong>26</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ro Kerns</td><td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=br>56:34</td><td class=br>+22</td>
<td class=bc>12 - 1 - 5</td>
<td class=br><strong>25</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>He Prokuratovs</td><td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kW>5:2</td>
<td class=kL>1:6</td>
<td class=kL>2:4</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>5:3</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kL>3:4</td>
<td class=kW>7:1</td>
<td class=kW>7:2</td>
<td class=kW>7:3</td>
<td class=kW>9:2</td>
<td class=br>72:45</td><td class=br>+27</td>
<td class=bc>11 - 2 - 5</td>
<td class=br><strong>24</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>An Bozic</td><td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=br>56:38</td><td class=br>+18</td>
<td class=bc>10 - 3 - 5</td>
<td class=br><strong>23</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>To Jakseboga</td><td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=br>39:46</td><td class=br>-7</td>
<td class=bc>9 - 1 - 8</td>
<td class=br><strong>19</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Zy Remeika</td><td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kW>6:1</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>6:1</td>
<td class=kL>3:4</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=br>60:46</td><td class=br>+14</td>
<td class=bc>8 - 2 - 8</td>
<td class=br><strong>18</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Da Baumanis</td><td class=kL>0:6</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>6:3</td>
<td class=kW>10:1</td>
<td class=kW>4:1</td>
<td class=br>56:48</td><td class=br>+8</td>
<td class=bc>8 - 1 - 9</td>
<td class=br><strong>17</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>La Ulfvensj�</td><td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>3:8</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=br>46:50</td><td class=br>-4</td>
<td class=bc>7 - 1 - 10</td>
<td class=br><strong>15</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Er Kalni��</td><td class=kL>2:8</td>
<td class=kL>0:4</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=br>34:45</td><td class=br>-11</td>
<td class=bc>6 - 2 - 10</td>
<td class=br><strong>14</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Re Stac�vi�s</td><td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>4:5</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>6:1</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=br>39:52</td><td class=br>-13</td>
<td class=bc>6 - 1 - 11</td>
<td class=br><strong>13</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>Da Belkovs</td><td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>6:4</td>
<td class=kW>3:2</td>
<td class=kT>0:0</td>
<td class=br>36:58</td><td class=br>-22</td>
<td class=bc>4 - 3 - 11</td>
<td class=br><strong>11</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Ke Nilsson</td><td class=kL>2:6</td>
<td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kL>3:8</td>
<td class=kL>0:8</td>
<td class=kL>1:3</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:6</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=br>32:79</td><td class=br>-47</td>
<td class=bc>4 - 0 - 14</td>
<td class=br><strong>8</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>M� Timbers</td><td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>2:7</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kL>3:6</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>0:1</td>
<td class=kL>4:6</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=br>28:77</td><td class=br>-49</td>
<td class=bc>3 - 1 - 14</td>
<td class=br><strong>7</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>E</td><td class=d>18.</td><td class=kt>Ra R�ders</td><td class=kL>0:6</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kL>1:7</td>
<td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kL>3:7</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>0:7</td>
<td class=kL>1:10</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=br>22:85</td><td class=br>-63</td>
<td class=bc>2 - 0 - 16</td>
<td class=br><strong>4</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>E</td><td class=d>19.</td><td class=kt>Ed Liepi��</td><td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>1:10</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>2:9</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kT>0:0</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=br>18:81</td><td class=br>-63</td>
<td class=bc>0 - 1 - 17</td>
<td class=br><strong>1</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ke Nilsson</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=blW>Pa Plesak</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>La Ulfvensj�</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ke Nilsson</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>Pa Plesak</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ke Nilsson</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Pa Plesak</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>M� Timbers</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=blW>La Ulfvensj�</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ra R�ders</td><td class=bc>-</td><td class=bl>Am Fylling</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=blW>Pa Plesak</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ke Nilsson</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>La Ulfvensj�</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Kr Lagzdi�a</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>An Bozic</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ke Nilsson</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>La Ulfvensj�</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Pa Plesak</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>El Sili��</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>1 : 10</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>La Ulfvensj�</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ke Nilsson</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Er Kalni��</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>La Ulfvensj�</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ke Nilsson</td><td class=bc>-</td><td class=blW>Er Kalni��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Ro Kerns</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>La Ulfvensj�</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>Er Kalni��</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ke Nilsson</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Ro Kerns</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>La Ulfvensj�</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>M� Timbers</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>An Bozic</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>La Ulfvensj�</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>To Jakseboga</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>Da Belkovs</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>Ke Nilsson</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>La Ulfvensj�</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>He Prokuratovs</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ke Nilsson</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>El Sili��</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>La Ulfvensj�</td><td class=bc>-</td><td class=blW>To Jakseboga</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>Ke Nilsson</td><td class=bc>8 : 0</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Kr Lagzdi�a</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>6 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>La Ulfvensj�</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>Ke Nilsson</td><td class=bc>8 : 3</tr></td>
<tr><td class=brW>Am Fylling</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>K� Balodis</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>He Prokuratovs</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=blW>Er Kalni��</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>La Ulfvensj�</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Ke Nilsson</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>K� Balodis</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>To Jakseboga</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>La Ulfvensj�</td><td class=bc>-</td><td class=bl>Ke Nilsson</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Pa Plesak</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Am Fylling</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Ke Nilsson</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>La Ulfvensj�</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Pa Plesak</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>6 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=brW>M� Timbers</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>Ke Nilsson</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>La Ulfvensj�</td><td class=bc>-</td><td class=blW>Kr Lagzdi�a</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ro Kerns</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Ke Nilsson</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=bl>An Bozic</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=bl>He Prokuratovs</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>La Ulfvensj�</td><td class=bc>-</td><td class=bl>K� Balodis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ro Kerns</td><td class=bc>-</td><td class=bl>Pa Plesak</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Ke Nilsson</td><td class=bc>-</td><td class=blW>An Bozic</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Ra R�ders</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>El Sili��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=bl>Kr Lagzdi�a</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>He Prokuratovs</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=blW>K� Balodis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>To Jakseboga</td><td class=bc>-</td><td class=blW>Am Fylling</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>La Ulfvensj�</td><td class=bc>-</td><td class=blW>Pa Plesak</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>3 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group RK F Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Re Vazoli��</td><td class=kx>*</td>
<td class=kW>8:2</td>
<td class=kW>7:3</td>
<td class=kT>6:6</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>7:1</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>5:3</td>
<td class=kW>8:1</td>
<td class=kW>8:1</td>
<td class=kW>11:1</td>
<td class=br>99:28</td><td class=br>+71</td>
<td class=bc>17 - 1 - 0</td>
<td class=br><strong>35</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Al Skudr�tis</td><td class=kL>2:8</td>
<td class=kx>*</td>
<td class=kW>7:2</td>
<td class=kL>3:7</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kT>4:4</td>
<td class=kW>9:5</td>
<td class=kW>6:2</td>
<td class=kW>8:1</td>
<td class=kW>6:1</td>
<td class=kW>6:2</td>
<td class=kW>9:0</td>
<td class=kW>12:0</td>
<td class=br>100:46</td><td class=br>+54</td>
<td class=bc>13 - 2 - 3</td>
<td class=br><strong>28</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Ti Dion</td><td class=kL>3:7</td>
<td class=kL>2:7</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kL>4:5</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>8:2</td>
<td class=kW>7:3</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kW>10:1</td>
<td class=br>72:41</td><td class=br>+31</td>
<td class=bc>13 - 2 - 3</td>
<td class=br><strong>28</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>An Kuz�ecovs</td><td class=kT>6:6</td>
<td class=kW>7:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kL>0:5</td>
<td class=kW>5:4</td>
<td class=kW>10:0</td>
<td class=kW>6:1</td>
<td class=kW>9:3</td>
<td class=kW>6:0</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>7:1</td>
<td class=br>84:40</td><td class=br>+44</td>
<td class=bc>13 - 1 - 4</td>
<td class=br><strong>27</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ja Koski</td><td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kL>3:6</td>
<td class=kL>0:1</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>6:0</td>
<td class=kW>9:1</td>
<td class=br>70:35</td><td class=br>+35</td>
<td class=bc>13 - 0 - 5</td>
<td class=br><strong>26</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Sa Lagzdi��</td><td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kW>5:4</td>
<td class=kL>2:4</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kW>7:1</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>7:1</td>
<td class=kW>7:0</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=br>71:39</td><td class=br>+32</td>
<td class=bc>11 - 2 - 5</td>
<td class=br><strong>24</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>An Kimberg</td><td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kL>0:5</td>
<td class=kW>3:2</td>
<td class=kW>7:3</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>9:2</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>7:0</td>
<td class=kW>6:1</td>
<td class=br>61:38</td><td class=br>+23</td>
<td class=bc>10 - 3 - 5</td>
<td class=br><strong>23</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>El R�cen�ja</td><td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kL>2:3</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>0:4</td>
<td class=kW>5:0</td>
<td class=kL>0:2</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=kW>8:2</td>
<td class=kW>6:0</td>
<td class=br>63:45</td><td class=br>+18</td>
<td class=bc>11 - 1 - 6</td>
<td class=br><strong>23</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Ti Rimski</td><td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>0:4</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kW>7:1</td>
<td class=kW>6:0</td>
<td class=kT>1:1</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=br>47:25</td><td class=br>+22</td>
<td class=bc>10 - 1 - 7</td>
<td class=br><strong>21</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Si Thomas</td><td class=kL>1:7</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kW>5:0</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>8:4</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=br>60:58</td><td class=br>+2</td>
<td class=bc>9 - 1 - 8</td>
<td class=br><strong>19</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>My Verbytskyy</td><td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>4:5</td>
<td class=kW>5:0</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kT>0:0</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>2:0</td>
<td class=br>44:41</td><td class=br>+3</td>
<td class=bc>9 - 1 - 8</td>
<td class=br><strong>19</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>D� Vesele</td><td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>3:7</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>9:4</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kW>8:2</td>
<td class=kW>9:1</td>
<td class=br>61:53</td><td class=br>+8</td>
<td class=bc>5 - 6 - 7</td>
<td class=br><strong>16</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Kr Zarinieks</td><td class=kL>0:5</td>
<td class=kL>5:9</td>
<td class=kL>1:4</td>
<td class=kL>0:10</td>
<td class=kL>1:7</td>
<td class=kL>1:7</td>
<td class=kT>4:4</td>
<td class=kL>3:5</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kT>0:0</td>
<td class=kL>4:9</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>3:5</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=br>44:76</td><td class=br>-32</td>
<td class=bc>4 - 4 - 10</td>
<td class=br><strong>12</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ja Hansson</td><td class=kL>3:5</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=br>32:55</td><td class=br>-23</td>
<td class=bc>5 - 0 - 13</td>
<td class=br><strong>10</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>Ge Jansons</td><td class=kL>1:5</td>
<td class=kL>1:8</td>
<td class=kL>2:8</td>
<td class=kL>3:9</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>2:9</td>
<td class=kL>2:5</td>
<td class=kL>1:7</td>
<td class=kL>4:8</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>7:2</td>
<td class=kW>6:1</td>
<td class=br>48:88</td><td class=br>-40</td>
<td class=bc>4 - 2 - 12</td>
<td class=br><strong>10</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Ed Garan�s</td><td class=kL>3:5</td>
<td class=kL>1:6</td>
<td class=kL>3:7</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>1:7</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>2:6</td>
<td class=kL>2:6</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=br>30:80</td><td class=br>-50</td>
<td class=bc>2 - 3 - 13</td>
<td class=br><strong>7</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Bi Gajsek</td><td class=kL>1:8</td>
<td class=kL>2:6</td>
<td class=kL>0:2</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>0:7</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=br>26:60</td><td class=br>-34</td>
<td class=bc>2 - 3 - 13</td>
<td class=br><strong>7</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>E</td><td class=d>18.</td><td class=kt>Ju Stei��nas</td><td class=kL>1:8</td>
<td class=kL>0:9</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>0:6</td>
<td class=kL>3:5</td>
<td class=kL>0:7</td>
<td class=kL>2:8</td>
<td class=kL>1:6</td>
<td class=kL>2:6</td>
<td class=kL>2:5</td>
<td class=kL>2:8</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>2:7</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>26:97</td><td class=br>-71</td>
<td class=bc>2 - 1 - 15</td>
<td class=br><strong>5</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>E</td><td class=d>19.</td><td class=kt>Ma Ru�manis</td><td class=kL>1:11</td>
<td class=kL>0:12</td>
<td class=kL>1:10</td>
<td class=kL>1:7</td>
<td class=kL>1:9</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>0:6</td>
<td class=kL>0:5</td>
<td class=kL>3:6</td>
<td class=kL>0:2</td>
<td class=kL>1:9</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>15:108</td><td class=br>-93</td>
<td class=bc>1 - 0 - 17</td>
<td class=br><strong>2</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Ma Ru�manis</td><td class=bc>10 : 1</tr></td>
<tr><td class=br>Bi Gajsek</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=blW>Ti Rimski</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>An Kimberg</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ja Koski</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ma Ru�manis</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Bi Gajsek</td><td class=bc>-</td><td class=bl>Ti Rimski</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=blW>An Kimberg</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>3 : 9</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>0 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ma Ru�manis</td><td class=bc>-</td><td class=blW>Ti Rimski</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Bi Gajsek</td><td class=bc>-</td><td class=blW>An Kimberg</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Ja Koski</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ti Rimski</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Ru�manis</td><td class=bc>-</td><td class=blW>An Kimberg</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Bi Gajsek</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>Ja Koski</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Kr Zarinieks</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ti Rimski</td><td class=bc>-</td><td class=blW>Al Skudr�tis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>An Kimberg</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Ru�manis</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Bi Gajsek</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=blW>Ja Koski</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=blW>Kr Zarinieks</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>An Kimberg</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ti Rimski</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Ru�manis</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Ja Koski</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Bi Gajsek</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ed Garan�s</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=blW>Ja Hansson</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>An Kimberg</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ti Rimski</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=blW>Ja Koski</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ma Ru�manis</td><td class=bc>-</td><td class=blW>Kr Zarinieks</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ti Dion</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Bi Gajsek</td><td class=bc>-</td><td class=blW>Ja Hansson</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>An Kimberg</td><td class=bc>-</td><td class=bl>El R�cen�ja</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ti Rimski</td><td class=bc>-</td><td class=bl>Ja Koski</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Ru�manis</td><td class=bc>-</td><td class=blW>Ja Hansson</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Bi Gajsek</td><td class=bc>-</td><td class=blW>Ju Stei��nas</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>El R�cen�ja</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>An Kimberg</td><td class=bc>-</td><td class=blW>Ja Koski</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>9 : 5</tr></td>
<tr><td class=brW>Ti Rimski</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Ru�manis</td><td class=bc>-</td><td class=blW>Ju Stei��nas</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ti Dion</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>7 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Ja Koski</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>An Kimberg</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ti Rimski</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ju Stei��nas</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Ma Ru�manis</td><td class=bc>-</td><td class=blW>Bi Gajsek</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Ja Koski</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>An Kimberg</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>9 : 2</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Ju Stei��nas</td><td class=bc>9 : 0</tr></td>
<tr><td class=brW>Ti Rimski</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Bi Gajsek</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Sa Lagzdi��</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>5 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ja Koski</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>8 : 4</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Ju Stei��nas</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>An Kimberg</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Bi Gajsek</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ti Rimski</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Re Vazoli��</td><td class=bc>-</td><td class=bl>Ma Ru�manis</td><td class=bc>11 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>4 : 9</tr></td>
<tr><td class=brW>Ja Koski</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Ge Jansons</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>Ju Stei��nas</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Bi Gajsek</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>An Kimberg</td><td class=bc>-</td><td class=bl>Ti Dion</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Al Skudr�tis</td><td class=bc>-</td><td class=bl>Ma Ru�manis</td><td class=bc>12 : 0</tr></td>
<tr><td class=br>Ti Rimski</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Ge Jansons</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ja Koski</td><td class=bc>-</td><td class=bl>Ju Stei��nas</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>Bi Gajsek</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Ma Ru�manis</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>An Kimberg</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Al Skudr�tis</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>2 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ja Hansson</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>Ju Stei��nas</td><td class=bc>8 : 2</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ja Koski</td><td class=bc>-</td><td class=bl>Bi Gajsek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>Ma Ru�manis</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Re Vazoli��</td><td class=bc>6 : 6</tr></td>
<tr><td class=brW>An Kimberg</td><td class=bc>-</td><td class=bl>Ti Rimski</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Ge Jansons</td><td class=bc>-</td><td class=bl>Ju Stei��nas</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ja Hansson</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>Bi Gajsek</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ja Koski</td><td class=bc>-</td><td class=bl>Ma Ru�manis</td><td class=bc>9 : 1</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Sa Lagzdi��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Ti Rimski</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>An Kuz�ecovs</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>7 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>Bi Gajsek</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>Ma Ru�manis</td><td class=bc>9 : 1</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ja Koski</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Ti Rimski</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>El R�cen�ja</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>An Kimberg</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Ed Garan�s</td><td class=bc>-</td><td class=bl>Bi Gajsek</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ge Jansons</td><td class=bc>-</td><td class=bl>Ma Ru�manis</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Kr Zarinieks</td><td class=bc>-</td><td class=bl>Ti Rimski</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ja Koski</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>An Kimberg</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>El R�cen�ja</td><td class=bc>-</td><td class=bl>An Kuz�ecovs</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Bi Gajsek</td><td class=bc>-</td><td class=blW>Ti Dion</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=blW>Ma Ru�manis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=blW>Sa Lagzdi��</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>Re Vazoli��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Ti Rimski</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>Al Skudr�tis</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=bl>An Kimberg</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ja Koski</td><td class=bc>-</td><td class=blW>An Kuz�ecovs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 7</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group RK G Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Ma Madera</td><td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>7:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kW>6:4</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kW>10:1</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>7:4</td>
<td class=kW>2:0</td>
<td class=kW>6:1</td>
<td class=br>84:34</td><td class=br>+50</td>
<td class=bc>16 - 1 - 1</td>
<td class=br><strong>33</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>J� Re�is</td><td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kL>3:5</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>6:3</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>4:3</td>
<td class=kW>8:1</td>
<td class=br>76:39</td><td class=br>+37</td>
<td class=bc>14 - 1 - 3</td>
<td class=br><strong>29</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>Se Mihejevs</td><td class=kL>1:7</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kL>0:7</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kL>0:1</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=br>49:29</td><td class=br>+20</td>
<td class=bc>14 - 0 - 4</td>
<td class=br><strong>28</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>An Jarvinen</td><td class=kL>1:4</td>
<td class=kW>5:3</td>
<td class=kW>7:0</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kW>7:2</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>3:5</td>
<td class=kW>5:2</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>8:2</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=br>77:39</td><td class=br>+38</td>
<td class=bc>13 - 1 - 4</td>
<td class=br><strong>27</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Ga Bohinc</td><td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>0:1</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>3:2</td>
<td class=kL>3:6</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=kL>5:6</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=br>64:44</td><td class=br>+20</td>
<td class=bc>12 - 0 - 6</td>
<td class=br><strong>24</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Ra Kuha�skis</td><td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kW>4:3</td>
<td class=kW>8:3</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kW>7:3</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kW>7:1</td>
<td class=br>67:46</td><td class=br>+21</td>
<td class=bc>10 - 3 - 5</td>
<td class=br><strong>23</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Ja Zalokar Obadi�</td><td class=kL>4:5</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>4:8</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>4:3</td>
<td class=kW>6:2</td>
<td class=kW>5:4</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=br>68:46</td><td class=br>+22</td>
<td class=bc>11 - 1 - 6</td>
<td class=br><strong>23</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Ni Sviklis</td><td class=kL>4:6</td>
<td class=kL>3:4</td>
<td class=kW>4:3</td>
<td class=kL>2:7</td>
<td class=kW>6:3</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kL>2:3</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=br>69:47</td><td class=br>+22</td>
<td class=bc>9 - 4 - 5</td>
<td class=br><strong>22</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Jo Thyzell</td><td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kW>8:4</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kW>8:1</td>
<td class=kW>3:2</td>
<td class=kW>8:1</td>
<td class=kW>6:3</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=br>65:48</td><td class=br>+17</td>
<td class=bc>10 - 1 - 7</td>
<td class=br><strong>21</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>He Petuch</td><td class=kT>4:4</td>
<td class=kL>1:6</td>
<td class=kW>1:0</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>6:3</td>
<td class=br>47:40</td><td class=br>+7</td>
<td class=bc>7 - 6 - 5</td>
<td class=br><strong>20</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Ai Romals</td><td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kW>6:5</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>6:4</td>
<td class=kW>5:1</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kW>10:0</td>
<td class=kW>6:2</td>
<td class=kW>8:1</td>
<td class=br>64:51</td><td class=br>+13</td>
<td class=bc>9 - 0 - 9</td>
<td class=br><strong>18</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>Iv �irsis</td><td class=kL>1:10</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kW>5:3</td>
<td class=kL>2:6</td>
<td class=kL>3:8</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kW>5:2</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=br>54:60</td><td class=br>-6</td>
<td class=bc>8 - 0 - 10</td>
<td class=br><strong>16</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Ra Stern�ts</td><td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kL>2:6</td>
<td class=kT>4:4</td>
<td class=kL>3:6</td>
<td class=kT>2:2</td>
<td class=kL>4:6</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>1:0</td>
<td class=kW>5:2</td>
<td class=br>53:68</td><td class=br>-15</td>
<td class=bc>6 - 2 - 10</td>
<td class=br><strong>14</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ju Hellevuo</td><td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>2:7</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kW>3:2</td>
<td class=kL>1:8</td>
<td class=kW>3:0</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>5:4</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=br>45:67</td><td class=br>-22</td>
<td class=bc>5 - 2 - 11</td>
<td class=br><strong>12</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>Re Saul�tis</td><td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kW>4:1</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=br>28:54</td><td class=br>-26</td>
<td class=bc>5 - 1 - 12</td>
<td class=br><strong>11</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>T� Gor�anova</td><td class=kL>1:4</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kW>3:2</td>
<td class=kL>3:7</td>
<td class=kL>0:5</td>
<td class=kL>0:6</td>
<td class=kL>1:8</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=br>31:77</td><td class=br>-46</td>
<td class=bc>4 - 0 - 14</td>
<td class=br><strong>8</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Ma P�tersons</td><td class=kL>4:7</td>
<td class=kL>1:5</td>
<td class=kL>0:3</td>
<td class=kL>2:8</td>
<td class=kL>3:4</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kL>0:10</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=br>33:81</td><td class=br>-48</td>
<td class=bc>2 - 2 - 14</td>
<td class=br><strong>6</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>E</td><td class=d>18.</td><td class=kt>Ma Kalni��</td><td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>0:2</td>
<td class=kL>2:6</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=br>23:58</td><td class=br>-35</td>
<td class=bc>2 - 0 - 16</td>
<td class=br><strong>4</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>E</td><td class=d>19.</td><td class=kt>Em Ka�s</td><td class=kL>1:6</td>
<td class=kL>1:8</td>
<td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>1:7</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kL>1:8</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=br>23:92</td><td class=br>-69</td>
<td class=bc>1 - 1 - 16</td>
<td class=br><strong>3</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ju Hellevuo</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>An Jarvinen</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>Ja Zalokar Obadi�</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>Jo Thyzell</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ju Hellevuo</td><td class=bc>-</td><td class=blW>An Jarvinen</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=blW>Ja Zalokar Obadi�</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Jo Thyzell</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Ai Romals</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>An Jarvinen</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ga Bohinc</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Ju Hellevuo</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=blW>Ja Zalokar Obadi�</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Jo Thyzell</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>An Jarvinen</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ga Bohinc</td><td class=bc>-</td><td class=bl>Ja Zalokar Obadi�</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ju Hellevuo</td><td class=bc>-</td><td class=blW>Jo Thyzell</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>An Jarvinen</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>J� Re�is</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Ja Zalokar Obadi�</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>Jo Thyzell</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ga Bohinc</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ju Hellevuo</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=blW>Ra Stern�ts</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Jarvinen</td><td class=bc>-</td><td class=blW>Ja Zalokar Obadi�</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Jo Thyzell</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ga Bohinc</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ju Hellevuo</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=blW>Ra Stern�ts</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Ja Zalokar Obadi�</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Jo Thyzell</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>An Jarvinen</td><td class=bc>-</td><td class=bl>Ni Sviklis</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Madera</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ga Bohinc</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ju Hellevuo</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ma P�tersons</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=blW>Jo Thyzell</td><td class=bc>4 : 8</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>An Jarvinen</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>T� Gor�anova</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ga Bohinc</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ju Hellevuo</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Jo Thyzell</td><td class=bc>-</td><td class=blW>Ni Sviklis</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>An Jarvinen</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>T� Gor�anova</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ga Bohinc</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Jo Thyzell</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>An Jarvinen</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>Ju Hellevuo</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Jo Thyzell</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>An Jarvinen</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>Ju Hellevuo</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Ma Madera</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Jo Thyzell</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>Ju Hellevuo</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>An Jarvinen</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>J� Re�is</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Ai Romals</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>6 : 4</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Jo Thyzell</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=bl>Ju Hellevuo</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Se Mihejevs</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>7 : 3</tr></td>
<tr><td class=br>An Jarvinen</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Ra Stern�ts</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ai Romals</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Ju Hellevuo</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Jo Thyzell</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Ra Kuha�skis</td><td class=bc>-</td><td class=bl>J� Re�is</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ra Stern�ts</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ai Romals</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>10 : 0</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Ju Hellevuo</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ni Sviklis</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Jo Thyzell</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Se Mihejevs</td><td class=bc>-</td><td class=blW>An Jarvinen</td><td class=bc>0 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ra Stern�ts</td><td class=bc>-</td><td class=bl>Ju Hellevuo</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ai Romals</td><td class=bc>-</td><td class=bl>Ga Bohinc</td><td class=bc>6 : 5</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Jo Thyzell</td><td class=bc>-</td><td class=blW>An Jarvinen</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ja Zalokar Obadi�</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Ma P�tersons</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ma Kalni��</td><td class=bc>-</td><td class=bl>Ju Hellevuo</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ra Stern�ts</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ai Romals</td><td class=bc>-</td><td class=bl>Ma Madera</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>An Jarvinen</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jo Thyzell</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=bl>Ju Hellevuo</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ma Kalni��</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>An Jarvinen</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=bl>Ra Kuha�skis</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ni Sviklis</td><td class=bc>-</td><td class=bl>Ja Zalokar Obadi�</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Ju Hellevuo</td><td class=bc>-</td><td class=blW>Ga Bohinc</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Ma Madera</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=blW>J� Re�is</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>An Jarvinen</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>Ra Kuha�skis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>Se Mihejevs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Ja Zalokar Obadi�</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Jo Thyzell</td><td class=bc>2 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group RK H Group</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>A</td><td class=d>1.</td><td class=kt>Va Smagars</td><td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kL>3:6</td>
<td class=kW>7:0</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>7:3</td>
<td class=kL>2:3</td>
<td class=kW>5:3</td>
<td class=kW>7:3</td>
<td class=kW>7:2</td>
<td class=kW>4:0</td>
<td class=kW>7:0</td>
<td class=kT>4:4</td>
<td class=kW>5:1</td>
<td class=kW>7:4</td>
<td class=kW>6:2</td>
<td class=kW>10:1</td>
<td class=br>94:38</td><td class=br>+56</td>
<td class=bc>15 - 1 - 2</td>
<td class=br><strong>31</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>A</td><td class=d>2.</td><td class=kt>Mi Kobrle</td><td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>9:0</td>
<td class=kT>4:4</td>
<td class=kW>6:2</td>
<td class=kW>8:3</td>
<td class=kT>2:2</td>
<td class=kW>10:3</td>
<td class=kW>7:2</td>
<td class=kW>3:0</td>
<td class=kW>7:2</td>
<td class=kW>9:3</td>
<td class=kW>7:1</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>8:0</td>
<td class=kW>9:0</td>
<td class=kW>8:2</td>
<td class=br>108:34</td><td class=br>+74</td>
<td class=bc>14 - 2 - 2</td>
<td class=br><strong>30</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>A</td><td class=d>3.</td><td class=kt>J� Bitmanis</td><td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kL>1:4</td>
<td class=kW>6:0</td>
<td class=kT>2:2</td>
<td class=kW>7:0</td>
<td class=kW>6:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=br>71:30</td><td class=br>+41</td>
<td class=bc>14 - 1 - 3</td>
<td class=br><strong>29</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>A</td><td class=d>4.</td><td class=kt>He Nilsson</td><td class=kW>6:3</td>
<td class=kL>0:9</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kL>3:6</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kL>3:6</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>5:2</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=br>55:49</td><td class=br>+6</td>
<td class=bc>12 - 1 - 5</td>
<td class=br><strong>25</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>A</td><td class=d>5.</td><td class=kt>Mi Tous</td><td class=kL>0:7</td>
<td class=kT>4:4</td>
<td class=kL>2:5</td>
<td class=kW>6:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>4:6</td>
<td class=kW>5:1</td>
<td class=kL>3:5</td>
<td class=kW>2:0</td>
<td class=kW>8:3</td>
<td class=kW>6:0</td>
<td class=kW>7:1</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>6:1</td>
<td class=kW>8:2</td>
<td class=kW>6:0</td>
<td class=br>79:45</td><td class=br>+34</td>
<td class=bc>11 - 2 - 5</td>
<td class=br><strong>24</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>A</td><td class=d>6.</td><td class=kt>Be Rjavec</td><td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kT>0:0</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kW>6:3</td>
<td class=kW>7:5</td>
<td class=kW>8:1</td>
<td class=br>59:40</td><td class=br>+19</td>
<td class=bc>9 - 6 - 3</td>
<td class=br><strong>24</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>A</td><td class=d>7.</td><td class=kt>Sa Skarainis</td><td class=kL>1:3</td>
<td class=kL>3:8</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>4:7</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kW>7:2</td>
<td class=kL>3:4</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=br>58:41</td><td class=br>+17</td>
<td class=bc>10 - 2 - 6</td>
<td class=br><strong>22</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>A</td><td class=d>8.</td><td class=kt>Mi Saul�tis</td><td class=kL>3:7</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kW>6:4</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kL>4:5</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=kW>4:1</td>
<td class=kT>2:2</td>
<td class=br>68:44</td><td class=br>+24</td>
<td class=bc>10 - 2 - 6</td>
<td class=br><strong>22</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>A</td><td class=d>9.</td><td class=kt>Ma Satkus</td><td class=kW>3:2</td>
<td class=kL>3:10</td>
<td class=kL>1:3</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kT>0:0</td>
<td class=kW>7:4</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kW>5:1</td>
<td class=kT>6:6</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kW>7:4</td>
<td class=kW>7:1</td>
<td class=kW>4:2</td>
<td class=br>62:61</td><td class=br>+1</td>
<td class=bc>9 - 3 - 6</td>
<td class=br><strong>21</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>B</td><td class=d>10.</td><td class=kt>Marg �bele</td><td class=kL>3:5</td>
<td class=kL>2:7</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kW>5:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>3:4</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>4:2</td>
<td class=kW>1:0</td>
<td class=kW>2:0</td>
<td class=br>49:51</td><td class=br>-2</td>
<td class=bc>9 - 0 - 9</td>
<td class=br><strong>18</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>B</td><td class=d>11.</td><td class=kt>Fr Platons</td><td class=kL>3:7</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kL>1:5</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kW>1:0</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=br>47:53</td><td class=br>-6</td>
<td class=bc>8 - 1 - 9</td>
<td class=br><strong>17</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>B</td><td class=d>12.</td><td class=kt>Ha V�veris</td><td class=kL>2:7</td>
<td class=kL>2:7</td>
<td class=kL>0:6</td>
<td class=kW>5:1</td>
<td class=kL>3:8</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kT>6:6</td>
<td class=kW>4:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>5:4</td>
<td class=kW>2:0</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kW>6:0</td>
<td class=br>51:64</td><td class=br>-13</td>
<td class=bc>7 - 3 - 8</td>
<td class=br><strong>17</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>C</td><td class=d>13.</td><td class=kt>Gu Buls</td><td class=kL>0:4</td>
<td class=kL>3:9</td>
<td class=kT>2:2</td>
<td class=kL>3:4</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>2:7</td>
<td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=br>37:66</td><td class=br>-29</td>
<td class=bc>5 - 3 - 10</td>
<td class=br><strong>13</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>C</td><td class=d>14.</td><td class=kt>Ma Zimba</td><td class=kL>0:7</td>
<td class=kL>1:7</td>
<td class=kL>0:7</td>
<td class=kL>0:3</td>
<td class=kL>1:7</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kL>2:3</td>
<td class=kL>0:1</td>
<td class=br>25:63</td><td class=br>-38</td>
<td class=bc>4 - 2 - 12</td>
<td class=br><strong>10</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>C</td><td class=d>15.</td><td class=kt>Li Kondrashevskyi</td><td class=kT>4:4</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>2:7</td>
<td class=kT>1:1</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kW>6:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kL>3:5</td>
<td class=kL>0:5</td>
<td class=kW>2:1</td>
<td class=br>39:62</td><td class=br>-23</td>
<td class=bc>4 - 2 - 12</td>
<td class=br><strong>10</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>D</td><td class=d>16.</td><td class=kt>Hy Nechutny</td><td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>2:6</td>
<td class=kT>3:3</td>
<td class=kW>3:1</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=br>31:52</td><td class=br>-21</td>
<td class=bc>4 - 2 - 12</td>
<td class=br><strong>10</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>D</td><td class=d>17.</td><td class=kt>Wi Possl</td><td class=kL>4:7</td>
<td class=kL>0:8</td>
<td class=kL>2:4</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>3:6</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kL>4:7</td>
<td class=kL>2:4</td>
<td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kT>3:3</td>
<td class=br>49:85</td><td class=br>-36</td>
<td class=bc>3 - 2 - 13</td>
<td class=br><strong>8</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>E</td><td class=d>18.</td><td class=kt>Al Liepi��</td><td class=kL>2:6</td>
<td class=kL>0:9</td>
<td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>2:8</td>
<td class=kL>5:7</td>
<td class=kL>0:4</td>
<td class=kL>1:4</td>
<td class=kL>1:7</td>
<td class=kL>0:1</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kL>1:2</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=br>30:77</td><td class=br>-47</td>
<td class=bc>3 - 1 - 14</td>
<td class=br><strong>7</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>E</td><td class=d>19.</td><td class=kt>Kr Timbers</td><td class=kL>1:10</td>
<td class=kL>2:8</td>
<td class=kL>0:6</td>
<td class=kL>0:4</td>
<td class=kL>0:6</td>
<td class=kL>1:8</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kL>0:6</td>
<td class=kL>1:4</td>
<td class=kW>1:0</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=br>21:78</td><td class=br>-57</td>
<td class=bc>1 - 2 - 15</td>
<td class=br><strong>4</strong></td><td class=d>19.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Wi Possl</td><td class=bc>-</td><td class=bl>Ma Zimba</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Li Kondrashevskyi</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Kr Timbers</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>He Nilsson</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Hy Nechutny</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>Mi Tous</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Ma Zimba</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Wi Possl</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Li Kondrashevskyi</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kr Timbers</td><td class=bc>-</td><td class=blW>He Nilsson</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Hy Nechutny</td><td class=bc>-</td><td class=blW>Mi Tous</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Zimba</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Wi Possl</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Li Kondrashevskyi</td><td class=bc>-</td><td class=blW>He Nilsson</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Kr Timbers</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Mi Tous</td><td class=bc>2 : 8</tr></td>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Hy Nechutny</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>8 : 3</tr></td>
<tr><td class=br>Ma Zimba</td><td class=bc>-</td><td class=blW>He Nilsson</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Wi Possl</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Li Kondrashevskyi</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=blW>Mi Tous</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Kr Timbers</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=blW>He Nilsson</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>J� Bitmanis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Zimba</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Wi Possl</td><td class=bc>-</td><td class=blW>Mi Tous</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Li Kondrashevskyi</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>6 : 6</tr></td>
<tr><td class=br>Kr Timbers</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Hy Nechutny</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>He Nilsson</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Kobrle</td><td class=bc>-</td><td class=bl>Mi Tous</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ma Zimba</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Wi Possl</td><td class=bc>-</td><td class=blW>Ma Satkus</td><td class=bc>4 : 7</tr></td>
<tr><td class=br>Li Kondrashevskyi</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>Hy Nechutny</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Kr Timbers</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Mi Tous</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>10 : 3</tr></td>
<tr><td class=br>Ma Zimba</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Wi Possl</td><td class=bc>-</td><td class=blW>Hy Nechutny</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Li Kondrashevskyi</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Be Rjavec</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=blW>Mi Tous</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>7 : 3</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Hy Nechutny</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Zimba</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Wi Possl</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Li Kondrashevskyi</td><td class=bc>-</td><td class=bl>Kr Timbers</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=bl>Mi Tous</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>He Nilsson</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Hy Nechutny</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>9 : 0</tr></td>
<tr><td class=br>Ma Zimba</td><td class=bc>-</td><td class=blW>Kr Timbers</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Wi Possl</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Mi Tous</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>He Nilsson</td><td class=bc>-</td><td class=bl>Hy Nechutny</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Kr Timbers</td><td class=bc>10 : 1</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Ma Zimba</td><td class=bc>-</td><td class=bl>Li Kondrashevskyi</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Ma Satkus</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Mi Tous</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Hy Nechutny</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>He Nilsson</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Kr Timbers</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Va Smagars</td><td class=bc>-</td><td class=bl>Li Kondrashevskyi</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Mi Kobrle</td><td class=bc>-</td><td class=bl>Wi Possl</td><td class=bc>8 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Hy Nechutny</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Mi Tous</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>7 : 5</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Kr Timbers</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Sa Skarainis</td><td class=bc>-</td><td class=bl>Li Kondrashevskyi</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Wi Possl</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Va Smagars</td><td class=bc>-</td><td class=bl>Ma Zimba</td><td class=bc>7 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>Hy Nechutny</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Mi Tous</td><td class=bc>-</td><td class=bl>Kr Timbers</td><td class=bc>6 : 0</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Li Kondrashevskyi</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>He Nilsson</td><td class=bc>-</td><td class=bl>Wi Possl</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Ma Zimba</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Mi Saul�tis</td><td class=bc>-</td><td class=bl>Mi Kobrle</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Hy Nechutny</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Kr Timbers</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Mi Tous</td><td class=bc>-</td><td class=bl>Li Kondrashevskyi</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Wi Possl</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Ma Zimba</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>He Nilsson</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>Sa Skarainis</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Hy Nechutny</td><td class=bc>-</td><td class=bl>Kr Timbers</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Li Kondrashevskyi</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Wi Possl</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Mi Tous</td><td class=bc>-</td><td class=bl>Ma Zimba</td><td class=bc>7 : 1</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>J� Bitmanis</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>He Nilsson</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Kr Timbers</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Hy Nechutny</td><td class=bc>-</td><td class=blW>Li Kondrashevskyi</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>Wi Possl</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Ma Zimba</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 7</tr></td>
<tr><td class=br>Mi Tous</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Be Rjavec</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>J� Bitmanis</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Kr Timbers</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Li Kondrashevskyi</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=bl>Wi Possl</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Hy Nechutny</td><td class=bc>-</td><td class=blW>Ma Zimba</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Va Smagars</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Mi Saul�tis</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Mi Tous</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Be Rjavec</td><td class=bc>-</td><td class=bl>He Nilsson</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>Li Kondrashevskyi</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>Kr Timbers</td><td class=bc>-</td><td class=bl>Wi Possl</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Ma Zimba</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>3 : 9</tr></td>
<tr><td class=br>Hy Nechutny</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Ma Satkus</td><td class=bc>-</td><td class=bl>Sa Skarainis</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>He Nilsson</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Mi Tous</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Li Kondrashevskyi</td><td class=bc>-</td><td class=blW>Wi Possl</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=bl>Ma Zimba</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Kr Timbers</td><td class=bc>-</td><td class=blW>Mi Kobrle</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Va Smagars</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Mi Saul�tis</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Hy Nechutny</td><td class=bc>-</td><td class=blW>Sa Skarainis</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>He Nilsson</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Ma Satkus</td><td class=bc>-</td><td class=blW>J� Bitmanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Be Rjavec</td><td class=bc>1 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<hr><a name="final"><p class=vm>Final groups</p></a>
<p class=v>Group 2.l�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Zy Remeika</td><td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>5:3</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>4:3</td>
<td class=kW>1:0</td>
<td class=kL>3:5</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>7:1</td>
<td class=kW>8:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>96:34</td><td class=br>+62</td>
<td class=bc>18 - 3 - 2</td>
<td class=br><strong>39</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Si Thomas</td><td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=kW>4:3</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>3:6</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>71:41</td><td class=br>+30</td>
<td class=bc>16 - 1 - 6</td>
<td class=br><strong>33</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Marg �bele</td><td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kW>6:2</td>
<td class=kW>6:3</td>
<td class=kL>4:5</td>
<td class=kW>6:1</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kL>0:2</td>
<td class=kL>3:4</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kT>4:4</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>85:51</td><td class=br>+34</td>
<td class=bc>14 - 4 - 5</td>
<td class=br><strong>32</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Iv �irsis</td><td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>4:3</td>
<td class=kT>1:1</td>
<td class=kL>3:6</td>
<td class=kW>4:3</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>7:5</td>
<td class=kW>4:2</td>
<td class=kT>5:5</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>79:51</td><td class=br>+28</td>
<td class=bc>13 - 6 - 4</td>
<td class=br><strong>32</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ed Putni��</td><td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kL>2:5</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kL>4:6</td>
<td class=kW>6:1</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kL>4:5</td>
<td class=kW>4:3</td>
<td class=kW>5:3</td>
<td class=kW>5:2</td>
<td class=kW>5:2</td>
<td class=kW>7:1</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=br>98:61</td><td class=br>+37</td>
<td class=bc>15 - 2 - 6</td>
<td class=br><strong>32</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Ro Verbi�s</td><td class=kL>3:5</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kW>5:4</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kW>3:0</td>
<td class=kW>7:4</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>76:55</td><td class=br>+21</td>
<td class=bc>13 - 5 - 5</td>
<td class=br><strong>31</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>M� �irsis</td><td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>6:4</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kL>2:6</td>
<td class=kW>2:1</td>
<td class=kL>2:4</td>
<td class=kW>3:0</td>
<td class=kL>0:3</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kW>6:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=br>61:50</td><td class=br>+11</td>
<td class=bc>14 - 1 - 8</td>
<td class=br><strong>29</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ai Romals</td><td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kL>2:3</td>
<td class=kW>4:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>5:4</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>65:60</td><td class=br>+5</td>
<td class=bc>13 - 2 - 8</td>
<td class=br><strong>28</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Da Baumanis</td><td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kL>2:6</td>
<td class=kL>1:4</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kT>5:5</td>
<td class=kW>4:1</td>
<td class=kT>5:5</td>
<td class=kW>2:0</td>
<td class=kL>1:2</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>73:53</td><td class=br>+20</td>
<td class=bc>12 - 4 - 7</td>
<td class=br><strong>28</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ka Vi�ums</td><td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kL>3:6</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kW>6:1</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>6:3</td>
<td class=kL>1:4</td>
<td class=kW>5:0</td>
<td class=br>68:54</td><td class=br>+14</td>
<td class=bc>13 - 0 - 10</td>
<td class=br><strong>26</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>To Bucek</td><td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=kW>5:4</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kT>2:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>1:0</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kL>4:5</td>
<td class=kL>1:3</td>
<td class=kW>5:1</td>
<td class=kW>4:0</td>
<td class=kW>1:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>64:50</td><td class=br>+14</td>
<td class=bc>12 - 1 - 10</td>
<td class=br><strong>25</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Il �irse</td><td class=kL>0:6</td>
<td class=kW>6:3</td>
<td class=kL>1:6</td>
<td class=kL>3:4</td>
<td class=kL>4:5</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>6:1</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kW>5:0</td>
<td class=br>72:64</td><td class=br>+8</td>
<td class=bc>11 - 2 - 10</td>
<td class=br><strong>24</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>He Petuch</td><td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kW>5:2</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>59:54</td><td class=br>+5</td>
<td class=bc>11 - 2 - 10</td>
<td class=br><strong>24</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>My Verbytskyy</td><td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kW>6:3</td>
<td class=kL>3:4</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>0:3</td>
<td class=kW>3:0</td>
<td class=kW>5:4</td>
<td class=kW>4:1</td>
<td class=kW>2:0</td>
<td class=kW>8:1</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>60:58</td><td class=br>+2</td>
<td class=bc>10 - 3 - 10</td>
<td class=br><strong>23</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>La Ulfvensj�</td><td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kL>4:7</td>
<td class=kW>3:0</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>1:0</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kW>5:1</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>55:53</td><td class=br>+2</td>
<td class=bc>11 - 0 - 12</td>
<td class=br><strong>22</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Ei G�ze</td><td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kW>4:3</td>
<td class=kL>0:4</td>
<td class=kL>2:5</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kT>5:5</td>
<td class=kW>3:1</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>3:0</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>3:4</td>
<td class=kW>2:1</td>
<td class=kW>3:1</td>
<td class=kW>4:2</td>
<td class=kT>0:0</td>
<td class=kL>1:5</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>50:58</td><td class=br>-8</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>Do Zupan�i�</td><td class=kL>0:4</td>
<td class=kL>0:1</td>
<td class=kL>3:6</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kL>3:5</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>0:1</td>
<td class=kW>4:3</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>57:60</td><td class=br>-3</td>
<td class=bc>8 - 3 - 12</td>
<td class=br><strong>19</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>D� Vesele</td><td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kL>1:6</td>
<td class=kL>1:3</td>
<td class=kT>5:5</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kL>4:5</td>
<td class=kW>2:1</td>
<td class=kL>1:2</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>6:1</td>
<td class=kL>2:5</td>
<td class=kW>5:2</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>5:0</td>
<td class=br>60:69</td><td class=br>-9</td>
<td class=bc>7 - 4 - 12</td>
<td class=br><strong>18</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Gu Ern�teins</td><td class=kT>2:2</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kL>5:7</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kL>0:2</td>
<td class=kL>1:6</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>1:4</td>
<td class=kW>4:0</td>
<td class=kL>1:3</td>
<td class=kT>3:3</td>
<td class=kL>1:6</td>
<td class=kx>*</td>
<td class=kL>3:5</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>59:66</td><td class=br>-7</td>
<td class=bc>7 - 4 - 12</td>
<td class=br><strong>18</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>Ha V�veris</td><td class=kL>1:7</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>0:3</td>
<td class=kW>5:2</td>
<td class=kW>5:3</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>2:6</td>
<td class=kW>5:0</td>
<td class=br>46:75</td><td class=br>-29</td>
<td class=bc>6 - 1 - 16</td>
<td class=br><strong>13</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Gi Remeika</td><td class=kL>1:8</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kT>5:5</td>
<td class=kL>2:6</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>0:4</td>
<td class=kL>0:5</td>
<td class=kW>3:1</td>
<td class=kL>1:8</td>
<td class=kW>3:0</td>
<td class=kT>0:0</td>
<td class=kL>1:6</td>
<td class=kL>2:5</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:0</td>
<td class=kL>2:3</td>
<td class=kW>5:0</td>
<td class=br>44:84</td><td class=br>-40</td>
<td class=bc>5 - 3 - 15</td>
<td class=br><strong>13</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>�v Vikmanis</td><td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kL>0:2</td>
<td class=kL>3:6</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kL>1:3</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>48:67</td><td class=br>-19</td>
<td class=bc>5 - 2 - 16</td>
<td class=br><strong>12</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>Fr Platons</td><td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kW>4:1</td>
<td class=kL>0:5</td>
<td class=kL>4:5</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kW>3:1</td>
<td class=kL>0:5</td>
<td class=kW>6:2</td>
<td class=kW>3:2</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=br>29:92</td><td class=br>-63</td>
<td class=bc>5 - 0 - 18</td>
<td class=br><strong>10</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>D� Apfelbaums</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=br>0:115</td><td class=br>-115</td>
<td class=bc>0 - 0 - 23</td>
<td class=br><strong>0</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>La Ulfvensj�</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Do Zupan�i�</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>La Ulfvensj�</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=blW>Gi Remeika</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Do Zupan�i�</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>5 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>La Ulfvensj�</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Gi Remeika</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Do Zupan�i�</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=blW>La Ulfvensj�</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>Do Zupan�i�</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>La Ulfvensj�</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Do Zupan�i�</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Fr Platons</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>La Ulfvensj�</td><td class=bc>-</td><td class=blW>Gi Remeika</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=blW>Do Zupan�i�</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Gu Ern�teins</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Gi Remeika</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>La Ulfvensj�</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Do Zupan�i�</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>Ai Romals</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>5 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Do Zupan�i�</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>La Ulfvensj�</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ha V�veris</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Do Zupan�i�</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>�v Vikmanis</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>La Ulfvensj�</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>5 : 5</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=bl>Ro Verbi�s</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Do Zupan�i�</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>La Ulfvensj�</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=blW>Ro Verbi�s</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Il �irse</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>3 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Do Zupan�i�</td><td class=bc>-</td><td class=blW>My Verbytskyy</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ka Vi�ums</td><td class=bc>-</td><td class=bl>Da Baumanis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>La Ulfvensj�</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Ro Verbi�s</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Gu Ern�teins</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=bl>My Verbytskyy</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Do Zupan�i�</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Ro Verbi�s</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>La Ulfvensj�</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>D� Vesele</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Il �irse</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>4 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Da Baumanis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>To Bucek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Do Zupan�i�</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Ro Verbi�s</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Gi Remeika</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>La Ulfvensj�</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>7 : 5</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>To Bucek</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Ei G�ze</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ai Romals</td><td class=bc>-</td><td class=bl>M� �irsis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Ro Verbi�s</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Do Zupan�i�</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>3 : 6</tr></td>
<tr><td class=brW>Ka Vi�ums</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>1 : 8</tr></td>
<tr><td class=br>La Ulfvensj�</td><td class=bc>-</td><td class=blW>Gu Ern�teins</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Iv �irsis</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ha V�veris</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ei G�ze</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Ro Verbi�s</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Do Zupan�i�</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Gu Ern�teins</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>La Ulfvensj�</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Iv �irsis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>M� �irsis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ro Verbi�s</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Marg �bele</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Do Zupan�i�</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>�v Vikmanis</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>La Ulfvensj�</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>D� Vesele</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>Ro Verbi�s</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Si Thomas</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=blW>Gu Ern�teins</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Do Zupan�i�</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ka Vi�ums</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>La Ulfvensj�</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Marg �bele</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>He Petuch</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ai Romals</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Fr Platons</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Do Zupan�i�</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ka Vi�ums</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Gi Remeika</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>He Petuch</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ed Putni��</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ai Romals</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Do Zupan�i�</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ka Vi�ums</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>�v Vikmanis</td><td class=bc>-</td><td class=blW>La Ulfvensj�</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>Si Thomas</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=blW>Zy Remeika</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Ei G�ze</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ai Romals</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Do Zupan�i�</td><td class=bc>-</td><td class=blW>La Ulfvensj�</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Ka Vi�ums</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=bl>Zy Remeika</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ai Romals</td><td class=bc>-</td><td class=bl>La Ulfvensj�</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Do Zupan�i�</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=bl>Gu Ern�teins</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>He Petuch</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Il �irse</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ro Verbi�s</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>D� Vesele</td><td class=bc>4 : 5</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>La Ulfvensj�</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Ai Romals</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Fr Platons</td><td class=bc>-</td><td class=bl>Ka Vi�ums</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=brW>Gu Ern�teins</td><td class=bc>-</td><td class=bl>Ed Putni��</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Zy Remeika</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Si Thomas</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>La Ulfvensj�</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>My Verbytskyy</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Ai Romals</td><td class=bc>-</td><td class=bl>Do Zupan�i�</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=brW>Ed Putni��</td><td class=bc>-</td><td class=bl>D� Apfelbaums</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>Ha V�veris</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=bl>Iv �irsis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Marg �bele</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>La Ulfvensj�</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>M� �irsis</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>�v Vikmanis</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>To Bucek</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Da Baumanis</td><td class=bc>-</td><td class=bl>Do Zupan�i�</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>My Verbytskyy</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=br>D� Apfelbaums</td><td class=bc>-</td><td class=blW>Il �irse</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ed Putni��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Gu Ern�teins</td><td class=bc>-</td><td class=blW>Ha V�veris</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Zy Remeika</td><td class=bc>-</td><td class=blW>Iv �irsis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Si Thomas</td><td class=bc>-</td><td class=bl>D� Vesele</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>He Petuch</td><td class=bc>-</td><td class=blW>La Ulfvensj�</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Marg �bele</td><td class=bc>-</td><td class=bl>Gi Remeika</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Ro Verbi�s</td><td class=bc>-</td><td class=bl>�v Vikmanis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>M� �irsis</td><td class=bc>-</td><td class=blW>Ka Vi�ums</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ei G�ze</td><td class=bc>-</td><td class=blW>Do Zupan�i�</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>To Bucek</td><td class=bc>-</td><td class=bl>Fr Platons</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Da Baumanis</td><td class=bc>-</td><td class=blW>Ai Romals</td><td class=bc>3 : 4</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 3.l�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>17</td>
<td class=ic>18</td>
<td class=ic>19</td>
<td class=ic>20</td>
<td class=ic>21</td>
<td class=ic>22</td>
<td class=ic>23</td>
<td class=ic>24</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Al Kalni��</td><td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>6:2</td>
<td class=kW>4:2</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>8:3</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=kW>3:1</td>
<td class=kW>7:2</td>
<td class=kW>3:2</td>
<td class=kW>9:2</td>
<td class=kW>7:0</td>
<td class=kW>4:3</td>
<td class=kW>5:0</td>
<td class=br>107:41</td><td class=br>+66</td>
<td class=bc>20 - 1 - 2</td>
<td class=br><strong>41</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Re Stac�vi�s</td><td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>6:1</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kT>3:3</td>
<td class=kW>7:6</td>
<td class=kW>6:1</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>2:0</td>
<td class=kT>3:3</td>
<td class=kW>5:0</td>
<td class=br>83:50</td><td class=br>+33</td>
<td class=bc>15 - 6 - 2</td>
<td class=br><strong>36</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Ro Fa�ken�teins</td><td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>5:2</td>
<td class=kT>3:3</td>
<td class=kW>8:3</td>
<td class=kW>2:0</td>
<td class=kW>5:3</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>5:3</td>
<td class=kL>3:6</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=br>79:52</td><td class=br>+27</td>
<td class=bc>16 - 1 - 6</td>
<td class=br><strong>33</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Ra Stern�ts</td><td class=kL>2:6</td>
<td class=kL>2:3</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>4:3</td>
<td class=kL>1:2</td>
<td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kW>4:0</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kW>4:0</td>
<td class=kL>1:5</td>
<td class=kW>5:3</td>
<td class=kW>2:1</td>
<td class=kW>4:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>65:51</td><td class=br>+14</td>
<td class=bc>14 - 1 - 8</td>
<td class=br><strong>29</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Jo Pleikys</td><td class=kL>2:6</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=kL>3:4</td>
<td class=kW>4:0</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=br>72:41</td><td class=br>+31</td>
<td class=bc>12 - 4 - 7</td>
<td class=br><strong>28</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>Ma Krauze</td><td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>2:5</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>7:2</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kW>6:2</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=br>60:53</td><td class=br>+7</td>
<td class=bc>11 - 5 - 7</td>
<td class=br><strong>27</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Li Kondrashevskyi</td><td class=kW>4:3</td>
<td class=kL>1:6</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kL>1:2</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kW>6:1</td>
<td class=kW>4:3</td>
<td class=kL>1:7</td>
<td class=kW>5:3</td>
<td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kW>7:3</td>
<td class=kW>7:0</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>6:0</td>
<td class=kW>5:0</td>
<td class=br>76:57</td><td class=br>+19</td>
<td class=bc>13 - 1 - 9</td>
<td class=br><strong>27</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Ju Hellevuo</td><td class=kL>2:4</td>
<td class=kL>3:6</td>
<td class=kL>3:8</td>
<td class=kL>1:2</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>2:3</td>
<td class=kW>6:2</td>
<td class=kW>1:0</td>
<td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kL>1:5</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>4:1</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=br>68:61</td><td class=br>+7</td>
<td class=bc>12 - 3 - 8</td>
<td class=br><strong>27</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>La Karlsson</td><td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kW>2:1</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=kT>2:2</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=br>63:57</td><td class=br>+6</td>
<td class=bc>10 - 5 - 8</td>
<td class=br><strong>25</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Gu Buls</td><td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>4:5</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kW>4:2</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>70:56</td><td class=br>+14</td>
<td class=bc>10 - 5 - 8</td>
<td class=br><strong>25</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Er Kalni��</td><td class=kL>1:4</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=kL>2:6</td>
<td class=kL>3:4</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kL>2:3</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=kL>2:3</td>
<td class=kL>3:4</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>5:0</td>
<td class=br>54:48</td><td class=br>+6</td>
<td class=bc>10 - 5 - 8</td>
<td class=br><strong>25</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ge Jansons</td><td class=kL>2:3</td>
<td class=kL>6:7</td>
<td class=kW>4:2</td>
<td class=kW>5:3</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>0:1</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>5:0</td>
<td class=kW>2:0</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kW>4:3</td>
<td class=kL>2:7</td>
<td class=kL>3:4</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=kW>5:0</td>
<td class=br>70:57</td><td class=br>+13</td>
<td class=bc>11 - 2 - 10</td>
<td class=br><strong>24</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Re Saul�tis</td><td class=kW>2:1</td>
<td class=kL>1:6</td>
<td class=kL>0:4</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kW>3:1</td>
<td class=kL>3:4</td>
<td class=kW>5:0</td>
<td class=kL>2:4</td>
<td class=kL>2:4</td>
<td class=kL>0:1</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kL>0:2</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>50:49</td><td class=br>+1</td>
<td class=bc>11 - 2 - 10</td>
<td class=br><strong>24</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Da Belkovs</td><td class=kL>3:8</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>7:1</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>5:4</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kW>2:0</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>2:1</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kW>2:1</td>
<td class=kL>4:5</td>
<td class=kW>5:0</td>
<td class=br>58:59</td><td class=br>-1</td>
<td class=bc>9 - 6 - 8</td>
<td class=br><strong>24</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>L� Bezdel�ga</td><td class=kT>3:3</td>
<td class=kW>4:2</td>
<td class=kW>5:1</td>
<td class=kL>0:4</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kW>5:1</td>
<td class=kW>3:1</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>5:1</td>
<td class=kL>1:5</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>62:51</td><td class=br>+11</td>
<td class=bc>10 - 4 - 9</td>
<td class=br><strong>24</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>On Gruncl</td><td class=kL>1:5</td>
<td class=kT>3:3</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kT>4:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>59:56</td><td class=br>+3</td>
<td class=bc>8 - 7 - 8</td>
<td class=br><strong>23</strong></td><td class=d>16.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>17.</td><td class=kt>J� Zem�ickis</td><td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kW>4:2</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>0:1</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kW>1:0</td>
<td class=kW>3:0</td>
<td class=kW>3:1</td>
<td class=kW>5:0</td>
<td class=br>40:43</td><td class=br>-3</td>
<td class=bc>10 - 2 - 11</td>
<td class=br><strong>22</strong></td><td class=d>17.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>18.</td><td class=kt>Ja Hansson</td><td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kL>3:7</td>
<td class=kL>0:4</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>1:4</td>
<td class=kL>3:4</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:0</td>
<td class=kW>5:4</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=kW>8:3</td>
<td class=kW>5:0</td>
<td class=br>56:63</td><td class=br>-7</td>
<td class=bc>9 - 3 - 11</td>
<td class=br><strong>21</strong></td><td class=d>18.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>19.</td><td class=kt>Ig Zamiatin</td><td class=kL>2:7</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kW>5:1</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>0:7</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>7:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kL>0:2</td>
<td class=kx>*</td>
<td class=kL>0:3</td>
<td class=kW>3:2</td>
<td class=kW>5:1</td>
<td class=kW>6:2</td>
<td class=kW>5:0</td>
<td class=br>58:67</td><td class=br>-9</td>
<td class=bc>8 - 4 - 11</td>
<td class=br><strong>20</strong></td><td class=d>19.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>20.</td><td class=kt>An Kova��uks</td><td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kW>6:3</td>
<td class=kL>3:5</td>
<td class=kL>1:7</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>1:5</td>
<td class=kL>1:4</td>
<td class=kL>2:4</td>
<td class=kW>4:3</td>
<td class=kW>4:3</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>1:5</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kW>3:0</td>
<td class=kx>*</td>
<td class=kL>2:5</td>
<td class=kW>5:0</td>
<td class=kW>6:1</td>
<td class=kW>5:0</td>
<td class=br>65:70</td><td class=br>-5</td>
<td class=bc>8 - 2 - 13</td>
<td class=br><strong>18</strong></td><td class=d>20.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>21.</td><td class=kt>Ag Pav�rs</td><td class=kL>2:9</td>
<td class=kL>2:3</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kW>3:1</td>
<td class=kW>5:1</td>
<td class=kT>3:3</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=br>53:61</td><td class=br>-8</td>
<td class=bc>6 - 4 - 13</td>
<td class=br><strong>16</strong></td><td class=d>21.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>22.</td><td class=kt>Ma Zimba</td><td class=kL>0:7</td>
<td class=kL>0:2</td>
<td class=kL>0:5</td>
<td class=kL>1:4</td>
<td class=kL>0:5</td>
<td class=kT>1:1</td>
<td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kT>2:2</td>
<td class=kL>2:7</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>5:0</td>
<td class=br>21:84</td><td class=br>-63</td>
<td class=bc>2 - 3 - 18</td>
<td class=br><strong>7</strong></td><td class=d>22.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>23.</td><td class=kt>As Kocere</td><td class=kL>3:4</td>
<td class=kT>3:3</td>
<td class=kL>0:2</td>
<td class=kL>2:3</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kL>0:6</td>
<td class=kL>2:4</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kW>5:4</td>
<td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>3:8</td>
<td class=kL>2:6</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=br>38:85</td><td class=br>-47</td>
<td class=bc>2 - 2 - 19</td>
<td class=br><strong>6</strong></td><td class=d>23.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>24.</td><td class=kt>Kr Zarinieks</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=br>0:115</td><td class=br>-115</td>
<td class=bc>0 - 0 - 23</td>
<td class=br><strong>0</strong></td><td class=d>24.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>On Gruncl</td><td class=bc>-</td><td class=bl>Li Kondrashevskyi</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>La Karlsson</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Al Kalni��</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ra Stern�ts</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ig Zamiatin</td><td class=bc>-</td><td class=bl>Ma Zimba</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=blW>Ju Hellevuo</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Li Kondrashevskyi</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>On Gruncl</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>La Karlsson</td><td class=bc>-</td><td class=blW>Da Belkovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ra Stern�ts</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>Ma Zimba</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=bl>Ju Hellevuo</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ig Zamiatin</td><td class=bc>-</td><td class=blW>Ja Hansson</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Li Kondrashevskyi</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>On Gruncl</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>La Karlsson</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Al Kalni��</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Ma Zimba</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ra Stern�ts</td><td class=bc>-</td><td class=bl>Ju Hellevuo</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Ja Hansson</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ig Zamiatin</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Li Kondrashevskyi</td><td class=bc>-</td><td class=blW>Da Belkovs</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>La Karlsson</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Al Kalni��</td><td class=bc>-</td><td class=bl>Ma Zimba</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>Ju Hellevuo</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Ja Hansson</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>Jo Pleikys</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=brW>Ge Jansons</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Li Kondrashevskyi</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ag Pav�rs</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=blW>Ma Zimba</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>La Karlsson</td><td class=bc>-</td><td class=bl>Ju Hellevuo</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Al Kalni��</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>Jo Pleikys</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Ig Zamiatin</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ge Jansons</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Li Kondrashevskyi</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ma Zimba</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Ju Hellevuo</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>La Karlsson</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Al Kalni��</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Ig Zamiatin</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ra Stern�ts</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>4 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Ge Jansons</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>Ma Zimba</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Li Kondrashevskyi</td><td class=bc>-</td><td class=bl>Ju Hellevuo</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>La Karlsson</td><td class=bc>-</td><td class=blW>Jo Pleikys</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Al Kalni��</td><td class=bc>-</td><td class=bl>Ig Zamiatin</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>Ma Zimba</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>Ju Hellevuo</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Ja Hansson</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Li Kondrashevskyi</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=bl>Ig Zamiatin</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>La Karlsson</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>Al Kalni��</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>An Kova��uks</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Ma Zimba</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Ju Hellevuo</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>Ja Hansson</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>6 : 7</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Li Kondrashevskyi</td><td class=bc>-</td><td class=blW>Jo Pleikys</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ig Zamiatin</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>La Karlsson</td><td class=bc>-</td><td class=blW>Ra Stern�ts</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Al Kalni��</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>Ma Zimba</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Ju Hellevuo</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Re Stac�vi�s</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>Ig Zamiatin</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Li Kondrashevskyi</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>Ra Stern�ts</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>On Gruncl</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>La Karlsson</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Ma Zimba</td><td class=bc>-</td><td class=blW>Ju Hellevuo</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Ja Hansson</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>Ig Zamiatin</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Li Kondrashevskyi</td><td class=bc>-</td><td class=blW>Ra Stern�ts</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=blW>Al Kalni��</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ju Hellevuo</td><td class=bc>-</td><td class=bl>Ja Hansson</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ma Zimba</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Jo Pleikys</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Ig Zamiatin</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ge Jansons</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Li Kondrashevskyi</td><td class=bc>-</td><td class=blW>Er Kalni��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Al Kalni��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ag Pav�rs</td><td class=bc>-</td><td class=blW>La Karlsson</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Re Stac�vi�s</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ju Hellevuo</td><td class=bc>-</td><td class=blW>Ro Fa�ken�teins</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Ma Zimba</td><td class=bc>-</td><td class=blW>Jo Pleikys</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Ig Zamiatin</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Ra Stern�ts</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ge Jansons</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>Al Kalni��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Li Kondrashevskyi</td><td class=bc>-</td><td class=blW>La Karlsson</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Ro Fa�ken�teins</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Jo Pleikys</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ju Hellevuo</td><td class=bc>-</td><td class=bl>Ig Zamiatin</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ma Zimba</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Ra Stern�ts</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Er Kalni��</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=blW>Al Kalni��</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>La Karlsson</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Re Saul�tis</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Li Kondrashevskyi</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Jo Pleikys</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Ig Zamiatin</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ju Hellevuo</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Zimba</td><td class=bc>-</td><td class=blW>Ra Stern�ts</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>As Kocere</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>An Kova��uks</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Al Kalni��</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>L� Bezdel�ga</td><td class=bc>-</td><td class=bl>La Karlsson</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ge Jansons</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Re Saul�tis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Jo Pleikys</td><td class=bc>-</td><td class=bl>Ig Zamiatin</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Ma Krauze</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Ra Stern�ts</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Ju Hellevuo</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ma Zimba</td><td class=bc>-</td><td class=blW>Er Kalni��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Al Kalni��</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>La Karlsson</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>On Gruncl</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Da Belkovs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ge Jansons</td><td class=bc>-</td><td class=blW>Li Kondrashevskyi</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Ig Zamiatin</td><td class=bc>-</td><td class=blW>Ma Krauze</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=blW>Gu Buls</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Er Kalni��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Ju Hellevuo</td><td class=bc>-</td><td class=blW>Al Kalni��</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ma Zimba</td><td class=bc>-</td><td class=bl>La Karlsson</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>On Gruncl</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Li Kondrashevskyi</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Da Belkovs</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>18</td></tr>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=bl>Gu Buls</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ig Zamiatin</td><td class=bc>-</td><td class=bl>Ra Stern�ts</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Jo Pleikys</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Er Kalni��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=blW>Al Kalni��</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=bl>La Karlsson</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ju Hellevuo</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Ma Zimba</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>Li Kondrashevskyi</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>J� Zem�ickis</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>L� Bezdel�ga</td><td class=bc>-</td><td class=blW>Ge Jansons</td><td class=bc>0 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>19</td></tr>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>Ra Stern�ts</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ig Zamiatin</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=blW>Al Kalni��</td><td class=bc>2 : 6</tr></td>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>La Karlsson</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ju Hellevuo</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Zimba</td><td class=bc>-</td><td class=blW>Li Kondrashevskyi</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>An Kova��uks</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>J� Zem�ickis</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>2 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>20</td></tr>
<tr><td class=brW>Ra Stern�ts</td><td class=bc>-</td><td class=bl>Kr Zarinieks</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>Er Kalni��</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>Al Kalni��</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ig Zamiatin</td><td class=bc>-</td><td class=blW>La Karlsson</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Jo Pleikys</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Li Kondrashevskyi</td><td class=bc>3 : 7</tr></td>
<tr><td class=br>Ju Hellevuo</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ma Zimba</td><td class=bc>-</td><td class=blW>Ge Jansons</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>As Kocere</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>5 : 4</tr></td>
<tr><td class=br>An Kova��uks</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>21</td></tr>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Er Kalni��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>Al Kalni��</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=blW>La Karlsson</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ig Zamiatin</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Li Kondrashevskyi</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ja Hansson</td><td class=bc>-</td><td class=blW>Ge Jansons</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Ju Hellevuo</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ma Zimba</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>As Kocere</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>22</td></tr>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>Al Kalni��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>La Karlsson</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=blW>On Gruncl</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ig Zamiatin</td><td class=bc>-</td><td class=blW>Li Kondrashevskyi</td><td class=bc>0 : 7</tr></td>
<tr><td class=brW>Jo Pleikys</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>Ge Jansons</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ja Hansson</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ju Hellevuo</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ma Zimba</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>23</td></tr>
<tr><td class=brW>Al Kalni��</td><td class=bc>-</td><td class=bl>La Karlsson</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=blW>On Gruncl</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Ag Pav�rs</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Gu Buls</td><td class=bc>-</td><td class=bl>Li Kondrashevskyi</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>Re Saul�tis</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Ig Zamiatin</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>7 : 2</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>L� Bezdel�ga</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ja Hansson</td><td class=bc>-</td><td class=bl>An Kova��uks</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ju Hellevuo</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>24</td></tr>
<tr><td class=br>La Karlsson</td><td class=bc>-</td><td class=bl>On Gruncl</td><td class=bc>4 : 4</tr></td>
<tr><td class=brW>Al Kalni��</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>9 : 2</tr></td>
<tr><td class=br>Er Kalni��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Li Kondrashevskyi</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ra Stern�ts</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=bl>Ge Jansons</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ma Krauze</td><td class=bc>-</td><td class=blW>Da Belkovs</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ig Zamiatin</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Jo Pleikys</td><td class=bc>-</td><td class=blW>J� Zem�ickis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ro Fa�ken�teins</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Ja Hansson</td><td class=bc>-</td><td class=bl>Ma Zimba</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>25</td></tr>
<tr><td class=br>On Gruncl</td><td class=bc>-</td><td class=bl>Ag Pav�rs</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>La Karlsson</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Kalni��</td><td class=bc>-</td><td class=blW>Li Kondrashevskyi</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Er Kalni��</td><td class=bc>-</td><td class=bl>Re Saul�tis</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Kr Zarinieks</td><td class=bc>-</td><td class=blW>Ge Jansons</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ra Stern�ts</td><td class=bc>-</td><td class=bl>Da Belkovs</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Gu Buls</td><td class=bc>-</td><td class=bl>L� Bezdel�ga</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Krauze</td><td class=bc>-</td><td class=bl>J� Zem�ickis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ig Zamiatin</td><td class=bc>-</td><td class=blW>An Kova��uks</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Jo Pleikys</td><td class=bc>-</td><td class=bl>As Kocere</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ro Fa�ken�teins</td><td class=bc>-</td><td class=bl>Ma Zimba</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Re Stac�vi�s</td><td class=bc>-</td><td class=bl>Ju Hellevuo</td><td class=bc>6 : 3</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 4.l�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Wi Possl</td><td class=kx>*</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kW>5:2</td>
<td class=kT>1:1</td>
<td class=kW>6:0</td>
<td class=kW>5:1</td>
<td class=kL>0:4</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kT>4:4</td>
<td class=kW>4:1</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kW>5:0</td>
<td class=br>53:23</td><td class=br>+30</td>
<td class=bc>10 - 3 - 2</td>
<td class=br><strong>23</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Ma P�tersons</td><td class=kT>3:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kW>2:0</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kT>1:1</td>
<td class=kW>5:4</td>
<td class=kW>3:1</td>
<td class=kW>3:1</td>
<td class=kW>4:3</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=br>37:31</td><td class=br>+6</td>
<td class=bc>10 - 3 - 2</td>
<td class=br><strong>23</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Ro Forsberg</td><td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kL>1:2</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>1:0</td>
<td class=kW>3:1</td>
<td class=kT>4:4</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>4:1</td>
<td class=kW>2:1</td>
<td class=br>35:23</td><td class=br>+12</td>
<td class=bc>10 - 2 - 3</td>
<td class=br><strong>22</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>�r Egl�tis</td><td class=kL>2:5</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kW>4:2</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kW>4:1</td>
<td class=kW>10:0</td>
<td class=br>43:28</td><td class=br>+15</td>
<td class=bc>8 - 2 - 5</td>
<td class=br><strong>18</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ro Aseri��</td><td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kW>3:0</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kT>2:2</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>1:0</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kW>2:0</td>
<td class=br>31:23</td><td class=br>+8</td>
<td class=bc>7 - 4 - 4</td>
<td class=br><strong>18</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>T� Gor�anova</td><td class=kL>0:6</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kL>0:3</td>
<td class=kT>1:1</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=br>19:27</td><td class=br>-8</td>
<td class=bc>6 - 4 - 5</td>
<td class=br><strong>16</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>M� Timbers</td><td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>0:3</td>
<td class=kL>1:6</td>
<td class=kT>2:2</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>2:0</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kT>3:3</td>
<td class=kW>2:1</td>
<td class=br>25:33</td><td class=br>-8</td>
<td class=bc>5 - 5 - 5</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Hy Nechutny</td><td class=kW>4:0</td>
<td class=kW>6:0</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>6:1</td>
<td class=k>&nbsp;</td>
<td class=kW>3:1</td>
<td class=kL>2:3</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>2:3</td>
<td class=br>39:24</td><td class=br>+15</td>
<td class=bc>6 - 2 - 6</td>
<td class=br><strong>14</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Ke Nilsson</td><td class=kL>0:3</td>
<td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>0:3</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kL>3:4</td>
<td class=kW>5:3</td>
<td class=kL>4:7</td>
<td class=kW>5:4</td>
<td class=kW>5:0</td>
<td class=br>34:41</td><td class=br>-7</td>
<td class=bc>6 - 2 - 7</td>
<td class=br><strong>14</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ro Garda</td><td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>4:1</td>
<td class=kT>1:1</td>
<td class=kT>1:1</td>
<td class=kL>1:6</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>1:5</td>
<td class=kW>3:1</td>
<td class=kW>4:0</td>
<td class=kW>3:2</td>
<td class=kL>1:3</td>
<td class=br>25:33</td><td class=br>-8</td>
<td class=bc>5 - 3 - 7</td>
<td class=br><strong>13</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>El Reinfelds</td><td class=kT>4:4</td>
<td class=kL>4:5</td>
<td class=kT>4:4</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kT>2:2</td>
<td class=k>&nbsp;</td>
<td class=kL>1:2</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>7:1</td>
<td class=kW>5:4</td>
<td class=kW>5:1</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=br>43:35</td><td class=br>+8</td>
<td class=bc>5 - 3 - 6</td>
<td class=br><strong>13</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Bi Gajsek</td><td class=kL>1:4</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kW>1:0</td>
<td class=kL>1:3</td>
<td class=kT>1:1</td>
<td class=kL>0:2</td>
<td class=kL>1:3</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kL>1:7</td>
<td class=kx>*</td>
<td class=kW>6:4</td>
<td class=kT>1:1</td>
<td class=kL>3:5</td>
<td class=kW>3:2</td>
<td class=br>31:43</td><td class=br>-12</td>
<td class=bc>5 - 2 - 8</td>
<td class=br><strong>12</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Br Gor�anovs</td><td class=kL>2:4</td>
<td class=kL>1:3</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kL>0:1</td>
<td class=kL>0:1</td>
<td class=kW>5:1</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kL>1:3</td>
<td class=kL>4:5</td>
<td class=kL>4:6</td>
<td class=kx>*</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=br>39:36</td><td class=br>+3</td>
<td class=bc>5 - 1 - 9</td>
<td class=br><strong>11</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Ri D�cis</td><td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kL>1:3</td>
<td class=kW>5:0</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kL>1:3</td>
<td class=kL>2:4</td>
<td class=kW>7:4</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>15:0</td>
<td class=br>43:39</td><td class=br>+4</td>
<td class=bc>4 - 3 - 8</td>
<td class=br><strong>11</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>Kr S�manis</td><td class=kL>2:3</td>
<td class=kL>1:3</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kT>3:3</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kL>2:3</td>
<td class=kW>3:0</td>
<td class=kW>5:3</td>
<td class=kL>0:5</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=br>33:41</td><td class=br>-8</td>
<td class=bc>4 - 3 - 8</td>
<td class=br><strong>11</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>Ed Garan�s</td><td class=kL>0:5</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>0:10</td>
<td class=kL>0:2</td>
<td class=kL>1:2</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kL>0:5</td>
<td class=kW>3:1</td>
<td class=kL>1:4</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>0:15</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=br>13:63</td><td class=br>-50</td>
<td class=bc>2 - 0 - 13</td>
<td class=br><strong>4</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>Wi Possl</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>�r Egl�tis</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ro Forsberg</td><td class=bc>-</td><td class=bl>Bi Gajsek</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Ke Nilsson</td><td class=bc>-</td><td class=blW>M� Timbers</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Ed Garan�s</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Hy Nechutny</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Wi Possl</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>Ma P�tersons</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Bi Gajsek</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>�r Egl�tis</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Ro Forsberg</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ke Nilsson</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Wi Possl</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Bi Gajsek</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>M� Timbers</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=blW>Ro Garda</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>�r Egl�tis</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ro Forsberg</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ke Nilsson</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ed Garan�s</td><td class=bc>-</td><td class=bl>Hy Nechutny</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Ma P�tersons</td><td class=bc>-</td><td class=bl>Bi Gajsek</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Wi Possl</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>�r Egl�tis</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ro Forsberg</td><td class=bc>-</td><td class=bl>Hy Nechutny</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ke Nilsson</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>0 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Bi Gajsek</td><td class=bc>-</td><td class=blW>M� Timbers</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Wi Possl</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ri D�cis</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Hy Nechutny</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>�r Egl�tis</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Ro Forsberg</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Bi Gajsek</td><td class=bc>-</td><td class=blW>El Reinfelds</td><td class=bc>1 : 7</tr></td>
<tr><td class=brW>Ma P�tersons</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Wi Possl</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Hy Nechutny</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ri D�cis</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>�r Egl�tis</td><td class=bc>-</td><td class=blW>Ke Nilsson</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Ro Garda</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Br Gor�anovs</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Bi Gajsek</td><td class=bc>-</td><td class=blW>Kr S�manis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=blW>Hy Nechutny</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Wi Possl</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ri D�cis</td><td class=bc>-</td><td class=bl>Ke Nilsson</td><td class=bc>7 : 4</tr></td>
<tr><td class=brW>Ro Aseri��</td><td class=bc>-</td><td class=bl>Ro Forsberg</td><td class=bc>3 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>El Reinfelds</td><td class=bc>-</td><td class=bl>Br Gor�anovs</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Ro Garda</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>M� Timbers</td><td class=bc>-</td><td class=bl>Hy Nechutny</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Bi Gajsek</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ma P�tersons</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Wi Possl</td><td class=bc>-</td><td class=bl>Ke Nilsson</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ro Forsberg</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ri D�cis</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Kr S�manis</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>Hy Nechutny</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=bl>T� Gor�anova</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>M� Timbers</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Bi Gajsek</td><td class=bc>-</td><td class=bl>Ke Nilsson</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Ma P�tersons</td><td class=bc>-</td><td class=bl>Ro Forsberg</td><td class=bc>4 : 3</tr></td>
<tr><td class=brW>Wi Possl</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=bl>Hy Nechutny</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>El Reinfelds</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=blW>Ke Nilsson</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Ro Forsberg</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Bi Gajsek</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Ma P�tersons</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Wi Possl</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Hy Nechutny</td><td class=bc>-</td><td class=blW>T� Gor�anova</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Kr S�manis</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Ke Nilsson</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>Ro Forsberg</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=blW>�r Egl�tis</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Bi Gajsek</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma P�tersons</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>T� Gor�anova</td><td class=bc>-</td><td class=bl>Ed Garan�s</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Hy Nechutny</td><td class=bc>-</td><td class=bl>Ke Nilsson</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=blW>Ro Forsberg</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Br Gor�anovs</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ro Garda</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Bi Gajsek</td><td class=bc>-</td><td class=blW>Wi Possl</td><td class=bc>1 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=blW>Ke Nilsson</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>T� Gor�anova</td><td class=bc>-</td><td class=bl>Ro Forsberg</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Hy Nechutny</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Kr S�manis</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=blW>Wi Possl</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>M� Timbers</td><td class=bc>-</td><td class=blW>Ma P�tersons</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ke Nilsson</td><td class=bc>-</td><td class=blW>Ro Forsberg</td><td class=bc>0 : 1</tr></td>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=blW>�r Egl�tis</td><td class=bc>0 : 10</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>Ro Aseri��</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Hy Nechutny</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Wi Possl</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=blW>Ma P�tersons</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Ro Garda</td><td class=bc>-</td><td class=blW>Bi Gajsek</td><td class=bc>1 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Ro Forsberg</td><td class=bc>-</td><td class=bl>�r Egl�tis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ke Nilsson</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=blW>Ri D�cis</td><td class=bc>0 : 15</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Hy Nechutny</td><td class=bc>-</td><td class=bl>Wi Possl</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=blW>Ma P�tersons</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Bi Gajsek</td><td class=bc>4 : 6</tr></td>
<tr><td class=br>El Reinfelds</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>�r Egl�tis</td><td class=bc>-</td><td class=bl>Ro Aseri��</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Ro Forsberg</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Ke Nilsson</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=blW>Wi Possl</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=blW>Ma P�tersons</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Hy Nechutny</td><td class=bc>-</td><td class=bl>Bi Gajsek</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Kr S�manis</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Br Gor�anovs</td><td class=bc>-</td><td class=blW>Ro Garda</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>Ro Aseri��</td><td class=bc>-</td><td class=bl>Ri D�cis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>�r Egl�tis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ro Forsberg</td><td class=bc>-</td><td class=bl>Wi Possl</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Ke Nilsson</td><td class=bc>-</td><td class=bl>Ma P�tersons</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ed Garan�s</td><td class=bc>-</td><td class=blW>Bi Gajsek</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>T� Gor�anova</td><td class=bc>-</td><td class=bl>M� Timbers</td><td class=bc>0 : 0</tr></td>
<tr><td class=brW>Hy Nechutny</td><td class=bc>-</td><td class=bl>Ro Garda</td><td class=bc>6 : 1</tr></td>
<tr><td class=brW>Kr S�manis</td><td class=bc>-</td><td class=bl>El Reinfelds</td><td class=bc>3 : 0</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
<p class=v>Group 5.l�ga</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>15</td>
<td class=ic>16</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>1.</td><td class=kt>Ma Kalni��</td><td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kW>3:0</td>
<td class=kW>7:0</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>1:0</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>5:2</td>
<td class=kT>2:2</td>
<td class=kW>13:0</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=br>59:13</td><td class=br>+46</td>
<td class=bc>12 - 2 - 1</td>
<td class=br><strong>26</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>2.</td><td class=kt>Kr Timbers</td><td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kT>0:0</td>
<td class=kT>4:4</td>
<td class=kL>1:4</td>
<td class=kL>0:4</td>
<td class=kW>4:3</td>
<td class=kW>4:2</td>
<td class=kW>2:1</td>
<td class=kW>2:0</td>
<td class=kW>4:1</td>
<td class=kW>5:2</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=br>46:23</td><td class=br>+23</td>
<td class=bc>11 - 2 - 2</td>
<td class=br><strong>24</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>3.</td><td class=kt>Al Liepi��</td><td class=kL>2:3</td>
<td class=kT>0:0</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kW>5:3</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>5:1</td>
<td class=kW>3:0</td>
<td class=kW>5:1</td>
<td class=kW>2:1</td>
<td class=kW>12:0</td>
<td class=kW>5:0</td>
<td class=kW>5:1</td>
<td class=br>56:19</td><td class=br>+37</td>
<td class=bc>11 - 1 - 3</td>
<td class=br><strong>23</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>4.</td><td class=kt>Gu Skapsts</td><td class=kL>1:3</td>
<td class=kT>4:4</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kL>3:6</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>5:0</td>
<td class=kW>4:2</td>
<td class=br>44:28</td><td class=br>+16</td>
<td class=bc>9 - 2 - 4</td>
<td class=br><strong>20</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt>Ju Stei��nas</td><td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kL>3:5</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=kW>5:4</td>
<td class=kW>6:2</td>
<td class=kL>2:3</td>
<td class=kT>2:2</td>
<td class=kW>6:4</td>
<td class=kW>5:1</td>
<td class=kT>2:2</td>
<td class=kW>8:0</td>
<td class=br>51:37</td><td class=br>+14</td>
<td class=bc>8 - 3 - 4</td>
<td class=br><strong>19</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt>To Ulis</td><td class=kL>0:7</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>4:2</td>
<td class=kL>1:4</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kT>0:0</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=br>41:32</td><td class=br>+9</td>
<td class=bc>8 - 3 - 4</td>
<td class=br><strong>19</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt>Em Ka�s</td><td class=kL>1:5</td>
<td class=kL>3:4</td>
<td class=kW>3:2</td>
<td class=kL>0:4</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kL>0:4</td>
<td class=kL>0:1</td>
<td class=kT>1:1</td>
<td class=kW>3:2</td>
<td class=kW>6:2</td>
<td class=kW>4:3</td>
<td class=kW>5:1</td>
<td class=kW>4:1</td>
<td class=br>39:37</td><td class=br>+2</td>
<td class=bc>8 - 1 - 6</td>
<td class=br><strong>17</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt>Em Vi��akovs</td><td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kL>1:2</td>
<td class=kT>1:1</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=kW>5:3</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=br>41:27</td><td class=br>+14</td>
<td class=bc>7 - 2 - 6</td>
<td class=br><strong>16</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt>Mi Myren</td><td class=kL>0:1</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>2:3</td>
<td class=kL>4:5</td>
<td class=kL>2:4</td>
<td class=kW>4:0</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:2</td>
<td class=kW>2:1</td>
<td class=kW>7:0</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=br>42:32</td><td class=br>+10</td>
<td class=bc>8 - 0 - 7</td>
<td class=br><strong>16</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt>Ed Liepi��</td><td class=kL>1:2</td>
<td class=kL>0:2</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>2:6</td>
<td class=kW>4:1</td>
<td class=kW>1:0</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=kL>1:2</td>
<td class=kW>4:0</td>
<td class=kW>4:2</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=br>36:30</td><td class=br>+6</td>
<td class=bc>7 - 0 - 8</td>
<td class=br><strong>14</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt>Ra R�ders</td><td class=kT>1:1</td>
<td class=kL>1:4</td>
<td class=kL>0:3</td>
<td class=kW>6:3</td>
<td class=kW>3:2</td>
<td class=kL>2:5</td>
<td class=kT>1:1</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kT>1:1</td>
<td class=kT>2:2</td>
<td class=kW>5:0</td>
<td class=kW>4:1</td>
<td class=br>38:38</td><td class=br>0</td>
<td class=bc>5 - 4 - 6</td>
<td class=br><strong>14</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt>Ju Forsberg</td><td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kT>2:2</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>1:2</td>
<td class=kW>2:1</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kL>1:2</td>
<td class=kW>4:1</td>
<td class=kW>5:0</td>
<td class=k>&nbsp;</td>
<td class=br>31:38</td><td class=br>-7</td>
<td class=bc>5 - 1 - 8</td>
<td class=br><strong>11</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt>Ma Ru�manis</td><td class=kT>2:2</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kL>0:4</td>
<td class=kL>4:6</td>
<td class=kT>0:0</td>
<td class=kL>2:6</td>
<td class=kL>0:4</td>
<td class=kL>0:7</td>
<td class=kL>0:4</td>
<td class=kT>1:1</td>
<td class=kW>2:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>5:0</td>
<td class=kT>3:3</td>
<td class=br>22:45</td><td class=br>-23</td>
<td class=bc>3 - 4 - 8</td>
<td class=br><strong>10</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt>Ro Zygelis</td><td class=kL>0:13</td>
<td class=kL>1:5</td>
<td class=kL>0:12</td>
<td class=kL>2:4</td>
<td class=kL>1:5</td>
<td class=kL>1:2</td>
<td class=kL>3:4</td>
<td class=kL>3:5</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:0</td>
<td class=kW>3:0</td>
<td class=br>25:65</td><td class=br>-40</td>
<td class=bc>2 - 1 - 12</td>
<td class=br><strong>5</strong></td><td class=d>14.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>15.</td><td class=kt>An Garan�a</td><td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kT>2:2</td>
<td class=kL>0:5</td>
<td class=kL>1:5</td>
<td class=kL>0:5</td>
<td class=kL>2:5</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kL>0:5</td>
<td class=kx>*</td>
<td class=kW>5:2</td>
<td class=br>10:67</td><td class=br>-57</td>
<td class=bc>1 - 1 - 13</td>
<td class=br><strong>3</strong></td><td class=d>15.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>16.</td><td class=kt>An Israelsson</td><td class=kL>1:5</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kL>2:4</td>
<td class=kL>0:8</td>
<td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>1:6</td>
<td class=kL>1:4</td>
<td class=k>&nbsp;</td>
<td class=kT>3:3</td>
<td class=kL>0:3</td>
<td class=kL>2:5</td>
<td class=kx>*</td>
<td class=br>16:66</td><td class=br>-50</td>
<td class=bc>0 - 1 - 13</td>
<td class=br><strong>1</strong></td><td class=d>16.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>To Ulis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>An Israelsson</td><td class=bc>-</td><td class=blW>Kr Timbers</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Gu Skapsts</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>4 : 0</tr></td>
<tr><td class=brW>Mi Myren</td><td class=bc>-</td><td class=bl>Ma Ru�manis</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ma Kalni��</td><td class=bc>-</td><td class=bl>Ro Zygelis</td><td class=bc>13 : 0</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Kr Timbers</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>To Ulis</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>An Israelsson</td><td class=bc>-</td><td class=bl>Ma Ru�manis</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Gu Skapsts</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Mi Myren</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=bl>Ro Zygelis</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Ju Stei��nas</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ma Kalni��</td><td class=bc>-</td><td class=bl>Ju Forsberg</td><td class=bc>5 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Kr Timbers</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>4 : 3</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ma Ru�manis</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>To Ulis</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>An Israelsson</td><td class=bc>-</td><td class=blW>An Garan�a</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Gu Skapsts</td><td class=bc>-</td><td class=bl>Ro Zygelis</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Myren</td><td class=bc>-</td><td class=blW>Em Vi��akovs</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ra R�ders</td><td class=bc>-</td><td class=bl>Ju Forsberg</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>3 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>Ma Ru�manis</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Kr Timbers</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>2 : 0</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>To Ulis</td><td class=bc>-</td><td class=bl>Ro Zygelis</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>An Israelsson</td><td class=bc>-</td><td class=blW>Em Vi��akovs</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Gu Skapsts</td><td class=bc>-</td><td class=bl>Ju Forsberg</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Mi Myren</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Ma Ru�manis</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Kr Timbers</td><td class=bc>-</td><td class=bl>Ro Zygelis</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>To Ulis</td><td class=bc>-</td><td class=blW>Ju Forsberg</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>An Israelsson</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Gu Skapsts</td><td class=bc>-</td><td class=blW>Ma Kalni��</td><td class=bc>1 : 3</tr></td>
<tr><td class=br>Mi Myren</td><td class=bc>-</td><td class=blW>Ju Stei��nas</td><td class=bc>4 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Ed Liepi��</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Ma Ru�manis</td><td class=bc>-</td><td class=bl>Ro Zygelis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>Em Vi��akovs</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Kr Timbers</td><td class=bc>-</td><td class=bl>Ju Forsberg</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>To Ulis</td><td class=bc>-</td><td class=blW>Ma Kalni��</td><td class=bc>0 : 7</tr></td>
<tr><td class=br>An Israelsson</td><td class=bc>-</td><td class=blW>Ju Stei��nas</td><td class=bc>0 : 8</tr></td>
<tr><td class=br>Gu Skapsts</td><td class=bc>-</td><td class=blW>Ra R�ders</td><td class=bc>3 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>Ro Zygelis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Em Vi��akovs</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Ma Ru�manis</td><td class=bc>-</td><td class=bl>Ju Forsberg</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>Al Liepi��</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Kr Timbers</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Ju Stei��nas</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>To Ulis</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>An Israelsson</td><td class=bc>-</td><td class=blW>Mi Myren</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Ro Zygelis</td><td class=bc>-</td><td class=blW>Em Vi��akovs</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>Ju Forsberg</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Ma Ru�manis</td><td class=bc>-</td><td class=bl>Ma Kalni��</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Ju Stei��nas</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Kr Timbers</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Mi Myren</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>To Ulis</td><td class=bc>-</td><td class=bl>Gu Skapsts</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>Ju Forsberg</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ro Zygelis</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>0 : 12</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>Ma Kalni��</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Ju Stei��nas</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Ma Ru�manis</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=blW>Mi Myren</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Kr Timbers</td><td class=bc>-</td><td class=bl>Gu Skapsts</td><td class=bc>4 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>An Israelsson</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Ju Forsberg</td><td class=bc>-</td><td class=blW>Al Liepi��</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>Ma Kalni��</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Ro Zygelis</td><td class=bc>-</td><td class=blW>Ju Stei��nas</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>Ra R�ders</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=blW>Mi Myren</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ma Ru�manis</td><td class=bc>-</td><td class=blW>Gu Skapsts</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Em Ka�s</td><td class=bc>-</td><td class=bl>An Israelsson</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Kr Timbers</td><td class=bc>-</td><td class=blW>To Ulis</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>Ma Kalni��</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ju Forsberg</td><td class=bc>-</td><td class=bl>Ju Stei��nas</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Em Vi��akovs</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Ro Zygelis</td><td class=bc>-</td><td class=blW>Mi Myren</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>Gu Skapsts</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ed Liepi��</td><td class=bc>-</td><td class=bl>An Israelsson</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Ma Ru�manis</td><td class=bc>-</td><td class=bl>To Ulis</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Em Ka�s</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Ma Kalni��</td><td class=bc>-</td><td class=bl>Ju Stei��nas</td><td class=bc>3 : 0</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Ra R�ders</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Ju Forsberg</td><td class=bc>-</td><td class=blW>Mi Myren</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=bl>Gu Skapsts</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ro Zygelis</td><td class=bc>-</td><td class=bl>An Israelsson</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>To Ulis</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Ed Liepi��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Ma Ru�manis</td><td class=bc>-</td><td class=blW>Kr Timbers</td><td class=bc>0 : 4</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=blW>Ra R�ders</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ma Kalni��</td><td class=bc>-</td><td class=bl>Mi Myren</td><td class=bc>1 : 0</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Gu Skapsts</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Ju Forsberg</td><td class=bc>-</td><td class=bl>An Israelsson</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=bl>To Ulis</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Ro Zygelis</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>Kr Timbers</td><td class=bc>0 : 5</tr></td>
<tr><td class=brW>Ed Liepi��</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>1 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=blW>Mi Myren</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=blW>Gu Skapsts</td><td class=bc>1 : 5</tr></td>
<tr><td class=brW>Ma Kalni��</td><td class=bc>-</td><td class=bl>An Israelsson</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=blW>To Ulis</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Ju Forsberg</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Em Vi��akovs</td><td class=bc>-</td><td class=blW>Kr Timbers</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ro Zygelis</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>An Garan�a</td><td class=bc>-</td><td class=blW>Ma Ru�manis</td><td class=bc>0 : 5</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Mi Myren</td><td class=bc>-</td><td class=blW>Gu Skapsts</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Ra R�ders</td><td class=bc>-</td><td class=bl>An Israelsson</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>Ju Stei��nas</td><td class=bc>-</td><td class=bl>To Ulis</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Ma Kalni��</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Al Liepi��</td><td class=bc>-</td><td class=bl>Kr Timbers</td><td class=bc>0 : 0</tr></td>
<tr><td class=br>Ju Forsberg</td><td class=bc>-</td><td class=blW>Em Ka�s</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Em Vi��akovs</td><td class=bc>-</td><td class=bl>Ma Ru�manis</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Ro Zygelis</td><td class=bc>-</td><td class=blW>Ed Liepi��</td><td class=bc>2 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>16</td></tr>
<tr><td class=brW>Gu Skapsts</td><td class=bc>-</td><td class=bl>An Israelsson</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Mi Myren</td><td class=bc>-</td><td class=blW>To Ulis</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Ju Stei��nas</td><td class=bc>-</td><td class=bl>Kr Timbers</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Ma Kalni��</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>Ma Ru�manis</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Ju Forsberg</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Em Vi��akovs</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>5 : 0</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>17</td></tr>
<tr><td class=br>An Israelsson</td><td class=bc>-</td><td class=blW>To Ulis</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Gu Skapsts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Mi Myren</td><td class=bc>-</td><td class=blW>Kr Timbers</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Ra R�ders</td><td class=bc>-</td><td class=bl>Em Ka�s</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Ju Stei��nas</td><td class=bc>-</td><td class=bl>Ma Ru�manis</td><td class=bc>6 : 4</tr></td>
<tr><td class=brW>Ma Kalni��</td><td class=bc>-</td><td class=bl>Ed Liepi��</td><td class=bc>2 : 1</tr></td>
<tr><td class=brW>Al Liepi��</td><td class=bc>-</td><td class=bl>An Garan�a</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Ju Forsberg</td><td class=bc>-</td><td class=bl>Ro Zygelis</td><td class=bc>4 : 1</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
