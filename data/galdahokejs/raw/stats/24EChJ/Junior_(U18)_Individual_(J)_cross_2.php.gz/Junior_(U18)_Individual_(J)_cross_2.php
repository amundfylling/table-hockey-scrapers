<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Junior (U18) Individual (J)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Junior_(U18)_Individual_(J)_list.php">Junior (U18) Individual (J)</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group Junior 2</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>14</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=116&x=-59&p=Ar%20Matantsev">Ar Matantsev</a></td><td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>5:3</td>
<td class=kW>3:2</td>
<td class=kW>5:2</td>
<td class=kW>4:3</td>
<td class=kW>4:1</td>
<td class=kW>6:3</td>
<td class=kW>4:2</td>
<td class=kL>2:3</td>
<td class=kW>5:2</td>
<td class=kW>6:1</td>
<td class=kW>7:1</td>
<td class=kW>10:0</td>
<td class=br>62:27</td><td class=br>+35</td>
<td class=bc>11 - 0 - 2</td>
<td class=br><strong>22</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=104&x=-59&p=Ed%20Nilsson">Ed Nilsson</a></td><td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kL>0:2</td>
<td class=kW>6:3</td>
<td class=kW>6:0</td>
<td class=kW>4:1</td>
<td class=kW>4:1</td>
<td class=kL>0:2</td>
<td class=kW>3:0</td>
<td class=kW>6:1</td>
<td class=kW>5:1</td>
<td class=kW>2:0</td>
<td class=kW>8:0</td>
<td class=br>49:15</td><td class=br>+34</td>
<td class=bc>10 - 0 - 3</td>
<td class=br><strong>20</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=211&x=-59&p=Ro%20L%C4%ABvmanis">Ro L�vmanis</a></td><td class=kL>3:5</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>4:2</td>
<td class=kL>0:5</td>
<td class=kT>3:3</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kW>8:3</td>
<td class=kW>3:1</td>
<td class=kW>2:1</td>
<td class=kW>5:2</td>
<td class=kW>1:0</td>
<td class=kW>4:1</td>
<td class=br>39:30</td><td class=br>+9</td>
<td class=bc>8 - 2 - 3</td>
<td class=br><strong>18</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=5&x=-59&p=Re%20Vazoli%C5%86%C5%A1">Re Vazoli��</a></td><td class=kL>2:3</td>
<td class=kW>2:0</td>
<td class=kL>2:4</td>
<td class=kx>*</td>
<td class=kW>1:0</td>
<td class=kL>2:3</td>
<td class=kW>3:1</td>
<td class=kW>5:4</td>
<td class=kL>2:3</td>
<td class=kW>8:2</td>
<td class=kW>5:0</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kW>9:0</td>
<td class=br>47:22</td><td class=br>+25</td>
<td class=bc>9 - 0 - 4</td>
<td class=br><strong>18</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=29&x=-59&p=Kr%20Lagzdi%C5%86a">Kr Lagzdi�a</a></td><td class=kL>2:5</td>
<td class=kL>3:6</td>
<td class=kW>5:0</td>
<td class=kL>0:1</td>
<td class=kx>*</td>
<td class=kL>1:3</td>
<td class=kW>8:1</td>
<td class=kW>5:3</td>
<td class=kT>1:1</td>
<td class=kW>10:1</td>
<td class=kW>5:3</td>
<td class=kW>6:0</td>
<td class=kW>6:0</td>
<td class=kW>4:0</td>
<td class=br>56:24</td><td class=br>+32</td>
<td class=bc>8 - 1 - 4</td>
<td class=br><strong>17</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=421&x=-59&p=Gu%20Nilsson">Gu Nilsson</a></td><td class=kL>3:4</td>
<td class=kL>0:6</td>
<td class=kT>3:3</td>
<td class=kW>3:2</td>
<td class=kW>3:1</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:3</td>
<td class=kL>0:3</td>
<td class=kL>2:4</td>
<td class=kW>2:1</td>
<td class=kT>2:2</td>
<td class=kW>3:0</td>
<td class=kW>5:4</td>
<td class=br>32:34</td><td class=br>-2</td>
<td class=bc>7 - 2 - 4</td>
<td class=br><strong>16</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=231&x=-59&p=Ar%20Tseluiko">Ar Tseluiko</a></td><td class=kL>1:4</td>
<td class=kL>1:4</td>
<td class=kW>4:1</td>
<td class=kL>1:3</td>
<td class=kL>1:8</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>5:2</td>
<td class=kW>7:2</td>
<td class=kW>5:0</td>
<td class=kW>5:2</td>
<td class=br>41:33</td><td class=br>+8</td>
<td class=bc>7 - 1 - 5</td>
<td class=br><strong>15</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=426&x=-59&p=Wi%20Wallin">Wi Wallin</a></td><td class=kL>3:6</td>
<td class=kL>1:4</td>
<td class=kT>2:2</td>
<td class=kL>4:5</td>
<td class=kL>3:5</td>
<td class=kL>3:4</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:3</td>
<td class=kW>6:2</td>
<td class=kW>11:3</td>
<td class=kW>7:4</td>
<td class=kW>3:0</td>
<td class=kW>5:2</td>
<td class=br>54:42</td><td class=br>+12</td>
<td class=bc>6 - 1 - 6</td>
<td class=br><strong>13</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=45&x=-59&p=Al%20Skudr%C4%ABtis">Al Skudr�tis</a></td><td class=kL>2:4</td>
<td class=kW>2:0</td>
<td class=kL>3:8</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kW>3:0</td>
<td class=kL>2:6</td>
<td class=kL>3:5</td>
<td class=kx>*</td>
<td class=kT>1:1</td>
<td class=kW>7:1</td>
<td class=kL>2:3</td>
<td class=kT>3:3</td>
<td class=kW>6:0</td>
<td class=br>38:34</td><td class=br>+4</td>
<td class=bc>5 - 3 - 5</td>
<td class=br><strong>13</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=218&x=-59&p=Dm%20Stykailo">Dm Stykailo</a></td><td class=kW>3:2</td>
<td class=kL>0:3</td>
<td class=kL>1:3</td>
<td class=kL>2:8</td>
<td class=kL>1:10</td>
<td class=kW>4:2</td>
<td class=kT>2:2</td>
<td class=kL>2:6</td>
<td class=kT>1:1</td>
<td class=kx>*</td>
<td class=kL>2:4</td>
<td class=kW>6:3</td>
<td class=kW>3:1</td>
<td class=kW>2:0</td>
<td class=br>29:45</td><td class=br>-16</td>
<td class=bc>5 - 2 - 6</td>
<td class=br><strong>12</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="stats.php?idpl=367&x=-59&p=Ol%20Pylypenko">Ol Pylypenko</a></td><td class=kL>2:5</td>
<td class=kL>1:6</td>
<td class=kL>1:2</td>
<td class=kL>0:5</td>
<td class=kL>3:5</td>
<td class=kL>1:2</td>
<td class=kL>2:5</td>
<td class=kL>3:11</td>
<td class=kL>1:7</td>
<td class=kW>4:2</td>
<td class=kx>*</td>
<td class=kW>6:2</td>
<td class=kT>2:2</td>
<td class=kW>7:0</td>
<td class=br>33:54</td><td class=br>-21</td>
<td class=bc>3 - 1 - 9</td>
<td class=br><strong>7</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="stats.php?idpl=242&x=-59&p=Ja%20Janouskovec">Ja Janouskovec</a></td><td class=kL>1:6</td>
<td class=kL>1:5</td>
<td class=kL>2:5</td>
<td class=kL>2:3</td>
<td class=kL>0:6</td>
<td class=kT>2:2</td>
<td class=kL>2:7</td>
<td class=kL>4:7</td>
<td class=kW>3:2</td>
<td class=kL>3:6</td>
<td class=kL>2:6</td>
<td class=kx>*</td>
<td class=kW>4:1</td>
<td class=kT>5:5</td>
<td class=br>31:61</td><td class=br>-30</td>
<td class=bc>2 - 2 - 9</td>
<td class=br><strong>6</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="stats.php?idpl=220&x=-59&p=Jo%20Pleikys">Jo Pleikys</a></td><td class=kL>1:7</td>
<td class=kL>0:2</td>
<td class=kL>0:1</td>
<td class=kL>0:3</td>
<td class=kL>0:6</td>
<td class=kL>0:3</td>
<td class=kL>0:5</td>
<td class=kL>0:3</td>
<td class=kT>3:3</td>
<td class=kL>1:3</td>
<td class=kT>2:2</td>
<td class=kL>1:4</td>
<td class=kx>*</td>
<td class=kW>3:1</td>
<td class=br>11:43</td><td class=br>-32</td>
<td class=bc>1 - 2 - 10</td>
<td class=br><strong>4</strong></td><td class=d>13.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>14.</td><td class=kt><a href="stats.php?idpl=410&x=-59&p=Mi%20Moravec">Mi Moravec</a></td><td class=kL>0:10</td>
<td class=kL>0:8</td>
<td class=kL>1:4</td>
<td class=kL>0:9</td>
<td class=kL>0:4</td>
<td class=kL>4:5</td>
<td class=kL>2:5</td>
<td class=kL>2:5</td>
<td class=kL>0:6</td>
<td class=kL>0:2</td>
<td class=kL>0:7</td>
<td class=kT>5:5</td>
<td class=kL>1:3</td>
<td class=kx>*</td>
<td class=br>15:73</td><td class=br>-58</td>
<td class=bc>0 - 1 - 12</td>
<td class=br><strong>1</strong></td><td class=d>14.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Janouskovec Jan</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>5 : 5</tr></td>
<tr><td class=br>L�vmanis Roberts</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Nilsson Gustav</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Tseluiko Artem</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>0 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Janouskovec Jan</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>4 : 1</tr></td>
<tr><td class=br>L�vmanis Roberts</td><td class=bc>-</td><td class=bl>Nilsson Gustav</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Tseluiko Artem</td><td class=bc>-</td><td class=bl>Stykailo Dmitri</td><td class=bc>2 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Wallin Wilton</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Nilsson Gustav</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Janouskovec Jan</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>L�vmanis Roberts</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Stykailo Dmitri</td><td class=bc>4 : 2</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>1 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=brW>Wallin Wilton</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>3 : 0</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Nilsson Gustav</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Matantsev Artem</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Janouskovec Jan</td><td class=bc>-</td><td class=blW>Stykailo Dmitri</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>L�vmanis Roberts</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=blW>Tseluiko Artem</td><td class=bc>2 : 5</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Nilsson Gustav</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>3 : 6</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>0 : 9</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Stykailo Dmitri</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Nilsson Eddie</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Janouskovec Jan</td><td class=bc>-</td><td class=blW>Tseluiko Artem</td><td class=bc>2 : 7</tr></td>
<tr><td class=brW>L�vmanis Roberts</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>8 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=br>Nilsson Gustav</td><td class=bc>-</td><td class=blW>Matantsev Artem</td><td class=bc>3 : 4</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Vazoli�� Regn�rs</td><td class=bc>0 : 3</tr></td>
<tr><td class=brW>Wallin Wilton</td><td class=bc>-</td><td class=bl>Stykailo Dmitri</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Tseluiko Artem</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Janouskovec Jan</td><td class=bc>-</td><td class=blW>Pylypenko Oleksandr</td><td class=bc>2 : 6</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Vazoli�� Regn�rs</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Nilsson Gustav</td><td class=bc>-</td><td class=blW>Stykailo Dmitri</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=blW>Tseluiko Artem</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Skudr�tis Alekss</td><td class=bc>0 : 6</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>&nbsp;</tr></td>
<tr><td class=br>Nilsson Eddie</td><td class=bc>-</td><td class=blW>L�vmanis Roberts</td><td class=bc>1 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Stykailo Dmitri</td><td class=bc>8 : 2</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Lagzdi�a Krista Annija</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Nilsson Gustav</td><td class=bc>-</td><td class=bl>Tseluiko Artem</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Wallin Wilton</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>11 : 3</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>L�vmanis Roberts</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>-----</td><td class=bc>-</td><td class=bl>Janouskovec Jan</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=br>Stykailo Dmitri</td><td class=bc>-</td><td class=blW>Lagzdi�a Krista Annija</td><td class=bc>1 : 10</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Tseluiko Artem</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>4 : 2</tr></td>
<tr><td class=brW>Nilsson Gustav</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>L�vmanis Roberts</td><td class=bc>0 : 1</tr></td>
<tr><td class=brW>Wallin Wilton</td><td class=bc>-</td><td class=bl>Janouskovec Jan</td><td class=bc>7 : 4</tr></td>
<tr><td class=br>Moravec Michael</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>0 : 8</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Tseluiko Artem</td><td class=bc>8 : 1</tr></td>
<tr><td class=br>Stykailo Dmitri</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>1 : 1</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>5 : 0</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>L�vmanis Roberts</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Nilsson Gustav</td><td class=bc>-</td><td class=bl>Janouskovec Jan</td><td class=bc>2 : 2</tr></td>
<tr><td class=br>Pleikys Jonas</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>0 : 2</tr></td>
<tr><td class=br>Wallin Wilton</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Tseluiko Artem</td><td class=bc>-</td><td class=bl>Skudr�tis Alekss</td><td class=bc>6 : 2</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Stykailo Dmitri</td><td class=bc>-</td><td class=blW>L�vmanis Roberts</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Janouskovec Jan</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Matantsev Artem</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Nilsson Gustav</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Pleikys Jonas</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=brW>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>Pylypenko Oleksandr</td><td class=bc>7 : 1</tr></td>
<tr><td class=brW>Tseluiko Artem</td><td class=bc>-</td><td class=bl>L�vmanis Roberts</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Janouskovec Jan</td><td class=bc>6 : 0</tr></td>
<tr><td class=br>Stykailo Dmitri</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>10 : 0</tr></td>
<tr><td class=brW>Nilsson Gustav</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>4 : 3</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=blW>L�vmanis Roberts</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Janouskovec Jan</td><td class=bc>2 : 3</tr></td>
<tr><td class=br>Tseluiko Artem</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 4</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Stykailo Dmitri</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>2 : 0</tr></td>
<tr><td class=brW>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>5 : 4</tr></td>
<tr><td class=brW>Matantsev Artem</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>14</td></tr>
<tr><td class=brW>L�vmanis Roberts</td><td class=bc>-</td><td class=bl>Janouskovec Jan</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Pylypenko Oleksandr</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 6</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Tseluiko Artem</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>5 : 2</tr></td>
<tr><td class=brW>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=bl>Wallin Wilton</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Stykailo Dmitri</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>3 : 1</tr></td>
<tr><td class=br>Vazoli�� Regn�rs</td><td class=bc>-</td><td class=blW>Nilsson Gustav</td><td class=bc>2 : 3</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>15</td></tr>
<tr><td class=br>Janouskovec Jan</td><td class=bc>-</td><td class=blW>Nilsson Eddie</td><td class=bc>1 : 5</tr></td>
<tr><td class=br>L�vmanis Roberts</td><td class=bc>-</td><td class=bl>-----</td><td class=bc>&nbsp;</tr></td>
<tr><td class=brW>Pylypenko Oleksandr</td><td class=bc>-</td><td class=bl>Moravec Michael</td><td class=bc>7 : 0</tr></td>
<tr><td class=br>Skudr�tis Alekss</td><td class=bc>-</td><td class=blW>Wallin Wilton</td><td class=bc>3 : 5</tr></td>
<tr><td class=brW>Tseluiko Artem</td><td class=bc>-</td><td class=bl>Pleikys Jonas</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Lagzdi�a Krista Annija</td><td class=bc>-</td><td class=blW>Nilsson Gustav</td><td class=bc>1 : 3</tr></td>
<tr><td class=brW>Stykailo Dmitri</td><td class=bc>-</td><td class=bl>Matantsev Artem</td><td class=bc>3 : 2</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
