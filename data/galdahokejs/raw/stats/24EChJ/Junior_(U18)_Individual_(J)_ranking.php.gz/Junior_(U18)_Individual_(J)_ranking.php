<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Junior (U18) Individual (J)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Junior_(U18)_Individual_(J)_list.php">Final Ranking</a></span></h2></div></div></div></div><h3 align="right">Junior (U18) Individual (J)&nbsp;&nbsp;</h3>
<p><div align="center">
<p class=v><br>
<div align=center><table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0 class="rnk">
<tr><th>&nbsp;</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">M</th>
<th align="center">+</th>
<th align="center">=</th>
<th align="center">-</th>
<th>&nbsp;</th>
<th>&nbsp;</th>
<th align="center">P</th>
</tr>
<tr><td class=ar>1.</td>
<td class=al><a href="stats.php?idpl=116&x=-59&p=Matantsev%20Artem">Matantsev Artem</a></td>
<td class=al>UKR</td>
<td class=ar>29</td>
<td class=ar>23</td>
<td class=ar>0</td>
<td class=ar>6</td>
<td class=ar>117</td>
<td class=al>&nbsp;:&nbsp;68</td>
<td class=ar>46</td>
</tr><tr><td class=br>2.</td>
<td class=bl><a href="stats.php?idpl=101&x=-59&p=Matantsev%20Evgeniy">Matantsev Evgeniy</a></td>
<td class=bl>UKR</td>
<td class=br>29</td>
<td class=br>20</td>
<td class=br>0</td>
<td class=br>9</td>
<td class=br>121</td>
<td class=bl>&nbsp;:&nbsp;78</td>
<td class=br>40</td>
</tr><tr><td class=ar>3.</td>
<td class=al><a href="stats.php?idpl=5&x=-59&p=Vazoli%C5%86%C5%A1%20Regn%C4%81rs">Vazoli�� Regn�rs</a></td>
<td class=al>LAT</td>
<td class=ar>29</td>
<td class=ar>18</td>
<td class=ar>0</td>
<td class=ar>11</td>
<td class=ar>83</td>
<td class=al>&nbsp;:&nbsp;58</td>
<td class=ar>36</td>
</tr><tr><td class=br>4.</td>
<td class=bl><a href="stats.php?idpl=43&x=-59&p=Naglis%20Edgars">Naglis Edgars</a></td>
<td class=bl>LAT</td>
<td class=br>28</td>
<td class=br>15</td>
<td class=br>1</td>
<td class=br>12</td>
<td class=br>107</td>
<td class=bl>&nbsp;:&nbsp;77</td>
<td class=br>31</td>
</tr><tr><td class=ar>5.</td>
<td class=al><a href="stats.php?idpl=34&x=-59&p=Re%C4%B7is%20J%C4%93kabs">Re�is J�kabs</a></td>
<td class=al>LAT</td>
<td class=ar>19</td>
<td class=ar>11</td>
<td class=ar>1</td>
<td class=ar>7</td>
<td class=ar>64</td>
<td class=al>&nbsp;:&nbsp;34</td>
<td class=ar>23</td>
</tr><tr><td class=br>6.</td>
<td class=bl><a href="stats.php?idpl=104&x=-59&p=Nilsson%20Eddie">Nilsson Eddie</a></td>
<td class=bl>SWE</td>
<td class=br>18</td>
<td class=br>11</td>
<td class=br>0</td>
<td class=br>7</td>
<td class=br>61</td>
<td class=bl>&nbsp;:&nbsp;38</td>
<td class=br>22</td>
</tr><tr><td class=ar>7.</td>
<td class=al><a href="stats.php?idpl=211&x=-59&p=L%C4%ABvmanis%20Roberts">L�vmanis Roberts</a></td>
<td class=al>LAT</td>
<td class=ar>20</td>
<td class=ar>11</td>
<td class=ar>2</td>
<td class=ar>7</td>
<td class=ar>59</td>
<td class=al>&nbsp;:&nbsp;55</td>
<td class=ar>24</td>
</tr><tr><td class=br>8.</td>
<td class=bl><a href="stats.php?idpl=83&x=-59&p=Baumanis%20Toms">Baumanis Toms</a></td>
<td class=bl>LAT</td>
<td class=br>16</td>
<td class=br>8</td>
<td class=br>2</td>
<td class=br>6</td>
<td class=br>49</td>
<td class=bl>&nbsp;:&nbsp;39</td>
<td class=br>18</td>
</tr><tr><td class=ar>9.</td>
<td class=al><a href="stats.php?idpl=67&x=-59&p=Mihhaljov%20Timur">Mihhaljov Timur</a></td>
<td class=al>EST</td>
<td class=ar>12</td>
<td class=ar>7</td>
<td class=ar>2</td>
<td class=ar>3</td>
<td class=ar>39</td>
<td class=al>&nbsp;:&nbsp;26</td>
<td class=ar>16</td>
</tr><tr><td class=br>10.</td>
<td class=bl><a href="stats.php?idpl=29&x=-59&p=Lagzdi%C5%86a%20Krista%20Annija">Lagzdi�a Krista Annija</a></td>
<td class=bl>LAT</td>
<td class=br>13</td>
<td class=br>8</td>
<td class=br>1</td>
<td class=br>4</td>
<td class=br>56</td>
<td class=bl>&nbsp;:&nbsp;24</td>
<td class=br>17</td>
</tr><tr><td class=ar>11.</td>
<td class=al><a href="stats.php?idpl=421&x=-59&p=Nilsson%20Gustav">Nilsson Gustav</a></td>
<td class=al>SWE</td>
<td class=ar>13</td>
<td class=ar>7</td>
<td class=ar>2</td>
<td class=ar>4</td>
<td class=ar>32</td>
<td class=al>&nbsp;:&nbsp;34</td>
<td class=ar>16</td>
</tr><tr><td class=br>12.</td>
<td class=bl><a href="stats.php?idpl=156&x=-59&p=Storozhenko%20Glib">Storozhenko Glib</a></td>
<td class=bl>UKR</td>
<td class=br>12</td>
<td class=br>6</td>
<td class=br>2</td>
<td class=br>4</td>
<td class=br>37</td>
<td class=bl>&nbsp;:&nbsp;25</td>
<td class=br>14</td>
</tr><tr><td class=ar>13.</td>
<td class=al><a href="stats.php?idpl=231&x=-59&p=Tseluiko%20Artem">Tseluiko Artem</a></td>
<td class=al>UKR</td>
<td class=ar>13</td>
<td class=ar>7</td>
<td class=ar>1</td>
<td class=ar>5</td>
<td class=ar>41</td>
<td class=al>&nbsp;:&nbsp;33</td>
<td class=ar>15</td>
</tr><tr><td class=br>14.</td>
<td class=bl><a href="stats.php?idpl=406&x=-59&p=Kraus%20Vojtech">Kraus Vojtech</a></td>
<td class=bl>CZE</td>
<td class=br>12</td>
<td class=br>6</td>
<td class=br>1</td>
<td class=br>5</td>
<td class=br>37</td>
<td class=bl>&nbsp;:&nbsp;40</td>
<td class=br>13</td>
</tr><tr><td class=ar>15.</td>
<td class=al><a href="stats.php?idpl=426&x=-59&p=Wallin%20Wilton">Wallin Wilton</a></td>
<td class=al>SWE</td>
<td class=ar>13</td>
<td class=ar>6</td>
<td class=ar>1</td>
<td class=ar>6</td>
<td class=ar>54</td>
<td class=al>&nbsp;:&nbsp;42</td>
<td class=ar>13</td>
</tr><tr><td class=br>16.</td>
<td class=bl><a href="stats.php?idpl=427&x=-59&p=Forsberg%20James-John">Forsberg James-John</a></td>
<td class=bl>SWE</td>
<td class=br>12</td>
<td class=br>5</td>
<td class=br>2</td>
<td class=br>5</td>
<td class=br>35</td>
<td class=bl>&nbsp;:&nbsp;33</td>
<td class=br>12</td>
</tr><tr><td class=ar>17.</td>
<td class=al><a href="stats.php?idpl=411&x=-59&p=Tous%20Michal">Tous Michal</a></td>
<td class=al>CZE</td>
<td class=ar>12</td>
<td class=ar>6</td>
<td class=ar>0</td>
<td class=ar>6</td>
<td class=ar>39</td>
<td class=al>&nbsp;:&nbsp;49</td>
<td class=ar>12</td>
</tr><tr><td class=br>18.</td>
<td class=bl><a href="stats.php?idpl=45&x=-59&p=Skudr%C4%ABtis%20Alekss">Skudr�tis Alekss</a></td>
<td class=bl>LAT</td>
<td class=br>13</td>
<td class=br>5</td>
<td class=br>3</td>
<td class=br>5</td>
<td class=br>38</td>
<td class=bl>&nbsp;:&nbsp;34</td>
<td class=br>13</td>
</tr><tr><td class=ar>19.</td>
<td class=al><a href="stats.php?idpl=218&x=-59&p=Stykailo%20Dmitri">Stykailo Dmitri</a></td>
<td class=al>EST</td>
<td class=ar>13</td>
<td class=ar>5</td>
<td class=ar>2</td>
<td class=ar>6</td>
<td class=ar>29</td>
<td class=al>&nbsp;:&nbsp;45</td>
<td class=ar>12</td>
</tr><tr><td class=br>20.</td>
<td class=bl><a href="stats.php?idpl=380&x=-59&p=Nyg%C3%A5rd%20Benjamin">Nyg�rd Benjamin</a></td>
<td class=bl>NOR</td>
<td class=br>12</td>
<td class=br>3</td>
<td class=br>0</td>
<td class=br>9</td>
<td class=br>22</td>
<td class=bl>&nbsp;:&nbsp;51</td>
<td class=br>6</td>
</tr><tr><td class=ar>21.</td>
<td class=al><a href="stats.php?idpl=367&x=-59&p=Pylypenko%20Oleksandr">Pylypenko Oleksandr</a></td>
<td class=al>UKR</td>
<td class=ar>13</td>
<td class=ar>3</td>
<td class=ar>1</td>
<td class=ar>9</td>
<td class=ar>33</td>
<td class=al>&nbsp;:&nbsp;54</td>
<td class=ar>7</td>
</tr><tr><td class=br>22.</td>
<td class=bl><a href="stats.php?idpl=418&x=-59&p=Hermansson%20Alfons">Hermansson Alfons</a></td>
<td class=bl>SWE</td>
<td class=br>12</td>
<td class=br>2</td>
<td class=br>1</td>
<td class=br>9</td>
<td class=br>27</td>
<td class=bl>&nbsp;:&nbsp;61</td>
<td class=br>5</td>
</tr><tr><td class=ar>23.</td>
<td class=al><a href="stats.php?idpl=242&x=-59&p=Janouskovec%20Jan">Janouskovec Jan</a></td>
<td class=al>CZE</td>
<td class=ar>13</td>
<td class=ar>2</td>
<td class=ar>2</td>
<td class=ar>9</td>
<td class=ar>31</td>
<td class=al>&nbsp;:&nbsp;61</td>
<td class=ar>6</td>
</tr><tr><td class=br>24.</td>
<td class=bl><a href="stats.php?idpl=394&x=-59&p=Uimonen%20Emil">Uimonen Emil</a></td>
<td class=bl>FIN</td>
<td class=br>12</td>
<td class=br>1</td>
<td class=br>1</td>
<td class=br>10</td>
<td class=br>21</td>
<td class=bl>&nbsp;:&nbsp;51</td>
<td class=br>3</td>
</tr><tr><td class=ar>25.</td>
<td class=al><a href="stats.php?idpl=220&x=-59&p=Pleikys%20Jonas">Pleikys Jonas</a></td>
<td class=al>LTU</td>
<td class=ar>13</td>
<td class=ar>1</td>
<td class=ar>2</td>
<td class=ar>10</td>
<td class=ar>11</td>
<td class=al>&nbsp;:&nbsp;43</td>
<td class=ar>4</td>
</tr><tr><td class=br>26.</td>
<td class=bl><a href="stats.php?idpl=219&x=-59&p=Razkevich%20Mykhailo">Razkevich Mykhailo</a></td>
<td class=bl>UKR</td>
<td class=br>12</td>
<td class=br>0</td>
<td class=br>1</td>
<td class=br>11</td>
<td class=br>18</td>
<td class=bl>&nbsp;:&nbsp;50</td>
<td class=br>1</td>
</tr><tr><td class=ar>27.</td>
<td class=al><a href="stats.php?idpl=410&x=-59&p=Moravec%20Michael">Moravec Michael</a></td>
<td class=al>CZE</td>
<td class=ar>13</td>
<td class=ar>0</td>
<td class=ar>1</td>
<td class=ar>12</td>
<td class=ar>15</td>
<td class=al>&nbsp;:&nbsp;73</td>
<td class=ar>1</td>
</tr></table></td></tr></table></div></p>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
