<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1257">
<title>Junior (U18) Individual (J)</title>
<link rel="StyleSheet" href="../css.css" type="text/css">
<link rel="StyleSheet" href="../xcss.css" type="text/css">
</head>
<body>
<br>Back to <a href="https://galdahokejs.lv/index.php/en/ech2024results">Results page of ECh2024</a><br><br>
<div id="highlighted"><div id="header"><div class="container"><div class="">
<h2 class="page-title"><span><a href="Junior_(U18)_Individual_(J)_list.php">Junior (U18) Individual (J)</a></span></h2></div></div></div></div><p><div align="center">
<p class=v>Group Junior 1</br><div align=center>
<table border=1 cellpadding=5 cellspacing=0>
<tr><td class=ir>&nbsp;</td><td class=ic>&nbsp;</td>
<td class=ic>&nbsp;</td>
<td class=ic>1</td>
<td class=ic>2</td>
<td class=ic>3</td>
<td class=ic>4</td>
<td class=ic>5</td>
<td class=ic>6</td>
<td class=ic>7</td>
<td class=ic>8</td>
<td class=ic>9</td>
<td class=ic>10</td>
<td class=ic>11</td>
<td class=ic>12</td>
<td class=ic>13</td>
<td class=ic>Score</td><td class=ic>GDiff.</td>
<td class=ic>Summary</td><td class=ic>Points</td>
<td class=ic>Rank.</td>
</tr><tr><td class=ir>1/4</td><td class=d>1.</td><td class=kt><a href="stats.php?idpl=34&x=-59&p=J%C4%93%20Re%C4%B7is">J� Re�is</a></td><td class=kx>*</td>
<td class=kW>4:0</td>
<td class=kW>5:2</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kT>2:2</td>
<td class=kW>7:2</td>
<td class=kW>4:1</td>
<td class=kW>6:2</td>
<td class=kW>6:1</td>
<td class=kW>6:0</td>
<td class=kW>2:0</td>
<td class=kW>5:0</td>
<td class=br>51:17</td><td class=br>+34</td>
<td class=bc>9 - 1 - 2</td>
<td class=br><strong>19</strong></td><td class=d>1.</td>
</tr><tr><td class=ir>1/4</td><td class=d>2.</td><td class=kt><a href="stats.php?idpl=43&x=-59&p=Ed%20Naglis">Ed Naglis</a></td><td class=kL>0:4</td>
<td class=kx>*</td>
<td class=kL>1:5</td>
<td class=kW>7:2</td>
<td class=kT>3:3</td>
<td class=kW>1:0</td>
<td class=kW>8:3</td>
<td class=kW>2:1</td>
<td class=kW>8:1</td>
<td class=kW>7:1</td>
<td class=kW>8:4</td>
<td class=kW>10:1</td>
<td class=kW>6:1</td>
<td class=br>61:26</td><td class=br>+35</td>
<td class=bc>9 - 1 - 2</td>
<td class=br><strong>19</strong></td><td class=d>2.</td>
</tr><tr><td class=ir>1/4</td><td class=d>3.</td><td class=kt><a href="stats.php?idpl=101&x=-59&p=Ev%20Matantsev">Ev Matantsev</a></td><td class=kL>2:5</td>
<td class=kW>5:1</td>
<td class=kx>*</td>
<td class=kW>6:3</td>
<td class=kW>8:2</td>
<td class=kL>2:3</td>
<td class=kL>0:5</td>
<td class=kW>8:4</td>
<td class=kW>8:4</td>
<td class=kW>7:1</td>
<td class=kW>5:2</td>
<td class=kW>6:2</td>
<td class=kW>5:3</td>
<td class=br>62:35</td><td class=br>+27</td>
<td class=bc>9 - 0 - 3</td>
<td class=br><strong>18</strong></td><td class=d>3.</td>
</tr><tr><td class=ir>1/4</td><td class=d>4.</td><td class=kt><a href="stats.php?idpl=83&x=-59&p=To%20Baumanis">To Baumanis</a></td><td class=kW>3:2</td>
<td class=kL>2:7</td>
<td class=kL>3:6</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kT>1:1</td>
<td class=kW>4:0</td>
<td class=kT>2:2</td>
<td class=kW>5:3</td>
<td class=kW>4:0</td>
<td class=kW>10:2</td>
<td class=kW>3:1</td>
<td class=kW>3:2</td>
<td class=br>42:27</td><td class=br>+15</td>
<td class=bc>8 - 2 - 2</td>
<td class=br><strong>18</strong></td><td class=d>4.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>5.</td><td class=kt><a href="stats.php?idpl=67&x=-59&p=Ti%20Mihhaljov">Ti Mihhaljov</a></td><td class=kW>4:2</td>
<td class=kT>3:3</td>
<td class=kL>2:8</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kW>3:0</td>
<td class=kT>3:3</td>
<td class=kL>3:4</td>
<td class=kW>4:2</td>
<td class=kW>4:0</td>
<td class=kW>5:0</td>
<td class=kW>4:0</td>
<td class=br>39:26</td><td class=br>+13</td>
<td class=bc>7 - 2 - 3</td>
<td class=br><strong>16</strong></td><td class=d>5.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>6.</td><td class=kt><a href="stats.php?idpl=156&x=-59&p=Gl%20Storozhenko">Gl Storozhenko</a></td><td class=kT>2:2</td>
<td class=kL>0:1</td>
<td class=kW>3:2</td>
<td class=kT>1:1</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kL>1:4</td>
<td class=kW>2:1</td>
<td class=kW>6:2</td>
<td class=kL>4:5</td>
<td class=kW>7:2</td>
<td class=kW>3:1</td>
<td class=kW>6:1</td>
<td class=br>37:25</td><td class=br>+12</td>
<td class=bc>6 - 2 - 4</td>
<td class=br><strong>14</strong></td><td class=d>6.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>7.</td><td class=kt><a href="stats.php?idpl=406&x=-59&p=Vo%20Kraus">Vo Kraus</a></td><td class=kL>2:7</td>
<td class=kL>3:8</td>
<td class=kW>5:0</td>
<td class=kL>0:4</td>
<td class=kL>0:3</td>
<td class=kW>4:1</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>3:5</td>
<td class=kW>5:2</td>
<td class=kT>4:4</td>
<td class=kW>5:2</td>
<td class=kW>3:2</td>
<td class=br>37:40</td><td class=br>-3</td>
<td class=bc>6 - 1 - 5</td>
<td class=br><strong>13</strong></td><td class=d>7.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>8.</td><td class=kt><a href="stats.php?idpl=427&x=-59&p=Ja%20Forsberg">Ja Forsberg</a></td><td class=kL>1:4</td>
<td class=kL>1:2</td>
<td class=kL>4:8</td>
<td class=kT>2:2</td>
<td class=kT>3:3</td>
<td class=kL>1:2</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>2:1</td>
<td class=kW>4:0</td>
<td class=kW>6:3</td>
<td class=kW>5:3</td>
<td class=kW>4:2</td>
<td class=br>35:33</td><td class=br>+2</td>
<td class=bc>5 - 2 - 5</td>
<td class=br><strong>12</strong></td><td class=d>8.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>9.</td><td class=kt><a href="stats.php?idpl=411&x=-59&p=Mi%20Tous">Mi Tous</a></td><td class=kL>2:6</td>
<td class=kL>1:8</td>
<td class=kL>4:8</td>
<td class=kL>3:5</td>
<td class=kW>4:3</td>
<td class=kL>2:6</td>
<td class=kW>5:3</td>
<td class=kL>1:2</td>
<td class=kx>*</td>
<td class=kW>5:1</td>
<td class=kW>4:2</td>
<td class=kW>3:2</td>
<td class=kW>5:3</td>
<td class=br>39:49</td><td class=br>-10</td>
<td class=bc>6 - 0 - 6</td>
<td class=br><strong>12</strong></td><td class=d>9.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>10.</td><td class=kt><a href="stats.php?idpl=380&x=-59&p=Be%20Nyg%C3%A5rd">Be Nyg�rd</a></td><td class=kL>1:6</td>
<td class=kL>1:7</td>
<td class=kL>1:7</td>
<td class=kL>0:4</td>
<td class=kL>2:4</td>
<td class=kW>5:4</td>
<td class=kL>2:5</td>
<td class=kL>0:4</td>
<td class=kL>1:5</td>
<td class=kx>*</td>
<td class=kW>3:2</td>
<td class=kL>2:3</td>
<td class=kW>4:0</td>
<td class=br>22:51</td><td class=br>-29</td>
<td class=bc>3 - 0 - 9</td>
<td class=br><strong>6</strong></td><td class=d>10.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>11.</td><td class=kt><a href="stats.php?idpl=418&x=-59&p=Al%20Hermansson">Al Hermansson</a></td><td class=kL>0:6</td>
<td class=kL>4:8</td>
<td class=kL>2:5</td>
<td class=kL>2:10</td>
<td class=kL>0:4</td>
<td class=kL>2:7</td>
<td class=kT>4:4</td>
<td class=kL>3:6</td>
<td class=kL>2:4</td>
<td class=kL>2:3</td>
<td class=kx>*</td>
<td class=kW>4:3</td>
<td class=kW>2:1</td>
<td class=br>27:61</td><td class=br>-34</td>
<td class=bc>2 - 1 - 9</td>
<td class=br><strong>5</strong></td><td class=d>11.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>12.</td><td class=kt><a href="stats.php?idpl=394&x=-59&p=Em%20Uimonen">Em Uimonen</a></td><td class=kL>0:2</td>
<td class=kL>1:10</td>
<td class=kL>2:6</td>
<td class=kL>1:3</td>
<td class=kL>0:5</td>
<td class=kL>1:3</td>
<td class=kL>2:5</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kW>3:2</td>
<td class=kL>3:4</td>
<td class=kx>*</td>
<td class=kT>3:3</td>
<td class=br>21:51</td><td class=br>-30</td>
<td class=bc>1 - 1 - 10</td>
<td class=br><strong>3</strong></td><td class=d>12.</td>
</tr><tr><td class=ir>&nbsp;</td><td class=d>13.</td><td class=kt><a href="stats.php?idpl=219&x=-59&p=My%20Razkevich">My Razkevich</a></td><td class=kL>0:5</td>
<td class=kL>1:6</td>
<td class=kL>3:5</td>
<td class=kL>2:3</td>
<td class=kL>0:4</td>
<td class=kL>1:6</td>
<td class=kL>2:3</td>
<td class=kL>2:4</td>
<td class=kL>3:5</td>
<td class=kL>0:4</td>
<td class=kL>1:2</td>
<td class=kT>3:3</td>
<td class=kx>*</td>
<td class=br>18:50</td><td class=br>-32</td>
<td class=bc>0 - 1 - 11</td>
<td class=br><strong>1</strong></td><td class=d>13.</td>
</tr></table></div></p>
<p><div align=center><table border=0 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>1</td></tr>
<tr><td class=brW>Forsberg James-John</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>6 : 3</tr></td>
<tr><td class=br>Kraus Vojtech</td><td class=bc>-</td><td class=blW>Tous Michal</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Razkevich Mykhailo</td><td class=bc>-</td><td class=blW>Nyg�rd Benjamin</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Mihhaljov Timur</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Matantsev Evgeniy</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Baumanis Toms</td><td class=bc>7 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>2</td></tr>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=blW>Tous Michal</td><td class=bc>2 : 4</tr></td>
<tr><td class=brW>Forsberg James-John</td><td class=bc>-</td><td class=bl>Nyg�rd Benjamin</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Kraus Vojtech</td><td class=bc>-</td><td class=blW>Mihhaljov Timur</td><td class=bc>0 : 3</tr></td>
<tr><td class=br>Razkevich Mykhailo</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>3 : 5</tr></td>
<tr><td class=br>Re�is J�kabs</td><td class=bc>-</td><td class=blW>Baumanis Toms</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>3 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>3</td></tr>
<tr><td class=brW>Tous Michal</td><td class=bc>-</td><td class=bl>Nyg�rd Benjamin</td><td class=bc>5 : 1</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=blW>Mihhaljov Timur</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>4 : 8</tr></td>
<tr><td class=br>Kraus Vojtech</td><td class=bc>-</td><td class=blW>Baumanis Toms</td><td class=bc>0 : 4</tr></td>
<tr><td class=br>Razkevich Mykhailo</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>4 : 0</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>4</td></tr>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Mihhaljov Timur</td><td class=bc>2 : 4</tr></td>
<tr><td class=br>Tous Michal</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>4 : 8</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=blW>Baumanis Toms</td><td class=bc>2 : 10</tr></td>
<tr><td class=brW>Forsberg James-John</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Kraus Vojtech</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>3 : 8</tr></td>
<tr><td class=br>Razkevich Mykhailo</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>1 : 6</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>5</td></tr>
<tr><td class=br>Mihhaljov Timur</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>2 : 8</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Baumanis Toms</td><td class=bc>0 : 4</tr></td>
<tr><td class=brW>Tous Michal</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>4 : 8</tr></td>
<tr><td class=br>Forsberg James-John</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>1 : 2</tr></td>
<tr><td class=br>Kraus Vojtech</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>2 : 7</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>6</td></tr>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Baumanis Toms</td><td class=bc>6 : 3</tr></td>
<tr><td class=brW>Mihhaljov Timur</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>1 : 7</tr></td>
<tr><td class=br>Tous Michal</td><td class=bc>-</td><td class=blW>Storozhenko Glib</td><td class=bc>2 : 6</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>0 : 6</tr></td>
<tr><td class=brW>Forsberg James-John</td><td class=bc>-</td><td class=bl>Razkevich Mykhailo</td><td class=bc>4 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>7</td></tr>
<tr><td class=brW>Baumanis Toms</td><td class=bc>-</td><td class=bl>Uimonen Emil</td><td class=bc>3 : 1</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Naglis Edgars</td><td class=bc>5 : 1</tr></td>
<tr><td class=brW>Mihhaljov Timur</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>1 : 6</tr></td>
<tr><td class=brW>Tous Michal</td><td class=bc>-</td><td class=bl>Razkevich Mykhailo</td><td class=bc>5 : 3</tr></td>
<tr><td class=br>Hermansson Alfons</td><td class=bc>-</td><td class=bl>Kraus Vojtech</td><td class=bc>4 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>8</td></tr>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=blW>Naglis Edgars</td><td class=bc>1 : 10</tr></td>
<tr><td class=br>Baumanis Toms</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>1 : 1</tr></td>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>2 : 5</tr></td>
<tr><td class=brW>Mihhaljov Timur</td><td class=bc>-</td><td class=bl>Razkevich Mykhailo</td><td class=bc>4 : 0</tr></td>
<tr><td class=br>Nyg�rd Benjamin</td><td class=bc>-</td><td class=blW>Kraus Vojtech</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Tous Michal</td><td class=bc>-</td><td class=blW>Forsberg James-John</td><td class=bc>1 : 2</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>9</td></tr>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Storozhenko Glib</td><td class=bc>1 : 0</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=blW>Re�is J�kabs</td><td class=bc>0 : 2</tr></td>
<tr><td class=brW>Baumanis Toms</td><td class=bc>-</td><td class=bl>Razkevich Mykhailo</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Matantsev Evgeniy</td><td class=bc>-</td><td class=blW>Kraus Vojtech</td><td class=bc>0 : 5</tr></td>
<tr><td class=br>Mihhaljov Timur</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>3 : 3</tr></td>
<tr><td class=brW>Nyg�rd Benjamin</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>3 : 2</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>10</td></tr>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Re�is J�kabs</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Razkevich Mykhailo</td><td class=bc>6 : 1</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=blW>Kraus Vojtech</td><td class=bc>2 : 5</tr></td>
<tr><td class=br>Baumanis Toms</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>2 : 2</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>5 : 2</tr></td>
<tr><td class=br>Mihhaljov Timur</td><td class=bc>-</td><td class=blW>Tous Michal</td><td class=bc>3 : 4</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>11</td></tr>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Razkevich Mykhailo</td><td class=bc>5 : 0</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Kraus Vojtech</td><td class=bc>1 : 4</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>2 : 1</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=blW>Hermansson Alfons</td><td class=bc>3 : 4</tr></td>
<tr><td class=brW>Baumanis Toms</td><td class=bc>-</td><td class=bl>Tous Michal</td><td class=bc>5 : 3</tr></td>
<tr><td class=brW>Matantsev Evgeniy</td><td class=bc>-</td><td class=bl>Nyg�rd Benjamin</td><td class=bc>7 : 1</tr></td>
</table>
</td></tr></table>
</td><td>&nbsp;</td><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>12</td></tr>
<tr><td class=br>Razkevich Mykhailo</td><td class=bc>-</td><td class=blW>Kraus Vojtech</td><td class=bc>2 : 3</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>4 : 1</tr></td>
<tr><td class=brW>Storozhenko Glib</td><td class=bc>-</td><td class=bl>Hermansson Alfons</td><td class=bc>7 : 2</tr></td>
<tr><td class=brW>Naglis Edgars</td><td class=bc>-</td><td class=bl>Tous Michal</td><td class=bc>8 : 1</tr></td>
<tr><td class=brW>Uimonen Emil</td><td class=bc>-</td><td class=bl>Nyg�rd Benjamin</td><td class=bc>3 : 2</tr></td>
<tr><td class=brW>Baumanis Toms</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>2 : 1</tr></td>
</table>
</td></tr></table>
</td></tr><tr><td colspan=5>&nbsp;</td></tr><tr><td>
<table border=1 cellpadding=0 cellspacing=0 bordercolor=#000000 bordercolordark=#000000 bordercolorlight=#008080><tr><td>
<table border=0 cellpadding=2 cellspacing=0>
<tr><td class=kt colspan=4>13</td></tr>
<tr><td class=brW>Kraus Vojtech</td><td class=bc>-</td><td class=bl>Forsberg James-John</td><td class=bc>3 : 2</tr></td>
<tr><td class=br>Razkevich Mykhailo</td><td class=bc>-</td><td class=blW>Hermansson Alfons</td><td class=bc>1 : 2</tr></td>
<tr><td class=brW>Re�is J�kabs</td><td class=bc>-</td><td class=bl>Tous Michal</td><td class=bc>6 : 2</tr></td>
<tr><td class=br>Storozhenko Glib</td><td class=bc>-</td><td class=blW>Nyg�rd Benjamin</td><td class=bc>4 : 5</tr></td>
<tr><td class=br>Naglis Edgars</td><td class=bc>-</td><td class=bl>Mihhaljov Timur</td><td class=bc>3 : 3</tr></td>
<tr><td class=br>Uimonen Emil</td><td class=bc>-</td><td class=blW>Matantsev Evgeniy</td><td class=bc>2 : 6</tr></td>
</table></td></tr></table></td></tr></table></div></p><hr>
</div></p>
<div class="pata"><br><a href="https://www.trefik.com" class="pata">generated by Trefik SW</a>&nbsp;&nbsp;<br>&nbsp;</div></body></html>
